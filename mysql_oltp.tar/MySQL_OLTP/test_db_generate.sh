#/bin/bash
# 对1111数据库生成一份测试实例
# TODO
# √1. 数据灌满后能否自动退出：自带的两个参数，时间和最大请求数，设置为0就不退出了。无法自动退出。只能ctrl c或者检查是否还有输出TPS。会自动结束的。
# 2. 如何跟实际测试的脚本中一些参数保持一致，如表数量，行数，等
# 3. MySQL的参数在哪里检查？binlog，QC这些



port=1111
# 有的机器没有mysql 客户端
[[ ! -f "/usr/bin/mysql" ]] && (echo 'mysql-client not exist! Install it.'; yum -y install mysql.x86_64 )
mysql -S /tmp/mysql${port}.sock -e "select now()" >/dev/null 2>&1 

if [[ $? -ne 0 ]]
then
    echo "MySQL1111 not exists, exit."
    exit 1
fi

# create database sysbench
mysql -S /tmp/mysql${port}.sock -e "create database sysbench" >/dev/null 2>&1 


# 热数据比例
dist_pct=20
# 请求落到热数据的比例
dist_res=60

#10个表 每个表1000w数据 128进程并发写
tb_count=10
tb_size=10000000
th_num=128
rq_max=999999999
time_max=3600
db_engine='innodb'

sysbench_path='/usr/home/gaopeng4/sysbench/sysbench/tests/db/'
sysbench_type='parallel_prepare.lua'


sysbench_path_hmoe="$sysbench_path""$sysbench_type"


if [[ ! -f $sysbench_path_hmoe ]]
then
    echo "File $sysbench_path_hmoe not exist!"
    exit 1
fi


# 使用并发生成数据，注意是run，不是prepare
# 使用socket连接，节省开销


sysbench --test="$sysbench_path""$sysbench_type"  \
--mysql-socket=/tmp/mysql${port}.sock --mysql-db=sysbench \
--oltp-tables-count=$tb_count --oltp-table-size=$tb_size \
--num-threads=$th_num  --oltp-test-mode=complex --rand-init=on \
--oltp-dist-type=special --oltp-dist-pct=$dist_pct --oltp-dist-res=$dist_res  \
--max-time=$time_max --max-requests=$rq_max --report-interval=1 \
--mysql-table-engine=$db_engine \
run

