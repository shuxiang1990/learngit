# 用来自动化完成基于sysbench的MySQL压测
# TODO
# √1. 版本是写死的，无法指定
# √2. 端口号指定，写到脚本外部传参
# √3. sysbench结果处理目前是写死的OLTP
# 4. sysbench的目录，目前是写死的
# √5. sysbench的测试方法，目前只能通过改脚本实现
# 6. 是否考虑独立一个配置文件，写好sysbench的目录位置，还有要测试的端口、测试类型
# 7. data1是写死的，测试一些多盘情况下，就需要重新挂载了，麻烦
# √8. pidstat 在6、7系统上，输出格式不一样
# √9. 用户输入端口号的校验、执行时间的校验



# 进度条拷贝
progress_cp()
{
if [[ $# -ne 2 ]]
then
echo "usage:$0 file1 file2"
exit 1
fi

if [[ -e $2 ]]
then
echo "$2 exist!!"
exit
fi

cp -rfp $1 $2 &
sleep 0.2
count=0
total_size=`du -s "$1" | awk '{print $1}'`
while [[ true ]]; do
   count=`du -s "$2" | awk '{print $1}'`
   if [[ `ps aux | grep -w cp | grep -w "$1 $2" | grep -v grep | wc -l` -eq 0 ]]; then
      # 打印出一个100%
      echo '' | awk -v total_size=100 -v count=100 '{
           percent = count / total_size * 100
           printf "%3d%% [",percent
           for (i=0;i<=percent;i++)
              printf "=" 
           printf ">"
           for (i=percent;i<100;i++)
              printf " "
           printf "]\r"
           } END {}' 
      # echo -en "\ncopy $1 to $2 finish!\n"
      echo -en "\n"
      break
   else
     if [[ `expr $count % 10` -eq 0 ]]; then
        echo '' | awk -v total_size=$total_size -v count=$count '{
             percent = count / total_size * 100
             printf "%3d%% [",percent
             for (i=0;i<=percent;i++)
                printf "=" 
             printf ">"
             for (i=percent;i<100;i++)
                printf " "
             printf "]\r"
             } END {}' 
     fi
   fi
   sleep 0.1
done
}


# 拷贝1111 到新的db提供测试
gen_db()
{
if [[ ! -d /data1/mysql1111 ]]
then 
echo "mysql1111 not exist! exit!"
exit
fi

if [[ $# -ne 2 ]]
then
echo "usage:$0 port db_version"
exit 1
fi

port=$1
db_version=$2

if [[ ! -d /usr/local/mysql-${db_version} ]]
then
    echo "/usr/local/mysql-${db_version} not exist, exit."
    exit 1
fi


# 增加对应的用户
groupadd -r mysql > /dev/null 2>&1
useradd  -r -g mysql -M -s /sbin/nologin mysql > /dev/null 2>&1
useradd  -r -g mysql -M -s /sbin/nologin my${port} > /dev/null 2>&1

# 保留当前目录
dir_source=`pwd`
# echo $dir_source
# cp /data1/mysql1111 /data1/mysql${port} -r
progress_cp  /data1/mysql1111 /data1/mysql${port}
chown -R my${port}:mysql /data1/mysql${port}
mv  /data1/mysql${port}/my1111.cnf /data1/mysql${port}/my${port}.cnf
sed -in "s/1111/${port}/g" /data1/mysql${port}/my${port}.cnf
cd /usr/local/mysql-${db_version}/bin
./mysqld_safe  --defaults-file=/data1/mysql${port}/my${port}.cnf > /dev/null 2>&1  &
cd $dir_source
}


# 检查db是否ready, 是否可连接
db_ready()
{
if [[ $# -ne 1 ]]
then
echo "usage:$0 port"
exit 1
fi

while [[ 1 ]]
do 
  mysql -P$1 -h127.0.0.1 -uroot -p123 -e "exit"  2>/dev/null
  if [[ $? -eq 0 ]]
    then
    break
    echo "db ready"
  else
    #echo "db not ready, try again"
    sleep 0.5
  fi
done 
}


# 倒计时功能 如果检测到sysbench进程不在,就退出
begin_countdown()
{
if [[ $# -ne 1 ]]
then
echo "usage:$0 countdown"
exit 1
fi

i=$1
while [[ 1 ]]
do
# 输出到一行,有倒计时的功能
echo -en "\r$i "
sleep 1
let i=i-1
  # 如果发现已经没有这个进程了,就退出计数
  if [[ `ps aux | grep -w 'sysbench --test' --color  | grep -v grep | wc -l` -eq 0 ]]
  then
    # echo -en "\r0 "
    echo
    break
  fi
done
}


# 进行sysbench压测
do_sysbench()
{
if [[ $# -ne 3 ]]
then
echo "usage:$0 port run_time sysbench_type"
exit 1
fi

port=$1
time_max=$2
sysbench_type=$3

>${port}_sysbench_result.sql

tb_count=10
tb_size=10000000
th_num=64
rq_max=999999999

# 热数据比例
dist_pct=20
# 请求落到热数据的比例
dist_res=60


sysbench --test=/usr/home/gaopeng4/sysbench/sysbench/tests/db/${sysbench_type}.lua \
--mysql-host=127.0.0.1 --mysql-port=$port --mysql-user=root --mysql-password=123 --mysql-db=sysbench \
--oltp-tables-count=$tb_count --oltp-table-size=$tb_size --num-threads=$th_num \
--oltp-test-mode=complex --rand-init=on --oltp-dist-type=special --oltp-dist-pct=$dist_pct --oltp-dist-res=$dist_res  \
--max-time=$time_max --max-requests=$rq_max --report-interval=1 \
run >> ${port}_sysbench_result.sql 
}



# 整理数据结果,把第N列取出来
# 具体取哪一列数据需要看上面的测试是什么类型，是oltp还是update
process_result()
{
if [[ $# -ne 3 ]]
then
echo "usage:$0 port run_time sysbench_type"
exit 1
fi

port=$1
run_time=$2
sysbench_type=$3


if [[ -f ${port}_sysbench_result.sql ]]
then
    # 打印一个表头
    echo "Time $sysbench_type" > ${port}_${sysbench_type}.sql

    # 根据压测类型获对应的字段
    if [[ X$sysbench_type = X'oltp' ]]
    then
        # oltp $5
    sed -n "/Threads started/,/OLTP test statistics:/p" ${port}_sysbench_result.sql | sed '1,2d' | sed '$d' | tr -d '[]' | awk '{print $1, $5}' | tr -d 's,' | head -n $run_time >> ${port}_${sysbench_type}.sql
    elif [[ X$sysbench_type = X'select' ]]
    then
        # select $7
        sed -n "/Threads started/,/OLTP test statistics:/p" ${port}_sysbench_result.sql | sed '1,2d' | sed '$d' | tr -d '[]' | awk '{print $1, $7}' | tr -d 's,' | head -n $run_time >> ${port}_${sysbench_type}.sql
    else 
        # insert/update/delete/ $9
        sed -n "/Threads started/,/OLTP test statistics:/p" ${port}_sysbench_result.sql | sed '1,2d' | sed '$d' | tr -d '[]' | awk '{print $1, $9}' | tr -d 's,' | head -n $run_time >> ${port}_${sysbench_type}.sql 
    fi


    # 获取响应时间
    echo "Time RT" > ${port}_rt.sql 
    sed -n "/Threads started/,/OLTP test statistics:/p" ${port}_sysbench_result.sql | sed '1,2d' | sed '$d' | tr -d '[]' | awk '{print $1,$12}' | tr -d 'ms' >> ${port}_rt.sql 
    
else
    echo "file ${port}_sysbench_result.sql not found, exit"
fi
}


# 清理临时文件,把有用的文件rsync到171
clean()
{
# 如果只是跑了一个端口,需要把另一个结果生成为空文件
# [[ ! -f ${port}.sql ]] && touch ${port}.sql
rsync *.sql 10.55.22.171::gaopeng4
# rm -fr *.sql 
# 发一个通知，说测试完了
python2.6 alert.py
}


# MySQL使用的cpu
pid_cpu()
{
if [[ $# -ne 1 ]]
then
echo "usage:$0 port"
exit 1
fi

port=$1

pid=`ps aux | grep mysqld -w | grep  my${port} | grep -v grep | awk '{print $2}'`
os_version=`cat /etc/redhat-release  | tr -d 'a-zA-Z() ' | head -n 1 | awk -F. '{print $1}'`

if [[ $os_version -eq 6 ]]
then
    pidstat  -p $pid  1 1 | grep Average | awk '{print $6}' | awk -F. '{print $1}'
else
    # Centos7 上是第7 列
    pidstat  -p $pid  1 1 | grep Average | awk '{print $7}' | awk -F. '{print $1}'
fi

}

# MySQL使用的IO
pid_io()
{
if [[ $# -ne 1 ]]
then
echo "usage:$0 port"
exit 1
fi

port=$1
pid=`ps aux | grep mysqld -w | grep  my${port} | grep -v grep | awk '{print $2}'`
os_version=`cat /etc/redhat-release  | tr -d 'a-zA-Z() ' | head -n 1 | awk -F. '{print $1}'`

# 需要对操作系统版本进行判断
if [[ $os_version -eq 6 ]]
then
    pidstat  -p $pid -d  1 1 | grep Average | awk '{print $3,$4}'  | awk -F. '{print $1, $2}' | awk '{print $1,$3}'
else
    # Centos7 上是第4 5 列
    pidstat  -p $pid -d  1 1 | grep Average | awk '{print $4,$5}'  | awk -F. '{print $1, $2}' | awk '{print $1,$3}'

fi
}

# 系统负载
sys_load()
{
cat /proc/loadavg | awk '{print $1}' |  awk -F. '{print $1}'
}


# cpuidle 和 iostat util
sys_mon()
{
if [[ $# -ne 1 ]]
then
echo "usage:$0 time"
exit 1
fi

i=$1
# cpu idle io util
vmstat 1 $i | awk '{print $15}' | egrep -v '^$|id' |  awk -F. '{print $1}'  >> sys_cpu_idle.sql &

# 获取对应的磁盘，去掉sdb1后面的1，如果是NVMe卡，去掉后面的p1字符
disk_label=`df -l | grep data1  | awk '{print $1}'| awk -F'/' '{print $3}' | sed 's/[0-9]$//' | sed 's/p$//'`
iostat  -dx 1 $i $disk_label |  awk -v disk_label=$disk_label '{if ($1 == disk_label) {print $NF} }'  >> sys_io_util.sql &

# sys load
while [[ 1 ]]
do 
   sys_load >> sys_load.sql &
   let i=i-1
   sleep 1
       if [[ $i -eq 0 ]]
       then
       exit
       fi
done
}


# 调用上面的函数，进行MySQL资源统计
port_mon()
{
if [[ $# -ne 2 ]]
then
echo "usage:$0 time port"
exit 1
fi

i=$1
port=$2
while [[ 1 ]]
do 
   pid_cpu $port >> ${port}_cpu.sql  &
   pid_io  $port >> ${port}_io.sql  
   let i=i-1
   if [[ $i -eq 0 ]]
   then
   exit
   fi
done
}



drop_cache()
{
sync; echo 1 > /proc/sys/vm/drop_caches  
swapoff -a && swapon -a
}


db_stop()
{
if [[ $# -ne 1 ]]
then
    echo "usage:$0 port"
    exit 1
fi

port=$1
ps aux | grep mysqld  | grep -w $port --color | grep -v grep |  awk '{print $2}' | xargs -i kill -9 {}  > /dev/null 2>&1
}



# main

# Help
if [[ $# -ne 4 ]]
then
echo "usage:$0 NewDBPort RunTime SysbenchType DBVersion"
echo "SysbenchType: insert|delete|update_index|update_non_index|select|select_random_ranges|select_random_points|oltp DBVersion"
exit 1
fi

port=$1
run_time=$2
sysbench_type=$3
db_version=$4


# 检查port、runtime参数
if echo $port | egrep -q '^[0-9]+$'; then
    # $var is a number
    :
else
    # $var is not a number
    echo "Port must be a number, exit"
    exit 1
fi


if echo $run_time | egrep -q '^[0-9]+$'; then
    # $var is a number
    :
else
    # $var is not a number
    echo "run_time must be a number, exit"
    exit 1
fi



# 检查逻辑
# 没有1111实例不行
if [[ ! -d /data1/mysql1111 ]]
then
echo "mysql1111 not exist! exit!"
exit
fi

# 检查是否安装了对应版本的DB
if [[ ! -d /usr/local/mysql-${db_version} ]]
then
    echo "/usr/local/mysql-${db_version} not exist, exit."
    exit 1
fi

# 已经有测试目录就退出
if [[ -d /data1/mysql${port} ]]
then
echo "mysql${port} already exist! exit!"
exit
fi

# 判断用户输入的sysbench类型是否合法
sysbench_type_list=('insert' 'delete' 'update_index' 'update_non_index' 'select' 'select_random_ranges' 'select_random_points' 'oltp')
echo  "${sysbench_type_list[@]}" | grep -w $sysbench_type -q
if [[ $? -ne 0 ]]
then
    echo "sysbench_type Error! exit."
    exit 1
fi


# 开始执行全部操作
rm -fr *.sql 

echo "1.stop db"
db_stop $port

# 如果是简单测试,这里关闭,否则浪费时间
echo "2.cp db && start db"
gen_db ${port} $db_version

echo "3.drop cache"
drop_cache 

echo "4.get db ready before run sysbench"
db_ready ${port}

echo "5.bgein sysbench"
do_sysbench ${port} $run_time $sysbench_type >/dev/null 2>&1 &

echo "6.start resource mon"
sys_mon $run_time >/dev/null 2>&1 &
port_mon $run_time ${port}  >/dev/null 2>&1 &

echo "7.start countdown"
begin_countdown $run_time

echo "8.End"
process_result ${port} $run_time $sysbench_type

# clean 

# rsync *.sql 10.55.22.171::gaopeng4/cg_test/tokudb


