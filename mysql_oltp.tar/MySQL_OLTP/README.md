- test_db_generate.sh
  - 用于生成测试的实例，默认是1111端口
  - 要测试什么引擎，修改这个脚本即可


- MySQL_sysbench_test_v2.sh
  - 使用上述的1111端口，cp一个新的实例，改配置，启动，测试


- draw.sh
   - 调用画图脚本画图
