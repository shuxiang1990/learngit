#! /bin/bash
#
# 对测试完的数据进行处理和画图
#

tests=(oltp insert delete update_index update_non_index select select_random_ranges select_random_points)

for t in ${tests[@]}
do

#  echo 'Time InnoDB RocksDB TokuDB' > data.sql
#  paste -d ' ' 5555_tps.sql 6666_tps.sql  | awk '{print $1, $2, $4}' >>  data.sql
#  
#  sed  '2d' data.sql  > tmp_file
#  
#  mv tmp_file data.sql
#  
#  ./draw_file.py  data.sql PM863_10\*480_TPS TPS
  echo $t 
  find . 

done
