sysbench 0.5:  multi-threaded system evaluation benchmark

Running the test with following options:
Number of threads: 64
Report intermediate results every 1 second(s)
Initializing random number generator from timer.

Random number generator seed is 0 and will be ignored


Threads started!

[   1s] threads: 64, tps: 0.00, reads: 0.00, writes: 19348.83, response time: 9.65ms (95%), errors: 0.00, reconnects:  0.00
[   2s] threads: 64, tps: 0.00, reads: 0.00, writes: 25978.89, response time: 7.83ms (95%), errors: 0.00, reconnects:  0.00
[   3s] threads: 64, tps: 0.00, reads: 0.00, writes: 30216.52, response time: 7.01ms (95%), errors: 0.00, reconnects:  0.00
[   4s] threads: 64, tps: 0.00, reads: 0.00, writes: 31195.98, response time: 6.41ms (95%), errors: 0.00, reconnects:  0.00
[   5s] threads: 64, tps: 0.00, reads: 0.00, writes: 32715.96, response time: 6.46ms (95%), errors: 0.00, reconnects:  0.00
[   6s] threads: 64, tps: 0.00, reads: 0.00, writes: 35175.04, response time: 5.70ms (95%), errors: 0.00, reconnects:  0.00
[   7s] threads: 64, tps: 0.00, reads: 0.00, writes: 34404.96, response time: 5.14ms (95%), errors: 0.00, reconnects:  0.00
[   8s] threads: 64, tps: 0.00, reads: 0.00, writes: 39771.90, response time: 3.66ms (95%), errors: 0.00, reconnects:  0.00
[   9s] threads: 64, tps: 0.00, reads: 0.00, writes: 47752.39, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[  10s] threads: 64, tps: 0.00, reads: 0.00, writes: 25981.97, response time: 8.72ms (95%), errors: 0.00, reconnects:  0.00
[  11s] threads: 64, tps: 0.00, reads: 0.00, writes: 31256.04, response time: 6.01ms (95%), errors: 0.00, reconnects:  0.00
[  12s] threads: 64, tps: 0.00, reads: 0.00, writes: 32599.62, response time: 5.87ms (95%), errors: 0.00, reconnects:  0.00
[  13s] threads: 64, tps: 0.00, reads: 0.00, writes: 30901.57, response time: 6.52ms (95%), errors: 0.00, reconnects:  0.00
[  14s] threads: 64, tps: 0.00, reads: 0.00, writes: 34006.86, response time: 5.09ms (95%), errors: 0.00, reconnects:  0.00
[  15s] threads: 64, tps: 0.00, reads: 0.00, writes: 46180.04, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[  16s] threads: 64, tps: 0.00, reads: 0.00, writes: 36835.04, response time: 5.36ms (95%), errors: 0.00, reconnects:  0.00
[  17s] threads: 64, tps: 0.00, reads: 0.00, writes: 34013.00, response time: 4.97ms (95%), errors: 0.00, reconnects:  0.00
[  18s] threads: 64, tps: 0.00, reads: 0.00, writes: 32225.97, response time: 5.14ms (95%), errors: 0.00, reconnects:  0.00
[  19s] threads: 64, tps: 0.00, reads: 0.00, writes: 32122.02, response time: 5.79ms (95%), errors: 0.00, reconnects:  0.00
[  20s] threads: 64, tps: 0.00, reads: 0.00, writes: 32592.02, response time: 5.04ms (95%), errors: 0.00, reconnects:  0.00
[  21s] threads: 64, tps: 0.00, reads: 0.00, writes: 42981.95, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[  22s] threads: 64, tps: 0.00, reads: 0.00, writes: 42240.92, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[  23s] threads: 64, tps: 0.00, reads: 0.00, writes: 30922.84, response time: 6.33ms (95%), errors: 0.00, reconnects:  0.00
[  24s] threads: 64, tps: 0.00, reads: 0.00, writes: 32887.25, response time: 5.58ms (95%), errors: 0.00, reconnects:  0.00
[  25s] threads: 64, tps: 0.00, reads: 0.00, writes: 32873.95, response time: 5.08ms (95%), errors: 0.00, reconnects:  0.00
[  26s] threads: 64, tps: 0.00, reads: 0.00, writes: 32190.99, response time: 5.24ms (95%), errors: 0.00, reconnects:  0.00
[  27s] threads: 64, tps: 0.00, reads: 0.00, writes: 39402.02, response time: 3.49ms (95%), errors: 0.00, reconnects:  0.00
[  28s] threads: 64, tps: 0.00, reads: 0.00, writes: 46169.68, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[  29s] threads: 64, tps: 0.00, reads: 0.00, writes: 27979.82, response time: 7.20ms (95%), errors: 0.00, reconnects:  0.00
[  30s] threads: 64, tps: 0.00, reads: 0.00, writes: 21580.00, response time: 8.24ms (95%), errors: 0.00, reconnects:  0.00
[  31s] threads: 64, tps: 0.00, reads: 0.00, writes: 22029.00, response time: 7.56ms (95%), errors: 0.00, reconnects:  0.00
[  32s] threads: 64, tps: 0.00, reads: 0.00, writes: 23703.71, response time: 7.48ms (95%), errors: 0.00, reconnects:  0.00
[  33s] threads: 64, tps: 0.00, reads: 0.00, writes: 25972.29, response time: 6.41ms (95%), errors: 0.00, reconnects:  0.00
[  34s] threads: 64, tps: 0.00, reads: 0.00, writes: 25308.00, response time: 7.53ms (95%), errors: 0.00, reconnects:  0.00
[  35s] threads: 64, tps: 0.00, reads: 0.00, writes: 36145.00, response time: 4.68ms (95%), errors: 0.00, reconnects:  0.00
[  36s] threads: 64, tps: 0.00, reads: 0.00, writes: 40376.05, response time: 3.52ms (95%), errors: 0.00, reconnects:  0.00
[  37s] threads: 64, tps: 0.00, reads: 0.00, writes: 32613.01, response time: 6.66ms (95%), errors: 0.00, reconnects:  0.00
[  38s] threads: 64, tps: 0.00, reads: 0.00, writes: 35255.94, response time: 5.49ms (95%), errors: 0.00, reconnects:  0.00
[  39s] threads: 64, tps: 0.00, reads: 0.00, writes: 36370.06, response time: 5.28ms (95%), errors: 0.00, reconnects:  0.00
[  40s] threads: 64, tps: 0.00, reads: 0.00, writes: 35517.01, response time: 5.42ms (95%), errors: 0.00, reconnects:  0.00
[  41s] threads: 64, tps: 0.00, reads: 0.00, writes: 39189.97, response time: 4.64ms (95%), errors: 0.00, reconnects:  0.00
[  42s] threads: 64, tps: 0.00, reads: 0.00, writes: 46583.94, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[  43s] threads: 64, tps: 0.00, reads: 0.00, writes: 43980.02, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[  44s] threads: 64, tps: 0.00, reads: 0.00, writes: 38567.00, response time: 4.18ms (95%), errors: 0.00, reconnects:  0.00
[  45s] threads: 64, tps: 0.00, reads: 0.00, writes: 38399.86, response time: 4.04ms (95%), errors: 0.00, reconnects:  0.00
[  46s] threads: 64, tps: 0.00, reads: 0.00, writes: 37769.22, response time: 4.72ms (95%), errors: 0.00, reconnects:  0.00
[  47s] threads: 64, tps: 0.00, reads: 0.00, writes: 43630.00, response time: 3.43ms (95%), errors: 0.00, reconnects:  0.00
[  48s] threads: 64, tps: 0.00, reads: 0.00, writes: 38756.95, response time: 3.75ms (95%), errors: 0.00, reconnects:  0.00
[  49s] threads: 64, tps: 0.00, reads: 0.00, writes: 38992.02, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[  50s] threads: 64, tps: 0.00, reads: 0.00, writes: 42534.00, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[  51s] threads: 64, tps: 0.00, reads: 0.00, writes: 35308.99, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[  52s] threads: 64, tps: 0.00, reads: 0.00, writes: 49598.00, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[  53s] threads: 64, tps: 0.00, reads: 0.00, writes: 50297.02, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[  54s] threads: 64, tps: 0.00, reads: 0.00, writes: 49841.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[  55s] threads: 64, tps: 0.00, reads: 0.00, writes: 48881.00, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[  56s] threads: 64, tps: 0.00, reads: 0.00, writes: 49834.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[  57s] threads: 64, tps: 0.00, reads: 0.00, writes: 51503.94, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[  58s] threads: 64, tps: 0.00, reads: 0.00, writes: 50559.99, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[  59s] threads: 64, tps: 0.00, reads: 0.00, writes: 49052.79, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[  60s] threads: 64, tps: 0.00, reads: 0.00, writes: 49461.24, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[  61s] threads: 64, tps: 0.00, reads: 0.00, writes: 49641.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[  62s] threads: 64, tps: 0.00, reads: 0.00, writes: 42029.81, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[  63s] threads: 64, tps: 0.00, reads: 0.00, writes: 35771.98, response time: 4.15ms (95%), errors: 0.00, reconnects:  0.00
[  64s] threads: 64, tps: 0.00, reads: 0.00, writes: 38790.31, response time: 4.19ms (95%), errors: 0.00, reconnects:  0.00
[  65s] threads: 64, tps: 0.00, reads: 0.00, writes: 42653.08, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[  66s] threads: 64, tps: 0.00, reads: 0.00, writes: 44221.97, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[  67s] threads: 64, tps: 0.00, reads: 0.00, writes: 47330.12, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[  68s] threads: 64, tps: 0.00, reads: 0.00, writes: 48561.02, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[  69s] threads: 64, tps: 0.00, reads: 0.00, writes: 44057.73, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[  70s] threads: 64, tps: 0.00, reads: 0.00, writes: 40157.20, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[  71s] threads: 64, tps: 0.00, reads: 0.00, writes: 44459.02, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[  72s] threads: 64, tps: 0.00, reads: 0.00, writes: 50589.78, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[  73s] threads: 64, tps: 0.00, reads: 0.00, writes: 47802.17, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[  74s] threads: 64, tps: 0.00, reads: 0.00, writes: 48485.06, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[  75s] threads: 64, tps: 0.00, reads: 0.00, writes: 49208.71, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[  76s] threads: 64, tps: 0.00, reads: 0.00, writes: 44217.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[  77s] threads: 64, tps: 0.00, reads: 0.00, writes: 50444.28, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[  78s] threads: 64, tps: 0.00, reads: 0.00, writes: 49105.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[  79s] threads: 64, tps: 0.00, reads: 0.00, writes: 50061.05, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[  80s] threads: 64, tps: 0.00, reads: 0.00, writes: 48569.87, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[  81s] threads: 64, tps: 0.00, reads: 0.00, writes: 46160.31, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[  82s] threads: 64, tps: 0.00, reads: 0.00, writes: 49206.96, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[  83s] threads: 64, tps: 0.00, reads: 0.00, writes: 49691.89, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[  84s] threads: 64, tps: 0.00, reads: 0.00, writes: 50720.07, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[  85s] threads: 64, tps: 0.00, reads: 0.00, writes: 49979.08, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[  86s] threads: 64, tps: 0.00, reads: 0.00, writes: 51159.95, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[  87s] threads: 64, tps: 0.00, reads: 0.00, writes: 47395.16, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[  88s] threads: 64, tps: 0.00, reads: 0.00, writes: 42457.99, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[  89s] threads: 64, tps: 0.00, reads: 0.00, writes: 47159.96, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[  90s] threads: 64, tps: 0.00, reads: 0.00, writes: 49242.83, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[  91s] threads: 64, tps: 0.00, reads: 0.00, writes: 50858.22, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[  92s] threads: 64, tps: 0.00, reads: 0.00, writes: 49702.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[  93s] threads: 64, tps: 0.00, reads: 0.00, writes: 48145.74, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[  94s] threads: 64, tps: 0.00, reads: 0.00, writes: 46527.12, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[  95s] threads: 64, tps: 0.00, reads: 0.00, writes: 49239.14, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[  96s] threads: 64, tps: 0.00, reads: 0.00, writes: 49507.93, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[  97s] threads: 64, tps: 0.00, reads: 0.00, writes: 49427.83, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[  98s] threads: 64, tps: 0.00, reads: 0.00, writes: 47123.77, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[  99s] threads: 64, tps: 0.00, reads: 0.00, writes: 39022.41, response time: 3.74ms (95%), errors: 0.00, reconnects:  0.00
[ 100s] threads: 64, tps: 0.00, reads: 0.00, writes: 43089.87, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[ 101s] threads: 64, tps: 0.00, reads: 0.00, writes: 41689.06, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[ 102s] threads: 64, tps: 0.00, reads: 0.00, writes: 36060.86, response time: 4.60ms (95%), errors: 0.00, reconnects:  0.00
[ 103s] threads: 64, tps: 0.00, reads: 0.00, writes: 38964.16, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[ 104s] threads: 64, tps: 0.00, reads: 0.00, writes: 38580.98, response time: 3.75ms (95%), errors: 0.00, reconnects:  0.00
[ 105s] threads: 64, tps: 0.00, reads: 0.00, writes: 42308.03, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[ 106s] threads: 64, tps: 0.00, reads: 0.00, writes: 47660.97, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 107s] threads: 64, tps: 0.00, reads: 0.00, writes: 43677.79, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 108s] threads: 64, tps: 0.00, reads: 0.00, writes: 41630.21, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 109s] threads: 64, tps: 0.00, reads: 0.00, writes: 38475.98, response time: 3.91ms (95%), errors: 0.00, reconnects:  0.00
[ 110s] threads: 64, tps: 0.00, reads: 0.00, writes: 32999.22, response time: 6.01ms (95%), errors: 0.00, reconnects:  0.00
[ 111s] threads: 64, tps: 0.00, reads: 0.00, writes: 40452.96, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[ 112s] threads: 64, tps: 0.00, reads: 0.00, writes: 34546.92, response time: 4.50ms (95%), errors: 0.00, reconnects:  0.00
[ 113s] threads: 64, tps: 0.00, reads: 0.00, writes: 33202.04, response time: 4.15ms (95%), errors: 0.00, reconnects:  0.00
[ 114s] threads: 64, tps: 0.00, reads: 0.00, writes: 36542.08, response time: 4.27ms (95%), errors: 0.00, reconnects:  0.00
[ 115s] threads: 64, tps: 0.00, reads: 0.00, writes: 40908.80, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 116s] threads: 64, tps: 0.00, reads: 0.00, writes: 40967.20, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 117s] threads: 64, tps: 0.00, reads: 0.00, writes: 48824.07, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 118s] threads: 64, tps: 0.00, reads: 0.00, writes: 40818.97, response time: 3.32ms (95%), errors: 0.00, reconnects:  0.00
[ 119s] threads: 64, tps: 0.00, reads: 0.00, writes: 43762.97, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 120s] threads: 64, tps: 0.00, reads: 0.00, writes: 47238.81, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 121s] threads: 64, tps: 0.00, reads: 0.00, writes: 48955.60, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 122s] threads: 64, tps: 0.00, reads: 0.00, writes: 50427.73, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 123s] threads: 64, tps: 0.00, reads: 0.00, writes: 45799.82, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 124s] threads: 64, tps: 0.00, reads: 0.00, writes: 49817.68, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 125s] threads: 64, tps: 0.00, reads: 0.00, writes: 48536.24, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 126s] threads: 64, tps: 0.00, reads: 0.00, writes: 49964.07, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 127s] threads: 64, tps: 0.00, reads: 0.00, writes: 44101.95, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 128s] threads: 64, tps: 0.00, reads: 0.00, writes: 46698.07, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 129s] threads: 64, tps: 0.00, reads: 0.00, writes: 48504.95, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 130s] threads: 64, tps: 0.00, reads: 0.00, writes: 49245.03, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 131s] threads: 64, tps: 0.00, reads: 0.00, writes: 48307.98, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 132s] threads: 64, tps: 0.00, reads: 0.00, writes: 48373.70, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 133s] threads: 64, tps: 0.00, reads: 0.00, writes: 47154.17, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 134s] threads: 64, tps: 0.00, reads: 0.00, writes: 39883.89, response time: 4.05ms (95%), errors: 0.00, reconnects:  0.00
[ 135s] threads: 64, tps: 0.00, reads: 0.00, writes: 34292.19, response time: 5.80ms (95%), errors: 0.00, reconnects:  0.00
[ 136s] threads: 64, tps: 0.00, reads: 0.00, writes: 38753.08, response time: 4.35ms (95%), errors: 0.00, reconnects:  0.00
[ 137s] threads: 64, tps: 0.00, reads: 0.00, writes: 45526.87, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[ 138s] threads: 64, tps: 0.00, reads: 0.00, writes: 40500.15, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[ 139s] threads: 64, tps: 0.00, reads: 0.00, writes: 39091.35, response time: 4.28ms (95%), errors: 0.00, reconnects:  0.00
[ 141s] threads: 64, tps: 0.00, reads: 0.00, writes: 39399.35, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[ 142s] threads: 64, tps: 0.00, reads: 0.00, writes: 17675.55, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 143s] threads: 64, tps: 0.00, reads: 0.00, writes: 46730.16, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 144s] threads: 64, tps: 0.00, reads: 0.00, writes: 46614.96, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 145s] threads: 64, tps: 0.00, reads: 0.00, writes: 33953.97, response time: 4.60ms (95%), errors: 0.00, reconnects:  0.00
[ 150s] threads: 64, tps: 0.00, reads: 0.00, writes: 38599.57, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 153s] threads: 64, tps: 0.00, reads: 0.00, writes: 9.16, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 154s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 155s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 156s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 157s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 158s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 159s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 160s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 161s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 162s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 163s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 164s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 165s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 166s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 167s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 168s] threads: 64, tps: 0.00, reads: 0.00, writes: 17116.58, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[ 169s] threads: 64, tps: 0.00, reads: 0.00, writes: 48586.28, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 170s] threads: 64, tps: 0.00, reads: 0.00, writes: 50592.87, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 171s] threads: 64, tps: 0.00, reads: 0.00, writes: 47880.98, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 172s] threads: 64, tps: 0.00, reads: 0.00, writes: 48870.79, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 173s] threads: 64, tps: 0.00, reads: 0.00, writes: 47402.09, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 174s] threads: 64, tps: 0.00, reads: 0.00, writes: 49814.68, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 175s] threads: 64, tps: 0.00, reads: 0.00, writes: 49962.98, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 176s] threads: 64, tps: 0.00, reads: 0.00, writes: 45558.12, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 177s] threads: 64, tps: 0.00, reads: 0.00, writes: 47662.82, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 178s] threads: 64, tps: 0.00, reads: 0.00, writes: 48040.20, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 179s] threads: 64, tps: 0.00, reads: 0.00, writes: 43619.06, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 180s] threads: 64, tps: 0.00, reads: 0.00, writes: 46374.98, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 181s] threads: 64, tps: 0.00, reads: 0.00, writes: 40764.92, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 182s] threads: 64, tps: 0.00, reads: 0.00, writes: 45878.31, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 183s] threads: 64, tps: 0.00, reads: 0.00, writes: 37306.96, response time: 3.37ms (95%), errors: 0.00, reconnects:  0.00
[ 184s] threads: 64, tps: 0.00, reads: 0.00, writes: 38986.96, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[ 185s] threads: 64, tps: 0.00, reads: 0.00, writes: 43698.00, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 186s] threads: 64, tps: 0.00, reads: 0.00, writes: 34872.00, response time: 4.73ms (95%), errors: 0.00, reconnects:  0.00
[ 187s] threads: 64, tps: 0.00, reads: 0.00, writes: 40146.98, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[ 188s] threads: 64, tps: 0.00, reads: 0.00, writes: 41713.06, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 189s] threads: 64, tps: 0.00, reads: 0.00, writes: 40674.98, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[ 190s] threads: 64, tps: 0.00, reads: 0.00, writes: 44076.90, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 191s] threads: 64, tps: 0.00, reads: 0.00, writes: 46743.13, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 192s] threads: 64, tps: 0.00, reads: 0.00, writes: 40256.79, response time: 3.52ms (95%), errors: 0.00, reconnects:  0.00
[ 193s] threads: 64, tps: 0.00, reads: 0.00, writes: 41662.00, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[ 194s] threads: 64, tps: 0.00, reads: 0.00, writes: 42481.06, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[ 195s] threads: 64, tps: 0.00, reads: 0.00, writes: 36346.86, response time: 4.30ms (95%), errors: 0.00, reconnects:  0.00
[ 196s] threads: 64, tps: 0.00, reads: 0.00, writes: 35439.97, response time: 4.47ms (95%), errors: 0.00, reconnects:  0.00
[ 197s] threads: 64, tps: 0.00, reads: 0.00, writes: 40887.17, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 198s] threads: 64, tps: 0.00, reads: 0.00, writes: 38525.91, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[ 199s] threads: 64, tps: 0.00, reads: 0.00, writes: 41180.95, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 200s] threads: 64, tps: 0.00, reads: 0.00, writes: 45520.13, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 201s] threads: 64, tps: 0.00, reads: 0.00, writes: 50274.63, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 202s] threads: 64, tps: 0.00, reads: 0.00, writes: 45048.66, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 203s] threads: 64, tps: 0.00, reads: 0.00, writes: 46992.88, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 204s] threads: 64, tps: 0.00, reads: 0.00, writes: 47483.10, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 205s] threads: 64, tps: 0.00, reads: 0.00, writes: 50426.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 206s] threads: 64, tps: 0.00, reads: 0.00, writes: 50797.25, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 207s] threads: 64, tps: 0.00, reads: 0.00, writes: 47736.54, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 208s] threads: 64, tps: 0.00, reads: 0.00, writes: 43747.30, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 209s] threads: 64, tps: 0.00, reads: 0.00, writes: 23088.73, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 210s] threads: 64, tps: 0.00, reads: 0.00, writes: 42478.49, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 211s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 212s] threads: 64, tps: 0.00, reads: 0.00, writes: 64.00, response time: 1866.00ms (95%), errors: 0.00, reconnects:  0.00
[ 213s] threads: 64, tps: 0.00, reads: 0.00, writes: 46010.14, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 214s] threads: 64, tps: 0.00, reads: 0.00, writes: 49005.02, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 215s] threads: 64, tps: 0.00, reads: 0.00, writes: 50145.95, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 216s] threads: 64, tps: 0.00, reads: 0.00, writes: 48725.03, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 217s] threads: 64, tps: 0.00, reads: 0.00, writes: 50899.96, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 218s] threads: 64, tps: 0.00, reads: 0.00, writes: 50747.54, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 219s] threads: 64, tps: 0.00, reads: 0.00, writes: 49207.37, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 220s] threads: 64, tps: 0.00, reads: 0.00, writes: 46240.92, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 221s] threads: 64, tps: 0.00, reads: 0.00, writes: 39942.06, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 222s] threads: 64, tps: 0.00, reads: 0.00, writes: 44127.99, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 223s] threads: 64, tps: 0.00, reads: 0.00, writes: 43264.60, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[ 224s] threads: 64, tps: 0.00, reads: 0.00, writes: 37285.58, response time: 3.99ms (95%), errors: 0.00, reconnects:  0.00
[ 225s] threads: 64, tps: 0.00, reads: 0.00, writes: 64.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 226s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 227s] threads: 64, tps: 0.00, reads: 0.00, writes: 9724.37, response time: 5.69ms (95%), errors: 0.00, reconnects:  0.00
[ 228s] threads: 64, tps: 0.00, reads: 0.00, writes: 39847.97, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[ 229s] threads: 64, tps: 0.00, reads: 0.00, writes: 40154.82, response time: 3.57ms (95%), errors: 0.00, reconnects:  0.00
[ 230s] threads: 64, tps: 0.00, reads: 0.00, writes: 44576.94, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[ 232s] threads: 64, tps: 0.00, reads: 0.00, writes: 44790.88, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 232s] threads: 64, tps: 0.00, reads: 0.00, writes: 15916.13, response time: 4.54ms (95%), errors: 0.00, reconnects:  0.00
[ 233s] threads: 64, tps: 0.00, reads: 0.00, writes: 30970.95, response time: 6.00ms (95%), errors: 0.00, reconnects:  0.00
[ 234s] threads: 64, tps: 0.00, reads: 0.00, writes: 29275.00, response time: 5.02ms (95%), errors: 0.00, reconnects:  0.00
[ 235s] threads: 64, tps: 0.00, reads: 0.00, writes: 31567.69, response time: 4.90ms (95%), errors: 0.00, reconnects:  0.00
[ 236s] threads: 64, tps: 0.00, reads: 0.00, writes: 31496.31, response time: 3.82ms (95%), errors: 0.00, reconnects:  0.00
[ 237s] threads: 64, tps: 0.00, reads: 0.00, writes: 61.99, response time: 170.23ms (95%), errors: 0.00, reconnects:  0.00
[ 238s] threads: 64, tps: 0.00, reads: 0.00, writes: 26565.03, response time: 3.68ms (95%), errors: 0.00, reconnects:  0.00
[ 239s] threads: 64, tps: 0.00, reads: 0.00, writes: 46618.36, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 240s] threads: 64, tps: 0.00, reads: 0.00, writes: 42099.03, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 241s] threads: 64, tps: 0.00, reads: 0.00, writes: 45218.94, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 242s] threads: 64, tps: 0.00, reads: 0.00, writes: 47417.02, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 243s] threads: 64, tps: 0.00, reads: 0.00, writes: 46724.01, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 244s] threads: 64, tps: 0.00, reads: 0.00, writes: 49593.02, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 245s] threads: 64, tps: 0.00, reads: 0.00, writes: 45865.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 246s] threads: 64, tps: 0.00, reads: 0.00, writes: 46808.94, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 247s] threads: 64, tps: 0.00, reads: 0.00, writes: 46638.05, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 248s] threads: 64, tps: 0.00, reads: 0.00, writes: 46739.91, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 249s] threads: 64, tps: 0.00, reads: 0.00, writes: 49297.99, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 250s] threads: 64, tps: 0.00, reads: 0.00, writes: 45185.10, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 251s] threads: 64, tps: 0.00, reads: 0.00, writes: 47866.04, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 252s] threads: 64, tps: 0.00, reads: 0.00, writes: 46902.95, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 253s] threads: 64, tps: 0.00, reads: 0.00, writes: 47552.99, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 254s] threads: 64, tps: 0.00, reads: 0.00, writes: 49101.05, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 255s] threads: 64, tps: 0.00, reads: 0.00, writes: 48678.95, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 256s] threads: 64, tps: 0.00, reads: 0.00, writes: 46816.00, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 257s] threads: 64, tps: 0.00, reads: 0.00, writes: 46791.99, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 258s] threads: 64, tps: 0.00, reads: 0.00, writes: 46760.96, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 259s] threads: 64, tps: 0.00, reads: 0.00, writes: 43905.03, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 260s] threads: 64, tps: 0.00, reads: 0.00, writes: 44625.02, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 261s] threads: 64, tps: 0.00, reads: 0.00, writes: 37933.98, response time: 3.85ms (95%), errors: 0.00, reconnects:  0.00
[ 262s] threads: 64, tps: 0.00, reads: 0.00, writes: 38795.04, response time: 3.43ms (95%), errors: 0.00, reconnects:  0.00
[ 263s] threads: 64, tps: 0.00, reads: 0.00, writes: 40904.99, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 264s] threads: 64, tps: 0.00, reads: 0.00, writes: 45164.89, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 265s] threads: 64, tps: 0.00, reads: 0.00, writes: 38294.05, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[ 266s] threads: 64, tps: 0.00, reads: 0.00, writes: 35891.02, response time: 4.34ms (95%), errors: 0.00, reconnects:  0.00
[ 267s] threads: 64, tps: 0.00, reads: 0.00, writes: 38731.02, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[ 268s] threads: 64, tps: 0.00, reads: 0.00, writes: 34585.92, response time: 3.58ms (95%), errors: 0.00, reconnects:  0.00
[ 269s] threads: 64, tps: 0.00, reads: 0.00, writes: 46109.11, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 270s] threads: 64, tps: 0.00, reads: 0.00, writes: 45533.02, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 271s] threads: 64, tps: 0.00, reads: 0.00, writes: 31703.96, response time: 4.67ms (95%), errors: 0.00, reconnects:  0.00
[ 272s] threads: 64, tps: 0.00, reads: 0.00, writes: 28247.02, response time: 4.55ms (95%), errors: 0.00, reconnects:  0.00
[ 273s] threads: 64, tps: 0.00, reads: 0.00, writes: 30968.00, response time: 4.40ms (95%), errors: 0.00, reconnects:  0.00
[ 274s] threads: 64, tps: 0.00, reads: 0.00, writes: 38848.97, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[ 275s] threads: 64, tps: 0.00, reads: 0.00, writes: 44721.86, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 276s] threads: 64, tps: 0.00, reads: 0.00, writes: 45470.20, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 277s] threads: 64, tps: 0.00, reads: 0.00, writes: 42927.61, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 278s] threads: 64, tps: 0.00, reads: 0.00, writes: 45220.38, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 279s] threads: 64, tps: 0.00, reads: 0.00, writes: 47885.02, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 280s] threads: 64, tps: 0.00, reads: 0.00, writes: 48668.02, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 281s] threads: 64, tps: 0.00, reads: 0.00, writes: 50407.94, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 282s] threads: 64, tps: 0.00, reads: 0.00, writes: 47602.10, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 283s] threads: 64, tps: 0.00, reads: 0.00, writes: 48192.93, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 284s] threads: 64, tps: 0.00, reads: 0.00, writes: 45012.03, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 285s] threads: 64, tps: 0.00, reads: 0.00, writes: 49676.90, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 286s] threads: 64, tps: 0.00, reads: 0.00, writes: 48929.09, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 287s] threads: 64, tps: 0.00, reads: 0.00, writes: 47836.94, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 288s] threads: 64, tps: 0.00, reads: 0.00, writes: 47842.05, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 289s] threads: 64, tps: 0.00, reads: 0.00, writes: 39895.95, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[ 290s] threads: 64, tps: 0.00, reads: 0.00, writes: 42669.04, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[ 291s] threads: 64, tps: 0.00, reads: 0.00, writes: 30941.97, response time: 4.51ms (95%), errors: 0.00, reconnects:  0.00
[ 292s] threads: 64, tps: 0.00, reads: 0.00, writes: 36138.03, response time: 3.32ms (95%), errors: 0.00, reconnects:  0.00
[ 293s] threads: 64, tps: 0.00, reads: 0.00, writes: 41308.02, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 294s] threads: 64, tps: 0.00, reads: 0.00, writes: 41043.99, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 295s] threads: 64, tps: 0.00, reads: 0.00, writes: 42044.87, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[ 296s] threads: 64, tps: 0.00, reads: 0.00, writes: 46501.20, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 297s] threads: 64, tps: 0.00, reads: 0.00, writes: 43087.94, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[ 298s] threads: 64, tps: 0.00, reads: 0.00, writes: 40316.01, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 299s] threads: 64, tps: 0.00, reads: 0.00, writes: 41558.00, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[ 300s] threads: 64, tps: 0.00, reads: 0.00, writes: 41973.03, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[ 301s] threads: 64, tps: 0.00, reads: 0.00, writes: 46942.92, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 302s] threads: 64, tps: 0.00, reads: 0.00, writes: 41782.02, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 303s] threads: 64, tps: 0.00, reads: 0.00, writes: 27376.03, response time: 7.08ms (95%), errors: 0.00, reconnects:  0.00
[ 304s] threads: 64, tps: 0.00, reads: 0.00, writes: 26309.98, response time: 5.67ms (95%), errors: 0.00, reconnects:  0.00
[ 305s] threads: 64, tps: 0.00, reads: 0.00, writes: 33800.00, response time: 3.49ms (95%), errors: 0.00, reconnects:  0.00
[ 306s] threads: 64, tps: 0.00, reads: 0.00, writes: 34557.98, response time: 3.53ms (95%), errors: 0.00, reconnects:  0.00
[ 307s] threads: 64, tps: 0.00, reads: 0.00, writes: 43872.02, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 308s] threads: 64, tps: 0.00, reads: 0.00, writes: 40551.04, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[ 309s] threads: 64, tps: 0.00, reads: 0.00, writes: 40942.98, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 310s] threads: 64, tps: 0.00, reads: 0.00, writes: 41504.83, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 311s] threads: 64, tps: 0.00, reads: 0.00, writes: 41307.20, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 312s] threads: 64, tps: 0.00, reads: 0.00, writes: 45624.04, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 313s] threads: 64, tps: 0.00, reads: 0.00, writes: 42944.94, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 314s] threads: 64, tps: 0.00, reads: 0.00, writes: 45710.08, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 315s] threads: 64, tps: 0.00, reads: 0.00, writes: 46453.87, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 316s] threads: 64, tps: 0.00, reads: 0.00, writes: 46562.04, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 317s] threads: 64, tps: 0.00, reads: 0.00, writes: 48064.94, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 318s] threads: 64, tps: 0.00, reads: 0.00, writes: 42700.07, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 319s] threads: 64, tps: 0.00, reads: 0.00, writes: 48480.91, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 320s] threads: 64, tps: 0.00, reads: 0.00, writes: 47952.09, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 321s] threads: 64, tps: 0.00, reads: 0.00, writes: 47348.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 322s] threads: 64, tps: 0.00, reads: 0.00, writes: 48985.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 323s] threads: 64, tps: 0.00, reads: 0.00, writes: 48396.99, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 324s] threads: 64, tps: 0.00, reads: 0.00, writes: 48901.58, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 325s] threads: 64, tps: 0.00, reads: 0.00, writes: 48350.74, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 326s] threads: 64, tps: 0.00, reads: 0.00, writes: 48394.67, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 327s] threads: 64, tps: 0.00, reads: 0.00, writes: 50053.96, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 328s] threads: 64, tps: 0.00, reads: 0.00, writes: 49235.99, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 329s] threads: 64, tps: 0.00, reads: 0.00, writes: 47852.03, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 330s] threads: 64, tps: 0.00, reads: 0.00, writes: 46137.04, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 331s] threads: 64, tps: 0.00, reads: 0.00, writes: 44722.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 332s] threads: 64, tps: 0.00, reads: 0.00, writes: 45918.01, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 333s] threads: 64, tps: 0.00, reads: 0.00, writes: 41661.02, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 334s] threads: 64, tps: 0.00, reads: 0.00, writes: 39626.97, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 335s] threads: 64, tps: 0.00, reads: 0.00, writes: 41295.97, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[ 336s] threads: 64, tps: 0.00, reads: 0.00, writes: 40346.11, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 337s] threads: 64, tps: 0.00, reads: 0.00, writes: 45839.32, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 338s] threads: 64, tps: 0.00, reads: 0.00, writes: 43184.03, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[ 339s] threads: 64, tps: 0.00, reads: 0.00, writes: 39969.98, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 340s] threads: 64, tps: 0.00, reads: 0.00, writes: 39591.98, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[ 341s] threads: 64, tps: 0.00, reads: 0.00, writes: 39659.04, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 342s] threads: 64, tps: 0.00, reads: 0.00, writes: 45470.99, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 343s] threads: 64, tps: 0.00, reads: 0.00, writes: 44125.95, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 344s] threads: 64, tps: 0.00, reads: 0.00, writes: 30478.97, response time: 4.84ms (95%), errors: 0.00, reconnects:  0.00
[ 345s] threads: 64, tps: 0.00, reads: 0.00, writes: 32286.07, response time: 4.93ms (95%), errors: 0.00, reconnects:  0.00
[ 346s] threads: 64, tps: 0.00, reads: 0.00, writes: 41663.00, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 347s] threads: 64, tps: 0.00, reads: 0.00, writes: 43287.02, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 348s] threads: 64, tps: 0.00, reads: 0.00, writes: 48088.23, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 349s] threads: 64, tps: 0.00, reads: 0.00, writes: 37284.53, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 350s] threads: 64, tps: 0.00, reads: 0.00, writes: 45413.44, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 351s] threads: 64, tps: 0.00, reads: 0.00, writes: 46551.69, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 352s] threads: 64, tps: 0.00, reads: 0.00, writes: 46867.07, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 353s] threads: 64, tps: 0.00, reads: 0.00, writes: 49553.94, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 354s] threads: 64, tps: 0.00, reads: 0.00, writes: 48347.03, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 355s] threads: 64, tps: 0.00, reads: 0.00, writes: 49491.81, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 356s] threads: 64, tps: 0.00, reads: 0.00, writes: 46982.16, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 357s] threads: 64, tps: 0.00, reads: 0.00, writes: 41487.01, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 358s] threads: 64, tps: 0.00, reads: 0.00, writes: 48192.97, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 359s] threads: 64, tps: 0.00, reads: 0.00, writes: 48683.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 360s] threads: 64, tps: 0.00, reads: 0.00, writes: 48512.08, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 361s] threads: 64, tps: 0.00, reads: 0.00, writes: 48369.93, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 362s] threads: 64, tps: 0.00, reads: 0.00, writes: 50232.49, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 363s] threads: 64, tps: 0.00, reads: 0.00, writes: 47964.44, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 364s] threads: 64, tps: 0.00, reads: 0.00, writes: 47904.12, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 365s] threads: 64, tps: 0.00, reads: 0.00, writes: 48535.95, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 366s] threads: 64, tps: 0.00, reads: 0.00, writes: 47194.05, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 367s] threads: 64, tps: 0.00, reads: 0.00, writes: 50024.96, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 368s] threads: 64, tps: 0.00, reads: 0.00, writes: 47946.99, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 369s] threads: 64, tps: 0.00, reads: 0.00, writes: 46854.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 370s] threads: 64, tps: 0.00, reads: 0.00, writes: 45585.04, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 371s] threads: 64, tps: 0.00, reads: 0.00, writes: 42065.93, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 372s] threads: 64, tps: 0.00, reads: 0.00, writes: 46333.09, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 373s] threads: 64, tps: 0.00, reads: 0.00, writes: 44586.93, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 374s] threads: 64, tps: 0.00, reads: 0.00, writes: 38694.05, response time: 3.68ms (95%), errors: 0.00, reconnects:  0.00
[ 375s] threads: 64, tps: 0.00, reads: 0.00, writes: 37329.35, response time: 3.81ms (95%), errors: 0.00, reconnects:  0.00
[ 376s] threads: 64, tps: 0.00, reads: 0.00, writes: 40143.62, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 377s] threads: 64, tps: 0.00, reads: 0.00, writes: 45031.00, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 378s] threads: 64, tps: 0.00, reads: 0.00, writes: 45613.05, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 379s] threads: 64, tps: 0.00, reads: 0.00, writes: 11075.77, response time: 20.34ms (95%), errors: 0.00, reconnects:  0.00
[ 380s] threads: 64, tps: 0.00, reads: 0.00, writes: 3226.98, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[ 381s] threads: 64, tps: 0.00, reads: 0.00, writes: 3212.08, response time: 20.84ms (95%), errors: 0.00, reconnects:  0.00
[ 382s] threads: 64, tps: 0.00, reads: 0.00, writes: 21600.99, response time: 8.47ms (95%), errors: 0.00, reconnects:  0.00
[ 383s] threads: 64, tps: 0.00, reads: 0.00, writes: 29052.03, response time: 5.42ms (95%), errors: 0.00, reconnects:  0.00
[ 384s] threads: 64, tps: 0.00, reads: 0.00, writes: 31018.95, response time: 4.19ms (95%), errors: 0.00, reconnects:  0.00
[ 385s] threads: 64, tps: 0.00, reads: 0.00, writes: 41001.51, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 386s] threads: 64, tps: 0.00, reads: 0.00, writes: 47879.66, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 387s] threads: 64, tps: 0.00, reads: 0.00, writes: 44710.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 388s] threads: 64, tps: 0.00, reads: 0.00, writes: 48749.95, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 389s] threads: 64, tps: 0.00, reads: 0.00, writes: 43463.09, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 390s] threads: 64, tps: 0.00, reads: 0.00, writes: 48138.96, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 391s] threads: 64, tps: 0.00, reads: 0.00, writes: 49197.94, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 392s] threads: 64, tps: 0.00, reads: 0.00, writes: 47433.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 393s] threads: 64, tps: 0.00, reads: 0.00, writes: 48017.06, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 394s] threads: 64, tps: 0.00, reads: 0.00, writes: 47161.97, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 395s] threads: 64, tps: 0.00, reads: 0.00, writes: 47877.96, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 396s] threads: 64, tps: 0.00, reads: 0.00, writes: 49192.09, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 397s] threads: 64, tps: 0.00, reads: 0.00, writes: 49061.98, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 398s] threads: 64, tps: 0.00, reads: 0.00, writes: 47121.01, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 399s] threads: 64, tps: 0.00, reads: 0.00, writes: 38425.77, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 400s] threads: 64, tps: 0.00, reads: 0.00, writes: 48189.06, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 401s] threads: 64, tps: 0.00, reads: 0.00, writes: 47080.83, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 402s] threads: 64, tps: 0.00, reads: 0.00, writes: 45546.32, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 403s] threads: 64, tps: 0.00, reads: 0.00, writes: 38212.90, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[ 404s] threads: 64, tps: 0.00, reads: 0.00, writes: 32611.99, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[ 405s] threads: 64, tps: 0.00, reads: 0.00, writes: 32821.01, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[ 406s] threads: 64, tps: 0.00, reads: 0.00, writes: 43872.00, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 407s] threads: 64, tps: 0.00, reads: 0.00, writes: 42040.15, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 408s] threads: 64, tps: 0.00, reads: 0.00, writes: 40034.86, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 409s] threads: 64, tps: 0.00, reads: 0.00, writes: 41902.18, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[ 410s] threads: 64, tps: 0.00, reads: 0.00, writes: 41043.76, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 411s] threads: 64, tps: 0.00, reads: 0.00, writes: 45318.15, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[ 412s] threads: 64, tps: 0.00, reads: 0.00, writes: 46650.05, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 413s] threads: 64, tps: 0.00, reads: 0.00, writes: 39280.89, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 414s] threads: 64, tps: 0.00, reads: 0.00, writes: 35535.13, response time: 4.59ms (95%), errors: 0.00, reconnects:  0.00
[ 415s] threads: 64, tps: 0.00, reads: 0.00, writes: 39193.96, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[ 416s] threads: 64, tps: 0.00, reads: 0.00, writes: 38608.81, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[ 417s] threads: 64, tps: 0.00, reads: 0.00, writes: 43076.26, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 418s] threads: 64, tps: 0.00, reads: 0.00, writes: 35592.89, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[ 419s] threads: 64, tps: 0.00, reads: 0.00, writes: 28370.08, response time: 5.18ms (95%), errors: 0.00, reconnects:  0.00
[ 420s] threads: 64, tps: 0.00, reads: 0.00, writes: 30598.87, response time: 4.57ms (95%), errors: 0.00, reconnects:  0.00
[ 421s] threads: 64, tps: 0.00, reads: 0.00, writes: 39528.13, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 422s] threads: 64, tps: 0.00, reads: 0.00, writes: 41843.96, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[ 423s] threads: 64, tps: 0.00, reads: 0.00, writes: 46166.08, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 424s] threads: 64, tps: 0.00, reads: 0.00, writes: 46163.00, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 425s] threads: 64, tps: 0.00, reads: 0.00, writes: 48870.78, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 426s] threads: 64, tps: 0.00, reads: 0.00, writes: 47769.28, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 427s] threads: 64, tps: 0.00, reads: 0.00, writes: 47080.88, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 428s] threads: 64, tps: 0.00, reads: 0.00, writes: 48835.89, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 429s] threads: 64, tps: 0.00, reads: 0.00, writes: 38971.00, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 430s] threads: 64, tps: 0.00, reads: 0.00, writes: 46550.14, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 431s] threads: 64, tps: 0.00, reads: 0.00, writes: 46765.81, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 432s] threads: 64, tps: 0.00, reads: 0.00, writes: 47006.24, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 433s] threads: 64, tps: 0.00, reads: 0.00, writes: 47654.72, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 434s] threads: 64, tps: 0.00, reads: 0.00, writes: 48238.29, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 435s] threads: 64, tps: 0.00, reads: 0.00, writes: 46836.25, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 436s] threads: 64, tps: 0.00, reads: 0.00, writes: 47900.55, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 437s] threads: 64, tps: 0.00, reads: 0.00, writes: 47209.70, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 438s] threads: 64, tps: 0.00, reads: 0.00, writes: 44729.52, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 439s] threads: 64, tps: 0.00, reads: 0.00, writes: 37239.95, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[ 440s] threads: 64, tps: 0.00, reads: 0.00, writes: 24974.94, response time: 4.23ms (95%), errors: 0.00, reconnects:  0.00
[ 441s] threads: 64, tps: 0.00, reads: 0.00, writes: 35743.08, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[ 442s] threads: 64, tps: 0.00, reads: 0.00, writes: 39834.98, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 443s] threads: 64, tps: 0.00, reads: 0.00, writes: 44254.10, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 444s] threads: 64, tps: 0.00, reads: 0.00, writes: 44701.95, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 445s] threads: 64, tps: 0.00, reads: 0.00, writes: 40706.02, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[ 446s] threads: 64, tps: 0.00, reads: 0.00, writes: 40273.96, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[ 447s] threads: 64, tps: 0.00, reads: 0.00, writes: 39150.81, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[ 448s] threads: 64, tps: 0.00, reads: 0.00, writes: 41675.23, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 449s] threads: 64, tps: 0.00, reads: 0.00, writes: 45073.98, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 450s] threads: 64, tps: 0.00, reads: 0.00, writes: 43703.03, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 451s] threads: 64, tps: 0.00, reads: 0.00, writes: 40607.98, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 452s] threads: 64, tps: 0.00, reads: 0.00, writes: 30824.98, response time: 4.88ms (95%), errors: 0.00, reconnects:  0.00
[ 453s] threads: 64, tps: 0.00, reads: 0.00, writes: 32595.04, response time: 3.91ms (95%), errors: 0.00, reconnects:  0.00
[ 454s] threads: 64, tps: 0.00, reads: 0.00, writes: 39511.98, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[ 455s] threads: 64, tps: 0.00, reads: 0.00, writes: 44732.06, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 456s] threads: 64, tps: 0.00, reads: 0.00, writes: 40332.83, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 457s] threads: 64, tps: 0.00, reads: 0.00, writes: 46209.24, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 458s] threads: 64, tps: 0.00, reads: 0.00, writes: 48213.95, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 459s] threads: 64, tps: 0.00, reads: 0.00, writes: 47389.81, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 460s] threads: 64, tps: 0.00, reads: 0.00, writes: 49584.17, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 461s] threads: 64, tps: 0.00, reads: 0.00, writes: 47830.35, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 462s] threads: 64, tps: 0.00, reads: 0.00, writes: 47352.66, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 463s] threads: 64, tps: 0.00, reads: 0.00, writes: 47034.04, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 464s] threads: 64, tps: 0.00, reads: 0.00, writes: 48636.35, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 465s] threads: 64, tps: 0.00, reads: 0.00, writes: 50050.63, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 466s] threads: 64, tps: 0.00, reads: 0.00, writes: 47729.02, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 467s] threads: 64, tps: 0.00, reads: 0.00, writes: 47838.96, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 468s] threads: 64, tps: 0.00, reads: 0.00, writes: 47514.32, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 469s] threads: 64, tps: 0.00, reads: 0.00, writes: 49830.79, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 470s] threads: 64, tps: 0.00, reads: 0.00, writes: 48130.42, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 471s] threads: 64, tps: 0.00, reads: 0.00, writes: 46760.51, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 472s] threads: 64, tps: 0.00, reads: 0.00, writes: 38988.02, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[ 473s] threads: 64, tps: 0.00, reads: 0.00, writes: 30678.00, response time: 3.90ms (95%), errors: 0.00, reconnects:  0.00
[ 474s] threads: 64, tps: 0.00, reads: 0.00, writes: 40785.04, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[ 475s] threads: 64, tps: 0.00, reads: 0.00, writes: 36601.92, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 476s] threads: 64, tps: 0.00, reads: 0.00, writes: 35570.00, response time: 3.50ms (95%), errors: 0.00, reconnects:  0.00
[ 477s] threads: 64, tps: 0.00, reads: 0.00, writes: 41438.05, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[ 478s] threads: 64, tps: 0.00, reads: 0.00, writes: 38142.02, response time: 3.86ms (95%), errors: 0.00, reconnects:  0.00
[ 479s] threads: 64, tps: 0.00, reads: 0.00, writes: 37662.99, response time: 4.05ms (95%), errors: 0.00, reconnects:  0.00
[ 480s] threads: 64, tps: 0.00, reads: 0.00, writes: 44394.97, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 481s] threads: 64, tps: 0.00, reads: 0.00, writes: 39141.97, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[ 482s] threads: 64, tps: 0.00, reads: 0.00, writes: 37777.03, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[ 483s] threads: 64, tps: 0.00, reads: 0.00, writes: 39337.99, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 484s] threads: 64, tps: 0.00, reads: 0.00, writes: 39739.00, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 485s] threads: 64, tps: 0.00, reads: 0.00, writes: 43219.85, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 486s] threads: 64, tps: 0.00, reads: 0.00, writes: 45699.16, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 487s] threads: 64, tps: 0.00, reads: 0.00, writes: 38576.66, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[ 488s] threads: 64, tps: 0.00, reads: 0.00, writes: 30517.64, response time: 3.95ms (95%), errors: 0.00, reconnects:  0.00
[ 489s] threads: 64, tps: 0.00, reads: 0.00, writes: 33297.00, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[ 490s] threads: 64, tps: 0.00, reads: 0.00, writes: 41459.99, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 491s] threads: 64, tps: 0.00, reads: 0.00, writes: 46441.05, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 492s] threads: 64, tps: 0.00, reads: 0.00, writes: 47885.01, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 493s] threads: 64, tps: 0.00, reads: 0.00, writes: 46431.94, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 494s] threads: 64, tps: 0.00, reads: 0.00, writes: 47531.92, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 495s] threads: 64, tps: 0.00, reads: 0.00, writes: 45899.00, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 496s] threads: 64, tps: 0.00, reads: 0.00, writes: 48368.10, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 497s] threads: 64, tps: 0.00, reads: 0.00, writes: 49816.99, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 498s] threads: 64, tps: 0.00, reads: 0.00, writes: 48264.95, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 499s] threads: 64, tps: 0.00, reads: 0.00, writes: 49388.05, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 500s] threads: 64, tps: 0.00, reads: 0.00, writes: 49231.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 501s] threads: 64, tps: 0.00, reads: 0.00, writes: 49688.08, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 502s] threads: 64, tps: 0.00, reads: 0.00, writes: 46413.81, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 503s] threads: 64, tps: 0.00, reads: 0.00, writes: 42749.13, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[ 504s] threads: 64, tps: 0.00, reads: 0.00, writes: 39765.01, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 505s] threads: 64, tps: 0.00, reads: 0.00, writes: 29887.24, response time: 4.46ms (95%), errors: 0.00, reconnects:  0.00
[ 506s] threads: 64, tps: 0.00, reads: 0.00, writes: 43520.96, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 507s] threads: 64, tps: 0.00, reads: 0.00, writes: 38478.98, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[ 508s] threads: 64, tps: 0.00, reads: 0.00, writes: 38740.04, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[ 509s] threads: 64, tps: 0.00, reads: 0.00, writes: 38978.99, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 510s] threads: 64, tps: 0.00, reads: 0.00, writes: 40394.07, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 511s] threads: 64, tps: 0.00, reads: 0.00, writes: 43018.95, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 512s] threads: 64, tps: 0.00, reads: 0.00, writes: 46760.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 513s] threads: 64, tps: 0.00, reads: 0.00, writes: 43763.95, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[ 514s] threads: 64, tps: 0.00, reads: 0.00, writes: 38704.05, response time: 3.57ms (95%), errors: 0.00, reconnects:  0.00
[ 515s] threads: 64, tps: 0.00, reads: 0.00, writes: 39484.84, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 516s] threads: 64, tps: 0.00, reads: 0.00, writes: 37567.14, response time: 3.79ms (95%), errors: 0.00, reconnects:  0.00
[ 517s] threads: 64, tps: 0.00, reads: 0.00, writes: 40631.78, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 518s] threads: 64, tps: 0.00, reads: 0.00, writes: 35551.20, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[ 519s] threads: 64, tps: 0.00, reads: 0.00, writes: 29839.98, response time: 4.85ms (95%), errors: 0.00, reconnects:  0.00
[ 520s] threads: 64, tps: 0.00, reads: 0.00, writes: 33183.07, response time: 3.42ms (95%), errors: 0.00, reconnects:  0.00
[ 521s] threads: 64, tps: 0.00, reads: 0.00, writes: 38293.08, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[ 522s] threads: 64, tps: 0.00, reads: 0.00, writes: 46018.00, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 523s] threads: 64, tps: 0.00, reads: 0.00, writes: 44809.00, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 524s] threads: 64, tps: 0.00, reads: 0.00, writes: 48078.01, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 525s] threads: 64, tps: 0.00, reads: 0.00, writes: 47685.05, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 526s] threads: 64, tps: 0.00, reads: 0.00, writes: 47281.97, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 527s] threads: 64, tps: 0.00, reads: 0.00, writes: 47548.98, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 528s] threads: 64, tps: 0.00, reads: 0.00, writes: 48578.05, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 529s] threads: 64, tps: 0.00, reads: 0.00, writes: 47455.84, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 530s] threads: 64, tps: 0.00, reads: 0.00, writes: 49987.95, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 531s] threads: 64, tps: 0.00, reads: 0.00, writes: 49680.15, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 532s] threads: 64, tps: 0.00, reads: 0.00, writes: 51273.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 533s] threads: 64, tps: 0.00, reads: 0.00, writes: 51096.01, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 534s] threads: 64, tps: 0.00, reads: 0.00, writes: 50407.36, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 535s] threads: 64, tps: 0.00, reads: 0.00, writes: 49285.63, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 536s] threads: 64, tps: 0.00, reads: 0.00, writes: 49931.96, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 537s] threads: 64, tps: 0.00, reads: 0.00, writes: 50317.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 538s] threads: 64, tps: 0.00, reads: 0.00, writes: 50928.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 539s] threads: 64, tps: 0.00, reads: 0.00, writes: 50311.09, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 540s] threads: 64, tps: 0.00, reads: 0.00, writes: 50425.93, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 541s] threads: 64, tps: 0.00, reads: 0.00, writes: 51646.06, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 542s] threads: 64, tps: 0.00, reads: 0.00, writes: 50885.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 543s] threads: 64, tps: 0.00, reads: 0.00, writes: 51376.96, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 544s] threads: 64, tps: 0.00, reads: 0.00, writes: 47862.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 545s] threads: 64, tps: 0.00, reads: 0.00, writes: 47990.95, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 546s] threads: 64, tps: 0.00, reads: 0.00, writes: 49206.99, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 547s] threads: 64, tps: 0.00, reads: 0.00, writes: 46939.05, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 548s] threads: 64, tps: 0.00, reads: 0.00, writes: 44700.81, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 549s] threads: 64, tps: 0.00, reads: 0.00, writes: 42256.14, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 550s] threads: 64, tps: 0.00, reads: 0.00, writes: 40549.00, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[ 551s] threads: 64, tps: 0.00, reads: 0.00, writes: 46710.00, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 552s] threads: 64, tps: 0.00, reads: 0.00, writes: 45759.99, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[ 553s] threads: 64, tps: 0.00, reads: 0.00, writes: 41264.99, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[ 554s] threads: 64, tps: 0.00, reads: 0.00, writes: 41666.06, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 555s] threads: 64, tps: 0.00, reads: 0.00, writes: 36667.86, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[ 556s] threads: 64, tps: 0.00, reads: 0.00, writes: 48269.13, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 557s] threads: 64, tps: 0.00, reads: 0.00, writes: 48777.98, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 558s] threads: 64, tps: 0.00, reads: 0.00, writes: 13183.98, response time: 20.15ms (95%), errors: 0.00, reconnects:  0.00
[ 559s] threads: 64, tps: 0.00, reads: 0.00, writes: 3237.00, response time: 20.70ms (95%), errors: 0.00, reconnects:  0.00
[ 560s] threads: 64, tps: 0.00, reads: 0.00, writes: 5119.99, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[ 561s] threads: 64, tps: 0.00, reads: 0.00, writes: 29218.07, response time: 4.17ms (95%), errors: 0.00, reconnects:  0.00
[ 562s] threads: 64, tps: 0.00, reads: 0.00, writes: 31739.17, response time: 3.47ms (95%), errors: 0.00, reconnects:  0.00
[ 563s] threads: 64, tps: 0.00, reads: 0.00, writes: 31364.80, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[ 564s] threads: 64, tps: 0.00, reads: 0.00, writes: 44433.00, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 565s] threads: 64, tps: 0.00, reads: 0.00, writes: 49331.26, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 566s] threads: 64, tps: 0.00, reads: 0.00, writes: 44986.63, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 567s] threads: 64, tps: 0.00, reads: 0.00, writes: 49973.03, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 568s] threads: 64, tps: 0.00, reads: 0.00, writes: 50005.72, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 569s] threads: 64, tps: 0.00, reads: 0.00, writes: 50125.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 570s] threads: 64, tps: 0.00, reads: 0.00, writes: 49810.92, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 571s] threads: 64, tps: 0.00, reads: 0.00, writes: 47132.09, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 572s] threads: 64, tps: 0.00, reads: 0.00, writes: 49543.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 573s] threads: 64, tps: 0.00, reads: 0.00, writes: 47254.17, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 574s] threads: 64, tps: 0.00, reads: 0.00, writes: 51836.82, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 575s] threads: 64, tps: 0.00, reads: 0.00, writes: 50156.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 576s] threads: 64, tps: 0.00, reads: 0.00, writes: 49567.18, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 577s] threads: 64, tps: 0.00, reads: 0.00, writes: 49571.82, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 578s] threads: 64, tps: 0.00, reads: 0.00, writes: 50794.15, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 579s] threads: 64, tps: 0.00, reads: 0.00, writes: 50525.09, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 580s] threads: 64, tps: 0.00, reads: 0.00, writes: 50489.71, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 581s] threads: 64, tps: 0.00, reads: 0.00, writes: 49002.24, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 582s] threads: 64, tps: 0.00, reads: 0.00, writes: 50022.78, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 583s] threads: 64, tps: 0.00, reads: 0.00, writes: 49640.25, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 584s] threads: 64, tps: 0.00, reads: 0.00, writes: 47404.99, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 585s] threads: 64, tps: 0.00, reads: 0.00, writes: 39818.81, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 586s] threads: 64, tps: 0.00, reads: 0.00, writes: 31544.15, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 587s] threads: 64, tps: 0.00, reads: 0.00, writes: 37821.96, response time: 3.32ms (95%), errors: 0.00, reconnects:  0.00
[ 588s] threads: 64, tps: 0.00, reads: 0.00, writes: 48316.83, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 589s] threads: 64, tps: 0.00, reads: 0.00, writes: 47614.24, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 590s] threads: 64, tps: 0.00, reads: 0.00, writes: 40905.90, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 591s] threads: 64, tps: 0.00, reads: 0.00, writes: 42366.06, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[ 592s] threads: 64, tps: 0.00, reads: 0.00, writes: 42571.83, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 593s] threads: 64, tps: 0.00, reads: 0.00, writes: 48032.30, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 594s] threads: 64, tps: 0.00, reads: 0.00, writes: 46339.95, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 595s] threads: 64, tps: 0.00, reads: 0.00, writes: 43644.94, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[ 596s] threads: 64, tps: 0.00, reads: 0.00, writes: 41352.00, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[ 597s] threads: 64, tps: 0.00, reads: 0.00, writes: 43275.75, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 598s] threads: 64, tps: 0.00, reads: 0.00, writes: 39631.26, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[ 599s] threads: 64, tps: 0.00, reads: 0.00, writes: 40037.01, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 600s] threads: 64, tps: 0.00, reads: 0.00, writes: 41829.00, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 601s] threads: 64, tps: 0.00, reads: 0.00, writes: 38144.99, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 602s] threads: 64, tps: 0.00, reads: 0.00, writes: 48868.96, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 603s] threads: 64, tps: 0.00, reads: 0.00, writes: 49373.83, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 604s] threads: 64, tps: 0.00, reads: 0.00, writes: 49079.17, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 605s] threads: 64, tps: 0.00, reads: 0.00, writes: 48672.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 606s] threads: 64, tps: 0.00, reads: 0.00, writes: 48664.14, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 607s] threads: 64, tps: 0.00, reads: 0.00, writes: 49706.89, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 608s] threads: 64, tps: 0.00, reads: 0.00, writes: 47279.78, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 609s] threads: 64, tps: 0.00, reads: 0.00, writes: 50318.32, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 610s] threads: 64, tps: 0.00, reads: 0.00, writes: 48210.81, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 611s] threads: 64, tps: 0.00, reads: 0.00, writes: 49401.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 612s] threads: 64, tps: 0.00, reads: 0.00, writes: 49093.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 613s] threads: 64, tps: 0.00, reads: 0.00, writes: 51656.90, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 614s] threads: 64, tps: 0.00, reads: 0.00, writes: 49537.84, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 615s] threads: 64, tps: 0.00, reads: 0.00, writes: 49831.26, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 616s] threads: 64, tps: 0.00, reads: 0.00, writes: 49069.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 617s] threads: 64, tps: 0.00, reads: 0.00, writes: 50790.92, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 618s] threads: 64, tps: 0.00, reads: 0.00, writes: 49802.06, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 619s] threads: 64, tps: 0.00, reads: 0.00, writes: 48041.02, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 620s] threads: 64, tps: 0.00, reads: 0.00, writes: 38805.97, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[ 621s] threads: 64, tps: 0.00, reads: 0.00, writes: 32851.99, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[ 622s] threads: 64, tps: 0.00, reads: 0.00, writes: 42036.75, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[ 623s] threads: 64, tps: 0.00, reads: 0.00, writes: 44441.08, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 624s] threads: 64, tps: 0.00, reads: 0.00, writes: 42332.01, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[ 625s] threads: 64, tps: 0.00, reads: 0.00, writes: 44902.26, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 626s] threads: 64, tps: 0.00, reads: 0.00, writes: 43257.80, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[ 627s] threads: 64, tps: 0.00, reads: 0.00, writes: 47306.20, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 628s] threads: 64, tps: 0.00, reads: 0.00, writes: 47851.76, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 629s] threads: 64, tps: 0.00, reads: 0.00, writes: 44722.36, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 630s] threads: 64, tps: 0.00, reads: 0.00, writes: 43110.60, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 631s] threads: 64, tps: 0.00, reads: 0.00, writes: 45566.14, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 632s] threads: 64, tps: 0.00, reads: 0.00, writes: 44889.84, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 633s] threads: 64, tps: 0.00, reads: 0.00, writes: 48557.03, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 634s] threads: 64, tps: 0.00, reads: 0.00, writes: 28449.64, response time: 11.46ms (95%), errors: 0.00, reconnects:  0.00
[ 635s] threads: 64, tps: 0.00, reads: 0.00, writes: 10788.01, response time: 20.32ms (95%), errors: 0.00, reconnects:  0.00
[ 636s] threads: 64, tps: 0.00, reads: 0.00, writes: 35125.84, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 637s] threads: 64, tps: 0.00, reads: 0.00, writes: 40502.25, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 638s] threads: 64, tps: 0.00, reads: 0.00, writes: 43746.59, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 639s] threads: 64, tps: 0.00, reads: 0.00, writes: 49420.55, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 640s] threads: 64, tps: 0.00, reads: 0.00, writes: 42291.96, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 641s] threads: 64, tps: 0.00, reads: 0.00, writes: 46243.85, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 642s] threads: 64, tps: 0.00, reads: 0.00, writes: 46824.19, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 643s] threads: 64, tps: 0.00, reads: 0.00, writes: 47252.84, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 644s] threads: 64, tps: 0.00, reads: 0.00, writes: 48820.23, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 645s] threads: 64, tps: 0.00, reads: 0.00, writes: 48173.00, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 646s] threads: 64, tps: 0.00, reads: 0.00, writes: 48904.73, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 647s] threads: 64, tps: 0.00, reads: 0.00, writes: 48167.27, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 648s] threads: 64, tps: 0.00, reads: 0.00, writes: 51025.77, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 649s] threads: 64, tps: 0.00, reads: 0.00, writes: 51231.20, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 650s] threads: 64, tps: 0.00, reads: 0.00, writes: 51255.05, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 651s] threads: 64, tps: 0.00, reads: 0.00, writes: 50246.94, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 652s] threads: 64, tps: 0.00, reads: 0.00, writes: 50721.74, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 653s] threads: 64, tps: 0.00, reads: 0.00, writes: 50685.24, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 654s] threads: 64, tps: 0.00, reads: 0.00, writes: 51244.03, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 655s] threads: 64, tps: 0.00, reads: 0.00, writes: 50271.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 656s] threads: 64, tps: 0.00, reads: 0.00, writes: 49279.96, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 657s] threads: 64, tps: 0.00, reads: 0.00, writes: 51217.94, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 658s] threads: 64, tps: 0.00, reads: 0.00, writes: 50689.06, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 659s] threads: 64, tps: 0.00, reads: 0.00, writes: 49233.80, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 660s] threads: 64, tps: 0.00, reads: 0.00, writes: 49043.15, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 661s] threads: 64, tps: 0.00, reads: 0.00, writes: 50122.99, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 662s] threads: 64, tps: 0.00, reads: 0.00, writes: 49801.05, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 663s] threads: 64, tps: 0.00, reads: 0.00, writes: 49756.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 664s] threads: 64, tps: 0.00, reads: 0.00, writes: 48176.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 665s] threads: 64, tps: 0.00, reads: 0.00, writes: 48725.55, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 666s] threads: 64, tps: 0.00, reads: 0.00, writes: 47854.45, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 667s] threads: 64, tps: 0.00, reads: 0.00, writes: 47387.00, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 668s] threads: 64, tps: 0.00, reads: 0.00, writes: 44628.02, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 669s] threads: 64, tps: 0.00, reads: 0.00, writes: 45802.95, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 670s] threads: 64, tps: 0.00, reads: 0.00, writes: 44949.00, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 671s] threads: 64, tps: 0.00, reads: 0.00, writes: 43179.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 672s] threads: 64, tps: 0.00, reads: 0.00, writes: 44146.04, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 673s] threads: 64, tps: 0.00, reads: 0.00, writes: 12789.99, response time: 20.23ms (95%), errors: 0.00, reconnects:  0.00
[ 674s] threads: 64, tps: 0.00, reads: 0.00, writes: 3223.92, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[ 675s] threads: 64, tps: 0.00, reads: 0.00, writes: 3243.97, response time: 20.69ms (95%), errors: 0.00, reconnects:  0.00
[ 676s] threads: 64, tps: 0.00, reads: 0.00, writes: 8824.07, response time: 20.42ms (95%), errors: 0.00, reconnects:  0.00
[ 677s] threads: 64, tps: 0.00, reads: 0.00, writes: 34337.84, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 678s] threads: 64, tps: 0.00, reads: 0.00, writes: 36427.03, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[ 679s] threads: 64, tps: 0.00, reads: 0.00, writes: 38734.00, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 680s] threads: 64, tps: 0.00, reads: 0.00, writes: 42759.07, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 681s] threads: 64, tps: 0.00, reads: 0.00, writes: 42953.94, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 682s] threads: 64, tps: 0.00, reads: 0.00, writes: 41533.82, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 683s] threads: 64, tps: 0.00, reads: 0.00, writes: 46042.16, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 684s] threads: 64, tps: 0.00, reads: 0.00, writes: 47392.08, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 685s] threads: 64, tps: 0.00, reads: 0.00, writes: 51436.97, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 686s] threads: 64, tps: 0.00, reads: 0.00, writes: 50278.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 687s] threads: 64, tps: 0.00, reads: 0.00, writes: 50493.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 688s] threads: 64, tps: 0.00, reads: 0.00, writes: 48601.73, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 689s] threads: 64, tps: 0.00, reads: 0.00, writes: 49340.25, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 690s] threads: 64, tps: 0.00, reads: 0.00, writes: 50874.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 691s] threads: 64, tps: 0.00, reads: 0.00, writes: 51001.95, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 692s] threads: 64, tps: 0.00, reads: 0.00, writes: 48983.04, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 693s] threads: 64, tps: 0.00, reads: 0.00, writes: 49993.96, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 694s] threads: 64, tps: 0.00, reads: 0.00, writes: 51174.06, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 695s] threads: 64, tps: 0.00, reads: 0.00, writes: 50633.98, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 696s] threads: 64, tps: 0.00, reads: 0.00, writes: 49807.84, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 697s] threads: 64, tps: 0.00, reads: 0.00, writes: 49960.08, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 698s] threads: 64, tps: 0.00, reads: 0.00, writes: 49656.77, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 699s] threads: 64, tps: 0.00, reads: 0.00, writes: 50990.25, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 700s] threads: 64, tps: 0.00, reads: 0.00, writes: 49461.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 701s] threads: 64, tps: 0.00, reads: 0.00, writes: 48798.07, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 702s] threads: 64, tps: 0.00, reads: 0.00, writes: 40274.94, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[ 703s] threads: 64, tps: 0.00, reads: 0.00, writes: 40474.97, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 704s] threads: 64, tps: 0.00, reads: 0.00, writes: 45157.03, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 705s] threads: 64, tps: 0.00, reads: 0.00, writes: 34900.86, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 706s] threads: 64, tps: 0.00, reads: 0.00, writes: 43725.15, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 707s] threads: 64, tps: 0.00, reads: 0.00, writes: 45635.92, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 708s] threads: 64, tps: 0.00, reads: 0.00, writes: 44940.14, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 709s] threads: 64, tps: 0.00, reads: 0.00, writes: 49120.96, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 710s] threads: 64, tps: 0.00, reads: 0.00, writes: 35213.40, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 711s] threads: 64, tps: 0.00, reads: 0.00, writes: 3221.97, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[ 712s] threads: 64, tps: 0.00, reads: 0.00, writes: 3244.08, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[ 713s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.95, response time: 20.71ms (95%), errors: 0.00, reconnects:  0.00
[ 714s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.96, response time: 20.58ms (95%), errors: 0.00, reconnects:  0.00
[ 715s] threads: 64, tps: 0.00, reads: 0.00, writes: 3242.08, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[ 716s] threads: 64, tps: 0.00, reads: 0.00, writes: 3226.00, response time: 20.60ms (95%), errors: 0.00, reconnects:  0.00
[ 717s] threads: 64, tps: 0.00, reads: 0.00, writes: 18477.04, response time: 19.39ms (95%), errors: 0.00, reconnects:  0.00
[ 718s] threads: 64, tps: 0.00, reads: 0.00, writes: 35055.05, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 719s] threads: 64, tps: 0.00, reads: 0.00, writes: 35724.98, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[ 720s] threads: 64, tps: 0.00, reads: 0.00, writes: 45309.02, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 721s] threads: 64, tps: 0.00, reads: 0.00, writes: 49099.05, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 722s] threads: 64, tps: 0.00, reads: 0.00, writes: 47874.95, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 723s] threads: 64, tps: 0.00, reads: 0.00, writes: 50570.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 724s] threads: 64, tps: 0.00, reads: 0.00, writes: 43290.06, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 725s] threads: 64, tps: 0.00, reads: 0.00, writes: 52318.01, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 726s] threads: 64, tps: 0.00, reads: 0.00, writes: 51731.82, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 727s] threads: 64, tps: 0.00, reads: 0.00, writes: 49587.85, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 728s] threads: 64, tps: 0.00, reads: 0.00, writes: 50359.11, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 729s] threads: 64, tps: 0.00, reads: 0.00, writes: 51207.10, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 730s] threads: 64, tps: 0.00, reads: 0.00, writes: 51335.03, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 731s] threads: 64, tps: 0.00, reads: 0.00, writes: 49837.09, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 732s] threads: 64, tps: 0.00, reads: 0.00, writes: 50092.76, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 733s] threads: 64, tps: 0.00, reads: 0.00, writes: 50025.29, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 734s] threads: 64, tps: 0.00, reads: 0.00, writes: 50260.73, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 735s] threads: 64, tps: 0.00, reads: 0.00, writes: 50167.21, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 736s] threads: 64, tps: 0.00, reads: 0.00, writes: 48837.71, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 737s] threads: 64, tps: 0.00, reads: 0.00, writes: 46728.26, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 738s] threads: 64, tps: 0.00, reads: 0.00, writes: 47307.96, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 739s] threads: 64, tps: 0.00, reads: 0.00, writes: 45983.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 740s] threads: 64, tps: 0.00, reads: 0.00, writes: 35666.89, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 741s] threads: 64, tps: 0.00, reads: 0.00, writes: 33466.13, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 742s] threads: 64, tps: 0.00, reads: 0.00, writes: 33291.01, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 743s] threads: 64, tps: 0.00, reads: 0.00, writes: 33606.04, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 744s] threads: 64, tps: 0.00, reads: 0.00, writes: 37455.00, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 745s] threads: 64, tps: 0.00, reads: 0.00, writes: 46751.92, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 746s] threads: 64, tps: 0.00, reads: 0.00, writes: 41150.76, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[ 747s] threads: 64, tps: 0.00, reads: 0.00, writes: 42395.32, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 748s] threads: 64, tps: 0.00, reads: 0.00, writes: 43472.98, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 749s] threads: 64, tps: 0.00, reads: 0.00, writes: 42616.97, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 750s] threads: 64, tps: 0.00, reads: 0.00, writes: 47542.79, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 751s] threads: 64, tps: 0.00, reads: 0.00, writes: 46326.20, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 752s] threads: 64, tps: 0.00, reads: 0.00, writes: 44329.99, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 753s] threads: 64, tps: 0.00, reads: 0.00, writes: 42878.00, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 754s] threads: 64, tps: 0.00, reads: 0.00, writes: 41876.04, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 755s] threads: 64, tps: 0.00, reads: 0.00, writes: 46689.95, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 756s] threads: 64, tps: 0.00, reads: 0.00, writes: 46725.80, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 757s] threads: 64, tps: 0.00, reads: 0.00, writes: 30332.17, response time: 3.57ms (95%), errors: 0.00, reconnects:  0.00
[ 758s] threads: 64, tps: 0.00, reads: 0.00, writes: 33810.95, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[ 759s] threads: 64, tps: 0.00, reads: 0.00, writes: 37918.01, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 760s] threads: 64, tps: 0.00, reads: 0.00, writes: 41947.01, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 761s] threads: 64, tps: 0.00, reads: 0.00, writes: 47188.90, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 762s] threads: 64, tps: 0.00, reads: 0.00, writes: 40851.05, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 763s] threads: 64, tps: 0.00, reads: 0.00, writes: 36256.02, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 764s] threads: 64, tps: 0.00, reads: 0.00, writes: 44623.31, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 765s] threads: 64, tps: 0.00, reads: 0.00, writes: 45606.67, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 766s] threads: 64, tps: 0.00, reads: 0.00, writes: 48872.41, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 767s] threads: 64, tps: 0.00, reads: 0.00, writes: 45625.37, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 768s] threads: 64, tps: 0.00, reads: 0.00, writes: 46083.97, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 769s] threads: 64, tps: 0.00, reads: 0.00, writes: 43908.10, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 770s] threads: 64, tps: 0.00, reads: 0.00, writes: 47825.99, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 771s] threads: 64, tps: 0.00, reads: 0.00, writes: 49095.71, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 772s] threads: 64, tps: 0.00, reads: 0.00, writes: 49811.30, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 773s] threads: 64, tps: 0.00, reads: 0.00, writes: 50098.93, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 774s] threads: 64, tps: 0.00, reads: 0.00, writes: 47818.98, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 775s] threads: 64, tps: 0.00, reads: 0.00, writes: 49953.04, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 776s] threads: 64, tps: 0.00, reads: 0.00, writes: 50341.02, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 777s] threads: 64, tps: 0.00, reads: 0.00, writes: 50105.61, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 778s] threads: 64, tps: 0.00, reads: 0.00, writes: 49488.40, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 779s] threads: 64, tps: 0.00, reads: 0.00, writes: 49126.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 780s] threads: 64, tps: 0.00, reads: 0.00, writes: 50355.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 781s] threads: 64, tps: 0.00, reads: 0.00, writes: 48934.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 782s] threads: 64, tps: 0.00, reads: 0.00, writes: 47674.96, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 783s] threads: 64, tps: 0.00, reads: 0.00, writes: 43022.89, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 784s] threads: 64, tps: 0.00, reads: 0.00, writes: 45369.09, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 785s] threads: 64, tps: 0.00, reads: 0.00, writes: 48579.07, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 786s] threads: 64, tps: 0.00, reads: 0.00, writes: 46449.02, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 787s] threads: 64, tps: 0.00, reads: 0.00, writes: 44566.73, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 788s] threads: 64, tps: 0.00, reads: 0.00, writes: 44380.23, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 789s] threads: 64, tps: 0.00, reads: 0.00, writes: 47047.99, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 790s] threads: 64, tps: 0.00, reads: 0.00, writes: 49362.01, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 791s] threads: 64, tps: 0.00, reads: 0.00, writes: 45923.96, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 792s] threads: 64, tps: 0.00, reads: 0.00, writes: 42878.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 793s] threads: 64, tps: 0.00, reads: 0.00, writes: 44784.06, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 794s] threads: 64, tps: 0.00, reads: 0.00, writes: 47434.92, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 795s] threads: 64, tps: 0.00, reads: 0.00, writes: 48996.10, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 796s] threads: 64, tps: 0.00, reads: 0.00, writes: 31292.65, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[ 797s] threads: 64, tps: 0.00, reads: 0.00, writes: 31467.22, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 798s] threads: 64, tps: 0.00, reads: 0.00, writes: 40414.11, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 799s] threads: 64, tps: 0.00, reads: 0.00, writes: 47043.04, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 800s] threads: 64, tps: 0.00, reads: 0.00, writes: 48789.95, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 801s] threads: 64, tps: 0.00, reads: 0.00, writes: 43830.76, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 802s] threads: 64, tps: 0.00, reads: 0.00, writes: 50566.33, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 803s] threads: 64, tps: 0.00, reads: 0.00, writes: 50768.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 804s] threads: 64, tps: 0.00, reads: 0.00, writes: 51142.96, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 805s] threads: 64, tps: 0.00, reads: 0.00, writes: 51404.06, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 806s] threads: 64, tps: 0.00, reads: 0.00, writes: 49468.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 807s] threads: 64, tps: 0.00, reads: 0.00, writes: 50323.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 808s] threads: 64, tps: 0.00, reads: 0.00, writes: 50558.93, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 809s] threads: 64, tps: 0.00, reads: 0.00, writes: 51762.08, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 810s] threads: 64, tps: 0.00, reads: 0.00, writes: 51586.99, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 811s] threads: 64, tps: 0.00, reads: 0.00, writes: 50549.02, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 812s] threads: 64, tps: 0.00, reads: 0.00, writes: 49946.02, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 813s] threads: 64, tps: 0.00, reads: 0.00, writes: 51103.77, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 814s] threads: 64, tps: 0.00, reads: 0.00, writes: 50440.14, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 815s] threads: 64, tps: 0.00, reads: 0.00, writes: 50294.99, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 816s] threads: 64, tps: 0.00, reads: 0.00, writes: 48261.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 817s] threads: 64, tps: 0.00, reads: 0.00, writes: 43671.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 818s] threads: 64, tps: 0.00, reads: 0.00, writes: 49781.09, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 819s] threads: 64, tps: 0.00, reads: 0.00, writes: 47432.02, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 820s] threads: 64, tps: 0.00, reads: 0.00, writes: 40836.00, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 821s] threads: 64, tps: 0.00, reads: 0.00, writes: 34332.67, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 822s] threads: 64, tps: 0.00, reads: 0.00, writes: 35913.35, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 823s] threads: 64, tps: 0.00, reads: 0.00, writes: 43402.74, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[ 824s] threads: 64, tps: 0.00, reads: 0.00, writes: 47944.05, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 825s] threads: 64, tps: 0.00, reads: 0.00, writes: 42460.20, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[ 826s] threads: 64, tps: 0.00, reads: 0.00, writes: 42785.76, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 827s] threads: 64, tps: 0.00, reads: 0.00, writes: 45498.23, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 828s] threads: 64, tps: 0.00, reads: 0.00, writes: 46099.87, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 829s] threads: 64, tps: 0.00, reads: 0.00, writes: 48225.00, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 830s] threads: 64, tps: 0.00, reads: 0.00, writes: 21488.41, response time: 19.55ms (95%), errors: 0.00, reconnects:  0.00
[ 831s] threads: 64, tps: 0.00, reads: 0.00, writes: 3220.88, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[ 832s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.08, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[ 833s] threads: 64, tps: 0.00, reads: 0.00, writes: 3225.04, response time: 21.48ms (95%), errors: 0.00, reconnects:  0.00
[ 834s] threads: 64, tps: 0.00, reads: 0.00, writes: 5275.99, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[ 835s] threads: 64, tps: 0.00, reads: 0.00, writes: 33426.00, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 836s] threads: 64, tps: 0.00, reads: 0.00, writes: 37841.18, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[ 837s] threads: 64, tps: 0.00, reads: 0.00, writes: 44843.95, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 838s] threads: 64, tps: 0.00, reads: 0.00, writes: 49797.89, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 839s] threads: 64, tps: 0.00, reads: 0.00, writes: 47930.14, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 840s] threads: 64, tps: 0.00, reads: 0.00, writes: 48810.03, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 841s] threads: 64, tps: 0.00, reads: 0.00, writes: 50996.73, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 842s] threads: 64, tps: 0.00, reads: 0.00, writes: 45840.98, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 843s] threads: 64, tps: 0.00, reads: 0.00, writes: 50087.28, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 844s] threads: 64, tps: 0.00, reads: 0.00, writes: 50142.73, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 845s] threads: 64, tps: 0.00, reads: 0.00, writes: 50236.28, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 846s] threads: 64, tps: 0.00, reads: 0.00, writes: 49802.95, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 847s] threads: 64, tps: 0.00, reads: 0.00, writes: 51656.84, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 848s] threads: 64, tps: 0.00, reads: 0.00, writes: 50411.18, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 849s] threads: 64, tps: 0.00, reads: 0.00, writes: 49673.09, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 850s] threads: 64, tps: 0.00, reads: 0.00, writes: 50288.92, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 851s] threads: 64, tps: 0.00, reads: 0.00, writes: 50618.05, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 852s] threads: 64, tps: 0.00, reads: 0.00, writes: 50842.70, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 853s] threads: 64, tps: 0.00, reads: 0.00, writes: 49682.22, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 854s] threads: 64, tps: 0.00, reads: 0.00, writes: 48676.06, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 855s] threads: 64, tps: 0.00, reads: 0.00, writes: 48705.76, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 856s] threads: 64, tps: 0.00, reads: 0.00, writes: 49627.18, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 857s] threads: 64, tps: 0.00, reads: 0.00, writes: 43718.38, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 858s] threads: 64, tps: 0.00, reads: 0.00, writes: 34239.97, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 859s] threads: 64, tps: 0.00, reads: 0.00, writes: 34381.54, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 860s] threads: 64, tps: 0.00, reads: 0.00, writes: 43129.01, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 861s] threads: 64, tps: 0.00, reads: 0.00, writes: 48104.85, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 862s] threads: 64, tps: 0.00, reads: 0.00, writes: 48542.14, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 863s] threads: 64, tps: 0.00, reads: 0.00, writes: 47017.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 864s] threads: 64, tps: 0.00, reads: 0.00, writes: 43981.92, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 865s] threads: 64, tps: 0.00, reads: 0.00, writes: 44264.87, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 866s] threads: 64, tps: 0.00, reads: 0.00, writes: 48116.96, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 867s] threads: 64, tps: 0.00, reads: 0.00, writes: 49585.08, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 868s] threads: 64, tps: 0.00, reads: 0.00, writes: 45670.05, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 869s] threads: 64, tps: 0.00, reads: 0.00, writes: 45975.09, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 870s] threads: 64, tps: 0.00, reads: 0.00, writes: 45218.85, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 871s] threads: 64, tps: 0.00, reads: 0.00, writes: 46318.16, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 872s] threads: 64, tps: 0.00, reads: 0.00, writes: 40383.01, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[ 873s] threads: 64, tps: 0.00, reads: 0.00, writes: 36221.83, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[ 874s] threads: 64, tps: 0.00, reads: 0.00, writes: 44385.19, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 875s] threads: 64, tps: 0.00, reads: 0.00, writes: 46124.86, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 876s] threads: 64, tps: 0.00, reads: 0.00, writes: 49050.85, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 877s] threads: 64, tps: 0.00, reads: 0.00, writes: 48330.18, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 878s] threads: 64, tps: 0.00, reads: 0.00, writes: 48369.22, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 879s] threads: 64, tps: 0.00, reads: 0.00, writes: 47948.77, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 880s] threads: 64, tps: 0.00, reads: 0.00, writes: 41372.14, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 881s] threads: 64, tps: 0.00, reads: 0.00, writes: 51413.92, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 882s] threads: 64, tps: 0.00, reads: 0.00, writes: 50399.03, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 883s] threads: 64, tps: 0.00, reads: 0.00, writes: 48730.86, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 884s] threads: 64, tps: 0.00, reads: 0.00, writes: 48881.16, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 885s] threads: 64, tps: 0.00, reads: 0.00, writes: 50638.00, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 886s] threads: 64, tps: 0.00, reads: 0.00, writes: 49695.07, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 887s] threads: 64, tps: 0.00, reads: 0.00, writes: 50462.85, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 888s] threads: 64, tps: 0.00, reads: 0.00, writes: 49480.13, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 889s] threads: 64, tps: 0.00, reads: 0.00, writes: 48181.01, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 890s] threads: 64, tps: 0.00, reads: 0.00, writes: 50928.94, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 891s] threads: 64, tps: 0.00, reads: 0.00, writes: 48938.05, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 892s] threads: 64, tps: 0.00, reads: 0.00, writes: 50148.16, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 893s] threads: 64, tps: 0.00, reads: 0.00, writes: 49347.59, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 894s] threads: 64, tps: 0.00, reads: 0.00, writes: 47752.22, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 895s] threads: 64, tps: 0.00, reads: 0.00, writes: 49762.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 896s] threads: 64, tps: 0.00, reads: 0.00, writes: 49411.04, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 897s] threads: 64, tps: 0.00, reads: 0.00, writes: 47768.71, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 898s] threads: 64, tps: 0.00, reads: 0.00, writes: 44615.25, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 899s] threads: 64, tps: 0.00, reads: 0.00, writes: 47793.93, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 900s] threads: 64, tps: 0.00, reads: 0.00, writes: 48131.87, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 901s] threads: 64, tps: 0.00, reads: 0.00, writes: 46055.25, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 902s] threads: 64, tps: 0.00, reads: 0.00, writes: 44877.39, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 903s] threads: 64, tps: 0.00, reads: 0.00, writes: 44240.57, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 904s] threads: 64, tps: 0.00, reads: 0.00, writes: 48299.93, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 905s] threads: 64, tps: 0.00, reads: 0.00, writes: 46649.97, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 906s] threads: 64, tps: 0.00, reads: 0.00, writes: 12161.60, response time: 20.20ms (95%), errors: 0.00, reconnects:  0.00
[ 907s] threads: 64, tps: 0.00, reads: 0.00, writes: 3248.00, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[ 908s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.05, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[ 909s] threads: 64, tps: 0.00, reads: 0.00, writes: 3227.97, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[ 910s] threads: 64, tps: 0.00, reads: 0.00, writes: 18957.47, response time: 19.60ms (95%), errors: 0.00, reconnects:  0.00
[ 911s] threads: 64, tps: 0.00, reads: 0.00, writes: 36072.09, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[ 912s] threads: 64, tps: 0.00, reads: 0.00, writes: 39094.02, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 913s] threads: 64, tps: 0.00, reads: 0.00, writes: 46331.03, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 914s] threads: 64, tps: 0.00, reads: 0.00, writes: 40401.93, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 915s] threads: 64, tps: 0.00, reads: 0.00, writes: 47625.01, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 916s] threads: 64, tps: 0.00, reads: 0.00, writes: 47574.08, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 917s] threads: 64, tps: 0.00, reads: 0.00, writes: 49635.99, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 918s] threads: 64, tps: 0.00, reads: 0.00, writes: 50559.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 919s] threads: 64, tps: 0.00, reads: 0.00, writes: 51207.00, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 920s] threads: 64, tps: 0.00, reads: 0.00, writes: 50632.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 921s] threads: 64, tps: 0.00, reads: 0.00, writes: 42391.03, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 922s] threads: 64, tps: 0.00, reads: 0.00, writes: 51321.03, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 923s] threads: 64, tps: 0.00, reads: 0.00, writes: 52200.93, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 924s] threads: 64, tps: 0.00, reads: 0.00, writes: 51033.04, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 925s] threads: 64, tps: 0.00, reads: 0.00, writes: 51194.89, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 926s] threads: 64, tps: 0.00, reads: 0.00, writes: 51038.10, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 927s] threads: 64, tps: 0.00, reads: 0.00, writes: 49271.93, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 928s] threads: 64, tps: 0.00, reads: 0.00, writes: 51582.84, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 929s] threads: 64, tps: 0.00, reads: 0.00, writes: 50620.16, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 930s] threads: 64, tps: 0.00, reads: 0.00, writes: 49063.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 931s] threads: 64, tps: 0.00, reads: 0.00, writes: 51716.12, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 932s] threads: 64, tps: 0.00, reads: 0.00, writes: 51456.92, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 933s] threads: 64, tps: 0.00, reads: 0.00, writes: 50583.79, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 934s] threads: 64, tps: 0.00, reads: 0.00, writes: 50534.25, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 935s] threads: 64, tps: 0.00, reads: 0.00, writes: 48566.96, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 936s] threads: 64, tps: 0.00, reads: 0.00, writes: 50931.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 937s] threads: 64, tps: 0.00, reads: 0.00, writes: 51103.08, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 938s] threads: 64, tps: 0.00, reads: 0.00, writes: 50198.97, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 939s] threads: 64, tps: 0.00, reads: 0.00, writes: 50260.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 940s] threads: 64, tps: 0.00, reads: 0.00, writes: 26921.29, response time: 18.82ms (95%), errors: 0.00, reconnects:  0.00
[ 941s] threads: 64, tps: 0.00, reads: 0.00, writes: 45003.15, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 942s] threads: 64, tps: 0.00, reads: 0.00, writes: 49938.06, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 943s] threads: 64, tps: 0.00, reads: 0.00, writes: 42920.77, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 944s] threads: 64, tps: 0.00, reads: 0.00, writes: 35400.14, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 945s] threads: 64, tps: 0.00, reads: 0.00, writes: 34856.01, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 946s] threads: 64, tps: 0.00, reads: 0.00, writes: 40516.06, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[ 947s] threads: 64, tps: 0.00, reads: 0.00, writes: 44064.99, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 948s] threads: 64, tps: 0.00, reads: 0.00, writes: 3243.94, response time: 20.65ms (95%), errors: 0.00, reconnects:  0.00
[ 949s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.05, response time: 20.60ms (95%), errors: 0.00, reconnects:  0.00
[ 950s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.01, response time: 20.58ms (95%), errors: 0.00, reconnects:  0.00
[ 951s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.96, response time: 20.72ms (95%), errors: 0.00, reconnects:  0.00
[ 952s] threads: 64, tps: 0.00, reads: 0.00, writes: 3228.02, response time: 20.75ms (95%), errors: 0.00, reconnects:  0.00
[ 953s] threads: 64, tps: 0.00, reads: 0.00, writes: 3236.01, response time: 20.67ms (95%), errors: 0.00, reconnects:  0.00
[ 954s] threads: 64, tps: 0.00, reads: 0.00, writes: 3214.92, response time: 22.52ms (95%), errors: 0.00, reconnects:  0.00
[ 955s] threads: 64, tps: 0.00, reads: 0.00, writes: 3243.98, response time: 20.75ms (95%), errors: 0.00, reconnects:  0.00
[ 956s] threads: 64, tps: 0.00, reads: 0.00, writes: 3220.05, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[ 957s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.97, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[ 958s] threads: 64, tps: 0.00, reads: 0.00, writes: 3219.99, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[ 959s] threads: 64, tps: 0.00, reads: 0.00, writes: 34485.10, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 960s] threads: 64, tps: 0.00, reads: 0.00, writes: 39287.99, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 961s] threads: 64, tps: 0.00, reads: 0.00, writes: 43479.49, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 962s] threads: 64, tps: 0.00, reads: 0.00, writes: 48380.59, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 963s] threads: 64, tps: 0.00, reads: 0.00, writes: 49536.02, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 964s] threads: 64, tps: 0.00, reads: 0.00, writes: 50328.74, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 965s] threads: 64, tps: 0.00, reads: 0.00, writes: 50388.17, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 966s] threads: 64, tps: 0.00, reads: 0.00, writes: 49997.11, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 967s] threads: 64, tps: 0.00, reads: 0.00, writes: 52280.90, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 968s] threads: 64, tps: 0.00, reads: 0.00, writes: 42115.57, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 969s] threads: 64, tps: 0.00, reads: 0.00, writes: 50544.96, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 970s] threads: 64, tps: 0.00, reads: 0.00, writes: 50516.50, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 971s] threads: 64, tps: 0.00, reads: 0.00, writes: 50907.94, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 972s] threads: 64, tps: 0.00, reads: 0.00, writes: 51981.64, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 973s] threads: 64, tps: 0.00, reads: 0.00, writes: 47782.99, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 974s] threads: 64, tps: 0.00, reads: 0.00, writes: 51132.96, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 975s] threads: 64, tps: 0.00, reads: 0.00, writes: 51732.07, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 976s] threads: 64, tps: 0.00, reads: 0.00, writes: 50055.94, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 977s] threads: 64, tps: 0.00, reads: 0.00, writes: 50125.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 978s] threads: 64, tps: 0.00, reads: 0.00, writes: 50869.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 979s] threads: 64, tps: 0.00, reads: 0.00, writes: 50806.02, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 980s] threads: 64, tps: 0.00, reads: 0.00, writes: 51771.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 981s] threads: 64, tps: 0.00, reads: 0.00, writes: 51454.96, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 982s] threads: 64, tps: 0.00, reads: 0.00, writes: 45891.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 983s] threads: 64, tps: 0.00, reads: 0.00, writes: 42770.97, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[ 984s] threads: 64, tps: 0.00, reads: 0.00, writes: 34493.86, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 985s] threads: 64, tps: 0.00, reads: 0.00, writes: 48797.13, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 986s] threads: 64, tps: 0.00, reads: 0.00, writes: 39801.12, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[ 987s] threads: 64, tps: 0.00, reads: 0.00, writes: 33895.97, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 988s] threads: 64, tps: 0.00, reads: 0.00, writes: 34416.99, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 989s] threads: 64, tps: 0.00, reads: 0.00, writes: 33236.96, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[ 990s] threads: 64, tps: 0.00, reads: 0.00, writes: 40094.03, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[ 991s] threads: 64, tps: 0.00, reads: 0.00, writes: 47564.02, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 992s] threads: 64, tps: 0.00, reads: 0.00, writes: 44033.01, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 993s] threads: 64, tps: 0.00, reads: 0.00, writes: 33424.97, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 994s] threads: 64, tps: 0.00, reads: 0.00, writes: 39082.08, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[ 995s] threads: 64, tps: 0.00, reads: 0.00, writes: 44302.73, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 996s] threads: 64, tps: 0.00, reads: 0.00, writes: 46753.22, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 997s] threads: 64, tps: 0.00, reads: 0.00, writes: 48006.02, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 998s] threads: 64, tps: 0.00, reads: 0.00, writes: 46515.00, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 999s] threads: 64, tps: 0.00, reads: 0.00, writes: 37234.91, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1000s] threads: 64, tps: 0.00, reads: 0.00, writes: 44204.13, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1001s] threads: 64, tps: 0.00, reads: 0.00, writes: 46012.97, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1002s] threads: 64, tps: 0.00, reads: 0.00, writes: 48871.03, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1003s] threads: 64, tps: 0.00, reads: 0.00, writes: 46904.00, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1004s] threads: 64, tps: 0.00, reads: 0.00, writes: 44098.99, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1005s] threads: 64, tps: 0.00, reads: 0.00, writes: 36984.01, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1006s] threads: 64, tps: 0.00, reads: 0.00, writes: 40969.96, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1007s] threads: 64, tps: 0.00, reads: 0.00, writes: 40420.97, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1008s] threads: 64, tps: 0.00, reads: 0.00, writes: 42899.12, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1009s] threads: 64, tps: 0.00, reads: 0.00, writes: 43481.08, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1010s] threads: 64, tps: 0.00, reads: 0.00, writes: 42929.80, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1011s] threads: 64, tps: 0.00, reads: 0.00, writes: 47042.03, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1012s] threads: 64, tps: 0.00, reads: 0.00, writes: 49151.99, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1013s] threads: 64, tps: 0.00, reads: 0.00, writes: 46141.86, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1014s] threads: 64, tps: 0.00, reads: 0.00, writes: 44231.16, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1015s] threads: 64, tps: 0.00, reads: 0.00, writes: 46611.01, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1016s] threads: 64, tps: 0.00, reads: 0.00, writes: 49376.92, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1017s] threads: 64, tps: 0.00, reads: 0.00, writes: 48817.98, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1018s] threads: 64, tps: 0.00, reads: 0.00, writes: 49964.11, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1019s] threads: 64, tps: 0.00, reads: 0.00, writes: 49416.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1020s] threads: 64, tps: 0.00, reads: 0.00, writes: 48581.87, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1021s] threads: 64, tps: 0.00, reads: 0.00, writes: 48235.13, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1022s] threads: 64, tps: 0.00, reads: 0.00, writes: 50988.96, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1023s] threads: 64, tps: 0.00, reads: 0.00, writes: 50303.06, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1024s] threads: 64, tps: 0.00, reads: 0.00, writes: 49514.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1025s] threads: 64, tps: 0.00, reads: 0.00, writes: 51040.00, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1026s] threads: 64, tps: 0.00, reads: 0.00, writes: 48359.94, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1027s] threads: 64, tps: 0.00, reads: 0.00, writes: 49689.01, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1028s] threads: 64, tps: 0.00, reads: 0.00, writes: 50238.00, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1029s] threads: 64, tps: 0.00, reads: 0.00, writes: 49178.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1030s] threads: 64, tps: 0.00, reads: 0.00, writes: 47471.03, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1031s] threads: 64, tps: 0.00, reads: 0.00, writes: 47644.02, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1032s] threads: 64, tps: 0.00, reads: 0.00, writes: 46082.91, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1033s] threads: 64, tps: 0.00, reads: 0.00, writes: 44187.10, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1034s] threads: 64, tps: 0.00, reads: 0.00, writes: 45623.94, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1035s] threads: 64, tps: 0.00, reads: 0.00, writes: 47718.00, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1036s] threads: 64, tps: 0.00, reads: 0.00, writes: 47910.01, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1037s] threads: 64, tps: 0.00, reads: 0.00, writes: 43600.99, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1038s] threads: 64, tps: 0.00, reads: 0.00, writes: 43151.39, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1039s] threads: 64, tps: 0.00, reads: 0.00, writes: 42033.62, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1040s] threads: 64, tps: 0.00, reads: 0.00, writes: 42944.96, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1041s] threads: 64, tps: 0.00, reads: 0.00, writes: 43523.70, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1042s] threads: 64, tps: 0.00, reads: 0.00, writes: 3252.02, response time: 20.60ms (95%), errors: 0.00, reconnects:  0.00
[1043s] threads: 64, tps: 0.00, reads: 0.00, writes: 10828.25, response time: 20.25ms (95%), errors: 0.00, reconnects:  0.00
[1044s] threads: 64, tps: 0.00, reads: 0.00, writes: 34218.02, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1045s] threads: 64, tps: 0.00, reads: 0.00, writes: 42110.98, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1046s] threads: 64, tps: 0.00, reads: 0.00, writes: 44753.08, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1047s] threads: 64, tps: 0.00, reads: 0.00, writes: 51259.91, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1048s] threads: 64, tps: 0.00, reads: 0.00, writes: 49549.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1049s] threads: 64, tps: 0.00, reads: 0.00, writes: 50636.96, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1050s] threads: 64, tps: 0.00, reads: 0.00, writes: 50808.09, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1051s] threads: 64, tps: 0.00, reads: 0.00, writes: 50020.00, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1052s] threads: 64, tps: 0.00, reads: 0.00, writes: 50357.93, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1053s] threads: 64, tps: 0.00, reads: 0.00, writes: 50304.78, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1054s] threads: 64, tps: 0.00, reads: 0.00, writes: 50549.35, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1055s] threads: 64, tps: 0.00, reads: 0.00, writes: 49471.88, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1056s] threads: 64, tps: 0.00, reads: 0.00, writes: 51125.85, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1057s] threads: 64, tps: 0.00, reads: 0.00, writes: 50987.19, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1058s] threads: 64, tps: 0.00, reads: 0.00, writes: 50505.79, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1059s] threads: 64, tps: 0.00, reads: 0.00, writes: 50084.28, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1060s] threads: 64, tps: 0.00, reads: 0.00, writes: 50376.16, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1061s] threads: 64, tps: 0.00, reads: 0.00, writes: 50699.76, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1062s] threads: 64, tps: 0.00, reads: 0.00, writes: 48760.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1063s] threads: 64, tps: 0.00, reads: 0.00, writes: 47288.17, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1064s] threads: 64, tps: 0.00, reads: 0.00, writes: 37761.00, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1065s] threads: 64, tps: 0.00, reads: 0.00, writes: 43678.03, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1066s] threads: 64, tps: 0.00, reads: 0.00, writes: 43114.99, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[1067s] threads: 64, tps: 0.00, reads: 0.00, writes: 34192.91, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[1068s] threads: 64, tps: 0.00, reads: 0.00, writes: 46606.93, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1069s] threads: 64, tps: 0.00, reads: 0.00, writes: 43559.07, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1070s] threads: 64, tps: 0.00, reads: 0.00, writes: 45668.13, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1071s] threads: 64, tps: 0.00, reads: 0.00, writes: 47397.86, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1072s] threads: 64, tps: 0.00, reads: 0.00, writes: 45187.12, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1073s] threads: 64, tps: 0.00, reads: 0.00, writes: 44058.84, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1074s] threads: 64, tps: 0.00, reads: 0.00, writes: 43822.47, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1075s] threads: 64, tps: 0.00, reads: 0.00, writes: 47589.79, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1076s] threads: 64, tps: 0.00, reads: 0.00, writes: 47853.84, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1077s] threads: 64, tps: 0.00, reads: 0.00, writes: 22549.49, response time: 19.44ms (95%), errors: 0.00, reconnects:  0.00
[1078s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.95, response time: 20.65ms (95%), errors: 0.00, reconnects:  0.00
[1079s] threads: 64, tps: 0.00, reads: 0.00, writes: 15153.61, response time: 20.05ms (95%), errors: 0.00, reconnects:  0.00
[1080s] threads: 64, tps: 0.00, reads: 0.00, writes: 31836.98, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1081s] threads: 64, tps: 0.00, reads: 0.00, writes: 43843.09, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1082s] threads: 64, tps: 0.00, reads: 0.00, writes: 48444.72, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1083s] threads: 64, tps: 0.00, reads: 0.00, writes: 49464.33, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1084s] threads: 64, tps: 0.00, reads: 0.00, writes: 50409.89, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1085s] threads: 64, tps: 0.00, reads: 0.00, writes: 45341.02, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1086s] threads: 64, tps: 0.00, reads: 0.00, writes: 50826.82, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1087s] threads: 64, tps: 0.00, reads: 0.00, writes: 51493.18, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[1088s] threads: 64, tps: 0.00, reads: 0.00, writes: 51612.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1089s] threads: 64, tps: 0.00, reads: 0.00, writes: 50149.04, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1090s] threads: 64, tps: 0.00, reads: 0.00, writes: 50022.96, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1091s] threads: 64, tps: 0.00, reads: 0.00, writes: 50032.02, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1092s] threads: 64, tps: 0.00, reads: 0.00, writes: 52352.03, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1093s] threads: 64, tps: 0.00, reads: 0.00, writes: 50336.70, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1094s] threads: 64, tps: 0.00, reads: 0.00, writes: 51321.21, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1095s] threads: 64, tps: 0.00, reads: 0.00, writes: 50568.27, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1096s] threads: 64, tps: 0.00, reads: 0.00, writes: 49997.78, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1097s] threads: 64, tps: 0.00, reads: 0.00, writes: 51203.95, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1098s] threads: 64, tps: 0.00, reads: 0.00, writes: 50745.97, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1099s] threads: 64, tps: 0.00, reads: 0.00, writes: 49708.81, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1100s] threads: 64, tps: 0.00, reads: 0.00, writes: 50538.15, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1101s] threads: 64, tps: 0.00, reads: 0.00, writes: 48757.92, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1102s] threads: 64, tps: 0.00, reads: 0.00, writes: 50407.64, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1103s] threads: 64, tps: 0.00, reads: 0.00, writes: 43703.46, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1104s] threads: 64, tps: 0.00, reads: 0.00, writes: 32999.80, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[1105s] threads: 64, tps: 0.00, reads: 0.00, writes: 36945.20, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1106s] threads: 64, tps: 0.00, reads: 0.00, writes: 47673.98, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1107s] threads: 64, tps: 0.00, reads: 0.00, writes: 37385.99, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[1108s] threads: 64, tps: 0.00, reads: 0.00, writes: 34628.02, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[1109s] threads: 64, tps: 0.00, reads: 0.00, writes: 39935.99, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1110s] threads: 64, tps: 0.00, reads: 0.00, writes: 44028.03, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1111s] threads: 64, tps: 0.00, reads: 0.00, writes: 48290.00, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1112s] threads: 64, tps: 0.00, reads: 0.00, writes: 47378.97, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1113s] threads: 64, tps: 0.00, reads: 0.00, writes: 45770.00, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1114s] threads: 64, tps: 0.00, reads: 0.00, writes: 44233.75, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1115s] threads: 64, tps: 0.00, reads: 0.00, writes: 43891.30, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1116s] threads: 64, tps: 0.00, reads: 0.00, writes: 46756.03, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1117s] threads: 64, tps: 0.00, reads: 0.00, writes: 47549.97, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1118s] threads: 64, tps: 0.00, reads: 0.00, writes: 17148.97, response time: 20.11ms (95%), errors: 0.00, reconnects:  0.00
[1119s] threads: 64, tps: 0.00, reads: 0.00, writes: 3218.91, response time: 20.65ms (95%), errors: 0.00, reconnects:  0.00
[1120s] threads: 64, tps: 0.00, reads: 0.00, writes: 3244.08, response time: 20.77ms (95%), errors: 0.00, reconnects:  0.00
[1121s] threads: 64, tps: 0.00, reads: 0.00, writes: 26853.10, response time: 4.28ms (95%), errors: 0.00, reconnects:  0.00
[1122s] threads: 64, tps: 0.00, reads: 0.00, writes: 35688.98, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1123s] threads: 64, tps: 0.00, reads: 0.00, writes: 40164.05, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1124s] threads: 64, tps: 0.00, reads: 0.00, writes: 48345.96, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1125s] threads: 64, tps: 0.00, reads: 0.00, writes: 48214.99, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1126s] threads: 64, tps: 0.00, reads: 0.00, writes: 43455.02, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1127s] threads: 64, tps: 0.00, reads: 0.00, writes: 49162.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1128s] threads: 64, tps: 0.00, reads: 0.00, writes: 49229.76, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1129s] threads: 64, tps: 0.00, reads: 0.00, writes: 52136.10, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1130s] threads: 64, tps: 0.00, reads: 0.00, writes: 48858.89, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1131s] threads: 64, tps: 0.00, reads: 0.00, writes: 49770.21, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1132s] threads: 64, tps: 0.00, reads: 0.00, writes: 50222.88, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1133s] threads: 64, tps: 0.00, reads: 0.00, writes: 49294.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1134s] threads: 64, tps: 0.00, reads: 0.00, writes: 51261.35, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1135s] threads: 64, tps: 0.00, reads: 0.00, writes: 48502.53, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1136s] threads: 64, tps: 0.00, reads: 0.00, writes: 49889.31, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1137s] threads: 64, tps: 0.00, reads: 0.00, writes: 48845.89, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1138s] threads: 64, tps: 0.00, reads: 0.00, writes: 51170.79, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1139s] threads: 64, tps: 0.00, reads: 0.00, writes: 50872.27, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1140s] threads: 64, tps: 0.00, reads: 0.00, writes: 49779.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1141s] threads: 64, tps: 0.00, reads: 0.00, writes: 50357.09, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1142s] threads: 64, tps: 0.00, reads: 0.00, writes: 51198.67, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1143s] threads: 64, tps: 0.00, reads: 0.00, writes: 48953.25, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1144s] threads: 64, tps: 0.00, reads: 0.00, writes: 47522.01, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1145s] threads: 64, tps: 0.00, reads: 0.00, writes: 41386.72, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1146s] threads: 64, tps: 0.00, reads: 0.00, writes: 33620.06, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1147s] threads: 64, tps: 0.00, reads: 0.00, writes: 39173.17, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1148s] threads: 64, tps: 0.00, reads: 0.00, writes: 47034.78, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1149s] threads: 64, tps: 0.00, reads: 0.00, writes: 39643.26, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1150s] threads: 64, tps: 0.00, reads: 0.00, writes: 43282.99, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1151s] threads: 64, tps: 0.00, reads: 0.00, writes: 43677.79, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1152s] threads: 64, tps: 0.00, reads: 0.00, writes: 44494.26, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1153s] threads: 64, tps: 0.00, reads: 0.00, writes: 47848.00, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1154s] threads: 64, tps: 0.00, reads: 0.00, writes: 46048.76, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1155s] threads: 64, tps: 0.00, reads: 0.00, writes: 42871.15, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1156s] threads: 64, tps: 0.00, reads: 0.00, writes: 44394.00, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1157s] threads: 64, tps: 0.00, reads: 0.00, writes: 43595.41, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1158s] threads: 64, tps: 0.00, reads: 0.00, writes: 47561.45, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1159s] threads: 64, tps: 0.00, reads: 0.00, writes: 38263.92, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1160s] threads: 64, tps: 0.00, reads: 0.00, writes: 3228.02, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[1161s] threads: 64, tps: 0.00, reads: 0.00, writes: 19474.55, response time: 19.06ms (95%), errors: 0.00, reconnects:  0.00
[1162s] threads: 64, tps: 0.00, reads: 0.00, writes: 38297.79, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1163s] threads: 64, tps: 0.00, reads: 0.00, writes: 42747.23, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1164s] threads: 64, tps: 0.00, reads: 0.00, writes: 46954.99, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1165s] threads: 64, tps: 0.00, reads: 0.00, writes: 45391.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1166s] threads: 64, tps: 0.00, reads: 0.00, writes: 45522.01, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1167s] threads: 64, tps: 0.00, reads: 0.00, writes: 48463.92, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1168s] threads: 64, tps: 0.00, reads: 0.00, writes: 48823.13, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1169s] threads: 64, tps: 0.00, reads: 0.00, writes: 49524.92, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1170s] threads: 64, tps: 0.00, reads: 0.00, writes: 48070.00, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1171s] threads: 64, tps: 0.00, reads: 0.00, writes: 48365.97, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1172s] threads: 64, tps: 0.00, reads: 0.00, writes: 48890.06, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1173s] threads: 64, tps: 0.00, reads: 0.00, writes: 48195.97, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1174s] threads: 64, tps: 0.00, reads: 0.00, writes: 51694.98, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1175s] threads: 64, tps: 0.00, reads: 0.00, writes: 50064.92, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1176s] threads: 64, tps: 0.00, reads: 0.00, writes: 50406.32, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1177s] threads: 64, tps: 0.00, reads: 0.00, writes: 49799.76, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1178s] threads: 64, tps: 0.00, reads: 0.00, writes: 49927.04, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1179s] threads: 64, tps: 0.00, reads: 0.00, writes: 50027.96, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1180s] threads: 64, tps: 0.00, reads: 0.00, writes: 48965.59, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1181s] threads: 64, tps: 0.00, reads: 0.00, writes: 49653.17, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1182s] threads: 64, tps: 0.00, reads: 0.00, writes: 48875.94, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1183s] threads: 64, tps: 0.00, reads: 0.00, writes: 50402.84, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1184s] threads: 64, tps: 0.00, reads: 0.00, writes: 48780.14, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1185s] threads: 64, tps: 0.00, reads: 0.00, writes: 48672.12, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1186s] threads: 64, tps: 0.00, reads: 0.00, writes: 49203.80, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1187s] threads: 64, tps: 0.00, reads: 0.00, writes: 50622.97, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1188s] threads: 64, tps: 0.00, reads: 0.00, writes: 50504.04, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1189s] threads: 64, tps: 0.00, reads: 0.00, writes: 48803.37, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1190s] threads: 64, tps: 0.00, reads: 0.00, writes: 49893.54, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1191s] threads: 64, tps: 0.00, reads: 0.00, writes: 45437.99, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1192s] threads: 64, tps: 0.00, reads: 0.00, writes: 48269.96, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1193s] threads: 64, tps: 0.00, reads: 0.00, writes: 48162.90, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1194s] threads: 64, tps: 0.00, reads: 0.00, writes: 43571.10, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1195s] threads: 64, tps: 0.00, reads: 0.00, writes: 43284.01, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1196s] threads: 64, tps: 0.00, reads: 0.00, writes: 38422.97, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1197s] threads: 64, tps: 0.00, reads: 0.00, writes: 46635.04, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1198s] threads: 64, tps: 0.00, reads: 0.00, writes: 47884.01, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1199s] threads: 64, tps: 0.00, reads: 0.00, writes: 13433.96, response time: 20.17ms (95%), errors: 0.00, reconnects:  0.00
[1200s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.90, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[1201s] threads: 64, tps: 0.00, reads: 0.00, writes: 3227.09, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[1202s] threads: 64, tps: 0.00, reads: 0.00, writes: 3234.96, response time: 20.58ms (95%), errors: 0.00, reconnects:  0.00
[1203s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.06, response time: 20.54ms (95%), errors: 0.00, reconnects:  0.00
[1204s] threads: 64, tps: 0.00, reads: 0.00, writes: 33677.99, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1205s] threads: 64, tps: 0.00, reads: 0.00, writes: 39282.98, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1206s] threads: 64, tps: 0.00, reads: 0.00, writes: 36820.93, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1207s] threads: 64, tps: 0.00, reads: 0.00, writes: 50370.21, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1208s] threads: 64, tps: 0.00, reads: 0.00, writes: 45238.97, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1209s] threads: 64, tps: 0.00, reads: 0.00, writes: 48740.99, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1210s] threads: 64, tps: 0.00, reads: 0.00, writes: 49786.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1211s] threads: 64, tps: 0.00, reads: 0.00, writes: 47626.92, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1212s] threads: 64, tps: 0.00, reads: 0.00, writes: 50737.04, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1213s] threads: 64, tps: 0.00, reads: 0.00, writes: 50312.99, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1214s] threads: 64, tps: 0.00, reads: 0.00, writes: 49960.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1215s] threads: 64, tps: 0.00, reads: 0.00, writes: 49279.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1216s] threads: 64, tps: 0.00, reads: 0.00, writes: 50589.89, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1217s] threads: 64, tps: 0.00, reads: 0.00, writes: 50581.06, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1218s] threads: 64, tps: 0.00, reads: 0.00, writes: 49864.01, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1219s] threads: 64, tps: 0.00, reads: 0.00, writes: 50130.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1220s] threads: 64, tps: 0.00, reads: 0.00, writes: 49395.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1221s] threads: 64, tps: 0.00, reads: 0.00, writes: 51035.94, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1222s] threads: 64, tps: 0.00, reads: 0.00, writes: 49766.86, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1223s] threads: 64, tps: 0.00, reads: 0.00, writes: 49415.20, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1224s] threads: 64, tps: 0.00, reads: 0.00, writes: 49487.05, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1225s] threads: 64, tps: 0.00, reads: 0.00, writes: 50288.87, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1226s] threads: 64, tps: 0.00, reads: 0.00, writes: 49648.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1227s] threads: 64, tps: 0.00, reads: 0.00, writes: 49583.07, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1228s] threads: 64, tps: 0.00, reads: 0.00, writes: 49715.75, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1229s] threads: 64, tps: 0.00, reads: 0.00, writes: 48797.27, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1230s] threads: 64, tps: 0.00, reads: 0.00, writes: 49450.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1231s] threads: 64, tps: 0.00, reads: 0.00, writes: 49055.95, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1232s] threads: 64, tps: 0.00, reads: 0.00, writes: 47195.01, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1233s] threads: 64, tps: 0.00, reads: 0.00, writes: 47142.87, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1234s] threads: 64, tps: 0.00, reads: 0.00, writes: 41174.08, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1235s] threads: 64, tps: 0.00, reads: 0.00, writes: 42184.00, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1236s] threads: 64, tps: 0.00, reads: 0.00, writes: 31895.06, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1237s] threads: 64, tps: 0.00, reads: 0.00, writes: 33249.81, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[1238s] threads: 64, tps: 0.00, reads: 0.00, writes: 34694.19, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1239s] threads: 64, tps: 0.00, reads: 0.00, writes: 38258.91, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1240s] threads: 64, tps: 0.00, reads: 0.00, writes: 47036.10, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1241s] threads: 64, tps: 0.00, reads: 0.00, writes: 48187.02, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1242s] threads: 64, tps: 0.00, reads: 0.00, writes: 24560.24, response time: 19.18ms (95%), errors: 0.00, reconnects:  0.00
[1243s] threads: 64, tps: 0.00, reads: 0.00, writes: 3238.08, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[1244s] threads: 64, tps: 0.00, reads: 0.00, writes: 3222.01, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[1245s] threads: 64, tps: 0.00, reads: 0.00, writes: 3246.95, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[1246s] threads: 64, tps: 0.00, reads: 0.00, writes: 3219.00, response time: 20.72ms (95%), errors: 0.00, reconnects:  0.00
[1247s] threads: 64, tps: 0.00, reads: 0.00, writes: 3243.90, response time: 20.54ms (95%), errors: 0.00, reconnects:  0.00
[1248s] threads: 64, tps: 0.00, reads: 0.00, writes: 3236.09, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[1249s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.03, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[1250s] threads: 64, tps: 0.00, reads: 0.00, writes: 18878.21, response time: 19.75ms (95%), errors: 0.00, reconnects:  0.00
[1251s] threads: 64, tps: 0.00, reads: 0.00, writes: 33159.96, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1252s] threads: 64, tps: 0.00, reads: 0.00, writes: 41043.18, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1253s] threads: 64, tps: 0.00, reads: 0.00, writes: 48684.04, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1254s] threads: 64, tps: 0.00, reads: 0.00, writes: 46419.91, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1255s] threads: 64, tps: 0.00, reads: 0.00, writes: 49699.14, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1256s] threads: 64, tps: 0.00, reads: 0.00, writes: 50065.88, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1257s] threads: 64, tps: 0.00, reads: 0.00, writes: 49983.07, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1258s] threads: 64, tps: 0.00, reads: 0.00, writes: 50431.01, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1259s] threads: 64, tps: 0.00, reads: 0.00, writes: 49689.02, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1260s] threads: 64, tps: 0.00, reads: 0.00, writes: 49012.96, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1261s] threads: 64, tps: 0.00, reads: 0.00, writes: 50249.92, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1262s] threads: 64, tps: 0.00, reads: 0.00, writes: 51970.13, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1263s] threads: 64, tps: 0.00, reads: 0.00, writes: 50173.86, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1264s] threads: 64, tps: 0.00, reads: 0.00, writes: 49675.80, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1265s] threads: 64, tps: 0.00, reads: 0.00, writes: 50601.13, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1266s] threads: 64, tps: 0.00, reads: 0.00, writes: 49919.26, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1267s] threads: 64, tps: 0.00, reads: 0.00, writes: 50788.96, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1268s] threads: 64, tps: 0.00, reads: 0.00, writes: 49983.89, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1269s] threads: 64, tps: 0.00, reads: 0.00, writes: 48921.05, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1270s] threads: 64, tps: 0.00, reads: 0.00, writes: 47623.57, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1271s] threads: 64, tps: 0.00, reads: 0.00, writes: 48328.49, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1272s] threads: 64, tps: 0.00, reads: 0.00, writes: 47918.94, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1273s] threads: 64, tps: 0.00, reads: 0.00, writes: 47268.07, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1274s] threads: 64, tps: 0.00, reads: 0.00, writes: 35031.01, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1275s] threads: 64, tps: 0.00, reads: 0.00, writes: 33826.74, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1276s] threads: 64, tps: 0.00, reads: 0.00, writes: 38175.60, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1277s] threads: 64, tps: 0.00, reads: 0.00, writes: 45580.35, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1278s] threads: 64, tps: 0.00, reads: 0.00, writes: 35586.52, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1279s] threads: 64, tps: 0.00, reads: 0.00, writes: 33280.53, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1280s] threads: 64, tps: 0.00, reads: 0.00, writes: 35723.98, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1281s] threads: 64, tps: 0.00, reads: 0.00, writes: 35269.02, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1282s] threads: 64, tps: 0.00, reads: 0.00, writes: 39715.91, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1283s] threads: 64, tps: 0.00, reads: 0.00, writes: 47229.15, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1284s] threads: 64, tps: 0.00, reads: 0.00, writes: 46539.91, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1285s] threads: 64, tps: 0.00, reads: 0.00, writes: 44288.02, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1286s] threads: 64, tps: 0.00, reads: 0.00, writes: 43904.95, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1287s] threads: 64, tps: 0.00, reads: 0.00, writes: 43666.01, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1288s] threads: 64, tps: 0.00, reads: 0.00, writes: 48360.05, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1289s] threads: 64, tps: 0.00, reads: 0.00, writes: 42639.95, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1290s] threads: 64, tps: 0.00, reads: 0.00, writes: 44793.04, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1291s] threads: 64, tps: 0.00, reads: 0.00, writes: 42937.84, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1292s] threads: 64, tps: 0.00, reads: 0.00, writes: 44637.05, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1293s] threads: 64, tps: 0.00, reads: 0.00, writes: 46178.17, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1294s] threads: 64, tps: 0.00, reads: 0.00, writes: 38734.95, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[1295s] threads: 64, tps: 0.00, reads: 0.00, writes: 40576.96, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1296s] threads: 64, tps: 0.00, reads: 0.00, writes: 44364.11, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1297s] threads: 64, tps: 0.00, reads: 0.00, writes: 46811.89, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1298s] threads: 64, tps: 0.00, reads: 0.00, writes: 50509.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1299s] threads: 64, tps: 0.00, reads: 0.00, writes: 47661.97, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1300s] threads: 64, tps: 0.00, reads: 0.00, writes: 47653.66, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1301s] threads: 64, tps: 0.00, reads: 0.00, writes: 48485.53, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1302s] threads: 64, tps: 0.00, reads: 0.00, writes: 48595.96, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1303s] threads: 64, tps: 0.00, reads: 0.00, writes: 49985.00, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1304s] threads: 64, tps: 0.00, reads: 0.00, writes: 49746.80, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1305s] threads: 64, tps: 0.00, reads: 0.00, writes: 45896.13, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1306s] threads: 64, tps: 0.00, reads: 0.00, writes: 50618.04, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1307s] threads: 64, tps: 0.00, reads: 0.00, writes: 49776.96, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1308s] threads: 64, tps: 0.00, reads: 0.00, writes: 50211.02, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1309s] threads: 64, tps: 0.00, reads: 0.00, writes: 49829.99, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1310s] threads: 64, tps: 0.00, reads: 0.00, writes: 48965.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1311s] threads: 64, tps: 0.00, reads: 0.00, writes: 49850.08, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1312s] threads: 64, tps: 0.00, reads: 0.00, writes: 50183.93, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1313s] threads: 64, tps: 0.00, reads: 0.00, writes: 48118.04, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1314s] threads: 64, tps: 0.00, reads: 0.00, writes: 48952.93, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1315s] threads: 64, tps: 0.00, reads: 0.00, writes: 47724.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1316s] threads: 64, tps: 0.00, reads: 0.00, writes: 48896.01, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1317s] threads: 64, tps: 0.00, reads: 0.00, writes: 46972.97, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1318s] threads: 64, tps: 0.00, reads: 0.00, writes: 46706.26, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1319s] threads: 64, tps: 0.00, reads: 0.00, writes: 45299.64, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1320s] threads: 64, tps: 0.00, reads: 0.00, writes: 43018.14, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1321s] threads: 64, tps: 0.00, reads: 0.00, writes: 47953.03, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1322s] threads: 64, tps: 0.00, reads: 0.00, writes: 45111.99, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1323s] threads: 64, tps: 0.00, reads: 0.00, writes: 44352.98, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1324s] threads: 64, tps: 0.00, reads: 0.00, writes: 43463.01, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1325s] threads: 64, tps: 0.00, reads: 0.00, writes: 43578.95, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1326s] threads: 64, tps: 0.00, reads: 0.00, writes: 46493.05, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1327s] threads: 64, tps: 0.00, reads: 0.00, writes: 45116.99, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1328s] threads: 64, tps: 0.00, reads: 0.00, writes: 14398.74, response time: 20.19ms (95%), errors: 0.00, reconnects:  0.00
[1329s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.03, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[1330s] threads: 64, tps: 0.00, reads: 0.00, writes: 3213.89, response time: 20.69ms (95%), errors: 0.00, reconnects:  0.00
[1331s] threads: 64, tps: 0.00, reads: 0.00, writes: 4679.19, response time: 20.48ms (95%), errors: 0.00, reconnects:  0.00
[1332s] threads: 64, tps: 0.00, reads: 0.00, writes: 34743.07, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1333s] threads: 64, tps: 0.00, reads: 0.00, writes: 35565.02, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1334s] threads: 64, tps: 0.00, reads: 0.00, writes: 43214.83, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1335s] threads: 64, tps: 0.00, reads: 0.00, writes: 49586.66, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1336s] threads: 64, tps: 0.00, reads: 0.00, writes: 46173.19, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1337s] threads: 64, tps: 0.00, reads: 0.00, writes: 47947.39, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1338s] threads: 64, tps: 0.00, reads: 0.00, writes: 48361.65, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1339s] threads: 64, tps: 0.00, reads: 0.00, writes: 49956.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1340s] threads: 64, tps: 0.00, reads: 0.00, writes: 51794.01, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1341s] threads: 64, tps: 0.00, reads: 0.00, writes: 50121.04, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1342s] threads: 64, tps: 0.00, reads: 0.00, writes: 50610.93, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1343s] threads: 64, tps: 0.00, reads: 0.00, writes: 50017.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1344s] threads: 64, tps: 0.00, reads: 0.00, writes: 49853.94, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1345s] threads: 64, tps: 0.00, reads: 0.00, writes: 50594.18, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1346s] threads: 64, tps: 0.00, reads: 0.00, writes: 49621.89, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1347s] threads: 64, tps: 0.00, reads: 0.00, writes: 49263.97, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1348s] threads: 64, tps: 0.00, reads: 0.00, writes: 48490.07, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1349s] threads: 64, tps: 0.00, reads: 0.00, writes: 49022.97, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1350s] threads: 64, tps: 0.00, reads: 0.00, writes: 49196.99, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1351s] threads: 64, tps: 0.00, reads: 0.00, writes: 49366.05, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1352s] threads: 64, tps: 0.00, reads: 0.00, writes: 48729.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1353s] threads: 64, tps: 0.00, reads: 0.00, writes: 50072.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1354s] threads: 64, tps: 0.00, reads: 0.00, writes: 50544.03, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1355s] threads: 64, tps: 0.00, reads: 0.00, writes: 48905.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1356s] threads: 64, tps: 0.00, reads: 0.00, writes: 48868.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1357s] threads: 64, tps: 0.00, reads: 0.00, writes: 47596.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1358s] threads: 64, tps: 0.00, reads: 0.00, writes: 47636.05, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1359s] threads: 64, tps: 0.00, reads: 0.00, writes: 46253.80, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1360s] threads: 64, tps: 0.00, reads: 0.00, writes: 35317.13, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1361s] threads: 64, tps: 0.00, reads: 0.00, writes: 32994.23, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1362s] threads: 64, tps: 0.00, reads: 0.00, writes: 33347.81, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1363s] threads: 64, tps: 0.00, reads: 0.00, writes: 42238.00, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1364s] threads: 64, tps: 0.00, reads: 0.00, writes: 45299.95, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1365s] threads: 64, tps: 0.00, reads: 0.00, writes: 39088.06, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1366s] threads: 64, tps: 0.00, reads: 0.00, writes: 41591.95, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1367s] threads: 64, tps: 0.00, reads: 0.00, writes: 42994.02, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1368s] threads: 64, tps: 0.00, reads: 0.00, writes: 34958.01, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[1369s] threads: 64, tps: 0.00, reads: 0.00, writes: 48335.92, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1370s] threads: 64, tps: 0.00, reads: 0.00, writes: 46372.06, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1371s] threads: 64, tps: 0.00, reads: 0.00, writes: 3223.00, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[1372s] threads: 64, tps: 0.00, reads: 0.00, writes: 3243.99, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[1373s] threads: 64, tps: 0.00, reads: 0.00, writes: 3226.00, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[1374s] threads: 64, tps: 0.00, reads: 0.00, writes: 3237.96, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[1375s] threads: 64, tps: 0.00, reads: 0.00, writes: 3224.00, response time: 20.58ms (95%), errors: 0.00, reconnects:  0.00
[1376s] threads: 64, tps: 0.00, reads: 0.00, writes: 3236.05, response time: 20.69ms (95%), errors: 0.00, reconnects:  0.00
[1377s] threads: 64, tps: 0.00, reads: 0.00, writes: 35579.13, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1378s] threads: 64, tps: 0.00, reads: 0.00, writes: 40000.05, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1379s] threads: 64, tps: 0.00, reads: 0.00, writes: 42824.96, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1380s] threads: 64, tps: 0.00, reads: 0.00, writes: 47256.06, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1381s] threads: 64, tps: 0.00, reads: 0.00, writes: 48286.97, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1382s] threads: 64, tps: 0.00, reads: 0.00, writes: 49555.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1383s] threads: 64, tps: 0.00, reads: 0.00, writes: 49526.77, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1384s] threads: 64, tps: 0.00, reads: 0.00, writes: 49146.28, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1385s] threads: 64, tps: 0.00, reads: 0.00, writes: 51329.94, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1386s] threads: 64, tps: 0.00, reads: 0.00, writes: 50838.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1387s] threads: 64, tps: 0.00, reads: 0.00, writes: 50124.90, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1388s] threads: 64, tps: 0.00, reads: 0.00, writes: 49657.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1389s] threads: 64, tps: 0.00, reads: 0.00, writes: 51077.06, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1390s] threads: 64, tps: 0.00, reads: 0.00, writes: 49699.87, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1391s] threads: 64, tps: 0.00, reads: 0.00, writes: 49463.12, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1392s] threads: 64, tps: 0.00, reads: 0.00, writes: 50108.03, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1393s] threads: 64, tps: 0.00, reads: 0.00, writes: 50870.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1394s] threads: 64, tps: 0.00, reads: 0.00, writes: 51202.02, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1395s] threads: 64, tps: 0.00, reads: 0.00, writes: 48946.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1396s] threads: 64, tps: 0.00, reads: 0.00, writes: 48974.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1397s] threads: 64, tps: 0.00, reads: 0.00, writes: 46723.03, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1398s] threads: 64, tps: 0.00, reads: 0.00, writes: 50080.90, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1399s] threads: 64, tps: 0.00, reads: 0.00, writes: 49388.90, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1400s] threads: 64, tps: 0.00, reads: 0.00, writes: 44319.44, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1401s] threads: 64, tps: 0.00, reads: 0.00, writes: 34176.62, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1402s] threads: 64, tps: 0.00, reads: 0.00, writes: 34056.93, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1403s] threads: 64, tps: 0.00, reads: 0.00, writes: 37668.97, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1404s] threads: 64, tps: 0.00, reads: 0.00, writes: 40845.05, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1405s] threads: 64, tps: 0.00, reads: 0.00, writes: 33812.82, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1406s] threads: 64, tps: 0.00, reads: 0.00, writes: 33150.00, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1407s] threads: 64, tps: 0.00, reads: 0.00, writes: 38634.04, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[1408s] threads: 64, tps: 0.00, reads: 0.00, writes: 42857.94, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1409s] threads: 64, tps: 0.00, reads: 0.00, writes: 47127.96, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1410s] threads: 64, tps: 0.00, reads: 0.00, writes: 48364.05, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1411s] threads: 64, tps: 0.00, reads: 0.00, writes: 43377.95, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1412s] threads: 64, tps: 0.00, reads: 0.00, writes: 37521.08, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1413s] threads: 64, tps: 0.00, reads: 0.00, writes: 44067.97, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1414s] threads: 64, tps: 0.00, reads: 0.00, writes: 48190.94, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1415s] threads: 64, tps: 0.00, reads: 0.00, writes: 48150.05, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1416s] threads: 64, tps: 0.00, reads: 0.00, writes: 43497.03, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1417s] threads: 64, tps: 0.00, reads: 0.00, writes: 43232.91, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[1418s] threads: 64, tps: 0.00, reads: 0.00, writes: 38080.10, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1419s] threads: 64, tps: 0.00, reads: 0.00, writes: 42519.00, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1420s] threads: 64, tps: 0.00, reads: 0.00, writes: 44418.94, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1421s] threads: 64, tps: 0.00, reads: 0.00, writes: 41176.97, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1422s] threads: 64, tps: 0.00, reads: 0.00, writes: 46847.93, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1423s] threads: 64, tps: 0.00, reads: 0.00, writes: 49078.20, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1424s] threads: 64, tps: 0.00, reads: 0.00, writes: 50775.74, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1425s] threads: 64, tps: 0.00, reads: 0.00, writes: 50208.18, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1426s] threads: 64, tps: 0.00, reads: 0.00, writes: 47556.13, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1427s] threads: 64, tps: 0.00, reads: 0.00, writes: 49037.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1428s] threads: 64, tps: 0.00, reads: 0.00, writes: 47890.00, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1429s] threads: 64, tps: 0.00, reads: 0.00, writes: 48998.94, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1430s] threads: 64, tps: 0.00, reads: 0.00, writes: 49483.06, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1431s] threads: 64, tps: 0.00, reads: 0.00, writes: 48955.95, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1432s] threads: 64, tps: 0.00, reads: 0.00, writes: 49637.03, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1433s] threads: 64, tps: 0.00, reads: 0.00, writes: 49082.07, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1434s] threads: 64, tps: 0.00, reads: 0.00, writes: 50765.93, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1435s] threads: 64, tps: 0.00, reads: 0.00, writes: 50257.07, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1436s] threads: 64, tps: 0.00, reads: 0.00, writes: 48990.90, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1437s] threads: 64, tps: 0.00, reads: 0.00, writes: 49078.01, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1438s] threads: 64, tps: 0.00, reads: 0.00, writes: 50668.03, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1439s] threads: 64, tps: 0.00, reads: 0.00, writes: 48357.00, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1440s] threads: 64, tps: 0.00, reads: 0.00, writes: 46745.96, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1441s] threads: 64, tps: 0.00, reads: 0.00, writes: 36823.98, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1442s] threads: 64, tps: 0.00, reads: 0.00, writes: 33158.42, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1443s] threads: 64, tps: 0.00, reads: 0.00, writes: 44064.70, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1444s] threads: 64, tps: 0.00, reads: 0.00, writes: 39395.11, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1445s] threads: 64, tps: 0.00, reads: 0.00, writes: 33081.03, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1446s] threads: 64, tps: 0.00, reads: 0.00, writes: 37128.03, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[1447s] threads: 64, tps: 0.00, reads: 0.00, writes: 43627.71, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1448s] threads: 64, tps: 0.00, reads: 0.00, writes: 45447.18, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1449s] threads: 64, tps: 0.00, reads: 0.00, writes: 48498.05, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1450s] threads: 64, tps: 0.00, reads: 0.00, writes: 40690.95, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1451s] threads: 64, tps: 0.00, reads: 0.00, writes: 41514.03, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1452s] threads: 64, tps: 0.00, reads: 0.00, writes: 43643.99, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1453s] threads: 64, tps: 0.00, reads: 0.00, writes: 44285.09, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1454s] threads: 64, tps: 0.00, reads: 0.00, writes: 47672.93, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1455s] threads: 64, tps: 0.00, reads: 0.00, writes: 43308.93, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1456s] threads: 64, tps: 0.00, reads: 0.00, writes: 3214.00, response time: 20.74ms (95%), errors: 0.00, reconnects:  0.00
[1457s] threads: 64, tps: 0.00, reads: 0.00, writes: 3238.95, response time: 20.72ms (95%), errors: 0.00, reconnects:  0.00
[1458s] threads: 64, tps: 0.00, reads: 0.00, writes: 21440.34, response time: 19.21ms (95%), errors: 0.00, reconnects:  0.00
[1459s] threads: 64, tps: 0.00, reads: 0.00, writes: 37706.04, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[1460s] threads: 64, tps: 0.00, reads: 0.00, writes: 37843.98, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1461s] threads: 64, tps: 0.00, reads: 0.00, writes: 45528.96, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1462s] threads: 64, tps: 0.00, reads: 0.00, writes: 46797.77, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1463s] threads: 64, tps: 0.00, reads: 0.00, writes: 42610.25, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1464s] threads: 64, tps: 0.00, reads: 0.00, writes: 42357.03, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1465s] threads: 64, tps: 0.00, reads: 0.00, writes: 43061.02, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1466s] threads: 64, tps: 0.00, reads: 0.00, writes: 46372.92, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1467s] threads: 64, tps: 0.00, reads: 0.00, writes: 48182.98, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1468s] threads: 64, tps: 0.00, reads: 0.00, writes: 44207.09, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1469s] threads: 64, tps: 0.00, reads: 0.00, writes: 45172.98, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1470s] threads: 64, tps: 0.00, reads: 0.00, writes: 48191.99, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1471s] threads: 64, tps: 0.00, reads: 0.00, writes: 50078.45, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1472s] threads: 64, tps: 0.00, reads: 0.00, writes: 49661.53, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1473s] threads: 64, tps: 0.00, reads: 0.00, writes: 49110.98, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1474s] threads: 64, tps: 0.00, reads: 0.00, writes: 47779.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1475s] threads: 64, tps: 0.00, reads: 0.00, writes: 49828.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1476s] threads: 64, tps: 0.00, reads: 0.00, writes: 50928.09, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1477s] threads: 64, tps: 0.00, reads: 0.00, writes: 48374.83, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1478s] threads: 64, tps: 0.00, reads: 0.00, writes: 49133.05, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1479s] threads: 64, tps: 0.00, reads: 0.00, writes: 49167.96, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1480s] threads: 64, tps: 0.00, reads: 0.00, writes: 49706.10, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1481s] threads: 64, tps: 0.00, reads: 0.00, writes: 50413.60, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1482s] threads: 64, tps: 0.00, reads: 0.00, writes: 49380.42, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1483s] threads: 64, tps: 0.00, reads: 0.00, writes: 47631.99, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1484s] threads: 64, tps: 0.00, reads: 0.00, writes: 48441.97, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1485s] threads: 64, tps: 0.00, reads: 0.00, writes: 48091.20, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1486s] threads: 64, tps: 0.00, reads: 0.00, writes: 49540.83, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1487s] threads: 64, tps: 0.00, reads: 0.00, writes: 48493.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1488s] threads: 64, tps: 0.00, reads: 0.00, writes: 48070.98, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1489s] threads: 64, tps: 0.00, reads: 0.00, writes: 47117.98, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1490s] threads: 64, tps: 0.00, reads: 0.00, writes: 42060.06, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1491s] threads: 64, tps: 0.00, reads: 0.00, writes: 47178.96, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1492s] threads: 64, tps: 0.00, reads: 0.00, writes: 41272.04, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1493s] threads: 64, tps: 0.00, reads: 0.00, writes: 43356.95, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1494s] threads: 64, tps: 0.00, reads: 0.00, writes: 42421.00, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1495s] threads: 64, tps: 0.00, reads: 0.00, writes: 47622.98, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1496s] threads: 64, tps: 0.00, reads: 0.00, writes: 46760.03, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1497s] threads: 64, tps: 0.00, reads: 0.00, writes: 9654.97, response time: 20.30ms (95%), errors: 0.00, reconnects:  0.00
[1498s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.00, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[1499s] threads: 64, tps: 0.00, reads: 0.00, writes: 3225.90, response time: 20.54ms (95%), errors: 0.00, reconnects:  0.00
[1500s] threads: 64, tps: 0.00, reads: 0.00, writes: 3245.10, response time: 20.65ms (95%), errors: 0.00, reconnects:  0.00
[1501s] threads: 64, tps: 0.00, reads: 0.00, writes: 4819.02, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[1502s] threads: 64, tps: 0.00, reads: 0.00, writes: 34975.04, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1503s] threads: 64, tps: 0.00, reads: 0.00, writes: 36623.01, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[1504s] threads: 64, tps: 0.00, reads: 0.00, writes: 41202.02, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1505s] threads: 64, tps: 0.00, reads: 0.00, writes: 47132.00, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1506s] threads: 64, tps: 0.00, reads: 0.00, writes: 44265.97, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1507s] threads: 64, tps: 0.00, reads: 0.00, writes: 44187.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1508s] threads: 64, tps: 0.00, reads: 0.00, writes: 50180.77, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1509s] threads: 64, tps: 0.00, reads: 0.00, writes: 50136.22, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1510s] threads: 64, tps: 0.00, reads: 0.00, writes: 50210.01, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1511s] threads: 64, tps: 0.00, reads: 0.00, writes: 50437.98, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1512s] threads: 64, tps: 0.00, reads: 0.00, writes: 49560.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1513s] threads: 64, tps: 0.00, reads: 0.00, writes: 49188.65, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1514s] threads: 64, tps: 0.00, reads: 0.00, writes: 51214.76, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1515s] threads: 64, tps: 0.00, reads: 0.00, writes: 48824.02, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1516s] threads: 64, tps: 0.00, reads: 0.00, writes: 49856.05, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1517s] threads: 64, tps: 0.00, reads: 0.00, writes: 49187.97, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1518s] threads: 64, tps: 0.00, reads: 0.00, writes: 48463.94, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1519s] threads: 64, tps: 0.00, reads: 0.00, writes: 50367.05, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1520s] threads: 64, tps: 0.00, reads: 0.00, writes: 49593.95, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1521s] threads: 64, tps: 0.00, reads: 0.00, writes: 49166.97, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1522s] threads: 64, tps: 0.00, reads: 0.00, writes: 49689.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1523s] threads: 64, tps: 0.00, reads: 0.00, writes: 48850.07, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1524s] threads: 64, tps: 0.00, reads: 0.00, writes: 49347.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1525s] threads: 64, tps: 0.00, reads: 0.00, writes: 49560.96, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1526s] threads: 64, tps: 0.00, reads: 0.00, writes: 46634.06, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1527s] threads: 64, tps: 0.00, reads: 0.00, writes: 48446.99, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1528s] threads: 64, tps: 0.00, reads: 0.00, writes: 46746.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1529s] threads: 64, tps: 0.00, reads: 0.00, writes: 47232.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1530s] threads: 64, tps: 0.00, reads: 0.00, writes: 37674.00, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1531s] threads: 64, tps: 0.00, reads: 0.00, writes: 36929.00, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1532s] threads: 64, tps: 0.00, reads: 0.00, writes: 33709.97, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1533s] threads: 64, tps: 0.00, reads: 0.00, writes: 36145.03, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1534s] threads: 64, tps: 0.00, reads: 0.00, writes: 43759.96, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1535s] threads: 64, tps: 0.00, reads: 0.00, writes: 32349.99, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[1536s] threads: 64, tps: 0.00, reads: 0.00, writes: 39802.96, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1537s] threads: 64, tps: 0.00, reads: 0.00, writes: 44451.63, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1538s] threads: 64, tps: 0.00, reads: 0.00, writes: 43943.41, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1539s] threads: 64, tps: 0.00, reads: 0.00, writes: 48314.99, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1540s] threads: 64, tps: 0.00, reads: 0.00, writes: 47362.99, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1541s] threads: 64, tps: 0.00, reads: 0.00, writes: 7684.97, response time: 20.51ms (95%), errors: 0.00, reconnects:  0.00
[1542s] threads: 64, tps: 0.00, reads: 0.00, writes: 3242.95, response time: 20.58ms (95%), errors: 0.00, reconnects:  0.00
[1543s] threads: 64, tps: 0.00, reads: 0.00, writes: 3220.05, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[1544s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.99, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[1545s] threads: 64, tps: 0.00, reads: 0.00, writes: 3229.95, response time: 20.39ms (95%), errors: 0.00, reconnects:  0.00
[1546s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.04, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[1547s] threads: 64, tps: 0.00, reads: 0.00, writes: 17211.09, response time: 19.73ms (95%), errors: 0.00, reconnects:  0.00
[1548s] threads: 64, tps: 0.00, reads: 0.00, writes: 34159.01, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1549s] threads: 64, tps: 0.00, reads: 0.00, writes: 40845.97, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1550s] threads: 64, tps: 0.00, reads: 0.00, writes: 49568.94, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1551s] threads: 64, tps: 0.00, reads: 0.00, writes: 48728.09, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1552s] threads: 64, tps: 0.00, reads: 0.00, writes: 49779.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1553s] threads: 64, tps: 0.00, reads: 0.00, writes: 49062.97, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1554s] threads: 64, tps: 0.00, reads: 0.00, writes: 45772.00, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1555s] threads: 64, tps: 0.00, reads: 0.00, writes: 51711.95, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1556s] threads: 64, tps: 0.00, reads: 0.00, writes: 49878.09, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1557s] threads: 64, tps: 0.00, reads: 0.00, writes: 49655.75, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1558s] threads: 64, tps: 0.00, reads: 0.00, writes: 49091.19, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1559s] threads: 64, tps: 0.00, reads: 0.00, writes: 50316.94, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1560s] threads: 64, tps: 0.00, reads: 0.00, writes: 51124.07, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1561s] threads: 64, tps: 0.00, reads: 0.00, writes: 50141.89, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1562s] threads: 64, tps: 0.00, reads: 0.00, writes: 49960.13, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1563s] threads: 64, tps: 0.00, reads: 0.00, writes: 50128.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1564s] threads: 64, tps: 0.00, reads: 0.00, writes: 50002.02, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1565s] threads: 64, tps: 0.00, reads: 0.00, writes: 49977.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1566s] threads: 64, tps: 0.00, reads: 0.00, writes: 46596.54, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1567s] threads: 64, tps: 0.00, reads: 0.00, writes: 47818.51, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1568s] threads: 64, tps: 0.00, reads: 0.00, writes: 48981.94, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1569s] threads: 64, tps: 0.00, reads: 0.00, writes: 46062.08, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1570s] threads: 64, tps: 0.00, reads: 0.00, writes: 38909.97, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[1571s] threads: 64, tps: 0.00, reads: 0.00, writes: 33342.96, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1572s] threads: 64, tps: 0.00, reads: 0.00, writes: 34437.09, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1573s] threads: 64, tps: 0.00, reads: 0.00, writes: 32190.94, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1574s] threads: 64, tps: 0.00, reads: 0.00, writes: 45818.59, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1575s] threads: 64, tps: 0.00, reads: 0.00, writes: 40360.35, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[1576s] threads: 64, tps: 0.00, reads: 0.00, writes: 33517.01, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1577s] threads: 64, tps: 0.00, reads: 0.00, writes: 34966.07, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1578s] threads: 64, tps: 0.00, reads: 0.00, writes: 32702.01, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1579s] threads: 64, tps: 0.00, reads: 0.00, writes: 43915.97, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1580s] threads: 64, tps: 0.00, reads: 0.00, writes: 47371.05, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1581s] threads: 64, tps: 0.00, reads: 0.00, writes: 47418.02, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1582s] threads: 64, tps: 0.00, reads: 0.00, writes: 41660.97, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1583s] threads: 64, tps: 0.00, reads: 0.00, writes: 43865.98, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1584s] threads: 64, tps: 0.00, reads: 0.00, writes: 43278.03, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1585s] threads: 64, tps: 0.00, reads: 0.00, writes: 47547.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1586s] threads: 64, tps: 0.00, reads: 0.00, writes: 47527.87, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1587s] threads: 64, tps: 0.00, reads: 0.00, writes: 43591.13, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1588s] threads: 64, tps: 0.00, reads: 0.00, writes: 44850.98, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1589s] threads: 64, tps: 0.00, reads: 0.00, writes: 34410.99, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1590s] threads: 64, tps: 0.00, reads: 0.00, writes: 44380.94, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1591s] threads: 64, tps: 0.00, reads: 0.00, writes: 41116.23, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1592s] threads: 64, tps: 0.00, reads: 0.00, writes: 41124.86, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1593s] threads: 64, tps: 0.00, reads: 0.00, writes: 47994.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1594s] threads: 64, tps: 0.00, reads: 0.00, writes: 48519.97, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1595s] threads: 64, tps: 0.00, reads: 0.00, writes: 49997.05, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1596s] threads: 64, tps: 0.00, reads: 0.00, writes: 51014.01, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1597s] threads: 64, tps: 0.00, reads: 0.00, writes: 48123.31, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1598s] threads: 64, tps: 0.00, reads: 0.00, writes: 49710.08, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1599s] threads: 64, tps: 0.00, reads: 0.00, writes: 49449.48, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1600s] threads: 64, tps: 0.00, reads: 0.00, writes: 50382.10, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1601s] threads: 64, tps: 0.00, reads: 0.00, writes: 47893.00, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1602s] threads: 64, tps: 0.00, reads: 0.00, writes: 49330.08, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1603s] threads: 64, tps: 0.00, reads: 0.00, writes: 49053.93, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1604s] threads: 64, tps: 0.00, reads: 0.00, writes: 50023.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1605s] threads: 64, tps: 0.00, reads: 0.00, writes: 50534.06, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1606s] threads: 64, tps: 0.00, reads: 0.00, writes: 51059.97, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1607s] threads: 64, tps: 0.00, reads: 0.00, writes: 49213.99, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1608s] threads: 64, tps: 0.00, reads: 0.00, writes: 45585.06, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1609s] threads: 64, tps: 0.00, reads: 0.00, writes: 41827.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1610s] threads: 64, tps: 0.00, reads: 0.00, writes: 45714.91, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1611s] threads: 64, tps: 0.00, reads: 0.00, writes: 36124.04, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1612s] threads: 64, tps: 0.00, reads: 0.00, writes: 34503.99, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1613s] threads: 64, tps: 0.00, reads: 0.00, writes: 32101.99, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[1614s] threads: 64, tps: 0.00, reads: 0.00, writes: 36803.02, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1615s] threads: 64, tps: 0.00, reads: 0.00, writes: 46883.93, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1616s] threads: 64, tps: 0.00, reads: 0.00, writes: 36897.02, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1617s] threads: 64, tps: 0.00, reads: 0.00, writes: 37641.57, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1618s] threads: 64, tps: 0.00, reads: 0.00, writes: 42915.62, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1619s] threads: 64, tps: 0.00, reads: 0.00, writes: 44219.21, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1620s] threads: 64, tps: 0.00, reads: 0.00, writes: 47514.07, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1621s] threads: 64, tps: 0.00, reads: 0.00, writes: 47501.97, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1622s] threads: 64, tps: 0.00, reads: 0.00, writes: 44567.02, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1623s] threads: 64, tps: 0.00, reads: 0.00, writes: 41668.91, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1624s] threads: 64, tps: 0.00, reads: 0.00, writes: 43358.82, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1625s] threads: 64, tps: 0.00, reads: 0.00, writes: 46830.22, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1626s] threads: 64, tps: 0.00, reads: 0.00, writes: 47203.05, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1627s] threads: 64, tps: 0.00, reads: 0.00, writes: 12593.75, response time: 20.19ms (95%), errors: 0.00, reconnects:  0.00
[1628s] threads: 64, tps: 0.00, reads: 0.00, writes: 3225.05, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[1629s] threads: 64, tps: 0.00, reads: 0.00, writes: 25335.07, response time: 6.78ms (95%), errors: 0.00, reconnects:  0.00
[1630s] threads: 64, tps: 0.00, reads: 0.00, writes: 36232.95, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1631s] threads: 64, tps: 0.00, reads: 0.00, writes: 42110.02, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1632s] threads: 64, tps: 0.00, reads: 0.00, writes: 46513.94, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1633s] threads: 64, tps: 0.00, reads: 0.00, writes: 48910.13, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1634s] threads: 64, tps: 0.00, reads: 0.00, writes: 49238.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1635s] threads: 64, tps: 0.00, reads: 0.00, writes: 49751.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1636s] threads: 64, tps: 0.00, reads: 0.00, writes: 49630.01, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1637s] threads: 64, tps: 0.00, reads: 0.00, writes: 51253.95, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1638s] threads: 64, tps: 0.00, reads: 0.00, writes: 49817.05, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1639s] threads: 64, tps: 0.00, reads: 0.00, writes: 49990.14, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1640s] threads: 64, tps: 0.00, reads: 0.00, writes: 49914.79, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1641s] threads: 64, tps: 0.00, reads: 0.00, writes: 51635.01, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1642s] threads: 64, tps: 0.00, reads: 0.00, writes: 51252.08, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1643s] threads: 64, tps: 0.00, reads: 0.00, writes: 49211.87, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1644s] threads: 64, tps: 0.00, reads: 0.00, writes: 49162.13, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1645s] threads: 64, tps: 0.00, reads: 0.00, writes: 47283.98, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1646s] threads: 64, tps: 0.00, reads: 0.00, writes: 50899.97, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1647s] threads: 64, tps: 0.00, reads: 0.00, writes: 50396.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1648s] threads: 64, tps: 0.00, reads: 0.00, writes: 48271.08, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1649s] threads: 64, tps: 0.00, reads: 0.00, writes: 46016.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1650s] threads: 64, tps: 0.00, reads: 0.00, writes: 46264.97, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1651s] threads: 64, tps: 0.00, reads: 0.00, writes: 46803.05, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1652s] threads: 64, tps: 0.00, reads: 0.00, writes: 40600.97, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[1653s] threads: 64, tps: 0.00, reads: 0.00, writes: 35247.00, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1654s] threads: 64, tps: 0.00, reads: 0.00, writes: 34733.04, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1655s] threads: 64, tps: 0.00, reads: 0.00, writes: 33560.97, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1656s] threads: 64, tps: 0.00, reads: 0.00, writes: 40477.01, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1657s] threads: 64, tps: 0.00, reads: 0.00, writes: 38040.03, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[1658s] threads: 64, tps: 0.00, reads: 0.00, writes: 44272.96, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1659s] threads: 64, tps: 0.00, reads: 0.00, writes: 44731.47, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1660s] threads: 64, tps: 0.00, reads: 0.00, writes: 41554.45, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1661s] threads: 64, tps: 0.00, reads: 0.00, writes: 47015.98, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1662s] threads: 64, tps: 0.00, reads: 0.00, writes: 49045.13, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1663s] threads: 64, tps: 0.00, reads: 0.00, writes: 45524.68, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1664s] threads: 64, tps: 0.00, reads: 0.00, writes: 44953.23, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1665s] threads: 64, tps: 0.00, reads: 0.00, writes: 43343.04, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1666s] threads: 64, tps: 0.00, reads: 0.00, writes: 44694.98, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1667s] threads: 64, tps: 0.00, reads: 0.00, writes: 47586.04, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1668s] threads: 64, tps: 0.00, reads: 0.00, writes: 32980.11, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[1669s] threads: 64, tps: 0.00, reads: 0.00, writes: 13795.36, response time: 20.05ms (95%), errors: 0.00, reconnects:  0.00
[1670s] threads: 64, tps: 0.00, reads: 0.00, writes: 34635.02, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1671s] threads: 64, tps: 0.00, reads: 0.00, writes: 38885.01, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1672s] threads: 64, tps: 0.00, reads: 0.00, writes: 43338.99, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1673s] threads: 64, tps: 0.00, reads: 0.00, writes: 48711.03, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1674s] threads: 64, tps: 0.00, reads: 0.00, writes: 43132.92, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1675s] threads: 64, tps: 0.00, reads: 0.00, writes: 43585.00, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1676s] threads: 64, tps: 0.00, reads: 0.00, writes: 45752.07, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1677s] threads: 64, tps: 0.00, reads: 0.00, writes: 48878.01, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1678s] threads: 64, tps: 0.00, reads: 0.00, writes: 47736.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1679s] threads: 64, tps: 0.00, reads: 0.00, writes: 48481.99, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1680s] threads: 64, tps: 0.00, reads: 0.00, writes: 48066.96, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1681s] threads: 64, tps: 0.00, reads: 0.00, writes: 48995.06, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1682s] threads: 64, tps: 0.00, reads: 0.00, writes: 49743.99, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1683s] threads: 64, tps: 0.00, reads: 0.00, writes: 50706.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1684s] threads: 64, tps: 0.00, reads: 0.00, writes: 50271.02, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1685s] threads: 64, tps: 0.00, reads: 0.00, writes: 49995.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1686s] threads: 64, tps: 0.00, reads: 0.00, writes: 48951.96, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1687s] threads: 64, tps: 0.00, reads: 0.00, writes: 50688.05, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1688s] threads: 64, tps: 0.00, reads: 0.00, writes: 49958.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1689s] threads: 64, tps: 0.00, reads: 0.00, writes: 48751.05, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1690s] threads: 64, tps: 0.00, reads: 0.00, writes: 40256.01, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1691s] threads: 64, tps: 0.00, reads: 0.00, writes: 50336.66, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1692s] threads: 64, tps: 0.00, reads: 0.00, writes: 51227.34, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1693s] threads: 64, tps: 0.00, reads: 0.00, writes: 50106.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1694s] threads: 64, tps: 0.00, reads: 0.00, writes: 49448.97, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1695s] threads: 64, tps: 0.00, reads: 0.00, writes: 48907.02, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1696s] threads: 64, tps: 0.00, reads: 0.00, writes: 43888.99, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1697s] threads: 64, tps: 0.00, reads: 0.00, writes: 50734.00, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1698s] threads: 64, tps: 0.00, reads: 0.00, writes: 49467.46, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1699s] threads: 64, tps: 0.00, reads: 0.00, writes: 49138.51, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1700s] threads: 64, tps: 0.00, reads: 0.00, writes: 41714.02, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1701s] threads: 64, tps: 0.00, reads: 0.00, writes: 45995.98, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1702s] threads: 64, tps: 0.00, reads: 0.00, writes: 35838.03, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1703s] threads: 64, tps: 0.00, reads: 0.00, writes: 33127.99, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1704s] threads: 64, tps: 0.00, reads: 0.00, writes: 34531.87, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1705s] threads: 64, tps: 0.00, reads: 0.00, writes: 34947.37, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1706s] threads: 64, tps: 0.00, reads: 0.00, writes: 36846.05, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[1707s] threads: 64, tps: 0.00, reads: 0.00, writes: 47869.93, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1708s] threads: 64, tps: 0.00, reads: 0.00, writes: 47243.98, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1709s] threads: 64, tps: 0.00, reads: 0.00, writes: 12134.01, response time: 20.31ms (95%), errors: 0.00, reconnects:  0.00
[1710s] threads: 64, tps: 0.00, reads: 0.00, writes: 3237.00, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[1711s] threads: 64, tps: 0.00, reads: 0.00, writes: 3226.92, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[1712s] threads: 64, tps: 0.00, reads: 0.00, writes: 3242.08, response time: 20.50ms (95%), errors: 0.00, reconnects:  0.00
[1713s] threads: 64, tps: 0.00, reads: 0.00, writes: 3234.98, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[1714s] threads: 64, tps: 0.00, reads: 0.00, writes: 3218.01, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[1715s] threads: 64, tps: 0.00, reads: 0.00, writes: 3219.92, response time: 20.67ms (95%), errors: 0.00, reconnects:  0.00
[1716s] threads: 64, tps: 0.00, reads: 0.00, writes: 3247.08, response time: 20.77ms (95%), errors: 0.00, reconnects:  0.00
[1717s] threads: 64, tps: 0.00, reads: 0.00, writes: 11158.00, response time: 20.23ms (95%), errors: 0.00, reconnects:  0.00
[1718s] threads: 64, tps: 0.00, reads: 0.00, writes: 34861.05, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1719s] threads: 64, tps: 0.00, reads: 0.00, writes: 37621.00, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[1720s] threads: 64, tps: 0.00, reads: 0.00, writes: 43845.00, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1721s] threads: 64, tps: 0.00, reads: 0.00, writes: 41836.13, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1722s] threads: 64, tps: 0.00, reads: 0.00, writes: 38893.78, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1723s] threads: 64, tps: 0.00, reads: 0.00, writes: 42504.00, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1724s] threads: 64, tps: 0.00, reads: 0.00, writes: 42970.98, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1725s] threads: 64, tps: 0.00, reads: 0.00, writes: 46376.98, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1726s] threads: 64, tps: 0.00, reads: 0.00, writes: 45276.63, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1727s] threads: 64, tps: 0.00, reads: 0.00, writes: 44673.42, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1728s] threads: 64, tps: 0.00, reads: 0.00, writes: 43305.99, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1729s] threads: 64, tps: 0.00, reads: 0.00, writes: 45256.94, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1730s] threads: 64, tps: 0.00, reads: 0.00, writes: 41721.06, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1731s] threads: 64, tps: 0.00, reads: 0.00, writes: 47760.99, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1732s] threads: 64, tps: 0.00, reads: 0.00, writes: 45496.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1733s] threads: 64, tps: 0.00, reads: 0.00, writes: 46653.96, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1734s] threads: 64, tps: 0.00, reads: 0.00, writes: 49082.09, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1735s] threads: 64, tps: 0.00, reads: 0.00, writes: 50673.93, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1736s] threads: 64, tps: 0.00, reads: 0.00, writes: 49765.56, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1737s] threads: 64, tps: 0.00, reads: 0.00, writes: 50341.50, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1738s] threads: 64, tps: 0.00, reads: 0.00, writes: 49082.67, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1739s] threads: 64, tps: 0.00, reads: 0.00, writes: 50435.29, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1740s] threads: 64, tps: 0.00, reads: 0.00, writes: 50352.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1741s] threads: 64, tps: 0.00, reads: 0.00, writes: 49200.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1742s] threads: 64, tps: 0.00, reads: 0.00, writes: 49770.04, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1743s] threads: 64, tps: 0.00, reads: 0.00, writes: 36447.93, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1744s] threads: 64, tps: 0.00, reads: 0.00, writes: 50635.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1745s] threads: 64, tps: 0.00, reads: 0.00, writes: 50924.09, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1746s] threads: 64, tps: 0.00, reads: 0.00, writes: 50199.93, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1747s] threads: 64, tps: 0.00, reads: 0.00, writes: 49846.01, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1748s] threads: 64, tps: 0.00, reads: 0.00, writes: 49450.57, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1749s] threads: 64, tps: 0.00, reads: 0.00, writes: 50038.45, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1750s] threads: 64, tps: 0.00, reads: 0.00, writes: 50579.01, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1751s] threads: 64, tps: 0.00, reads: 0.00, writes: 48746.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1752s] threads: 64, tps: 0.00, reads: 0.00, writes: 46891.70, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1753s] threads: 64, tps: 0.00, reads: 0.00, writes: 35863.17, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1754s] threads: 64, tps: 0.00, reads: 0.00, writes: 46764.10, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1755s] threads: 64, tps: 0.00, reads: 0.00, writes: 36560.96, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1756s] threads: 64, tps: 0.00, reads: 0.00, writes: 31583.05, response time: 3.66ms (95%), errors: 0.00, reconnects:  0.00
[1757s] threads: 64, tps: 0.00, reads: 0.00, writes: 33916.01, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[1758s] threads: 64, tps: 0.00, reads: 0.00, writes: 33389.96, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1759s] threads: 64, tps: 0.00, reads: 0.00, writes: 42674.96, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1760s] threads: 64, tps: 0.00, reads: 0.00, writes: 49248.02, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1761s] threads: 64, tps: 0.00, reads: 0.00, writes: 48089.04, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1762s] threads: 64, tps: 0.00, reads: 0.00, writes: 8159.89, response time: 20.40ms (95%), errors: 0.00, reconnects:  0.00
[1763s] threads: 64, tps: 0.00, reads: 0.00, writes: 3236.04, response time: 20.63ms (95%), errors: 0.00, reconnects:  0.00
[1764s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.01, response time: 20.51ms (95%), errors: 0.00, reconnects:  0.00
[1765s] threads: 64, tps: 0.00, reads: 0.00, writes: 3227.99, response time: 20.43ms (95%), errors: 0.00, reconnects:  0.00
[1766s] threads: 64, tps: 0.00, reads: 0.00, writes: 3239.93, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[1767s] threads: 64, tps: 0.00, reads: 0.00, writes: 3236.08, response time: 20.48ms (95%), errors: 0.00, reconnects:  0.00
[1768s] threads: 64, tps: 0.00, reads: 0.00, writes: 3227.00, response time: 20.78ms (95%), errors: 0.00, reconnects:  0.00
[1769s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.00, response time: 20.72ms (95%), errors: 0.00, reconnects:  0.00
[1770s] threads: 64, tps: 0.00, reads: 0.00, writes: 12232.99, response time: 20.22ms (95%), errors: 0.00, reconnects:  0.00
[1771s] threads: 64, tps: 0.00, reads: 0.00, writes: 36055.03, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[1772s] threads: 64, tps: 0.00, reads: 0.00, writes: 38819.04, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[1773s] threads: 64, tps: 0.00, reads: 0.00, writes: 47604.99, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1774s] threads: 64, tps: 0.00, reads: 0.00, writes: 44771.00, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1775s] threads: 64, tps: 0.00, reads: 0.00, writes: 40007.97, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1776s] threads: 64, tps: 0.00, reads: 0.00, writes: 44184.07, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1777s] threads: 64, tps: 0.00, reads: 0.00, writes: 49215.26, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1778s] threads: 64, tps: 0.00, reads: 0.00, writes: 51322.73, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1779s] threads: 64, tps: 0.00, reads: 0.00, writes: 51206.06, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1780s] threads: 64, tps: 0.00, reads: 0.00, writes: 49734.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1781s] threads: 64, tps: 0.00, reads: 0.00, writes: 49838.88, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1782s] threads: 64, tps: 0.00, reads: 0.00, writes: 49524.82, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1783s] threads: 64, tps: 0.00, reads: 0.00, writes: 50283.22, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1784s] threads: 64, tps: 0.00, reads: 0.00, writes: 49730.07, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1785s] threads: 64, tps: 0.00, reads: 0.00, writes: 49852.41, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1786s] threads: 64, tps: 0.00, reads: 0.00, writes: 49603.58, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1787s] threads: 64, tps: 0.00, reads: 0.00, writes: 51111.96, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1788s] threads: 64, tps: 0.00, reads: 0.00, writes: 51395.95, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1789s] threads: 64, tps: 0.00, reads: 0.00, writes: 37434.03, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1790s] threads: 64, tps: 0.00, reads: 0.00, writes: 49004.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1791s] threads: 64, tps: 0.00, reads: 0.00, writes: 49133.56, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1792s] threads: 64, tps: 0.00, reads: 0.00, writes: 49262.54, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1793s] threads: 64, tps: 0.00, reads: 0.00, writes: 48801.36, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1794s] threads: 64, tps: 0.00, reads: 0.00, writes: 49262.65, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1795s] threads: 64, tps: 0.00, reads: 0.00, writes: 48403.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1796s] threads: 64, tps: 0.00, reads: 0.00, writes: 42285.97, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1797s] threads: 64, tps: 0.00, reads: 0.00, writes: 42605.92, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1798s] threads: 64, tps: 0.00, reads: 0.00, writes: 32688.52, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[1799s] threads: 64, tps: 0.00, reads: 0.00, writes: 31228.54, response time: 4.85ms (95%), errors: 0.00, reconnects:  0.00
[1800s] threads: 64, tps: 0.00, reads: 0.00, writes: 34469.01, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1801s] threads: 64, tps: 0.00, reads: 0.00, writes: 33986.98, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1802s] threads: 64, tps: 0.00, reads: 0.00, writes: 35776.42, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1803s] threads: 64, tps: 0.00, reads: 0.00, writes: 46591.70, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1804s] threads: 64, tps: 0.00, reads: 0.00, writes: 36777.41, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1805s] threads: 64, tps: 0.00, reads: 0.00, writes: 40698.68, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[1806s] threads: 64, tps: 0.00, reads: 0.00, writes: 44130.99, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1807s] threads: 64, tps: 0.00, reads: 0.00, writes: 43794.07, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1808s] threads: 64, tps: 0.00, reads: 0.00, writes: 47830.93, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1809s] threads: 64, tps: 0.00, reads: 0.00, writes: 46567.96, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1810s] threads: 64, tps: 0.00, reads: 0.00, writes: 45049.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1811s] threads: 64, tps: 0.00, reads: 0.00, writes: 42070.02, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[1812s] threads: 64, tps: 0.00, reads: 0.00, writes: 43472.09, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1813s] threads: 64, tps: 0.00, reads: 0.00, writes: 47822.91, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1814s] threads: 64, tps: 0.00, reads: 0.00, writes: 46859.04, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1815s] threads: 64, tps: 0.00, reads: 0.00, writes: 8923.82, response time: 20.39ms (95%), errors: 0.00, reconnects:  0.00
[1816s] threads: 64, tps: 0.00, reads: 0.00, writes: 3249.06, response time: 20.77ms (95%), errors: 0.00, reconnects:  0.00
[1817s] threads: 64, tps: 0.00, reads: 0.00, writes: 28778.04, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[1818s] threads: 64, tps: 0.00, reads: 0.00, writes: 43637.83, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1819s] threads: 64, tps: 0.00, reads: 0.00, writes: 46796.97, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1820s] threads: 64, tps: 0.00, reads: 0.00, writes: 48945.98, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1821s] threads: 64, tps: 0.00, reads: 0.00, writes: 43438.20, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1822s] threads: 64, tps: 0.00, reads: 0.00, writes: 49591.94, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1823s] threads: 64, tps: 0.00, reads: 0.00, writes: 49509.10, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1824s] threads: 64, tps: 0.00, reads: 0.00, writes: 49554.94, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1825s] threads: 64, tps: 0.00, reads: 0.00, writes: 49107.01, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1826s] threads: 64, tps: 0.00, reads: 0.00, writes: 50361.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1827s] threads: 64, tps: 0.00, reads: 0.00, writes: 49715.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1828s] threads: 64, tps: 0.00, reads: 0.00, writes: 49771.11, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1829s] threads: 64, tps: 0.00, reads: 0.00, writes: 49963.95, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1830s] threads: 64, tps: 0.00, reads: 0.00, writes: 43442.98, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1831s] threads: 64, tps: 0.00, reads: 0.00, writes: 49892.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1832s] threads: 64, tps: 0.00, reads: 0.00, writes: 48238.98, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1833s] threads: 64, tps: 0.00, reads: 0.00, writes: 49219.90, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1834s] threads: 64, tps: 0.00, reads: 0.00, writes: 50024.06, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1835s] threads: 64, tps: 0.00, reads: 0.00, writes: 48996.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1836s] threads: 64, tps: 0.00, reads: 0.00, writes: 49636.04, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1837s] threads: 64, tps: 0.00, reads: 0.00, writes: 49432.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1838s] threads: 64, tps: 0.00, reads: 0.00, writes: 50930.97, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1839s] threads: 64, tps: 0.00, reads: 0.00, writes: 50653.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1840s] threads: 64, tps: 0.00, reads: 0.00, writes: 48346.93, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1841s] threads: 64, tps: 0.00, reads: 0.00, writes: 50287.11, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1842s] threads: 64, tps: 0.00, reads: 0.00, writes: 49105.01, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1843s] threads: 64, tps: 0.00, reads: 0.00, writes: 49585.95, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1844s] threads: 64, tps: 0.00, reads: 0.00, writes: 48319.01, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1845s] threads: 64, tps: 0.00, reads: 0.00, writes: 47710.97, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1846s] threads: 64, tps: 0.00, reads: 0.00, writes: 48200.06, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1847s] threads: 64, tps: 0.00, reads: 0.00, writes: 45507.97, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1848s] threads: 64, tps: 0.00, reads: 0.00, writes: 47229.99, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1849s] threads: 64, tps: 0.00, reads: 0.00, writes: 44032.55, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1850s] threads: 64, tps: 0.00, reads: 0.00, writes: 42716.44, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1851s] threads: 64, tps: 0.00, reads: 0.00, writes: 44298.94, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1852s] threads: 64, tps: 0.00, reads: 0.00, writes: 44247.03, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1853s] threads: 64, tps: 0.00, reads: 0.00, writes: 48608.04, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1854s] threads: 64, tps: 0.00, reads: 0.00, writes: 27962.93, response time: 13.51ms (95%), errors: 0.00, reconnects:  0.00
[1855s] threads: 64, tps: 0.00, reads: 0.00, writes: 3210.98, response time: 20.96ms (95%), errors: 0.00, reconnects:  0.00
[1856s] threads: 64, tps: 0.00, reads: 0.00, writes: 3248.96, response time: 20.60ms (95%), errors: 0.00, reconnects:  0.00
[1857s] threads: 64, tps: 0.00, reads: 0.00, writes: 3216.97, response time: 20.58ms (95%), errors: 0.00, reconnects:  0.00
[1858s] threads: 64, tps: 0.00, reads: 0.00, writes: 3246.10, response time: 20.57ms (95%), errors: 0.00, reconnects:  0.00
[1859s] threads: 64, tps: 0.00, reads: 0.00, writes: 24179.01, response time: 9.46ms (95%), errors: 0.00, reconnects:  0.00
[1860s] threads: 64, tps: 0.00, reads: 0.00, writes: 34344.99, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1861s] threads: 64, tps: 0.00, reads: 0.00, writes: 34230.96, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1862s] threads: 64, tps: 0.00, reads: 0.00, writes: 41457.93, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1863s] threads: 64, tps: 0.00, reads: 0.00, writes: 46976.11, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1864s] threads: 64, tps: 0.00, reads: 0.00, writes: 42759.22, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1865s] threads: 64, tps: 0.00, reads: 0.00, writes: 43980.87, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1866s] threads: 64, tps: 0.00, reads: 0.00, writes: 46392.94, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1867s] threads: 64, tps: 0.00, reads: 0.00, writes: 48735.99, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1868s] threads: 64, tps: 0.00, reads: 0.00, writes: 49836.93, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1869s] threads: 64, tps: 0.00, reads: 0.00, writes: 49699.09, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1870s] threads: 64, tps: 0.00, reads: 0.00, writes: 49836.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1871s] threads: 64, tps: 0.00, reads: 0.00, writes: 49714.09, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1872s] threads: 64, tps: 0.00, reads: 0.00, writes: 44284.91, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1873s] threads: 64, tps: 0.00, reads: 0.00, writes: 50430.68, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1874s] threads: 64, tps: 0.00, reads: 0.00, writes: 49692.30, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1875s] threads: 64, tps: 0.00, reads: 0.00, writes: 47072.97, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1876s] threads: 64, tps: 0.00, reads: 0.00, writes: 48912.01, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1877s] threads: 64, tps: 0.00, reads: 0.00, writes: 50789.06, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1878s] threads: 64, tps: 0.00, reads: 0.00, writes: 48974.84, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1879s] threads: 64, tps: 0.00, reads: 0.00, writes: 50230.18, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1880s] threads: 64, tps: 0.00, reads: 0.00, writes: 49932.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1881s] threads: 64, tps: 0.00, reads: 0.00, writes: 50349.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1882s] threads: 64, tps: 0.00, reads: 0.00, writes: 49979.07, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1883s] threads: 64, tps: 0.00, reads: 0.00, writes: 49915.97, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1884s] threads: 64, tps: 0.00, reads: 0.00, writes: 49770.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1885s] threads: 64, tps: 0.00, reads: 0.00, writes: 48003.91, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1886s] threads: 64, tps: 0.00, reads: 0.00, writes: 51087.10, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1887s] threads: 64, tps: 0.00, reads: 0.00, writes: 50776.92, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1888s] threads: 64, tps: 0.00, reads: 0.00, writes: 48977.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1889s] threads: 64, tps: 0.00, reads: 0.00, writes: 46789.05, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1890s] threads: 64, tps: 0.00, reads: 0.00, writes: 50275.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1891s] threads: 64, tps: 0.00, reads: 0.00, writes: 49484.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1892s] threads: 64, tps: 0.00, reads: 0.00, writes: 49305.97, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1893s] threads: 64, tps: 0.00, reads: 0.00, writes: 44603.07, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1894s] threads: 64, tps: 0.00, reads: 0.00, writes: 34252.96, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1895s] threads: 64, tps: 0.00, reads: 0.00, writes: 39838.11, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1896s] threads: 64, tps: 0.00, reads: 0.00, writes: 45573.13, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1897s] threads: 64, tps: 0.00, reads: 0.00, writes: 3249.06, response time: 20.49ms (95%), errors: 0.00, reconnects:  0.00
[1898s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.99, response time: 20.67ms (95%), errors: 0.00, reconnects:  0.00
[1899s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.00, response time: 20.51ms (95%), errors: 0.00, reconnects:  0.00
[1900s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.01, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[1901s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.98, response time: 20.47ms (95%), errors: 0.00, reconnects:  0.00
[1902s] threads: 64, tps: 0.00, reads: 0.00, writes: 3229.02, response time: 20.63ms (95%), errors: 0.00, reconnects:  0.00
[1903s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.00, response time: 20.55ms (95%), errors: 0.00, reconnects:  0.00
[1904s] threads: 64, tps: 0.00, reads: 0.00, writes: 3229.93, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[1905s] threads: 64, tps: 0.00, reads: 0.00, writes: 3234.06, response time: 20.54ms (95%), errors: 0.00, reconnects:  0.00
[1906s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.99, response time: 20.81ms (95%), errors: 0.00, reconnects:  0.00
[1907s] threads: 64, tps: 0.00, reads: 0.00, writes: 3238.00, response time: 20.85ms (95%), errors: 0.00, reconnects:  0.00
[1908s] threads: 64, tps: 0.00, reads: 0.00, writes: 3217.00, response time: 20.57ms (95%), errors: 0.00, reconnects:  0.00
[1909s] threads: 64, tps: 0.00, reads: 0.00, writes: 3252.00, response time: 20.72ms (95%), errors: 0.00, reconnects:  0.00
[1910s] threads: 64, tps: 0.00, reads: 0.00, writes: 3229.00, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[1911s] threads: 64, tps: 0.00, reads: 0.00, writes: 9467.04, response time: 20.43ms (95%), errors: 0.00, reconnects:  0.00
[1912s] threads: 64, tps: 0.00, reads: 0.00, writes: 36316.07, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1913s] threads: 64, tps: 0.00, reads: 0.00, writes: 40040.92, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1914s] threads: 64, tps: 0.00, reads: 0.00, writes: 46363.07, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1915s] threads: 64, tps: 0.00, reads: 0.00, writes: 48182.78, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1916s] threads: 64, tps: 0.00, reads: 0.00, writes: 48204.16, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1917s] threads: 64, tps: 0.00, reads: 0.00, writes: 49117.04, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1918s] threads: 64, tps: 0.00, reads: 0.00, writes: 49679.64, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1919s] threads: 64, tps: 0.00, reads: 0.00, writes: 50482.37, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1920s] threads: 64, tps: 0.00, reads: 0.00, writes: 49356.05, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1921s] threads: 64, tps: 0.00, reads: 0.00, writes: 49166.89, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1922s] threads: 64, tps: 0.00, reads: 0.00, writes: 39307.02, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1923s] threads: 64, tps: 0.00, reads: 0.00, writes: 50190.06, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1924s] threads: 64, tps: 0.00, reads: 0.00, writes: 51571.97, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1925s] threads: 64, tps: 0.00, reads: 0.00, writes: 49711.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1926s] threads: 64, tps: 0.00, reads: 0.00, writes: 50421.90, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1927s] threads: 64, tps: 0.00, reads: 0.00, writes: 49640.06, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1928s] threads: 64, tps: 0.00, reads: 0.00, writes: 51760.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1929s] threads: 64, tps: 0.00, reads: 0.00, writes: 51074.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1930s] threads: 64, tps: 0.00, reads: 0.00, writes: 49245.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1931s] threads: 64, tps: 0.00, reads: 0.00, writes: 49688.08, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1932s] threads: 64, tps: 0.00, reads: 0.00, writes: 50159.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1933s] threads: 64, tps: 0.00, reads: 0.00, writes: 51777.95, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1934s] threads: 64, tps: 0.00, reads: 0.00, writes: 49455.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1935s] threads: 64, tps: 0.00, reads: 0.00, writes: 48907.08, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1936s] threads: 64, tps: 0.00, reads: 0.00, writes: 49098.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1937s] threads: 64, tps: 0.00, reads: 0.00, writes: 49420.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1938s] threads: 64, tps: 0.00, reads: 0.00, writes: 46957.03, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1939s] threads: 64, tps: 0.00, reads: 0.00, writes: 36738.98, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1940s] threads: 64, tps: 0.00, reads: 0.00, writes: 33273.95, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[1941s] threads: 64, tps: 0.00, reads: 0.00, writes: 31784.05, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[1942s] threads: 64, tps: 0.00, reads: 0.00, writes: 35249.03, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1943s] threads: 64, tps: 0.00, reads: 0.00, writes: 44793.05, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1944s] threads: 64, tps: 0.00, reads: 0.00, writes: 40807.90, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1945s] threads: 64, tps: 0.00, reads: 0.00, writes: 32733.96, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[1946s] threads: 64, tps: 0.00, reads: 0.00, writes: 44371.06, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1947s] threads: 64, tps: 0.00, reads: 0.00, writes: 44160.98, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1948s] threads: 64, tps: 0.00, reads: 0.00, writes: 45667.04, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1949s] threads: 64, tps: 0.00, reads: 0.00, writes: 48350.99, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1950s] threads: 64, tps: 0.00, reads: 0.00, writes: 46452.04, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1951s] threads: 64, tps: 0.00, reads: 0.00, writes: 43651.97, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1952s] threads: 64, tps: 0.00, reads: 0.00, writes: 43482.03, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1953s] threads: 64, tps: 0.00, reads: 0.00, writes: 45328.02, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1954s] threads: 64, tps: 0.00, reads: 0.00, writes: 45789.97, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1955s] threads: 64, tps: 0.00, reads: 0.00, writes: 45665.98, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1956s] threads: 64, tps: 0.00, reads: 0.00, writes: 41792.01, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1957s] threads: 64, tps: 0.00, reads: 0.00, writes: 27885.03, response time: 3.89ms (95%), errors: 0.00, reconnects:  0.00
[1958s] threads: 64, tps: 0.00, reads: 0.00, writes: 38256.97, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[1959s] threads: 64, tps: 0.00, reads: 0.00, writes: 50884.05, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1960s] threads: 64, tps: 0.00, reads: 0.00, writes: 48752.91, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1961s] threads: 64, tps: 0.00, reads: 0.00, writes: 43783.03, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1962s] threads: 64, tps: 0.00, reads: 0.00, writes: 49060.96, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1963s] threads: 64, tps: 0.00, reads: 0.00, writes: 49421.27, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1964s] threads: 64, tps: 0.00, reads: 0.00, writes: 49917.84, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1965s] threads: 64, tps: 0.00, reads: 0.00, writes: 49277.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1966s] threads: 64, tps: 0.00, reads: 0.00, writes: 49540.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1967s] threads: 64, tps: 0.00, reads: 0.00, writes: 49451.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1968s] threads: 64, tps: 0.00, reads: 0.00, writes: 50751.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1969s] threads: 64, tps: 0.00, reads: 0.00, writes: 50727.03, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1970s] threads: 64, tps: 0.00, reads: 0.00, writes: 49571.93, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1971s] threads: 64, tps: 0.00, reads: 0.00, writes: 49258.74, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1972s] threads: 64, tps: 0.00, reads: 0.00, writes: 47984.02, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1973s] threads: 64, tps: 0.00, reads: 0.00, writes: 50657.25, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1974s] threads: 64, tps: 0.00, reads: 0.00, writes: 50273.80, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1975s] threads: 64, tps: 0.00, reads: 0.00, writes: 49566.96, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1976s] threads: 64, tps: 0.00, reads: 0.00, writes: 47423.95, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1977s] threads: 64, tps: 0.00, reads: 0.00, writes: 43992.48, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1978s] threads: 64, tps: 0.00, reads: 0.00, writes: 42884.74, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1979s] threads: 64, tps: 0.00, reads: 0.00, writes: 31547.04, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[1980s] threads: 64, tps: 0.00, reads: 0.00, writes: 33210.99, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1981s] threads: 64, tps: 0.00, reads: 0.00, writes: 32577.99, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[1982s] threads: 64, tps: 0.00, reads: 0.00, writes: 34400.16, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1983s] threads: 64, tps: 0.00, reads: 0.00, writes: 40237.17, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1984s] threads: 64, tps: 0.00, reads: 0.00, writes: 48240.77, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1985s] threads: 64, tps: 0.00, reads: 0.00, writes: 42643.13, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1986s] threads: 64, tps: 0.00, reads: 0.00, writes: 44674.27, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1987s] threads: 64, tps: 0.00, reads: 0.00, writes: 42424.71, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1988s] threads: 64, tps: 0.00, reads: 0.00, writes: 44869.49, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1989s] threads: 64, tps: 0.00, reads: 0.00, writes: 47084.01, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1990s] threads: 64, tps: 0.00, reads: 0.00, writes: 45733.95, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1991s] threads: 64, tps: 0.00, reads: 0.00, writes: 44310.05, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1992s] threads: 64, tps: 0.00, reads: 0.00, writes: 37907.01, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1993s] threads: 64, tps: 0.00, reads: 0.00, writes: 44237.92, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1994s] threads: 64, tps: 0.00, reads: 0.00, writes: 47404.10, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1995s] threads: 64, tps: 0.00, reads: 0.00, writes: 40944.00, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[1996s] threads: 64, tps: 0.00, reads: 0.00, writes: 33411.41, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1997s] threads: 64, tps: 0.00, reads: 0.00, writes: 41329.72, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1998s] threads: 64, tps: 0.00, reads: 0.00, writes: 46160.95, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1999s] threads: 64, tps: 0.00, reads: 0.00, writes: 50948.11, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2000s] threads: 64, tps: 0.00, reads: 0.00, writes: 42321.94, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2001s] threads: 64, tps: 0.00, reads: 0.00, writes: 48942.05, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2002s] threads: 64, tps: 0.00, reads: 0.00, writes: 50104.01, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2003s] threads: 64, tps: 0.00, reads: 0.00, writes: 49635.91, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2004s] threads: 64, tps: 0.00, reads: 0.00, writes: 50607.03, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2005s] threads: 64, tps: 0.00, reads: 0.00, writes: 49605.06, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2006s] threads: 64, tps: 0.00, reads: 0.00, writes: 48918.91, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2007s] threads: 64, tps: 0.00, reads: 0.00, writes: 49055.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2008s] threads: 64, tps: 0.00, reads: 0.00, writes: 49830.16, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2009s] threads: 64, tps: 0.00, reads: 0.00, writes: 49668.02, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2010s] threads: 64, tps: 0.00, reads: 0.00, writes: 50235.94, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2011s] threads: 64, tps: 0.00, reads: 0.00, writes: 48934.95, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2012s] threads: 64, tps: 0.00, reads: 0.00, writes: 48249.07, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2013s] threads: 64, tps: 0.00, reads: 0.00, writes: 49612.93, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2014s] threads: 64, tps: 0.00, reads: 0.00, writes: 49322.99, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2015s] threads: 64, tps: 0.00, reads: 0.00, writes: 48585.30, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2016s] threads: 64, tps: 0.00, reads: 0.00, writes: 50072.88, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2017s] threads: 64, tps: 0.00, reads: 0.00, writes: 48344.75, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2018s] threads: 64, tps: 0.00, reads: 0.00, writes: 49547.17, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2019s] threads: 64, tps: 0.00, reads: 0.00, writes: 48582.75, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2020s] threads: 64, tps: 0.00, reads: 0.00, writes: 46844.30, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2021s] threads: 64, tps: 0.00, reads: 0.00, writes: 44697.89, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2022s] threads: 64, tps: 0.00, reads: 0.00, writes: 45260.84, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2023s] threads: 64, tps: 0.00, reads: 0.00, writes: 47756.19, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2024s] threads: 64, tps: 0.00, reads: 0.00, writes: 43465.00, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2025s] threads: 64, tps: 0.00, reads: 0.00, writes: 44409.01, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2026s] threads: 64, tps: 0.00, reads: 0.00, writes: 43388.46, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2027s] threads: 64, tps: 0.00, reads: 0.00, writes: 48242.52, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2028s] threads: 64, tps: 0.00, reads: 0.00, writes: 47425.38, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2029s] threads: 64, tps: 0.00, reads: 0.00, writes: 9904.86, response time: 20.29ms (95%), errors: 0.00, reconnects:  0.00
[2030s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.01, response time: 20.71ms (95%), errors: 0.00, reconnects:  0.00
[2031s] threads: 64, tps: 0.00, reads: 0.00, writes: 3237.04, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[2032s] threads: 64, tps: 0.00, reads: 0.00, writes: 3237.00, response time: 20.67ms (95%), errors: 0.00, reconnects:  0.00
[2033s] threads: 64, tps: 0.00, reads: 0.00, writes: 32422.00, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[2034s] threads: 64, tps: 0.00, reads: 0.00, writes: 35325.02, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[2035s] threads: 64, tps: 0.00, reads: 0.00, writes: 39735.99, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[2036s] threads: 64, tps: 0.00, reads: 0.00, writes: 46039.05, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2037s] threads: 64, tps: 0.00, reads: 0.00, writes: 44695.99, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2038s] threads: 64, tps: 0.00, reads: 0.00, writes: 47549.74, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2039s] threads: 64, tps: 0.00, reads: 0.00, writes: 49225.32, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2040s] threads: 64, tps: 0.00, reads: 0.00, writes: 48726.94, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2041s] threads: 64, tps: 0.00, reads: 0.00, writes: 44423.99, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2042s] threads: 64, tps: 0.00, reads: 0.00, writes: 49937.02, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2043s] threads: 64, tps: 0.00, reads: 0.00, writes: 48932.94, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2044s] threads: 64, tps: 0.00, reads: 0.00, writes: 49583.14, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2045s] threads: 64, tps: 0.00, reads: 0.00, writes: 50508.89, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2046s] threads: 64, tps: 0.00, reads: 0.00, writes: 50008.01, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2047s] threads: 64, tps: 0.00, reads: 0.00, writes: 46582.93, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2048s] threads: 64, tps: 0.00, reads: 0.00, writes: 49765.09, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2049s] threads: 64, tps: 0.00, reads: 0.00, writes: 48857.01, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2050s] threads: 64, tps: 0.00, reads: 0.00, writes: 50634.73, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2051s] threads: 64, tps: 0.00, reads: 0.00, writes: 50255.23, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2052s] threads: 64, tps: 0.00, reads: 0.00, writes: 49316.01, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2053s] threads: 64, tps: 0.00, reads: 0.00, writes: 49500.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2054s] threads: 64, tps: 0.00, reads: 0.00, writes: 49657.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2055s] threads: 64, tps: 0.00, reads: 0.00, writes: 50425.90, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2056s] threads: 64, tps: 0.00, reads: 0.00, writes: 49333.01, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2057s] threads: 64, tps: 0.00, reads: 0.00, writes: 49068.09, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2058s] threads: 64, tps: 0.00, reads: 0.00, writes: 47657.84, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2059s] threads: 64, tps: 0.00, reads: 0.00, writes: 50311.07, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2060s] threads: 64, tps: 0.00, reads: 0.00, writes: 47445.05, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2061s] threads: 64, tps: 0.00, reads: 0.00, writes: 47886.95, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2062s] threads: 64, tps: 0.00, reads: 0.00, writes: 44997.05, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2063s] threads: 64, tps: 0.00, reads: 0.00, writes: 33546.83, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[2064s] threads: 64, tps: 0.00, reads: 0.00, writes: 42612.07, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2065s] threads: 64, tps: 0.00, reads: 0.00, writes: 40226.35, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[2066s] threads: 64, tps: 0.00, reads: 0.00, writes: 34583.39, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[2067s] threads: 64, tps: 0.00, reads: 0.00, writes: 33640.97, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[2068s] threads: 64, tps: 0.00, reads: 0.00, writes: 33711.02, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[2069s] threads: 64, tps: 0.00, reads: 0.00, writes: 41996.03, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2070s] threads: 64, tps: 0.00, reads: 0.00, writes: 47032.01, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2071s] threads: 64, tps: 0.00, reads: 0.00, writes: 48446.00, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2072s] threads: 64, tps: 0.00, reads: 0.00, writes: 17451.00, response time: 19.95ms (95%), errors: 0.00, reconnects:  0.00
[2073s] threads: 64, tps: 0.00, reads: 0.00, writes: 3242.99, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[2074s] threads: 64, tps: 0.00, reads: 0.00, writes: 3234.93, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[2075s] threads: 64, tps: 0.00, reads: 0.00, writes: 3215.08, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[2076s] threads: 64, tps: 0.00, reads: 0.00, writes: 3251.99, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[2077s] threads: 64, tps: 0.00, reads: 0.00, writes: 3234.00, response time: 20.68ms (95%), errors: 0.00, reconnects:  0.00
[2078s] threads: 64, tps: 0.00, reads: 0.00, writes: 3229.99, response time: 20.68ms (95%), errors: 0.00, reconnects:  0.00
[2079s] threads: 64, tps: 0.00, reads: 0.00, writes: 3232.93, response time: 20.75ms (95%), errors: 0.00, reconnects:  0.00
[2080s] threads: 64, tps: 0.00, reads: 0.00, writes: 25839.62, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[2081s] threads: 64, tps: 0.00, reads: 0.00, writes: 34881.04, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[2082s] threads: 64, tps: 0.00, reads: 0.00, writes: 42623.95, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2083s] threads: 64, tps: 0.00, reads: 0.00, writes: 46914.95, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2084s] threads: 64, tps: 0.00, reads: 0.00, writes: 44136.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2085s] threads: 64, tps: 0.00, reads: 0.00, writes: 49253.00, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2086s] threads: 64, tps: 0.00, reads: 0.00, writes: 42598.03, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2087s] threads: 64, tps: 0.00, reads: 0.00, writes: 50932.93, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2088s] threads: 64, tps: 0.00, reads: 0.00, writes: 50156.63, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2089s] threads: 64, tps: 0.00, reads: 0.00, writes: 48966.41, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2090s] threads: 64, tps: 0.00, reads: 0.00, writes: 49924.82, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2091s] threads: 64, tps: 0.00, reads: 0.00, writes: 48230.09, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2092s] threads: 64, tps: 0.00, reads: 0.00, writes: 49020.98, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2093s] threads: 64, tps: 0.00, reads: 0.00, writes: 50866.11, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2094s] threads: 64, tps: 0.00, reads: 0.00, writes: 48107.97, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2095s] threads: 64, tps: 0.00, reads: 0.00, writes: 50018.03, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2096s] threads: 64, tps: 0.00, reads: 0.00, writes: 49241.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2097s] threads: 64, tps: 0.00, reads: 0.00, writes: 51331.93, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2098s] threads: 64, tps: 0.00, reads: 0.00, writes: 49408.07, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2099s] threads: 64, tps: 0.00, reads: 0.00, writes: 49102.93, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2100s] threads: 64, tps: 0.00, reads: 0.00, writes: 49465.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2101s] threads: 64, tps: 0.00, reads: 0.00, writes: 49078.13, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2102s] threads: 64, tps: 0.00, reads: 0.00, writes: 49994.83, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2103s] threads: 64, tps: 0.00, reads: 0.00, writes: 49216.67, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2104s] threads: 64, tps: 0.00, reads: 0.00, writes: 48624.53, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2105s] threads: 64, tps: 0.00, reads: 0.00, writes: 48178.52, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2106s] threads: 64, tps: 0.00, reads: 0.00, writes: 48398.42, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2107s] threads: 64, tps: 0.00, reads: 0.00, writes: 43741.00, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2108s] threads: 64, tps: 0.00, reads: 0.00, writes: 35400.99, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[2109s] threads: 64, tps: 0.00, reads: 0.00, writes: 33521.08, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[2110s] threads: 64, tps: 0.00, reads: 0.00, writes: 34797.95, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[2111s] threads: 64, tps: 0.00, reads: 0.00, writes: 37555.95, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[2112s] threads: 64, tps: 0.00, reads: 0.00, writes: 46194.06, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2113s] threads: 64, tps: 0.00, reads: 0.00, writes: 34883.97, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[2114s] threads: 64, tps: 0.00, reads: 0.00, writes: 43859.02, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[2115s] threads: 64, tps: 0.00, reads: 0.00, writes: 43701.01, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2116s] threads: 64, tps: 0.00, reads: 0.00, writes: 42900.00, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2117s] threads: 64, tps: 0.00, reads: 0.00, writes: 46255.95, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2118s] threads: 64, tps: 0.00, reads: 0.00, writes: 44048.63, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2119s] threads: 64, tps: 0.00, reads: 0.00, writes: 43217.87, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2120s] threads: 64, tps: 0.00, reads: 0.00, writes: 41919.48, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2121s] threads: 64, tps: 0.00, reads: 0.00, writes: 43964.97, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2122s] threads: 64, tps: 0.00, reads: 0.00, writes: 48499.99, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2123s] threads: 64, tps: 0.00, reads: 0.00, writes: 47516.78, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2124s] threads: 64, tps: 0.00, reads: 0.00, writes: 18988.07, response time: 19.80ms (95%), errors: 0.00, reconnects:  0.00
[2125s] threads: 64, tps: 0.00, reads: 0.00, writes: 4443.99, response time: 20.43ms (95%), errors: 0.00, reconnects:  0.00
[2126s] threads: 64, tps: 0.00, reads: 0.00, writes: 30113.90, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[2127s] threads: 64, tps: 0.00, reads: 0.00, writes: 38499.64, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2128s] threads: 64, tps: 0.00, reads: 0.00, writes: 41084.01, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2129s] threads: 64, tps: 0.00, reads: 0.00, writes: 49292.93, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2130s] threads: 64, tps: 0.00, reads: 0.00, writes: 43459.04, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2131s] threads: 64, tps: 0.00, reads: 0.00, writes: 47668.01, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2132s] threads: 64, tps: 0.00, reads: 0.00, writes: 49752.89, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2133s] threads: 64, tps: 0.00, reads: 0.00, writes: 48742.08, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2134s] threads: 64, tps: 0.00, reads: 0.00, writes: 49925.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2135s] threads: 64, tps: 0.00, reads: 0.00, writes: 49774.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2136s] threads: 64, tps: 0.00, reads: 0.00, writes: 48576.11, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2137s] threads: 64, tps: 0.00, reads: 0.00, writes: 50212.86, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2138s] threads: 64, tps: 0.00, reads: 0.00, writes: 50727.48, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2139s] threads: 64, tps: 0.00, reads: 0.00, writes: 50223.58, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2140s] threads: 64, tps: 0.00, reads: 0.00, writes: 49278.87, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2141s] threads: 64, tps: 0.00, reads: 0.00, writes: 45460.11, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2142s] threads: 64, tps: 0.00, reads: 0.00, writes: 49354.95, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2143s] threads: 64, tps: 0.00, reads: 0.00, writes: 50091.01, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2144s] threads: 64, tps: 0.00, reads: 0.00, writes: 49425.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2145s] threads: 64, tps: 0.00, reads: 0.00, writes: 49019.10, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2146s] threads: 64, tps: 0.00, reads: 0.00, writes: 49520.95, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2147s] threads: 64, tps: 0.00, reads: 0.00, writes: 49258.83, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2148s] threads: 64, tps: 0.00, reads: 0.00, writes: 50103.16, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2149s] threads: 64, tps: 0.00, reads: 0.00, writes: 49357.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2150s] threads: 64, tps: 0.00, reads: 0.00, writes: 48951.94, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2151s] threads: 64, tps: 0.00, reads: 0.00, writes: 45547.01, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2152s] threads: 64, tps: 0.00, reads: 0.00, writes: 50201.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2153s] threads: 64, tps: 0.00, reads: 0.00, writes: 49468.93, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2154s] threads: 64, tps: 0.00, reads: 0.00, writes: 47081.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2155s] threads: 64, tps: 0.00, reads: 0.00, writes: 48393.62, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2156s] threads: 64, tps: 0.00, reads: 0.00, writes: 46038.37, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2157s] threads: 64, tps: 0.00, reads: 0.00, writes: 45567.99, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2158s] threads: 64, tps: 0.00, reads: 0.00, writes: 34436.99, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[2159s] threads: 64, tps: 0.00, reads: 0.00, writes: 30720.87, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[2160s] threads: 64, tps: 0.00, reads: 0.00, writes: 32870.98, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[2161s] threads: 64, tps: 0.00, reads: 0.00, writes: 33459.19, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[2162s] threads: 64, tps: 0.00, reads: 0.00, writes: 41485.01, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[2163s] threads: 64, tps: 0.00, reads: 0.00, writes: 47879.91, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2164s] threads: 64, tps: 0.00, reads: 0.00, writes: 36982.08, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2165s] threads: 64, tps: 0.00, reads: 0.00, writes: 3222.94, response time: 20.71ms (95%), errors: 0.00, reconnects:  0.00
[2166s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.01, response time: 20.67ms (95%), errors: 0.00, reconnects:  0.00
[2167s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.98, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[2168s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.07, response time: 20.57ms (95%), errors: 0.00, reconnects:  0.00
[2169s] threads: 64, tps: 0.00, reads: 0.00, writes: 3232.99, response time: 20.50ms (95%), errors: 0.00, reconnects:  0.00
[2170s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.01, response time: 20.69ms (95%), errors: 0.00, reconnects:  0.00
[2171s] threads: 64, tps: 0.00, reads: 0.00, writes: 3243.00, response time: 20.76ms (95%), errors: 0.00, reconnects:  0.00
[2172s] threads: 64, tps: 0.00, reads: 0.00, writes: 3222.01, response time: 20.88ms (95%), errors: 0.00, reconnects:  0.00
[2173s] threads: 64, tps: 0.00, reads: 0.00, writes: 10556.99, response time: 20.35ms (95%), errors: 0.00, reconnects:  0.00
[2174s] threads: 64, tps: 0.00, reads: 0.00, writes: 34365.98, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[2175s] threads: 64, tps: 0.00, reads: 0.00, writes: 37858.01, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2176s] threads: 64, tps: 0.00, reads: 0.00, writes: 45635.99, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2177s] threads: 64, tps: 0.00, reads: 0.00, writes: 45754.95, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2178s] threads: 64, tps: 0.00, reads: 0.00, writes: 44865.12, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2179s] threads: 64, tps: 0.00, reads: 0.00, writes: 44291.19, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2180s] threads: 64, tps: 0.00, reads: 0.00, writes: 48583.94, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2181s] threads: 64, tps: 0.00, reads: 0.00, writes: 49956.92, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2182s] threads: 64, tps: 0.00, reads: 0.00, writes: 50217.96, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2183s] threads: 64, tps: 0.00, reads: 0.00, writes: 48416.05, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2184s] threads: 64, tps: 0.00, reads: 0.00, writes: 48206.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2185s] threads: 64, tps: 0.00, reads: 0.00, writes: 48383.04, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2186s] threads: 64, tps: 0.00, reads: 0.00, writes: 51721.94, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2187s] threads: 64, tps: 0.00, reads: 0.00, writes: 48940.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2188s] threads: 64, tps: 0.00, reads: 0.00, writes: 50292.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2189s] threads: 64, tps: 0.00, reads: 0.00, writes: 49727.05, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2190s] threads: 64, tps: 0.00, reads: 0.00, writes: 49257.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2191s] threads: 64, tps: 0.00, reads: 0.00, writes: 49927.01, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2192s] threads: 64, tps: 0.00, reads: 0.00, writes: 47483.99, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2193s] threads: 64, tps: 0.00, reads: 0.00, writes: 48760.01, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2194s] threads: 64, tps: 0.00, reads: 0.00, writes: 47647.89, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2195s] threads: 64, tps: 0.00, reads: 0.00, writes: 51701.43, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2196s] threads: 64, tps: 0.00, reads: 0.00, writes: 48507.94, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2197s] threads: 64, tps: 0.00, reads: 0.00, writes: 48574.50, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2198s] threads: 64, tps: 0.00, reads: 0.00, writes: 42667.97, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2199s] threads: 64, tps: 0.00, reads: 0.00, writes: 28044.99, response time: 3.94ms (95%), errors: 0.00, reconnects:  0.00
[2200s] threads: 64, tps: 0.00, reads: 0.00, writes: 45819.05, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2201s] threads: 64, tps: 0.00, reads: 0.00, writes: 41876.46, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2202s] threads: 64, tps: 0.00, reads: 0.00, writes: 33497.22, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[2203s] threads: 64, tps: 0.00, reads: 0.00, writes: 35176.45, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[2204s] threads: 64, tps: 0.00, reads: 0.00, writes: 33301.54, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[2205s] threads: 64, tps: 0.00, reads: 0.00, writes: 34506.99, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[2206s] threads: 64, tps: 0.00, reads: 0.00, writes: 43259.87, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2207s] threads: 64, tps: 0.00, reads: 0.00, writes: 40445.18, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[2208s] threads: 64, tps: 0.00, reads: 0.00, writes: 36988.99, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[2209s] threads: 64, tps: 0.00, reads: 0.00, writes: 43769.96, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2210s] threads: 64, tps: 0.00, reads: 0.00, writes: 42718.99, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[2211s] threads: 64, tps: 0.00, reads: 0.00, writes: 41396.91, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2212s] threads: 64, tps: 0.00, reads: 0.00, writes: 46038.05, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2213s] threads: 64, tps: 0.00, reads: 0.00, writes: 44368.12, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2214s] threads: 64, tps: 0.00, reads: 0.00, writes: 42781.93, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2215s] threads: 64, tps: 0.00, reads: 0.00, writes: 43310.86, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[2216s] threads: 64, tps: 0.00, reads: 0.00, writes: 44936.04, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2217s] threads: 64, tps: 0.00, reads: 0.00, writes: 46709.06, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2218s] threads: 64, tps: 0.00, reads: 0.00, writes: 46621.11, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2219s] threads: 64, tps: 0.00, reads: 0.00, writes: 3626.05, response time: 20.76ms (95%), errors: 0.00, reconnects:  0.00
[2220s] threads: 64, tps: 0.00, reads: 0.00, writes: 32354.52, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[2221s] threads: 64, tps: 0.00, reads: 0.00, writes: 38663.78, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2222s] threads: 64, tps: 0.00, reads: 0.00, writes: 43899.94, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2223s] threads: 64, tps: 0.00, reads: 0.00, writes: 50727.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2224s] threads: 64, tps: 0.00, reads: 0.00, writes: 48267.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2225s] threads: 64, tps: 0.00, reads: 0.00, writes: 49634.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2226s] threads: 64, tps: 0.00, reads: 0.00, writes: 48193.01, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2227s] threads: 64, tps: 0.00, reads: 0.00, writes: 48548.70, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2228s] threads: 64, tps: 0.00, reads: 0.00, writes: 50292.35, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2229s] threads: 64, tps: 0.00, reads: 0.00, writes: 49413.91, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2230s] threads: 64, tps: 0.00, reads: 0.00, writes: 49228.07, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2231s] threads: 64, tps: 0.00, reads: 0.00, writes: 49062.01, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2232s] threads: 64, tps: 0.00, reads: 0.00, writes: 49490.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2233s] threads: 64, tps: 0.00, reads: 0.00, writes: 50134.99, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2234s] threads: 64, tps: 0.00, reads: 0.00, writes: 48823.93, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2235s] threads: 64, tps: 0.00, reads: 0.00, writes: 48608.02, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2236s] threads: 64, tps: 0.00, reads: 0.00, writes: 48925.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2237s] threads: 64, tps: 0.00, reads: 0.00, writes: 50839.96, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2238s] threads: 64, tps: 0.00, reads: 0.00, writes: 49310.79, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2239s] threads: 64, tps: 0.00, reads: 0.00, writes: 48487.19, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2240s] threads: 64, tps: 0.00, reads: 0.00, writes: 49227.13, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2241s] threads: 64, tps: 0.00, reads: 0.00, writes: 50703.92, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2242s] threads: 64, tps: 0.00, reads: 0.00, writes: 50075.05, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2243s] threads: 64, tps: 0.00, reads: 0.00, writes: 48896.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2244s] threads: 64, tps: 0.00, reads: 0.00, writes: 44758.02, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2245s] threads: 64, tps: 0.00, reads: 0.00, writes: 35468.98, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[2246s] threads: 64, tps: 0.00, reads: 0.00, writes: 44816.01, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2247s] threads: 64, tps: 0.00, reads: 0.00, writes: 37160.98, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[2248s] threads: 64, tps: 0.00, reads: 0.00, writes: 32418.69, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[2249s] threads: 64, tps: 0.00, reads: 0.00, writes: 41125.97, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[2250s] threads: 64, tps: 0.00, reads: 0.00, writes: 39247.89, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2251s] threads: 64, tps: 0.00, reads: 0.00, writes: 44589.10, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2252s] threads: 64, tps: 0.00, reads: 0.00, writes: 48151.92, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2253s] threads: 64, tps: 0.00, reads: 0.00, writes: 47265.11, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2254s] threads: 64, tps: 0.00, reads: 0.00, writes: 42906.97, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2255s] threads: 64, tps: 0.00, reads: 0.00, writes: 44024.99, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2256s] threads: 64, tps: 0.00, reads: 0.00, writes: 45911.04, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2257s] threads: 64, tps: 0.00, reads: 0.00, writes: 47340.97, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2258s] threads: 64, tps: 0.00, reads: 0.00, writes: 35139.00, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2259s] threads: 64, tps: 0.00, reads: 0.00, writes: 3217.92, response time: 20.76ms (95%), errors: 0.00, reconnects:  0.00
[2260s] threads: 64, tps: 0.00, reads: 0.00, writes: 8477.19, response time: 20.42ms (95%), errors: 0.00, reconnects:  0.00
[2261s] threads: 64, tps: 0.00, reads: 0.00, writes: 36001.03, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[2262s] threads: 64, tps: 0.00, reads: 0.00, writes: 40852.01, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[2263s] threads: 64, tps: 0.00, reads: 0.00, writes: 43859.81, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2264s] threads: 64, tps: 0.00, reads: 0.00, writes: 49861.23, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2265s] threads: 64, tps: 0.00, reads: 0.00, writes: 48062.98, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2266s] threads: 64, tps: 0.00, reads: 0.00, writes: 48871.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2267s] threads: 64, tps: 0.00, reads: 0.00, writes: 49088.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2268s] threads: 64, tps: 0.00, reads: 0.00, writes: 47362.08, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2269s] threads: 64, tps: 0.00, reads: 0.00, writes: 50310.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2270s] threads: 64, tps: 0.00, reads: 0.00, writes: 48688.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2271s] threads: 64, tps: 0.00, reads: 0.00, writes: 50138.92, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2272s] threads: 64, tps: 0.00, reads: 0.00, writes: 49221.13, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2273s] threads: 64, tps: 0.00, reads: 0.00, writes: 50841.94, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2274s] threads: 64, tps: 0.00, reads: 0.00, writes: 49230.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2275s] threads: 64, tps: 0.00, reads: 0.00, writes: 49465.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2276s] threads: 64, tps: 0.00, reads: 0.00, writes: 49321.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2277s] threads: 64, tps: 0.00, reads: 0.00, writes: 49763.01, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2278s] threads: 64, tps: 0.00, reads: 0.00, writes: 50447.03, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2279s] threads: 64, tps: 0.00, reads: 0.00, writes: 50808.02, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2280s] threads: 64, tps: 0.00, reads: 0.00, writes: 47893.73, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2281s] threads: 64, tps: 0.00, reads: 0.00, writes: 49512.24, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2282s] threads: 64, tps: 0.00, reads: 0.00, writes: 50456.98, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2283s] threads: 64, tps: 0.00, reads: 0.00, writes: 50032.93, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2284s] threads: 64, tps: 0.00, reads: 0.00, writes: 48006.00, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2285s] threads: 64, tps: 0.00, reads: 0.00, writes: 43724.09, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2286s] threads: 64, tps: 0.00, reads: 0.00, writes: 36669.80, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[2287s] threads: 64, tps: 0.00, reads: 0.00, writes: 46008.16, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2288s] threads: 64, tps: 0.00, reads: 0.00, writes: 38261.05, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[2289s] threads: 64, tps: 0.00, reads: 0.00, writes: 33745.01, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[2290s] threads: 64, tps: 0.00, reads: 0.00, writes: 32315.95, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[2291s] threads: 64, tps: 0.00, reads: 0.00, writes: 33785.03, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[2292s] threads: 64, tps: 0.00, reads: 0.00, writes: 33926.96, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[2293s] threads: 64, tps: 0.00, reads: 0.00, writes: 45045.10, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2294s] threads: 64, tps: 0.00, reads: 0.00, writes: 41263.92, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2295s] threads: 64, tps: 0.00, reads: 0.00, writes: 34264.01, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[2296s] threads: 64, tps: 0.00, reads: 0.00, writes: 43608.98, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2297s] threads: 64, tps: 0.00, reads: 0.00, writes: 43139.79, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2298s] threads: 64, tps: 0.00, reads: 0.00, writes: 46332.22, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2299s] threads: 64, tps: 0.00, reads: 0.00, writes: 47142.06, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2300s] threads: 64, tps: 0.00, reads: 0.00, writes: 28840.91, response time: 8.74ms (95%), errors: 0.00, reconnects:  0.00
[2301s] threads: 64, tps: 0.00, reads: 0.00, writes: 3219.99, response time: 20.71ms (95%), errors: 0.00, reconnects:  0.00
[2302s] threads: 64, tps: 0.00, reads: 0.00, writes: 3253.01, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[2303s] threads: 64, tps: 0.00, reads: 0.00, writes: 3217.99, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[2304s] threads: 64, tps: 0.00, reads: 0.00, writes: 3211.02, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[2305s] threads: 64, tps: 0.00, reads: 0.00, writes: 3252.00, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[2306s] threads: 64, tps: 0.00, reads: 0.00, writes: 3223.92, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[2307s] threads: 64, tps: 0.00, reads: 0.00, writes: 24546.55, response time: 5.80ms (95%), errors: 0.00, reconnects:  0.00
[2308s] threads: 64, tps: 0.00, reads: 0.00, writes: 36055.97, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[2309s] threads: 64, tps: 0.00, reads: 0.00, writes: 34987.05, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[2310s] threads: 64, tps: 0.00, reads: 0.00, writes: 42729.00, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2311s] threads: 64, tps: 0.00, reads: 0.00, writes: 44067.96, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2312s] threads: 64, tps: 0.00, reads: 0.00, writes: 39767.05, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[2313s] threads: 64, tps: 0.00, reads: 0.00, writes: 46314.95, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2314s] threads: 64, tps: 0.00, reads: 0.00, writes: 48185.05, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2315s] threads: 64, tps: 0.00, reads: 0.00, writes: 49482.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2316s] threads: 64, tps: 0.00, reads: 0.00, writes: 47933.06, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2317s] threads: 64, tps: 0.00, reads: 0.00, writes: 48520.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2318s] threads: 64, tps: 0.00, reads: 0.00, writes: 49145.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2319s] threads: 64, tps: 0.00, reads: 0.00, writes: 49125.04, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2320s] threads: 64, tps: 0.00, reads: 0.00, writes: 51015.99, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2321s] threads: 64, tps: 0.00, reads: 0.00, writes: 48276.05, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2322s] threads: 64, tps: 0.00, reads: 0.00, writes: 48418.92, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2323s] threads: 64, tps: 0.00, reads: 0.00, writes: 49207.01, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2324s] threads: 64, tps: 0.00, reads: 0.00, writes: 50301.58, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2325s] threads: 64, tps: 0.00, reads: 0.00, writes: 47529.31, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2326s] threads: 64, tps: 0.00, reads: 0.00, writes: 49767.15, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2327s] threads: 64, tps: 0.00, reads: 0.00, writes: 48587.95, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2328s] threads: 64, tps: 0.00, reads: 0.00, writes: 48158.02, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2329s] threads: 64, tps: 0.00, reads: 0.00, writes: 49028.95, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2330s] threads: 64, tps: 0.00, reads: 0.00, writes: 49150.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2331s] threads: 64, tps: 0.00, reads: 0.00, writes: 49787.05, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2332s] threads: 64, tps: 0.00, reads: 0.00, writes: 47509.96, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2333s] threads: 64, tps: 0.00, reads: 0.00, writes: 44732.03, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2334s] threads: 64, tps: 0.00, reads: 0.00, writes: 46687.99, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2335s] threads: 64, tps: 0.00, reads: 0.00, writes: 30035.00, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[2336s] threads: 64, tps: 0.00, reads: 0.00, writes: 33405.99, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[2337s] threads: 64, tps: 0.00, reads: 0.00, writes: 32184.04, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[2338s] threads: 64, tps: 0.00, reads: 0.00, writes: 31721.93, response time: 3.53ms (95%), errors: 0.00, reconnects:  0.00
[2339s] threads: 64, tps: 0.00, reads: 0.00, writes: 32621.04, response time: 3.28ms (95%), errors: 0.00, reconnects:  0.00
[2340s] threads: 64, tps: 0.00, reads: 0.00, writes: 44594.98, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2341s] threads: 64, tps: 0.00, reads: 0.00, writes: 42479.05, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2342s] threads: 64, tps: 0.00, reads: 0.00, writes: 32241.95, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[2343s] threads: 64, tps: 0.00, reads: 0.00, writes: 33754.83, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[2344s] threads: 64, tps: 0.00, reads: 0.00, writes: 43297.20, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2345s] threads: 64, tps: 0.00, reads: 0.00, writes: 43963.05, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2346s] threads: 64, tps: 0.00, reads: 0.00, writes: 48061.02, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2347s] threads: 64, tps: 0.00, reads: 0.00, writes: 47320.97, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2348s] threads: 64, tps: 0.00, reads: 0.00, writes: 44699.99, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2349s] threads: 64, tps: 0.00, reads: 0.00, writes: 44130.02, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2350s] threads: 64, tps: 0.00, reads: 0.00, writes: 44603.01, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2351s] threads: 64, tps: 0.00, reads: 0.00, writes: 47590.98, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2352s] threads: 64, tps: 0.00, reads: 0.00, writes: 39128.86, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2353s] threads: 64, tps: 0.00, reads: 0.00, writes: 3219.91, response time: 20.73ms (95%), errors: 0.00, reconnects:  0.00
[2354s] threads: 64, tps: 0.00, reads: 0.00, writes: 3239.79, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[2355s] threads: 64, tps: 0.00, reads: 0.00, writes: 13408.26, response time: 20.06ms (95%), errors: 0.00, reconnects:  0.00
[2356s] threads: 64, tps: 0.00, reads: 0.00, writes: 33825.04, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[2357s] threads: 64, tps: 0.00, reads: 0.00, writes: 33466.84, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[2358s] threads: 64, tps: 0.00, reads: 0.00, writes: 33268.16, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[2359s] threads: 64, tps: 0.00, reads: 0.00, writes: 46343.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2360s] threads: 64, tps: 0.00, reads: 0.00, writes: 41043.00, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[2361s] threads: 64, tps: 0.00, reads: 0.00, writes: 46491.98, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2362s] threads: 64, tps: 0.00, reads: 0.00, writes: 49287.05, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2363s] threads: 64, tps: 0.00, reads: 0.00, writes: 46192.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2364s] threads: 64, tps: 0.00, reads: 0.00, writes: 49314.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2365s] threads: 64, tps: 0.00, reads: 0.00, writes: 48989.95, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2366s] threads: 64, tps: 0.00, reads: 0.00, writes: 48367.06, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2367s] threads: 64, tps: 0.00, reads: 0.00, writes: 46950.01, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2368s] threads: 64, tps: 0.00, reads: 0.00, writes: 50401.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2369s] threads: 64, tps: 0.00, reads: 0.00, writes: 49942.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2370s] threads: 64, tps: 0.00, reads: 0.00, writes: 46927.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2371s] threads: 64, tps: 0.00, reads: 0.00, writes: 49992.08, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2372s] threads: 64, tps: 0.00, reads: 0.00, writes: 49098.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2373s] threads: 64, tps: 0.00, reads: 0.00, writes: 50244.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2374s] threads: 64, tps: 0.00, reads: 0.00, writes: 49956.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2375s] threads: 64, tps: 0.00, reads: 0.00, writes: 48079.98, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2376s] threads: 64, tps: 0.00, reads: 0.00, writes: 50145.96, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2377s] threads: 64, tps: 0.00, reads: 0.00, writes: 49815.07, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2378s] threads: 64, tps: 0.00, reads: 0.00, writes: 42002.94, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2379s] threads: 64, tps: 0.00, reads: 0.00, writes: 47861.00, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2380s] threads: 64, tps: 0.00, reads: 0.00, writes: 47437.01, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2381s] threads: 64, tps: 0.00, reads: 0.00, writes: 47208.03, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2382s] threads: 64, tps: 0.00, reads: 0.00, writes: 36438.80, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[2383s] threads: 64, tps: 0.00, reads: 0.00, writes: 44567.23, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2384s] threads: 64, tps: 0.00, reads: 0.00, writes: 34675.97, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[2385s] threads: 64, tps: 0.00, reads: 0.00, writes: 33251.03, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[2386s] threads: 64, tps: 0.00, reads: 0.00, writes: 37414.98, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2387s] threads: 64, tps: 0.00, reads: 0.00, writes: 43477.99, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2388s] threads: 64, tps: 0.00, reads: 0.00, writes: 44793.05, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2389s] threads: 64, tps: 0.00, reads: 0.00, writes: 46370.95, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2390s] threads: 64, tps: 0.00, reads: 0.00, writes: 42778.02, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2391s] threads: 64, tps: 0.00, reads: 0.00, writes: 43472.94, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2392s] threads: 64, tps: 0.00, reads: 0.00, writes: 44324.03, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2393s] threads: 64, tps: 0.00, reads: 0.00, writes: 44255.05, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2394s] threads: 64, tps: 0.00, reads: 0.00, writes: 48143.95, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2395s] threads: 64, tps: 0.00, reads: 0.00, writes: 37923.02, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2396s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.00, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[2397s] threads: 64, tps: 0.00, reads: 0.00, writes: 3227.97, response time: 20.65ms (95%), errors: 0.00, reconnects:  0.00
[2398s] threads: 64, tps: 0.00, reads: 0.00, writes: 27636.25, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[2399s] threads: 64, tps: 0.00, reads: 0.00, writes: 39427.97, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2400s] threads: 64, tps: 0.00, reads: 0.00, writes: 44833.02, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2401s] threads: 64, tps: 0.00, reads: 0.00, writes: 49837.07, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2402s] threads: 64, tps: 0.00, reads: 0.00, writes: 49337.97, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2403s] threads: 64, tps: 0.00, reads: 0.00, writes: 48623.76, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2404s] threads: 64, tps: 0.00, reads: 0.00, writes: 49133.31, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2405s] threads: 64, tps: 0.00, reads: 0.00, writes: 48831.92, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2406s] threads: 64, tps: 0.00, reads: 0.00, writes: 48846.05, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2407s] threads: 64, tps: 0.00, reads: 0.00, writes: 48550.93, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2408s] threads: 64, tps: 0.00, reads: 0.00, writes: 48690.08, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2409s] threads: 64, tps: 0.00, reads: 0.00, writes: 48531.90, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2410s] threads: 64, tps: 0.00, reads: 0.00, writes: 49043.03, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2411s] threads: 64, tps: 0.00, reads: 0.00, writes: 48834.24, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2412s] threads: 64, tps: 0.00, reads: 0.00, writes: 48464.71, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2413s] threads: 64, tps: 0.00, reads: 0.00, writes: 49382.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2414s] threads: 64, tps: 0.00, reads: 0.00, writes: 48918.02, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2415s] threads: 64, tps: 0.00, reads: 0.00, writes: 50611.02, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2416s] threads: 64, tps: 0.00, reads: 0.00, writes: 50163.04, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2417s] threads: 64, tps: 0.00, reads: 0.00, writes: 47832.97, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2418s] threads: 64, tps: 0.00, reads: 0.00, writes: 42540.77, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2419s] threads: 64, tps: 0.00, reads: 0.00, writes: 49506.84, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2420s] threads: 64, tps: 0.00, reads: 0.00, writes: 50486.14, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2421s] threads: 64, tps: 0.00, reads: 0.00, writes: 50598.06, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2422s] threads: 64, tps: 0.00, reads: 0.00, writes: 49812.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2423s] threads: 64, tps: 0.00, reads: 0.00, writes: 49227.89, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2424s] threads: 64, tps: 0.00, reads: 0.00, writes: 48968.07, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2425s] threads: 64, tps: 0.00, reads: 0.00, writes: 45920.02, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2426s] threads: 64, tps: 0.00, reads: 0.00, writes: 32136.04, response time: 3.43ms (95%), errors: 0.00, reconnects:  0.00
[2427s] threads: 64, tps: 0.00, reads: 0.00, writes: 32170.32, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[2428s] threads: 64, tps: 0.00, reads: 0.00, writes: 34019.69, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[2429s] threads: 64, tps: 0.00, reads: 0.00, writes: 36214.99, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[2430s] threads: 64, tps: 0.00, reads: 0.00, writes: 46201.95, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2431s] threads: 64, tps: 0.00, reads: 0.00, writes: 35824.05, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[2432s] threads: 64, tps: 0.00, reads: 0.00, writes: 35541.94, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[2433s] threads: 64, tps: 0.00, reads: 0.00, writes: 43102.00, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2434s] threads: 64, tps: 0.00, reads: 0.00, writes: 41106.04, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2435s] threads: 64, tps: 0.00, reads: 0.00, writes: 46315.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2436s] threads: 64, tps: 0.00, reads: 0.00, writes: 46734.07, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2437s] threads: 64, tps: 0.00, reads: 0.00, writes: 33286.24, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[2438s] threads: 64, tps: 0.00, reads: 0.00, writes: 3232.06, response time: 20.82ms (95%), errors: 0.00, reconnects:  0.00
[2439s] threads: 64, tps: 0.00, reads: 0.00, writes: 3200.00, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[2440s] threads: 64, tps: 0.00, reads: 0.00, writes: 3254.01, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[2441s] threads: 64, tps: 0.00, reads: 0.00, writes: 3215.00, response time: 21.17ms (95%), errors: 0.00, reconnects:  0.00
[2442s] threads: 64, tps: 0.00, reads: 0.00, writes: 3211.99, response time: 20.65ms (95%), errors: 0.00, reconnects:  0.00
[2443s] threads: 64, tps: 0.00, reads: 0.00, writes: 5731.90, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[2444s] threads: 64, tps: 0.00, reads: 0.00, writes: 31925.63, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[2445s] threads: 64, tps: 0.00, reads: 0.00, writes: 37485.03, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[2446s] threads: 64, tps: 0.00, reads: 0.00, writes: 43335.00, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2447s] threads: 64, tps: 0.00, reads: 0.00, writes: 47364.98, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2448s] threads: 64, tps: 0.00, reads: 0.00, writes: 40461.03, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2449s] threads: 64, tps: 0.00, reads: 0.00, writes: 40272.95, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[2450s] threads: 64, tps: 0.00, reads: 0.00, writes: 40248.01, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[2451s] threads: 64, tps: 0.00, reads: 0.00, writes: 42577.05, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2452s] threads: 64, tps: 0.00, reads: 0.00, writes: 49125.95, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2453s] threads: 64, tps: 0.00, reads: 0.00, writes: 46482.77, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2454s] threads: 64, tps: 0.00, reads: 0.00, writes: 47956.25, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2455s] threads: 64, tps: 0.00, reads: 0.00, writes: 49719.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2456s] threads: 64, tps: 0.00, reads: 0.00, writes: 47648.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2457s] threads: 64, tps: 0.00, reads: 0.00, writes: 48749.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2458s] threads: 64, tps: 0.00, reads: 0.00, writes: 48877.96, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2459s] threads: 64, tps: 0.00, reads: 0.00, writes: 49658.97, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2460s] threads: 64, tps: 0.00, reads: 0.00, writes: 49608.04, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2461s] threads: 64, tps: 0.00, reads: 0.00, writes: 48738.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2462s] threads: 64, tps: 0.00, reads: 0.00, writes: 48460.02, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2463s] threads: 64, tps: 0.00, reads: 0.00, writes: 47632.95, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2464s] threads: 64, tps: 0.00, reads: 0.00, writes: 41312.05, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2465s] threads: 64, tps: 0.00, reads: 0.00, writes: 50022.01, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2466s] threads: 64, tps: 0.00, reads: 0.00, writes: 49724.98, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2467s] threads: 64, tps: 0.00, reads: 0.00, writes: 49434.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2468s] threads: 64, tps: 0.00, reads: 0.00, writes: 49330.94, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2469s] threads: 64, tps: 0.00, reads: 0.00, writes: 48983.82, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2470s] threads: 64, tps: 0.00, reads: 0.00, writes: 49872.18, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2471s] threads: 64, tps: 0.00, reads: 0.00, writes: 50218.97, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2472s] threads: 64, tps: 0.00, reads: 0.00, writes: 49342.19, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2473s] threads: 64, tps: 0.00, reads: 0.00, writes: 49623.84, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2474s] threads: 64, tps: 0.00, reads: 0.00, writes: 48617.01, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2475s] threads: 64, tps: 0.00, reads: 0.00, writes: 49621.98, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2476s] threads: 64, tps: 0.00, reads: 0.00, writes: 49754.97, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2477s] threads: 64, tps: 0.00, reads: 0.00, writes: 48135.06, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2478s] threads: 64, tps: 0.00, reads: 0.00, writes: 48624.00, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2479s] threads: 64, tps: 0.00, reads: 0.00, writes: 48831.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2480s] threads: 64, tps: 0.00, reads: 0.00, writes: 47231.95, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2481s] threads: 64, tps: 0.00, reads: 0.00, writes: 42423.97, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2482s] threads: 64, tps: 0.00, reads: 0.00, writes: 34272.01, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[2483s] threads: 64, tps: 0.00, reads: 0.00, writes: 33058.91, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[2484s] threads: 64, tps: 0.00, reads: 0.00, writes: 38275.13, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[2485s] threads: 64, tps: 0.00, reads: 0.00, writes: 48042.98, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2486s] threads: 64, tps: 0.00, reads: 0.00, writes: 47186.05, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2487s] threads: 64, tps: 0.00, reads: 0.00, writes: 10515.98, response time: 20.36ms (95%), errors: 0.00, reconnects:  0.00
[2488s] threads: 64, tps: 0.00, reads: 0.00, writes: 3226.01, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[2489s] threads: 64, tps: 0.00, reads: 0.00, writes: 3236.00, response time: 20.54ms (95%), errors: 0.00, reconnects:  0.00
[2490s] threads: 64, tps: 0.00, reads: 0.00, writes: 3226.00, response time: 20.40ms (95%), errors: 0.00, reconnects:  0.00
[2491s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.99, response time: 20.46ms (95%), errors: 0.00, reconnects:  0.00
[2492s] threads: 64, tps: 0.00, reads: 0.00, writes: 3211.00, response time: 20.50ms (95%), errors: 0.00, reconnects:  0.00
[2493s] threads: 64, tps: 0.00, reads: 0.00, writes: 3225.00, response time: 20.47ms (95%), errors: 0.00, reconnects:  0.00
[2494s] threads: 64, tps: 0.00, reads: 0.00, writes: 3251.94, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[2495s] threads: 64, tps: 0.00, reads: 0.00, writes: 3217.98, response time: 20.50ms (95%), errors: 0.00, reconnects:  0.00
[2496s] threads: 64, tps: 0.00, reads: 0.00, writes: 28751.61, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[2497s] threads: 64, tps: 0.00, reads: 0.00, writes: 37285.11, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2498s] threads: 64, tps: 0.00, reads: 0.00, writes: 42853.99, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2499s] threads: 64, tps: 0.00, reads: 0.00, writes: 48316.08, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2500s] threads: 64, tps: 0.00, reads: 0.00, writes: 41869.82, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2501s] threads: 64, tps: 0.00, reads: 0.00, writes: 45854.03, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2502s] threads: 64, tps: 0.00, reads: 0.00, writes: 48472.20, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2503s] threads: 64, tps: 0.00, reads: 0.00, writes: 48973.78, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2504s] threads: 64, tps: 0.00, reads: 0.00, writes: 51599.24, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2505s] threads: 64, tps: 0.00, reads: 0.00, writes: 49585.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2506s] threads: 64, tps: 0.00, reads: 0.00, writes: 50615.81, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2507s] threads: 64, tps: 0.00, reads: 0.00, writes: 49439.24, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2508s] threads: 64, tps: 0.00, reads: 0.00, writes: 51111.91, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2509s] threads: 64, tps: 0.00, reads: 0.00, writes: 41825.71, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2510s] threads: 64, tps: 0.00, reads: 0.00, writes: 49467.44, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2511s] threads: 64, tps: 0.00, reads: 0.00, writes: 50158.88, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2512s] threads: 64, tps: 0.00, reads: 0.00, writes: 49771.04, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2513s] threads: 64, tps: 0.00, reads: 0.00, writes: 51162.09, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2514s] threads: 64, tps: 0.00, reads: 0.00, writes: 47863.82, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2515s] threads: 64, tps: 0.00, reads: 0.00, writes: 48409.15, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2516s] threads: 64, tps: 0.00, reads: 0.00, writes: 48704.95, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2517s] threads: 64, tps: 0.00, reads: 0.00, writes: 49679.10, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2518s] threads: 64, tps: 0.00, reads: 0.00, writes: 49887.83, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2519s] threads: 64, tps: 0.00, reads: 0.00, writes: 49784.15, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2520s] threads: 64, tps: 0.00, reads: 0.00, writes: 48710.95, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2521s] threads: 64, tps: 0.00, reads: 0.00, writes: 48862.84, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2522s] threads: 64, tps: 0.00, reads: 0.00, writes: 47888.17, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2523s] threads: 64, tps: 0.00, reads: 0.00, writes: 46472.92, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2524s] threads: 64, tps: 0.00, reads: 0.00, writes: 37334.03, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[2525s] threads: 64, tps: 0.00, reads: 0.00, writes: 32912.97, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[2526s] threads: 64, tps: 0.00, reads: 0.00, writes: 32267.03, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[2527s] threads: 64, tps: 0.00, reads: 0.00, writes: 41473.26, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2528s] threads: 64, tps: 0.00, reads: 0.00, writes: 45190.79, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2529s] threads: 64, tps: 0.00, reads: 0.00, writes: 32191.02, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[2530s] threads: 64, tps: 0.00, reads: 0.00, writes: 32716.99, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[2531s] threads: 64, tps: 0.00, reads: 0.00, writes: 33188.93, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[2532s] threads: 64, tps: 0.00, reads: 0.00, writes: 35246.90, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[2533s] threads: 64, tps: 0.00, reads: 0.00, writes: 38598.34, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[2534s] threads: 64, tps: 0.00, reads: 0.00, writes: 48081.96, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2535s] threads: 64, tps: 0.00, reads: 0.00, writes: 47189.99, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2536s] threads: 64, tps: 0.00, reads: 0.00, writes: 44308.01, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2537s] threads: 64, tps: 0.00, reads: 0.00, writes: 44205.65, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2538s] threads: 64, tps: 0.00, reads: 0.00, writes: 44345.43, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2539s] threads: 64, tps: 0.00, reads: 0.00, writes: 47618.83, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2540s] threads: 64, tps: 0.00, reads: 0.00, writes: 34952.02, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2541s] threads: 64, tps: 0.00, reads: 0.00, writes: 3229.99, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[2542s] threads: 64, tps: 0.00, reads: 0.00, writes: 3223.01, response time: 20.50ms (95%), errors: 0.00, reconnects:  0.00
[2543s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.94, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[2544s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.06, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[2545s] threads: 64, tps: 0.00, reads: 0.00, writes: 23886.04, response time: 13.56ms (95%), errors: 0.00, reconnects:  0.00
[2546s] threads: 64, tps: 0.00, reads: 0.00, writes: 41735.86, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2547s] threads: 64, tps: 0.00, reads: 0.00, writes: 45880.18, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2548s] threads: 64, tps: 0.00, reads: 0.00, writes: 48707.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2549s] threads: 64, tps: 0.00, reads: 0.00, writes: 49244.03, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2550s] threads: 64, tps: 0.00, reads: 0.00, writes: 48975.96, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2551s] threads: 64, tps: 0.00, reads: 0.00, writes: 49026.96, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2552s] threads: 64, tps: 0.00, reads: 0.00, writes: 48495.06, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2553s] threads: 64, tps: 0.00, reads: 0.00, writes: 43579.96, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2554s] threads: 64, tps: 0.00, reads: 0.00, writes: 48663.05, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2555s] threads: 64, tps: 0.00, reads: 0.00, writes: 49279.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2556s] threads: 64, tps: 0.00, reads: 0.00, writes: 49583.04, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2557s] threads: 64, tps: 0.00, reads: 0.00, writes: 50213.96, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2558s] threads: 64, tps: 0.00, reads: 0.00, writes: 49465.05, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2559s] threads: 64, tps: 0.00, reads: 0.00, writes: 49293.05, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2560s] threads: 64, tps: 0.00, reads: 0.00, writes: 49675.87, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2561s] threads: 64, tps: 0.00, reads: 0.00, writes: 48884.11, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2562s] threads: 64, tps: 0.00, reads: 0.00, writes: 50264.06, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2563s] threads: 64, tps: 0.00, reads: 0.00, writes: 50544.85, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2564s] threads: 64, tps: 0.00, reads: 0.00, writes: 49416.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2565s] threads: 64, tps: 0.00, reads: 0.00, writes: 49486.02, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2566s] threads: 64, tps: 0.00, reads: 0.00, writes: 49718.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2567s] threads: 64, tps: 0.00, reads: 0.00, writes: 47737.01, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2568s] threads: 64, tps: 0.00, reads: 0.00, writes: 48655.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2569s] threads: 64, tps: 0.00, reads: 0.00, writes: 48604.90, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2570s] threads: 64, tps: 0.00, reads: 0.00, writes: 45274.85, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2571s] threads: 64, tps: 0.00, reads: 0.00, writes: 47272.18, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2572s] threads: 64, tps: 0.00, reads: 0.00, writes: 43932.07, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2573s] threads: 64, tps: 0.00, reads: 0.00, writes: 32548.01, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[2574s] threads: 64, tps: 0.00, reads: 0.00, writes: 34420.99, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[2575s] threads: 64, tps: 0.00, reads: 0.00, writes: 35242.01, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[2576s] threads: 64, tps: 0.00, reads: 0.00, writes: 33971.94, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[2577s] threads: 64, tps: 0.00, reads: 0.00, writes: 47069.07, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2578s] threads: 64, tps: 0.00, reads: 0.00, writes: 43489.07, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2579s] threads: 64, tps: 0.00, reads: 0.00, writes: 42974.93, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2580s] threads: 64, tps: 0.00, reads: 0.00, writes: 43826.02, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2581s] threads: 64, tps: 0.00, reads: 0.00, writes: 43947.02, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2582s] threads: 64, tps: 0.00, reads: 0.00, writes: 45896.96, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2583s] threads: 64, tps: 0.00, reads: 0.00, writes: 45627.04, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2584s] threads: 64, tps: 0.00, reads: 0.00, writes: 11923.02, response time: 20.16ms (95%), errors: 0.00, reconnects:  0.00
[2585s] threads: 64, tps: 0.00, reads: 0.00, writes: 3240.98, response time: 20.44ms (95%), errors: 0.00, reconnects:  0.00
[2586s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.94, response time: 20.49ms (95%), errors: 0.00, reconnects:  0.00
[2587s] threads: 64, tps: 0.00, reads: 0.00, writes: 3211.06, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[2588s] threads: 64, tps: 0.00, reads: 0.00, writes: 3232.00, response time: 20.93ms (95%), errors: 0.00, reconnects:  0.00
[2589s] threads: 64, tps: 0.00, reads: 0.00, writes: 6337.00, response time: 20.47ms (95%), errors: 0.00, reconnects:  0.00
[2590s] threads: 64, tps: 0.00, reads: 0.00, writes: 34463.02, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[2591s] threads: 64, tps: 0.00, reads: 0.00, writes: 36638.97, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2592s] threads: 64, tps: 0.00, reads: 0.00, writes: 37644.03, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2593s] threads: 64, tps: 0.00, reads: 0.00, writes: 48317.96, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2594s] threads: 64, tps: 0.00, reads: 0.00, writes: 41146.06, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2595s] threads: 64, tps: 0.00, reads: 0.00, writes: 45696.97, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2596s] threads: 64, tps: 0.00, reads: 0.00, writes: 47732.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2597s] threads: 64, tps: 0.00, reads: 0.00, writes: 39451.99, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[2598s] threads: 64, tps: 0.00, reads: 0.00, writes: 49440.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2599s] threads: 64, tps: 0.00, reads: 0.00, writes: 49867.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2600s] threads: 64, tps: 0.00, reads: 0.00, writes: 49820.94, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2601s] threads: 64, tps: 0.00, reads: 0.00, writes: 49959.01, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2602s] threads: 64, tps: 0.00, reads: 0.00, writes: 49217.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2603s] threads: 64, tps: 0.00, reads: 0.00, writes: 50095.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2604s] threads: 64, tps: 0.00, reads: 0.00, writes: 48537.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2605s] threads: 64, tps: 0.00, reads: 0.00, writes: 48790.00, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2606s] threads: 64, tps: 0.00, reads: 0.00, writes: 48268.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2607s] threads: 64, tps: 0.00, reads: 0.00, writes: 51088.04, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2608s] threads: 64, tps: 0.00, reads: 0.00, writes: 50550.93, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2609s] threads: 64, tps: 0.00, reads: 0.00, writes: 49094.33, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2610s] threads: 64, tps: 0.00, reads: 0.00, writes: 48266.69, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2611s] threads: 64, tps: 0.00, reads: 0.00, writes: 46658.01, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2612s] threads: 64, tps: 0.00, reads: 0.00, writes: 50518.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2613s] threads: 64, tps: 0.00, reads: 0.00, writes: 49473.08, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2614s] threads: 64, tps: 0.00, reads: 0.00, writes: 49457.93, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2615s] threads: 64, tps: 0.00, reads: 0.00, writes: 49110.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2616s] threads: 64, tps: 0.00, reads: 0.00, writes: 45288.05, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2617s] threads: 64, tps: 0.00, reads: 0.00, writes: 46492.05, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2618s] threads: 64, tps: 0.00, reads: 0.00, writes: 37684.77, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[2619s] threads: 64, tps: 0.00, reads: 0.00, writes: 33356.15, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[2620s] threads: 64, tps: 0.00, reads: 0.00, writes: 32632.01, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[2621s] threads: 64, tps: 0.00, reads: 0.00, writes: 32183.99, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[2622s] threads: 64, tps: 0.00, reads: 0.00, writes: 41243.00, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2623s] threads: 64, tps: 0.00, reads: 0.00, writes: 40546.02, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[2624s] threads: 64, tps: 0.00, reads: 0.00, writes: 35182.99, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[2625s] threads: 64, tps: 0.00, reads: 0.00, writes: 34102.98, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[2626s] threads: 64, tps: 0.00, reads: 0.00, writes: 32766.02, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[2627s] threads: 64, tps: 0.00, reads: 0.00, writes: 44317.97, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2628s] threads: 64, tps: 0.00, reads: 0.00, writes: 46605.06, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2629s] threads: 64, tps: 0.00, reads: 0.00, writes: 47167.92, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2630s] threads: 64, tps: 0.00, reads: 0.00, writes: 43109.99, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2631s] threads: 64, tps: 0.00, reads: 0.00, writes: 44093.02, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2632s] threads: 64, tps: 0.00, reads: 0.00, writes: 40178.04, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2633s] threads: 64, tps: 0.00, reads: 0.00, writes: 44960.00, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2634s] threads: 64, tps: 0.00, reads: 0.00, writes: 46586.97, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2635s] threads: 64, tps: 0.00, reads: 0.00, writes: 24272.01, response time: 19.70ms (95%), errors: 0.00, reconnects:  0.00
[2636s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.99, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[2637s] threads: 64, tps: 0.00, reads: 0.00, writes: 3221.94, response time: 20.54ms (95%), errors: 0.00, reconnects:  0.00
[2638s] threads: 64, tps: 0.00, reads: 0.00, writes: 24008.51, response time: 11.51ms (95%), errors: 0.00, reconnects:  0.00
[2639s] threads: 64, tps: 0.00, reads: 0.00, writes: 34290.06, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2640s] threads: 64, tps: 0.00, reads: 0.00, writes: 42169.88, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2641s] threads: 64, tps: 0.00, reads: 0.00, writes: 47514.20, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2642s] threads: 64, tps: 0.00, reads: 0.00, writes: 47682.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2643s] threads: 64, tps: 0.00, reads: 0.00, writes: 46737.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2644s] threads: 64, tps: 0.00, reads: 0.00, writes: 48896.07, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2645s] threads: 64, tps: 0.00, reads: 0.00, writes: 48412.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2646s] threads: 64, tps: 0.00, reads: 0.00, writes: 51454.01, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2647s] threads: 64, tps: 0.00, reads: 0.00, writes: 48212.92, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2648s] threads: 64, tps: 0.00, reads: 0.00, writes: 48906.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2649s] threads: 64, tps: 0.00, reads: 0.00, writes: 47528.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2650s] threads: 64, tps: 0.00, reads: 0.00, writes: 47576.94, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2651s] threads: 64, tps: 0.00, reads: 0.00, writes: 51199.34, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2652s] threads: 64, tps: 0.00, reads: 0.00, writes: 47085.53, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2653s] threads: 64, tps: 0.00, reads: 0.00, writes: 48885.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2654s] threads: 64, tps: 0.00, reads: 0.00, writes: 48647.00, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2655s] threads: 64, tps: 0.00, reads: 0.00, writes: 45844.95, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2656s] threads: 64, tps: 0.00, reads: 0.00, writes: 49530.12, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2657s] threads: 64, tps: 0.00, reads: 0.00, writes: 48466.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2658s] threads: 64, tps: 0.00, reads: 0.00, writes: 49142.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2659s] threads: 64, tps: 0.00, reads: 0.00, writes: 50799.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2660s] threads: 64, tps: 0.00, reads: 0.00, writes: 50366.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2661s] threads: 64, tps: 0.00, reads: 0.00, writes: 48357.95, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2662s] threads: 64, tps: 0.00, reads: 0.00, writes: 44686.99, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2663s] threads: 64, tps: 0.00, reads: 0.00, writes: 33268.01, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[2664s] threads: 64, tps: 0.00, reads: 0.00, writes: 32416.03, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[2665s] threads: 64, tps: 0.00, reads: 0.00, writes: 45274.99, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2666s] threads: 64, tps: 0.00, reads: 0.00, writes: 40074.02, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[2667s] threads: 64, tps: 0.00, reads: 0.00, writes: 31721.98, response time: 3.82ms (95%), errors: 0.00, reconnects:  0.00
[2668s] threads: 64, tps: 0.00, reads: 0.00, writes: 32935.03, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[2669s] threads: 64, tps: 0.00, reads: 0.00, writes: 32657.88, response time: 3.34ms (95%), errors: 0.00, reconnects:  0.00
[2670s] threads: 64, tps: 0.00, reads: 0.00, writes: 35542.51, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[2671s] threads: 64, tps: 0.00, reads: 0.00, writes: 44030.93, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2672s] threads: 64, tps: 0.00, reads: 0.00, writes: 44525.99, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2673s] threads: 64, tps: 0.00, reads: 0.00, writes: 42800.08, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2674s] threads: 64, tps: 0.00, reads: 0.00, writes: 43397.95, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[2675s] threads: 64, tps: 0.00, reads: 0.00, writes: 43653.97, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2676s] threads: 64, tps: 0.00, reads: 0.00, writes: 44113.02, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2677s] threads: 64, tps: 0.00, reads: 0.00, writes: 48482.00, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2678s] threads: 64, tps: 0.00, reads: 0.00, writes: 21591.02, response time: 19.38ms (95%), errors: 0.00, reconnects:  0.00
[2679s] threads: 64, tps: 0.00, reads: 0.00, writes: 3237.00, response time: 20.72ms (95%), errors: 0.00, reconnects:  0.00
[2680s] threads: 64, tps: 0.00, reads: 0.00, writes: 3210.93, response time: 20.58ms (95%), errors: 0.00, reconnects:  0.00
[2681s] threads: 64, tps: 0.00, reads: 0.00, writes: 3240.07, response time: 20.55ms (95%), errors: 0.00, reconnects:  0.00
[2682s] threads: 64, tps: 0.00, reads: 0.00, writes: 22101.27, response time: 18.89ms (95%), errors: 0.00, reconnects:  0.00
[2683s] threads: 64, tps: 0.00, reads: 0.00, writes: 36942.16, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2684s] threads: 64, tps: 0.00, reads: 0.00, writes: 36659.00, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2685s] threads: 64, tps: 0.00, reads: 0.00, writes: 44563.98, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2686s] threads: 64, tps: 0.00, reads: 0.00, writes: 45426.30, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2687s] threads: 64, tps: 0.00, reads: 0.00, writes: 41236.66, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2688s] threads: 64, tps: 0.00, reads: 0.00, writes: 43718.04, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2689s] threads: 64, tps: 0.00, reads: 0.00, writes: 45894.99, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2690s] threads: 64, tps: 0.00, reads: 0.00, writes: 49879.97, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2691s] threads: 64, tps: 0.00, reads: 0.00, writes: 51702.02, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2692s] threads: 64, tps: 0.00, reads: 0.00, writes: 47596.01, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2693s] threads: 64, tps: 0.00, reads: 0.00, writes: 49040.99, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2694s] threads: 64, tps: 0.00, reads: 0.00, writes: 49269.00, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2695s] threads: 64, tps: 0.00, reads: 0.00, writes: 50044.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2696s] threads: 64, tps: 0.00, reads: 0.00, writes: 48563.87, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2697s] threads: 64, tps: 0.00, reads: 0.00, writes: 49176.17, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2698s] threads: 64, tps: 0.00, reads: 0.00, writes: 49541.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2699s] threads: 64, tps: 0.00, reads: 0.00, writes: 48941.02, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2700s] threads: 64, tps: 0.00, reads: 0.00, writes: 50150.91, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2701s] threads: 64, tps: 0.00, reads: 0.00, writes: 49933.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2702s] threads: 64, tps: 0.00, reads: 0.00, writes: 49344.03, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2703s] threads: 64, tps: 0.00, reads: 0.00, writes: 48954.98, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2704s] threads: 64, tps: 0.00, reads: 0.00, writes: 49938.97, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2705s] threads: 64, tps: 0.00, reads: 0.00, writes: 48512.02, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2706s] threads: 64, tps: 0.00, reads: 0.00, writes: 46416.03, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2707s] threads: 64, tps: 0.00, reads: 0.00, writes: 45232.95, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2708s] threads: 64, tps: 0.00, reads: 0.00, writes: 36665.00, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[2709s] threads: 64, tps: 0.00, reads: 0.00, writes: 44753.05, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2710s] threads: 64, tps: 0.00, reads: 0.00, writes: 40055.98, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[2711s] threads: 64, tps: 0.00, reads: 0.00, writes: 35536.00, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[2712s] threads: 64, tps: 0.00, reads: 0.00, writes: 41785.03, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[2713s] threads: 64, tps: 0.00, reads: 0.00, writes: 42587.02, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2714s] threads: 64, tps: 0.00, reads: 0.00, writes: 44942.98, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2715s] threads: 64, tps: 0.00, reads: 0.00, writes: 46195.86, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2716s] threads: 64, tps: 0.00, reads: 0.00, writes: 43424.88, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2717s] threads: 64, tps: 0.00, reads: 0.00, writes: 44339.27, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2718s] threads: 64, tps: 0.00, reads: 0.00, writes: 44616.99, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2719s] threads: 64, tps: 0.00, reads: 0.00, writes: 44772.00, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2720s] threads: 64, tps: 0.00, reads: 0.00, writes: 42142.61, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2721s] threads: 64, tps: 0.00, reads: 0.00, writes: 35912.97, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2722s] threads: 64, tps: 0.00, reads: 0.00, writes: 3240.05, response time: 20.50ms (95%), errors: 0.00, reconnects:  0.00
[2723s] threads: 64, tps: 0.00, reads: 0.00, writes: 14226.70, response time: 19.97ms (95%), errors: 0.00, reconnects:  0.00
[2724s] threads: 64, tps: 0.00, reads: 0.00, writes: 34011.77, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[2725s] threads: 64, tps: 0.00, reads: 0.00, writes: 42148.98, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2726s] threads: 64, tps: 0.00, reads: 0.00, writes: 47575.99, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2727s] threads: 64, tps: 0.00, reads: 0.00, writes: 50119.09, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2728s] threads: 64, tps: 0.00, reads: 0.00, writes: 48550.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2729s] threads: 64, tps: 0.00, reads: 0.00, writes: 48487.97, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2730s] threads: 64, tps: 0.00, reads: 0.00, writes: 49386.95, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2731s] threads: 64, tps: 0.00, reads: 0.00, writes: 49493.04, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2732s] threads: 64, tps: 0.00, reads: 0.00, writes: 50453.93, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2733s] threads: 64, tps: 0.00, reads: 0.00, writes: 48586.82, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2734s] threads: 64, tps: 0.00, reads: 0.00, writes: 50117.20, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2735s] threads: 64, tps: 0.00, reads: 0.00, writes: 49202.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2736s] threads: 64, tps: 0.00, reads: 0.00, writes: 51351.03, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2737s] threads: 64, tps: 0.00, reads: 0.00, writes: 49267.54, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2738s] threads: 64, tps: 0.00, reads: 0.00, writes: 48498.46, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2739s] threads: 64, tps: 0.00, reads: 0.00, writes: 49086.16, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2740s] threads: 64, tps: 0.00, reads: 0.00, writes: 46427.75, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2741s] threads: 64, tps: 0.00, reads: 0.00, writes: 50102.07, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2742s] threads: 64, tps: 0.00, reads: 0.00, writes: 50052.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2743s] threads: 64, tps: 0.00, reads: 0.00, writes: 49601.02, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2744s] threads: 64, tps: 0.00, reads: 0.00, writes: 49534.93, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2745s] threads: 64, tps: 0.00, reads: 0.00, writes: 50210.02, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2746s] threads: 64, tps: 0.00, reads: 0.00, writes: 50133.98, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2747s] threads: 64, tps: 0.00, reads: 0.00, writes: 49173.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2748s] threads: 64, tps: 0.00, reads: 0.00, writes: 46883.05, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2749s] threads: 64, tps: 0.00, reads: 0.00, writes: 47797.01, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2750s] threads: 64, tps: 0.00, reads: 0.00, writes: 43985.00, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2751s] threads: 64, tps: 0.00, reads: 0.00, writes: 35541.96, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[2752s] threads: 64, tps: 0.00, reads: 0.00, writes: 34716.03, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[2753s] threads: 64, tps: 0.00, reads: 0.00, writes: 26187.85, response time: 4.11ms (95%), errors: 0.00, reconnects:  0.00
[2754s] threads: 64, tps: 0.00, reads: 0.00, writes: 31978.23, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[2755s] threads: 64, tps: 0.00, reads: 0.00, writes: 36964.91, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[2756s] threads: 64, tps: 0.00, reads: 0.00, writes: 45161.03, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2757s] threads: 64, tps: 0.00, reads: 0.00, writes: 35216.11, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[2758s] threads: 64, tps: 0.00, reads: 0.00, writes: 34811.91, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[2759s] threads: 64, tps: 0.00, reads: 0.00, writes: 42086.95, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2760s] threads: 64, tps: 0.00, reads: 0.00, writes: 39856.59, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2761s] threads: 64, tps: 0.00, reads: 0.00, writes: 43920.49, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2762s] threads: 64, tps: 0.00, reads: 0.00, writes: 48385.12, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2763s] threads: 64, tps: 0.00, reads: 0.00, writes: 25635.93, response time: 19.11ms (95%), errors: 0.00, reconnects:  0.00
[2764s] threads: 64, tps: 0.00, reads: 0.00, writes: 3220.01, response time: 20.63ms (95%), errors: 0.00, reconnects:  0.00
[2765s] threads: 64, tps: 0.00, reads: 0.00, writes: 3238.00, response time: 20.48ms (95%), errors: 0.00, reconnects:  0.00
[2766s] threads: 64, tps: 0.00, reads: 0.00, writes: 3224.00, response time: 20.45ms (95%), errors: 0.00, reconnects:  0.00
[2767s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.99, response time: 20.42ms (95%), errors: 0.00, reconnects:  0.00
[2768s] threads: 64, tps: 0.00, reads: 0.00, writes: 3237.98, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[2769s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.02, response time: 20.32ms (95%), errors: 0.00, reconnects:  0.00
[2770s] threads: 64, tps: 0.00, reads: 0.00, writes: 18072.99, response time: 19.87ms (95%), errors: 0.00, reconnects:  0.00
[2771s] threads: 64, tps: 0.00, reads: 0.00, writes: 41449.00, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[2772s] threads: 64, tps: 0.00, reads: 0.00, writes: 45213.01, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2773s] threads: 64, tps: 0.00, reads: 0.00, writes: 47325.05, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2774s] threads: 64, tps: 0.00, reads: 0.00, writes: 49134.71, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2775s] threads: 64, tps: 0.00, reads: 0.00, writes: 48298.31, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2776s] threads: 64, tps: 0.00, reads: 0.00, writes: 49375.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2777s] threads: 64, tps: 0.00, reads: 0.00, writes: 48035.93, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2778s] threads: 64, tps: 0.00, reads: 0.00, writes: 49360.02, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2779s] threads: 64, tps: 0.00, reads: 0.00, writes: 47775.98, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2780s] threads: 64, tps: 0.00, reads: 0.00, writes: 49451.05, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2781s] threads: 64, tps: 0.00, reads: 0.00, writes: 49394.06, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2782s] threads: 64, tps: 0.00, reads: 0.00, writes: 50656.89, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2783s] threads: 64, tps: 0.00, reads: 0.00, writes: 49457.98, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2784s] threads: 64, tps: 0.00, reads: 0.00, writes: 49343.02, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2785s] threads: 64, tps: 0.00, reads: 0.00, writes: 48893.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2786s] threads: 64, tps: 0.00, reads: 0.00, writes: 49382.02, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2787s] threads: 64, tps: 0.00, reads: 0.00, writes: 49496.06, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2788s] threads: 64, tps: 0.00, reads: 0.00, writes: 49236.90, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2789s] threads: 64, tps: 0.00, reads: 0.00, writes: 49170.10, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2790s] threads: 64, tps: 0.00, reads: 0.00, writes: 46884.94, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2791s] threads: 64, tps: 0.00, reads: 0.00, writes: 49964.99, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2792s] threads: 64, tps: 0.00, reads: 0.00, writes: 48573.04, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2793s] threads: 64, tps: 0.00, reads: 0.00, writes: 48673.03, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2794s] threads: 64, tps: 0.00, reads: 0.00, writes: 48554.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2795s] threads: 64, tps: 0.00, reads: 0.00, writes: 47984.92, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2796s] threads: 64, tps: 0.00, reads: 0.00, writes: 50019.07, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2797s] threads: 64, tps: 0.00, reads: 0.00, writes: 48975.96, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2798s] threads: 64, tps: 0.00, reads: 0.00, writes: 49226.72, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2799s] threads: 64, tps: 0.00, reads: 0.00, writes: 48073.31, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2800s] threads: 64, tps: 0.00, reads: 0.00, writes: 47605.89, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2801s] threads: 64, tps: 0.00, reads: 0.00, writes: 49287.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2802s] threads: 64, tps: 0.00, reads: 0.00, writes: 49088.03, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2803s] threads: 64, tps: 0.00, reads: 0.00, writes: 38812.28, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2804s] threads: 64, tps: 0.00, reads: 0.00, writes: 46852.87, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2805s] threads: 64, tps: 0.00, reads: 0.00, writes: 47272.02, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2806s] threads: 64, tps: 0.00, reads: 0.00, writes: 46859.97, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2807s] threads: 64, tps: 0.00, reads: 0.00, writes: 37347.05, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[2808s] threads: 64, tps: 0.00, reads: 0.00, writes: 34198.44, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[2809s] threads: 64, tps: 0.00, reads: 0.00, writes: 32677.48, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[2810s] threads: 64, tps: 0.00, reads: 0.00, writes: 34854.99, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[2811s] threads: 64, tps: 0.00, reads: 0.00, writes: 41485.00, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[2812s] threads: 64, tps: 0.00, reads: 0.00, writes: 39073.15, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2813s] threads: 64, tps: 0.00, reads: 0.00, writes: 3208.07, response time: 20.51ms (95%), errors: 0.00, reconnects:  0.00
[2814s] threads: 64, tps: 0.00, reads: 0.00, writes: 3244.00, response time: 20.45ms (95%), errors: 0.00, reconnects:  0.00
[2815s] threads: 64, tps: 0.00, reads: 0.00, writes: 3219.00, response time: 20.33ms (95%), errors: 0.00, reconnects:  0.00
[2816s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.98, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[2817s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.01, response time: 20.50ms (95%), errors: 0.00, reconnects:  0.00
[2818s] threads: 64, tps: 0.00, reads: 0.00, writes: 3217.99, response time: 20.74ms (95%), errors: 0.00, reconnects:  0.00
[2819s] threads: 64, tps: 0.00, reads: 0.00, writes: 3227.95, response time: 20.45ms (95%), errors: 0.00, reconnects:  0.00
[2820s] threads: 64, tps: 0.00, reads: 0.00, writes: 3226.07, response time: 21.52ms (95%), errors: 0.00, reconnects:  0.00
[2821s] threads: 64, tps: 0.00, reads: 0.00, writes: 3223.98, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[2822s] threads: 64, tps: 0.00, reads: 0.00, writes: 3220.95, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[2823s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.06, response time: 20.84ms (95%), errors: 0.00, reconnects:  0.00
[2824s] threads: 64, tps: 0.00, reads: 0.00, writes: 3228.01, response time: 20.65ms (95%), errors: 0.00, reconnects:  0.00
[2825s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.92, response time: 20.60ms (95%), errors: 0.00, reconnects:  0.00
[2826s] threads: 64, tps: 0.00, reads: 0.00, writes: 25039.54, response time: 4.15ms (95%), errors: 0.00, reconnects:  0.00
[2827s] threads: 64, tps: 0.00, reads: 0.00, writes: 32922.13, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[2828s] threads: 64, tps: 0.00, reads: 0.00, writes: 40534.13, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[2829s] threads: 64, tps: 0.00, reads: 0.00, writes: 45703.97, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2830s] threads: 64, tps: 0.00, reads: 0.00, writes: 45773.41, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2831s] threads: 64, tps: 0.00, reads: 0.00, writes: 45331.38, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2832s] threads: 64, tps: 0.00, reads: 0.00, writes: 49118.23, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2833s] threads: 64, tps: 0.00, reads: 0.00, writes: 48800.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2834s] threads: 64, tps: 0.00, reads: 0.00, writes: 48019.72, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2835s] threads: 64, tps: 0.00, reads: 0.00, writes: 49912.33, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2836s] threads: 64, tps: 0.00, reads: 0.00, writes: 48725.99, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2837s] threads: 64, tps: 0.00, reads: 0.00, writes: 48186.99, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2838s] threads: 64, tps: 0.00, reads: 0.00, writes: 49901.96, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2839s] threads: 64, tps: 0.00, reads: 0.00, writes: 49839.11, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2840s] threads: 64, tps: 0.00, reads: 0.00, writes: 49665.92, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2841s] threads: 64, tps: 0.00, reads: 0.00, writes: 48037.08, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2842s] threads: 64, tps: 0.00, reads: 0.00, writes: 49672.93, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2843s] threads: 64, tps: 0.00, reads: 0.00, writes: 50162.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2844s] threads: 64, tps: 0.00, reads: 0.00, writes: 50640.96, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2845s] threads: 64, tps: 0.00, reads: 0.00, writes: 49595.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2846s] threads: 64, tps: 0.00, reads: 0.00, writes: 49189.08, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2847s] threads: 64, tps: 0.00, reads: 0.00, writes: 48880.90, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2848s] threads: 64, tps: 0.00, reads: 0.00, writes: 50189.01, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2849s] threads: 64, tps: 0.00, reads: 0.00, writes: 49028.10, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2850s] threads: 64, tps: 0.00, reads: 0.00, writes: 47671.00, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2851s] threads: 64, tps: 0.00, reads: 0.00, writes: 47455.95, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2852s] threads: 64, tps: 0.00, reads: 0.00, writes: 46524.09, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2853s] threads: 64, tps: 0.00, reads: 0.00, writes: 47590.90, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2854s] threads: 64, tps: 0.00, reads: 0.00, writes: 32034.02, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2855s] threads: 64, tps: 0.00, reads: 0.00, writes: 33104.00, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[2856s] threads: 64, tps: 0.00, reads: 0.00, writes: 34942.99, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[2857s] threads: 64, tps: 0.00, reads: 0.00, writes: 33848.01, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[2858s] threads: 64, tps: 0.00, reads: 0.00, writes: 40088.97, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2859s] threads: 64, tps: 0.00, reads: 0.00, writes: 44464.94, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2860s] threads: 64, tps: 0.00, reads: 0.00, writes: 34347.04, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[2861s] threads: 64, tps: 0.00, reads: 0.00, writes: 34499.39, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[2862s] threads: 64, tps: 0.00, reads: 0.00, writes: 32954.98, response time: 3.28ms (95%), errors: 0.00, reconnects:  0.00
[2863s] threads: 64, tps: 0.00, reads: 0.00, writes: 33462.50, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[2864s] threads: 64, tps: 0.00, reads: 0.00, writes: 38028.64, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[2865s] threads: 64, tps: 0.00, reads: 0.00, writes: 45638.52, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2866s] threads: 64, tps: 0.00, reads: 0.00, writes: 33463.67, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[2867s] threads: 64, tps: 0.00, reads: 0.00, writes: 39365.15, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[2868s] threads: 64, tps: 0.00, reads: 0.00, writes: 42048.23, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2869s] threads: 64, tps: 0.00, reads: 0.00, writes: 41403.02, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2870s] threads: 64, tps: 0.00, reads: 0.00, writes: 43951.95, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2871s] threads: 64, tps: 0.00, reads: 0.00, writes: 47063.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2872s] threads: 64, tps: 0.00, reads: 0.00, writes: 43399.04, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2873s] threads: 64, tps: 0.00, reads: 0.00, writes: 43429.98, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2874s] threads: 64, tps: 0.00, reads: 0.00, writes: 43062.00, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2875s] threads: 64, tps: 0.00, reads: 0.00, writes: 46392.04, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2876s] threads: 64, tps: 0.00, reads: 0.00, writes: 47443.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2877s] threads: 64, tps: 0.00, reads: 0.00, writes: 19053.96, response time: 19.92ms (95%), errors: 0.00, reconnects:  0.00
[2878s] threads: 64, tps: 0.00, reads: 0.00, writes: 3228.99, response time: 20.79ms (95%), errors: 0.00, reconnects:  0.00
[2879s] threads: 64, tps: 0.00, reads: 0.00, writes: 26299.11, response time: 3.70ms (95%), errors: 0.00, reconnects:  0.00
[2880s] threads: 64, tps: 0.00, reads: 0.00, writes: 38469.00, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2881s] threads: 64, tps: 0.00, reads: 0.00, writes: 42327.04, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2882s] threads: 64, tps: 0.00, reads: 0.00, writes: 45788.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2883s] threads: 64, tps: 0.00, reads: 0.00, writes: 46178.96, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2884s] threads: 64, tps: 0.00, reads: 0.00, writes: 44741.96, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2885s] threads: 64, tps: 0.00, reads: 0.00, writes: 44575.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2886s] threads: 64, tps: 0.00, reads: 0.00, writes: 44465.00, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2887s] threads: 64, tps: 0.00, reads: 0.00, writes: 48686.38, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2888s] threads: 64, tps: 0.00, reads: 0.00, writes: 47648.67, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2889s] threads: 64, tps: 0.00, reads: 0.00, writes: 44993.26, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2890s] threads: 64, tps: 0.00, reads: 0.00, writes: 45338.62, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2891s] threads: 64, tps: 0.00, reads: 0.00, writes: 47680.92, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2892s] threads: 64, tps: 0.00, reads: 0.00, writes: 49663.16, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2893s] threads: 64, tps: 0.00, reads: 0.00, writes: 48159.00, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2894s] threads: 64, tps: 0.00, reads: 0.00, writes: 49154.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2895s] threads: 64, tps: 0.00, reads: 0.00, writes: 46988.98, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2896s] threads: 64, tps: 0.00, reads: 0.00, writes: 49160.17, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2897s] threads: 64, tps: 0.00, reads: 0.00, writes: 43804.14, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2898s] threads: 64, tps: 0.00, reads: 0.00, writes: 48432.02, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2899s] threads: 64, tps: 0.00, reads: 0.00, writes: 48573.25, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2900s] threads: 64, tps: 0.00, reads: 0.00, writes: 47871.75, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2901s] threads: 64, tps: 0.00, reads: 0.00, writes: 49631.96, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2902s] threads: 64, tps: 0.00, reads: 0.00, writes: 48192.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2903s] threads: 64, tps: 0.00, reads: 0.00, writes: 49110.01, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2904s] threads: 64, tps: 0.00, reads: 0.00, writes: 49191.96, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2905s] threads: 64, tps: 0.00, reads: 0.00, writes: 46823.77, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2906s] threads: 64, tps: 0.00, reads: 0.00, writes: 49327.26, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2907s] threads: 64, tps: 0.00, reads: 0.00, writes: 47713.01, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2908s] threads: 64, tps: 0.00, reads: 0.00, writes: 39320.99, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[2909s] threads: 64, tps: 0.00, reads: 0.00, writes: 33506.01, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[2910s] threads: 64, tps: 0.00, reads: 0.00, writes: 34003.99, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[2911s] threads: 64, tps: 0.00, reads: 0.00, writes: 38129.06, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[2912s] threads: 64, tps: 0.00, reads: 0.00, writes: 46416.91, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2913s] threads: 64, tps: 0.00, reads: 0.00, writes: 44496.96, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2914s] threads: 64, tps: 0.00, reads: 0.00, writes: 43438.09, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2915s] threads: 64, tps: 0.00, reads: 0.00, writes: 42755.03, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2916s] threads: 64, tps: 0.00, reads: 0.00, writes: 44349.89, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2917s] threads: 64, tps: 0.00, reads: 0.00, writes: 47264.05, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2918s] threads: 64, tps: 0.00, reads: 0.00, writes: 46771.06, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2919s] threads: 64, tps: 0.00, reads: 0.00, writes: 3379.00, response time: 20.81ms (95%), errors: 0.00, reconnects:  0.00
[2920s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.95, response time: 20.85ms (95%), errors: 0.00, reconnects:  0.00
[2921s] threads: 64, tps: 0.00, reads: 0.00, writes: 3214.04, response time: 20.84ms (95%), errors: 0.00, reconnects:  0.00
[2922s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.01, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[2923s] threads: 64, tps: 0.00, reads: 0.00, writes: 11395.99, response time: 20.08ms (95%), errors: 0.00, reconnects:  0.00
[2924s] threads: 64, tps: 0.00, reads: 0.00, writes: 34837.01, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[2925s] threads: 64, tps: 0.00, reads: 0.00, writes: 35641.04, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2926s] threads: 64, tps: 0.00, reads: 0.00, writes: 42928.90, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2927s] threads: 64, tps: 0.00, reads: 0.00, writes: 44780.04, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2928s] threads: 64, tps: 0.00, reads: 0.00, writes: 41604.03, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2929s] threads: 64, tps: 0.00, reads: 0.00, writes: 43608.00, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2930s] threads: 64, tps: 0.00, reads: 0.00, writes: 48743.80, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2931s] threads: 64, tps: 0.00, reads: 0.00, writes: 49245.15, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2932s] threads: 64, tps: 0.00, reads: 0.00, writes: 50120.03, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2933s] threads: 64, tps: 0.00, reads: 0.00, writes: 49252.88, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2934s] threads: 64, tps: 0.00, reads: 0.00, writes: 49982.19, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2935s] threads: 64, tps: 0.00, reads: 0.00, writes: 49370.98, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2936s] threads: 64, tps: 0.00, reads: 0.00, writes: 50786.78, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2937s] threads: 64, tps: 0.00, reads: 0.00, writes: 49068.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2938s] threads: 64, tps: 0.00, reads: 0.00, writes: 48509.98, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2939s] threads: 64, tps: 0.00, reads: 0.00, writes: 48625.25, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2940s] threads: 64, tps: 0.00, reads: 0.00, writes: 36735.76, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2941s] threads: 64, tps: 0.00, reads: 0.00, writes: 50599.74, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2942s] threads: 64, tps: 0.00, reads: 0.00, writes: 49685.20, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2943s] threads: 64, tps: 0.00, reads: 0.00, writes: 48587.82, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2944s] threads: 64, tps: 0.00, reads: 0.00, writes: 49084.26, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2945s] threads: 64, tps: 0.00, reads: 0.00, writes: 49114.96, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2946s] threads: 64, tps: 0.00, reads: 0.00, writes: 47916.97, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2947s] threads: 64, tps: 0.00, reads: 0.00, writes: 48444.80, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2948s] threads: 64, tps: 0.00, reads: 0.00, writes: 46207.27, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2949s] threads: 64, tps: 0.00, reads: 0.00, writes: 47779.97, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2950s] threads: 64, tps: 0.00, reads: 0.00, writes: 48200.92, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2951s] threads: 64, tps: 0.00, reads: 0.00, writes: 46541.87, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2952s] threads: 64, tps: 0.00, reads: 0.00, writes: 45950.16, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2953s] threads: 64, tps: 0.00, reads: 0.00, writes: 35473.79, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[2954s] threads: 64, tps: 0.00, reads: 0.00, writes: 34107.19, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[2955s] threads: 64, tps: 0.00, reads: 0.00, writes: 39662.81, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[2956s] threads: 64, tps: 0.00, reads: 0.00, writes: 45772.28, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2957s] threads: 64, tps: 0.00, reads: 0.00, writes: 34452.97, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[2958s] threads: 64, tps: 0.00, reads: 0.00, writes: 36835.37, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[2959s] threads: 64, tps: 0.00, reads: 0.00, writes: 42820.60, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2960s] threads: 64, tps: 0.00, reads: 0.00, writes: 43330.17, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2961s] threads: 64, tps: 0.00, reads: 0.00, writes: 47730.98, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2962s] threads: 64, tps: 0.00, reads: 0.00, writes: 47987.03, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2963s] threads: 64, tps: 0.00, reads: 0.00, writes: 9617.76, response time: 20.32ms (95%), errors: 0.00, reconnects:  0.00
[2964s] threads: 64, tps: 0.00, reads: 0.00, writes: 3247.06, response time: 20.70ms (95%), errors: 0.00, reconnects:  0.00
[2965s] threads: 64, tps: 0.00, reads: 0.00, writes: 3217.01, response time: 20.42ms (95%), errors: 0.00, reconnects:  0.00
[2966s] threads: 64, tps: 0.00, reads: 0.00, writes: 3240.00, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[2967s] threads: 64, tps: 0.00, reads: 0.00, writes: 3212.89, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[2968s] threads: 64, tps: 0.00, reads: 0.00, writes: 3241.09, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[2969s] threads: 64, tps: 0.00, reads: 0.00, writes: 3222.94, response time: 20.89ms (95%), errors: 0.00, reconnects:  0.00
[2970s] threads: 64, tps: 0.00, reads: 0.00, writes: 24142.62, response time: 5.49ms (95%), errors: 0.00, reconnects:  0.00
[2971s] threads: 64, tps: 0.00, reads: 0.00, writes: 34751.95, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[2972s] threads: 64, tps: 0.00, reads: 0.00, writes: 44074.03, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2973s] threads: 64, tps: 0.00, reads: 0.00, writes: 50645.29, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2974s] threads: 64, tps: 0.00, reads: 0.00, writes: 46201.47, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2975s] threads: 64, tps: 0.00, reads: 0.00, writes: 48332.75, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2976s] threads: 64, tps: 0.00, reads: 0.00, writes: 48485.94, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2977s] threads: 64, tps: 0.00, reads: 0.00, writes: 50848.25, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2978s] threads: 64, tps: 0.00, reads: 0.00, writes: 48687.84, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2979s] threads: 64, tps: 0.00, reads: 0.00, writes: 49069.03, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2980s] threads: 64, tps: 0.00, reads: 0.00, writes: 48561.01, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2981s] threads: 64, tps: 0.00, reads: 0.00, writes: 48904.15, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2982s] threads: 64, tps: 0.00, reads: 0.00, writes: 49731.89, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2983s] threads: 64, tps: 0.00, reads: 0.00, writes: 47846.90, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2984s] threads: 64, tps: 0.00, reads: 0.00, writes: 48539.26, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2985s] threads: 64, tps: 0.00, reads: 0.00, writes: 41686.92, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2986s] threads: 64, tps: 0.00, reads: 0.00, writes: 49574.78, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2987s] threads: 64, tps: 0.00, reads: 0.00, writes: 49050.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2988s] threads: 64, tps: 0.00, reads: 0.00, writes: 48220.29, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2989s] threads: 64, tps: 0.00, reads: 0.00, writes: 48215.95, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2990s] threads: 64, tps: 0.00, reads: 0.00, writes: 48337.73, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2991s] threads: 64, tps: 0.00, reads: 0.00, writes: 48324.32, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2992s] threads: 64, tps: 0.00, reads: 0.00, writes: 49016.92, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2993s] threads: 64, tps: 0.00, reads: 0.00, writes: 48949.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2994s] threads: 64, tps: 0.00, reads: 0.00, writes: 47285.09, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2995s] threads: 64, tps: 0.00, reads: 0.00, writes: 39373.95, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2996s] threads: 64, tps: 0.00, reads: 0.00, writes: 39695.88, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[2997s] threads: 64, tps: 0.00, reads: 0.00, writes: 46407.14, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2998s] threads: 64, tps: 0.00, reads: 0.00, writes: 33266.01, response time: 3.28ms (95%), errors: 0.00, reconnects:  0.00
[2999s] threads: 64, tps: 0.00, reads: 0.00, writes: 31855.99, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[3000s] threads: 64, tps: 0.00, reads: 0.00, writes: 35328.97, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[3001s] threads: 64, tps: 0.00, reads: 0.00, writes: 34256.94, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[3002s] threads: 64, tps: 0.00, reads: 0.00, writes: 38059.10, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[3003s] threads: 64, tps: 0.00, reads: 0.00, writes: 47398.99, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3004s] threads: 64, tps: 0.00, reads: 0.00, writes: 34146.97, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[3005s] threads: 64, tps: 0.00, reads: 0.00, writes: 32770.89, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[3006s] threads: 64, tps: 0.00, reads: 0.00, writes: 42425.68, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[3007s] threads: 64, tps: 0.00, reads: 0.00, writes: 43661.29, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3008s] threads: 64, tps: 0.00, reads: 0.00, writes: 47093.04, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3009s] threads: 64, tps: 0.00, reads: 0.00, writes: 46617.99, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3010s] threads: 64, tps: 0.00, reads: 0.00, writes: 43477.90, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[3011s] threads: 64, tps: 0.00, reads: 0.00, writes: 43268.98, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[3012s] threads: 64, tps: 0.00, reads: 0.00, writes: 42703.10, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[3013s] threads: 64, tps: 0.00, reads: 0.00, writes: 46290.90, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3014s] threads: 64, tps: 0.00, reads: 0.00, writes: 46134.83, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3015s] threads: 64, tps: 0.00, reads: 0.00, writes: 15979.05, response time: 20.06ms (95%), errors: 0.00, reconnects:  0.00
[3016s] threads: 64, tps: 0.00, reads: 0.00, writes: 3237.99, response time: 20.68ms (95%), errors: 0.00, reconnects:  0.00
[3017s] threads: 64, tps: 0.00, reads: 0.00, writes: 8913.96, response time: 20.29ms (95%), errors: 0.00, reconnects:  0.00
[3018s] threads: 64, tps: 0.00, reads: 0.00, writes: 33778.18, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[3019s] threads: 64, tps: 0.00, reads: 0.00, writes: 39036.13, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3020s] threads: 64, tps: 0.00, reads: 0.00, writes: 38202.00, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3021s] threads: 64, tps: 0.00, reads: 0.00, writes: 47827.94, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3022s] threads: 64, tps: 0.00, reads: 0.00, writes: 47419.81, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3023s] threads: 64, tps: 0.00, reads: 0.00, writes: 48260.23, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3024s] threads: 64, tps: 0.00, reads: 0.00, writes: 48254.04, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3025s] threads: 64, tps: 0.00, reads: 0.00, writes: 48752.94, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3026s] threads: 64, tps: 0.00, reads: 0.00, writes: 49829.04, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3027s] threads: 64, tps: 0.00, reads: 0.00, writes: 42495.87, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3028s] threads: 64, tps: 0.00, reads: 0.00, writes: 48718.11, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3029s] threads: 64, tps: 0.00, reads: 0.00, writes: 47586.00, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3030s] threads: 64, tps: 0.00, reads: 0.00, writes: 49531.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3031s] threads: 64, tps: 0.00, reads: 0.00, writes: 50086.98, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3032s] threads: 64, tps: 0.00, reads: 0.00, writes: 49521.03, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3033s] threads: 64, tps: 0.00, reads: 0.00, writes: 49291.06, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3034s] threads: 64, tps: 0.00, reads: 0.00, writes: 47990.96, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3035s] threads: 64, tps: 0.00, reads: 0.00, writes: 50467.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3036s] threads: 64, tps: 0.00, reads: 0.00, writes: 49862.03, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3037s] threads: 64, tps: 0.00, reads: 0.00, writes: 48927.76, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3038s] threads: 64, tps: 0.00, reads: 0.00, writes: 49733.24, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3039s] threads: 64, tps: 0.00, reads: 0.00, writes: 49495.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3040s] threads: 64, tps: 0.00, reads: 0.00, writes: 48216.83, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3041s] threads: 64, tps: 0.00, reads: 0.00, writes: 49355.18, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3042s] threads: 64, tps: 0.00, reads: 0.00, writes: 44512.01, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3043s] threads: 64, tps: 0.00, reads: 0.00, writes: 34108.01, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[3044s] threads: 64, tps: 0.00, reads: 0.00, writes: 34962.78, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[3045s] threads: 64, tps: 0.00, reads: 0.00, writes: 46002.22, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3046s] threads: 64, tps: 0.00, reads: 0.00, writes: 38621.60, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[3047s] threads: 64, tps: 0.00, reads: 0.00, writes: 44432.95, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[3048s] threads: 64, tps: 0.00, reads: 0.00, writes: 43905.07, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3049s] threads: 64, tps: 0.00, reads: 0.00, writes: 43330.98, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[3050s] threads: 64, tps: 0.00, reads: 0.00, writes: 47977.96, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3051s] threads: 64, tps: 0.00, reads: 0.00, writes: 46730.02, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3052s] threads: 64, tps: 0.00, reads: 0.00, writes: 41782.81, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[3053s] threads: 64, tps: 0.00, reads: 0.00, writes: 42688.25, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[3054s] threads: 64, tps: 0.00, reads: 0.00, writes: 43690.97, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3055s] threads: 64, tps: 0.00, reads: 0.00, writes: 48203.01, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3056s] threads: 64, tps: 0.00, reads: 0.00, writes: 47511.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3057s] threads: 64, tps: 0.00, reads: 0.00, writes: 13985.66, response time: 20.14ms (95%), errors: 0.00, reconnects:  0.00
[3058s] threads: 64, tps: 0.00, reads: 0.00, writes: 24145.53, response time: 8.04ms (95%), errors: 0.00, reconnects:  0.00
[3059s] threads: 64, tps: 0.00, reads: 0.00, writes: 35058.01, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[3060s] threads: 64, tps: 0.00, reads: 0.00, writes: 31119.00, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[3061s] threads: 64, tps: 0.00, reads: 0.00, writes: 40227.05, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3062s] threads: 64, tps: 0.00, reads: 0.00, writes: 47745.89, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3063s] threads: 64, tps: 0.00, reads: 0.00, writes: 44189.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3064s] threads: 64, tps: 0.00, reads: 0.00, writes: 45174.04, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3065s] threads: 64, tps: 0.00, reads: 0.00, writes: 45534.04, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3066s] threads: 64, tps: 0.00, reads: 0.00, writes: 46625.05, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3067s] threads: 64, tps: 0.00, reads: 0.00, writes: 42771.94, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3068s] threads: 64, tps: 0.00, reads: 0.00, writes: 47602.99, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[3069s] threads: 64, tps: 0.00, reads: 0.00, writes: 48220.97, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3070s] threads: 64, tps: 0.00, reads: 0.00, writes: 48086.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3071s] threads: 64, tps: 0.00, reads: 0.00, writes: 49934.03, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3072s] threads: 64, tps: 0.00, reads: 0.00, writes: 48776.97, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3073s] threads: 64, tps: 0.00, reads: 0.00, writes: 49911.03, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3074s] threads: 64, tps: 0.00, reads: 0.00, writes: 49372.95, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3075s] threads: 64, tps: 0.00, reads: 0.00, writes: 48556.08, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3076s] threads: 64, tps: 0.00, reads: 0.00, writes: 49697.73, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3077s] threads: 64, tps: 0.00, reads: 0.00, writes: 49620.18, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3078s] threads: 64, tps: 0.00, reads: 0.00, writes: 47923.04, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3079s] threads: 64, tps: 0.00, reads: 0.00, writes: 48354.04, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3080s] threads: 64, tps: 0.00, reads: 0.00, writes: 49517.99, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3081s] threads: 64, tps: 0.00, reads: 0.00, writes: 49775.92, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3082s] threads: 64, tps: 0.00, reads: 0.00, writes: 49503.05, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3083s] threads: 64, tps: 0.00, reads: 0.00, writes: 47738.01, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3084s] threads: 64, tps: 0.00, reads: 0.00, writes: 48714.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3085s] threads: 64, tps: 0.00, reads: 0.00, writes: 47884.99, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3086s] threads: 64, tps: 0.00, reads: 0.00, writes: 48900.98, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3087s] threads: 64, tps: 0.00, reads: 0.00, writes: 48371.98, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3088s] threads: 64, tps: 0.00, reads: 0.00, writes: 47998.05, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3089s] threads: 64, tps: 0.00, reads: 0.00, writes: 47873.01, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3090s] threads: 64, tps: 0.00, reads: 0.00, writes: 49899.94, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3091s] threads: 64, tps: 0.00, reads: 0.00, writes: 48494.01, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3092s] threads: 64, tps: 0.00, reads: 0.00, writes: 45439.05, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3093s] threads: 64, tps: 0.00, reads: 0.00, writes: 35089.95, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[3094s] threads: 64, tps: 0.00, reads: 0.00, writes: 33404.03, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[3095s] threads: 64, tps: 0.00, reads: 0.00, writes: 44578.97, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3096s] threads: 64, tps: 0.00, reads: 0.00, writes: 24473.92, response time: 19.14ms (95%), errors: 0.00, reconnects:  0.00
[3097s] threads: 64, tps: 0.00, reads: 0.00, writes: 3216.00, response time: 20.58ms (95%), errors: 0.00, reconnects:  0.00
[3098s] threads: 64, tps: 0.00, reads: 0.00, writes: 3225.01, response time: 20.47ms (95%), errors: 0.00, reconnects:  0.00
[3099s] threads: 64, tps: 0.00, reads: 0.00, writes: 3244.01, response time: 20.70ms (95%), errors: 0.00, reconnects:  0.00
[3100s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.00, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[3101s] threads: 64, tps: 0.00, reads: 0.00, writes: 3202.90, response time: 20.77ms (95%), errors: 0.00, reconnects:  0.00
[3102s] threads: 64, tps: 0.00, reads: 0.00, writes: 3250.03, response time: 20.67ms (95%), errors: 0.00, reconnects:  0.00
[3103s] threads: 64, tps: 0.00, reads: 0.00, writes: 3217.01, response time: 20.70ms (95%), errors: 0.00, reconnects:  0.00
[3104s] threads: 64, tps: 0.00, reads: 0.00, writes: 3246.05, response time: 20.88ms (95%), errors: 0.00, reconnects:  0.00
[3105s] threads: 64, tps: 0.00, reads: 0.00, writes: 3219.91, response time: 20.68ms (95%), errors: 0.00, reconnects:  0.00
[3106s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.11, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[3107s] threads: 64, tps: 0.00, reads: 0.00, writes: 3232.92, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[3108s] threads: 64, tps: 0.00, reads: 0.00, writes: 3218.02, response time: 20.75ms (95%), errors: 0.00, reconnects:  0.00
[3109s] threads: 64, tps: 0.00, reads: 0.00, writes: 3228.05, response time: 20.74ms (95%), errors: 0.00, reconnects:  0.00
[3110s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.98, response time: 20.68ms (95%), errors: 0.00, reconnects:  0.00
[3111s] threads: 64, tps: 0.00, reads: 0.00, writes: 28552.08, response time: 3.34ms (95%), errors: 0.00, reconnects:  0.00
[3112s] threads: 64, tps: 0.00, reads: 0.00, writes: 39045.13, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3113s] threads: 64, tps: 0.00, reads: 0.00, writes: 44026.79, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3114s] threads: 64, tps: 0.00, reads: 0.00, writes: 48460.21, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3115s] threads: 64, tps: 0.00, reads: 0.00, writes: 46946.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3116s] threads: 64, tps: 0.00, reads: 0.00, writes: 47239.09, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3117s] threads: 64, tps: 0.00, reads: 0.00, writes: 47105.96, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3118s] threads: 64, tps: 0.00, reads: 0.00, writes: 39327.00, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3119s] threads: 64, tps: 0.00, reads: 0.00, writes: 51063.81, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3120s] threads: 64, tps: 0.00, reads: 0.00, writes: 49324.17, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3121s] threads: 64, tps: 0.00, reads: 0.00, writes: 49527.02, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3122s] threads: 64, tps: 0.00, reads: 0.00, writes: 47953.60, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3123s] threads: 64, tps: 0.00, reads: 0.00, writes: 49980.38, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3124s] threads: 64, tps: 0.00, reads: 0.00, writes: 50380.09, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3125s] threads: 64, tps: 0.00, reads: 0.00, writes: 48848.64, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3126s] threads: 64, tps: 0.00, reads: 0.00, writes: 48148.06, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3127s] threads: 64, tps: 0.00, reads: 0.00, writes: 49437.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3128s] threads: 64, tps: 0.00, reads: 0.00, writes: 49981.90, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3129s] threads: 64, tps: 0.00, reads: 0.00, writes: 49073.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3130s] threads: 64, tps: 0.00, reads: 0.00, writes: 49183.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3131s] threads: 64, tps: 0.00, reads: 0.00, writes: 50063.96, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[3132s] threads: 64, tps: 0.00, reads: 0.00, writes: 49999.08, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3133s] threads: 64, tps: 0.00, reads: 0.00, writes: 50669.97, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3134s] threads: 64, tps: 0.00, reads: 0.00, writes: 48364.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3135s] threads: 64, tps: 0.00, reads: 0.00, writes: 48876.93, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3136s] threads: 64, tps: 0.00, reads: 0.00, writes: 48675.10, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3137s] threads: 64, tps: 0.00, reads: 0.00, writes: 50068.90, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3138s] threads: 64, tps: 0.00, reads: 0.00, writes: 49864.06, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3139s] threads: 64, tps: 0.00, reads: 0.00, writes: 48871.17, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3140s] threads: 64, tps: 0.00, reads: 0.00, writes: 49015.18, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3141s] threads: 64, tps: 0.00, reads: 0.00, writes: 48986.08, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3142s] threads: 64, tps: 0.00, reads: 0.00, writes: 49980.96, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3143s] threads: 64, tps: 0.00, reads: 0.00, writes: 47015.12, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3144s] threads: 64, tps: 0.00, reads: 0.00, writes: 45230.96, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3145s] threads: 64, tps: 0.00, reads: 0.00, writes: 34177.02, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[3146s] threads: 64, tps: 0.00, reads: 0.00, writes: 32370.95, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[3147s] threads: 64, tps: 0.00, reads: 0.00, writes: 45229.03, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3148s] threads: 64, tps: 0.00, reads: 0.00, writes: 37109.01, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[3149s] threads: 64, tps: 0.00, reads: 0.00, writes: 31911.94, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[3150s] threads: 64, tps: 0.00, reads: 0.00, writes: 33999.99, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[3151s] threads: 64, tps: 0.00, reads: 0.00, writes: 30738.87, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[3152s] threads: 64, tps: 0.00, reads: 0.00, writes: 30964.18, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[3153s] threads: 64, tps: 0.00, reads: 0.00, writes: 44482.98, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[3154s] threads: 64, tps: 0.00, reads: 0.00, writes: 46228.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3155s] threads: 64, tps: 0.00, reads: 0.00, writes: 43027.90, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3156s] threads: 64, tps: 0.00, reads: 0.00, writes: 42482.12, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3157s] threads: 64, tps: 0.00, reads: 0.00, writes: 38586.59, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[3158s] threads: 64, tps: 0.00, reads: 0.00, writes: 45957.34, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3159s] threads: 64, tps: 0.00, reads: 0.00, writes: 46919.07, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[3160s] threads: 64, tps: 0.00, reads: 0.00, writes: 38205.02, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[3161s] threads: 64, tps: 0.00, reads: 0.00, writes: 3217.99, response time: 20.83ms (95%), errors: 0.00, reconnects:  0.00
[3162s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.01, response time: 20.74ms (95%), errors: 0.00, reconnects:  0.00
[3163s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.01, response time: 20.71ms (95%), errors: 0.00, reconnects:  0.00
[3164s] threads: 64, tps: 0.00, reads: 0.00, writes: 3713.99, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[3165s] threads: 64, tps: 0.00, reads: 0.00, writes: 36057.05, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[3166s] threads: 64, tps: 0.00, reads: 0.00, writes: 41616.02, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[3167s] threads: 64, tps: 0.00, reads: 0.00, writes: 45032.00, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3168s] threads: 64, tps: 0.00, reads: 0.00, writes: 48713.06, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3169s] threads: 64, tps: 0.00, reads: 0.00, writes: 49445.01, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3170s] threads: 64, tps: 0.00, reads: 0.00, writes: 49407.88, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3171s] threads: 64, tps: 0.00, reads: 0.00, writes: 48122.14, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3172s] threads: 64, tps: 0.00, reads: 0.00, writes: 48248.93, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3173s] threads: 64, tps: 0.00, reads: 0.00, writes: 50101.79, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3174s] threads: 64, tps: 0.00, reads: 0.00, writes: 47509.13, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3175s] threads: 64, tps: 0.00, reads: 0.00, writes: 49498.10, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3176s] threads: 64, tps: 0.00, reads: 0.00, writes: 48285.99, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3177s] threads: 64, tps: 0.00, reads: 0.00, writes: 49990.33, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3178s] threads: 64, tps: 0.00, reads: 0.00, writes: 49576.57, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3179s] threads: 64, tps: 0.00, reads: 0.00, writes: 48497.05, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3180s] threads: 64, tps: 0.00, reads: 0.00, writes: 48910.95, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3181s] threads: 64, tps: 0.00, reads: 0.00, writes: 47869.01, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3182s] threads: 64, tps: 0.00, reads: 0.00, writes: 50551.03, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3183s] threads: 64, tps: 0.00, reads: 0.00, writes: 47344.06, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3184s] threads: 64, tps: 0.00, reads: 0.00, writes: 48698.95, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3185s] threads: 64, tps: 0.00, reads: 0.00, writes: 49584.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3186s] threads: 64, tps: 0.00, reads: 0.00, writes: 50838.84, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3187s] threads: 64, tps: 0.00, reads: 0.00, writes: 48911.07, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3188s] threads: 64, tps: 0.00, reads: 0.00, writes: 47669.07, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3189s] threads: 64, tps: 0.00, reads: 0.00, writes: 39918.99, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[3190s] threads: 64, tps: 0.00, reads: 0.00, writes: 33061.98, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[3191s] threads: 64, tps: 0.00, reads: 0.00, writes: 40048.01, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[3192s] threads: 64, tps: 0.00, reads: 0.00, writes: 38657.97, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[3193s] threads: 64, tps: 0.00, reads: 0.00, writes: 32635.04, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[3194s] threads: 64, tps: 0.00, reads: 0.00, writes: 35207.34, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[3195s] threads: 64, tps: 0.00, reads: 0.00, writes: 34726.65, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[3196s] threads: 64, tps: 0.00, reads: 0.00, writes: 33740.95, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[3197s] threads: 64, tps: 0.00, reads: 0.00, writes: 37363.01, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[3198s] threads: 64, tps: 0.00, reads: 0.00, writes: 44911.04, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3199s] threads: 64, tps: 0.00, reads: 0.00, writes: 33310.13, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[3200s] threads: 64, tps: 0.00, reads: 0.00, writes: 37375.01, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[3201s] threads: 64, tps: 0.00, reads: 0.00, writes: 43394.94, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[3202s] threads: 64, tps: 0.00, reads: 0.00, writes: 42887.02, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[3203s] threads: 64, tps: 0.00, reads: 0.00, writes: 47221.06, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3204s] threads: 64, tps: 0.00, reads: 0.00, writes: 46143.94, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3205s] threads: 64, tps: 0.00, reads: 0.00, writes: 6806.01, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[3206s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.94, response time: 20.71ms (95%), errors: 0.00, reconnects:  0.00
[3207s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.05, response time: 20.71ms (95%), errors: 0.00, reconnects:  0.00
[3208s] threads: 64, tps: 0.00, reads: 0.00, writes: 3228.01, response time: 20.60ms (95%), errors: 0.00, reconnects:  0.00
[3209s] threads: 64, tps: 0.00, reads: 0.00, writes: 3208.92, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[3210s] threads: 64, tps: 0.00, reads: 0.00, writes: 3235.08, response time: 20.67ms (95%), errors: 0.00, reconnects:  0.00
[3211s] threads: 64, tps: 0.00, reads: 0.00, writes: 25422.04, response time: 3.65ms (95%), errors: 0.00, reconnects:  0.00
[3212s] threads: 64, tps: 0.00, reads: 0.00, writes: 35247.01, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[3213s] threads: 64, tps: 0.00, reads: 0.00, writes: 39009.73, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3214s] threads: 64, tps: 0.00, reads: 0.00, writes: 47560.56, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3215s] threads: 64, tps: 0.00, reads: 0.00, writes: 47738.99, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3216s] threads: 64, tps: 0.00, reads: 0.00, writes: 48852.00, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3217s] threads: 64, tps: 0.00, reads: 0.00, writes: 48452.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3218s] threads: 64, tps: 0.00, reads: 0.00, writes: 47820.05, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3219s] threads: 64, tps: 0.00, reads: 0.00, writes: 49881.81, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3220s] threads: 64, tps: 0.00, reads: 0.00, writes: 47593.16, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3221s] threads: 64, tps: 0.00, reads: 0.00, writes: 49422.97, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3222s] threads: 64, tps: 0.00, reads: 0.00, writes: 48992.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3223s] threads: 64, tps: 0.00, reads: 0.00, writes: 48753.03, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3224s] threads: 64, tps: 0.00, reads: 0.00, writes: 50452.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3225s] threads: 64, tps: 0.00, reads: 0.00, writes: 48898.97, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3226s] threads: 64, tps: 0.00, reads: 0.00, writes: 49141.11, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3227s] threads: 64, tps: 0.00, reads: 0.00, writes: 48725.88, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3228s] threads: 64, tps: 0.00, reads: 0.00, writes: 50526.06, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3229s] threads: 64, tps: 0.00, reads: 0.00, writes: 50102.93, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3230s] threads: 64, tps: 0.00, reads: 0.00, writes: 47588.05, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3231s] threads: 64, tps: 0.00, reads: 0.00, writes: 45677.85, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3232s] threads: 64, tps: 0.00, reads: 0.00, writes: 44101.12, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3233s] threads: 64, tps: 0.00, reads: 0.00, writes: 48854.74, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3234s] threads: 64, tps: 0.00, reads: 0.00, writes: 47546.31, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[3235s] threads: 64, tps: 0.00, reads: 0.00, writes: 39168.92, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[3236s] threads: 64, tps: 0.00, reads: 0.00, writes: 33232.01, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[3237s] threads: 64, tps: 0.00, reads: 0.00, writes: 31796.02, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[3238s] threads: 64, tps: 0.00, reads: 0.00, writes: 40170.03, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[3239s] threads: 64, tps: 0.00, reads: 0.00, writes: 42468.95, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3240s] threads: 64, tps: 0.00, reads: 0.00, writes: 34551.02, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[3241s] threads: 64, tps: 0.00, reads: 0.00, writes: 34436.83, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[3242s] threads: 64, tps: 0.00, reads: 0.00, writes: 33099.16, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[3243s] threads: 64, tps: 0.00, reads: 0.00, writes: 31877.88, response time: 3.57ms (95%), errors: 0.00, reconnects:  0.00
[3244s] threads: 64, tps: 0.00, reads: 0.00, writes: 38556.16, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[3245s] threads: 64, tps: 0.00, reads: 0.00, writes: 37974.92, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[3246s] threads: 64, tps: 0.00, reads: 0.00, writes: 41867.10, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[3247s] threads: 64, tps: 0.00, reads: 0.00, writes: 42788.93, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3248s] threads: 64, tps: 0.00, reads: 0.00, writes: 44260.06, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[3249s] threads: 64, tps: 0.00, reads: 0.00, writes: 44766.07, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3250s] threads: 64, tps: 0.00, reads: 0.00, writes: 46614.86, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3251s] threads: 64, tps: 0.00, reads: 0.00, writes: 46594.99, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3252s] threads: 64, tps: 0.00, reads: 0.00, writes: 42223.05, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[3253s] threads: 64, tps: 0.00, reads: 0.00, writes: 42172.00, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[3254s] threads: 64, tps: 0.00, reads: 0.00, writes: 41295.50, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[3255s] threads: 64, tps: 0.00, reads: 0.00, writes: 47890.49, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3256s] threads: 64, tps: 0.00, reads: 0.00, writes: 47217.78, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3257s] threads: 64, tps: 0.00, reads: 0.00, writes: 7825.98, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[3258s] threads: 64, tps: 0.00, reads: 0.00, writes: 34476.99, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[3259s] threads: 64, tps: 0.00, reads: 0.00, writes: 40697.06, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[3260s] threads: 64, tps: 0.00, reads: 0.00, writes: 41538.97, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[3261s] threads: 64, tps: 0.00, reads: 0.00, writes: 45451.43, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3262s] threads: 64, tps: 0.00, reads: 0.00, writes: 46961.72, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3263s] threads: 64, tps: 0.00, reads: 0.00, writes: 48117.95, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3264s] threads: 64, tps: 0.00, reads: 0.00, writes: 49182.04, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3265s] threads: 64, tps: 0.00, reads: 0.00, writes: 49980.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3266s] threads: 64, tps: 0.00, reads: 0.00, writes: 51205.44, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3267s] threads: 64, tps: 0.00, reads: 0.00, writes: 49001.51, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3268s] threads: 64, tps: 0.00, reads: 0.00, writes: 50130.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3269s] threads: 64, tps: 0.00, reads: 0.00, writes: 49156.06, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3270s] threads: 64, tps: 0.00, reads: 0.00, writes: 49508.87, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3271s] threads: 64, tps: 0.00, reads: 0.00, writes: 50506.11, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3272s] threads: 64, tps: 0.00, reads: 0.00, writes: 46140.98, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3273s] threads: 64, tps: 0.00, reads: 0.00, writes: 48722.92, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3274s] threads: 64, tps: 0.00, reads: 0.00, writes: 48318.02, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3275s] threads: 64, tps: 0.00, reads: 0.00, writes: 50560.12, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3276s] threads: 64, tps: 0.00, reads: 0.00, writes: 49321.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3277s] threads: 64, tps: 0.00, reads: 0.00, writes: 42391.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3278s] threads: 64, tps: 0.00, reads: 0.00, writes: 48496.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3279s] threads: 64, tps: 0.00, reads: 0.00, writes: 48420.99, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3280s] threads: 64, tps: 0.00, reads: 0.00, writes: 50020.03, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3281s] threads: 64, tps: 0.00, reads: 0.00, writes: 49176.94, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3282s] threads: 64, tps: 0.00, reads: 0.00, writes: 47046.99, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3283s] threads: 64, tps: 0.00, reads: 0.00, writes: 47217.94, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3284s] threads: 64, tps: 0.00, reads: 0.00, writes: 43842.07, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3285s] threads: 64, tps: 0.00, reads: 0.00, writes: 45455.97, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3286s] threads: 64, tps: 0.00, reads: 0.00, writes: 35677.00, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[3287s] threads: 64, tps: 0.00, reads: 0.00, writes: 36139.00, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[3288s] threads: 64, tps: 0.00, reads: 0.00, writes: 35332.98, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[3289s] threads: 64, tps: 0.00, reads: 0.00, writes: 35512.00, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[3290s] threads: 64, tps: 0.00, reads: 0.00, writes: 43368.04, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[3291s] threads: 64, tps: 0.00, reads: 0.00, writes: 42035.99, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[3292s] threads: 64, tps: 0.00, reads: 0.00, writes: 43466.01, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3293s] threads: 64, tps: 0.00, reads: 0.00, writes: 43107.09, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3294s] threads: 64, tps: 0.00, reads: 0.00, writes: 43631.85, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[3295s] threads: 64, tps: 0.00, reads: 0.00, writes: 44261.02, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3296s] threads: 64, tps: 0.00, reads: 0.00, writes: 47698.02, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[3297s] threads: 64, tps: 0.00, reads: 0.00, writes: 19451.64, response time: 19.87ms (95%), errors: 0.00, reconnects:  0.00
[3298s] threads: 64, tps: 0.00, reads: 0.00, writes: 3229.97, response time: 20.73ms (95%), errors: 0.00, reconnects:  0.00
[3299s] threads: 64, tps: 0.00, reads: 0.00, writes: 3223.07, response time: 20.71ms (95%), errors: 0.00, reconnects:  0.00
[3300s] threads: 64, tps: 0.00, reads: 0.00, writes: 3239.02, response time: 20.69ms (95%), errors: 0.00, reconnects:  0.00
[3301s] threads: 64, tps: 0.00, reads: 0.00, writes: 3227.94, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[3302s] threads: 64, tps: 0.00, reads: 0.00, writes: 3206.99, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[3303s] threads: 64, tps: 0.00, reads: 0.00, writes: 22049.48, response time: 19.16ms (95%), errors: 0.00, reconnects:  0.00
[3304s] threads: 64, tps: 0.00, reads: 0.00, writes: 37741.02, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3305s] threads: 64, tps: 0.00, reads: 0.00, writes: 39860.02, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[3306s] threads: 64, tps: 0.00, reads: 0.00, writes: 45546.93, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3307s] threads: 64, tps: 0.00, reads: 0.00, writes: 46368.04, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3308s] threads: 64, tps: 0.00, reads: 0.00, writes: 48837.92, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3309s] threads: 64, tps: 0.00, reads: 0.00, writes: 48853.05, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3310s] threads: 64, tps: 0.00, reads: 0.00, writes: 48616.95, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3311s] threads: 64, tps: 0.00, reads: 0.00, writes: 51013.06, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3312s] threads: 64, tps: 0.00, reads: 0.00, writes: 49643.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3313s] threads: 64, tps: 0.00, reads: 0.00, writes: 49641.91, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3314s] threads: 64, tps: 0.00, reads: 0.00, writes: 49131.09, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3315s] threads: 64, tps: 0.00, reads: 0.00, writes: 49503.61, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3316s] threads: 64, tps: 0.00, reads: 0.00, writes: 50989.39, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3317s] threads: 64, tps: 0.00, reads: 0.00, writes: 44286.98, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3318s] threads: 64, tps: 0.00, reads: 0.00, writes: 50294.06, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3319s] threads: 64, tps: 0.00, reads: 0.00, writes: 49763.96, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3320s] threads: 64, tps: 0.00, reads: 0.00, writes: 50225.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3321s] threads: 64, tps: 0.00, reads: 0.00, writes: 49174.72, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3322s] threads: 64, tps: 0.00, reads: 0.00, writes: 48276.23, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3323s] threads: 64, tps: 0.00, reads: 0.00, writes: 49598.85, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3324s] threads: 64, tps: 0.00, reads: 0.00, writes: 48596.17, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3325s] threads: 64, tps: 0.00, reads: 0.00, writes: 49991.04, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3326s] threads: 64, tps: 0.00, reads: 0.00, writes: 49172.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3327s] threads: 64, tps: 0.00, reads: 0.00, writes: 49534.05, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3328s] threads: 64, tps: 0.00, reads: 0.00, writes: 38366.93, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3329s] threads: 64, tps: 0.00, reads: 0.00, writes: 48082.10, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3330s] threads: 64, tps: 0.00, reads: 0.00, writes: 47317.97, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3331s] threads: 64, tps: 0.00, reads: 0.00, writes: 33889.96, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[3332s] threads: 64, tps: 0.00, reads: 0.00, writes: 34332.03, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[3333s] threads: 64, tps: 0.00, reads: 0.00, writes: 33180.97, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[3334s] threads: 64, tps: 0.00, reads: 0.00, writes: 33524.79, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[3335s] threads: 64, tps: 0.00, reads: 0.00, writes: 41330.28, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[3336s] threads: 64, tps: 0.00, reads: 0.00, writes: 44388.79, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3337s] threads: 64, tps: 0.00, reads: 0.00, writes: 31435.17, response time: 3.58ms (95%), errors: 0.00, reconnects:  0.00
[3338s] threads: 64, tps: 0.00, reads: 0.00, writes: 33444.95, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[3339s] threads: 64, tps: 0.00, reads: 0.00, writes: 38595.99, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[3340s] threads: 64, tps: 0.00, reads: 0.00, writes: 42830.07, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[3341s] threads: 64, tps: 0.00, reads: 0.00, writes: 47396.99, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3342s] threads: 64, tps: 0.00, reads: 0.00, writes: 45805.87, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3343s] threads: 64, tps: 0.00, reads: 0.00, writes: 44771.37, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3344s] threads: 64, tps: 0.00, reads: 0.00, writes: 42001.98, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[3345s] threads: 64, tps: 0.00, reads: 0.00, writes: 42933.83, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3346s] threads: 64, tps: 0.00, reads: 0.00, writes: 46692.03, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3347s] threads: 64, tps: 0.00, reads: 0.00, writes: 48454.27, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3348s] threads: 64, tps: 0.00, reads: 0.00, writes: 14031.66, response time: 20.23ms (95%), errors: 0.00, reconnects:  0.00
[3349s] threads: 64, tps: 0.00, reads: 0.00, writes: 3223.07, response time: 20.71ms (95%), errors: 0.00, reconnects:  0.00
[3350s] threads: 64, tps: 0.00, reads: 0.00, writes: 3212.96, response time: 20.84ms (95%), errors: 0.00, reconnects:  0.00
[3351s] threads: 64, tps: 0.00, reads: 0.00, writes: 28701.41, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[3352s] threads: 64, tps: 0.00, reads: 0.00, writes: 35881.02, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[3353s] threads: 64, tps: 0.00, reads: 0.00, writes: 39287.98, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[3354s] threads: 64, tps: 0.00, reads: 0.00, writes: 47308.02, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3355s] threads: 64, tps: 0.00, reads: 0.00, writes: 47936.98, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3356s] threads: 64, tps: 0.00, reads: 0.00, writes: 47185.03, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3357s] threads: 64, tps: 0.00, reads: 0.00, writes: 48185.97, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3358s] threads: 64, tps: 0.00, reads: 0.00, writes: 48936.03, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3359s] threads: 64, tps: 0.00, reads: 0.00, writes: 51267.93, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3360s] threads: 64, tps: 0.00, reads: 0.00, writes: 49726.01, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3361s] threads: 64, tps: 0.00, reads: 0.00, writes: 48605.96, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3362s] threads: 64, tps: 0.00, reads: 0.00, writes: 47482.09, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3363s] threads: 64, tps: 0.00, reads: 0.00, writes: 47225.71, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3364s] threads: 64, tps: 0.00, reads: 0.00, writes: 49532.50, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3365s] threads: 64, tps: 0.00, reads: 0.00, writes: 49866.93, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3366s] threads: 64, tps: 0.00, reads: 0.00, writes: 48036.99, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3367s] threads: 64, tps: 0.00, reads: 0.00, writes: 48687.05, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3368s] threads: 64, tps: 0.00, reads: 0.00, writes: 49358.04, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3369s] threads: 64, tps: 0.00, reads: 0.00, writes: 49040.93, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3370s] threads: 64, tps: 0.00, reads: 0.00, writes: 40954.05, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3371s] threads: 64, tps: 0.00, reads: 0.00, writes: 49083.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3372s] threads: 64, tps: 0.00, reads: 0.00, writes: 47553.97, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3373s] threads: 64, tps: 0.00, reads: 0.00, writes: 49212.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3374s] threads: 64, tps: 0.00, reads: 0.00, writes: 49292.04, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3375s] threads: 64, tps: 0.00, reads: 0.00, writes: 47299.96, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3376s] threads: 64, tps: 0.00, reads: 0.00, writes: 48049.97, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3377s] threads: 64, tps: 0.00, reads: 0.00, writes: 49229.05, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3378s] threads: 64, tps: 0.00, reads: 0.00, writes: 49616.02, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3379s] threads: 64, tps: 0.00, reads: 0.00, writes: 48358.95, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3380s] threads: 64, tps: 0.00, reads: 0.00, writes: 47720.04, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3381s] threads: 64, tps: 0.00, reads: 0.00, writes: 48022.94, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3382s] threads: 64, tps: 0.00, reads: 0.00, writes: 50178.05, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3383s] threads: 64, tps: 0.00, reads: 0.00, writes: 46610.90, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3384s] threads: 64, tps: 0.00, reads: 0.00, writes: 47237.99, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3385s] threads: 64, tps: 0.00, reads: 0.00, writes: 40420.03, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[3386s] threads: 64, tps: 0.00, reads: 0.00, writes: 32383.99, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[3387s] threads: 64, tps: 0.00, reads: 0.00, writes: 40913.04, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[3388s] threads: 64, tps: 0.00, reads: 0.00, writes: 44756.10, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3389s] threads: 64, tps: 0.00, reads: 0.00, writes: 3229.99, response time: 20.48ms (95%), errors: 0.00, reconnects:  0.00
[3390s] threads: 64, tps: 0.00, reads: 0.00, writes: 3224.00, response time: 20.59ms (95%), errors: 0.00, reconnects:  0.00
[3391s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.94, response time: 20.67ms (95%), errors: 0.00, reconnects:  0.00
[3392s] threads: 64, tps: 0.00, reads: 0.00, writes: 3226.99, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[3393s] threads: 64, tps: 0.00, reads: 0.00, writes: 3237.03, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[3394s] threads: 64, tps: 0.00, reads: 0.00, writes: 3224.04, response time: 20.73ms (95%), errors: 0.00, reconnects:  0.00
[3395s] threads: 64, tps: 0.00, reads: 0.00, writes: 3219.93, response time: 20.69ms (95%), errors: 0.00, reconnects:  0.00
[3396s] threads: 64, tps: 0.00, reads: 0.00, writes: 3232.08, response time: 20.76ms (95%), errors: 0.00, reconnects:  0.00
[3397s] threads: 64, tps: 0.00, reads: 0.00, writes: 3233.97, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[3398s] threads: 64, tps: 0.00, reads: 0.00, writes: 3227.00, response time: 20.74ms (95%), errors: 0.00, reconnects:  0.00
[3399s] threads: 64, tps: 0.00, reads: 0.00, writes: 3225.97, response time: 20.83ms (95%), errors: 0.00, reconnects:  0.00
[3400s] threads: 64, tps: 0.00, reads: 0.00, writes: 3212.95, response time: 20.80ms (95%), errors: 0.00, reconnects:  0.00
[3401s] threads: 64, tps: 0.00, reads: 0.00, writes: 9695.32, response time: 20.28ms (95%), errors: 0.00, reconnects:  0.00
[3402s] threads: 64, tps: 0.00, reads: 0.00, writes: 35305.00, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[3403s] threads: 64, tps: 0.00, reads: 0.00, writes: 35365.00, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[3404s] threads: 64, tps: 0.00, reads: 0.00, writes: 44001.99, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3405s] threads: 64, tps: 0.00, reads: 0.00, writes: 49665.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3406s] threads: 64, tps: 0.00, reads: 0.00, writes: 47307.99, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3407s] threads: 64, tps: 0.00, reads: 0.00, writes: 47682.91, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3408s] threads: 64, tps: 0.00, reads: 0.00, writes: 49284.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3409s] threads: 64, tps: 0.00, reads: 0.00, writes: 50136.08, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3410s] threads: 64, tps: 0.00, reads: 0.00, writes: 49607.03, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3411s] threads: 64, tps: 0.00, reads: 0.00, writes: 46800.94, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3412s] threads: 64, tps: 0.00, reads: 0.00, writes: 49080.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3413s] threads: 64, tps: 0.00, reads: 0.00, writes: 48731.05, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3414s] threads: 64, tps: 0.00, reads: 0.00, writes: 50339.03, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3415s] threads: 64, tps: 0.00, reads: 0.00, writes: 51282.89, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3416s] threads: 64, tps: 0.00, reads: 0.00, writes: 46491.07, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3417s] threads: 64, tps: 0.00, reads: 0.00, writes: 50008.94, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3418s] threads: 64, tps: 0.00, reads: 0.00, writes: 49309.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3419s] threads: 64, tps: 0.00, reads: 0.00, writes: 41803.77, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[3420s] threads: 64, tps: 0.00, reads: 0.00, writes: 48746.28, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3421s] threads: 64, tps: 0.00, reads: 0.00, writes: 49663.06, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3422s] threads: 64, tps: 0.00, reads: 0.00, writes: 49876.92, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3423s] threads: 64, tps: 0.00, reads: 0.00, writes: 50640.04, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[3424s] threads: 64, tps: 0.00, reads: 0.00, writes: 50918.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3425s] threads: 64, tps: 0.00, reads: 0.00, writes: 44054.97, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3426s] threads: 64, tps: 0.00, reads: 0.00, writes: 38851.02, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[3427s] threads: 64, tps: 0.00, reads: 0.00, writes: 31745.01, response time: 3.50ms (95%), errors: 0.00, reconnects:  0.00
[3428s] threads: 64, tps: 0.00, reads: 0.00, writes: 36091.88, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[3429s] threads: 64, tps: 0.00, reads: 0.00, writes: 44911.05, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3430s] threads: 64, tps: 0.00, reads: 0.00, writes: 32756.51, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[3431s] threads: 64, tps: 0.00, reads: 0.00, writes: 33277.37, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[3432s] threads: 64, tps: 0.00, reads: 0.00, writes: 35643.19, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[3433s] threads: 64, tps: 0.00, reads: 0.00, writes: 34648.10, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[3434s] threads: 64, tps: 0.00, reads: 0.00, writes: 32882.54, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[3435s] threads: 64, tps: 0.00, reads: 0.00, writes: 47228.05, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3436s] threads: 64, tps: 0.00, reads: 0.00, writes: 40088.18, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[3437s] threads: 64, tps: 0.00, reads: 0.00, writes: 34845.03, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[3438s] threads: 64, tps: 0.00, reads: 0.00, writes: 37861.00, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[3439s] threads: 64, tps: 0.00, reads: 0.00, writes: 43405.95, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3440s] threads: 64, tps: 0.00, reads: 0.00, writes: 43466.02, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3441s] threads: 64, tps: 0.00, reads: 0.00, writes: 46949.97, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3442s] threads: 64, tps: 0.00, reads: 0.00, writes: 46204.94, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3443s] threads: 64, tps: 0.00, reads: 0.00, writes: 43274.07, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[3444s] threads: 64, tps: 0.00, reads: 0.00, writes: 43204.92, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[3445s] threads: 64, tps: 0.00, reads: 0.00, writes: 45309.03, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3446s] threads: 64, tps: 0.00, reads: 0.00, writes: 47635.01, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3447s] threads: 64, tps: 0.00, reads: 0.00, writes: 44511.03, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3448s] threads: 64, tps: 0.00, reads: 0.00, writes: 44395.96, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[3449s] threads: 64, tps: 0.00, reads: 0.00, writes: 41116.08, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[3450s] threads: 64, tps: 0.00, reads: 0.00, writes: 37615.96, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[3451s] threads: 64, tps: 0.00, reads: 0.00, writes: 46458.03, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3452s] threads: 64, tps: 0.00, reads: 0.00, writes: 41662.38, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[3453s] threads: 64, tps: 0.00, reads: 0.00, writes: 34721.51, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[3454s] threads: 64, tps: 0.00, reads: 0.00, writes: 49173.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3455s] threads: 64, tps: 0.00, reads: 0.00, writes: 49317.85, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3456s] threads: 64, tps: 0.00, reads: 0.00, writes: 47595.04, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3457s] threads: 64, tps: 0.00, reads: 0.00, writes: 49243.00, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3458s] threads: 64, tps: 0.00, reads: 0.00, writes: 49396.06, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3459s] threads: 64, tps: 0.00, reads: 0.00, writes: 48909.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3460s] threads: 64, tps: 0.00, reads: 0.00, writes: 42028.97, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3461s] threads: 64, tps: 0.00, reads: 0.00, writes: 49180.04, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3462s] threads: 64, tps: 0.00, reads: 0.00, writes: 45573.98, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3463s] threads: 64, tps: 0.00, reads: 0.00, writes: 48039.00, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3464s] threads: 64, tps: 0.00, reads: 0.00, writes: 48710.95, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3465s] threads: 64, tps: 0.00, reads: 0.00, writes: 48457.06, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3466s] threads: 64, tps: 0.00, reads: 0.00, writes: 49576.92, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3467s] threads: 64, tps: 0.00, reads: 0.00, writes: 48673.00, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3468s] threads: 64, tps: 0.00, reads: 0.00, writes: 49971.08, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3469s] threads: 64, tps: 0.00, reads: 0.00, writes: 48260.82, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3470s] threads: 64, tps: 0.00, reads: 0.00, writes: 49964.25, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3471s] threads: 64, tps: 0.00, reads: 0.00, writes: 49243.92, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3472s] threads: 64, tps: 0.00, reads: 0.00, writes: 47466.09, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3473s] threads: 64, tps: 0.00, reads: 0.00, writes: 47475.70, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3474s] threads: 64, tps: 0.00, reads: 0.00, writes: 43350.17, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3475s] threads: 64, tps: 0.00, reads: 0.00, writes: 43389.93, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3476s] threads: 64, tps: 0.00, reads: 0.00, writes: 33556.85, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[3477s] threads: 64, tps: 0.00, reads: 0.00, writes: 31594.16, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[3478s] threads: 64, tps: 0.00, reads: 0.00, writes: 32345.96, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[3479s] threads: 64, tps: 0.00, reads: 0.00, writes: 39150.99, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[3480s] threads: 64, tps: 0.00, reads: 0.00, writes: 45320.07, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3481s] threads: 64, tps: 0.00, reads: 0.00, writes: 47992.99, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3482s] threads: 64, tps: 0.00, reads: 0.00, writes: 45288.92, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3483s] threads: 64, tps: 0.00, reads: 0.00, writes: 42242.24, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[3484s] threads: 64, tps: 0.00, reads: 0.00, writes: 43657.88, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[3485s] threads: 64, tps: 0.00, reads: 0.00, writes: 47400.95, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3486s] threads: 64, tps: 0.00, reads: 0.00, writes: 46975.98, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3487s] threads: 64, tps: 0.00, reads: 0.00, writes: 34024.00, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[3488s] threads: 64, tps: 0.00, reads: 0.00, writes: 3220.93, response time: 20.74ms (95%), errors: 0.00, reconnects:  0.00
[3489s] threads: 64, tps: 0.00, reads: 0.00, writes: 3238.04, response time: 20.60ms (95%), errors: 0.00, reconnects:  0.00
[3490s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.96, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[3491s] threads: 64, tps: 0.00, reads: 0.00, writes: 27985.62, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[3492s] threads: 64, tps: 0.00, reads: 0.00, writes: 41066.88, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[3493s] threads: 64, tps: 0.00, reads: 0.00, writes: 43234.10, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3494s] threads: 64, tps: 0.00, reads: 0.00, writes: 45152.02, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3495s] threads: 64, tps: 0.00, reads: 0.00, writes: 47506.95, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3496s] threads: 64, tps: 0.00, reads: 0.00, writes: 48801.00, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3497s] threads: 64, tps: 0.00, reads: 0.00, writes: 49224.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3498s] threads: 64, tps: 0.00, reads: 0.00, writes: 49833.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3499s] threads: 64, tps: 0.00, reads: 0.00, writes: 48639.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3500s] threads: 64, tps: 0.00, reads: 0.00, writes: 49609.93, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3501s] threads: 64, tps: 0.00, reads: 0.00, writes: 49917.78, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3502s] threads: 64, tps: 0.00, reads: 0.00, writes: 40229.22, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3503s] threads: 64, tps: 0.00, reads: 0.00, writes: 49793.95, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3504s] threads: 64, tps: 0.00, reads: 0.00, writes: 50001.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3505s] threads: 64, tps: 0.00, reads: 0.00, writes: 47911.03, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3506s] threads: 64, tps: 0.00, reads: 0.00, writes: 48390.98, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3507s] threads: 64, tps: 0.00, reads: 0.00, writes: 46578.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3508s] threads: 64, tps: 0.00, reads: 0.00, writes: 49853.03, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3509s] threads: 64, tps: 0.00, reads: 0.00, writes: 50565.87, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3510s] threads: 64, tps: 0.00, reads: 0.00, writes: 49259.10, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3511s] threads: 64, tps: 0.00, reads: 0.00, writes: 49025.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3512s] threads: 64, tps: 0.00, reads: 0.00, writes: 47433.00, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3513s] threads: 64, tps: 0.00, reads: 0.00, writes: 50273.05, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3514s] threads: 64, tps: 0.00, reads: 0.00, writes: 49633.92, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3515s] threads: 64, tps: 0.00, reads: 0.00, writes: 48745.03, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3516s] threads: 64, tps: 0.00, reads: 0.00, writes: 48008.99, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3517s] threads: 64, tps: 0.00, reads: 0.00, writes: 46127.02, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3518s] threads: 64, tps: 0.00, reads: 0.00, writes: 45995.88, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3519s] threads: 64, tps: 0.00, reads: 0.00, writes: 38009.07, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[3520s] threads: 64, tps: 0.00, reads: 0.00, writes: 32129.03, response time: 3.32ms (95%), errors: 0.00, reconnects:  0.00
[3521s] threads: 64, tps: 0.00, reads: 0.00, writes: 32952.87, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[3522s] threads: 64, tps: 0.00, reads: 0.00, writes: 33646.13, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[3523s] threads: 64, tps: 0.00, reads: 0.00, writes: 47060.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3524s] threads: 64, tps: 0.00, reads: 0.00, writes: 39701.04, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[3525s] threads: 64, tps: 0.00, reads: 0.00, writes: 34011.02, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[3526s] threads: 64, tps: 0.00, reads: 0.00, writes: 40265.94, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[3527s] threads: 64, tps: 0.00, reads: 0.00, writes: 44185.00, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[3528s] threads: 64, tps: 0.00, reads: 0.00, writes: 45680.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3529s] threads: 64, tps: 0.00, reads: 0.00, writes: 48195.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3530s] threads: 64, tps: 0.00, reads: 0.00, writes: 27157.39, response time: 15.64ms (95%), errors: 0.00, reconnects:  0.00
[3531s] threads: 64, tps: 0.00, reads: 0.00, writes: 3232.03, response time: 20.77ms (95%), errors: 0.00, reconnects:  0.00
[3532s] threads: 64, tps: 0.00, reads: 0.00, writes: 3232.98, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[3533s] threads: 64, tps: 0.00, reads: 0.00, writes: 3237.06, response time: 20.70ms (95%), errors: 0.00, reconnects:  0.00
[3534s] threads: 64, tps: 0.00, reads: 0.00, writes: 3221.95, response time: 21.94ms (95%), errors: 0.00, reconnects:  0.00
[3535s] threads: 64, tps: 0.00, reads: 0.00, writes: 3231.05, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[3536s] threads: 64, tps: 0.00, reads: 0.00, writes: 3232.94, response time: 20.57ms (95%), errors: 0.00, reconnects:  0.00
[3537s] threads: 64, tps: 0.00, reads: 0.00, writes: 4032.08, response time: 20.62ms (95%), errors: 0.00, reconnects:  0.00
[3538s] threads: 64, tps: 0.00, reads: 0.00, writes: 38685.06, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3539s] threads: 64, tps: 0.00, reads: 0.00, writes: 44635.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3540s] threads: 64, tps: 0.00, reads: 0.00, writes: 47924.03, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3541s] threads: 64, tps: 0.00, reads: 0.00, writes: 47189.93, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3542s] threads: 64, tps: 0.00, reads: 0.00, writes: 49234.02, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3543s] threads: 64, tps: 0.00, reads: 0.00, writes: 48800.00, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3544s] threads: 64, tps: 0.00, reads: 0.00, writes: 47936.79, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3545s] threads: 64, tps: 0.00, reads: 0.00, writes: 50311.26, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3546s] threads: 64, tps: 0.00, reads: 0.00, writes: 48931.97, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3547s] threads: 64, tps: 0.00, reads: 0.00, writes: 42678.00, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3548s] threads: 64, tps: 0.00, reads: 0.00, writes: 49620.01, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3549s] threads: 64, tps: 0.00, reads: 0.00, writes: 49929.81, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3550s] threads: 64, tps: 0.00, reads: 0.00, writes: 48816.20, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3551s] threads: 64, tps: 0.00, reads: 0.00, writes: 49529.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3552s] threads: 64, tps: 0.00, reads: 0.00, writes: 49326.96, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3553s] threads: 64, tps: 0.00, reads: 0.00, writes: 49962.01, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3554s] threads: 64, tps: 0.00, reads: 0.00, writes: 50146.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3555s] threads: 64, tps: 0.00, reads: 0.00, writes: 50897.93, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3556s] threads: 64, tps: 0.00, reads: 0.00, writes: 48467.08, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3557s] threads: 64, tps: 0.00, reads: 0.00, writes: 48608.96, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3558s] threads: 64, tps: 0.00, reads: 0.00, writes: 48693.98, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3559s] threads: 64, tps: 0.00, reads: 0.00, writes: 50613.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3560s] threads: 64, tps: 0.00, reads: 0.00, writes: 49432.01, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3561s] threads: 64, tps: 0.00, reads: 0.00, writes: 49521.93, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3562s] threads: 64, tps: 0.00, reads: 0.00, writes: 49187.60, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3563s] threads: 64, tps: 0.00, reads: 0.00, writes: 49765.46, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3564s] threads: 64, tps: 0.00, reads: 0.00, writes: 50528.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3565s] threads: 64, tps: 0.00, reads: 0.00, writes: 48413.12, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3566s] threads: 64, tps: 0.00, reads: 0.00, writes: 47666.78, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3567s] threads: 64, tps: 0.00, reads: 0.00, writes: 47448.03, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3568s] threads: 64, tps: 0.00, reads: 0.00, writes: 50281.09, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3569s] threads: 64, tps: 0.00, reads: 0.00, writes: 47318.99, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3570s] threads: 64, tps: 0.00, reads: 0.00, writes: 45707.98, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3571s] threads: 64, tps: 0.00, reads: 0.00, writes: 38241.99, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[3572s] threads: 64, tps: 0.00, reads: 0.00, writes: 32438.00, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[3573s] threads: 64, tps: 0.00, reads: 0.00, writes: 46006.02, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3574s] threads: 64, tps: 0.00, reads: 0.00, writes: 39393.99, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[3575s] threads: 64, tps: 0.00, reads: 0.00, writes: 33048.96, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[3576s] threads: 64, tps: 0.00, reads: 0.00, writes: 34453.01, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[3577s] threads: 64, tps: 0.00, reads: 0.00, writes: 31345.07, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[3578s] threads: 64, tps: 0.00, reads: 0.00, writes: 31922.95, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[3579s] threads: 64, tps: 0.00, reads: 0.00, writes: 33724.65, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[3580s] threads: 64, tps: 0.00, reads: 0.00, writes: 40587.43, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3581s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.93, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[3582s] threads: 64, tps: 0.00, reads: 0.00, writes: 3209.99, response time: 20.68ms (95%), errors: 0.00, reconnects:  0.00
[3583s] threads: 64, tps: 0.00, reads: 0.00, writes: 3229.99, response time: 20.76ms (95%), errors: 0.00, reconnects:  0.00
[3584s] threads: 64, tps: 0.00, reads: 0.00, writes: 3234.08, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[3585s] threads: 64, tps: 0.00, reads: 0.00, writes: 3230.00, response time: 20.69ms (95%), errors: 0.00, reconnects:  0.00
[3586s] threads: 64, tps: 0.00, reads: 0.00, writes: 3227.99, response time: 20.74ms (95%), errors: 0.00, reconnects:  0.00
[3587s] threads: 64, tps: 0.00, reads: 0.00, writes: 3217.00, response time: 20.66ms (95%), errors: 0.00, reconnects:  0.00
[3588s] threads: 64, tps: 0.00, reads: 0.00, writes: 3228.95, response time: 20.88ms (95%), errors: 0.00, reconnects:  0.00
[3589s] threads: 64, tps: 0.00, reads: 0.00, writes: 3239.06, response time: 20.70ms (95%), errors: 0.00, reconnects:  0.00
[3590s] threads: 64, tps: 0.00, reads: 0.00, writes: 3222.99, response time: 20.79ms (95%), errors: 0.00, reconnects:  0.00
[3591s] threads: 64, tps: 0.00, reads: 0.00, writes: 3451.01, response time: 20.61ms (95%), errors: 0.00, reconnects:  0.00
[3592s] threads: 64, tps: 0.00, reads: 0.00, writes: 31603.79, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[3593s] threads: 64, tps: 0.00, reads: 0.00, writes: 33478.34, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[3594s] threads: 64, tps: 0.00, reads: 0.00, writes: 37796.08, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[3595s] threads: 64, tps: 0.00, reads: 0.00, writes: 43655.13, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3596s] threads: 64, tps: 0.00, reads: 0.00, writes: 48662.90, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3597s] threads: 64, tps: 0.00, reads: 0.00, writes: 43539.02, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3598s] threads: 64, tps: 0.00, reads: 0.00, writes: 48358.94, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3599s] threads: 64, tps: 0.00, reads: 0.00, writes: 50074.08, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3600s] threads: 64, tps: 0.00, reads: 0.00, writes: 50069.98, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
OLTP test statistics:
    queries performed:
        read:                            0
        write:                           148332759
        other:                           0
        total:                           148332759
    transactions:                        0      (0.00 per sec.)
    read/write requests:                 148332759 (41203.47 per sec.)
    other operations:                    0      (0.00 per sec.)
    ignored errors:                      0      (0.00 per sec.)
    reconnects:                          0      (0.00 per sec.)

General statistics:
    total time:                          3600.0062s
    total number of events:              148332759
    total time taken by event execution: 229795.6569s
    response time:
         min:                                  0.12ms
         avg:                                  1.55ms
         max:                              17540.92ms
         approx.  95 percentile:               2.29ms

Threads fairness:
    events (avg/stddev):           2317699.3594/857.95
    execution time (avg/stddev):   3590.5571/0.14

