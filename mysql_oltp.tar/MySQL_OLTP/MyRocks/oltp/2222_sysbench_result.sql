sysbench 0.5:  multi-threaded system evaluation benchmark

Running the test with following options:
Number of threads: 64
Report intermediate results every 1 second(s)
Initializing random number generator from timer.

Random number generator seed is 0 and will be ignored


Threads started!

[   1s] threads: 64, tps: 2194.30, reads: 31373.09, writes: 8791.32, response time: 44.20ms (95%), errors: 0.00, reconnects:  0.00
[   2s] threads: 64, tps: 2450.01, reads: 34445.08, writes: 9934.02, response time: 53.29ms (95%), errors: 0.00, reconnects:  0.00
[   3s] threads: 64, tps: 2802.01, reads: 39200.08, writes: 11128.02, response time: 44.69ms (95%), errors: 0.00, reconnects:  0.00
[   4s] threads: 64, tps: 2891.00, reads: 40366.95, writes: 11541.99, response time: 42.28ms (95%), errors: 0.00, reconnects:  0.00
[   5s] threads: 64, tps: 2106.00, reads: 29533.03, writes: 8480.01, response time: 61.08ms (95%), errors: 0.00, reconnects:  0.00
[   6s] threads: 64, tps: 1630.00, reads: 22851.99, writes: 6425.00, response time: 74.25ms (95%), errors: 0.00, reconnects:  0.00
[   7s] threads: 64, tps: 1285.00, reads: 17968.98, writes: 5168.99, response time: 85.31ms (95%), errors: 0.00, reconnects:  0.00
[   8s] threads: 64, tps: 1334.00, reads: 18687.03, writes: 5340.01, response time: 81.49ms (95%), errors: 0.00, reconnects:  0.00
[   9s] threads: 64, tps: 1321.00, reads: 18495.99, writes: 5252.00, response time: 84.62ms (95%), errors: 0.00, reconnects:  0.00
[  10s] threads: 64, tps: 1217.00, reads: 17049.00, writes: 4881.00, response time: 89.15ms (95%), errors: 0.00, reconnects:  0.00
[  11s] threads: 64, tps: 1259.00, reads: 17626.02, writes: 5024.01, response time: 85.54ms (95%), errors: 0.00, reconnects:  0.00
[  12s] threads: 64, tps: 1126.00, reads: 15756.00, writes: 4507.00, response time: 100.51ms (95%), errors: 0.00, reconnects:  0.00
[  13s] threads: 64, tps: 1111.97, reads: 15567.62, writes: 4436.89, response time: 93.80ms (95%), errors: 0.00, reconnects:  0.00
[  14s] threads: 64, tps: 914.01, reads: 12690.19, writes: 3682.06, response time: 109.70ms (95%), errors: 0.00, reconnects:  0.00
[  15s] threads: 64, tps: 821.01, reads: 11511.08, writes: 3267.02, response time: 139.92ms (95%), errors: 0.00, reconnects:  0.00
[  16s] threads: 64, tps: 890.00, reads: 12454.01, writes: 3565.00, response time: 107.10ms (95%), errors: 0.00, reconnects:  0.00
[  17s] threads: 64, tps: 868.00, reads: 12206.01, writes: 3474.00, response time: 117.20ms (95%), errors: 0.00, reconnects:  0.00
[  18s] threads: 64, tps: 896.00, reads: 12516.01, writes: 3584.00, response time: 111.75ms (95%), errors: 0.00, reconnects:  0.00
[  19s] threads: 64, tps: 919.00, reads: 12883.99, writes: 3690.00, response time: 102.37ms (95%), errors: 0.00, reconnects:  0.00
[  20s] threads: 64, tps: 927.00, reads: 12892.00, writes: 3682.00, response time: 108.29ms (95%), errors: 0.00, reconnects:  0.00
[  21s] threads: 64, tps: 982.00, reads: 13864.99, writes: 3938.00, response time: 102.55ms (95%), errors: 0.00, reconnects:  0.00
[  22s] threads: 64, tps: 939.00, reads: 13087.00, writes: 3767.00, response time: 102.15ms (95%), errors: 0.00, reconnects:  0.00
[  23s] threads: 64, tps: 1072.00, reads: 15011.02, writes: 4276.01, response time: 99.05ms (95%), errors: 0.00, reconnects:  0.00
[  24s] threads: 64, tps: 1441.00, reads: 20216.96, writes: 5770.99, response time: 76.23ms (95%), errors: 0.00, reconnects:  0.00
[  25s] threads: 64, tps: 2969.93, reads: 41617.99, writes: 11936.71, response time: 40.24ms (95%), errors: 0.00, reconnects:  0.00
[  26s] threads: 64, tps: 3300.08, reads: 46185.16, writes: 13200.33, response time: 31.46ms (95%), errors: 0.00, reconnects:  0.00
[  27s] threads: 64, tps: 3403.82, reads: 47512.55, writes: 13557.30, response time: 30.25ms (95%), errors: 0.00, reconnects:  0.00
[  28s] threads: 64, tps: 3297.17, reads: 46209.38, writes: 13215.68, response time: 31.31ms (95%), errors: 0.00, reconnects:  0.00
[  29s] threads: 64, tps: 3210.01, reads: 45174.08, writes: 12970.02, response time: 32.59ms (95%), errors: 0.00, reconnects:  0.00
[  30s] threads: 64, tps: 2859.00, reads: 39900.98, writes: 11275.99, response time: 36.10ms (95%), errors: 0.00, reconnects:  0.00
[  31s] threads: 64, tps: 2197.00, reads: 30641.00, writes: 8808.00, response time: 48.07ms (95%), errors: 0.00, reconnects:  0.00
[  32s] threads: 64, tps: 1781.00, reads: 25075.00, writes: 7206.00, response time: 57.58ms (95%), errors: 0.00, reconnects:  0.00
[  33s] threads: 64, tps: 1905.00, reads: 26642.02, writes: 7547.00, response time: 53.27ms (95%), errors: 0.00, reconnects:  0.00
[  34s] threads: 64, tps: 1819.00, reads: 25495.95, writes: 7265.99, response time: 54.46ms (95%), errors: 0.00, reconnects:  0.00
[  35s] threads: 64, tps: 1484.00, reads: 20664.01, writes: 5903.00, response time: 68.40ms (95%), errors: 0.00, reconnects:  0.00
[  36s] threads: 64, tps: 1384.00, reads: 19342.03, writes: 5541.01, response time: 69.31ms (95%), errors: 0.00, reconnects:  0.00
[  37s] threads: 64, tps: 1393.00, reads: 19658.00, writes: 5645.00, response time: 69.49ms (95%), errors: 0.00, reconnects:  0.00
[  38s] threads: 64, tps: 1424.00, reads: 20005.98, writes: 5758.99, response time: 70.06ms (95%), errors: 0.00, reconnects:  0.00
[  39s] threads: 64, tps: 1529.00, reads: 21295.01, writes: 6033.00, response time: 64.25ms (95%), errors: 0.00, reconnects:  0.00
[  40s] threads: 64, tps: 1473.00, reads: 20642.96, writes: 5830.99, response time: 69.06ms (95%), errors: 0.00, reconnects:  0.00
[  41s] threads: 64, tps: 1502.00, reads: 20985.02, writes: 6024.01, response time: 67.46ms (95%), errors: 0.00, reconnects:  0.00
[  42s] threads: 64, tps: 1376.00, reads: 19261.01, writes: 5498.00, response time: 72.49ms (95%), errors: 0.00, reconnects:  0.00
[  43s] threads: 64, tps: 1369.00, reads: 19033.00, writes: 5503.00, response time: 67.08ms (95%), errors: 0.00, reconnects:  0.00
[  44s] threads: 64, tps: 1439.00, reads: 20274.00, writes: 5723.00, response time: 61.47ms (95%), errors: 0.00, reconnects:  0.00
[  45s] threads: 64, tps: 1618.00, reads: 22567.97, writes: 6489.99, response time: 59.17ms (95%), errors: 0.00, reconnects:  0.00
[  46s] threads: 64, tps: 1840.00, reads: 25886.01, writes: 7361.00, response time: 51.09ms (95%), errors: 0.00, reconnects:  0.00
[  47s] threads: 64, tps: 2246.00, reads: 31377.03, writes: 9024.01, response time: 44.70ms (95%), errors: 0.00, reconnects:  0.00
[  48s] threads: 64, tps: 2856.00, reads: 40160.00, writes: 11513.00, response time: 34.76ms (95%), errors: 0.00, reconnects:  0.00
[  49s] threads: 64, tps: 3464.00, reads: 48418.02, writes: 13777.01, response time: 28.94ms (95%), errors: 0.00, reconnects:  0.00
[  50s] threads: 64, tps: 3539.00, reads: 49505.97, writes: 14116.99, response time: 27.61ms (95%), errors: 0.00, reconnects:  0.00
[  51s] threads: 64, tps: 3634.00, reads: 50838.95, writes: 14567.99, response time: 27.24ms (95%), errors: 0.00, reconnects:  0.00
[  52s] threads: 64, tps: 3517.00, reads: 49269.02, writes: 14077.01, response time: 29.35ms (95%), errors: 0.00, reconnects:  0.00
[  53s] threads: 64, tps: 3343.01, reads: 46712.09, writes: 13359.03, response time: 31.00ms (95%), errors: 0.00, reconnects:  0.00
[  54s] threads: 64, tps: 2811.00, reads: 39264.99, writes: 11194.00, response time: 35.64ms (95%), errors: 0.00, reconnects:  0.00
[  55s] threads: 64, tps: 2418.00, reads: 34065.96, writes: 9809.99, response time: 42.76ms (95%), errors: 0.00, reconnects:  0.00
[  56s] threads: 64, tps: 1961.00, reads: 27420.03, writes: 7748.01, response time: 52.37ms (95%), errors: 0.00, reconnects:  0.00
[  57s] threads: 64, tps: 1958.00, reads: 27309.96, writes: 7818.99, response time: 51.89ms (95%), errors: 0.00, reconnects:  0.00
[  58s] threads: 64, tps: 1752.00, reads: 24524.02, writes: 6978.01, response time: 53.62ms (95%), errors: 0.00, reconnects:  0.00
[  59s] threads: 64, tps: 1294.00, reads: 18087.99, writes: 5170.00, response time: 89.65ms (95%), errors: 0.00, reconnects:  0.00
[  60s] threads: 64, tps: 1623.00, reads: 22993.03, writes: 6668.01, response time: 103.41ms (95%), errors: 0.00, reconnects:  0.00
[  61s] threads: 64, tps: 1925.00, reads: 26700.96, writes: 7578.99, response time: 47.69ms (95%), errors: 0.00, reconnects:  0.00
[  62s] threads: 64, tps: 1788.00, reads: 25018.98, writes: 7147.00, response time: 52.26ms (95%), errors: 0.00, reconnects:  0.00
[  63s] threads: 64, tps: 1743.00, reads: 24526.02, writes: 6971.01, response time: 53.43ms (95%), errors: 0.00, reconnects:  0.00
[  64s] threads: 64, tps: 1745.00, reads: 24387.00, writes: 6941.00, response time: 49.83ms (95%), errors: 0.00, reconnects:  0.00
[  65s] threads: 64, tps: 1697.00, reads: 23768.99, writes: 6819.00, response time: 54.01ms (95%), errors: 0.00, reconnects:  0.00
[  66s] threads: 64, tps: 1750.00, reads: 24433.99, writes: 7015.00, response time: 58.02ms (95%), errors: 0.00, reconnects:  0.00
[  67s] threads: 64, tps: 1697.00, reads: 23825.02, writes: 6756.00, response time: 55.63ms (95%), errors: 0.00, reconnects:  0.00
[  68s] threads: 64, tps: 1724.00, reads: 24066.99, writes: 6907.00, response time: 53.03ms (95%), errors: 0.00, reconnects:  0.00
[  69s] threads: 64, tps: 1592.00, reads: 22316.03, writes: 6351.01, response time: 59.37ms (95%), errors: 0.00, reconnects:  0.00
[  70s] threads: 64, tps: 1620.99, reads: 22713.88, writes: 6477.96, response time: 53.88ms (95%), errors: 0.00, reconnects:  0.00
[  71s] threads: 64, tps: 1640.01, reads: 22990.09, writes: 6616.03, response time: 55.35ms (95%), errors: 0.00, reconnects:  0.00
[  72s] threads: 64, tps: 1702.00, reads: 23770.00, writes: 6830.00, response time: 54.58ms (95%), errors: 0.00, reconnects:  0.00
[  73s] threads: 64, tps: 1645.99, reads: 23135.86, writes: 6508.96, response time: 57.77ms (95%), errors: 0.00, reconnects:  0.00
[  74s] threads: 64, tps: 1537.01, reads: 21500.14, writes: 6133.04, response time: 63.52ms (95%), errors: 0.00, reconnects:  0.00
[  75s] threads: 64, tps: 1612.99, reads: 22534.91, writes: 6466.97, response time: 57.81ms (95%), errors: 0.00, reconnects:  0.00
[  76s] threads: 64, tps: 1804.01, reads: 25143.09, writes: 7234.03, response time: 51.42ms (95%), errors: 0.00, reconnects:  0.00
[  77s] threads: 64, tps: 1783.00, reads: 25011.00, writes: 7155.00, response time: 50.93ms (95%), errors: 0.00, reconnects:  0.00
[  78s] threads: 64, tps: 2017.99, reads: 28321.89, writes: 8037.97, response time: 44.65ms (95%), errors: 0.00, reconnects:  0.00
[  79s] threads: 64, tps: 2023.00, reads: 28455.04, writes: 8168.01, response time: 46.11ms (95%), errors: 0.00, reconnects:  0.00
[  80s] threads: 64, tps: 2195.00, reads: 30612.96, writes: 8700.99, response time: 42.31ms (95%), errors: 0.00, reconnects:  0.00
[  81s] threads: 64, tps: 2647.01, reads: 37039.19, writes: 10617.06, response time: 36.97ms (95%), errors: 0.00, reconnects:  0.00
[  82s] threads: 64, tps: 2820.99, reads: 39484.92, writes: 11277.98, response time: 34.46ms (95%), errors: 0.00, reconnects:  0.00
[  83s] threads: 64, tps: 3174.00, reads: 44475.02, writes: 12681.00, response time: 31.20ms (95%), errors: 0.00, reconnects:  0.00
[  84s] threads: 64, tps: 2990.99, reads: 41975.81, writes: 12065.94, response time: 37.85ms (95%), errors: 0.00, reconnects:  0.00
[  85s] threads: 64, tps: 2966.01, reads: 41315.18, writes: 11741.05, response time: 41.58ms (95%), errors: 0.00, reconnects:  0.00
[  86s] threads: 64, tps: 2104.00, reads: 29562.02, writes: 8429.00, response time: 100.15ms (95%), errors: 0.00, reconnects:  0.00
[  87s] threads: 64, tps: 3344.00, reads: 46849.00, writes: 13406.00, response time: 29.86ms (95%), errors: 0.00, reconnects:  0.00
[  88s] threads: 64, tps: 2983.99, reads: 41777.82, writes: 11928.95, response time: 31.84ms (95%), errors: 0.00, reconnects:  0.00
[  89s] threads: 64, tps: 2926.01, reads: 40932.21, writes: 11692.06, response time: 33.92ms (95%), errors: 0.00, reconnects:  0.00
[  90s] threads: 64, tps: 2827.99, reads: 39567.89, writes: 11330.97, response time: 33.30ms (95%), errors: 0.00, reconnects:  0.00
[  91s] threads: 64, tps: 2709.01, reads: 37988.08, writes: 10849.02, response time: 36.30ms (95%), errors: 0.00, reconnects:  0.00
[  92s] threads: 64, tps: 2598.99, reads: 36379.85, writes: 10433.96, response time: 37.78ms (95%), errors: 0.00, reconnects:  0.00
[  93s] threads: 64, tps: 2403.01, reads: 33546.13, writes: 9534.04, response time: 40.46ms (95%), errors: 0.00, reconnects:  0.00
[  94s] threads: 64, tps: 2214.00, reads: 31082.98, writes: 8905.99, response time: 41.06ms (95%), errors: 0.00, reconnects:  0.00
[  95s] threads: 64, tps: 2128.99, reads: 29739.91, writes: 8502.97, response time: 43.32ms (95%), errors: 0.00, reconnects:  0.00
[  96s] threads: 64, tps: 1957.01, reads: 27457.12, writes: 7835.03, response time: 48.67ms (95%), errors: 0.00, reconnects:  0.00
[  97s] threads: 64, tps: 1966.00, reads: 27584.99, writes: 7895.00, response time: 48.38ms (95%), errors: 0.00, reconnects:  0.00
[  98s] threads: 64, tps: 2004.00, reads: 27921.00, writes: 7959.00, response time: 47.08ms (95%), errors: 0.00, reconnects:  0.00
[  99s] threads: 64, tps: 1931.00, reads: 27193.00, writes: 7811.00, response time: 47.20ms (95%), errors: 0.00, reconnects:  0.00
[ 100s] threads: 64, tps: 1946.99, reads: 27077.89, writes: 7696.97, response time: 51.32ms (95%), errors: 0.00, reconnects:  0.00
[ 101s] threads: 64, tps: 1837.01, reads: 25620.12, writes: 7347.04, response time: 50.13ms (95%), errors: 0.00, reconnects:  0.00
[ 102s] threads: 64, tps: 1750.98, reads: 24712.77, writes: 7035.93, response time: 52.29ms (95%), errors: 0.00, reconnects:  0.00
[ 103s] threads: 64, tps: 1599.01, reads: 22340.16, writes: 6335.04, response time: 58.70ms (95%), errors: 0.00, reconnects:  0.00
[ 104s] threads: 64, tps: 1584.00, reads: 22163.02, writes: 6348.01, response time: 57.95ms (95%), errors: 0.00, reconnects:  0.00
[ 105s] threads: 64, tps: 1436.00, reads: 20105.02, writes: 5780.00, response time: 61.58ms (95%), errors: 0.00, reconnects:  0.00
[ 106s] threads: 64, tps: 1559.99, reads: 21815.87, writes: 6197.96, response time: 58.28ms (95%), errors: 0.00, reconnects:  0.00
[ 107s] threads: 64, tps: 1614.00, reads: 22588.03, writes: 6449.01, response time: 54.91ms (95%), errors: 0.00, reconnects:  0.00
[ 108s] threads: 64, tps: 1529.01, reads: 21472.12, writes: 6119.03, response time: 58.14ms (95%), errors: 0.00, reconnects:  0.00
[ 109s] threads: 64, tps: 1475.99, reads: 20628.91, writes: 5929.97, response time: 61.47ms (95%), errors: 0.00, reconnects:  0.00
[ 110s] threads: 64, tps: 1384.00, reads: 19379.99, writes: 5536.00, response time: 66.74ms (95%), errors: 0.00, reconnects:  0.00
[ 111s] threads: 64, tps: 1328.00, reads: 18510.99, writes: 5283.00, response time: 65.38ms (95%), errors: 0.00, reconnects:  0.00
[ 112s] threads: 64, tps: 1431.01, reads: 20093.08, writes: 5731.02, response time: 59.94ms (95%), errors: 0.00, reconnects:  0.00
[ 113s] threads: 64, tps: 1333.00, reads: 18680.93, writes: 5322.98, response time: 70.35ms (95%), errors: 0.00, reconnects:  0.00
[ 114s] threads: 64, tps: 1547.00, reads: 21661.97, writes: 6237.99, response time: 57.03ms (95%), errors: 0.00, reconnects:  0.00
[ 115s] threads: 64, tps: 1568.00, reads: 21964.99, writes: 6226.00, response time: 55.45ms (95%), errors: 0.00, reconnects:  0.00
[ 116s] threads: 64, tps: 1480.01, reads: 20724.13, writes: 5935.04, response time: 65.89ms (95%), errors: 0.00, reconnects:  0.00
[ 117s] threads: 64, tps: 1570.99, reads: 21982.90, writes: 6364.97, response time: 61.95ms (95%), errors: 0.00, reconnects:  0.00
[ 118s] threads: 64, tps: 1682.00, reads: 23643.01, writes: 6737.00, response time: 54.08ms (95%), errors: 0.00, reconnects:  0.00
[ 119s] threads: 64, tps: 1775.01, reads: 24797.08, writes: 7097.02, response time: 52.92ms (95%), errors: 0.00, reconnects:  0.00
[ 120s] threads: 64, tps: 1667.00, reads: 23273.94, writes: 6584.98, response time: 55.24ms (95%), errors: 0.00, reconnects:  0.00
[ 121s] threads: 64, tps: 1655.00, reads: 23202.06, writes: 6667.02, response time: 57.38ms (95%), errors: 0.00, reconnects:  0.00
[ 122s] threads: 64, tps: 1588.00, reads: 22239.95, writes: 6350.99, response time: 60.99ms (95%), errors: 0.00, reconnects:  0.00
[ 123s] threads: 64, tps: 1831.00, reads: 25643.06, writes: 7312.02, response time: 53.83ms (95%), errors: 0.00, reconnects:  0.00
[ 124s] threads: 64, tps: 1923.00, reads: 26929.00, writes: 7680.00, response time: 49.65ms (95%), errors: 0.00, reconnects:  0.00
[ 125s] threads: 64, tps: 2037.99, reads: 28547.84, writes: 8146.95, response time: 47.94ms (95%), errors: 0.00, reconnects:  0.00
[ 126s] threads: 64, tps: 2154.01, reads: 30148.17, writes: 8643.05, response time: 46.43ms (95%), errors: 0.00, reconnects:  0.00
[ 127s] threads: 64, tps: 2393.00, reads: 33329.01, writes: 9529.00, response time: 42.74ms (95%), errors: 0.00, reconnects:  0.00
[ 128s] threads: 64, tps: 2553.99, reads: 35728.86, writes: 10236.96, response time: 40.51ms (95%), errors: 0.00, reconnects:  0.00
[ 129s] threads: 64, tps: 3103.99, reads: 43608.80, writes: 12410.94, response time: 33.91ms (95%), errors: 0.00, reconnects:  0.00
[ 130s] threads: 64, tps: 3515.03, reads: 49285.38, writes: 14178.11, response time: 28.32ms (95%), errors: 0.00, reconnects:  0.00
[ 131s] threads: 64, tps: 3719.99, reads: 52146.80, writes: 14839.94, response time: 26.15ms (95%), errors: 0.00, reconnects:  0.00
[ 132s] threads: 64, tps: 3609.01, reads: 50347.09, writes: 14330.03, response time: 28.09ms (95%), errors: 0.00, reconnects:  0.00
[ 133s] threads: 64, tps: 3288.99, reads: 46173.86, writes: 13220.96, response time: 30.58ms (95%), errors: 0.00, reconnects:  0.00
[ 134s] threads: 64, tps: 3243.02, reads: 45352.26, writes: 12958.07, response time: 32.02ms (95%), errors: 0.00, reconnects:  0.00
[ 135s] threads: 64, tps: 3061.99, reads: 42866.92, writes: 12252.98, response time: 33.00ms (95%), errors: 0.00, reconnects:  0.00
[ 136s] threads: 64, tps: 2745.99, reads: 38330.88, writes: 10953.97, response time: 36.70ms (95%), errors: 0.00, reconnects:  0.00
[ 137s] threads: 64, tps: 2637.01, reads: 36990.18, writes: 10515.05, response time: 41.56ms (95%), errors: 0.00, reconnects:  0.00
[ 138s] threads: 64, tps: 2226.98, reads: 31123.79, writes: 8969.94, response time: 46.71ms (95%), errors: 0.00, reconnects:  0.00
[ 139s] threads: 64, tps: 2007.01, reads: 27998.15, writes: 7968.04, response time: 50.43ms (95%), errors: 0.00, reconnects:  0.00
[ 140s] threads: 64, tps: 1918.00, reads: 26954.02, writes: 7679.01, response time: 52.54ms (95%), errors: 0.00, reconnects:  0.00
[ 141s] threads: 64, tps: 1743.00, reads: 24424.04, writes: 6974.01, response time: 55.01ms (95%), errors: 0.00, reconnects:  0.00
[ 142s] threads: 64, tps: 1773.99, reads: 24930.81, writes: 7140.94, response time: 55.35ms (95%), errors: 0.00, reconnects:  0.00
[ 143s] threads: 64, tps: 1841.01, reads: 25606.14, writes: 7305.04, response time: 53.10ms (95%), errors: 0.00, reconnects:  0.00
[ 144s] threads: 64, tps: 1988.00, reads: 27945.02, writes: 7993.00, response time: 47.46ms (95%), errors: 0.00, reconnects:  0.00
[ 145s] threads: 64, tps: 2020.00, reads: 28173.02, writes: 8059.01, response time: 47.35ms (95%), errors: 0.00, reconnects:  0.00
[ 146s] threads: 64, tps: 2093.99, reads: 29450.89, writes: 8400.97, response time: 44.63ms (95%), errors: 0.00, reconnects:  0.00
[ 147s] threads: 64, tps: 2183.01, reads: 30557.14, writes: 8774.04, response time: 45.13ms (95%), errors: 0.00, reconnects:  0.00
[ 148s] threads: 64, tps: 2021.99, reads: 28220.93, writes: 8028.98, response time: 46.68ms (95%), errors: 0.00, reconnects:  0.00
[ 149s] threads: 64, tps: 2029.00, reads: 28471.06, writes: 8135.02, response time: 45.70ms (95%), errors: 0.00, reconnects:  0.00
[ 150s] threads: 64, tps: 1972.00, reads: 27616.01, writes: 7899.00, response time: 46.63ms (95%), errors: 0.00, reconnects:  0.00
[ 151s] threads: 64, tps: 1989.00, reads: 27865.97, writes: 7946.99, response time: 45.50ms (95%), errors: 0.00, reconnects:  0.00
[ 152s] threads: 64, tps: 1835.99, reads: 25680.91, writes: 7316.97, response time: 51.35ms (95%), errors: 0.00, reconnects:  0.00
[ 153s] threads: 64, tps: 1784.01, reads: 24958.09, writes: 7115.02, response time: 54.61ms (95%), errors: 0.00, reconnects:  0.00
[ 154s] threads: 64, tps: 1832.00, reads: 25700.98, writes: 7355.99, response time: 50.01ms (95%), errors: 0.00, reconnects:  0.00
[ 155s] threads: 64, tps: 1907.00, reads: 26650.02, writes: 7657.01, response time: 46.77ms (95%), errors: 0.00, reconnects:  0.00
[ 156s] threads: 64, tps: 1849.00, reads: 25995.98, writes: 7444.99, response time: 49.09ms (95%), errors: 0.00, reconnects:  0.00
[ 157s] threads: 64, tps: 1828.99, reads: 25614.87, writes: 7320.96, response time: 50.13ms (95%), errors: 0.00, reconnects:  0.00
[ 158s] threads: 64, tps: 1816.01, reads: 25273.13, writes: 7168.04, response time: 50.98ms (95%), errors: 0.00, reconnects:  0.00
[ 159s] threads: 64, tps: 1837.00, reads: 25833.04, writes: 7408.01, response time: 49.71ms (95%), errors: 0.00, reconnects:  0.00
[ 160s] threads: 64, tps: 1806.98, reads: 25221.67, writes: 7154.91, response time: 51.02ms (95%), errors: 0.00, reconnects:  0.00
[ 161s] threads: 64, tps: 1684.01, reads: 23577.20, writes: 6770.06, response time: 53.72ms (95%), errors: 0.00, reconnects:  0.00
[ 162s] threads: 64, tps: 1609.00, reads: 22598.00, writes: 6428.00, response time: 63.81ms (95%), errors: 0.00, reconnects:  0.00
[ 163s] threads: 64, tps: 1511.00, reads: 21105.99, writes: 6063.00, response time: 62.08ms (95%), errors: 0.00, reconnects:  0.00
[ 164s] threads: 64, tps: 1638.01, reads: 22836.08, writes: 6513.02, response time: 54.08ms (95%), errors: 0.00, reconnects:  0.00
[ 165s] threads: 64, tps: 1618.99, reads: 22784.92, writes: 6549.98, response time: 54.24ms (95%), errors: 0.00, reconnects:  0.00
[ 166s] threads: 64, tps: 1691.00, reads: 23647.02, writes: 6737.01, response time: 53.05ms (95%), errors: 0.00, reconnects:  0.00
[ 167s] threads: 64, tps: 1697.00, reads: 23721.98, writes: 6778.99, response time: 52.12ms (95%), errors: 0.00, reconnects:  0.00
[ 168s] threads: 64, tps: 1685.00, reads: 23626.00, writes: 6732.00, response time: 52.81ms (95%), errors: 0.00, reconnects:  0.00
[ 169s] threads: 64, tps: 1723.01, reads: 24110.10, writes: 6880.03, response time: 53.19ms (95%), errors: 0.00, reconnects:  0.00
[ 170s] threads: 64, tps: 1599.00, reads: 22447.00, writes: 6428.00, response time: 55.17ms (95%), errors: 0.00, reconnects:  0.00
[ 171s] threads: 64, tps: 1612.99, reads: 22504.90, writes: 6388.97, response time: 52.87ms (95%), errors: 0.00, reconnects:  0.00
[ 172s] threads: 64, tps: 1507.01, reads: 21184.09, writes: 6111.03, response time: 60.16ms (95%), errors: 0.00, reconnects:  0.00
[ 173s] threads: 64, tps: 1486.00, reads: 20642.94, writes: 5881.98, response time: 61.26ms (95%), errors: 0.00, reconnects:  0.00
[ 174s] threads: 64, tps: 1426.99, reads: 19991.88, writes: 5709.97, response time: 63.43ms (95%), errors: 0.00, reconnects:  0.00
[ 175s] threads: 64, tps: 1449.01, reads: 20315.09, writes: 5777.03, response time: 63.13ms (95%), errors: 0.00, reconnects:  0.00
[ 176s] threads: 64, tps: 1583.01, reads: 22312.08, writes: 6440.02, response time: 55.65ms (95%), errors: 0.00, reconnects:  0.00
[ 177s] threads: 64, tps: 1509.00, reads: 20989.02, writes: 5956.00, response time: 62.28ms (95%), errors: 0.00, reconnects:  0.00
[ 178s] threads: 64, tps: 1426.99, reads: 20039.90, writes: 5720.97, response time: 63.49ms (95%), errors: 0.00, reconnects:  0.00
[ 179s] threads: 64, tps: 1506.01, reads: 21011.12, writes: 5989.03, response time: 62.19ms (95%), errors: 0.00, reconnects:  0.00
[ 180s] threads: 64, tps: 1328.00, reads: 18579.98, writes: 5319.00, response time: 68.32ms (95%), errors: 0.00, reconnects:  0.00
[ 181s] threads: 64, tps: 1452.99, reads: 20353.92, writes: 5808.98, response time: 64.06ms (95%), errors: 0.00, reconnects:  0.00
[ 182s] threads: 64, tps: 1357.01, reads: 19016.11, writes: 5421.03, response time: 65.51ms (95%), errors: 0.00, reconnects:  0.00
[ 183s] threads: 64, tps: 1498.00, reads: 20958.99, writes: 6045.00, response time: 57.79ms (95%), errors: 0.00, reconnects:  0.00
[ 184s] threads: 64, tps: 1527.00, reads: 21346.96, writes: 6080.99, response time: 55.58ms (95%), errors: 0.00, reconnects:  0.00
[ 185s] threads: 64, tps: 1617.00, reads: 22759.93, writes: 6529.98, response time: 52.80ms (95%), errors: 0.00, reconnects:  0.00
[ 186s] threads: 64, tps: 1633.01, reads: 22800.07, writes: 6481.02, response time: 55.63ms (95%), errors: 0.00, reconnects:  0.00
[ 187s] threads: 64, tps: 1668.00, reads: 23422.02, writes: 6683.01, response time: 54.66ms (95%), errors: 0.00, reconnects:  0.00
[ 188s] threads: 64, tps: 1660.00, reads: 23104.98, writes: 6611.99, response time: 55.19ms (95%), errors: 0.00, reconnects:  0.00
[ 189s] threads: 64, tps: 1591.00, reads: 22236.93, writes: 6356.98, response time: 56.15ms (95%), errors: 0.00, reconnects:  0.00
[ 190s] threads: 64, tps: 1486.01, reads: 20883.08, writes: 5951.02, response time: 61.97ms (95%), errors: 0.00, reconnects:  0.00
[ 191s] threads: 64, tps: 1482.00, reads: 20806.02, writes: 5914.01, response time: 61.39ms (95%), errors: 0.00, reconnects:  0.00
[ 192s] threads: 64, tps: 1482.00, reads: 20686.99, writes: 5936.00, response time: 61.47ms (95%), errors: 0.00, reconnects:  0.00
[ 193s] threads: 64, tps: 1519.00, reads: 21324.00, writes: 6098.00, response time: 59.80ms (95%), errors: 0.00, reconnects:  0.00
[ 194s] threads: 64, tps: 1535.00, reads: 21395.98, writes: 6108.99, response time: 56.78ms (95%), errors: 0.00, reconnects:  0.00
[ 195s] threads: 64, tps: 1612.99, reads: 22620.89, writes: 6508.97, response time: 55.70ms (95%), errors: 0.00, reconnects:  0.00
[ 196s] threads: 64, tps: 1647.01, reads: 23128.12, writes: 6570.03, response time: 54.19ms (95%), errors: 0.00, reconnects:  0.00
[ 197s] threads: 64, tps: 1671.00, reads: 23492.03, writes: 6783.01, response time: 54.64ms (95%), errors: 0.00, reconnects:  0.00
[ 198s] threads: 64, tps: 1675.00, reads: 23224.98, writes: 6570.00, response time: 54.73ms (95%), errors: 0.00, reconnects:  0.00
[ 199s] threads: 64, tps: 1643.00, reads: 23101.99, writes: 6563.00, response time: 54.40ms (95%), errors: 0.00, reconnects:  0.00
[ 200s] threads: 64, tps: 1616.00, reads: 22667.98, writes: 6582.00, response time: 56.19ms (95%), errors: 0.00, reconnects:  0.00
[ 201s] threads: 64, tps: 1577.00, reads: 22013.04, writes: 6195.01, response time: 58.29ms (95%), errors: 0.00, reconnects:  0.00
[ 202s] threads: 64, tps: 1594.00, reads: 22270.97, writes: 6359.99, response time: 57.76ms (95%), errors: 0.00, reconnects:  0.00
[ 203s] threads: 64, tps: 1594.99, reads: 22371.90, writes: 6432.97, response time: 55.34ms (95%), errors: 0.00, reconnects:  0.00
[ 204s] threads: 64, tps: 1680.98, reads: 23599.66, writes: 6790.90, response time: 52.69ms (95%), errors: 0.00, reconnects:  0.00
[ 205s] threads: 64, tps: 1833.04, reads: 25679.51, writes: 7277.14, response time: 50.81ms (95%), errors: 0.00, reconnects:  0.00
[ 206s] threads: 64, tps: 1814.00, reads: 25317.03, writes: 7233.01, response time: 55.67ms (95%), errors: 0.00, reconnects:  0.00
[ 207s] threads: 64, tps: 1867.00, reads: 26139.00, writes: 7448.00, response time: 51.72ms (95%), errors: 0.00, reconnects:  0.00
[ 208s] threads: 64, tps: 1820.00, reads: 25457.98, writes: 7267.99, response time: 52.09ms (95%), errors: 0.00, reconnects:  0.00
[ 209s] threads: 64, tps: 1641.98, reads: 22999.70, writes: 6597.91, response time: 57.64ms (95%), errors: 0.00, reconnects:  0.00
[ 210s] threads: 64, tps: 1750.02, reads: 24455.29, writes: 7003.08, response time: 55.34ms (95%), errors: 0.00, reconnects:  0.00
[ 211s] threads: 64, tps: 1567.00, reads: 22013.00, writes: 6246.00, response time: 65.75ms (95%), errors: 0.00, reconnects:  0.00
[ 212s] threads: 64, tps: 1731.00, reads: 24255.01, writes: 6951.00, response time: 56.71ms (95%), errors: 0.00, reconnects:  0.00
[ 213s] threads: 64, tps: 1854.99, reads: 25849.91, writes: 7381.97, response time: 53.67ms (95%), errors: 0.00, reconnects:  0.00
[ 214s] threads: 64, tps: 1972.01, reads: 27664.11, writes: 7895.03, response time: 50.77ms (95%), errors: 0.00, reconnects:  0.00
[ 215s] threads: 64, tps: 2091.00, reads: 29308.97, writes: 8435.99, response time: 45.88ms (95%), errors: 0.00, reconnects:  0.00
[ 216s] threads: 64, tps: 2230.00, reads: 31183.04, writes: 8852.01, response time: 44.29ms (95%), errors: 0.00, reconnects:  0.00
[ 217s] threads: 64, tps: 2828.00, reads: 39707.97, writes: 11374.99, response time: 34.06ms (95%), errors: 0.00, reconnects:  0.00
[ 218s] threads: 64, tps: 3084.00, reads: 43111.01, writes: 12294.00, response time: 32.40ms (95%), errors: 0.00, reconnects:  0.00
[ 219s] threads: 64, tps: 3121.00, reads: 43637.01, writes: 12518.00, response time: 31.82ms (95%), errors: 0.00, reconnects:  0.00
[ 220s] threads: 64, tps: 3127.01, reads: 43728.07, writes: 12448.02, response time: 30.92ms (95%), errors: 0.00, reconnects:  0.00
[ 221s] threads: 64, tps: 3113.99, reads: 43729.84, writes: 12475.96, response time: 32.49ms (95%), errors: 0.00, reconnects:  0.00
[ 222s] threads: 64, tps: 2942.01, reads: 41169.11, writes: 11829.03, response time: 32.24ms (95%), errors: 0.00, reconnects:  0.00
[ 223s] threads: 64, tps: 2957.00, reads: 41351.97, writes: 11762.99, response time: 32.73ms (95%), errors: 0.00, reconnects:  0.00
[ 224s] threads: 64, tps: 3011.00, reads: 42115.02, writes: 12022.01, response time: 34.88ms (95%), errors: 0.00, reconnects:  0.00
[ 225s] threads: 64, tps: 2953.97, reads: 41586.61, writes: 11953.89, response time: 32.74ms (95%), errors: 0.00, reconnects:  0.00
[ 226s] threads: 64, tps: 3044.03, reads: 42480.40, writes: 12076.11, response time: 32.91ms (95%), errors: 0.00, reconnects:  0.00
[ 227s] threads: 64, tps: 2938.94, reads: 41132.19, writes: 11764.77, response time: 32.49ms (95%), errors: 0.00, reconnects:  0.00
[ 228s] threads: 64, tps: 2845.05, reads: 39809.75, writes: 11370.22, response time: 33.55ms (95%), errors: 0.00, reconnects:  0.00
[ 229s] threads: 64, tps: 2815.00, reads: 39404.01, writes: 11225.00, response time: 34.61ms (95%), errors: 0.00, reconnects:  0.00
[ 230s] threads: 64, tps: 2922.00, reads: 40935.94, writes: 11691.98, response time: 33.71ms (95%), errors: 0.00, reconnects:  0.00
[ 231s] threads: 64, tps: 2845.00, reads: 39726.01, writes: 11451.00, response time: 34.47ms (95%), errors: 0.00, reconnects:  0.00
[ 232s] threads: 64, tps: 2971.00, reads: 41731.00, writes: 11886.00, response time: 33.16ms (95%), errors: 0.00, reconnects:  0.00
[ 233s] threads: 64, tps: 2691.00, reads: 37676.05, writes: 10732.01, response time: 36.52ms (95%), errors: 0.00, reconnects:  0.00
[ 234s] threads: 64, tps: 2627.00, reads: 36724.99, writes: 10514.00, response time: 36.59ms (95%), errors: 0.00, reconnects:  0.00
[ 235s] threads: 64, tps: 2721.98, reads: 38095.78, writes: 10847.94, response time: 36.14ms (95%), errors: 0.00, reconnects:  0.00
[ 236s] threads: 64, tps: 2761.02, reads: 38691.22, writes: 11041.06, response time: 34.61ms (95%), errors: 0.00, reconnects:  0.00
[ 237s] threads: 64, tps: 2638.00, reads: 36928.96, writes: 10567.99, response time: 37.41ms (95%), errors: 0.00, reconnects:  0.00
[ 238s] threads: 64, tps: 2633.00, reads: 36967.02, writes: 10636.01, response time: 36.86ms (95%), errors: 0.00, reconnects:  0.00
[ 239s] threads: 64, tps: 2639.00, reads: 36758.00, writes: 10492.00, response time: 36.34ms (95%), errors: 0.00, reconnects:  0.00
[ 240s] threads: 64, tps: 2673.00, reads: 37455.98, writes: 10642.99, response time: 37.55ms (95%), errors: 0.00, reconnects:  0.00
[ 241s] threads: 64, tps: 2562.00, reads: 35806.03, writes: 10268.01, response time: 38.83ms (95%), errors: 0.00, reconnects:  0.00
[ 242s] threads: 64, tps: 2518.00, reads: 35368.03, writes: 10155.01, response time: 39.21ms (95%), errors: 0.00, reconnects:  0.00
[ 243s] threads: 64, tps: 2333.00, reads: 32661.01, writes: 9247.00, response time: 41.94ms (95%), errors: 0.00, reconnects:  0.00
[ 244s] threads: 64, tps: 2348.00, reads: 32796.95, writes: 9396.98, response time: 42.25ms (95%), errors: 0.00, reconnects:  0.00
[ 245s] threads: 64, tps: 2060.95, reads: 28897.36, writes: 8224.82, response time: 47.37ms (95%), errors: 0.00, reconnects:  0.00
[ 246s] threads: 64, tps: 1948.05, reads: 27300.65, writes: 7786.18, response time: 49.52ms (95%), errors: 0.00, reconnects:  0.00
[ 247s] threads: 64, tps: 1720.00, reads: 24075.94, writes: 6900.98, response time: 53.22ms (95%), errors: 0.00, reconnects:  0.00
[ 248s] threads: 64, tps: 1582.00, reads: 22162.03, writes: 6305.01, response time: 60.03ms (95%), errors: 0.00, reconnects:  0.00
[ 249s] threads: 64, tps: 1573.00, reads: 21991.02, writes: 6279.01, response time: 61.47ms (95%), errors: 0.00, reconnects:  0.00
[ 250s] threads: 64, tps: 1751.99, reads: 24536.86, writes: 7029.96, response time: 54.71ms (95%), errors: 0.00, reconnects:  0.00
[ 251s] threads: 64, tps: 1740.01, reads: 24350.13, writes: 6973.04, response time: 53.88ms (95%), errors: 0.00, reconnects:  0.00
[ 252s] threads: 64, tps: 1720.00, reads: 24047.99, writes: 6892.00, response time: 54.14ms (95%), errors: 0.00, reconnects:  0.00
[ 253s] threads: 64, tps: 1846.00, reads: 25863.99, writes: 7352.00, response time: 51.10ms (95%), errors: 0.00, reconnects:  0.00
[ 254s] threads: 64, tps: 1737.00, reads: 24287.99, writes: 7007.00, response time: 53.29ms (95%), errors: 0.00, reconnects:  0.00
[ 255s] threads: 64, tps: 1754.00, reads: 24701.97, writes: 7061.99, response time: 52.57ms (95%), errors: 0.00, reconnects:  0.00
[ 256s] threads: 64, tps: 1649.00, reads: 22994.01, writes: 6551.00, response time: 58.03ms (95%), errors: 0.00, reconnects:  0.00
[ 257s] threads: 64, tps: 1603.00, reads: 22418.01, writes: 6356.00, response time: 58.36ms (95%), errors: 0.00, reconnects:  0.00
[ 258s] threads: 64, tps: 1579.00, reads: 22202.01, writes: 6374.00, response time: 62.73ms (95%), errors: 0.00, reconnects:  0.00
[ 259s] threads: 64, tps: 1461.00, reads: 20362.02, writes: 5787.01, response time: 65.38ms (95%), errors: 0.00, reconnects:  0.00
[ 260s] threads: 64, tps: 1435.00, reads: 20033.97, writes: 5714.99, response time: 65.04ms (95%), errors: 0.00, reconnects:  0.00
[ 261s] threads: 64, tps: 1437.00, reads: 20113.99, writes: 5850.00, response time: 65.38ms (95%), errors: 0.00, reconnects:  0.00
[ 262s] threads: 64, tps: 1415.00, reads: 19899.94, writes: 5591.98, response time: 66.38ms (95%), errors: 0.00, reconnects:  0.00
[ 263s] threads: 64, tps: 1599.00, reads: 22388.04, writes: 6397.01, response time: 54.92ms (95%), errors: 0.00, reconnects:  0.00
[ 264s] threads: 64, tps: 1617.00, reads: 22704.04, writes: 6525.01, response time: 53.64ms (95%), errors: 0.00, reconnects:  0.00
[ 265s] threads: 64, tps: 1639.00, reads: 22852.94, writes: 6485.98, response time: 55.63ms (95%), errors: 0.00, reconnects:  0.00
[ 266s] threads: 64, tps: 1586.98, reads: 22175.75, writes: 6336.93, response time: 58.03ms (95%), errors: 0.00, reconnects:  0.00
[ 267s] threads: 64, tps: 1711.02, reads: 24044.32, writes: 6934.09, response time: 53.64ms (95%), errors: 0.00, reconnects:  0.00
[ 268s] threads: 64, tps: 1716.00, reads: 24028.02, writes: 6830.01, response time: 55.49ms (95%), errors: 0.00, reconnects:  0.00
[ 269s] threads: 64, tps: 1524.00, reads: 21253.99, writes: 6125.00, response time: 62.54ms (95%), errors: 0.00, reconnects:  0.00
[ 270s] threads: 64, tps: 1716.00, reads: 23975.01, writes: 6813.00, response time: 55.90ms (95%), errors: 0.00, reconnects:  0.00
[ 271s] threads: 64, tps: 1678.00, reads: 23401.98, writes: 6730.00, response time: 56.51ms (95%), errors: 0.00, reconnects:  0.00
[ 272s] threads: 64, tps: 1501.00, reads: 21181.00, writes: 5947.00, response time: 59.71ms (95%), errors: 0.00, reconnects:  0.00
[ 273s] threads: 64, tps: 1516.00, reads: 21165.96, writes: 6094.99, response time: 63.16ms (95%), errors: 0.00, reconnects:  0.00
[ 274s] threads: 64, tps: 1679.00, reads: 23518.04, writes: 6718.01, response time: 54.29ms (95%), errors: 0.00, reconnects:  0.00
[ 275s] threads: 64, tps: 1633.00, reads: 22854.02, writes: 6518.01, response time: 53.29ms (95%), errors: 0.00, reconnects:  0.00
[ 276s] threads: 64, tps: 1546.00, reads: 21661.99, writes: 6167.00, response time: 57.36ms (95%), errors: 0.00, reconnects:  0.00
[ 277s] threads: 64, tps: 1567.00, reads: 21961.00, writes: 6269.00, response time: 57.74ms (95%), errors: 0.00, reconnects:  0.00
[ 278s] threads: 64, tps: 1691.99, reads: 23672.90, writes: 6776.97, response time: 53.62ms (95%), errors: 0.00, reconnects:  0.00
[ 279s] threads: 64, tps: 1765.01, reads: 24745.13, writes: 7118.04, response time: 49.17ms (95%), errors: 0.00, reconnects:  0.00
[ 280s] threads: 64, tps: 1882.00, reads: 26233.99, writes: 7475.00, response time: 48.26ms (95%), errors: 0.00, reconnects:  0.00
[ 281s] threads: 64, tps: 1757.00, reads: 24642.97, writes: 7005.99, response time: 50.83ms (95%), errors: 0.00, reconnects:  0.00
[ 282s] threads: 64, tps: 1832.00, reads: 25633.02, writes: 7342.01, response time: 49.05ms (95%), errors: 0.00, reconnects:  0.00
[ 283s] threads: 64, tps: 1758.00, reads: 24673.00, writes: 7024.00, response time: 50.80ms (95%), errors: 0.00, reconnects:  0.00
[ 284s] threads: 64, tps: 1705.00, reads: 23925.01, writes: 6824.00, response time: 51.76ms (95%), errors: 0.00, reconnects:  0.00
[ 285s] threads: 64, tps: 1590.00, reads: 22210.97, writes: 6355.99, response time: 56.47ms (95%), errors: 0.00, reconnects:  0.00
[ 286s] threads: 64, tps: 1584.00, reads: 22196.01, writes: 6352.00, response time: 55.44ms (95%), errors: 0.00, reconnects:  0.00
[ 287s] threads: 64, tps: 1606.00, reads: 22464.02, writes: 6427.01, response time: 52.21ms (95%), errors: 0.00, reconnects:  0.00
[ 288s] threads: 64, tps: 1655.00, reads: 23140.00, writes: 6611.00, response time: 52.43ms (95%), errors: 0.00, reconnects:  0.00
[ 289s] threads: 64, tps: 1726.00, reads: 24158.96, writes: 6941.99, response time: 49.95ms (95%), errors: 0.00, reconnects:  0.00
[ 290s] threads: 64, tps: 1815.00, reads: 25427.04, writes: 7276.01, response time: 49.17ms (95%), errors: 0.00, reconnects:  0.00
[ 291s] threads: 64, tps: 1818.00, reads: 25484.95, writes: 7268.99, response time: 48.71ms (95%), errors: 0.00, reconnects:  0.00
[ 292s] threads: 64, tps: 1792.00, reads: 25105.02, writes: 7171.01, response time: 51.18ms (95%), errors: 0.00, reconnects:  0.00
[ 293s] threads: 64, tps: 1809.00, reads: 25357.98, writes: 7233.99, response time: 48.43ms (95%), errors: 0.00, reconnects:  0.00
[ 294s] threads: 64, tps: 1802.00, reads: 25211.06, writes: 7194.02, response time: 49.31ms (95%), errors: 0.00, reconnects:  0.00
[ 295s] threads: 64, tps: 1759.00, reads: 24527.98, writes: 6992.00, response time: 51.04ms (95%), errors: 0.00, reconnects:  0.00
[ 296s] threads: 64, tps: 1619.00, reads: 22847.01, writes: 6548.00, response time: 56.07ms (95%), errors: 0.00, reconnects:  0.00
[ 297s] threads: 64, tps: 1608.00, reads: 22399.93, writes: 6361.98, response time: 57.22ms (95%), errors: 0.00, reconnects:  0.00
[ 298s] threads: 64, tps: 1667.00, reads: 23328.02, writes: 6660.01, response time: 51.65ms (95%), errors: 0.00, reconnects:  0.00
[ 299s] threads: 64, tps: 1749.00, reads: 24443.04, writes: 6998.01, response time: 50.31ms (95%), errors: 0.00, reconnects:  0.00
[ 300s] threads: 64, tps: 1754.00, reads: 24604.98, writes: 7081.99, response time: 49.43ms (95%), errors: 0.00, reconnects:  0.00
[ 301s] threads: 64, tps: 1884.99, reads: 26256.86, writes: 7489.96, response time: 49.59ms (95%), errors: 0.00, reconnects:  0.00
[ 302s] threads: 64, tps: 1880.01, reads: 26500.18, writes: 7570.05, response time: 48.02ms (95%), errors: 0.00, reconnects:  0.00
[ 303s] threads: 64, tps: 1871.99, reads: 26108.82, writes: 7444.95, response time: 49.73ms (95%), errors: 0.00, reconnects:  0.00
[ 304s] threads: 64, tps: 1838.00, reads: 25717.01, writes: 7388.00, response time: 49.76ms (95%), errors: 0.00, reconnects:  0.00
[ 305s] threads: 64, tps: 1865.97, reads: 26142.65, writes: 7425.90, response time: 49.62ms (95%), errors: 0.00, reconnects:  0.00
[ 306s] threads: 64, tps: 1806.03, reads: 25370.46, writes: 7296.13, response time: 49.77ms (95%), errors: 0.00, reconnects:  0.00
[ 307s] threads: 64, tps: 1772.00, reads: 24763.03, writes: 6982.01, response time: 50.83ms (95%), errors: 0.00, reconnects:  0.00
[ 308s] threads: 64, tps: 1716.00, reads: 24080.98, writes: 6880.99, response time: 52.48ms (95%), errors: 0.00, reconnects:  0.00
[ 309s] threads: 64, tps: 1590.00, reads: 22166.98, writes: 6377.00, response time: 57.31ms (95%), errors: 0.00, reconnects:  0.00
[ 310s] threads: 64, tps: 1679.00, reads: 23470.04, writes: 6695.01, response time: 50.61ms (95%), errors: 0.00, reconnects:  0.00
[ 311s] threads: 64, tps: 1710.00, reads: 24142.00, writes: 6946.00, response time: 50.98ms (95%), errors: 0.00, reconnects:  0.00
[ 312s] threads: 64, tps: 1876.00, reads: 25998.01, writes: 7414.00, response time: 48.19ms (95%), errors: 0.00, reconnects:  0.00
[ 313s] threads: 64, tps: 1852.00, reads: 25999.01, writes: 7395.00, response time: 49.19ms (95%), errors: 0.00, reconnects:  0.00
[ 314s] threads: 64, tps: 2022.99, reads: 28461.85, writes: 8177.96, response time: 44.25ms (95%), errors: 0.00, reconnects:  0.00
[ 315s] threads: 64, tps: 1995.01, reads: 27832.11, writes: 7951.03, response time: 47.23ms (95%), errors: 0.00, reconnects:  0.00
[ 316s] threads: 64, tps: 1953.00, reads: 27391.03, writes: 7843.01, response time: 47.87ms (95%), errors: 0.00, reconnects:  0.00
[ 317s] threads: 64, tps: 1794.00, reads: 25137.02, writes: 7155.00, response time: 54.50ms (95%), errors: 0.00, reconnects:  0.00
[ 318s] threads: 64, tps: 1916.96, reads: 26701.50, writes: 7604.86, response time: 52.81ms (95%), errors: 0.00, reconnects:  0.00
[ 319s] threads: 64, tps: 2010.03, reads: 28200.45, writes: 8074.13, response time: 125.40ms (95%), errors: 0.00, reconnects:  0.00
[ 320s] threads: 64, tps: 1969.01, reads: 27619.07, writes: 7837.02, response time: 47.18ms (95%), errors: 0.00, reconnects:  0.00
[ 321s] threads: 64, tps: 1979.00, reads: 27612.99, writes: 7920.00, response time: 46.28ms (95%), errors: 0.00, reconnects:  0.00
[ 322s] threads: 64, tps: 2100.00, reads: 29427.00, writes: 8388.00, response time: 43.80ms (95%), errors: 0.00, reconnects:  0.00
[ 323s] threads: 64, tps: 2129.00, reads: 29909.00, writes: 8590.00, response time: 43.06ms (95%), errors: 0.00, reconnects:  0.00
[ 324s] threads: 64, tps: 2298.00, reads: 32068.99, writes: 9142.00, response time: 40.85ms (95%), errors: 0.00, reconnects:  0.00
[ 325s] threads: 64, tps: 2417.00, reads: 33823.98, writes: 9670.99, response time: 40.17ms (95%), errors: 0.00, reconnects:  0.00
[ 326s] threads: 64, tps: 2348.00, reads: 32973.99, writes: 9423.00, response time: 40.16ms (95%), errors: 0.00, reconnects:  0.00
[ 327s] threads: 64, tps: 2366.00, reads: 33053.01, writes: 9420.00, response time: 42.38ms (95%), errors: 0.00, reconnects:  0.00
[ 328s] threads: 64, tps: 2380.00, reads: 33353.96, writes: 9524.99, response time: 39.94ms (95%), errors: 0.00, reconnects:  0.00
[ 329s] threads: 64, tps: 2372.00, reads: 33366.01, writes: 9626.00, response time: 39.82ms (95%), errors: 0.00, reconnects:  0.00
[ 330s] threads: 64, tps: 2420.00, reads: 33776.07, writes: 9615.02, response time: 38.58ms (95%), errors: 0.00, reconnects:  0.00
[ 331s] threads: 64, tps: 2286.00, reads: 31902.99, writes: 9104.00, response time: 41.00ms (95%), errors: 0.00, reconnects:  0.00
[ 332s] threads: 64, tps: 2202.00, reads: 30900.96, writes: 8777.99, response time: 43.67ms (95%), errors: 0.00, reconnects:  0.00
[ 333s] threads: 64, tps: 2122.00, reads: 29645.98, writes: 8477.99, response time: 49.11ms (95%), errors: 0.00, reconnects:  0.00
[ 334s] threads: 64, tps: 2464.00, reads: 34511.05, writes: 9903.01, response time: 37.93ms (95%), errors: 0.00, reconnects:  0.00
[ 335s] threads: 64, tps: 2655.99, reads: 37225.86, writes: 10620.96, response time: 36.70ms (95%), errors: 0.00, reconnects:  0.00
[ 336s] threads: 64, tps: 2595.01, reads: 36390.15, writes: 10444.04, response time: 36.29ms (95%), errors: 0.00, reconnects:  0.00
[ 337s] threads: 64, tps: 2621.99, reads: 36724.80, writes: 10496.94, response time: 36.94ms (95%), errors: 0.00, reconnects:  0.00
[ 338s] threads: 64, tps: 2672.02, reads: 37342.22, writes: 10620.06, response time: 36.84ms (95%), errors: 0.00, reconnects:  0.00
[ 339s] threads: 64, tps: 2651.00, reads: 37015.97, writes: 10586.99, response time: 35.44ms (95%), errors: 0.00, reconnects:  0.00
[ 340s] threads: 64, tps: 2590.00, reads: 36403.99, writes: 10385.00, response time: 37.39ms (95%), errors: 0.00, reconnects:  0.00
[ 341s] threads: 64, tps: 2684.99, reads: 37424.85, writes: 10719.96, response time: 40.39ms (95%), errors: 0.00, reconnects:  0.00
[ 342s] threads: 64, tps: 2641.01, reads: 37014.15, writes: 10543.04, response time: 37.23ms (95%), errors: 0.00, reconnects:  0.00
[ 343s] threads: 64, tps: 2638.97, reads: 37023.56, writes: 10566.88, response time: 36.14ms (95%), errors: 0.00, reconnects:  0.00
[ 344s] threads: 64, tps: 2490.03, reads: 34845.45, writes: 9944.13, response time: 39.47ms (95%), errors: 0.00, reconnects:  0.00
[ 345s] threads: 64, tps: 2306.99, reads: 32324.83, writes: 9253.95, response time: 41.16ms (95%), errors: 0.00, reconnects:  0.00
[ 346s] threads: 64, tps: 2463.01, reads: 34425.12, writes: 9859.04, response time: 40.23ms (95%), errors: 0.00, reconnects:  0.00
[ 347s] threads: 64, tps: 2805.01, reads: 39253.10, writes: 11164.03, response time: 34.94ms (95%), errors: 0.00, reconnects:  0.00
[ 348s] threads: 64, tps: 2838.99, reads: 39776.86, writes: 11442.96, response time: 35.01ms (95%), errors: 0.00, reconnects:  0.00
[ 349s] threads: 64, tps: 2906.01, reads: 40734.08, writes: 11656.02, response time: 33.50ms (95%), errors: 0.00, reconnects:  0.00
[ 350s] threads: 64, tps: 2852.00, reads: 39983.98, writes: 11374.00, response time: 35.17ms (95%), errors: 0.00, reconnects:  0.00
[ 351s] threads: 64, tps: 2806.00, reads: 39320.03, writes: 11293.01, response time: 34.01ms (95%), errors: 0.00, reconnects:  0.00
[ 352s] threads: 64, tps: 2879.00, reads: 40228.99, writes: 11426.00, response time: 33.85ms (95%), errors: 0.00, reconnects:  0.00
[ 353s] threads: 64, tps: 2642.97, reads: 37002.63, writes: 10573.89, response time: 37.26ms (95%), errors: 0.00, reconnects:  0.00
[ 354s] threads: 64, tps: 2725.03, reads: 38028.38, writes: 10850.11, response time: 36.08ms (95%), errors: 0.00, reconnects:  0.00
[ 355s] threads: 64, tps: 2614.94, reads: 36634.18, writes: 10503.77, response time: 37.72ms (95%), errors: 0.00, reconnects:  0.00
[ 356s] threads: 64, tps: 2720.06, reads: 38164.84, writes: 10883.24, response time: 34.65ms (95%), errors: 0.00, reconnects:  0.00
[ 357s] threads: 64, tps: 2638.00, reads: 36943.02, writes: 10560.01, response time: 37.35ms (95%), errors: 0.00, reconnects:  0.00
[ 358s] threads: 64, tps: 2623.00, reads: 36698.98, writes: 10468.99, response time: 38.75ms (95%), errors: 0.00, reconnects:  0.00
[ 359s] threads: 64, tps: 2446.95, reads: 34195.32, writes: 9751.81, response time: 39.40ms (95%), errors: 0.00, reconnects:  0.00
[ 360s] threads: 64, tps: 2486.05, reads: 34863.64, writes: 9997.18, response time: 38.42ms (95%), errors: 0.00, reconnects:  0.00
[ 361s] threads: 64, tps: 2571.00, reads: 35788.00, writes: 10211.00, response time: 37.76ms (95%), errors: 0.00, reconnects:  0.00
[ 362s] threads: 64, tps: 2549.00, reads: 35900.07, writes: 10220.02, response time: 38.18ms (95%), errors: 0.00, reconnects:  0.00
[ 363s] threads: 64, tps: 2634.00, reads: 36859.00, writes: 10548.00, response time: 37.72ms (95%), errors: 0.00, reconnects:  0.00
[ 364s] threads: 64, tps: 2563.00, reads: 35888.02, writes: 10301.00, response time: 38.18ms (95%), errors: 0.00, reconnects:  0.00
[ 365s] threads: 64, tps: 2598.00, reads: 36278.95, writes: 10321.99, response time: 36.96ms (95%), errors: 0.00, reconnects:  0.00
[ 366s] threads: 64, tps: 2607.00, reads: 36548.03, writes: 10463.01, response time: 37.84ms (95%), errors: 0.00, reconnects:  0.00
[ 367s] threads: 64, tps: 2491.54, reads: 34944.49, writes: 10010.13, response time: 39.97ms (95%), errors: 0.00, reconnects:  0.00
[ 368s] threads: 64, tps: 2546.42, reads: 35627.94, writes: 10138.69, response time: 38.13ms (95%), errors: 0.00, reconnects:  0.00
[ 369s] threads: 64, tps: 2392.05, reads: 33594.67, writes: 9691.19, response time: 40.42ms (95%), errors: 0.00, reconnects:  0.00
[ 370s] threads: 64, tps: 2376.00, reads: 33148.94, writes: 9383.98, response time: 41.08ms (95%), errors: 0.00, reconnects:  0.00
[ 371s] threads: 64, tps: 2400.01, reads: 33561.08, writes: 9577.02, response time: 40.52ms (95%), errors: 0.00, reconnects:  0.00
[ 372s] threads: 64, tps: 2159.00, reads: 30348.99, writes: 8707.00, response time: 45.36ms (95%), errors: 0.00, reconnects:  0.00
[ 373s] threads: 64, tps: 2025.00, reads: 28249.97, writes: 8028.99, response time: 45.77ms (95%), errors: 0.00, reconnects:  0.00
[ 374s] threads: 64, tps: 2093.00, reads: 29200.01, writes: 8365.00, response time: 44.69ms (95%), errors: 0.00, reconnects:  0.00
[ 375s] threads: 64, tps: 2122.00, reads: 29898.02, writes: 8548.00, response time: 45.13ms (95%), errors: 0.00, reconnects:  0.00
[ 376s] threads: 64, tps: 2189.00, reads: 30621.99, writes: 8751.00, response time: 43.06ms (95%), errors: 0.00, reconnects:  0.00
[ 377s] threads: 64, tps: 2140.00, reads: 29914.00, writes: 8533.00, response time: 44.92ms (95%), errors: 0.00, reconnects:  0.00
[ 378s] threads: 64, tps: 2130.00, reads: 29777.02, writes: 8547.01, response time: 44.34ms (95%), errors: 0.00, reconnects:  0.00
[ 379s] threads: 64, tps: 1976.00, reads: 27721.99, writes: 7903.00, response time: 49.73ms (95%), errors: 0.00, reconnects:  0.00
[ 380s] threads: 64, tps: 1862.00, reads: 26036.97, writes: 7440.99, response time: 50.12ms (95%), errors: 0.00, reconnects:  0.00
[ 381s] threads: 64, tps: 1848.00, reads: 25936.98, writes: 7424.00, response time: 51.69ms (95%), errors: 0.00, reconnects:  0.00
[ 382s] threads: 64, tps: 1768.00, reads: 24659.05, writes: 7034.01, response time: 52.76ms (95%), errors: 0.00, reconnects:  0.00
[ 383s] threads: 64, tps: 1684.95, reads: 23553.25, writes: 6735.79, response time: 56.68ms (95%), errors: 0.00, reconnects:  0.00
[ 384s] threads: 64, tps: 1697.05, reads: 23813.73, writes: 6751.21, response time: 55.95ms (95%), errors: 0.00, reconnects:  0.00
[ 385s] threads: 64, tps: 1687.00, reads: 23721.98, writes: 6834.00, response time: 55.45ms (95%), errors: 0.00, reconnects:  0.00
[ 386s] threads: 64, tps: 1659.00, reads: 23034.03, writes: 6536.01, response time: 57.96ms (95%), errors: 0.00, reconnects:  0.00
[ 387s] threads: 64, tps: 1709.00, reads: 24037.00, writes: 6855.00, response time: 55.17ms (95%), errors: 0.00, reconnects:  0.00
[ 388s] threads: 64, tps: 1642.00, reads: 23117.02, writes: 6711.01, response time: 58.70ms (95%), errors: 0.00, reconnects:  0.00
[ 389s] threads: 64, tps: 1539.00, reads: 21449.97, writes: 6000.99, response time: 63.45ms (95%), errors: 0.00, reconnects:  0.00
[ 390s] threads: 64, tps: 1566.99, reads: 21878.93, writes: 6266.98, response time: 57.29ms (95%), errors: 0.00, reconnects:  0.00
[ 391s] threads: 64, tps: 1634.01, reads: 22955.11, writes: 6644.03, response time: 54.51ms (95%), errors: 0.00, reconnects:  0.00
[ 392s] threads: 64, tps: 1681.00, reads: 23572.03, writes: 6753.01, response time: 54.94ms (95%), errors: 0.00, reconnects:  0.00
[ 393s] threads: 64, tps: 1735.00, reads: 24193.97, writes: 6872.99, response time: 54.60ms (95%), errors: 0.00, reconnects:  0.00
[ 394s] threads: 64, tps: 1791.00, reads: 24993.97, writes: 7113.99, response time: 53.40ms (95%), errors: 0.00, reconnects:  0.00
[ 395s] threads: 64, tps: 1902.00, reads: 26696.03, writes: 7656.01, response time: 49.08ms (95%), errors: 0.00, reconnects:  0.00
[ 396s] threads: 64, tps: 1740.00, reads: 24389.98, writes: 6922.00, response time: 52.50ms (95%), errors: 0.00, reconnects:  0.00
[ 397s] threads: 64, tps: 1670.00, reads: 23328.00, writes: 6701.00, response time: 53.95ms (95%), errors: 0.00, reconnects:  0.00
[ 398s] threads: 64, tps: 1709.99, reads: 23945.92, writes: 6829.98, response time: 55.06ms (95%), errors: 0.00, reconnects:  0.00
[ 399s] threads: 64, tps: 1754.08, reads: 24494.19, writes: 7032.30, response time: 53.58ms (95%), errors: 0.00, reconnects:  0.00
[ 400s] threads: 64, tps: 1813.99, reads: 25345.85, writes: 7216.93, response time: 49.31ms (95%), errors: 0.00, reconnects:  0.00
[ 401s] threads: 64, tps: 1740.00, reads: 24424.93, writes: 6960.98, response time: 49.71ms (95%), errors: 0.00, reconnects:  0.00
[ 402s] threads: 64, tps: 1655.00, reads: 23269.05, writes: 6596.01, response time: 55.99ms (95%), errors: 0.00, reconnects:  0.00
[ 403s] threads: 64, tps: 1606.00, reads: 22547.00, writes: 6529.00, response time: 57.45ms (95%), errors: 0.00, reconnects:  0.00
[ 404s] threads: 64, tps: 1498.00, reads: 20819.99, writes: 5904.00, response time: 64.44ms (95%), errors: 0.00, reconnects:  0.00
[ 405s] threads: 64, tps: 1526.00, reads: 21385.00, writes: 6099.00, response time: 59.89ms (95%), errors: 0.00, reconnects:  0.00
[ 406s] threads: 64, tps: 1748.00, reads: 24379.01, writes: 6989.00, response time: 51.33ms (95%), errors: 0.00, reconnects:  0.00
[ 407s] threads: 64, tps: 1842.00, reads: 25987.99, writes: 7472.00, response time: 47.66ms (95%), errors: 0.00, reconnects:  0.00
[ 408s] threads: 64, tps: 1868.00, reads: 26025.97, writes: 7422.99, response time: 49.31ms (95%), errors: 0.00, reconnects:  0.00
[ 409s] threads: 64, tps: 1798.00, reads: 25182.06, writes: 7198.02, response time: 51.48ms (95%), errors: 0.00, reconnects:  0.00
[ 410s] threads: 64, tps: 1653.00, reads: 23109.00, writes: 6553.00, response time: 56.04ms (95%), errors: 0.00, reconnects:  0.00
[ 411s] threads: 64, tps: 1706.00, reads: 23944.98, writes: 6818.99, response time: 51.18ms (95%), errors: 0.00, reconnects:  0.00
[ 412s] threads: 64, tps: 1703.00, reads: 23799.99, writes: 6843.00, response time: 55.63ms (95%), errors: 0.00, reconnects:  0.00
[ 413s] threads: 64, tps: 1695.00, reads: 23875.04, writes: 6862.01, response time: 53.08ms (95%), errors: 0.00, reconnects:  0.00
[ 414s] threads: 64, tps: 1676.00, reads: 23304.98, writes: 6585.99, response time: 52.99ms (95%), errors: 0.00, reconnects:  0.00
[ 415s] threads: 64, tps: 1533.00, reads: 21465.01, writes: 6149.00, response time: 59.90ms (95%), errors: 0.00, reconnects:  0.00
[ 416s] threads: 64, tps: 1543.00, reads: 21673.00, writes: 6167.00, response time: 55.94ms (95%), errors: 0.00, reconnects:  0.00
[ 417s] threads: 64, tps: 1594.00, reads: 22259.97, writes: 6382.99, response time: 55.27ms (95%), errors: 0.00, reconnects:  0.00
[ 418s] threads: 64, tps: 1687.00, reads: 23647.01, writes: 6744.00, response time: 52.42ms (95%), errors: 0.00, reconnects:  0.00
[ 419s] threads: 64, tps: 1740.00, reads: 24331.00, writes: 6980.00, response time: 52.10ms (95%), errors: 0.00, reconnects:  0.00
[ 420s] threads: 64, tps: 1806.00, reads: 25297.05, writes: 7233.01, response time: 49.88ms (95%), errors: 0.00, reconnects:  0.00
[ 421s] threads: 64, tps: 1861.00, reads: 26124.96, writes: 7458.99, response time: 48.94ms (95%), errors: 0.00, reconnects:  0.00
[ 422s] threads: 64, tps: 1851.00, reads: 25717.00, writes: 7354.00, response time: 49.88ms (95%), errors: 0.00, reconnects:  0.00
[ 423s] threads: 64, tps: 1681.00, reads: 23673.02, writes: 6749.00, response time: 55.02ms (95%), errors: 0.00, reconnects:  0.00
[ 424s] threads: 64, tps: 1673.00, reads: 23311.96, writes: 6727.99, response time: 54.61ms (95%), errors: 0.00, reconnects:  0.00
[ 425s] threads: 64, tps: 1612.00, reads: 22600.03, writes: 6382.01, response time: 58.16ms (95%), errors: 0.00, reconnects:  0.00
[ 426s] threads: 64, tps: 1637.00, reads: 22982.00, writes: 6579.00, response time: 53.70ms (95%), errors: 0.00, reconnects:  0.00
[ 427s] threads: 64, tps: 1543.00, reads: 21607.99, writes: 6157.00, response time: 60.07ms (95%), errors: 0.00, reconnects:  0.00
[ 428s] threads: 64, tps: 1323.99, reads: 18576.91, writes: 5288.97, response time: 77.01ms (95%), errors: 0.00, reconnects:  0.00
[ 429s] threads: 64, tps: 1514.01, reads: 21146.10, writes: 6041.03, response time: 57.38ms (95%), errors: 0.00, reconnects:  0.00
[ 430s] threads: 64, tps: 1570.00, reads: 21918.98, writes: 6289.99, response time: 56.00ms (95%), errors: 0.00, reconnects:  0.00
[ 431s] threads: 64, tps: 1672.00, reads: 23448.05, writes: 6712.01, response time: 53.29ms (95%), errors: 0.00, reconnects:  0.00
[ 432s] threads: 64, tps: 1647.00, reads: 23116.96, writes: 6584.99, response time: 53.53ms (95%), errors: 0.00, reconnects:  0.00
[ 433s] threads: 64, tps: 1574.00, reads: 22133.94, writes: 6402.98, response time: 57.81ms (95%), errors: 0.00, reconnects:  0.00
[ 434s] threads: 64, tps: 1613.93, reads: 22391.03, writes: 6322.73, response time: 65.65ms (95%), errors: 0.00, reconnects:  0.00
[ 435s] threads: 64, tps: 1753.08, reads: 24738.16, writes: 7103.33, response time: 56.51ms (95%), errors: 0.00, reconnects:  0.00
[ 436s] threads: 64, tps: 1717.00, reads: 23957.01, writes: 6821.00, response time: 51.90ms (95%), errors: 0.00, reconnects:  0.00
[ 437s] threads: 64, tps: 1656.00, reads: 23097.99, writes: 6585.00, response time: 53.75ms (95%), errors: 0.00, reconnects:  0.00
[ 438s] threads: 64, tps: 1673.00, reads: 23629.02, writes: 6831.01, response time: 54.17ms (95%), errors: 0.00, reconnects:  0.00
[ 439s] threads: 64, tps: 1617.00, reads: 22450.99, writes: 6330.00, response time: 57.91ms (95%), errors: 0.00, reconnects:  0.00
[ 440s] threads: 64, tps: 1561.00, reads: 21915.98, writes: 6318.99, response time: 58.52ms (95%), errors: 0.00, reconnects:  0.00
[ 441s] threads: 64, tps: 1665.00, reads: 23283.00, writes: 6574.00, response time: 52.89ms (95%), errors: 0.00, reconnects:  0.00
[ 442s] threads: 64, tps: 1551.00, reads: 21735.03, writes: 6215.01, response time: 60.10ms (95%), errors: 0.00, reconnects:  0.00
[ 443s] threads: 64, tps: 1514.00, reads: 21169.01, writes: 6053.00, response time: 57.77ms (95%), errors: 0.00, reconnects:  0.00
[ 444s] threads: 64, tps: 1538.00, reads: 21565.98, writes: 6211.99, response time: 57.43ms (95%), errors: 0.00, reconnects:  0.00
[ 445s] threads: 64, tps: 1623.00, reads: 22749.98, writes: 6529.99, response time: 54.53ms (95%), errors: 0.00, reconnects:  0.00
[ 446s] threads: 64, tps: 1767.00, reads: 24636.03, writes: 6981.01, response time: 50.67ms (95%), errors: 0.00, reconnects:  0.00
[ 447s] threads: 64, tps: 1698.00, reads: 23832.98, writes: 6843.00, response time: 52.99ms (95%), errors: 0.00, reconnects:  0.00
[ 448s] threads: 64, tps: 1720.87, reads: 24131.11, writes: 6906.46, response time: 54.08ms (95%), errors: 0.00, reconnects:  0.00
[ 449s] threads: 64, tps: 1796.14, reads: 25119.92, writes: 7178.55, response time: 50.24ms (95%), errors: 0.00, reconnects:  0.00
[ 450s] threads: 64, tps: 1602.00, reads: 22385.02, writes: 6350.00, response time: 60.48ms (95%), errors: 0.00, reconnects:  0.00
[ 451s] threads: 64, tps: 1619.00, reads: 22735.04, writes: 6510.01, response time: 57.12ms (95%), errors: 0.00, reconnects:  0.00
[ 452s] threads: 64, tps: 1910.00, reads: 26716.99, writes: 7636.00, response time: 48.15ms (95%), errors: 0.00, reconnects:  0.00
[ 453s] threads: 64, tps: 1837.00, reads: 25755.99, writes: 7345.00, response time: 49.11ms (95%), errors: 0.00, reconnects:  0.00
[ 454s] threads: 64, tps: 1867.00, reads: 26134.99, writes: 7466.00, response time: 47.59ms (95%), errors: 0.00, reconnects:  0.00
[ 455s] threads: 64, tps: 1671.00, reads: 23305.03, writes: 6634.01, response time: 53.19ms (95%), errors: 0.00, reconnects:  0.00
[ 456s] threads: 64, tps: 1721.00, reads: 24119.95, writes: 6905.98, response time: 52.12ms (95%), errors: 0.00, reconnects:  0.00
[ 457s] threads: 64, tps: 1752.00, reads: 24489.02, writes: 7001.01, response time: 51.65ms (95%), errors: 0.00, reconnects:  0.00
[ 458s] threads: 64, tps: 1842.99, reads: 25796.89, writes: 7409.97, response time: 50.46ms (95%), errors: 0.00, reconnects:  0.00
[ 459s] threads: 64, tps: 1959.01, reads: 27407.13, writes: 7788.04, response time: 45.78ms (95%), errors: 0.00, reconnects:  0.00
[ 460s] threads: 64, tps: 1954.00, reads: 27543.00, writes: 7937.00, response time: 46.63ms (95%), errors: 0.00, reconnects:  0.00
[ 461s] threads: 64, tps: 1980.00, reads: 27541.01, writes: 7853.00, response time: 46.61ms (95%), errors: 0.00, reconnects:  0.00
[ 462s] threads: 64, tps: 2096.00, reads: 29403.99, writes: 8379.00, response time: 44.37ms (95%), errors: 0.00, reconnects:  0.00
[ 463s] threads: 64, tps: 1840.97, reads: 25901.62, writes: 7427.89, response time: 49.39ms (95%), errors: 0.00, reconnects:  0.00
[ 464s] threads: 64, tps: 1980.99, reads: 27679.79, writes: 7861.94, response time: 46.64ms (95%), errors: 0.00, reconnects:  0.00
[ 465s] threads: 64, tps: 2010.04, reads: 28194.57, writes: 8103.17, response time: 47.10ms (95%), errors: 0.00, reconnects:  0.00
[ 466s] threads: 64, tps: 1974.00, reads: 27443.04, writes: 7775.01, response time: 46.50ms (95%), errors: 0.00, reconnects:  0.00
[ 467s] threads: 64, tps: 1936.00, reads: 27130.98, writes: 7738.99, response time: 46.66ms (95%), errors: 0.00, reconnects:  0.00
[ 468s] threads: 64, tps: 1803.00, reads: 25335.99, writes: 7255.00, response time: 52.95ms (95%), errors: 0.00, reconnects:  0.00
[ 469s] threads: 64, tps: 1801.00, reads: 25114.05, writes: 7163.01, response time: 51.28ms (95%), errors: 0.00, reconnects:  0.00
[ 470s] threads: 64, tps: 1812.00, reads: 25431.99, writes: 7289.00, response time: 49.52ms (95%), errors: 0.00, reconnects:  0.00
[ 471s] threads: 64, tps: 1963.00, reads: 27468.99, writes: 7860.00, response time: 46.41ms (95%), errors: 0.00, reconnects:  0.00
[ 472s] threads: 64, tps: 2086.00, reads: 29270.98, writes: 8365.99, response time: 43.51ms (95%), errors: 0.00, reconnects:  0.00
[ 473s] threads: 64, tps: 2044.00, reads: 28635.06, writes: 8196.02, response time: 43.70ms (95%), errors: 0.00, reconnects:  0.00
[ 474s] threads: 64, tps: 2142.00, reads: 29953.95, writes: 8515.99, response time: 43.18ms (95%), errors: 0.00, reconnects:  0.00
[ 475s] threads: 64, tps: 2239.00, reads: 31324.03, writes: 9004.01, response time: 41.01ms (95%), errors: 0.00, reconnects:  0.00
[ 476s] threads: 64, tps: 2099.00, reads: 29365.00, writes: 8328.00, response time: 44.27ms (95%), errors: 0.00, reconnects:  0.00
[ 477s] threads: 64, tps: 2125.00, reads: 29809.97, writes: 8588.99, response time: 44.14ms (95%), errors: 0.00, reconnects:  0.00
[ 478s] threads: 64, tps: 2167.00, reads: 30321.02, writes: 8659.01, response time: 42.75ms (95%), errors: 0.00, reconnects:  0.00
[ 479s] threads: 64, tps: 2153.00, reads: 29983.02, writes: 8555.01, response time: 44.05ms (95%), errors: 0.00, reconnects:  0.00
[ 480s] threads: 64, tps: 1995.00, reads: 28062.99, writes: 8004.00, response time: 51.22ms (95%), errors: 0.00, reconnects:  0.00
[ 481s] threads: 64, tps: 2065.00, reads: 28965.99, writes: 8283.00, response time: 50.15ms (95%), errors: 0.00, reconnects:  0.00
[ 482s] threads: 64, tps: 2130.00, reads: 29739.00, writes: 8444.00, response time: 43.91ms (95%), errors: 0.00, reconnects:  0.00
[ 483s] threads: 64, tps: 2140.00, reads: 29900.00, writes: 8557.00, response time: 41.78ms (95%), errors: 0.00, reconnects:  0.00
[ 484s] threads: 64, tps: 2195.00, reads: 30780.01, writes: 8779.00, response time: 42.64ms (95%), errors: 0.00, reconnects:  0.00
[ 485s] threads: 64, tps: 2015.00, reads: 28241.97, writes: 8064.99, response time: 46.09ms (95%), errors: 0.00, reconnects:  0.00
[ 486s] threads: 64, tps: 2050.00, reads: 28711.99, writes: 8231.00, response time: 46.66ms (95%), errors: 0.00, reconnects:  0.00
[ 487s] threads: 64, tps: 2146.00, reads: 29994.02, writes: 8633.01, response time: 44.02ms (95%), errors: 0.00, reconnects:  0.00
[ 488s] threads: 64, tps: 2334.00, reads: 32581.01, writes: 9249.00, response time: 40.61ms (95%), errors: 0.00, reconnects:  0.00
[ 489s] threads: 64, tps: 2338.00, reads: 32859.00, writes: 9406.00, response time: 40.41ms (95%), errors: 0.00, reconnects:  0.00
[ 490s] threads: 64, tps: 2228.00, reads: 31027.98, writes: 8857.99, response time: 42.41ms (95%), errors: 0.00, reconnects:  0.00
[ 491s] threads: 64, tps: 2187.00, reads: 30821.03, writes: 8834.01, response time: 42.94ms (95%), errors: 0.00, reconnects:  0.00
[ 492s] threads: 64, tps: 2247.00, reads: 31443.03, writes: 8990.01, response time: 41.25ms (95%), errors: 0.00, reconnects:  0.00
[ 493s] threads: 64, tps: 2274.00, reads: 31769.01, writes: 9088.00, response time: 42.33ms (95%), errors: 0.00, reconnects:  0.00
[ 494s] threads: 64, tps: 2216.00, reads: 31025.00, writes: 8815.00, response time: 42.53ms (95%), errors: 0.00, reconnects:  0.00
[ 495s] threads: 64, tps: 2241.84, reads: 31432.77, writes: 8965.36, response time: 40.06ms (95%), errors: 0.00, reconnects:  0.00
[ 496s] threads: 64, tps: 2071.14, reads: 28963.02, writes: 8274.58, response time: 45.31ms (95%), errors: 0.00, reconnects:  0.00
[ 497s] threads: 64, tps: 2023.00, reads: 28362.00, writes: 8094.00, response time: 46.27ms (95%), errors: 0.00, reconnects:  0.00
[ 498s] threads: 64, tps: 2187.00, reads: 30689.00, writes: 8804.00, response time: 42.07ms (95%), errors: 0.00, reconnects:  0.00
[ 499s] threads: 64, tps: 2253.00, reads: 31444.96, writes: 8939.99, response time: 41.88ms (95%), errors: 0.00, reconnects:  0.00
[ 500s] threads: 64, tps: 2388.99, reads: 33527.91, writes: 9617.98, response time: 39.14ms (95%), errors: 0.00, reconnects:  0.00
[ 501s] threads: 64, tps: 2392.00, reads: 33420.97, writes: 9571.99, response time: 38.87ms (95%), errors: 0.00, reconnects:  0.00
[ 502s] threads: 64, tps: 2359.00, reads: 33024.01, writes: 9397.00, response time: 40.13ms (95%), errors: 0.00, reconnects:  0.00
[ 503s] threads: 64, tps: 2421.97, reads: 33895.59, writes: 9712.88, response time: 39.14ms (95%), errors: 0.00, reconnects:  0.00
[ 504s] threads: 64, tps: 2364.03, reads: 33050.42, writes: 9418.12, response time: 41.05ms (95%), errors: 0.00, reconnects:  0.00
[ 505s] threads: 64, tps: 2335.01, reads: 32744.13, writes: 9366.04, response time: 39.88ms (95%), errors: 0.00, reconnects:  0.00
[ 506s] threads: 64, tps: 2406.00, reads: 33645.01, writes: 9636.00, response time: 39.20ms (95%), errors: 0.00, reconnects:  0.00
[ 507s] threads: 64, tps: 2326.00, reads: 32668.00, writes: 9339.00, response time: 40.72ms (95%), errors: 0.00, reconnects:  0.00
[ 508s] threads: 64, tps: 2412.00, reads: 33828.02, writes: 9681.01, response time: 39.23ms (95%), errors: 0.00, reconnects:  0.00
[ 509s] threads: 64, tps: 2324.00, reads: 32331.98, writes: 9197.99, response time: 40.92ms (95%), errors: 0.00, reconnects:  0.00
[ 510s] threads: 64, tps: 2209.00, reads: 30942.95, writes: 8845.98, response time: 45.42ms (95%), errors: 0.00, reconnects:  0.00
[ 511s] threads: 64, tps: 2085.00, reads: 29212.07, writes: 8308.02, response time: 46.49ms (95%), errors: 0.00, reconnects:  0.00
[ 512s] threads: 64, tps: 2117.00, reads: 29630.99, writes: 8480.00, response time: 43.43ms (95%), errors: 0.00, reconnects:  0.00
[ 513s] threads: 64, tps: 2181.99, reads: 30661.93, writes: 8809.98, response time: 42.41ms (95%), errors: 0.00, reconnects:  0.00
[ 514s] threads: 64, tps: 2201.00, reads: 30799.05, writes: 8771.01, response time: 42.12ms (95%), errors: 0.00, reconnects:  0.00
[ 515s] threads: 64, tps: 2223.00, reads: 30987.01, writes: 8853.00, response time: 42.83ms (95%), errors: 0.00, reconnects:  0.00
[ 516s] threads: 64, tps: 2197.00, reads: 30904.02, writes: 8825.01, response time: 42.08ms (95%), errors: 0.00, reconnects:  0.00
[ 517s] threads: 64, tps: 2059.00, reads: 28733.98, writes: 8242.99, response time: 45.54ms (95%), errors: 0.00, reconnects:  0.00
[ 518s] threads: 64, tps: 2147.00, reads: 29985.01, writes: 8545.00, response time: 45.28ms (95%), errors: 0.00, reconnects:  0.00
[ 519s] threads: 64, tps: 2311.00, reads: 32363.95, writes: 9264.99, response time: 41.80ms (95%), errors: 0.00, reconnects:  0.00
[ 520s] threads: 64, tps: 2062.00, reads: 28882.05, writes: 8214.01, response time: 45.91ms (95%), errors: 0.00, reconnects:  0.00
[ 521s] threads: 64, tps: 2120.00, reads: 29716.00, writes: 8492.00, response time: 43.96ms (95%), errors: 0.00, reconnects:  0.00
[ 522s] threads: 64, tps: 1990.00, reads: 27950.02, writes: 8048.01, response time: 46.57ms (95%), errors: 0.00, reconnects:  0.00
[ 523s] threads: 64, tps: 1995.00, reads: 27916.95, writes: 7930.99, response time: 47.02ms (95%), errors: 0.00, reconnects:  0.00
[ 524s] threads: 64, tps: 2024.00, reads: 28307.98, writes: 8082.00, response time: 49.56ms (95%), errors: 0.00, reconnects:  0.00
[ 525s] threads: 64, tps: 2022.00, reads: 28167.01, writes: 8031.00, response time: 47.72ms (95%), errors: 0.00, reconnects:  0.00
[ 526s] threads: 64, tps: 2016.00, reads: 28366.99, writes: 8085.00, response time: 47.56ms (95%), errors: 0.00, reconnects:  0.00
[ 527s] threads: 64, tps: 1840.00, reads: 25749.01, writes: 7370.00, response time: 50.63ms (95%), errors: 0.00, reconnects:  0.00
[ 528s] threads: 64, tps: 1774.00, reads: 24822.99, writes: 7068.00, response time: 53.02ms (95%), errors: 0.00, reconnects:  0.00
[ 529s] threads: 64, tps: 1849.99, reads: 25905.88, writes: 7454.97, response time: 51.07ms (95%), errors: 0.00, reconnects:  0.00
[ 530s] threads: 64, tps: 2026.01, reads: 28305.15, writes: 8075.04, response time: 44.79ms (95%), errors: 0.00, reconnects:  0.00
[ 531s] threads: 64, tps: 2018.00, reads: 28283.02, writes: 8089.01, response time: 43.98ms (95%), errors: 0.00, reconnects:  0.00
[ 532s] threads: 64, tps: 2022.00, reads: 28256.00, writes: 8052.00, response time: 45.61ms (95%), errors: 0.00, reconnects:  0.00
[ 533s] threads: 64, tps: 1992.00, reads: 27973.97, writes: 8021.99, response time: 44.82ms (95%), errors: 0.00, reconnects:  0.00
[ 534s] threads: 64, tps: 1896.00, reads: 26455.99, writes: 7574.00, response time: 51.01ms (95%), errors: 0.00, reconnects:  0.00
[ 535s] threads: 64, tps: 1881.00, reads: 26416.03, writes: 7501.01, response time: 48.25ms (95%), errors: 0.00, reconnects:  0.00
[ 536s] threads: 64, tps: 1950.00, reads: 27272.00, writes: 7818.00, response time: 46.67ms (95%), errors: 0.00, reconnects:  0.00
[ 537s] threads: 64, tps: 1755.00, reads: 24528.97, writes: 6997.99, response time: 54.66ms (95%), errors: 0.00, reconnects:  0.00
[ 538s] threads: 64, tps: 1825.00, reads: 25583.04, writes: 7365.01, response time: 50.64ms (95%), errors: 0.00, reconnects:  0.00
[ 539s] threads: 64, tps: 1885.00, reads: 26342.95, writes: 7491.99, response time: 48.09ms (95%), errors: 0.00, reconnects:  0.00
[ 540s] threads: 64, tps: 1726.00, reads: 24302.93, writes: 6956.98, response time: 52.37ms (95%), errors: 0.00, reconnects:  0.00
[ 541s] threads: 64, tps: 1764.01, reads: 24581.09, writes: 6982.03, response time: 50.83ms (95%), errors: 0.00, reconnects:  0.00
[ 542s] threads: 64, tps: 1518.00, reads: 21326.02, writes: 6144.00, response time: 65.12ms (95%), errors: 0.00, reconnects:  0.00
[ 543s] threads: 64, tps: 1750.00, reads: 24441.95, writes: 6918.98, response time: 53.40ms (95%), errors: 0.00, reconnects:  0.00
[ 544s] threads: 64, tps: 1797.00, reads: 25309.04, writes: 7326.01, response time: 49.91ms (95%), errors: 0.00, reconnects:  0.00
[ 545s] threads: 64, tps: 1704.00, reads: 23677.02, writes: 6710.01, response time: 54.12ms (95%), errors: 0.00, reconnects:  0.00
[ 546s] threads: 64, tps: 1876.00, reads: 26309.98, writes: 7502.00, response time: 50.27ms (95%), errors: 0.00, reconnects:  0.00
[ 547s] threads: 64, tps: 1795.00, reads: 25181.98, writes: 7197.99, response time: 51.01ms (95%), errors: 0.00, reconnects:  0.00
[ 548s] threads: 64, tps: 1901.00, reads: 26530.04, writes: 7569.01, response time: 48.78ms (95%), errors: 0.00, reconnects:  0.00
[ 549s] threads: 64, tps: 1965.00, reads: 27453.97, writes: 7845.99, response time: 46.25ms (95%), errors: 0.00, reconnects:  0.00
[ 550s] threads: 64, tps: 1942.00, reads: 27198.03, writes: 7745.01, response time: 47.08ms (95%), errors: 0.00, reconnects:  0.00
[ 551s] threads: 64, tps: 1743.00, reads: 24583.98, writes: 7087.99, response time: 51.78ms (95%), errors: 0.00, reconnects:  0.00
[ 552s] threads: 64, tps: 1815.00, reads: 25271.98, writes: 7216.99, response time: 51.15ms (95%), errors: 0.00, reconnects:  0.00
[ 553s] threads: 64, tps: 1907.00, reads: 26694.02, writes: 7600.01, response time: 48.46ms (95%), errors: 0.00, reconnects:  0.00
[ 554s] threads: 64, tps: 1798.00, reads: 25163.01, writes: 7185.00, response time: 49.88ms (95%), errors: 0.00, reconnects:  0.00
[ 555s] threads: 64, tps: 1791.00, reads: 25126.99, writes: 7152.00, response time: 49.03ms (95%), errors: 0.00, reconnects:  0.00
[ 556s] threads: 64, tps: 1569.00, reads: 22055.99, writes: 6320.00, response time: 58.38ms (95%), errors: 0.00, reconnects:  0.00
[ 557s] threads: 64, tps: 1552.00, reads: 21657.03, writes: 6170.01, response time: 57.26ms (95%), errors: 0.00, reconnects:  0.00
[ 558s] threads: 64, tps: 1608.99, reads: 22398.85, writes: 6437.96, response time: 55.09ms (95%), errors: 0.00, reconnects:  0.00
[ 559s] threads: 64, tps: 1690.01, reads: 23780.13, writes: 6771.04, response time: 55.85ms (95%), errors: 0.00, reconnects:  0.00
[ 560s] threads: 64, tps: 1797.99, reads: 25121.90, writes: 7178.97, response time: 49.58ms (95%), errors: 0.00, reconnects:  0.00
[ 561s] threads: 64, tps: 1853.00, reads: 25993.98, writes: 7435.99, response time: 49.02ms (95%), errors: 0.00, reconnects:  0.00
[ 562s] threads: 64, tps: 1851.01, reads: 25852.14, writes: 7414.04, response time: 47.86ms (95%), errors: 0.00, reconnects:  0.00
[ 563s] threads: 64, tps: 1864.99, reads: 26228.89, writes: 7502.97, response time: 46.77ms (95%), errors: 0.00, reconnects:  0.00
[ 564s] threads: 64, tps: 1895.01, reads: 26590.12, writes: 7589.03, response time: 48.20ms (95%), errors: 0.00, reconnects:  0.00
[ 565s] threads: 64, tps: 1772.00, reads: 24670.98, writes: 7037.99, response time: 50.81ms (95%), errors: 0.00, reconnects:  0.00
[ 566s] threads: 64, tps: 1585.99, reads: 22191.89, writes: 6351.97, response time: 60.07ms (95%), errors: 0.00, reconnects:  0.00
[ 567s] threads: 64, tps: 1836.01, reads: 25702.15, writes: 7321.04, response time: 50.95ms (95%), errors: 0.00, reconnects:  0.00
[ 568s] threads: 64, tps: 1804.99, reads: 25312.87, writes: 7239.96, response time: 50.92ms (95%), errors: 0.00, reconnects:  0.00
[ 569s] threads: 64, tps: 1806.00, reads: 25263.03, writes: 7236.01, response time: 49.53ms (95%), errors: 0.00, reconnects:  0.00
[ 570s] threads: 64, tps: 1698.01, reads: 23829.08, writes: 6723.02, response time: 54.06ms (95%), errors: 0.00, reconnects:  0.00
[ 571s] threads: 64, tps: 1624.99, reads: 22707.91, writes: 6502.97, response time: 56.52ms (95%), errors: 0.00, reconnects:  0.00
[ 572s] threads: 64, tps: 1641.01, reads: 22968.08, writes: 6570.02, response time: 53.43ms (95%), errors: 0.00, reconnects:  0.00
[ 573s] threads: 64, tps: 1663.00, reads: 23249.03, writes: 6659.01, response time: 53.51ms (95%), errors: 0.00, reconnects:  0.00
[ 574s] threads: 64, tps: 1789.00, reads: 25013.00, writes: 7136.00, response time: 49.79ms (95%), errors: 0.00, reconnects:  0.00
[ 575s] threads: 64, tps: 1802.99, reads: 25303.86, writes: 7270.96, response time: 50.86ms (95%), errors: 0.00, reconnects:  0.00
[ 576s] threads: 64, tps: 1842.01, reads: 25807.12, writes: 7372.03, response time: 50.07ms (95%), errors: 0.00, reconnects:  0.00
[ 577s] threads: 64, tps: 1840.00, reads: 25752.01, writes: 7370.00, response time: 49.14ms (95%), errors: 0.00, reconnects:  0.00
[ 578s] threads: 64, tps: 1834.00, reads: 25572.01, writes: 7312.00, response time: 49.55ms (95%), errors: 0.00, reconnects:  0.00
[ 579s] threads: 64, tps: 1845.00, reads: 25894.96, writes: 7347.99, response time: 50.48ms (95%), errors: 0.00, reconnects:  0.00
[ 580s] threads: 64, tps: 1750.00, reads: 24517.00, writes: 7012.00, response time: 51.70ms (95%), errors: 0.00, reconnects:  0.00
[ 581s] threads: 64, tps: 1804.99, reads: 25348.91, writes: 7261.97, response time: 49.02ms (95%), errors: 0.00, reconnects:  0.00
[ 582s] threads: 64, tps: 1696.01, reads: 23642.08, writes: 6743.02, response time: 56.37ms (95%), errors: 0.00, reconnects:  0.00
[ 583s] threads: 64, tps: 1507.00, reads: 21115.01, writes: 6013.00, response time: 60.68ms (95%), errors: 0.00, reconnects:  0.00
[ 584s] threads: 64, tps: 1422.00, reads: 19990.99, writes: 5750.00, response time: 67.20ms (95%), errors: 0.00, reconnects:  0.00
[ 585s] threads: 64, tps: 1372.00, reads: 19090.03, writes: 5491.01, response time: 69.62ms (95%), errors: 0.00, reconnects:  0.00
[ 586s] threads: 64, tps: 1555.00, reads: 21887.01, writes: 6167.00, response time: 56.32ms (95%), errors: 0.00, reconnects:  0.00
[ 587s] threads: 64, tps: 1552.00, reads: 21669.96, writes: 6240.99, response time: 56.68ms (95%), errors: 0.00, reconnects:  0.00
[ 588s] threads: 64, tps: 1581.00, reads: 22073.05, writes: 6327.01, response time: 61.50ms (95%), errors: 0.00, reconnects:  0.00
[ 589s] threads: 64, tps: 1652.99, reads: 23186.89, writes: 6560.97, response time: 57.96ms (95%), errors: 0.00, reconnects:  0.00
[ 590s] threads: 64, tps: 1777.93, reads: 24873.09, writes: 7155.74, response time: 54.55ms (95%), errors: 0.00, reconnects:  0.00
[ 591s] threads: 64, tps: 1643.07, reads: 22973.91, writes: 6534.26, response time: 54.64ms (95%), errors: 0.00, reconnects:  0.00
[ 592s] threads: 64, tps: 1709.00, reads: 24026.02, writes: 6920.01, response time: 54.40ms (95%), errors: 0.00, reconnects:  0.00
[ 593s] threads: 64, tps: 1859.00, reads: 25905.98, writes: 7327.99, response time: 49.91ms (95%), errors: 0.00, reconnects:  0.00
[ 594s] threads: 64, tps: 1778.00, reads: 24973.97, writes: 7153.99, response time: 53.53ms (95%), errors: 0.00, reconnects:  0.00
[ 595s] threads: 64, tps: 1742.00, reads: 24268.01, writes: 6957.00, response time: 53.11ms (95%), errors: 0.00, reconnects:  0.00
[ 596s] threads: 64, tps: 1753.00, reads: 24558.04, writes: 7041.01, response time: 51.86ms (95%), errors: 0.00, reconnects:  0.00
[ 597s] threads: 64, tps: 1645.00, reads: 23114.00, writes: 6547.00, response time: 56.02ms (95%), errors: 0.00, reconnects:  0.00
[ 598s] threads: 64, tps: 1731.99, reads: 24226.93, writes: 6900.98, response time: 54.42ms (95%), errors: 0.00, reconnects:  0.00
[ 599s] threads: 64, tps: 1684.00, reads: 23589.05, writes: 6761.02, response time: 54.40ms (95%), errors: 0.00, reconnects:  0.00
[ 600s] threads: 64, tps: 1673.00, reads: 23417.01, writes: 6697.00, response time: 52.23ms (95%), errors: 0.00, reconnects:  0.00
[ 601s] threads: 64, tps: 1742.00, reads: 24334.97, writes: 6944.99, response time: 52.23ms (95%), errors: 0.00, reconnects:  0.00
[ 602s] threads: 64, tps: 1753.00, reads: 24728.02, writes: 7086.01, response time: 50.34ms (95%), errors: 0.00, reconnects:  0.00
[ 603s] threads: 64, tps: 1941.00, reads: 27111.98, writes: 7781.00, response time: 46.42ms (95%), errors: 0.00, reconnects:  0.00
[ 604s] threads: 64, tps: 1896.00, reads: 26542.02, writes: 7524.01, response time: 48.33ms (95%), errors: 0.00, reconnects:  0.00
[ 605s] threads: 64, tps: 1966.00, reads: 27622.98, writes: 7983.00, response time: 44.05ms (95%), errors: 0.00, reconnects:  0.00
[ 606s] threads: 64, tps: 2028.00, reads: 28271.00, writes: 8030.00, response time: 46.47ms (95%), errors: 0.00, reconnects:  0.00
[ 607s] threads: 64, tps: 2057.00, reads: 28797.05, writes: 8190.01, response time: 45.50ms (95%), errors: 0.00, reconnects:  0.00
[ 608s] threads: 64, tps: 2020.00, reads: 28377.96, writes: 8141.99, response time: 44.25ms (95%), errors: 0.00, reconnects:  0.00
[ 609s] threads: 64, tps: 1999.99, reads: 27730.89, writes: 7906.97, response time: 46.38ms (95%), errors: 0.00, reconnects:  0.00
[ 610s] threads: 64, tps: 2031.00, reads: 28642.06, writes: 8171.02, response time: 46.63ms (95%), errors: 0.00, reconnects:  0.00
[ 611s] threads: 64, tps: 2042.01, reads: 28522.08, writes: 8133.02, response time: 44.38ms (95%), errors: 0.00, reconnects:  0.00
[ 612s] threads: 64, tps: 1942.99, reads: 27199.87, writes: 7798.96, response time: 45.91ms (95%), errors: 0.00, reconnects:  0.00
[ 613s] threads: 64, tps: 1744.01, reads: 24506.08, writes: 7042.02, response time: 53.40ms (95%), errors: 0.00, reconnects:  0.00
[ 614s] threads: 64, tps: 1742.00, reads: 24322.01, writes: 6863.00, response time: 52.34ms (95%), errors: 0.00, reconnects:  0.00
[ 615s] threads: 64, tps: 1745.00, reads: 24454.00, writes: 6980.00, response time: 52.17ms (95%), errors: 0.00, reconnects:  0.00
[ 616s] threads: 64, tps: 1882.96, reads: 26346.47, writes: 7555.85, response time: 47.29ms (95%), errors: 0.00, reconnects:  0.00
[ 617s] threads: 64, tps: 1998.04, reads: 27963.60, writes: 8016.17, response time: 46.16ms (95%), errors: 0.00, reconnects:  0.00
[ 618s] threads: 64, tps: 2110.00, reads: 29593.01, writes: 8460.00, response time: 43.19ms (95%), errors: 0.00, reconnects:  0.00
[ 619s] threads: 64, tps: 2090.00, reads: 29183.00, writes: 8328.00, response time: 44.10ms (95%), errors: 0.00, reconnects:  0.00
[ 620s] threads: 64, tps: 2186.00, reads: 30547.98, writes: 8708.99, response time: 42.79ms (95%), errors: 0.00, reconnects:  0.00
[ 621s] threads: 64, tps: 2236.00, reads: 31376.02, writes: 9027.01, response time: 42.02ms (95%), errors: 0.00, reconnects:  0.00
[ 622s] threads: 64, tps: 2237.00, reads: 31431.95, writes: 8953.99, response time: 40.69ms (95%), errors: 0.00, reconnects:  0.00
[ 623s] threads: 64, tps: 2166.00, reads: 30220.03, writes: 8635.01, response time: 45.44ms (95%), errors: 0.00, reconnects:  0.00
[ 624s] threads: 64, tps: 2084.00, reads: 29221.00, writes: 8349.00, response time: 44.71ms (95%), errors: 0.00, reconnects:  0.00
[ 625s] threads: 64, tps: 2069.00, reads: 29032.99, writes: 8347.00, response time: 46.56ms (95%), errors: 0.00, reconnects:  0.00
[ 626s] threads: 64, tps: 2054.00, reads: 28556.97, writes: 8121.99, response time: 46.81ms (95%), errors: 0.00, reconnects:  0.00
[ 627s] threads: 64, tps: 2078.00, reads: 29131.01, writes: 8260.00, response time: 45.02ms (95%), errors: 0.00, reconnects:  0.00
[ 628s] threads: 64, tps: 2109.97, reads: 29588.53, writes: 8493.87, response time: 43.19ms (95%), errors: 0.00, reconnects:  0.00
[ 629s] threads: 64, tps: 1947.03, reads: 27215.46, writes: 7748.13, response time: 48.55ms (95%), errors: 0.00, reconnects:  0.00
[ 630s] threads: 64, tps: 2079.00, reads: 29124.00, writes: 8302.00, response time: 44.51ms (95%), errors: 0.00, reconnects:  0.00
[ 631s] threads: 64, tps: 2194.00, reads: 30726.99, writes: 8798.00, response time: 41.23ms (95%), errors: 0.00, reconnects:  0.00
[ 632s] threads: 64, tps: 2280.00, reads: 31993.96, writes: 9231.99, response time: 40.90ms (95%), errors: 0.00, reconnects:  0.00
[ 633s] threads: 64, tps: 2398.99, reads: 33554.93, writes: 9533.98, response time: 39.41ms (95%), errors: 0.00, reconnects:  0.00
[ 634s] threads: 64, tps: 2394.77, reads: 33645.76, writes: 9664.07, response time: 38.81ms (95%), errors: 0.00, reconnects:  0.00
[ 635s] threads: 64, tps: 2429.24, reads: 33858.35, writes: 9632.95, response time: 39.40ms (95%), errors: 0.00, reconnects:  0.00
[ 636s] threads: 64, tps: 2471.00, reads: 34480.01, writes: 9849.00, response time: 38.81ms (95%), errors: 0.00, reconnects:  0.00
[ 637s] threads: 64, tps: 2382.00, reads: 33490.02, writes: 9576.01, response time: 39.56ms (95%), errors: 0.00, reconnects:  0.00
[ 638s] threads: 64, tps: 2457.99, reads: 34336.86, writes: 9783.96, response time: 37.80ms (95%), errors: 0.00, reconnects:  0.00
[ 639s] threads: 64, tps: 2349.01, reads: 32763.10, writes: 9356.03, response time: 40.10ms (95%), errors: 0.00, reconnects:  0.00
[ 640s] threads: 64, tps: 2389.00, reads: 33660.02, writes: 9647.00, response time: 38.75ms (95%), errors: 0.00, reconnects:  0.00
[ 641s] threads: 64, tps: 2476.00, reads: 34535.00, writes: 9891.00, response time: 38.87ms (95%), errors: 0.00, reconnects:  0.00
[ 642s] threads: 64, tps: 2435.00, reads: 34278.00, writes: 9778.00, response time: 38.74ms (95%), errors: 0.00, reconnects:  0.00
[ 643s] threads: 64, tps: 2330.00, reads: 32499.00, writes: 9251.00, response time: 40.19ms (95%), errors: 0.00, reconnects:  0.00
[ 644s] threads: 64, tps: 2165.00, reads: 30295.01, writes: 8624.00, response time: 44.47ms (95%), errors: 0.00, reconnects:  0.00
[ 645s] threads: 64, tps: 1915.00, reads: 26938.00, writes: 7741.00, response time: 47.93ms (95%), errors: 0.00, reconnects:  0.00
[ 646s] threads: 64, tps: 2095.00, reads: 29175.96, writes: 8306.99, response time: 44.57ms (95%), errors: 0.00, reconnects:  0.00
[ 647s] threads: 64, tps: 2125.00, reads: 29799.05, writes: 8545.01, response time: 43.07ms (95%), errors: 0.00, reconnects:  0.00
[ 648s] threads: 64, tps: 2259.00, reads: 31622.00, writes: 9010.00, response time: 40.69ms (95%), errors: 0.00, reconnects:  0.00
[ 649s] threads: 64, tps: 2311.00, reads: 32448.97, writes: 9296.99, response time: 39.89ms (95%), errors: 0.00, reconnects:  0.00
[ 650s] threads: 64, tps: 2384.00, reads: 33390.96, writes: 9561.99, response time: 38.53ms (95%), errors: 0.00, reconnects:  0.00
[ 651s] threads: 64, tps: 2405.00, reads: 33469.01, writes: 9534.00, response time: 39.00ms (95%), errors: 0.00, reconnects:  0.00
[ 652s] threads: 64, tps: 2474.00, reads: 34608.04, writes: 9927.01, response time: 37.79ms (95%), errors: 0.00, reconnects:  0.00
[ 653s] threads: 64, tps: 2471.00, reads: 34685.02, writes: 9854.01, response time: 38.54ms (95%), errors: 0.00, reconnects:  0.00
[ 654s] threads: 64, tps: 2386.99, reads: 33494.82, writes: 9591.95, response time: 39.97ms (95%), errors: 0.00, reconnects:  0.00
[ 655s] threads: 64, tps: 2275.01, reads: 31779.10, writes: 9070.03, response time: 42.12ms (95%), errors: 0.00, reconnects:  0.00
[ 656s] threads: 64, tps: 2289.00, reads: 32058.06, writes: 9128.02, response time: 42.56ms (95%), errors: 0.00, reconnects:  0.00
[ 657s] threads: 64, tps: 2368.00, reads: 33274.96, writes: 9558.99, response time: 40.75ms (95%), errors: 0.00, reconnects:  0.00
[ 658s] threads: 64, tps: 2381.00, reads: 33184.04, writes: 9464.01, response time: 44.77ms (95%), errors: 0.00, reconnects:  0.00
[ 659s] threads: 64, tps: 2503.99, reads: 35075.93, writes: 10020.98, response time: 38.81ms (95%), errors: 0.00, reconnects:  0.00
[ 660s] threads: 64, tps: 2165.00, reads: 30365.04, writes: 8650.01, response time: 45.94ms (95%), errors: 0.00, reconnects:  0.00
[ 661s] threads: 64, tps: 2142.00, reads: 29925.97, writes: 8532.99, response time: 46.05ms (95%), errors: 0.00, reconnects:  0.00
[ 662s] threads: 64, tps: 2137.00, reads: 29879.03, writes: 8571.01, response time: 45.13ms (95%), errors: 0.00, reconnects:  0.00
[ 663s] threads: 64, tps: 2090.00, reads: 29316.04, writes: 8349.01, response time: 43.42ms (95%), errors: 0.00, reconnects:  0.00
[ 664s] threads: 64, tps: 2189.00, reads: 30738.95, writes: 8828.99, response time: 42.17ms (95%), errors: 0.00, reconnects:  0.00
[ 665s] threads: 64, tps: 2186.00, reads: 30567.02, writes: 8732.01, response time: 43.32ms (95%), errors: 0.00, reconnects:  0.00
[ 666s] threads: 64, tps: 2097.00, reads: 29290.00, writes: 8377.00, response time: 46.71ms (95%), errors: 0.00, reconnects:  0.00
[ 667s] threads: 64, tps: 2134.00, reads: 29804.97, writes: 8479.99, response time: 44.75ms (95%), errors: 0.00, reconnects:  0.00
[ 668s] threads: 64, tps: 2050.00, reads: 28852.03, writes: 8299.01, response time: 44.50ms (95%), errors: 0.00, reconnects:  0.00
[ 669s] threads: 64, tps: 2073.00, reads: 29090.97, writes: 8321.99, response time: 44.97ms (95%), errors: 0.00, reconnects:  0.00
[ 670s] threads: 64, tps: 2148.99, reads: 30030.86, writes: 8518.96, response time: 43.01ms (95%), errors: 0.00, reconnects:  0.00
[ 671s] threads: 64, tps: 2086.01, reads: 29141.12, writes: 8332.04, response time: 45.63ms (95%), errors: 0.00, reconnects:  0.00
[ 672s] threads: 64, tps: 1802.00, reads: 25160.01, writes: 7164.00, response time: 53.83ms (95%), errors: 0.00, reconnects:  0.00
[ 673s] threads: 64, tps: 1941.00, reads: 27185.00, writes: 7809.00, response time: 47.83ms (95%), errors: 0.00, reconnects:  0.00
[ 674s] threads: 64, tps: 1856.00, reads: 26034.00, writes: 7403.00, response time: 51.39ms (95%), errors: 0.00, reconnects:  0.00
[ 675s] threads: 64, tps: 2065.00, reads: 28968.02, writes: 8270.01, response time: 47.72ms (95%), errors: 0.00, reconnects:  0.00
[ 676s] threads: 64, tps: 1980.00, reads: 27640.99, writes: 7931.00, response time: 46.64ms (95%), errors: 0.00, reconnects:  0.00
[ 677s] threads: 64, tps: 1937.00, reads: 27136.04, writes: 7775.01, response time: 46.64ms (95%), errors: 0.00, reconnects:  0.00
[ 678s] threads: 64, tps: 1742.99, reads: 24375.85, writes: 6896.96, response time: 54.08ms (95%), errors: 0.00, reconnects:  0.00
[ 679s] threads: 64, tps: 1750.01, reads: 24517.12, writes: 7006.03, response time: 53.38ms (95%), errors: 0.00, reconnects:  0.00
[ 680s] threads: 64, tps: 1774.00, reads: 24812.02, writes: 7086.01, response time: 51.10ms (95%), errors: 0.00, reconnects:  0.00
[ 681s] threads: 64, tps: 1810.00, reads: 25318.98, writes: 7251.00, response time: 49.08ms (95%), errors: 0.00, reconnects:  0.00
[ 682s] threads: 64, tps: 1803.00, reads: 25170.01, writes: 7227.00, response time: 52.51ms (95%), errors: 0.00, reconnects:  0.00
[ 683s] threads: 64, tps: 1909.00, reads: 26817.00, writes: 7660.00, response time: 47.15ms (95%), errors: 0.00, reconnects:  0.00
[ 684s] threads: 64, tps: 1892.00, reads: 26539.00, writes: 7592.00, response time: 54.50ms (95%), errors: 0.00, reconnects:  0.00
[ 685s] threads: 64, tps: 1947.00, reads: 27143.02, writes: 7766.00, response time: 49.53ms (95%), errors: 0.00, reconnects:  0.00
[ 686s] threads: 64, tps: 1817.00, reads: 25673.03, writes: 7354.01, response time: 49.67ms (95%), errors: 0.00, reconnects:  0.00
[ 687s] threads: 64, tps: 1990.00, reads: 27691.99, writes: 7861.00, response time: 46.60ms (95%), errors: 0.00, reconnects:  0.00
[ 688s] threads: 64, tps: 1952.00, reads: 27317.94, writes: 7819.98, response time: 48.26ms (95%), errors: 0.00, reconnects:  0.00
[ 689s] threads: 64, tps: 1867.00, reads: 26107.03, writes: 7452.01, response time: 49.94ms (95%), errors: 0.00, reconnects:  0.00
[ 690s] threads: 64, tps: 1835.00, reads: 25777.98, writes: 7301.99, response time: 54.25ms (95%), errors: 0.00, reconnects:  0.00
[ 691s] threads: 64, tps: 1639.00, reads: 22907.02, writes: 6600.00, response time: 66.02ms (95%), errors: 0.00, reconnects:  0.00
[ 692s] threads: 64, tps: 1717.00, reads: 24075.00, writes: 6857.00, response time: 62.28ms (95%), errors: 0.00, reconnects:  0.00
[ 693s] threads: 64, tps: 1685.00, reads: 23518.00, writes: 6714.00, response time: 55.87ms (95%), errors: 0.00, reconnects:  0.00
[ 694s] threads: 64, tps: 1593.00, reads: 22355.01, writes: 6369.00, response time: 57.46ms (95%), errors: 0.00, reconnects:  0.00
[ 695s] threads: 64, tps: 1611.00, reads: 22504.00, writes: 6439.00, response time: 54.71ms (95%), errors: 0.00, reconnects:  0.00
[ 696s] threads: 64, tps: 1505.00, reads: 21221.01, writes: 6097.00, response time: 58.09ms (95%), errors: 0.00, reconnects:  0.00
[ 697s] threads: 64, tps: 1663.00, reads: 23244.02, writes: 6637.01, response time: 52.80ms (95%), errors: 0.00, reconnects:  0.00
[ 698s] threads: 64, tps: 1572.97, reads: 21912.63, writes: 6244.89, response time: 60.50ms (95%), errors: 0.00, reconnects:  0.00
[ 699s] threads: 64, tps: 1733.03, reads: 24302.40, writes: 7011.11, response time: 53.98ms (95%), errors: 0.00, reconnects:  0.00
[ 700s] threads: 64, tps: 1737.00, reads: 24364.99, writes: 6961.00, response time: 51.22ms (95%), errors: 0.00, reconnects:  0.00
[ 701s] threads: 64, tps: 1725.00, reads: 24123.97, writes: 6861.99, response time: 55.62ms (95%), errors: 0.00, reconnects:  0.00
[ 702s] threads: 64, tps: 1823.00, reads: 25556.98, writes: 7229.99, response time: 49.31ms (95%), errors: 0.00, reconnects:  0.00
[ 703s] threads: 64, tps: 1818.00, reads: 25427.99, writes: 7370.00, response time: 51.32ms (95%), errors: 0.00, reconnects:  0.00
[ 704s] threads: 64, tps: 1777.00, reads: 24825.00, writes: 7000.00, response time: 52.18ms (95%), errors: 0.00, reconnects:  0.00
[ 705s] threads: 64, tps: 1565.00, reads: 21963.95, writes: 6354.99, response time: 60.77ms (95%), errors: 0.00, reconnects:  0.00
[ 706s] threads: 64, tps: 1745.01, reads: 24448.09, writes: 6922.03, response time: 53.19ms (95%), errors: 0.00, reconnects:  0.00
[ 707s] threads: 64, tps: 1683.00, reads: 23518.03, writes: 6782.01, response time: 53.30ms (95%), errors: 0.00, reconnects:  0.00
[ 708s] threads: 64, tps: 1694.99, reads: 23697.82, writes: 6705.95, response time: 52.86ms (95%), errors: 0.00, reconnects:  0.00
[ 709s] threads: 64, tps: 1624.01, reads: 22817.16, writes: 6545.05, response time: 56.49ms (95%), errors: 0.00, reconnects:  0.00
[ 710s] threads: 64, tps: 1421.00, reads: 19809.03, writes: 5623.01, response time: 72.32ms (95%), errors: 0.00, reconnects:  0.00
[ 711s] threads: 64, tps: 1414.00, reads: 19794.98, writes: 5690.00, response time: 66.18ms (95%), errors: 0.00, reconnects:  0.00
[ 712s] threads: 64, tps: 1275.00, reads: 17924.00, writes: 5101.00, response time: 75.64ms (95%), errors: 0.00, reconnects:  0.00
[ 713s] threads: 64, tps: 1234.99, reads: 17216.92, writes: 4915.98, response time: 77.33ms (95%), errors: 0.00, reconnects:  0.00
[ 714s] threads: 64, tps: 1467.01, reads: 20494.12, writes: 5883.03, response time: 62.45ms (95%), errors: 0.00, reconnects:  0.00
[ 715s] threads: 64, tps: 1491.00, reads: 20951.96, writes: 6009.99, response time: 60.97ms (95%), errors: 0.00, reconnects:  0.00
[ 716s] threads: 64, tps: 1634.00, reads: 22981.97, writes: 6582.99, response time: 55.87ms (95%), errors: 0.00, reconnects:  0.00
[ 717s] threads: 64, tps: 1697.99, reads: 23628.91, writes: 6731.97, response time: 53.83ms (95%), errors: 0.00, reconnects:  0.00
[ 718s] threads: 64, tps: 1709.01, reads: 24007.11, writes: 6879.03, response time: 52.28ms (95%), errors: 0.00, reconnects:  0.00
[ 719s] threads: 64, tps: 1817.99, reads: 25463.92, writes: 7276.98, response time: 49.82ms (95%), errors: 0.00, reconnects:  0.00
[ 720s] threads: 64, tps: 1836.01, reads: 25737.12, writes: 7367.03, response time: 52.46ms (95%), errors: 0.00, reconnects:  0.00
[ 721s] threads: 64, tps: 1806.00, reads: 25261.98, writes: 7168.99, response time: 49.85ms (95%), errors: 0.00, reconnects:  0.00
[ 722s] threads: 64, tps: 1784.99, reads: 25042.88, writes: 7157.97, response time: 50.58ms (95%), errors: 0.00, reconnects:  0.00
[ 723s] threads: 64, tps: 1802.01, reads: 25158.15, writes: 7213.04, response time: 50.58ms (95%), errors: 0.00, reconnects:  0.00
[ 724s] threads: 64, tps: 1751.99, reads: 24439.80, writes: 6974.94, response time: 50.70ms (95%), errors: 0.00, reconnects:  0.00
[ 725s] threads: 64, tps: 1690.01, reads: 23651.17, writes: 6705.05, response time: 52.15ms (95%), errors: 0.00, reconnects:  0.00
[ 726s] threads: 64, tps: 1589.00, reads: 22419.02, writes: 6470.01, response time: 58.09ms (95%), errors: 0.00, reconnects:  0.00
[ 727s] threads: 64, tps: 1609.00, reads: 22367.98, writes: 6330.00, response time: 55.09ms (95%), errors: 0.00, reconnects:  0.00
[ 728s] threads: 64, tps: 1520.99, reads: 21399.90, writes: 6104.97, response time: 58.57ms (95%), errors: 0.00, reconnects:  0.00
[ 729s] threads: 64, tps: 1474.01, reads: 20560.09, writes: 5875.03, response time: 59.69ms (95%), errors: 0.00, reconnects:  0.00
[ 730s] threads: 64, tps: 1458.00, reads: 20365.99, writes: 5825.00, response time: 61.48ms (95%), errors: 0.00, reconnects:  0.00
[ 731s] threads: 64, tps: 1637.98, reads: 22957.68, writes: 6571.91, response time: 57.03ms (95%), errors: 0.00, reconnects:  0.00
[ 732s] threads: 64, tps: 1737.02, reads: 24335.33, writes: 6961.09, response time: 52.14ms (95%), errors: 0.00, reconnects:  0.00
[ 733s] threads: 64, tps: 1812.00, reads: 25376.00, writes: 7314.00, response time: 49.65ms (95%), errors: 0.00, reconnects:  0.00
[ 734s] threads: 64, tps: 1808.00, reads: 25433.02, writes: 7279.00, response time: 50.86ms (95%), errors: 0.00, reconnects:  0.00
[ 735s] threads: 64, tps: 1898.00, reads: 26429.01, writes: 7450.00, response time: 48.10ms (95%), errors: 0.00, reconnects:  0.00
[ 736s] threads: 64, tps: 1809.00, reads: 25310.02, writes: 7280.01, response time: 49.89ms (95%), errors: 0.00, reconnects:  0.00
[ 737s] threads: 64, tps: 1923.00, reads: 26884.94, writes: 7639.98, response time: 47.15ms (95%), errors: 0.00, reconnects:  0.00
[ 738s] threads: 64, tps: 1711.00, reads: 24055.05, writes: 6891.01, response time: 51.87ms (95%), errors: 0.00, reconnects:  0.00
[ 739s] threads: 64, tps: 1786.00, reads: 24934.99, writes: 7101.00, response time: 51.56ms (95%), errors: 0.00, reconnects:  0.00
[ 740s] threads: 64, tps: 1726.00, reads: 24148.98, writes: 6906.00, response time: 54.94ms (95%), errors: 0.00, reconnects:  0.00
[ 741s] threads: 64, tps: 1744.00, reads: 24551.99, writes: 7033.00, response time: 51.38ms (95%), errors: 0.00, reconnects:  0.00
[ 742s] threads: 64, tps: 1699.00, reads: 23700.04, writes: 6806.01, response time: 52.18ms (95%), errors: 0.00, reconnects:  0.00
[ 743s] threads: 64, tps: 1657.00, reads: 23247.98, writes: 6561.99, response time: 55.29ms (95%), errors: 0.00, reconnects:  0.00
[ 744s] threads: 64, tps: 1689.00, reads: 23574.00, writes: 6754.00, response time: 51.62ms (95%), errors: 0.00, reconnects:  0.00
[ 745s] threads: 64, tps: 1668.00, reads: 23369.02, writes: 6666.01, response time: 54.40ms (95%), errors: 0.00, reconnects:  0.00
[ 746s] threads: 64, tps: 1674.00, reads: 23413.99, writes: 6740.00, response time: 54.40ms (95%), errors: 0.00, reconnects:  0.00
[ 747s] threads: 64, tps: 1709.00, reads: 23843.01, writes: 6798.00, response time: 52.37ms (95%), errors: 0.00, reconnects:  0.00
[ 748s] threads: 64, tps: 1839.00, reads: 25926.98, writes: 7459.99, response time: 49.12ms (95%), errors: 0.00, reconnects:  0.00
[ 749s] threads: 64, tps: 1926.00, reads: 26795.97, writes: 7631.99, response time: 48.41ms (95%), errors: 0.00, reconnects:  0.00
[ 750s] threads: 64, tps: 1911.00, reads: 26904.04, writes: 7702.01, response time: 47.93ms (95%), errors: 0.00, reconnects:  0.00
[ 751s] threads: 64, tps: 1930.00, reads: 27107.03, writes: 7751.01, response time: 47.40ms (95%), errors: 0.00, reconnects:  0.00
[ 752s] threads: 64, tps: 2005.00, reads: 28038.95, writes: 8009.98, response time: 44.97ms (95%), errors: 0.00, reconnects:  0.00
[ 753s] threads: 64, tps: 1972.00, reads: 27471.04, writes: 7866.01, response time: 45.74ms (95%), errors: 0.00, reconnects:  0.00
[ 754s] threads: 64, tps: 1847.00, reads: 25924.96, writes: 7349.99, response time: 49.89ms (95%), errors: 0.00, reconnects:  0.00
[ 755s] threads: 64, tps: 1925.00, reads: 26937.01, writes: 7727.00, response time: 48.71ms (95%), errors: 0.00, reconnects:  0.00
[ 756s] threads: 64, tps: 1929.00, reads: 26883.02, writes: 7723.00, response time: 46.50ms (95%), errors: 0.00, reconnects:  0.00
[ 757s] threads: 64, tps: 1867.00, reads: 26156.01, writes: 7394.00, response time: 47.64ms (95%), errors: 0.00, reconnects:  0.00
[ 758s] threads: 64, tps: 1827.00, reads: 25739.00, writes: 7352.00, response time: 49.80ms (95%), errors: 0.00, reconnects:  0.00
[ 759s] threads: 64, tps: 1732.00, reads: 24258.97, writes: 6958.99, response time: 52.37ms (95%), errors: 0.00, reconnects:  0.00
[ 760s] threads: 64, tps: 1618.00, reads: 22590.03, writes: 6394.01, response time: 55.37ms (95%), errors: 0.00, reconnects:  0.00
[ 761s] threads: 64, tps: 1683.00, reads: 23468.98, writes: 6722.99, response time: 52.94ms (95%), errors: 0.00, reconnects:  0.00
[ 762s] threads: 64, tps: 1669.98, reads: 23457.71, writes: 6702.92, response time: 51.30ms (95%), errors: 0.00, reconnects:  0.00
[ 763s] threads: 64, tps: 1800.02, reads: 25176.34, writes: 7210.10, response time: 49.73ms (95%), errors: 0.00, reconnects:  0.00
[ 764s] threads: 64, tps: 1847.00, reads: 25845.99, writes: 7414.00, response time: 48.48ms (95%), errors: 0.00, reconnects:  0.00
[ 765s] threads: 64, tps: 1925.95, reads: 26978.25, writes: 7687.79, response time: 48.26ms (95%), errors: 0.00, reconnects:  0.00
[ 766s] threads: 64, tps: 1954.05, reads: 27294.76, writes: 7808.22, response time: 46.05ms (95%), errors: 0.00, reconnects:  0.00
[ 767s] threads: 64, tps: 1981.00, reads: 27843.00, writes: 7969.00, response time: 45.12ms (95%), errors: 0.00, reconnects:  0.00
[ 768s] threads: 64, tps: 1957.00, reads: 27483.03, writes: 7861.01, response time: 47.27ms (95%), errors: 0.00, reconnects:  0.00
[ 769s] threads: 64, tps: 1901.00, reads: 26552.98, writes: 7561.00, response time: 46.64ms (95%), errors: 0.00, reconnects:  0.00
[ 770s] threads: 64, tps: 1823.00, reads: 25351.98, writes: 7240.99, response time: 48.89ms (95%), errors: 0.00, reconnects:  0.00
[ 771s] threads: 64, tps: 1848.00, reads: 26066.03, writes: 7482.01, response time: 47.84ms (95%), errors: 0.00, reconnects:  0.00
[ 772s] threads: 64, tps: 1829.00, reads: 25559.98, writes: 7254.00, response time: 50.66ms (95%), errors: 0.00, reconnects:  0.00
[ 773s] threads: 64, tps: 1879.00, reads: 26171.98, writes: 7530.99, response time: 47.62ms (95%), errors: 0.00, reconnects:  0.00
[ 774s] threads: 64, tps: 1773.00, reads: 24876.00, writes: 7046.00, response time: 51.61ms (95%), errors: 0.00, reconnects:  0.00
[ 775s] threads: 64, tps: 1757.00, reads: 24651.02, writes: 7007.01, response time: 50.15ms (95%), errors: 0.00, reconnects:  0.00
[ 776s] threads: 64, tps: 1602.00, reads: 22434.99, writes: 6417.00, response time: 55.20ms (95%), errors: 0.00, reconnects:  0.00
[ 777s] threads: 64, tps: 1693.00, reads: 23598.02, writes: 6768.01, response time: 52.34ms (95%), errors: 0.00, reconnects:  0.00
[ 778s] threads: 64, tps: 1672.00, reads: 23486.00, writes: 6728.00, response time: 51.81ms (95%), errors: 0.00, reconnects:  0.00
[ 779s] threads: 64, tps: 1742.00, reads: 24382.98, writes: 6937.99, response time: 50.51ms (95%), errors: 0.00, reconnects:  0.00
[ 780s] threads: 64, tps: 1829.00, reads: 25540.97, writes: 7367.99, response time: 48.41ms (95%), errors: 0.00, reconnects:  0.00
[ 781s] threads: 64, tps: 1922.00, reads: 27072.02, writes: 7700.00, response time: 47.87ms (95%), errors: 0.00, reconnects:  0.00
[ 782s] threads: 64, tps: 2021.00, reads: 28142.04, writes: 8074.01, response time: 45.36ms (95%), errors: 0.00, reconnects:  0.00
[ 783s] threads: 64, tps: 1989.00, reads: 27973.00, writes: 7985.00, response time: 45.29ms (95%), errors: 0.00, reconnects:  0.00
[ 784s] threads: 64, tps: 2032.00, reads: 28359.96, writes: 8073.99, response time: 44.41ms (95%), errors: 0.00, reconnects:  0.00
[ 785s] threads: 64, tps: 1975.00, reads: 27702.02, writes: 7939.01, response time: 47.26ms (95%), errors: 0.00, reconnects:  0.00
[ 786s] threads: 64, tps: 2030.00, reads: 28530.97, writes: 8180.99, response time: 44.16ms (95%), errors: 0.00, reconnects:  0.00
[ 787s] threads: 64, tps: 1923.00, reads: 26845.98, writes: 7620.00, response time: 48.10ms (95%), errors: 0.00, reconnects:  0.00
[ 788s] threads: 64, tps: 1949.99, reads: 27187.92, writes: 7743.98, response time: 46.81ms (95%), errors: 0.00, reconnects:  0.00
[ 789s] threads: 64, tps: 1960.01, reads: 27426.13, writes: 7850.04, response time: 47.05ms (95%), errors: 0.00, reconnects:  0.00
[ 790s] threads: 64, tps: 1888.00, reads: 26546.98, writes: 7588.00, response time: 48.59ms (95%), errors: 0.00, reconnects:  0.00
[ 791s] threads: 64, tps: 1824.99, reads: 25481.89, writes: 7253.97, response time: 49.65ms (95%), errors: 0.00, reconnects:  0.00
[ 792s] threads: 64, tps: 1714.01, reads: 24039.09, writes: 6859.03, response time: 51.65ms (95%), errors: 0.00, reconnects:  0.00
[ 793s] threads: 64, tps: 1705.00, reads: 23807.02, writes: 6799.01, response time: 52.73ms (95%), errors: 0.00, reconnects:  0.00
[ 794s] threads: 64, tps: 1745.00, reads: 24454.01, writes: 6985.00, response time: 50.60ms (95%), errors: 0.00, reconnects:  0.00
[ 795s] threads: 64, tps: 1688.00, reads: 23712.98, writes: 6847.99, response time: 53.93ms (95%), errors: 0.00, reconnects:  0.00
[ 796s] threads: 64, tps: 1877.99, reads: 26200.88, writes: 7428.97, response time: 48.59ms (95%), errors: 0.00, reconnects:  0.00
[ 797s] threads: 64, tps: 1978.01, reads: 27783.16, writes: 7937.05, response time: 46.45ms (95%), errors: 0.00, reconnects:  0.00
[ 798s] threads: 64, tps: 1971.00, reads: 27551.95, writes: 7899.98, response time: 45.48ms (95%), errors: 0.00, reconnects:  0.00
[ 799s] threads: 64, tps: 2003.00, reads: 28027.06, writes: 8052.02, response time: 45.08ms (95%), errors: 0.00, reconnects:  0.00
[ 800s] threads: 64, tps: 1968.99, reads: 27570.87, writes: 7880.96, response time: 46.16ms (95%), errors: 0.00, reconnects:  0.00
[ 801s] threads: 64, tps: 1962.01, reads: 27328.11, writes: 7808.03, response time: 46.14ms (95%), errors: 0.00, reconnects:  0.00
[ 802s] threads: 64, tps: 2005.00, reads: 28073.97, writes: 7989.99, response time: 45.16ms (95%), errors: 0.00, reconnects:  0.00
[ 803s] threads: 64, tps: 1949.00, reads: 27406.00, writes: 7852.00, response time: 46.20ms (95%), errors: 0.00, reconnects:  0.00
[ 804s] threads: 64, tps: 1869.00, reads: 26209.04, writes: 7407.01, response time: 48.70ms (95%), errors: 0.00, reconnects:  0.00
[ 805s] threads: 64, tps: 1793.99, reads: 25204.88, writes: 7267.97, response time: 53.46ms (95%), errors: 0.00, reconnects:  0.00
[ 806s] threads: 64, tps: 1713.01, reads: 23982.09, writes: 6842.03, response time: 56.37ms (95%), errors: 0.00, reconnects:  0.00
[ 807s] threads: 64, tps: 1826.00, reads: 25448.99, writes: 7261.00, response time: 50.01ms (95%), errors: 0.00, reconnects:  0.00
[ 808s] threads: 64, tps: 1675.00, reads: 23541.00, writes: 6737.00, response time: 57.43ms (95%), errors: 0.00, reconnects:  0.00
[ 809s] threads: 64, tps: 1540.00, reads: 21512.02, writes: 6073.01, response time: 64.56ms (95%), errors: 0.00, reconnects:  0.00
[ 810s] threads: 64, tps: 1538.00, reads: 21492.98, writes: 6166.99, response time: 61.06ms (95%), errors: 0.00, reconnects:  0.00
[ 811s] threads: 64, tps: 1543.99, reads: 21620.92, writes: 6154.98, response time: 59.05ms (95%), errors: 0.00, reconnects:  0.00
[ 812s] threads: 64, tps: 1983.01, reads: 27747.12, writes: 7939.03, response time: 47.36ms (95%), errors: 0.00, reconnects:  0.00
[ 813s] threads: 64, tps: 2145.00, reads: 30125.98, writes: 8650.00, response time: 44.39ms (95%), errors: 0.00, reconnects:  0.00
[ 814s] threads: 64, tps: 2305.00, reads: 32157.03, writes: 9197.01, response time: 41.38ms (95%), errors: 0.00, reconnects:  0.00
[ 815s] threads: 64, tps: 2306.00, reads: 32243.96, writes: 9254.99, response time: 41.48ms (95%), errors: 0.00, reconnects:  0.00
[ 816s] threads: 64, tps: 2477.48, reads: 34784.72, writes: 9942.92, response time: 39.68ms (95%), errors: 0.00, reconnects:  0.00
[ 817s] threads: 64, tps: 2699.55, reads: 37753.74, writes: 10702.19, response time: 38.48ms (95%), errors: 0.00, reconnects:  0.00
[ 818s] threads: 64, tps: 2656.00, reads: 37199.04, writes: 10665.01, response time: 37.05ms (95%), errors: 0.00, reconnects:  0.00
[ 819s] threads: 64, tps: 2540.01, reads: 35520.14, writes: 10162.04, response time: 40.69ms (95%), errors: 0.00, reconnects:  0.00
[ 820s] threads: 64, tps: 2341.00, reads: 32808.02, writes: 9369.01, response time: 47.64ms (95%), errors: 0.00, reconnects:  0.00
[ 821s] threads: 64, tps: 2483.84, reads: 34719.83, writes: 9899.38, response time: 45.21ms (95%), errors: 0.00, reconnects:  0.00
[ 822s] threads: 64, tps: 2387.14, reads: 33529.97, writes: 9597.56, response time: 49.36ms (95%), errors: 0.00, reconnects:  0.00
[ 823s] threads: 64, tps: 2458.01, reads: 34366.15, writes: 9816.04, response time: 39.70ms (95%), errors: 0.00, reconnects:  0.00
[ 824s] threads: 64, tps: 2452.00, reads: 34288.01, writes: 9839.00, response time: 41.30ms (95%), errors: 0.00, reconnects:  0.00
[ 825s] threads: 64, tps: 2370.00, reads: 33209.96, writes: 9502.99, response time: 41.40ms (95%), errors: 0.00, reconnects:  0.00
[ 826s] threads: 64, tps: 2278.00, reads: 31794.00, writes: 9011.00, response time: 41.14ms (95%), errors: 0.00, reconnects:  0.00
[ 827s] threads: 64, tps: 2180.00, reads: 30596.99, writes: 8725.00, response time: 42.04ms (95%), errors: 0.00, reconnects:  0.00
[ 828s] threads: 64, tps: 1879.00, reads: 26305.01, writes: 7531.00, response time: 51.42ms (95%), errors: 0.00, reconnects:  0.00
[ 829s] threads: 64, tps: 1986.99, reads: 27824.91, writes: 7966.97, response time: 47.90ms (95%), errors: 0.00, reconnects:  0.00
[ 830s] threads: 64, tps: 2148.00, reads: 29896.06, writes: 8573.02, response time: 44.53ms (95%), errors: 0.00, reconnects:  0.00
[ 831s] threads: 64, tps: 2192.99, reads: 31021.87, writes: 8853.96, response time: 41.93ms (95%), errors: 0.00, reconnects:  0.00
[ 832s] threads: 64, tps: 2318.01, reads: 32227.18, writes: 9195.05, response time: 40.61ms (95%), errors: 0.00, reconnects:  0.00
[ 833s] threads: 64, tps: 2261.00, reads: 31771.97, writes: 9088.99, response time: 43.20ms (95%), errors: 0.00, reconnects:  0.00
[ 834s] threads: 64, tps: 2228.00, reads: 31178.02, writes: 8887.01, response time: 44.54ms (95%), errors: 0.00, reconnects:  0.00
[ 835s] threads: 64, tps: 2272.00, reads: 31800.02, writes: 9047.00, response time: 42.71ms (95%), errors: 0.00, reconnects:  0.00
[ 836s] threads: 64, tps: 2192.00, reads: 30428.96, writes: 8735.99, response time: 46.16ms (95%), errors: 0.00, reconnects:  0.00
[ 837s] threads: 64, tps: 2202.00, reads: 31071.02, writes: 8854.01, response time: 42.61ms (95%), errors: 0.00, reconnects:  0.00
[ 838s] threads: 64, tps: 2189.99, reads: 30505.91, writes: 8745.98, response time: 42.82ms (95%), errors: 0.00, reconnects:  0.00
[ 839s] threads: 64, tps: 2026.00, reads: 28566.06, writes: 8128.02, response time: 45.83ms (95%), errors: 0.00, reconnects:  0.00
[ 840s] threads: 64, tps: 2080.00, reads: 29091.04, writes: 8355.01, response time: 46.98ms (95%), errors: 0.00, reconnects:  0.00
[ 841s] threads: 64, tps: 2218.00, reads: 31033.98, writes: 8817.00, response time: 42.70ms (95%), errors: 0.00, reconnects:  0.00
[ 842s] threads: 64, tps: 2131.00, reads: 29745.02, writes: 8491.01, response time: 44.65ms (95%), errors: 0.00, reconnects:  0.00
[ 843s] threads: 64, tps: 2057.00, reads: 28876.93, writes: 8230.98, response time: 45.72ms (95%), errors: 0.00, reconnects:  0.00
[ 844s] threads: 64, tps: 1812.99, reads: 25381.91, writes: 7260.97, response time: 52.29ms (95%), errors: 0.00, reconnects:  0.00
[ 845s] threads: 64, tps: 1835.01, reads: 25789.10, writes: 7391.03, response time: 53.18ms (95%), errors: 0.00, reconnects:  0.00
[ 846s] threads: 64, tps: 1807.99, reads: 25274.90, writes: 7171.97, response time: 51.30ms (95%), errors: 0.00, reconnects:  0.00
[ 847s] threads: 64, tps: 1788.01, reads: 24947.13, writes: 7191.04, response time: 50.52ms (95%), errors: 0.00, reconnects:  0.00
[ 848s] threads: 64, tps: 1828.00, reads: 25644.98, writes: 7311.99, response time: 49.67ms (95%), errors: 0.00, reconnects:  0.00
[ 849s] threads: 64, tps: 1780.00, reads: 24925.02, writes: 7136.00, response time: 52.39ms (95%), errors: 0.00, reconnects:  0.00
[ 850s] threads: 64, tps: 1945.00, reads: 27085.01, writes: 7730.00, response time: 48.52ms (95%), errors: 0.00, reconnects:  0.00
[ 851s] threads: 64, tps: 1874.00, reads: 26238.96, writes: 7548.99, response time: 47.16ms (95%), errors: 0.00, reconnects:  0.00
[ 852s] threads: 64, tps: 1858.00, reads: 26018.02, writes: 7398.00, response time: 49.86ms (95%), errors: 0.00, reconnects:  0.00
[ 853s] threads: 64, tps: 1950.00, reads: 27433.95, writes: 7847.99, response time: 46.96ms (95%), errors: 0.00, reconnects:  0.00
[ 854s] threads: 64, tps: 1974.00, reads: 27656.04, writes: 7919.01, response time: 44.55ms (95%), errors: 0.00, reconnects:  0.00
[ 855s] threads: 64, tps: 1928.00, reads: 26944.03, writes: 7619.01, response time: 47.96ms (95%), errors: 0.00, reconnects:  0.00
[ 856s] threads: 64, tps: 1954.00, reads: 27454.99, writes: 7907.00, response time: 44.97ms (95%), errors: 0.00, reconnects:  0.00
[ 857s] threads: 64, tps: 1892.99, reads: 26471.84, writes: 7579.96, response time: 46.92ms (95%), errors: 0.00, reconnects:  0.00
[ 858s] threads: 64, tps: 1882.00, reads: 26293.00, writes: 7473.00, response time: 48.16ms (95%), errors: 0.00, reconnects:  0.00
[ 859s] threads: 64, tps: 1918.00, reads: 26703.00, writes: 7661.00, response time: 46.80ms (95%), errors: 0.00, reconnects:  0.00
[ 860s] threads: 64, tps: 1836.01, reads: 25804.11, writes: 7328.03, response time: 50.16ms (95%), errors: 0.00, reconnects:  0.00
[ 861s] threads: 64, tps: 1744.00, reads: 24366.05, writes: 6972.01, response time: 50.22ms (95%), errors: 0.00, reconnects:  0.00
[ 862s] threads: 64, tps: 1720.50, reads: 24192.01, writes: 6861.02, response time: 50.58ms (95%), errors: 0.00, reconnects:  0.00
[ 863s] threads: 64, tps: 1628.46, reads: 22813.50, writes: 6516.86, response time: 56.95ms (95%), errors: 0.00, reconnects:  0.00
[ 864s] threads: 64, tps: 1599.01, reads: 22384.08, writes: 6424.02, response time: 55.22ms (95%), errors: 0.00, reconnects:  0.00
[ 865s] threads: 64, tps: 1703.00, reads: 23677.00, writes: 6787.00, response time: 53.56ms (95%), errors: 0.00, reconnects:  0.00
[ 866s] threads: 64, tps: 1642.99, reads: 23175.91, writes: 6623.97, response time: 53.69ms (95%), errors: 0.00, reconnects:  0.00
[ 867s] threads: 64, tps: 1772.01, reads: 24788.12, writes: 7073.03, response time: 52.00ms (95%), errors: 0.00, reconnects:  0.00
[ 868s] threads: 64, tps: 1698.99, reads: 23634.90, writes: 6835.97, response time: 52.83ms (95%), errors: 0.00, reconnects:  0.00
[ 869s] threads: 64, tps: 1805.00, reads: 25480.00, writes: 7235.00, response time: 50.77ms (95%), errors: 0.00, reconnects:  0.00
[ 870s] threads: 64, tps: 1881.01, reads: 26293.15, writes: 7522.04, response time: 46.95ms (95%), errors: 0.00, reconnects:  0.00
[ 871s] threads: 64, tps: 1886.98, reads: 26278.68, writes: 7510.91, response time: 50.10ms (95%), errors: 0.00, reconnects:  0.00
[ 872s] threads: 64, tps: 1879.02, reads: 26444.29, writes: 7533.08, response time: 48.80ms (95%), errors: 0.00, reconnects:  0.00
[ 873s] threads: 64, tps: 1852.00, reads: 25924.95, writes: 7415.99, response time: 50.16ms (95%), errors: 0.00, reconnects:  0.00
[ 874s] threads: 64, tps: 1637.00, reads: 22917.05, writes: 6492.02, response time: 54.43ms (95%), errors: 0.00, reconnects:  0.00
[ 875s] threads: 64, tps: 1574.99, reads: 21982.90, writes: 6331.97, response time: 59.62ms (95%), errors: 0.00, reconnects:  0.00
[ 876s] threads: 64, tps: 1596.01, reads: 22372.09, writes: 6354.03, response time: 57.77ms (95%), errors: 0.00, reconnects:  0.00
[ 877s] threads: 64, tps: 1645.99, reads: 23084.89, writes: 6606.97, response time: 55.17ms (95%), errors: 0.00, reconnects:  0.00
[ 878s] threads: 64, tps: 1541.01, reads: 21500.12, writes: 6143.03, response time: 59.14ms (95%), errors: 0.00, reconnects:  0.00
[ 879s] threads: 64, tps: 1558.00, reads: 21839.99, writes: 6204.00, response time: 59.92ms (95%), errors: 0.00, reconnects:  0.00
[ 880s] threads: 64, tps: 1547.00, reads: 21720.98, writes: 6202.00, response time: 59.46ms (95%), errors: 0.00, reconnects:  0.00
[ 881s] threads: 64, tps: 1467.99, reads: 20485.92, writes: 5858.98, response time: 61.10ms (95%), errors: 0.00, reconnects:  0.00
[ 882s] threads: 64, tps: 1482.01, reads: 20716.08, writes: 5937.02, response time: 59.40ms (95%), errors: 0.00, reconnects:  0.00
[ 883s] threads: 64, tps: 1572.00, reads: 22073.98, writes: 6293.00, response time: 53.87ms (95%), errors: 0.00, reconnects:  0.00
[ 884s] threads: 64, tps: 1598.00, reads: 22334.98, writes: 6429.99, response time: 56.14ms (95%), errors: 0.00, reconnects:  0.00
[ 885s] threads: 64, tps: 1676.00, reads: 23486.04, writes: 6685.01, response time: 51.86ms (95%), errors: 0.00, reconnects:  0.00
[ 886s] threads: 64, tps: 1695.00, reads: 23670.97, writes: 6785.99, response time: 52.06ms (95%), errors: 0.00, reconnects:  0.00
[ 887s] threads: 64, tps: 1708.00, reads: 23965.94, writes: 6841.98, response time: 51.41ms (95%), errors: 0.00, reconnects:  0.00
[ 888s] threads: 64, tps: 1744.01, reads: 24373.10, writes: 6983.03, response time: 51.95ms (95%), errors: 0.00, reconnects:  0.00
[ 889s] threads: 64, tps: 1779.00, reads: 24873.99, writes: 7106.00, response time: 50.04ms (95%), errors: 0.00, reconnects:  0.00
[ 890s] threads: 64, tps: 1775.00, reads: 24983.00, writes: 7165.00, response time: 49.92ms (95%), errors: 0.00, reconnects:  0.00
[ 891s] threads: 64, tps: 1874.00, reads: 26147.98, writes: 7434.99, response time: 46.18ms (95%), errors: 0.00, reconnects:  0.00
[ 892s] threads: 64, tps: 1782.00, reads: 24881.02, writes: 7100.00, response time: 49.50ms (95%), errors: 0.00, reconnects:  0.00
[ 893s] threads: 64, tps: 1805.00, reads: 25367.97, writes: 7271.99, response time: 48.75ms (95%), errors: 0.00, reconnects:  0.00
[ 894s] threads: 64, tps: 1847.99, reads: 25807.91, writes: 7381.98, response time: 48.84ms (95%), errors: 0.00, reconnects:  0.00
[ 895s] threads: 64, tps: 1810.01, reads: 25448.11, writes: 7255.03, response time: 50.33ms (95%), errors: 0.00, reconnects:  0.00
[ 896s] threads: 64, tps: 1780.00, reads: 24846.98, writes: 7057.99, response time: 50.19ms (95%), errors: 0.00, reconnects:  0.00
[ 897s] threads: 64, tps: 1763.00, reads: 24703.02, writes: 7058.00, response time: 50.87ms (95%), errors: 0.00, reconnects:  0.00
[ 898s] threads: 64, tps: 1570.00, reads: 22071.95, writes: 6331.99, response time: 57.27ms (95%), errors: 0.00, reconnects:  0.00
[ 899s] threads: 64, tps: 1590.00, reads: 22186.05, writes: 6294.01, response time: 55.27ms (95%), errors: 0.00, reconnects:  0.00
[ 900s] threads: 64, tps: 1619.00, reads: 22761.01, writes: 6552.00, response time: 52.12ms (95%), errors: 0.00, reconnects:  0.00
[ 901s] threads: 64, tps: 1673.98, reads: 23260.70, writes: 6668.91, response time: 53.21ms (95%), errors: 0.00, reconnects:  0.00
[ 902s] threads: 64, tps: 1743.02, reads: 24421.31, writes: 6967.09, response time: 50.04ms (95%), errors: 0.00, reconnects:  0.00
[ 903s] threads: 64, tps: 1844.00, reads: 25869.99, writes: 7358.00, response time: 48.52ms (95%), errors: 0.00, reconnects:  0.00
[ 904s] threads: 64, tps: 1898.98, reads: 26602.75, writes: 7650.93, response time: 46.24ms (95%), errors: 0.00, reconnects:  0.00
[ 905s] threads: 64, tps: 1963.02, reads: 27577.28, writes: 7871.08, response time: 44.78ms (95%), errors: 0.00, reconnects:  0.00
[ 906s] threads: 64, tps: 1914.00, reads: 26593.98, writes: 7600.99, response time: 46.75ms (95%), errors: 0.00, reconnects:  0.00
[ 907s] threads: 64, tps: 1802.00, reads: 25156.02, writes: 7199.00, response time: 52.65ms (95%), errors: 0.00, reconnects:  0.00
[ 908s] threads: 64, tps: 1722.00, reads: 24198.98, writes: 6883.99, response time: 54.51ms (95%), errors: 0.00, reconnects:  0.00
[ 909s] threads: 64, tps: 1732.98, reads: 24272.71, writes: 6990.92, response time: 59.98ms (95%), errors: 0.00, reconnects:  0.00
[ 910s] threads: 64, tps: 1832.02, reads: 25685.33, writes: 7274.09, response time: 50.16ms (95%), errors: 0.00, reconnects:  0.00
[ 911s] threads: 64, tps: 1804.00, reads: 25341.02, writes: 7294.00, response time: 48.68ms (95%), errors: 0.00, reconnects:  0.00
[ 912s] threads: 64, tps: 1843.00, reads: 25693.99, writes: 7255.00, response time: 49.48ms (95%), errors: 0.00, reconnects:  0.00
[ 913s] threads: 64, tps: 1738.00, reads: 24421.01, writes: 7019.00, response time: 50.00ms (95%), errors: 0.00, reconnects:  0.00
[ 914s] threads: 64, tps: 1783.00, reads: 24927.96, writes: 7055.99, response time: 51.65ms (95%), errors: 0.00, reconnects:  0.00
[ 915s] threads: 64, tps: 1755.00, reads: 24377.02, writes: 7027.01, response time: 54.92ms (95%), errors: 0.00, reconnects:  0.00
[ 916s] threads: 64, tps: 1585.00, reads: 22344.99, writes: 6346.00, response time: 56.56ms (95%), errors: 0.00, reconnects:  0.00
[ 917s] threads: 64, tps: 1647.00, reads: 23103.01, writes: 6599.00, response time: 53.37ms (95%), errors: 0.00, reconnects:  0.00
[ 918s] threads: 64, tps: 1714.00, reads: 23975.01, writes: 6845.00, response time: 50.22ms (95%), errors: 0.00, reconnects:  0.00
[ 919s] threads: 64, tps: 1726.00, reads: 24252.96, writes: 6967.99, response time: 50.30ms (95%), errors: 0.00, reconnects:  0.00
[ 920s] threads: 64, tps: 1850.00, reads: 25795.03, writes: 7363.01, response time: 49.28ms (95%), errors: 0.00, reconnects:  0.00
[ 921s] threads: 64, tps: 1925.00, reads: 27063.96, writes: 7763.99, response time: 46.47ms (95%), errors: 0.00, reconnects:  0.00
[ 922s] threads: 64, tps: 1908.99, reads: 26609.89, writes: 7600.97, response time: 45.72ms (95%), errors: 0.00, reconnects:  0.00
[ 923s] threads: 64, tps: 1940.01, reads: 27295.14, writes: 7806.04, response time: 46.82ms (95%), errors: 0.00, reconnects:  0.00
[ 924s] threads: 64, tps: 1898.00, reads: 26537.02, writes: 7555.01, response time: 47.64ms (95%), errors: 0.00, reconnects:  0.00
[ 925s] threads: 64, tps: 1959.00, reads: 27305.99, writes: 7793.00, response time: 45.16ms (95%), errors: 0.00, reconnects:  0.00
[ 926s] threads: 64, tps: 1866.00, reads: 26158.03, writes: 7503.01, response time: 47.50ms (95%), errors: 0.00, reconnects:  0.00
[ 927s] threads: 64, tps: 1933.00, reads: 27000.97, writes: 7666.99, response time: 46.84ms (95%), errors: 0.00, reconnects:  0.00
[ 928s] threads: 64, tps: 1773.00, reads: 24885.99, writes: 7143.00, response time: 49.71ms (95%), errors: 0.00, reconnects:  0.00
[ 929s] threads: 64, tps: 1829.00, reads: 25617.01, writes: 7326.00, response time: 50.60ms (95%), errors: 0.00, reconnects:  0.00
[ 930s] threads: 64, tps: 1920.00, reads: 26897.00, writes: 7673.00, response time: 47.97ms (95%), errors: 0.00, reconnects:  0.00
[ 931s] threads: 64, tps: 1897.00, reads: 26495.95, writes: 7539.99, response time: 47.53ms (95%), errors: 0.00, reconnects:  0.00
[ 932s] threads: 64, tps: 1811.01, reads: 25386.08, writes: 7248.02, response time: 48.29ms (95%), errors: 0.00, reconnects:  0.00
[ 933s] threads: 64, tps: 1732.00, reads: 24258.00, writes: 6920.00, response time: 52.04ms (95%), errors: 0.00, reconnects:  0.00
[ 934s] threads: 64, tps: 1611.00, reads: 22547.99, writes: 6439.00, response time: 54.87ms (95%), errors: 0.00, reconnects:  0.00
[ 935s] threads: 64, tps: 1654.00, reads: 23201.01, writes: 6614.00, response time: 52.81ms (95%), errors: 0.00, reconnects:  0.00
[ 936s] threads: 64, tps: 1746.99, reads: 24370.85, writes: 7011.96, response time: 49.37ms (95%), errors: 0.00, reconnects:  0.00
[ 937s] threads: 64, tps: 1887.00, reads: 26462.98, writes: 7574.99, response time: 48.25ms (95%), errors: 0.00, reconnects:  0.00
[ 938s] threads: 64, tps: 1933.01, reads: 26988.18, writes: 7729.05, response time: 48.84ms (95%), errors: 0.00, reconnects:  0.00
[ 939s] threads: 64, tps: 2000.00, reads: 28018.98, writes: 8029.99, response time: 45.63ms (95%), errors: 0.00, reconnects:  0.00
[ 940s] threads: 64, tps: 1860.00, reads: 26094.00, writes: 7414.00, response time: 50.95ms (95%), errors: 0.00, reconnects:  0.00
[ 941s] threads: 64, tps: 1876.96, reads: 26405.49, writes: 7588.85, response time: 54.09ms (95%), errors: 0.00, reconnects:  0.00
[ 942s] threads: 64, tps: 1913.03, reads: 26646.48, writes: 7594.14, response time: 52.17ms (95%), errors: 0.00, reconnects:  0.00
[ 943s] threads: 64, tps: 2101.00, reads: 29550.04, writes: 8463.01, response time: 43.05ms (95%), errors: 0.00, reconnects:  0.00
[ 944s] threads: 64, tps: 2075.00, reads: 29019.94, writes: 8299.98, response time: 43.84ms (95%), errors: 0.00, reconnects:  0.00
[ 945s] threads: 64, tps: 1958.00, reads: 27293.01, writes: 7726.00, response time: 47.80ms (95%), errors: 0.00, reconnects:  0.00
[ 946s] threads: 64, tps: 1949.00, reads: 27228.03, writes: 7795.01, response time: 47.27ms (95%), errors: 0.00, reconnects:  0.00
[ 947s] threads: 64, tps: 2001.00, reads: 28051.00, writes: 8005.00, response time: 47.33ms (95%), errors: 0.00, reconnects:  0.00
[ 948s] threads: 64, tps: 1933.00, reads: 26978.98, writes: 7700.99, response time: 47.74ms (95%), errors: 0.00, reconnects:  0.00
[ 949s] threads: 64, tps: 1764.00, reads: 24812.04, writes: 7067.01, response time: 51.47ms (95%), errors: 0.00, reconnects:  0.00
[ 950s] threads: 64, tps: 1638.00, reads: 22933.98, writes: 6534.00, response time: 57.15ms (95%), errors: 0.00, reconnects:  0.00
[ 951s] threads: 64, tps: 1604.00, reads: 22484.03, writes: 6431.01, response time: 56.98ms (95%), errors: 0.00, reconnects:  0.00
[ 952s] threads: 64, tps: 1424.00, reads: 19986.98, writes: 5724.99, response time: 68.30ms (95%), errors: 0.00, reconnects:  0.00
[ 953s] threads: 64, tps: 1656.99, reads: 23115.87, writes: 6593.96, response time: 54.16ms (95%), errors: 0.00, reconnects:  0.00
[ 954s] threads: 64, tps: 1697.01, reads: 23772.11, writes: 6795.03, response time: 52.45ms (95%), errors: 0.00, reconnects:  0.00
[ 955s] threads: 64, tps: 1583.99, reads: 22248.90, writes: 6408.97, response time: 55.73ms (95%), errors: 0.00, reconnects:  0.00
[ 956s] threads: 64, tps: 1631.01, reads: 22689.11, writes: 6487.03, response time: 55.60ms (95%), errors: 0.00, reconnects:  0.00
[ 957s] threads: 64, tps: 1732.00, reads: 24316.00, writes: 6931.00, response time: 53.53ms (95%), errors: 0.00, reconnects:  0.00
[ 958s] threads: 64, tps: 1859.00, reads: 25987.04, writes: 7416.01, response time: 48.58ms (95%), errors: 0.00, reconnects:  0.00
[ 959s] threads: 64, tps: 2008.99, reads: 28045.92, writes: 8023.98, response time: 47.33ms (95%), errors: 0.00, reconnects:  0.00
[ 960s] threads: 64, tps: 2052.00, reads: 28789.06, writes: 8235.02, response time: 45.48ms (95%), errors: 0.00, reconnects:  0.00
[ 961s] threads: 64, tps: 2144.00, reads: 30101.99, writes: 8612.00, response time: 44.34ms (95%), errors: 0.00, reconnects:  0.00
[ 962s] threads: 64, tps: 2255.00, reads: 31561.00, writes: 8983.00, response time: 43.66ms (95%), errors: 0.00, reconnects:  0.00
[ 963s] threads: 64, tps: 2327.00, reads: 32533.99, writes: 9340.00, response time: 41.74ms (95%), errors: 0.00, reconnects:  0.00
[ 964s] threads: 64, tps: 2293.00, reads: 32043.03, writes: 9101.01, response time: 46.80ms (95%), errors: 0.00, reconnects:  0.00
[ 965s] threads: 64, tps: 2184.00, reads: 30535.00, writes: 8736.00, response time: 48.51ms (95%), errors: 0.00, reconnects:  0.00
[ 966s] threads: 64, tps: 2146.00, reads: 30057.95, writes: 8581.99, response time: 54.43ms (95%), errors: 0.00, reconnects:  0.00
[ 967s] threads: 64, tps: 2476.00, reads: 34804.04, writes: 10012.01, response time: 40.09ms (95%), errors: 0.00, reconnects:  0.00
[ 968s] threads: 64, tps: 2593.00, reads: 36279.93, writes: 10371.98, response time: 37.02ms (95%), errors: 0.00, reconnects:  0.00
[ 969s] threads: 64, tps: 2640.00, reads: 37028.96, writes: 10563.99, response time: 38.10ms (95%), errors: 0.00, reconnects:  0.00
[ 970s] threads: 64, tps: 2587.01, reads: 36304.11, writes: 10399.03, response time: 38.37ms (95%), errors: 0.00, reconnects:  0.00
[ 971s] threads: 64, tps: 2285.00, reads: 31872.99, writes: 9037.00, response time: 43.33ms (95%), errors: 0.00, reconnects:  0.00
[ 972s] threads: 64, tps: 2121.99, reads: 29673.87, writes: 8463.96, response time: 45.54ms (95%), errors: 0.00, reconnects:  0.00
[ 973s] threads: 64, tps: 2193.01, reads: 30793.15, writes: 8828.04, response time: 43.77ms (95%), errors: 0.00, reconnects:  0.00
[ 974s] threads: 64, tps: 2357.00, reads: 32939.02, writes: 9461.00, response time: 40.38ms (95%), errors: 0.00, reconnects:  0.00
[ 975s] threads: 64, tps: 2361.99, reads: 33181.82, writes: 9465.95, response time: 40.54ms (95%), errors: 0.00, reconnects:  0.00
[ 976s] threads: 64, tps: 2416.97, reads: 33763.65, writes: 9585.90, response time: 39.76ms (95%), errors: 0.00, reconnects:  0.00
[ 977s] threads: 64, tps: 2349.04, reads: 32779.52, writes: 9394.15, response time: 40.73ms (95%), errors: 0.00, reconnects:  0.00
[ 978s] threads: 64, tps: 2360.00, reads: 32957.96, writes: 9377.99, response time: 41.94ms (95%), errors: 0.00, reconnects:  0.00
[ 979s] threads: 64, tps: 2299.00, reads: 32265.98, writes: 9281.00, response time: 42.18ms (95%), errors: 0.00, reconnects:  0.00
[ 980s] threads: 64, tps: 2298.00, reads: 32313.98, writes: 9211.99, response time: 41.73ms (95%), errors: 0.00, reconnects:  0.00
[ 981s] threads: 64, tps: 2418.00, reads: 33593.04, writes: 9586.01, response time: 40.67ms (95%), errors: 0.00, reconnects:  0.00
[ 982s] threads: 64, tps: 2294.00, reads: 32246.01, writes: 9216.00, response time: 42.48ms (95%), errors: 0.00, reconnects:  0.00
[ 983s] threads: 64, tps: 2392.00, reads: 33493.96, writes: 9568.99, response time: 41.86ms (95%), errors: 0.00, reconnects:  0.00
[ 984s] threads: 64, tps: 2342.00, reads: 32919.03, writes: 9424.01, response time: 46.60ms (95%), errors: 0.00, reconnects:  0.00
[ 985s] threads: 64, tps: 2430.00, reads: 34025.02, writes: 9701.01, response time: 40.24ms (95%), errors: 0.00, reconnects:  0.00
[ 986s] threads: 64, tps: 2242.00, reads: 31300.96, writes: 8934.99, response time: 41.78ms (95%), errors: 0.00, reconnects:  0.00
[ 987s] threads: 64, tps: 2294.00, reads: 32106.06, writes: 9201.02, response time: 41.55ms (95%), errors: 0.00, reconnects:  0.00
[ 988s] threads: 64, tps: 2291.00, reads: 32009.97, writes: 9078.99, response time: 43.32ms (95%), errors: 0.00, reconnects:  0.00
[ 989s] threads: 64, tps: 2166.00, reads: 30306.96, writes: 8712.99, response time: 45.08ms (95%), errors: 0.00, reconnects:  0.00
[ 990s] threads: 64, tps: 2171.98, reads: 30546.67, writes: 8733.91, response time: 43.34ms (95%), errors: 0.00, reconnects:  0.00
[ 991s] threads: 64, tps: 1951.02, reads: 27155.29, writes: 7710.08, response time: 48.83ms (95%), errors: 0.00, reconnects:  0.00
[ 992s] threads: 64, tps: 2019.99, reads: 28459.80, writes: 8179.94, response time: 46.46ms (95%), errors: 0.00, reconnects:  0.00
[ 993s] threads: 64, tps: 1919.02, reads: 26748.22, writes: 7600.06, response time: 49.83ms (95%), errors: 0.00, reconnects:  0.00
[ 994s] threads: 64, tps: 1928.00, reads: 26991.00, writes: 7743.00, response time: 47.25ms (95%), errors: 0.00, reconnects:  0.00
[ 995s] threads: 64, tps: 1943.00, reads: 27237.98, writes: 7767.00, response time: 47.72ms (95%), errors: 0.00, reconnects:  0.00
[ 996s] threads: 64, tps: 1986.00, reads: 27733.00, writes: 7997.00, response time: 45.77ms (95%), errors: 0.00, reconnects:  0.00
[ 997s] threads: 64, tps: 2002.53, reads: 28052.40, writes: 7932.14, response time: 47.36ms (95%), errors: 0.00, reconnects:  0.00
[ 998s] threads: 64, tps: 2103.50, reads: 29379.93, writes: 8436.99, response time: 43.47ms (95%), errors: 0.00, reconnects:  0.00
[ 999s] threads: 64, tps: 1986.00, reads: 27903.00, writes: 7937.00, response time: 47.33ms (95%), errors: 0.00, reconnects:  0.00
[1000s] threads: 64, tps: 1987.00, reads: 27824.99, writes: 8014.00, response time: 48.97ms (95%), errors: 0.00, reconnects:  0.00
[1001s] threads: 64, tps: 2130.00, reads: 29763.95, writes: 8447.99, response time: 43.58ms (95%), errors: 0.00, reconnects:  0.00
[1002s] threads: 64, tps: 2229.00, reads: 31203.05, writes: 8938.01, response time: 42.46ms (95%), errors: 0.00, reconnects:  0.00
[1003s] threads: 64, tps: 2115.00, reads: 29735.00, writes: 8513.00, response time: 44.22ms (95%), errors: 0.00, reconnects:  0.00
[1004s] threads: 64, tps: 2049.00, reads: 28544.00, writes: 8140.00, response time: 48.00ms (95%), errors: 0.00, reconnects:  0.00
[1005s] threads: 64, tps: 1850.00, reads: 25952.95, writes: 7381.99, response time: 50.84ms (95%), errors: 0.00, reconnects:  0.00
[1006s] threads: 64, tps: 2009.00, reads: 28120.04, writes: 8036.01, response time: 46.53ms (95%), errors: 0.00, reconnects:  0.00
[1007s] threads: 64, tps: 1949.99, reads: 27341.90, writes: 7881.97, response time: 47.86ms (95%), errors: 0.00, reconnects:  0.00
[1008s] threads: 64, tps: 2054.01, reads: 28737.11, writes: 8190.03, response time: 44.75ms (95%), errors: 0.00, reconnects:  0.00
[1009s] threads: 64, tps: 2074.00, reads: 29187.97, writes: 8379.99, response time: 44.45ms (95%), errors: 0.00, reconnects:  0.00
[1010s] threads: 64, tps: 2016.99, reads: 28084.89, writes: 7933.97, response time: 46.21ms (95%), errors: 0.00, reconnects:  0.00
[1011s] threads: 64, tps: 1959.01, reads: 27363.12, writes: 7807.03, response time: 46.63ms (95%), errors: 0.00, reconnects:  0.00
[1012s] threads: 64, tps: 1785.00, reads: 25099.02, writes: 7200.01, response time: 51.35ms (95%), errors: 0.00, reconnects:  0.00
[1013s] threads: 64, tps: 1773.00, reads: 24604.02, writes: 7019.01, response time: 51.21ms (95%), errors: 0.00, reconnects:  0.00
[1014s] threads: 64, tps: 1704.97, reads: 23979.60, writes: 6833.89, response time: 54.43ms (95%), errors: 0.00, reconnects:  0.00
[1015s] threads: 64, tps: 1755.03, reads: 24693.42, writes: 7110.12, response time: 52.75ms (95%), errors: 0.00, reconnects:  0.00
[1016s] threads: 64, tps: 1873.00, reads: 26144.97, writes: 7460.99, response time: 48.04ms (95%), errors: 0.00, reconnects:  0.00
[1017s] threads: 64, tps: 1821.00, reads: 25513.99, writes: 7225.00, response time: 51.47ms (95%), errors: 0.00, reconnects:  0.00
[1018s] threads: 64, tps: 1968.00, reads: 27475.04, writes: 7910.01, response time: 45.98ms (95%), errors: 0.00, reconnects:  0.00
[1019s] threads: 64, tps: 2017.00, reads: 28408.00, writes: 8127.00, response time: 45.67ms (95%), errors: 0.00, reconnects:  0.00
[1020s] threads: 64, tps: 1912.00, reads: 26680.99, writes: 7596.00, response time: 48.23ms (95%), errors: 0.00, reconnects:  0.00
[1021s] threads: 64, tps: 1962.00, reads: 27492.96, writes: 7860.99, response time: 46.92ms (95%), errors: 0.00, reconnects:  0.00
[1022s] threads: 64, tps: 1981.00, reads: 27675.03, writes: 7910.01, response time: 46.84ms (95%), errors: 0.00, reconnects:  0.00
[1023s] threads: 64, tps: 1837.00, reads: 25681.98, writes: 7329.99, response time: 50.69ms (95%), errors: 0.00, reconnects:  0.00
[1024s] threads: 64, tps: 1903.00, reads: 26719.04, writes: 7623.01, response time: 50.70ms (95%), errors: 0.00, reconnects:  0.00
[1025s] threads: 64, tps: 1716.00, reads: 24151.00, writes: 6941.00, response time: 53.90ms (95%), errors: 0.00, reconnects:  0.00
[1026s] threads: 64, tps: 1763.00, reads: 24423.96, writes: 6921.99, response time: 53.83ms (95%), errors: 0.00, reconnects:  0.00
[1027s] threads: 64, tps: 1736.00, reads: 24364.05, writes: 6945.01, response time: 52.62ms (95%), errors: 0.00, reconnects:  0.00
[1028s] threads: 64, tps: 1793.00, reads: 25101.97, writes: 7193.99, response time: 49.71ms (95%), errors: 0.00, reconnects:  0.00
[1029s] threads: 64, tps: 1782.00, reads: 24977.01, writes: 7131.00, response time: 51.95ms (95%), errors: 0.00, reconnects:  0.00
[1030s] threads: 64, tps: 1499.00, reads: 21093.96, writes: 6032.99, response time: 61.36ms (95%), errors: 0.00, reconnects:  0.00
[1031s] threads: 64, tps: 1557.00, reads: 21731.04, writes: 6234.01, response time: 59.42ms (95%), errors: 0.00, reconnects:  0.00
[1032s] threads: 64, tps: 1611.99, reads: 22534.85, writes: 6376.96, response time: 57.45ms (95%), errors: 0.00, reconnects:  0.00
[1033s] threads: 64, tps: 1607.01, reads: 22503.17, writes: 6486.05, response time: 54.14ms (95%), errors: 0.00, reconnects:  0.00
[1034s] threads: 64, tps: 1640.00, reads: 22895.01, writes: 6510.00, response time: 54.16ms (95%), errors: 0.00, reconnects:  0.00
[1035s] threads: 64, tps: 1676.97, reads: 23465.54, writes: 6730.87, response time: 52.61ms (95%), errors: 0.00, reconnects:  0.00
[1036s] threads: 64, tps: 1749.03, reads: 24662.44, writes: 7076.13, response time: 50.78ms (95%), errors: 0.00, reconnects:  0.00
[1037s] threads: 64, tps: 1818.98, reads: 25410.76, writes: 7261.93, response time: 48.57ms (95%), errors: 0.00, reconnects:  0.00
[1038s] threads: 64, tps: 1855.02, reads: 25847.24, writes: 7338.07, response time: 50.70ms (95%), errors: 0.00, reconnects:  0.00
[1039s] threads: 64, tps: 1863.00, reads: 26229.04, writes: 7503.01, response time: 48.29ms (95%), errors: 0.00, reconnects:  0.00
[1040s] threads: 64, tps: 1899.00, reads: 26480.96, writes: 7571.99, response time: 45.74ms (95%), errors: 0.00, reconnects:  0.00
[1041s] threads: 64, tps: 1878.00, reads: 26302.02, writes: 7504.01, response time: 48.09ms (95%), errors: 0.00, reconnects:  0.00
[1042s] threads: 64, tps: 1779.70, reads: 25103.75, writes: 7224.78, response time: 49.56ms (95%), errors: 0.00, reconnects:  0.00
[1043s] threads: 64, tps: 1909.31, reads: 26522.31, writes: 7578.23, response time: 47.10ms (95%), errors: 0.00, reconnects:  0.00
[1044s] threads: 64, tps: 1696.01, reads: 23735.15, writes: 6759.04, response time: 54.96ms (95%), errors: 0.00, reconnects:  0.00
[1045s] threads: 64, tps: 1732.00, reads: 24321.97, writes: 6920.99, response time: 54.74ms (95%), errors: 0.00, reconnects:  0.00
[1046s] threads: 64, tps: 1702.00, reads: 23787.03, writes: 6839.01, response time: 52.61ms (95%), errors: 0.00, reconnects:  0.00
[1047s] threads: 64, tps: 1676.00, reads: 23535.00, writes: 6671.00, response time: 54.16ms (95%), errors: 0.00, reconnects:  0.00
[1048s] threads: 64, tps: 1521.00, reads: 21083.98, writes: 6095.99, response time: 61.37ms (95%), errors: 0.00, reconnects:  0.00
[1049s] threads: 64, tps: 1572.98, reads: 22233.66, writes: 6294.90, response time: 57.29ms (95%), errors: 0.00, reconnects:  0.00
[1050s] threads: 64, tps: 1494.02, reads: 21001.34, writes: 5983.10, response time: 62.32ms (95%), errors: 0.00, reconnects:  0.00
[1051s] threads: 64, tps: 1507.00, reads: 20951.03, writes: 5967.01, response time: 60.10ms (95%), errors: 0.00, reconnects:  0.00
[1052s] threads: 64, tps: 1448.00, reads: 20316.96, writes: 5806.99, response time: 60.97ms (95%), errors: 0.00, reconnects:  0.00
[1053s] threads: 64, tps: 1482.00, reads: 20729.01, writes: 5942.00, response time: 61.25ms (95%), errors: 0.00, reconnects:  0.00
[1054s] threads: 64, tps: 1579.00, reads: 22101.01, writes: 6319.00, response time: 56.22ms (95%), errors: 0.00, reconnects:  0.00
[1055s] threads: 64, tps: 1667.00, reads: 23441.99, writes: 6725.00, response time: 51.52ms (95%), errors: 0.00, reconnects:  0.00
[1056s] threads: 64, tps: 1732.00, reads: 24135.01, writes: 6882.00, response time: 51.76ms (95%), errors: 0.00, reconnects:  0.00
[1057s] threads: 64, tps: 1672.99, reads: 23437.91, writes: 6737.97, response time: 52.70ms (95%), errors: 0.00, reconnects:  0.00
[1058s] threads: 64, tps: 1723.01, reads: 24147.11, writes: 6876.03, response time: 52.12ms (95%), errors: 0.00, reconnects:  0.00
[1059s] threads: 64, tps: 1690.00, reads: 23717.95, writes: 6785.99, response time: 54.09ms (95%), errors: 0.00, reconnects:  0.00
[1060s] threads: 64, tps: 1667.00, reads: 23216.03, writes: 6617.01, response time: 54.12ms (95%), errors: 0.00, reconnects:  0.00
[1061s] threads: 64, tps: 1685.00, reads: 23522.99, writes: 6727.00, response time: 53.88ms (95%), errors: 0.00, reconnects:  0.00
[1062s] threads: 64, tps: 1720.00, reads: 24133.97, writes: 6903.99, response time: 52.29ms (95%), errors: 0.00, reconnects:  0.00
[1063s] threads: 64, tps: 1569.00, reads: 21953.06, writes: 6275.02, response time: 57.48ms (95%), errors: 0.00, reconnects:  0.00
[1064s] threads: 64, tps: 1525.00, reads: 21425.98, writes: 6092.00, response time: 59.17ms (95%), errors: 0.00, reconnects:  0.00
[1065s] threads: 64, tps: 1554.99, reads: 21709.91, writes: 6226.98, response time: 60.34ms (95%), errors: 0.00, reconnects:  0.00
[1066s] threads: 64, tps: 1589.00, reads: 22310.06, writes: 6341.02, response time: 56.32ms (95%), errors: 0.00, reconnects:  0.00
[1067s] threads: 64, tps: 1573.00, reads: 21968.02, writes: 6285.00, response time: 60.70ms (95%), errors: 0.00, reconnects:  0.00
[1068s] threads: 64, tps: 1485.00, reads: 20766.01, writes: 5907.00, response time: 60.46ms (95%), errors: 0.00, reconnects:  0.00
[1069s] threads: 64, tps: 1472.00, reads: 20738.98, writes: 5924.99, response time: 62.04ms (95%), errors: 0.00, reconnects:  0.00
[1070s] threads: 64, tps: 1349.00, reads: 18841.02, writes: 5366.01, response time: 65.85ms (95%), errors: 0.00, reconnects:  0.00
[1071s] threads: 64, tps: 1412.00, reads: 19745.99, writes: 5651.00, response time: 61.06ms (95%), errors: 0.00, reconnects:  0.00
[1072s] threads: 64, tps: 1448.00, reads: 20203.99, writes: 5788.00, response time: 59.30ms (95%), errors: 0.00, reconnects:  0.00
[1073s] threads: 64, tps: 1529.00, reads: 21457.00, writes: 6120.00, response time: 56.54ms (95%), errors: 0.00, reconnects:  0.00
[1074s] threads: 64, tps: 1584.00, reads: 22185.02, writes: 6356.01, response time: 54.86ms (95%), errors: 0.00, reconnects:  0.00
[1075s] threads: 64, tps: 1631.00, reads: 22801.01, writes: 6557.00, response time: 55.10ms (95%), errors: 0.00, reconnects:  0.00
[1076s] threads: 64, tps: 1703.00, reads: 23862.99, writes: 6828.00, response time: 51.92ms (95%), errors: 0.00, reconnects:  0.00
[1077s] threads: 64, tps: 1730.00, reads: 24234.99, writes: 6900.00, response time: 53.38ms (95%), errors: 0.00, reconnects:  0.00
[1078s] threads: 64, tps: 1764.00, reads: 24752.04, writes: 7078.01, response time: 51.25ms (95%), errors: 0.00, reconnects:  0.00
[1079s] threads: 64, tps: 1731.00, reads: 24240.99, writes: 6930.00, response time: 51.22ms (95%), errors: 0.00, reconnects:  0.00
[1080s] threads: 64, tps: 1776.00, reads: 24803.96, writes: 7085.99, response time: 49.76ms (95%), errors: 0.00, reconnects:  0.00
[1081s] threads: 64, tps: 1758.00, reads: 24627.01, writes: 6967.00, response time: 49.76ms (95%), errors: 0.00, reconnects:  0.00
[1082s] threads: 64, tps: 1648.00, reads: 23043.01, writes: 6629.00, response time: 53.29ms (95%), errors: 0.00, reconnects:  0.00
[1083s] threads: 64, tps: 1626.00, reads: 22808.03, writes: 6516.01, response time: 54.79ms (95%), errors: 0.00, reconnects:  0.00
[1084s] threads: 64, tps: 1715.00, reads: 24037.96, writes: 6871.99, response time: 50.63ms (95%), errors: 0.00, reconnects:  0.00
[1085s] threads: 64, tps: 1659.00, reads: 23116.96, writes: 6582.99, response time: 53.98ms (95%), errors: 0.00, reconnects:  0.00
[1086s] threads: 64, tps: 1572.00, reads: 22014.05, writes: 6265.01, response time: 57.48ms (95%), errors: 0.00, reconnects:  0.00
[1087s] threads: 64, tps: 1534.00, reads: 21517.00, writes: 6143.00, response time: 57.14ms (95%), errors: 0.00, reconnects:  0.00
[1088s] threads: 64, tps: 1485.00, reads: 20873.97, writes: 6016.99, response time: 62.67ms (95%), errors: 0.00, reconnects:  0.00
[1089s] threads: 64, tps: 1286.00, reads: 17872.03, writes: 5066.01, response time: 67.79ms (95%), errors: 0.00, reconnects:  0.00
[1090s] threads: 64, tps: 1374.00, reads: 19204.98, writes: 5494.00, response time: 61.45ms (95%), errors: 0.00, reconnects:  0.00
[1091s] threads: 64, tps: 1428.00, reads: 20120.00, writes: 5728.00, response time: 60.46ms (95%), errors: 0.00, reconnects:  0.00
[1092s] threads: 64, tps: 1408.00, reads: 19732.02, writes: 5655.00, response time: 64.58ms (95%), errors: 0.00, reconnects:  0.00
[1093s] threads: 64, tps: 1544.00, reads: 21634.98, writes: 6229.99, response time: 58.63ms (95%), errors: 0.00, reconnects:  0.00
[1094s] threads: 64, tps: 1705.00, reads: 23767.00, writes: 6815.00, response time: 51.48ms (95%), errors: 0.00, reconnects:  0.00
[1095s] threads: 64, tps: 1652.00, reads: 23103.00, writes: 6540.00, response time: 55.14ms (95%), errors: 0.00, reconnects:  0.00
[1096s] threads: 64, tps: 1679.00, reads: 23492.01, writes: 6742.00, response time: 52.72ms (95%), errors: 0.00, reconnects:  0.00
[1097s] threads: 64, tps: 1770.00, reads: 24787.02, writes: 7081.00, response time: 50.12ms (95%), errors: 0.00, reconnects:  0.00
[1098s] threads: 64, tps: 1723.00, reads: 24193.99, writes: 6901.00, response time: 52.72ms (95%), errors: 0.00, reconnects:  0.00
[1099s] threads: 64, tps: 1622.00, reads: 22791.01, writes: 6538.00, response time: 61.19ms (95%), errors: 0.00, reconnects:  0.00
[1100s] threads: 64, tps: 1770.00, reads: 24691.99, writes: 7057.00, response time: 54.86ms (95%), errors: 0.00, reconnects:  0.00
[1101s] threads: 64, tps: 1763.00, reads: 24801.02, writes: 7110.01, response time: 52.40ms (95%), errors: 0.00, reconnects:  0.00
[1102s] threads: 64, tps: 1598.00, reads: 22188.99, writes: 6271.00, response time: 56.90ms (95%), errors: 0.00, reconnects:  0.00
[1103s] threads: 64, tps: 1709.00, reads: 23919.97, writes: 6832.99, response time: 53.64ms (95%), errors: 0.00, reconnects:  0.00
[1104s] threads: 64, tps: 1783.00, reads: 24995.04, writes: 7183.01, response time: 51.04ms (95%), errors: 0.00, reconnects:  0.00
[1105s] threads: 64, tps: 1711.99, reads: 23947.88, writes: 6785.96, response time: 51.50ms (95%), errors: 0.00, reconnects:  0.00
[1106s] threads: 64, tps: 1639.01, reads: 22944.10, writes: 6557.03, response time: 56.88ms (95%), errors: 0.00, reconnects:  0.00
[1107s] threads: 64, tps: 1562.94, reads: 21982.11, writes: 6252.75, response time: 57.29ms (95%), errors: 0.00, reconnects:  0.00
[1108s] threads: 64, tps: 1468.06, reads: 20515.85, writes: 5863.24, response time: 61.36ms (95%), errors: 0.00, reconnects:  0.00
[1109s] threads: 64, tps: 1513.00, reads: 21217.99, writes: 6072.00, response time: 56.58ms (95%), errors: 0.00, reconnects:  0.00
[1110s] threads: 64, tps: 1550.00, reads: 21608.00, writes: 6177.00, response time: 56.46ms (95%), errors: 0.00, reconnects:  0.00
[1111s] threads: 64, tps: 1571.00, reads: 22020.02, writes: 6332.01, response time: 55.73ms (95%), errors: 0.00, reconnects:  0.00
[1112s] threads: 64, tps: 1688.00, reads: 23617.97, writes: 6742.99, response time: 52.62ms (95%), errors: 0.00, reconnects:  0.00
[1113s] threads: 64, tps: 1700.00, reads: 23773.02, writes: 6776.01, response time: 53.42ms (95%), errors: 0.00, reconnects:  0.00
[1114s] threads: 64, tps: 1737.00, reads: 24463.01, writes: 7038.00, response time: 51.27ms (95%), errors: 0.00, reconnects:  0.00
[1115s] threads: 64, tps: 1738.00, reads: 24383.98, writes: 6993.99, response time: 52.12ms (95%), errors: 0.00, reconnects:  0.00
[1116s] threads: 64, tps: 1725.00, reads: 23927.97, writes: 6797.99, response time: 53.82ms (95%), errors: 0.00, reconnects:  0.00
[1117s] threads: 64, tps: 1789.00, reads: 25075.02, writes: 7153.00, response time: 49.18ms (95%), errors: 0.00, reconnects:  0.00
[1118s] threads: 64, tps: 1680.00, reads: 23644.97, writes: 6814.99, response time: 54.69ms (95%), errors: 0.00, reconnects:  0.00
[1119s] threads: 64, tps: 1762.00, reads: 24611.02, writes: 6995.01, response time: 51.87ms (95%), errors: 0.00, reconnects:  0.00
[1120s] threads: 64, tps: 1735.00, reads: 24273.99, writes: 6914.00, response time: 52.31ms (95%), errors: 0.00, reconnects:  0.00
[1121s] threads: 64, tps: 1640.00, reads: 23149.04, writes: 6737.01, response time: 53.21ms (95%), errors: 0.00, reconnects:  0.00
[1122s] threads: 64, tps: 1683.98, reads: 23472.75, writes: 6599.93, response time: 54.56ms (95%), errors: 0.00, reconnects:  0.00
[1123s] threads: 64, tps: 1780.02, reads: 24753.26, writes: 7029.07, response time: 50.78ms (95%), errors: 0.00, reconnects:  0.00
[1124s] threads: 64, tps: 1673.00, reads: 23512.96, writes: 6743.99, response time: 54.12ms (95%), errors: 0.00, reconnects:  0.00
[1125s] threads: 64, tps: 1754.96, reads: 24566.49, writes: 6982.86, response time: 51.02ms (95%), errors: 0.00, reconnects:  0.00
[1126s] threads: 64, tps: 1619.04, reads: 22722.51, writes: 6611.15, response time: 56.78ms (95%), errors: 0.00, reconnects:  0.00
[1127s] threads: 64, tps: 1617.00, reads: 22554.00, writes: 6307.00, response time: 57.70ms (95%), errors: 0.00, reconnects:  0.00
[1128s] threads: 64, tps: 1712.00, reads: 23931.98, writes: 6872.00, response time: 52.10ms (95%), errors: 0.00, reconnects:  0.00
[1129s] threads: 64, tps: 1769.00, reads: 24793.03, writes: 7064.01, response time: 54.01ms (95%), errors: 0.00, reconnects:  0.00
[1130s] threads: 64, tps: 1762.00, reads: 24721.97, writes: 7136.99, response time: 51.24ms (95%), errors: 0.00, reconnects:  0.00
[1131s] threads: 64, tps: 1789.00, reads: 24848.98, writes: 7059.00, response time: 53.46ms (95%), errors: 0.00, reconnects:  0.00
[1132s] threads: 64, tps: 2028.00, reads: 28660.97, writes: 8219.99, response time: 45.19ms (95%), errors: 0.00, reconnects:  0.00
[1133s] threads: 64, tps: 2092.00, reads: 29233.04, writes: 8374.01, response time: 45.28ms (95%), errors: 0.00, reconnects:  0.00
[1134s] threads: 64, tps: 2052.00, reads: 28637.99, writes: 8145.00, response time: 44.86ms (95%), errors: 0.00, reconnects:  0.00
[1135s] threads: 64, tps: 2323.00, reads: 32561.02, writes: 9264.01, response time: 41.43ms (95%), errors: 0.00, reconnects:  0.00
[1136s] threads: 64, tps: 2478.00, reads: 34593.02, writes: 9924.01, response time: 38.58ms (95%), errors: 0.00, reconnects:  0.00
[1137s] threads: 64, tps: 2427.99, reads: 34169.87, writes: 9753.96, response time: 40.87ms (95%), errors: 0.00, reconnects:  0.00
[1138s] threads: 64, tps: 2395.01, reads: 33451.12, writes: 9591.04, response time: 40.84ms (95%), errors: 0.00, reconnects:  0.00
[1139s] threads: 64, tps: 2500.00, reads: 34924.96, writes: 9973.99, response time: 39.03ms (95%), errors: 0.00, reconnects:  0.00
[1140s] threads: 64, tps: 2384.00, reads: 33504.00, writes: 9585.00, response time: 40.62ms (95%), errors: 0.00, reconnects:  0.00
[1141s] threads: 64, tps: 2409.00, reads: 33565.03, writes: 9561.01, response time: 41.45ms (95%), errors: 0.00, reconnects:  0.00
[1142s] threads: 64, tps: 2415.00, reads: 33990.98, writes: 9740.99, response time: 40.63ms (95%), errors: 0.00, reconnects:  0.00
[1143s] threads: 64, tps: 2376.00, reads: 33235.05, writes: 9439.01, response time: 40.50ms (95%), errors: 0.00, reconnects:  0.00
[1144s] threads: 64, tps: 2287.00, reads: 31994.96, writes: 9180.99, response time: 43.53ms (95%), errors: 0.00, reconnects:  0.00
[1145s] threads: 64, tps: 2244.00, reads: 31366.01, writes: 8997.00, response time: 43.47ms (95%), errors: 0.00, reconnects:  0.00
[1146s] threads: 64, tps: 2185.00, reads: 30570.02, writes: 8703.01, response time: 45.70ms (95%), errors: 0.00, reconnects:  0.00
[1147s] threads: 64, tps: 1847.00, reads: 25910.99, writes: 7356.00, response time: 53.06ms (95%), errors: 0.00, reconnects:  0.00
[1148s] threads: 64, tps: 2000.00, reads: 28057.96, writes: 8014.99, response time: 49.70ms (95%), errors: 0.00, reconnects:  0.00
[1149s] threads: 64, tps: 2127.00, reads: 29722.05, writes: 8504.01, response time: 44.21ms (95%), errors: 0.00, reconnects:  0.00
[1150s] threads: 64, tps: 2129.00, reads: 29965.96, writes: 8625.99, response time: 44.58ms (95%), errors: 0.00, reconnects:  0.00
[1151s] threads: 64, tps: 2252.97, reads: 31501.54, writes: 8954.87, response time: 43.16ms (95%), errors: 0.00, reconnects:  0.00
[1152s] threads: 64, tps: 2246.03, reads: 31377.48, writes: 8965.14, response time: 43.50ms (95%), errors: 0.00, reconnects:  0.00
[1153s] threads: 64, tps: 2326.95, reads: 32625.24, writes: 9363.78, response time: 40.92ms (95%), errors: 0.00, reconnects:  0.00
[1154s] threads: 64, tps: 2313.06, reads: 32378.78, writes: 9210.22, response time: 41.53ms (95%), errors: 0.00, reconnects:  0.00
[1155s] threads: 64, tps: 2330.00, reads: 32450.95, writes: 9273.99, response time: 40.27ms (95%), errors: 0.00, reconnects:  0.00
[1156s] threads: 64, tps: 2269.00, reads: 31881.06, writes: 9103.02, response time: 42.79ms (95%), errors: 0.00, reconnects:  0.00
[1157s] threads: 64, tps: 2336.00, reads: 32692.99, writes: 9359.00, response time: 41.42ms (95%), errors: 0.00, reconnects:  0.00
[1158s] threads: 64, tps: 2399.00, reads: 33567.00, writes: 9588.00, response time: 40.04ms (95%), errors: 0.00, reconnects:  0.00
[1159s] threads: 64, tps: 2277.00, reads: 31762.98, writes: 9029.99, response time: 41.03ms (95%), errors: 0.00, reconnects:  0.00
[1160s] threads: 64, tps: 2129.00, reads: 29949.97, writes: 8580.99, response time: 45.42ms (95%), errors: 0.00, reconnects:  0.00
[1161s] threads: 64, tps: 2249.00, reads: 31422.02, writes: 8941.01, response time: 41.90ms (95%), errors: 0.00, reconnects:  0.00
[1162s] threads: 64, tps: 2091.99, reads: 29443.89, writes: 8528.97, response time: 45.98ms (95%), errors: 0.00, reconnects:  0.00
[1163s] threads: 64, tps: 2065.01, reads: 28598.12, writes: 8111.03, response time: 48.71ms (95%), errors: 0.00, reconnects:  0.00
[1164s] threads: 64, tps: 2079.00, reads: 29190.00, writes: 8365.00, response time: 43.59ms (95%), errors: 0.00, reconnects:  0.00
[1165s] threads: 64, tps: 2197.00, reads: 30868.04, writes: 8731.01, response time: 43.14ms (95%), errors: 0.00, reconnects:  0.00
[1166s] threads: 64, tps: 1766.00, reads: 24746.94, writes: 7067.98, response time: 58.36ms (95%), errors: 0.00, reconnects:  0.00
[1167s] threads: 64, tps: 1731.00, reads: 24259.01, writes: 6979.00, response time: 56.49ms (95%), errors: 0.00, reconnects:  0.00
[1168s] threads: 64, tps: 1449.99, reads: 20260.93, writes: 5751.98, response time: 69.97ms (95%), errors: 0.00, reconnects:  0.00
[1169s] threads: 64, tps: 1398.01, reads: 19455.08, writes: 5561.02, response time: 66.48ms (95%), errors: 0.00, reconnects:  0.00
[1170s] threads: 64, tps: 1570.00, reads: 22031.98, writes: 6298.99, response time: 60.26ms (95%), errors: 0.00, reconnects:  0.00
[1171s] threads: 64, tps: 1733.00, reads: 24340.03, writes: 6939.01, response time: 52.07ms (95%), errors: 0.00, reconnects:  0.00
[1172s] threads: 64, tps: 1661.00, reads: 23197.99, writes: 6667.00, response time: 56.22ms (95%), errors: 0.00, reconnects:  0.00
[1173s] threads: 64, tps: 1792.00, reads: 25120.96, writes: 7186.99, response time: 49.86ms (95%), errors: 0.00, reconnects:  0.00
[1174s] threads: 64, tps: 1807.00, reads: 25282.06, writes: 7273.02, response time: 50.22ms (95%), errors: 0.00, reconnects:  0.00
[1175s] threads: 64, tps: 1733.96, reads: 24238.47, writes: 6916.85, response time: 53.61ms (95%), errors: 0.00, reconnects:  0.00
[1176s] threads: 64, tps: 1858.04, reads: 25926.53, writes: 7349.15, response time: 48.32ms (95%), errors: 0.00, reconnects:  0.00
[1177s] threads: 64, tps: 1896.72, reads: 26712.10, writes: 7690.88, response time: 47.72ms (95%), errors: 0.00, reconnects:  0.00
[1178s] threads: 64, tps: 1927.28, reads: 27007.93, writes: 7704.12, response time: 46.16ms (95%), errors: 0.00, reconnects:  0.00
[1179s] threads: 64, tps: 1908.00, reads: 26687.01, writes: 7609.00, response time: 46.60ms (95%), errors: 0.00, reconnects:  0.00
[1180s] threads: 64, tps: 1850.00, reads: 25839.95, writes: 7374.99, response time: 48.89ms (95%), errors: 0.00, reconnects:  0.00
[1181s] threads: 64, tps: 1821.00, reads: 25563.00, writes: 7322.00, response time: 48.78ms (95%), errors: 0.00, reconnects:  0.00
[1182s] threads: 64, tps: 1840.00, reads: 25659.05, writes: 7360.01, response time: 50.80ms (95%), errors: 0.00, reconnects:  0.00
[1183s] threads: 64, tps: 1832.00, reads: 25643.99, writes: 7274.00, response time: 49.94ms (95%), errors: 0.00, reconnects:  0.00
[1184s] threads: 64, tps: 1686.00, reads: 23590.99, writes: 6739.00, response time: 57.86ms (95%), errors: 0.00, reconnects:  0.00
[1185s] threads: 64, tps: 1784.00, reads: 25059.00, writes: 7152.00, response time: 50.10ms (95%), errors: 0.00, reconnects:  0.00
[1186s] threads: 64, tps: 1783.00, reads: 24961.98, writes: 7140.99, response time: 50.60ms (95%), errors: 0.00, reconnects:  0.00
[1187s] threads: 64, tps: 1816.00, reads: 25367.01, writes: 7262.00, response time: 50.60ms (95%), errors: 0.00, reconnects:  0.00
[1188s] threads: 64, tps: 1717.00, reads: 24061.07, writes: 6869.02, response time: 51.24ms (95%), errors: 0.00, reconnects:  0.00
[1189s] threads: 64, tps: 1682.00, reads: 23590.96, writes: 6679.99, response time: 54.73ms (95%), errors: 0.00, reconnects:  0.00
[1190s] threads: 64, tps: 1554.00, reads: 21697.02, writes: 6213.00, response time: 58.52ms (95%), errors: 0.00, reconnects:  0.00
[1191s] threads: 64, tps: 1616.00, reads: 22636.99, writes: 6460.00, response time: 55.39ms (95%), errors: 0.00, reconnects:  0.00
[1192s] threads: 64, tps: 1588.00, reads: 22214.97, writes: 6348.99, response time: 54.32ms (95%), errors: 0.00, reconnects:  0.00
[1193s] threads: 64, tps: 1601.00, reads: 22415.02, writes: 6427.01, response time: 54.19ms (95%), errors: 0.00, reconnects:  0.00
[1194s] threads: 64, tps: 1640.00, reads: 22989.97, writes: 6596.99, response time: 55.95ms (95%), errors: 0.00, reconnects:  0.00
[1195s] threads: 64, tps: 1705.00, reads: 23890.02, writes: 6849.01, response time: 53.42ms (95%), errors: 0.00, reconnects:  0.00
[1196s] threads: 64, tps: 1616.00, reads: 22637.01, writes: 6447.00, response time: 56.81ms (95%), errors: 0.00, reconnects:  0.00
[1197s] threads: 64, tps: 1525.00, reads: 21325.97, writes: 6061.99, response time: 60.48ms (95%), errors: 0.00, reconnects:  0.00
[1198s] threads: 64, tps: 1544.00, reads: 21647.04, writes: 6194.01, response time: 62.43ms (95%), errors: 0.00, reconnects:  0.00
[1199s] threads: 64, tps: 1503.00, reads: 21107.99, writes: 6120.00, response time: 64.48ms (95%), errors: 0.00, reconnects:  0.00
[1200s] threads: 64, tps: 1610.00, reads: 22476.00, writes: 6351.00, response time: 58.96ms (95%), errors: 0.00, reconnects:  0.00
[1201s] threads: 64, tps: 1757.00, reads: 24533.03, writes: 7042.01, response time: 54.12ms (95%), errors: 0.00, reconnects:  0.00
[1202s] threads: 64, tps: 1866.00, reads: 26164.96, writes: 7454.99, response time: 48.49ms (95%), errors: 0.00, reconnects:  0.00
[1203s] threads: 64, tps: 1798.00, reads: 25112.00, writes: 7124.00, response time: 50.49ms (95%), errors: 0.00, reconnects:  0.00
[1204s] threads: 64, tps: 1776.00, reads: 24976.98, writes: 7180.99, response time: 50.25ms (95%), errors: 0.00, reconnects:  0.00
[1205s] threads: 64, tps: 1796.00, reads: 25022.03, writes: 7096.01, response time: 52.45ms (95%), errors: 0.00, reconnects:  0.00
[1206s] threads: 64, tps: 1591.00, reads: 22350.95, writes: 6427.99, response time: 58.00ms (95%), errors: 0.00, reconnects:  0.00
[1207s] threads: 64, tps: 1864.00, reads: 26128.04, writes: 7508.01, response time: 48.36ms (95%), errors: 0.00, reconnects:  0.00
[1208s] threads: 64, tps: 1829.00, reads: 25545.02, writes: 7242.01, response time: 48.84ms (95%), errors: 0.00, reconnects:  0.00
[1209s] threads: 64, tps: 1824.00, reads: 25570.99, writes: 7293.00, response time: 49.73ms (95%), errors: 0.00, reconnects:  0.00
[1210s] threads: 64, tps: 1868.00, reads: 26171.99, writes: 7478.00, response time: 47.46ms (95%), errors: 0.00, reconnects:  0.00
[1211s] threads: 64, tps: 1841.00, reads: 25837.02, writes: 7422.01, response time: 47.37ms (95%), errors: 0.00, reconnects:  0.00
[1212s] threads: 64, tps: 1766.00, reads: 24641.99, writes: 6973.00, response time: 49.65ms (95%), errors: 0.00, reconnects:  0.00
[1213s] threads: 64, tps: 1639.00, reads: 23035.00, writes: 6635.00, response time: 52.53ms (95%), errors: 0.00, reconnects:  0.00
[1214s] threads: 64, tps: 1497.00, reads: 20894.03, writes: 5904.01, response time: 61.69ms (95%), errors: 0.00, reconnects:  0.00
[1215s] threads: 64, tps: 1564.00, reads: 21810.96, writes: 6244.99, response time: 56.29ms (95%), errors: 0.00, reconnects:  0.00
[1216s] threads: 64, tps: 1609.00, reads: 22615.01, writes: 6447.00, response time: 53.54ms (95%), errors: 0.00, reconnects:  0.00
[1217s] threads: 64, tps: 1659.00, reads: 23220.97, writes: 6689.99, response time: 52.54ms (95%), errors: 0.00, reconnects:  0.00
[1218s] threads: 64, tps: 1737.00, reads: 24285.06, writes: 6953.02, response time: 51.48ms (95%), errors: 0.00, reconnects:  0.00
[1219s] threads: 64, tps: 1876.00, reads: 26143.95, writes: 7456.99, response time: 48.84ms (95%), errors: 0.00, reconnects:  0.00
[1220s] threads: 64, tps: 1760.00, reads: 24774.01, writes: 7077.00, response time: 50.37ms (95%), errors: 0.00, reconnects:  0.00
[1221s] threads: 64, tps: 1856.99, reads: 25805.83, writes: 7367.95, response time: 48.99ms (95%), errors: 0.00, reconnects:  0.00
[1222s] threads: 64, tps: 1833.01, reads: 25903.08, writes: 7452.02, response time: 47.57ms (95%), errors: 0.00, reconnects:  0.00
[1223s] threads: 64, tps: 1878.01, reads: 26208.11, writes: 7481.03, response time: 46.54ms (95%), errors: 0.00, reconnects:  0.00
[1224s] threads: 64, tps: 1888.00, reads: 26363.96, writes: 7533.99, response time: 47.63ms (95%), errors: 0.00, reconnects:  0.00
[1225s] threads: 64, tps: 1926.85, reads: 26967.87, writes: 7666.40, response time: 45.92ms (95%), errors: 0.00, reconnects:  0.00
[1226s] threads: 64, tps: 1827.15, reads: 25659.07, writes: 7378.60, response time: 47.67ms (95%), errors: 0.00, reconnects:  0.00
[1227s] threads: 64, tps: 1865.00, reads: 26219.98, writes: 7479.99, response time: 46.88ms (95%), errors: 0.00, reconnects:  0.00
[1228s] threads: 64, tps: 1872.00, reads: 26172.03, writes: 7451.01, response time: 48.71ms (95%), errors: 0.00, reconnects:  0.00
[1229s] threads: 64, tps: 1856.00, reads: 25900.99, writes: 7428.00, response time: 48.35ms (95%), errors: 0.00, reconnects:  0.00
[1230s] threads: 64, tps: 1941.99, reads: 27102.92, writes: 7727.98, response time: 45.40ms (95%), errors: 0.00, reconnects:  0.00
[1231s] threads: 64, tps: 1887.97, reads: 26550.53, writes: 7579.87, response time: 46.41ms (95%), errors: 0.00, reconnects:  0.00
[1232s] threads: 64, tps: 1780.04, reads: 24857.52, writes: 7056.15, response time: 50.73ms (95%), errors: 0.00, reconnects:  0.00
[1233s] threads: 64, tps: 1712.00, reads: 24020.98, writes: 6861.99, response time: 51.41ms (95%), errors: 0.00, reconnects:  0.00
[1234s] threads: 64, tps: 1495.00, reads: 21070.00, writes: 6091.00, response time: 60.35ms (95%), errors: 0.00, reconnects:  0.00
[1235s] threads: 64, tps: 1580.00, reads: 21969.00, writes: 6188.00, response time: 59.81ms (95%), errors: 0.00, reconnects:  0.00
[1236s] threads: 64, tps: 1544.00, reads: 21552.99, writes: 6179.00, response time: 54.94ms (95%), errors: 0.00, reconnects:  0.00
[1237s] threads: 64, tps: 1555.00, reads: 21738.00, writes: 6218.00, response time: 56.22ms (95%), errors: 0.00, reconnects:  0.00
[1238s] threads: 64, tps: 1604.00, reads: 22478.02, writes: 6459.00, response time: 55.65ms (95%), errors: 0.00, reconnects:  0.00
[1239s] threads: 64, tps: 1699.00, reads: 23932.97, writes: 6849.99, response time: 50.61ms (95%), errors: 0.00, reconnects:  0.00
[1240s] threads: 64, tps: 1750.00, reads: 24446.01, writes: 6975.00, response time: 51.90ms (95%), errors: 0.00, reconnects:  0.00
[1241s] threads: 64, tps: 1883.00, reads: 26333.00, writes: 7497.00, response time: 46.63ms (95%), errors: 0.00, reconnects:  0.00
[1242s] threads: 64, tps: 1895.00, reads: 26455.01, writes: 7602.00, response time: 47.39ms (95%), errors: 0.00, reconnects:  0.00
[1243s] threads: 64, tps: 1819.00, reads: 25640.00, writes: 7299.00, response time: 50.07ms (95%), errors: 0.00, reconnects:  0.00
[1244s] threads: 64, tps: 1769.00, reads: 24742.97, writes: 7066.99, response time: 50.55ms (95%), errors: 0.00, reconnects:  0.00
[1245s] threads: 64, tps: 1548.60, reads: 21617.50, writes: 6162.44, response time: 57.62ms (95%), errors: 0.00, reconnects:  0.00
[1246s] threads: 64, tps: 1721.56, reads: 24034.72, writes: 6858.20, response time: 53.98ms (95%), errors: 0.00, reconnects:  0.00
[1247s] threads: 64, tps: 1789.00, reads: 25114.00, writes: 7182.00, response time: 53.22ms (95%), errors: 0.00, reconnects:  0.00
[1248s] threads: 64, tps: 1760.00, reads: 24641.97, writes: 7008.99, response time: 50.75ms (95%), errors: 0.00, reconnects:  0.00
[1249s] threads: 64, tps: 1720.00, reads: 24079.00, writes: 6886.00, response time: 53.30ms (95%), errors: 0.00, reconnects:  0.00
[1250s] threads: 64, tps: 1679.00, reads: 23562.98, writes: 6764.00, response time: 52.81ms (95%), errors: 0.00, reconnects:  0.00
[1251s] threads: 64, tps: 1669.00, reads: 23280.03, writes: 6645.01, response time: 54.55ms (95%), errors: 0.00, reconnects:  0.00
[1252s] threads: 64, tps: 1693.00, reads: 23732.02, writes: 6832.01, response time: 52.69ms (95%), errors: 0.00, reconnects:  0.00
[1253s] threads: 64, tps: 1876.97, reads: 26295.55, writes: 7470.87, response time: 47.47ms (95%), errors: 0.00, reconnects:  0.00
[1254s] threads: 64, tps: 1639.03, reads: 22837.36, writes: 6512.10, response time: 53.70ms (95%), errors: 0.00, reconnects:  0.00
[1255s] threads: 64, tps: 1584.00, reads: 22194.00, writes: 6314.00, response time: 59.39ms (95%), errors: 0.00, reconnects:  0.00
[1256s] threads: 64, tps: 1543.97, reads: 21758.60, writes: 6330.88, response time: 60.48ms (95%), errors: 0.00, reconnects:  0.00
[1257s] threads: 64, tps: 1659.03, reads: 23180.44, writes: 6486.12, response time: 54.53ms (95%), errors: 0.00, reconnects:  0.00
[1258s] threads: 64, tps: 1741.00, reads: 24334.95, writes: 6974.99, response time: 53.22ms (95%), errors: 0.00, reconnects:  0.00
[1259s] threads: 64, tps: 1813.00, reads: 25310.03, writes: 7260.01, response time: 50.13ms (95%), errors: 0.00, reconnects:  0.00
[1260s] threads: 64, tps: 1704.00, reads: 23923.99, writes: 6853.00, response time: 51.45ms (95%), errors: 0.00, reconnects:  0.00
[1261s] threads: 64, tps: 1813.00, reads: 25451.03, writes: 7260.01, response time: 49.74ms (95%), errors: 0.00, reconnects:  0.00
[1262s] threads: 64, tps: 1877.00, reads: 26138.97, writes: 7456.99, response time: 48.36ms (95%), errors: 0.00, reconnects:  0.00
[1263s] threads: 64, tps: 1956.00, reads: 27353.00, writes: 7855.00, response time: 47.37ms (95%), errors: 0.00, reconnects:  0.00
[1264s] threads: 64, tps: 1827.00, reads: 25692.98, writes: 7310.00, response time: 52.20ms (95%), errors: 0.00, reconnects:  0.00
[1265s] threads: 64, tps: 2100.00, reads: 29436.06, writes: 8434.02, response time: 43.98ms (95%), errors: 0.00, reconnects:  0.00
[1266s] threads: 64, tps: 2129.00, reads: 29714.98, writes: 8467.99, response time: 45.95ms (95%), errors: 0.00, reconnects:  0.00
[1267s] threads: 64, tps: 2035.00, reads: 28589.98, writes: 8178.00, response time: 47.46ms (95%), errors: 0.00, reconnects:  0.00
[1268s] threads: 64, tps: 2072.00, reads: 28939.00, writes: 8243.00, response time: 46.53ms (95%), errors: 0.00, reconnects:  0.00
[1269s] threads: 64, tps: 2166.00, reads: 30260.01, writes: 8644.00, response time: 43.89ms (95%), errors: 0.00, reconnects:  0.00
[1270s] threads: 64, tps: 2079.00, reads: 29193.01, writes: 8409.00, response time: 45.04ms (95%), errors: 0.00, reconnects:  0.00
[1271s] threads: 64, tps: 2172.00, reads: 30496.99, writes: 8719.00, response time: 43.70ms (95%), errors: 0.00, reconnects:  0.00
[1272s] threads: 64, tps: 2146.00, reads: 29906.99, writes: 8509.00, response time: 45.25ms (95%), errors: 0.00, reconnects:  0.00
[1273s] threads: 64, tps: 2218.00, reads: 31190.02, writes: 8933.01, response time: 44.12ms (95%), errors: 0.00, reconnects:  0.00
[1274s] threads: 64, tps: 2259.00, reads: 31555.98, writes: 8998.99, response time: 42.96ms (95%), errors: 0.00, reconnects:  0.00
[1275s] threads: 64, tps: 2359.00, reads: 32968.02, writes: 9401.00, response time: 42.29ms (95%), errors: 0.00, reconnects:  0.00
[1276s] threads: 64, tps: 2304.00, reads: 32325.97, writes: 9245.99, response time: 42.69ms (95%), errors: 0.00, reconnects:  0.00
[1277s] threads: 64, tps: 2226.00, reads: 31217.06, writes: 8929.02, response time: 45.46ms (95%), errors: 0.00, reconnects:  0.00
[1278s] threads: 64, tps: 2181.94, reads: 30486.23, writes: 8685.78, response time: 47.64ms (95%), errors: 0.00, reconnects:  0.00
[1279s] threads: 64, tps: 2183.05, reads: 30543.72, writes: 8716.21, response time: 44.24ms (95%), errors: 0.00, reconnects:  0.00
[1280s] threads: 64, tps: 2349.00, reads: 32843.00, writes: 9367.00, response time: 43.53ms (95%), errors: 0.00, reconnects:  0.00
[1281s] threads: 64, tps: 2469.97, reads: 34634.59, writes: 9935.88, response time: 40.70ms (95%), errors: 0.00, reconnects:  0.00
[1282s] threads: 64, tps: 2428.02, reads: 33933.24, writes: 9651.07, response time: 42.89ms (95%), errors: 0.00, reconnects:  0.00
[1283s] threads: 64, tps: 2523.01, reads: 35324.13, writes: 10125.04, response time: 39.18ms (95%), errors: 0.00, reconnects:  0.00
[1284s] threads: 64, tps: 2524.01, reads: 35375.08, writes: 10106.02, response time: 38.57ms (95%), errors: 0.00, reconnects:  0.00
[1285s] threads: 64, tps: 2416.99, reads: 33823.92, writes: 9679.98, response time: 39.44ms (95%), errors: 0.00, reconnects:  0.00
[1286s] threads: 64, tps: 2402.01, reads: 33594.07, writes: 9625.02, response time: 39.70ms (95%), errors: 0.00, reconnects:  0.00
[1287s] threads: 64, tps: 2454.00, reads: 34504.01, writes: 9854.00, response time: 39.09ms (95%), errors: 0.00, reconnects:  0.00
[1288s] threads: 64, tps: 2456.00, reads: 34260.98, writes: 9747.00, response time: 39.49ms (95%), errors: 0.00, reconnects:  0.00
[1289s] threads: 64, tps: 2450.00, reads: 34235.98, writes: 9779.00, response time: 38.46ms (95%), errors: 0.00, reconnects:  0.00
[1290s] threads: 64, tps: 2395.00, reads: 33545.99, writes: 9588.00, response time: 40.01ms (95%), errors: 0.00, reconnects:  0.00
[1291s] threads: 64, tps: 2386.00, reads: 33484.03, writes: 9572.01, response time: 40.80ms (95%), errors: 0.00, reconnects:  0.00
[1292s] threads: 64, tps: 2282.00, reads: 31993.99, writes: 9140.00, response time: 43.10ms (95%), errors: 0.00, reconnects:  0.00
[1293s] threads: 64, tps: 2222.99, reads: 31245.87, writes: 9004.96, response time: 44.01ms (95%), errors: 0.00, reconnects:  0.00
[1294s] threads: 64, tps: 2189.01, reads: 30507.17, writes: 8612.05, response time: 45.25ms (95%), errors: 0.00, reconnects:  0.00
[1295s] threads: 64, tps: 2133.00, reads: 29799.96, writes: 8543.99, response time: 47.49ms (95%), errors: 0.00, reconnects:  0.00
[1296s] threads: 64, tps: 2255.00, reads: 31550.98, writes: 8986.99, response time: 42.82ms (95%), errors: 0.00, reconnects:  0.00
[1297s] threads: 64, tps: 2285.00, reads: 32071.00, writes: 9245.00, response time: 40.76ms (95%), errors: 0.00, reconnects:  0.00
[1298s] threads: 64, tps: 2290.00, reads: 32104.00, writes: 9162.00, response time: 41.53ms (95%), errors: 0.00, reconnects:  0.00
[1299s] threads: 64, tps: 2200.00, reads: 30723.03, writes: 8749.01, response time: 41.64ms (95%), errors: 0.00, reconnects:  0.00
[1300s] threads: 64, tps: 2192.00, reads: 30664.96, writes: 8706.99, response time: 42.33ms (95%), errors: 0.00, reconnects:  0.00
[1301s] threads: 64, tps: 1953.00, reads: 27382.03, writes: 7917.01, response time: 48.45ms (95%), errors: 0.00, reconnects:  0.00
[1302s] threads: 64, tps: 1968.00, reads: 27491.04, writes: 7765.01, response time: 47.40ms (95%), errors: 0.00, reconnects:  0.00
[1303s] threads: 64, tps: 1872.00, reads: 26202.94, writes: 7530.98, response time: 48.45ms (95%), errors: 0.00, reconnects:  0.00
[1304s] threads: 64, tps: 1932.00, reads: 27132.03, writes: 7755.01, response time: 47.72ms (95%), errors: 0.00, reconnects:  0.00
[1305s] threads: 64, tps: 1943.00, reads: 27104.03, writes: 7739.01, response time: 48.96ms (95%), errors: 0.00, reconnects:  0.00
[1306s] threads: 64, tps: 1971.00, reads: 27597.00, writes: 7899.00, response time: 47.73ms (95%), errors: 0.00, reconnects:  0.00
[1307s] threads: 64, tps: 2138.00, reads: 29970.00, writes: 8545.00, response time: 42.85ms (95%), errors: 0.00, reconnects:  0.00
[1308s] threads: 64, tps: 2090.00, reads: 29331.94, writes: 8373.98, response time: 45.01ms (95%), errors: 0.00, reconnects:  0.00
[1309s] threads: 64, tps: 2165.00, reads: 30300.06, writes: 8681.02, response time: 43.93ms (95%), errors: 0.00, reconnects:  0.00
[1310s] threads: 64, tps: 2112.00, reads: 29351.03, writes: 8382.01, response time: 45.21ms (95%), errors: 0.00, reconnects:  0.00
[1311s] threads: 64, tps: 2040.00, reads: 28717.98, writes: 8232.99, response time: 43.92ms (95%), errors: 0.00, reconnects:  0.00
[1312s] threads: 64, tps: 2167.00, reads: 30428.99, writes: 8665.00, response time: 43.45ms (95%), errors: 0.00, reconnects:  0.00
[1313s] threads: 64, tps: 2138.00, reads: 29768.94, writes: 8483.98, response time: 43.67ms (95%), errors: 0.00, reconnects:  0.00
[1314s] threads: 64, tps: 2076.00, reads: 29052.03, writes: 8349.01, response time: 45.52ms (95%), errors: 0.00, reconnects:  0.00
[1315s] threads: 64, tps: 2165.00, reads: 30396.02, writes: 8653.01, response time: 43.12ms (95%), errors: 0.00, reconnects:  0.00
[1316s] threads: 64, tps: 2115.00, reads: 29574.98, writes: 8452.00, response time: 44.14ms (95%), errors: 0.00, reconnects:  0.00
[1317s] threads: 64, tps: 1969.00, reads: 27530.02, writes: 7891.01, response time: 47.46ms (95%), errors: 0.00, reconnects:  0.00
[1318s] threads: 64, tps: 2048.00, reads: 28661.97, writes: 8149.99, response time: 45.13ms (95%), errors: 0.00, reconnects:  0.00
[1319s] threads: 64, tps: 2073.00, reads: 29090.01, writes: 8340.00, response time: 44.71ms (95%), errors: 0.00, reconnects:  0.00
[1320s] threads: 64, tps: 2013.00, reads: 28198.01, writes: 8052.00, response time: 45.74ms (95%), errors: 0.00, reconnects:  0.00
[1321s] threads: 64, tps: 1982.00, reads: 27711.96, writes: 7895.99, response time: 46.17ms (95%), errors: 0.00, reconnects:  0.00
[1322s] threads: 64, tps: 1997.00, reads: 27997.97, writes: 7979.99, response time: 45.62ms (95%), errors: 0.00, reconnects:  0.00
[1323s] threads: 64, tps: 1936.01, reads: 27134.07, writes: 7721.02, response time: 48.84ms (95%), errors: 0.00, reconnects:  0.00
[1324s] threads: 64, tps: 1797.00, reads: 25066.00, writes: 7179.00, response time: 51.10ms (95%), errors: 0.00, reconnects:  0.00
[1325s] threads: 64, tps: 1802.00, reads: 25289.96, writes: 7233.99, response time: 50.54ms (95%), errors: 0.00, reconnects:  0.00
[1326s] threads: 64, tps: 1750.00, reads: 24563.98, writes: 7047.00, response time: 52.35ms (95%), errors: 0.00, reconnects:  0.00
[1327s] threads: 64, tps: 1872.99, reads: 26193.83, writes: 7492.95, response time: 48.71ms (95%), errors: 0.00, reconnects:  0.00
[1328s] threads: 64, tps: 2081.02, reads: 29075.23, writes: 8295.07, response time: 44.27ms (95%), errors: 0.00, reconnects:  0.00
[1329s] threads: 64, tps: 1982.00, reads: 27887.98, writes: 7994.99, response time: 46.52ms (95%), errors: 0.00, reconnects:  0.00
[1330s] threads: 64, tps: 2067.00, reads: 28653.00, writes: 8202.00, response time: 45.46ms (95%), errors: 0.00, reconnects:  0.00
[1331s] threads: 64, tps: 2076.00, reads: 29174.99, writes: 8306.00, response time: 45.00ms (95%), errors: 0.00, reconnects:  0.00
[1332s] threads: 64, tps: 2050.00, reads: 28757.02, writes: 8234.01, response time: 45.52ms (95%), errors: 0.00, reconnects:  0.00
[1333s] threads: 64, tps: 2090.00, reads: 29234.97, writes: 8353.99, response time: 44.24ms (95%), errors: 0.00, reconnects:  0.00
[1334s] threads: 64, tps: 2079.00, reads: 29065.05, writes: 8276.01, response time: 44.47ms (95%), errors: 0.00, reconnects:  0.00
[1335s] threads: 64, tps: 2034.97, reads: 28602.58, writes: 8215.88, response time: 44.77ms (95%), errors: 0.00, reconnects:  0.00
[1336s] threads: 64, tps: 2024.03, reads: 28322.36, writes: 8041.10, response time: 45.73ms (95%), errors: 0.00, reconnects:  0.00
[1337s] threads: 64, tps: 2062.00, reads: 28798.03, writes: 8221.01, response time: 45.46ms (95%), errors: 0.00, reconnects:  0.00
[1338s] threads: 64, tps: 2032.00, reads: 28449.01, writes: 8168.00, response time: 46.03ms (95%), errors: 0.00, reconnects:  0.00
[1339s] threads: 64, tps: 1897.00, reads: 26533.96, writes: 7570.99, response time: 47.76ms (95%), errors: 0.00, reconnects:  0.00
[1340s] threads: 64, tps: 1921.00, reads: 26876.01, writes: 7669.00, response time: 49.24ms (95%), errors: 0.00, reconnects:  0.00
[1341s] threads: 64, tps: 1903.00, reads: 26788.01, writes: 7633.00, response time: 49.40ms (95%), errors: 0.00, reconnects:  0.00
[1342s] threads: 64, tps: 1999.00, reads: 27936.98, writes: 8020.00, response time: 46.41ms (95%), errors: 0.00, reconnects:  0.00
[1343s] threads: 64, tps: 1843.99, reads: 25782.90, writes: 7375.97, response time: 50.93ms (95%), errors: 0.00, reconnects:  0.00
[1344s] threads: 64, tps: 1735.01, reads: 24312.13, writes: 6867.04, response time: 55.17ms (95%), errors: 0.00, reconnects:  0.00
[1345s] threads: 64, tps: 1650.00, reads: 23105.00, writes: 6621.00, response time: 56.73ms (95%), errors: 0.00, reconnects:  0.00
[1346s] threads: 64, tps: 1847.00, reads: 25812.96, writes: 7360.99, response time: 50.73ms (95%), errors: 0.00, reconnects:  0.00
[1347s] threads: 64, tps: 1834.00, reads: 25752.01, writes: 7356.00, response time: 49.39ms (95%), errors: 0.00, reconnects:  0.00
[1348s] threads: 64, tps: 1836.00, reads: 25630.94, writes: 7335.98, response time: 48.70ms (95%), errors: 0.00, reconnects:  0.00
[1349s] threads: 64, tps: 1934.00, reads: 27023.05, writes: 7749.01, response time: 48.90ms (95%), errors: 0.00, reconnects:  0.00
[1350s] threads: 64, tps: 1915.00, reads: 26899.01, writes: 7669.00, response time: 45.89ms (95%), errors: 0.00, reconnects:  0.00
[1351s] threads: 64, tps: 1980.00, reads: 27801.00, writes: 8026.00, response time: 45.43ms (95%), errors: 0.00, reconnects:  0.00
[1352s] threads: 64, tps: 2023.00, reads: 28112.97, writes: 7948.99, response time: 44.39ms (95%), errors: 0.00, reconnects:  0.00
[1353s] threads: 64, tps: 2013.00, reads: 28326.06, writes: 8138.02, response time: 44.14ms (95%), errors: 0.00, reconnects:  0.00
[1354s] threads: 64, tps: 2013.00, reads: 28275.97, writes: 8078.99, response time: 44.42ms (95%), errors: 0.00, reconnects:  0.00
[1355s] threads: 64, tps: 2035.36, reads: 28483.98, writes: 8157.42, response time: 44.46ms (95%), errors: 0.00, reconnects:  0.00
[1356s] threads: 64, tps: 2040.65, reads: 28508.04, writes: 8128.58, response time: 45.37ms (95%), errors: 0.00, reconnects:  0.00
[1357s] threads: 64, tps: 2051.00, reads: 28818.99, writes: 8247.00, response time: 45.00ms (95%), errors: 0.00, reconnects:  0.00
[1358s] threads: 64, tps: 2036.00, reads: 28346.03, writes: 8082.01, response time: 43.67ms (95%), errors: 0.00, reconnects:  0.00
[1359s] threads: 64, tps: 1988.00, reads: 27795.97, writes: 7881.99, response time: 43.72ms (95%), errors: 0.00, reconnects:  0.00
[1360s] threads: 64, tps: 1991.00, reads: 27839.02, writes: 7990.01, response time: 45.44ms (95%), errors: 0.00, reconnects:  0.00
[1361s] threads: 64, tps: 1880.00, reads: 26385.01, writes: 7553.00, response time: 47.32ms (95%), errors: 0.00, reconnects:  0.00
[1362s] threads: 64, tps: 1870.00, reads: 26292.97, writes: 7543.99, response time: 47.12ms (95%), errors: 0.00, reconnects:  0.00
[1363s] threads: 64, tps: 1940.98, reads: 27062.78, writes: 7710.94, response time: 48.39ms (95%), errors: 0.00, reconnects:  0.00
[1364s] threads: 64, tps: 1933.02, reads: 27052.23, writes: 7740.07, response time: 47.64ms (95%), errors: 0.00, reconnects:  0.00
[1365s] threads: 64, tps: 1910.00, reads: 26882.99, writes: 7678.00, response time: 46.73ms (95%), errors: 0.00, reconnects:  0.00
[1366s] threads: 64, tps: 1824.00, reads: 25376.01, writes: 7207.00, response time: 49.24ms (95%), errors: 0.00, reconnects:  0.00
[1367s] threads: 64, tps: 1709.00, reads: 24014.01, writes: 6865.00, response time: 56.92ms (95%), errors: 0.00, reconnects:  0.00
[1368s] threads: 64, tps: 1594.00, reads: 22252.01, writes: 6322.00, response time: 57.72ms (95%), errors: 0.00, reconnects:  0.00
[1369s] threads: 64, tps: 1670.00, reads: 23396.96, writes: 6678.99, response time: 52.42ms (95%), errors: 0.00, reconnects:  0.00
[1370s] threads: 64, tps: 1677.00, reads: 23481.01, writes: 6756.00, response time: 52.50ms (95%), errors: 0.00, reconnects:  0.00
[1371s] threads: 64, tps: 1703.00, reads: 23828.01, writes: 6812.00, response time: 52.99ms (95%), errors: 0.00, reconnects:  0.00
[1372s] threads: 64, tps: 1779.00, reads: 24892.95, writes: 7089.99, response time: 49.62ms (95%), errors: 0.00, reconnects:  0.00
[1373s] threads: 64, tps: 1921.57, reads: 26964.97, writes: 7740.27, response time: 45.80ms (95%), errors: 0.00, reconnects:  0.00
[1374s] threads: 64, tps: 1978.44, reads: 27634.21, writes: 7843.76, response time: 46.29ms (95%), errors: 0.00, reconnects:  0.00
[1375s] threads: 64, tps: 1973.00, reads: 27653.04, writes: 7950.01, response time: 45.76ms (95%), errors: 0.00, reconnects:  0.00
[1376s] threads: 64, tps: 2037.00, reads: 28506.97, writes: 8139.99, response time: 44.85ms (95%), errors: 0.00, reconnects:  0.00
[1377s] threads: 64, tps: 2028.00, reads: 28353.96, writes: 8105.99, response time: 44.33ms (95%), errors: 0.00, reconnects:  0.00
[1378s] threads: 64, tps: 1992.00, reads: 27837.04, writes: 7954.01, response time: 45.29ms (95%), errors: 0.00, reconnects:  0.00
[1379s] threads: 64, tps: 1910.00, reads: 26795.00, writes: 7610.00, response time: 47.43ms (95%), errors: 0.00, reconnects:  0.00
[1380s] threads: 64, tps: 1811.00, reads: 25353.02, writes: 7292.01, response time: 51.05ms (95%), errors: 0.00, reconnects:  0.00
[1381s] threads: 64, tps: 1772.00, reads: 24811.98, writes: 7091.99, response time: 52.39ms (95%), errors: 0.00, reconnects:  0.00
[1382s] threads: 64, tps: 1844.00, reads: 25860.04, writes: 7348.01, response time: 49.18ms (95%), errors: 0.00, reconnects:  0.00
[1383s] threads: 64, tps: 1836.00, reads: 25688.96, writes: 7315.99, response time: 49.50ms (95%), errors: 0.00, reconnects:  0.00
[1384s] threads: 64, tps: 1791.00, reads: 25108.00, writes: 7219.00, response time: 50.55ms (95%), errors: 0.00, reconnects:  0.00
[1385s] threads: 64, tps: 1813.00, reads: 25357.02, writes: 7232.01, response time: 51.50ms (95%), errors: 0.00, reconnects:  0.00
[1386s] threads: 64, tps: 1701.00, reads: 23797.97, writes: 6776.99, response time: 52.01ms (95%), errors: 0.00, reconnects:  0.00
[1387s] threads: 64, tps: 1790.00, reads: 25016.01, writes: 7170.00, response time: 51.27ms (95%), errors: 0.00, reconnects:  0.00
[1388s] threads: 64, tps: 1851.00, reads: 25975.02, writes: 7398.01, response time: 49.14ms (95%), errors: 0.00, reconnects:  0.00
[1389s] threads: 64, tps: 1738.00, reads: 24425.99, writes: 7010.00, response time: 53.13ms (95%), errors: 0.00, reconnects:  0.00
[1390s] threads: 64, tps: 1678.95, reads: 23370.24, writes: 6668.78, response time: 57.58ms (95%), errors: 0.00, reconnects:  0.00
[1391s] threads: 64, tps: 1826.06, reads: 25568.86, writes: 7290.24, response time: 50.66ms (95%), errors: 0.00, reconnects:  0.00
[1392s] threads: 64, tps: 1829.00, reads: 25636.97, writes: 7305.99, response time: 48.13ms (95%), errors: 0.00, reconnects:  0.00
[1393s] threads: 64, tps: 1735.71, reads: 24341.92, writes: 6968.83, response time: 52.86ms (95%), errors: 0.00, reconnects:  0.00
[1394s] threads: 64, tps: 1799.30, reads: 25172.22, writes: 7182.20, response time: 52.80ms (95%), errors: 0.00, reconnects:  0.00
[1395s] threads: 64, tps: 1812.18, reads: 25408.45, writes: 7302.68, response time: 51.50ms (95%), errors: 0.00, reconnects:  0.00
[1396s] threads: 64, tps: 1794.82, reads: 25133.44, writes: 7193.27, response time: 53.19ms (95%), errors: 0.00, reconnects:  0.00
[1397s] threads: 64, tps: 1755.00, reads: 24588.96, writes: 7028.99, response time: 54.99ms (95%), errors: 0.00, reconnects:  0.00
[1398s] threads: 64, tps: 1733.77, reads: 24255.74, writes: 6930.07, response time: 52.99ms (95%), errors: 0.00, reconnects:  0.00
[1399s] threads: 64, tps: 1757.24, reads: 24487.34, writes: 6999.95, response time: 53.74ms (95%), errors: 0.00, reconnects:  0.00
[1400s] threads: 64, tps: 1850.00, reads: 25953.01, writes: 7409.00, response time: 48.03ms (95%), errors: 0.00, reconnects:  0.00
[1401s] threads: 64, tps: 1985.00, reads: 27788.95, writes: 7918.98, response time: 44.63ms (95%), errors: 0.00, reconnects:  0.00
[1402s] threads: 64, tps: 1810.00, reads: 25362.07, writes: 7270.02, response time: 51.01ms (95%), errors: 0.00, reconnects:  0.00
[1403s] threads: 64, tps: 1942.00, reads: 27234.96, writes: 7792.99, response time: 46.60ms (95%), errors: 0.00, reconnects:  0.00
[1404s] threads: 64, tps: 1945.00, reads: 27159.03, writes: 7760.01, response time: 44.97ms (95%), errors: 0.00, reconnects:  0.00
[1405s] threads: 64, tps: 1896.00, reads: 26584.97, writes: 7573.99, response time: 48.06ms (95%), errors: 0.00, reconnects:  0.00
[1406s] threads: 64, tps: 1856.00, reads: 25940.00, writes: 7375.00, response time: 49.17ms (95%), errors: 0.00, reconnects:  0.00
[1407s] threads: 64, tps: 1923.00, reads: 26887.01, writes: 7740.00, response time: 48.19ms (95%), errors: 0.00, reconnects:  0.00
[1408s] threads: 64, tps: 1780.99, reads: 24957.91, writes: 7112.97, response time: 51.67ms (95%), errors: 0.00, reconnects:  0.00
[1409s] threads: 64, tps: 1659.01, reads: 23322.10, writes: 6655.03, response time: 55.15ms (95%), errors: 0.00, reconnects:  0.00
[1410s] threads: 64, tps: 1845.00, reads: 25732.00, writes: 7369.00, response time: 50.25ms (95%), errors: 0.00, reconnects:  0.00
[1411s] threads: 64, tps: 1836.00, reads: 25701.99, writes: 7331.00, response time: 50.01ms (95%), errors: 0.00, reconnects:  0.00
[1412s] threads: 64, tps: 1762.96, reads: 24821.46, writes: 7134.84, response time: 50.99ms (95%), errors: 0.00, reconnects:  0.00
[1413s] threads: 64, tps: 1684.04, reads: 23460.51, writes: 6656.14, response time: 55.80ms (95%), errors: 0.00, reconnects:  0.00
[1414s] threads: 64, tps: 1617.00, reads: 22602.95, writes: 6443.99, response time: 57.50ms (95%), errors: 0.00, reconnects:  0.00
[1415s] threads: 64, tps: 1450.00, reads: 20341.97, writes: 5825.99, response time: 64.50ms (95%), errors: 0.00, reconnects:  0.00
[1416s] threads: 64, tps: 1594.01, reads: 22397.08, writes: 6415.02, response time: 58.09ms (95%), errors: 0.00, reconnects:  0.00
[1417s] threads: 64, tps: 1376.00, reads: 19182.02, writes: 5424.01, response time: 68.11ms (95%), errors: 0.00, reconnects:  0.00
[1418s] threads: 64, tps: 1444.00, reads: 20182.99, writes: 5790.00, response time: 65.02ms (95%), errors: 0.00, reconnects:  0.00
[1419s] threads: 64, tps: 1632.00, reads: 22825.99, writes: 6509.00, response time: 57.09ms (95%), errors: 0.00, reconnects:  0.00
[1420s] threads: 64, tps: 1845.00, reads: 25733.02, writes: 7386.00, response time: 49.55ms (95%), errors: 0.00, reconnects:  0.00
[1421s] threads: 64, tps: 1923.00, reads: 26937.98, writes: 7718.99, response time: 47.12ms (95%), errors: 0.00, reconnects:  0.00
[1422s] threads: 64, tps: 1865.00, reads: 26190.01, writes: 7479.00, response time: 48.42ms (95%), errors: 0.00, reconnects:  0.00
[1423s] threads: 64, tps: 1961.00, reads: 27510.02, writes: 7814.01, response time: 45.66ms (95%), errors: 0.00, reconnects:  0.00
[1424s] threads: 64, tps: 1994.00, reads: 27812.95, writes: 7985.99, response time: 45.80ms (95%), errors: 0.00, reconnects:  0.00
[1425s] threads: 64, tps: 1988.00, reads: 27990.01, writes: 8023.00, response time: 46.27ms (95%), errors: 0.00, reconnects:  0.00
[1426s] threads: 64, tps: 2020.00, reads: 28166.99, writes: 8018.00, response time: 44.59ms (95%), errors: 0.00, reconnects:  0.00
[1427s] threads: 64, tps: 2002.00, reads: 28194.03, writes: 8086.01, response time: 45.29ms (95%), errors: 0.00, reconnects:  0.00
[1428s] threads: 64, tps: 2106.00, reads: 29353.98, writes: 8328.99, response time: 43.71ms (95%), errors: 0.00, reconnects:  0.00
[1429s] threads: 64, tps: 1939.00, reads: 27224.98, writes: 7803.99, response time: 47.59ms (95%), errors: 0.00, reconnects:  0.00
[1430s] threads: 64, tps: 1924.00, reads: 26787.04, writes: 7676.01, response time: 49.62ms (95%), errors: 0.00, reconnects:  0.00
[1431s] threads: 64, tps: 2010.00, reads: 28304.99, writes: 8071.00, response time: 46.02ms (95%), errors: 0.00, reconnects:  0.00
[1432s] threads: 64, tps: 1914.00, reads: 26634.99, writes: 7574.00, response time: 48.36ms (95%), errors: 0.00, reconnects:  0.00
[1433s] threads: 64, tps: 2155.00, reads: 30340.04, writes: 8683.01, response time: 42.23ms (95%), errors: 0.00, reconnects:  0.00
[1434s] threads: 64, tps: 2189.00, reads: 30664.98, writes: 8782.99, response time: 42.67ms (95%), errors: 0.00, reconnects:  0.00
[1435s] threads: 64, tps: 2225.00, reads: 31097.01, writes: 8920.00, response time: 42.67ms (95%), errors: 0.00, reconnects:  0.00
[1436s] threads: 64, tps: 2143.00, reads: 29985.02, writes: 8462.00, response time: 42.87ms (95%), errors: 0.00, reconnects:  0.00
[1437s] threads: 64, tps: 2139.00, reads: 29950.97, writes: 8602.99, response time: 42.90ms (95%), errors: 0.00, reconnects:  0.00
[1438s] threads: 64, tps: 2060.00, reads: 28798.98, writes: 8198.99, response time: 46.41ms (95%), errors: 0.00, reconnects:  0.00
[1439s] threads: 64, tps: 1684.07, reads: 23654.94, writes: 6769.27, response time: 56.88ms (95%), errors: 0.00, reconnects:  0.00
[1440s] threads: 64, tps: 1689.93, reads: 23585.03, writes: 6708.72, response time: 57.55ms (95%), errors: 0.00, reconnects:  0.00
[1441s] threads: 64, tps: 1894.00, reads: 26456.05, writes: 7589.02, response time: 48.04ms (95%), errors: 0.00, reconnects:  0.00
[1442s] threads: 64, tps: 1826.00, reads: 25689.98, writes: 7366.99, response time: 49.31ms (95%), errors: 0.00, reconnects:  0.00
[1443s] threads: 64, tps: 1932.00, reads: 27035.01, writes: 7735.00, response time: 47.50ms (95%), errors: 0.00, reconnects:  0.00
[1444s] threads: 64, tps: 1927.00, reads: 26825.98, writes: 7654.99, response time: 47.96ms (95%), errors: 0.00, reconnects:  0.00
[1445s] threads: 64, tps: 2028.00, reads: 28633.02, writes: 8223.01, response time: 44.93ms (95%), errors: 0.00, reconnects:  0.00
[1446s] threads: 64, tps: 2147.00, reads: 29926.99, writes: 8535.00, response time: 43.77ms (95%), errors: 0.00, reconnects:  0.00
[1447s] threads: 64, tps: 2168.00, reads: 30385.03, writes: 8701.01, response time: 44.30ms (95%), errors: 0.00, reconnects:  0.00
[1448s] threads: 64, tps: 2210.00, reads: 30996.02, writes: 8822.01, response time: 41.29ms (95%), errors: 0.00, reconnects:  0.00
[1449s] threads: 64, tps: 2228.97, reads: 31172.62, writes: 8937.89, response time: 42.04ms (95%), errors: 0.00, reconnects:  0.00
[1450s] threads: 64, tps: 2325.03, reads: 32439.36, writes: 9234.10, response time: 40.53ms (95%), errors: 0.00, reconnects:  0.00
[1451s] threads: 64, tps: 2312.98, reads: 32345.74, writes: 9262.93, response time: 40.00ms (95%), errors: 0.00, reconnects:  0.00
[1452s] threads: 64, tps: 2221.02, reads: 31136.28, writes: 8887.08, response time: 43.91ms (95%), errors: 0.00, reconnects:  0.00
[1453s] threads: 64, tps: 2131.00, reads: 29880.97, writes: 8524.99, response time: 43.85ms (95%), errors: 0.00, reconnects:  0.00
[1454s] threads: 64, tps: 2237.00, reads: 31229.00, writes: 8939.00, response time: 40.97ms (95%), errors: 0.00, reconnects:  0.00
[1455s] threads: 64, tps: 2209.00, reads: 31051.97, writes: 8868.99, response time: 42.09ms (95%), errors: 0.00, reconnects:  0.00
[1456s] threads: 64, tps: 2083.00, reads: 29060.04, writes: 8287.01, response time: 44.85ms (95%), errors: 0.00, reconnects:  0.00
[1457s] threads: 64, tps: 2054.00, reads: 28879.04, writes: 8244.01, response time: 45.04ms (95%), errors: 0.00, reconnects:  0.00
[1458s] threads: 64, tps: 1956.00, reads: 27366.95, writes: 7851.99, response time: 48.61ms (95%), errors: 0.00, reconnects:  0.00
[1459s] threads: 64, tps: 1990.99, reads: 27812.89, writes: 7924.97, response time: 48.71ms (95%), errors: 0.00, reconnects:  0.00
[1460s] threads: 64, tps: 1973.01, reads: 27652.14, writes: 7903.04, response time: 49.68ms (95%), errors: 0.00, reconnects:  0.00
[1461s] threads: 64, tps: 1913.00, reads: 26676.95, writes: 7576.99, response time: 48.62ms (95%), errors: 0.00, reconnects:  0.00
[1462s] threads: 64, tps: 1949.00, reads: 27275.00, writes: 7817.00, response time: 46.82ms (95%), errors: 0.00, reconnects:  0.00
[1463s] threads: 64, tps: 1737.00, reads: 24406.94, writes: 6922.98, response time: 52.54ms (95%), errors: 0.00, reconnects:  0.00
[1464s] threads: 64, tps: 1782.00, reads: 24954.96, writes: 7148.99, response time: 50.06ms (95%), errors: 0.00, reconnects:  0.00
[1465s] threads: 64, tps: 1778.01, reads: 24876.13, writes: 7127.04, response time: 49.68ms (95%), errors: 0.00, reconnects:  0.00
[1466s] threads: 64, tps: 1758.00, reads: 24553.99, writes: 7016.00, response time: 52.12ms (95%), errors: 0.00, reconnects:  0.00
[1467s] threads: 64, tps: 1824.99, reads: 25581.88, writes: 7322.97, response time: 51.42ms (95%), errors: 0.00, reconnects:  0.00
[1468s] threads: 64, tps: 1712.00, reads: 24120.01, writes: 6912.00, response time: 54.91ms (95%), errors: 0.00, reconnects:  0.00
[1469s] threads: 64, tps: 1812.00, reads: 25339.97, writes: 7272.99, response time: 51.47ms (95%), errors: 0.00, reconnects:  0.00
[1470s] threads: 64, tps: 1971.01, reads: 27520.08, writes: 7788.02, response time: 47.36ms (95%), errors: 0.00, reconnects:  0.00
[1471s] threads: 64, tps: 2053.01, reads: 28725.07, writes: 8216.02, response time: 45.98ms (95%), errors: 0.00, reconnects:  0.00
[1472s] threads: 64, tps: 2013.99, reads: 28104.86, writes: 8073.96, response time: 47.97ms (95%), errors: 0.00, reconnects:  0.00
[1473s] threads: 64, tps: 2096.01, reads: 29515.16, writes: 8477.05, response time: 44.26ms (95%), errors: 0.00, reconnects:  0.00
[1474s] threads: 64, tps: 2054.99, reads: 28691.84, writes: 8140.96, response time: 44.62ms (95%), errors: 0.00, reconnects:  0.00
[1475s] threads: 64, tps: 2094.01, reads: 29439.17, writes: 8436.05, response time: 44.24ms (95%), errors: 0.00, reconnects:  0.00
[1476s] threads: 64, tps: 2093.99, reads: 29281.84, writes: 8334.95, response time: 44.41ms (95%), errors: 0.00, reconnects:  0.00
[1477s] threads: 64, tps: 2129.01, reads: 29756.16, writes: 8483.05, response time: 42.90ms (95%), errors: 0.00, reconnects:  0.00
[1478s] threads: 64, tps: 2070.00, reads: 28907.99, writes: 8251.00, response time: 45.87ms (95%), errors: 0.00, reconnects:  0.00
[1479s] threads: 64, tps: 2108.00, reads: 29470.97, writes: 8457.99, response time: 42.17ms (95%), errors: 0.00, reconnects:  0.00
[1480s] threads: 64, tps: 2000.99, reads: 28042.90, writes: 7964.97, response time: 45.39ms (95%), errors: 0.00, reconnects:  0.00
[1481s] threads: 64, tps: 2031.01, reads: 28414.12, writes: 8133.03, response time: 44.18ms (95%), errors: 0.00, reconnects:  0.00
[1482s] threads: 64, tps: 1992.00, reads: 28075.00, writes: 8068.00, response time: 45.12ms (95%), errors: 0.00, reconnects:  0.00
[1483s] threads: 64, tps: 2090.99, reads: 29154.87, writes: 8295.96, response time: 43.60ms (95%), errors: 0.00, reconnects:  0.00
[1484s] threads: 64, tps: 2017.01, reads: 28237.13, writes: 8068.04, response time: 46.57ms (95%), errors: 0.00, reconnects:  0.00
[1485s] threads: 64, tps: 1878.00, reads: 26393.99, writes: 7578.00, response time: 48.13ms (95%), errors: 0.00, reconnects:  0.00
[1486s] threads: 64, tps: 1768.99, reads: 24552.91, writes: 6945.97, response time: 53.27ms (95%), errors: 0.00, reconnects:  0.00
[1487s] threads: 64, tps: 1683.01, reads: 23637.09, writes: 6736.02, response time: 53.70ms (95%), errors: 0.00, reconnects:  0.00
[1488s] threads: 64, tps: 1829.00, reads: 25679.00, writes: 7333.00, response time: 48.28ms (95%), errors: 0.00, reconnects:  0.00
[1489s] threads: 64, tps: 1757.81, reads: 24591.39, writes: 7061.25, response time: 50.34ms (95%), errors: 0.00, reconnects:  0.00
[1490s] threads: 64, tps: 1875.16, reads: 26182.27, writes: 7477.65, response time: 49.17ms (95%), errors: 0.00, reconnects:  0.00
[1491s] threads: 64, tps: 1921.03, reads: 26947.48, writes: 7700.14, response time: 46.00ms (95%), errors: 0.00, reconnects:  0.00
[1492s] threads: 64, tps: 1960.00, reads: 27460.02, writes: 7807.01, response time: 48.10ms (95%), errors: 0.00, reconnects:  0.00
[1493s] threads: 64, tps: 2013.00, reads: 28219.00, writes: 8155.00, response time: 45.29ms (95%), errors: 0.00, reconnects:  0.00
[1494s] threads: 64, tps: 2069.00, reads: 28892.98, writes: 8219.99, response time: 44.58ms (95%), errors: 0.00, reconnects:  0.00
[1495s] threads: 64, tps: 2024.99, reads: 28366.91, writes: 8107.98, response time: 44.17ms (95%), errors: 0.00, reconnects:  0.00
[1496s] threads: 64, tps: 2063.01, reads: 28852.14, writes: 8256.04, response time: 44.18ms (95%), errors: 0.00, reconnects:  0.00
[1497s] threads: 64, tps: 2077.00, reads: 29044.95, writes: 8293.99, response time: 44.82ms (95%), errors: 0.00, reconnects:  0.00
[1498s] threads: 64, tps: 2040.00, reads: 28584.04, writes: 8154.01, response time: 44.47ms (95%), errors: 0.00, reconnects:  0.00
[1499s] threads: 64, tps: 2099.00, reads: 29545.98, writes: 8472.00, response time: 44.16ms (95%), errors: 0.00, reconnects:  0.00
[1500s] threads: 64, tps: 2109.99, reads: 29482.90, writes: 8430.97, response time: 42.46ms (95%), errors: 0.00, reconnects:  0.00
[1501s] threads: 64, tps: 2119.01, reads: 29528.11, writes: 8397.03, response time: 42.18ms (95%), errors: 0.00, reconnects:  0.00
[1502s] threads: 64, tps: 2075.00, reads: 29091.02, writes: 8296.01, response time: 44.08ms (95%), errors: 0.00, reconnects:  0.00
[1503s] threads: 64, tps: 2155.00, reads: 29926.96, writes: 8603.99, response time: 42.52ms (95%), errors: 0.00, reconnects:  0.00
[1504s] threads: 64, tps: 1968.00, reads: 27753.02, writes: 7886.01, response time: 45.06ms (95%), errors: 0.00, reconnects:  0.00
[1505s] threads: 64, tps: 2012.00, reads: 28227.98, writes: 8049.99, response time: 45.46ms (95%), errors: 0.00, reconnects:  0.00
[1506s] threads: 64, tps: 1962.99, reads: 27485.93, writes: 7921.98, response time: 47.54ms (95%), errors: 0.00, reconnects:  0.00
[1507s] threads: 64, tps: 1940.00, reads: 27242.07, writes: 7755.02, response time: 46.88ms (95%), errors: 0.00, reconnects:  0.00
[1508s] threads: 64, tps: 1919.00, reads: 26717.02, writes: 7592.00, response time: 47.80ms (95%), errors: 0.00, reconnects:  0.00
[1509s] threads: 64, tps: 1815.00, reads: 25464.00, writes: 7268.00, response time: 49.03ms (95%), errors: 0.00, reconnects:  0.00
[1510s] threads: 64, tps: 1745.99, reads: 24587.91, writes: 7060.97, response time: 51.50ms (95%), errors: 0.00, reconnects:  0.00
[1511s] threads: 64, tps: 1741.01, reads: 24230.10, writes: 6871.03, response time: 53.42ms (95%), errors: 0.00, reconnects:  0.00
[1512s] threads: 64, tps: 1698.00, reads: 23816.98, writes: 6830.00, response time: 51.95ms (95%), errors: 0.00, reconnects:  0.00
[1513s] threads: 64, tps: 1672.00, reads: 23337.99, writes: 6663.00, response time: 54.58ms (95%), errors: 0.00, reconnects:  0.00
[1514s] threads: 64, tps: 1754.99, reads: 24562.84, writes: 7054.95, response time: 52.45ms (95%), errors: 0.00, reconnects:  0.00
[1515s] threads: 64, tps: 1784.01, reads: 24982.18, writes: 7148.05, response time: 50.10ms (95%), errors: 0.00, reconnects:  0.00
[1516s] threads: 64, tps: 1826.97, reads: 25555.60, writes: 7278.89, response time: 48.65ms (95%), errors: 0.00, reconnects:  0.00
[1517s] threads: 64, tps: 1959.03, reads: 27425.41, writes: 7833.12, response time: 45.76ms (95%), errors: 0.00, reconnects:  0.00
[1518s] threads: 64, tps: 1974.00, reads: 27646.04, writes: 7918.01, response time: 46.41ms (95%), errors: 0.00, reconnects:  0.00
[1519s] threads: 64, tps: 1946.00, reads: 27428.97, writes: 7849.99, response time: 45.47ms (95%), errors: 0.00, reconnects:  0.00
[1520s] threads: 64, tps: 1930.00, reads: 26889.04, writes: 7649.01, response time: 45.78ms (95%), errors: 0.00, reconnects:  0.00
[1521s] threads: 64, tps: 1855.00, reads: 25848.00, writes: 7414.00, response time: 49.73ms (95%), errors: 0.00, reconnects:  0.00
[1522s] threads: 64, tps: 1809.00, reads: 25539.98, writes: 7296.00, response time: 50.42ms (95%), errors: 0.00, reconnects:  0.00
[1523s] threads: 64, tps: 1735.00, reads: 24076.99, writes: 6850.00, response time: 52.39ms (95%), errors: 0.00, reconnects:  0.00
[1524s] threads: 64, tps: 1844.00, reads: 26023.05, writes: 7464.02, response time: 51.16ms (95%), errors: 0.00, reconnects:  0.00
[1525s] threads: 64, tps: 1786.99, reads: 24992.85, writes: 7151.96, response time: 51.50ms (95%), errors: 0.00, reconnects:  0.00
[1526s] threads: 64, tps: 1791.01, reads: 24977.13, writes: 7115.04, response time: 52.43ms (95%), errors: 0.00, reconnects:  0.00
[1527s] threads: 64, tps: 1729.00, reads: 24177.99, writes: 6889.00, response time: 52.73ms (95%), errors: 0.00, reconnects:  0.00
[1528s] threads: 64, tps: 1657.00, reads: 23254.99, writes: 6625.00, response time: 56.31ms (95%), errors: 0.00, reconnects:  0.00
[1529s] threads: 64, tps: 1867.00, reads: 26088.01, writes: 7486.00, response time: 49.24ms (95%), errors: 0.00, reconnects:  0.00
[1530s] threads: 64, tps: 1876.00, reads: 26301.02, writes: 7517.01, response time: 48.30ms (95%), errors: 0.00, reconnects:  0.00
[1531s] threads: 64, tps: 1910.00, reads: 26787.00, writes: 7686.00, response time: 47.63ms (95%), errors: 0.00, reconnects:  0.00
[1532s] threads: 64, tps: 1846.00, reads: 25873.97, writes: 7363.99, response time: 50.18ms (95%), errors: 0.00, reconnects:  0.00
[1533s] threads: 64, tps: 1918.00, reads: 26725.01, writes: 7626.00, response time: 47.18ms (95%), errors: 0.00, reconnects:  0.00
[1534s] threads: 64, tps: 1840.00, reads: 25726.93, writes: 7329.98, response time: 50.04ms (95%), errors: 0.00, reconnects:  0.00
[1535s] threads: 64, tps: 1779.01, reads: 25007.10, writes: 7112.03, response time: 52.18ms (95%), errors: 0.00, reconnects:  0.00
[1536s] threads: 64, tps: 1904.00, reads: 26668.97, writes: 7665.99, response time: 48.67ms (95%), errors: 0.00, reconnects:  0.00
[1537s] threads: 64, tps: 2001.00, reads: 28032.02, writes: 8012.01, response time: 46.39ms (95%), errors: 0.00, reconnects:  0.00
[1538s] threads: 64, tps: 2070.00, reads: 29065.95, writes: 8325.99, response time: 44.34ms (95%), errors: 0.00, reconnects:  0.00
[1539s] threads: 64, tps: 2080.00, reads: 29025.96, writes: 8288.99, response time: 45.80ms (95%), errors: 0.00, reconnects:  0.00
[1540s] threads: 64, tps: 2038.01, reads: 28461.08, writes: 8123.02, response time: 46.14ms (95%), errors: 0.00, reconnects:  0.00
[1541s] threads: 64, tps: 2020.00, reads: 28303.99, writes: 8068.00, response time: 46.32ms (95%), errors: 0.00, reconnects:  0.00
[1542s] threads: 64, tps: 2085.99, reads: 29336.86, writes: 8454.96, response time: 44.45ms (95%), errors: 0.00, reconnects:  0.00
[1543s] threads: 64, tps: 2105.01, reads: 29296.14, writes: 8328.04, response time: 46.81ms (95%), errors: 0.00, reconnects:  0.00
[1544s] threads: 64, tps: 2143.00, reads: 30084.98, writes: 8594.00, response time: 44.21ms (95%), errors: 0.00, reconnects:  0.00
[1545s] threads: 64, tps: 2085.00, reads: 29053.02, writes: 8309.01, response time: 47.46ms (95%), errors: 0.00, reconnects:  0.00
[1546s] threads: 64, tps: 2190.00, reads: 30689.00, writes: 8737.00, response time: 42.78ms (95%), errors: 0.00, reconnects:  0.00
[1547s] threads: 64, tps: 2128.00, reads: 29990.00, writes: 8598.00, response time: 43.68ms (95%), errors: 0.00, reconnects:  0.00
[1548s] threads: 64, tps: 2104.99, reads: 29389.82, writes: 8398.95, response time: 45.54ms (95%), errors: 0.00, reconnects:  0.00
[1549s] threads: 64, tps: 2099.00, reads: 29443.04, writes: 8393.01, response time: 44.78ms (95%), errors: 0.00, reconnects:  0.00
[1550s] threads: 64, tps: 2134.01, reads: 29907.14, writes: 8606.04, response time: 43.09ms (95%), errors: 0.00, reconnects:  0.00
[1551s] threads: 64, tps: 2142.00, reads: 29878.03, writes: 8467.01, response time: 46.11ms (95%), errors: 0.00, reconnects:  0.00
[1552s] threads: 64, tps: 2021.00, reads: 28253.93, writes: 8070.98, response time: 46.36ms (95%), errors: 0.00, reconnects:  0.00
[1553s] threads: 64, tps: 1973.00, reads: 27607.02, writes: 7905.00, response time: 47.96ms (95%), errors: 0.00, reconnects:  0.00
[1554s] threads: 64, tps: 2049.00, reads: 28704.03, writes: 8180.01, response time: 46.64ms (95%), errors: 0.00, reconnects:  0.00
[1555s] threads: 64, tps: 1960.00, reads: 27645.02, writes: 7992.01, response time: 47.01ms (95%), errors: 0.00, reconnects:  0.00
[1556s] threads: 64, tps: 1978.00, reads: 27295.97, writes: 7760.99, response time: 47.83ms (95%), errors: 0.00, reconnects:  0.00
[1557s] threads: 64, tps: 1884.00, reads: 26583.04, writes: 7527.01, response time: 49.80ms (95%), errors: 0.00, reconnects:  0.00
[1558s] threads: 64, tps: 1889.99, reads: 26418.84, writes: 7547.95, response time: 47.63ms (95%), errors: 0.00, reconnects:  0.00
[1559s] threads: 64, tps: 1619.00, reads: 22736.99, writes: 6485.00, response time: 57.39ms (95%), errors: 0.00, reconnects:  0.00
[1560s] threads: 64, tps: 1699.01, reads: 23748.11, writes: 6780.03, response time: 52.70ms (95%), errors: 0.00, reconnects:  0.00
[1561s] threads: 64, tps: 1672.00, reads: 23434.00, writes: 6686.00, response time: 51.44ms (95%), errors: 0.00, reconnects:  0.00
[1562s] threads: 64, tps: 1701.00, reads: 23830.04, writes: 6829.01, response time: 53.40ms (95%), errors: 0.00, reconnects:  0.00
[1563s] threads: 64, tps: 1836.99, reads: 25747.93, writes: 7410.98, response time: 49.17ms (95%), errors: 0.00, reconnects:  0.00
[1564s] threads: 64, tps: 1895.00, reads: 26417.02, writes: 7539.01, response time: 47.15ms (95%), errors: 0.00, reconnects:  0.00
[1565s] threads: 64, tps: 1888.00, reads: 26532.00, writes: 7557.00, response time: 46.91ms (95%), errors: 0.00, reconnects:  0.00
[1566s] threads: 64, tps: 1819.00, reads: 25377.00, writes: 7244.00, response time: 51.78ms (95%), errors: 0.00, reconnects:  0.00
[1567s] threads: 64, tps: 1813.00, reads: 25429.99, writes: 7264.00, response time: 48.17ms (95%), errors: 0.00, reconnects:  0.00
[1568s] threads: 64, tps: 1967.00, reads: 27612.00, writes: 7922.00, response time: 46.17ms (95%), errors: 0.00, reconnects:  0.00
[1569s] threads: 64, tps: 1985.00, reads: 27709.05, writes: 7932.01, response time: 46.45ms (95%), errors: 0.00, reconnects:  0.00
[1570s] threads: 64, tps: 2059.00, reads: 28874.98, writes: 8222.99, response time: 42.96ms (95%), errors: 0.00, reconnects:  0.00
[1571s] threads: 64, tps: 1944.00, reads: 27262.97, writes: 7809.99, response time: 45.95ms (95%), errors: 0.00, reconnects:  0.00
[1572s] threads: 64, tps: 1964.00, reads: 27489.02, writes: 7830.01, response time: 46.29ms (95%), errors: 0.00, reconnects:  0.00
[1573s] threads: 64, tps: 1948.00, reads: 27353.04, writes: 7857.01, response time: 45.00ms (95%), errors: 0.00, reconnects:  0.00
[1574s] threads: 64, tps: 2016.00, reads: 27928.96, writes: 7983.99, response time: 45.80ms (95%), errors: 0.00, reconnects:  0.00
[1575s] threads: 64, tps: 1919.00, reads: 26985.98, writes: 7685.99, response time: 46.63ms (95%), errors: 0.00, reconnects:  0.00
[1576s] threads: 64, tps: 1960.00, reads: 27413.02, writes: 7804.01, response time: 47.02ms (95%), errors: 0.00, reconnects:  0.00
[1577s] threads: 64, tps: 1897.00, reads: 26679.00, writes: 7630.00, response time: 47.13ms (95%), errors: 0.00, reconnects:  0.00
[1578s] threads: 64, tps: 1883.00, reads: 26326.00, writes: 7523.00, response time: 47.57ms (95%), errors: 0.00, reconnects:  0.00
[1579s] threads: 64, tps: 1932.00, reads: 27053.00, writes: 7743.00, response time: 48.16ms (95%), errors: 0.00, reconnects:  0.00
[1580s] threads: 64, tps: 1984.00, reads: 27782.02, writes: 7920.01, response time: 46.25ms (95%), errors: 0.00, reconnects:  0.00
[1581s] threads: 64, tps: 1875.00, reads: 26215.95, writes: 7505.98, response time: 49.05ms (95%), errors: 0.00, reconnects:  0.00
[1582s] threads: 64, tps: 1723.00, reads: 24028.04, writes: 6816.01, response time: 52.72ms (95%), errors: 0.00, reconnects:  0.00
[1583s] threads: 64, tps: 1727.00, reads: 24180.99, writes: 6905.00, response time: 53.45ms (95%), errors: 0.00, reconnects:  0.00
[1584s] threads: 64, tps: 1604.00, reads: 22640.00, writes: 6531.00, response time: 58.35ms (95%), errors: 0.00, reconnects:  0.00
[1585s] threads: 64, tps: 1648.00, reads: 23026.99, writes: 6503.00, response time: 54.20ms (95%), errors: 0.00, reconnects:  0.00
[1586s] threads: 64, tps: 1682.00, reads: 23458.98, writes: 6704.00, response time: 53.82ms (95%), errors: 0.00, reconnects:  0.00
[1587s] threads: 64, tps: 1727.00, reads: 24215.04, writes: 6930.01, response time: 51.13ms (95%), errors: 0.00, reconnects:  0.00
[1588s] threads: 64, tps: 1772.00, reads: 24740.99, writes: 7110.00, response time: 50.83ms (95%), errors: 0.00, reconnects:  0.00
[1589s] threads: 64, tps: 1856.00, reads: 26047.02, writes: 7439.01, response time: 49.21ms (95%), errors: 0.00, reconnects:  0.00
[1590s] threads: 64, tps: 1795.00, reads: 25151.96, writes: 7200.99, response time: 50.03ms (95%), errors: 0.00, reconnects:  0.00
[1591s] threads: 64, tps: 1870.00, reads: 26096.01, writes: 7457.00, response time: 50.45ms (95%), errors: 0.00, reconnects:  0.00
[1592s] threads: 64, tps: 1936.00, reads: 27121.93, writes: 7760.98, response time: 45.32ms (95%), errors: 0.00, reconnects:  0.00
[1593s] threads: 64, tps: 1994.00, reads: 27904.05, writes: 7943.02, response time: 44.35ms (95%), errors: 0.00, reconnects:  0.00
[1594s] threads: 64, tps: 1957.00, reads: 27441.03, writes: 7830.01, response time: 46.77ms (95%), errors: 0.00, reconnects:  0.00
[1595s] threads: 64, tps: 2048.98, reads: 28648.69, writes: 8192.91, response time: 45.10ms (95%), errors: 0.00, reconnects:  0.00
[1596s] threads: 64, tps: 2063.02, reads: 28966.30, writes: 8289.09, response time: 44.39ms (95%), errors: 0.00, reconnects:  0.00
[1597s] threads: 64, tps: 2095.00, reads: 29282.01, writes: 8345.00, response time: 43.56ms (95%), errors: 0.00, reconnects:  0.00
[1598s] threads: 64, tps: 2026.00, reads: 28368.02, writes: 8105.01, response time: 44.97ms (95%), errors: 0.00, reconnects:  0.00
[1599s] threads: 64, tps: 2014.00, reads: 28195.97, writes: 8064.99, response time: 44.85ms (95%), errors: 0.00, reconnects:  0.00
[1600s] threads: 64, tps: 2059.00, reads: 28791.02, writes: 8228.00, response time: 44.45ms (95%), errors: 0.00, reconnects:  0.00
[1601s] threads: 64, tps: 2095.00, reads: 29323.98, writes: 8350.99, response time: 43.15ms (95%), errors: 0.00, reconnects:  0.00
[1602s] threads: 64, tps: 1880.00, reads: 26284.99, writes: 7554.00, response time: 50.13ms (95%), errors: 0.00, reconnects:  0.00
[1603s] threads: 64, tps: 2008.00, reads: 28313.99, writes: 8106.00, response time: 45.17ms (95%), errors: 0.00, reconnects:  0.00
[1604s] threads: 64, tps: 2051.00, reads: 28521.99, writes: 8131.00, response time: 45.27ms (95%), errors: 0.00, reconnects:  0.00
[1605s] threads: 64, tps: 2117.00, reads: 29660.05, writes: 8478.01, response time: 44.97ms (95%), errors: 0.00, reconnects:  0.00
[1606s] threads: 64, tps: 2019.00, reads: 28336.98, writes: 8111.99, response time: 46.71ms (95%), errors: 0.00, reconnects:  0.00
[1607s] threads: 64, tps: 1988.00, reads: 27872.01, writes: 7946.00, response time: 46.18ms (95%), errors: 0.00, reconnects:  0.00
[1608s] threads: 64, tps: 1872.00, reads: 26241.00, writes: 7481.00, response time: 48.97ms (95%), errors: 0.00, reconnects:  0.00
[1609s] threads: 64, tps: 1890.00, reads: 26284.00, writes: 7473.00, response time: 48.96ms (95%), errors: 0.00, reconnects:  0.00
[1610s] threads: 64, tps: 1894.00, reads: 26601.04, writes: 7609.01, response time: 47.37ms (95%), errors: 0.00, reconnects:  0.00
[1611s] threads: 64, tps: 1988.00, reads: 27855.94, writes: 8010.98, response time: 47.20ms (95%), errors: 0.00, reconnects:  0.00
[1612s] threads: 64, tps: 2057.97, reads: 28711.61, writes: 8149.89, response time: 44.00ms (95%), errors: 0.00, reconnects:  0.00
[1613s] threads: 64, tps: 2149.03, reads: 30167.41, writes: 8645.12, response time: 44.50ms (95%), errors: 0.00, reconnects:  0.00
[1614s] threads: 64, tps: 2187.00, reads: 30762.01, writes: 8852.00, response time: 42.07ms (95%), errors: 0.00, reconnects:  0.00
[1615s] threads: 64, tps: 2264.00, reads: 31444.01, writes: 8903.00, response time: 43.62ms (95%), errors: 0.00, reconnects:  0.00
[1616s] threads: 64, tps: 2130.00, reads: 29938.01, writes: 8608.00, response time: 45.46ms (95%), errors: 0.00, reconnects:  0.00
[1617s] threads: 64, tps: 2077.00, reads: 29079.98, writes: 8276.99, response time: 44.98ms (95%), errors: 0.00, reconnects:  0.00
[1618s] threads: 64, tps: 2226.00, reads: 31112.97, writes: 8891.99, response time: 42.53ms (95%), errors: 0.00, reconnects:  0.00
[1619s] threads: 64, tps: 2108.99, reads: 29715.93, writes: 8536.98, response time: 44.62ms (95%), errors: 0.00, reconnects:  0.00
[1620s] threads: 64, tps: 1938.01, reads: 27043.11, writes: 7693.03, response time: 49.94ms (95%), errors: 0.00, reconnects:  0.00
[1621s] threads: 64, tps: 1956.44, reads: 27331.12, writes: 7795.75, response time: 49.89ms (95%), errors: 0.00, reconnects:  0.00
[1622s] threads: 64, tps: 2029.56, reads: 28367.78, writes: 8135.23, response time: 47.09ms (95%), errors: 0.00, reconnects:  0.00
[1623s] threads: 64, tps: 2066.02, reads: 29080.23, writes: 8307.07, response time: 46.99ms (95%), errors: 0.00, reconnects:  0.00
[1624s] threads: 64, tps: 2045.01, reads: 28554.17, writes: 8138.05, response time: 46.22ms (95%), errors: 0.00, reconnects:  0.00
[1625s] threads: 64, tps: 1976.99, reads: 27669.87, writes: 7935.96, response time: 47.63ms (95%), errors: 0.00, reconnects:  0.00
[1626s] threads: 64, tps: 1929.01, reads: 26935.14, writes: 7629.04, response time: 52.06ms (95%), errors: 0.00, reconnects:  0.00
[1627s] threads: 64, tps: 1872.00, reads: 26214.98, writes: 7507.00, response time: 53.26ms (95%), errors: 0.00, reconnects:  0.00
[1628s] threads: 64, tps: 1753.99, reads: 24576.90, writes: 7074.97, response time: 54.69ms (95%), errors: 0.00, reconnects:  0.00
[1629s] threads: 64, tps: 1786.00, reads: 24949.02, writes: 7092.01, response time: 54.48ms (95%), errors: 0.00, reconnects:  0.00
[1630s] threads: 64, tps: 1876.01, reads: 26285.09, writes: 7511.03, response time: 49.92ms (95%), errors: 0.00, reconnects:  0.00
[1631s] threads: 64, tps: 2021.00, reads: 28383.99, writes: 8122.00, response time: 46.28ms (95%), errors: 0.00, reconnects:  0.00
[1632s] threads: 64, tps: 1950.00, reads: 27378.99, writes: 7834.00, response time: 48.67ms (95%), errors: 0.00, reconnects:  0.00
[1633s] threads: 64, tps: 1855.99, reads: 25862.86, writes: 7320.96, response time: 50.52ms (95%), errors: 0.00, reconnects:  0.00
[1634s] threads: 64, tps: 1808.01, reads: 25240.14, writes: 7225.04, response time: 52.01ms (95%), errors: 0.00, reconnects:  0.00
[1635s] threads: 64, tps: 1945.00, reads: 27232.98, writes: 7797.00, response time: 45.78ms (95%), errors: 0.00, reconnects:  0.00
[1636s] threads: 64, tps: 1693.00, reads: 23769.01, writes: 6766.00, response time: 53.58ms (95%), errors: 0.00, reconnects:  0.00
[1637s] threads: 64, tps: 1663.00, reads: 23230.01, writes: 6656.00, response time: 52.78ms (95%), errors: 0.00, reconnects:  0.00
[1638s] threads: 64, tps: 1738.99, reads: 24379.86, writes: 6930.96, response time: 50.19ms (95%), errors: 0.00, reconnects:  0.00
[1639s] threads: 64, tps: 1719.01, reads: 24141.12, writes: 6979.04, response time: 52.20ms (95%), errors: 0.00, reconnects:  0.00
[1640s] threads: 64, tps: 1782.00, reads: 24986.03, writes: 7115.01, response time: 50.25ms (95%), errors: 0.00, reconnects:  0.00
[1641s] threads: 64, tps: 1898.00, reads: 26433.97, writes: 7509.99, response time: 47.19ms (95%), errors: 0.00, reconnects:  0.00
[1642s] threads: 64, tps: 1894.00, reads: 26659.00, writes: 7645.00, response time: 46.34ms (95%), errors: 0.00, reconnects:  0.00
[1643s] threads: 64, tps: 1971.00, reads: 27561.04, writes: 7907.01, response time: 44.89ms (95%), errors: 0.00, reconnects:  0.00
[1644s] threads: 64, tps: 1962.00, reads: 27326.96, writes: 7757.99, response time: 46.77ms (95%), errors: 0.00, reconnects:  0.00
[1645s] threads: 64, tps: 1992.99, reads: 28068.89, writes: 8089.97, response time: 45.46ms (95%), errors: 0.00, reconnects:  0.00
[1646s] threads: 64, tps: 2075.99, reads: 28866.84, writes: 8205.96, response time: 43.81ms (95%), errors: 0.00, reconnects:  0.00
[1647s] threads: 64, tps: 2016.02, reads: 28384.25, writes: 8103.07, response time: 45.52ms (95%), errors: 0.00, reconnects:  0.00
[1648s] threads: 64, tps: 2144.00, reads: 29894.05, writes: 8586.01, response time: 43.21ms (95%), errors: 0.00, reconnects:  0.00
[1649s] threads: 64, tps: 2039.00, reads: 28767.98, writes: 8231.99, response time: 44.17ms (95%), errors: 0.00, reconnects:  0.00
[1650s] threads: 64, tps: 2041.00, reads: 28329.01, writes: 8034.00, response time: 46.46ms (95%), errors: 0.00, reconnects:  0.00
[1651s] threads: 64, tps: 2084.00, reads: 29192.00, writes: 8317.00, response time: 43.53ms (95%), errors: 0.00, reconnects:  0.00
[1652s] threads: 64, tps: 2065.00, reads: 28965.97, writes: 8278.99, response time: 43.01ms (95%), errors: 0.00, reconnects:  0.00
[1653s] threads: 64, tps: 2056.00, reads: 28851.02, writes: 8288.00, response time: 44.45ms (95%), errors: 0.00, reconnects:  0.00
[1654s] threads: 64, tps: 2030.00, reads: 28326.01, writes: 8091.00, response time: 44.74ms (95%), errors: 0.00, reconnects:  0.00
[1655s] threads: 64, tps: 2027.99, reads: 28451.88, writes: 8117.97, response time: 43.63ms (95%), errors: 0.00, reconnects:  0.00
[1656s] threads: 64, tps: 2052.01, reads: 28704.11, writes: 8178.03, response time: 45.46ms (95%), errors: 0.00, reconnects:  0.00
[1657s] threads: 64, tps: 2009.00, reads: 28182.03, writes: 8067.01, response time: 45.43ms (95%), errors: 0.00, reconnects:  0.00
[1658s] threads: 64, tps: 1949.99, reads: 27243.91, writes: 7768.97, response time: 47.15ms (95%), errors: 0.00, reconnects:  0.00
[1659s] threads: 64, tps: 2000.00, reads: 27965.98, writes: 8002.99, response time: 46.07ms (95%), errors: 0.00, reconnects:  0.00
[1660s] threads: 64, tps: 1853.00, reads: 25949.01, writes: 7374.00, response time: 47.70ms (95%), errors: 0.00, reconnects:  0.00
[1661s] threads: 64, tps: 1760.00, reads: 24646.00, writes: 7030.00, response time: 52.69ms (95%), errors: 0.00, reconnects:  0.00
[1662s] threads: 64, tps: 1559.00, reads: 21796.07, writes: 6241.02, response time: 58.63ms (95%), errors: 0.00, reconnects:  0.00
[1663s] threads: 64, tps: 1635.98, reads: 22970.71, writes: 6541.92, response time: 56.56ms (95%), errors: 0.00, reconnects:  0.00
[1664s] threads: 64, tps: 1772.02, reads: 24758.30, writes: 7081.09, response time: 50.22ms (95%), errors: 0.00, reconnects:  0.00
[1665s] threads: 64, tps: 1767.00, reads: 24751.01, writes: 7140.00, response time: 53.40ms (95%), errors: 0.00, reconnects:  0.00
[1666s] threads: 64, tps: 1707.78, reads: 24077.91, writes: 6903.11, response time: 52.42ms (95%), errors: 0.00, reconnects:  0.00
[1667s] threads: 64, tps: 1782.23, reads: 24863.20, writes: 7094.91, response time: 52.17ms (95%), errors: 0.00, reconnects:  0.00
[1668s] threads: 64, tps: 1819.00, reads: 25344.99, writes: 7208.00, response time: 51.15ms (95%), errors: 0.00, reconnects:  0.00
[1669s] threads: 64, tps: 1749.00, reads: 24503.00, writes: 6963.00, response time: 52.45ms (95%), errors: 0.00, reconnects:  0.00
[1670s] threads: 64, tps: 1686.95, reads: 23623.37, writes: 6757.82, response time: 54.56ms (95%), errors: 0.00, reconnects:  0.00
[1671s] threads: 64, tps: 1719.05, reads: 24197.65, writes: 7026.19, response time: 54.42ms (95%), errors: 0.00, reconnects:  0.00
[1672s] threads: 64, tps: 1968.00, reads: 27473.00, writes: 7817.00, response time: 47.74ms (95%), errors: 0.00, reconnects:  0.00
[1673s] threads: 64, tps: 1948.00, reads: 27218.02, writes: 7754.00, response time: 48.52ms (95%), errors: 0.00, reconnects:  0.00
[1674s] threads: 64, tps: 2008.99, reads: 28288.85, writes: 8095.96, response time: 45.87ms (95%), errors: 0.00, reconnects:  0.00
[1675s] threads: 64, tps: 1976.01, reads: 27529.11, writes: 7825.03, response time: 46.10ms (95%), errors: 0.00, reconnects:  0.00
[1676s] threads: 64, tps: 1923.00, reads: 27018.03, writes: 7760.01, response time: 48.43ms (95%), errors: 0.00, reconnects:  0.00
[1677s] threads: 64, tps: 1990.00, reads: 27718.97, writes: 7888.99, response time: 45.67ms (95%), errors: 0.00, reconnects:  0.00
[1678s] threads: 64, tps: 2044.00, reads: 28615.98, writes: 8163.99, response time: 43.66ms (95%), errors: 0.00, reconnects:  0.00
[1679s] threads: 64, tps: 2002.96, reads: 28093.50, writes: 8011.86, response time: 45.70ms (95%), errors: 0.00, reconnects:  0.00
[1680s] threads: 64, tps: 1993.04, reads: 27865.51, writes: 8015.15, response time: 46.17ms (95%), errors: 0.00, reconnects:  0.00
[1681s] threads: 64, tps: 1959.00, reads: 27381.03, writes: 7780.01, response time: 48.58ms (95%), errors: 0.00, reconnects:  0.00
[1682s] threads: 64, tps: 1955.00, reads: 27443.03, writes: 7828.01, response time: 46.36ms (95%), errors: 0.00, reconnects:  0.00
[1683s] threads: 64, tps: 1919.00, reads: 26872.94, writes: 7657.98, response time: 47.96ms (95%), errors: 0.00, reconnects:  0.00
[1684s] threads: 64, tps: 1852.00, reads: 25890.03, writes: 7426.01, response time: 50.07ms (95%), errors: 0.00, reconnects:  0.00
[1685s] threads: 64, tps: 1813.00, reads: 25398.01, writes: 7218.00, response time: 53.51ms (95%), errors: 0.00, reconnects:  0.00
[1686s] threads: 64, tps: 1832.00, reads: 25873.00, writes: 7577.00, response time: 49.76ms (95%), errors: 0.00, reconnects:  0.00
[1687s] threads: 64, tps: 1883.00, reads: 26102.01, writes: 7299.00, response time: 52.39ms (95%), errors: 0.00, reconnects:  0.00
[1688s] threads: 64, tps: 1693.00, reads: 23758.02, writes: 6797.01, response time: 52.99ms (95%), errors: 0.00, reconnects:  0.00
[1689s] threads: 64, tps: 1684.99, reads: 23727.83, writes: 6851.95, response time: 57.26ms (95%), errors: 0.00, reconnects:  0.00
[1690s] threads: 64, tps: 1573.00, reads: 21928.07, writes: 6174.02, response time: 60.39ms (95%), errors: 0.00, reconnects:  0.00
[1691s] threads: 64, tps: 1562.00, reads: 21804.99, writes: 6221.00, response time: 59.30ms (95%), errors: 0.00, reconnects:  0.00
[1692s] threads: 64, tps: 1532.01, reads: 21540.08, writes: 6216.02, response time: 60.16ms (95%), errors: 0.00, reconnects:  0.00
[1693s] threads: 64, tps: 1747.00, reads: 24344.00, writes: 6910.00, response time: 53.51ms (95%), errors: 0.00, reconnects:  0.00
[1694s] threads: 64, tps: 1888.00, reads: 26612.01, writes: 7659.00, response time: 49.15ms (95%), errors: 0.00, reconnects:  0.00
[1695s] threads: 64, tps: 1985.00, reads: 27667.99, writes: 7882.00, response time: 47.47ms (95%), errors: 0.00, reconnects:  0.00
[1696s] threads: 64, tps: 2008.98, reads: 28028.71, writes: 8021.92, response time: 47.52ms (95%), errors: 0.00, reconnects:  0.00
[1697s] threads: 64, tps: 2048.96, reads: 28900.46, writes: 8307.84, response time: 43.71ms (95%), errors: 0.00, reconnects:  0.00
[1698s] threads: 64, tps: 2099.06, reads: 29354.84, writes: 8335.24, response time: 45.44ms (95%), errors: 0.00, reconnects:  0.00
[1699s] threads: 64, tps: 2015.00, reads: 28176.96, writes: 8062.99, response time: 46.95ms (95%), errors: 0.00, reconnects:  0.00
[1700s] threads: 64, tps: 1989.00, reads: 27802.06, writes: 7912.02, response time: 46.74ms (95%), errors: 0.00, reconnects:  0.00
[1701s] threads: 64, tps: 2023.00, reads: 28448.95, writes: 8170.99, response time: 44.98ms (95%), errors: 0.00, reconnects:  0.00
[1702s] threads: 64, tps: 2107.00, reads: 29384.99, writes: 8385.00, response time: 43.58ms (95%), errors: 0.00, reconnects:  0.00
[1703s] threads: 64, tps: 2104.00, reads: 29415.05, writes: 8413.02, response time: 44.62ms (95%), errors: 0.00, reconnects:  0.00
[1704s] threads: 64, tps: 2133.00, reads: 29847.99, writes: 8473.00, response time: 44.34ms (95%), errors: 0.00, reconnects:  0.00
[1705s] threads: 64, tps: 2138.00, reads: 29862.03, writes: 8569.01, response time: 42.65ms (95%), errors: 0.00, reconnects:  0.00
[1706s] threads: 64, tps: 2076.00, reads: 29203.99, writes: 8348.00, response time: 45.37ms (95%), errors: 0.00, reconnects:  0.00
[1707s] threads: 64, tps: 2088.00, reads: 29083.00, writes: 8337.00, response time: 45.73ms (95%), errors: 0.00, reconnects:  0.00
[1708s] threads: 64, tps: 2063.00, reads: 28955.95, writes: 8218.99, response time: 44.88ms (95%), errors: 0.00, reconnects:  0.00
[1709s] threads: 64, tps: 1951.00, reads: 27262.04, writes: 7785.01, response time: 47.01ms (95%), errors: 0.00, reconnects:  0.00
[1710s] threads: 64, tps: 2110.00, reads: 29510.01, writes: 8410.00, response time: 43.96ms (95%), errors: 0.00, reconnects:  0.00
[1711s] threads: 64, tps: 2021.00, reads: 28269.97, writes: 8085.99, response time: 44.65ms (95%), errors: 0.00, reconnects:  0.00
[1712s] threads: 64, tps: 1865.00, reads: 26231.02, writes: 7502.00, response time: 49.03ms (95%), errors: 0.00, reconnects:  0.00
[1713s] threads: 64, tps: 2051.00, reads: 28770.04, writes: 8224.01, response time: 44.86ms (95%), errors: 0.00, reconnects:  0.00
[1714s] threads: 64, tps: 1947.00, reads: 27262.95, writes: 7796.98, response time: 46.09ms (95%), errors: 0.00, reconnects:  0.00
[1715s] threads: 64, tps: 1917.00, reads: 26813.00, writes: 7617.00, response time: 48.16ms (95%), errors: 0.00, reconnects:  0.00
[1716s] threads: 64, tps: 1826.00, reads: 25493.01, writes: 7297.00, response time: 51.36ms (95%), errors: 0.00, reconnects:  0.00
[1717s] threads: 64, tps: 1803.00, reads: 25258.02, writes: 7210.00, response time: 50.33ms (95%), errors: 0.00, reconnects:  0.00
[1718s] threads: 64, tps: 1828.00, reads: 25620.00, writes: 7347.00, response time: 49.71ms (95%), errors: 0.00, reconnects:  0.00
[1719s] threads: 64, tps: 1857.00, reads: 25951.00, writes: 7387.00, response time: 49.80ms (95%), errors: 0.00, reconnects:  0.00
[1720s] threads: 64, tps: 1844.00, reads: 25904.99, writes: 7457.00, response time: 48.87ms (95%), errors: 0.00, reconnects:  0.00
[1721s] threads: 64, tps: 1775.99, reads: 24943.89, writes: 7138.97, response time: 52.84ms (95%), errors: 0.00, reconnects:  0.00
[1722s] threads: 64, tps: 1920.01, reads: 26734.13, writes: 7603.04, response time: 49.34ms (95%), errors: 0.00, reconnects:  0.00
[1723s] threads: 64, tps: 1964.99, reads: 27419.86, writes: 7836.96, response time: 46.64ms (95%), errors: 0.00, reconnects:  0.00
[1724s] threads: 64, tps: 1991.01, reads: 28036.13, writes: 8026.04, response time: 45.40ms (95%), errors: 0.00, reconnects:  0.00
[1725s] threads: 64, tps: 2042.99, reads: 28536.88, writes: 8143.96, response time: 45.91ms (95%), errors: 0.00, reconnects:  0.00
[1726s] threads: 64, tps: 2124.01, reads: 29826.16, writes: 8533.05, response time: 43.67ms (95%), errors: 0.00, reconnects:  0.00
[1727s] threads: 64, tps: 2129.99, reads: 29765.84, writes: 8490.96, response time: 43.83ms (95%), errors: 0.00, reconnects:  0.00
[1728s] threads: 64, tps: 2110.00, reads: 29593.02, writes: 8467.01, response time: 44.98ms (95%), errors: 0.00, reconnects:  0.00
[1729s] threads: 64, tps: 2048.01, reads: 28617.09, writes: 8138.03, response time: 46.02ms (95%), errors: 0.00, reconnects:  0.00
[1730s] threads: 64, tps: 2137.00, reads: 29900.00, writes: 8584.00, response time: 43.91ms (95%), errors: 0.00, reconnects:  0.00
[1731s] threads: 64, tps: 2021.00, reads: 28313.02, writes: 8091.00, response time: 46.61ms (95%), errors: 0.00, reconnects:  0.00
[1732s] threads: 64, tps: 2095.00, reads: 29198.02, writes: 8305.00, response time: 44.69ms (95%), errors: 0.00, reconnects:  0.00
[1733s] threads: 64, tps: 2127.00, reads: 29768.99, writes: 8524.00, response time: 44.51ms (95%), errors: 0.00, reconnects:  0.00
[1734s] threads: 64, tps: 2117.00, reads: 29832.02, writes: 8495.01, response time: 44.10ms (95%), errors: 0.00, reconnects:  0.00
[1735s] threads: 64, tps: 2308.00, reads: 32145.96, writes: 9212.99, response time: 41.25ms (95%), errors: 0.00, reconnects:  0.00
[1736s] threads: 64, tps: 2164.00, reads: 30443.98, writes: 8674.99, response time: 42.20ms (95%), errors: 0.00, reconnects:  0.00
[1737s] threads: 64, tps: 1951.00, reads: 27260.04, writes: 7828.01, response time: 49.18ms (95%), errors: 0.00, reconnects:  0.00
[1738s] threads: 64, tps: 2029.00, reads: 28411.01, writes: 8158.00, response time: 45.96ms (95%), errors: 0.00, reconnects:  0.00
[1739s] threads: 64, tps: 2032.00, reads: 28440.99, writes: 8062.00, response time: 46.42ms (95%), errors: 0.00, reconnects:  0.00
[1740s] threads: 64, tps: 2095.00, reads: 29274.96, writes: 8378.99, response time: 44.86ms (95%), errors: 0.00, reconnects:  0.00
[1741s] threads: 64, tps: 2152.00, reads: 30202.01, writes: 8616.00, response time: 44.02ms (95%), errors: 0.00, reconnects:  0.00
[1742s] threads: 64, tps: 1934.00, reads: 27081.01, writes: 7741.00, response time: 48.64ms (95%), errors: 0.00, reconnects:  0.00
[1743s] threads: 64, tps: 1932.00, reads: 26937.00, writes: 7685.00, response time: 48.17ms (95%), errors: 0.00, reconnects:  0.00
[1744s] threads: 64, tps: 1973.00, reads: 27599.02, writes: 7870.00, response time: 45.37ms (95%), errors: 0.00, reconnects:  0.00
[1745s] threads: 64, tps: 1760.00, reads: 24735.95, writes: 7053.99, response time: 53.78ms (95%), errors: 0.00, reconnects:  0.00
[1746s] threads: 64, tps: 1795.00, reads: 25154.06, writes: 7197.02, response time: 50.34ms (95%), errors: 0.00, reconnects:  0.00
[1747s] threads: 64, tps: 1812.99, reads: 25409.92, writes: 7268.98, response time: 50.04ms (95%), errors: 0.00, reconnects:  0.00
[1748s] threads: 64, tps: 1783.00, reads: 24869.04, writes: 7097.01, response time: 51.67ms (95%), errors: 0.00, reconnects:  0.00
[1749s] threads: 64, tps: 1777.00, reads: 24887.01, writes: 7121.00, response time: 52.50ms (95%), errors: 0.00, reconnects:  0.00
[1750s] threads: 64, tps: 1942.00, reads: 27266.00, writes: 7834.00, response time: 48.68ms (95%), errors: 0.00, reconnects:  0.00
[1751s] threads: 64, tps: 2084.00, reads: 29226.98, writes: 8332.99, response time: 45.05ms (95%), errors: 0.00, reconnects:  0.00
[1752s] threads: 64, tps: 2077.00, reads: 29046.98, writes: 8277.99, response time: 46.66ms (95%), errors: 0.00, reconnects:  0.00
[1753s] threads: 64, tps: 2026.00, reads: 28386.06, writes: 8146.02, response time: 46.21ms (95%), errors: 0.00, reconnects:  0.00
[1754s] threads: 64, tps: 2073.78, reads: 28882.02, writes: 8246.15, response time: 46.68ms (95%), errors: 0.00, reconnects:  0.00
[1755s] threads: 64, tps: 2006.18, reads: 27978.39, writes: 8007.69, response time: 47.70ms (95%), errors: 0.00, reconnects:  0.00
[1756s] threads: 64, tps: 2021.00, reads: 28574.03, writes: 8150.01, response time: 46.77ms (95%), errors: 0.00, reconnects:  0.00
[1757s] threads: 64, tps: 2187.00, reads: 30557.99, writes: 8739.00, response time: 43.01ms (95%), errors: 0.00, reconnects:  0.00
[1758s] threads: 64, tps: 2120.00, reads: 29646.04, writes: 8505.01, response time: 43.70ms (95%), errors: 0.00, reconnects:  0.00
[1759s] threads: 64, tps: 2154.00, reads: 30189.97, writes: 8563.99, response time: 41.94ms (95%), errors: 0.00, reconnects:  0.00
[1760s] threads: 64, tps: 2147.00, reads: 30153.99, writes: 8682.00, response time: 43.63ms (95%), errors: 0.00, reconnects:  0.00
[1761s] threads: 64, tps: 2204.00, reads: 30670.99, writes: 8658.00, response time: 43.62ms (95%), errors: 0.00, reconnects:  0.00
[1762s] threads: 64, tps: 2122.00, reads: 29924.01, writes: 8667.00, response time: 43.73ms (95%), errors: 0.00, reconnects:  0.00
[1763s] threads: 64, tps: 2144.00, reads: 29858.02, writes: 8469.01, response time: 44.16ms (95%), errors: 0.00, reconnects:  0.00
[1764s] threads: 64, tps: 2140.00, reads: 29954.99, writes: 8594.00, response time: 42.05ms (95%), errors: 0.00, reconnects:  0.00
[1765s] threads: 64, tps: 2101.00, reads: 29438.03, writes: 8359.01, response time: 44.67ms (95%), errors: 0.00, reconnects:  0.00
[1766s] threads: 64, tps: 2045.00, reads: 28694.99, writes: 8230.00, response time: 46.59ms (95%), errors: 0.00, reconnects:  0.00
[1767s] threads: 64, tps: 1983.00, reads: 27616.98, writes: 7843.00, response time: 47.96ms (95%), errors: 0.00, reconnects:  0.00
[1768s] threads: 64, tps: 1987.00, reads: 27872.98, writes: 7980.99, response time: 46.29ms (95%), errors: 0.00, reconnects:  0.00
[1769s] threads: 64, tps: 2064.00, reads: 29011.04, writes: 8331.01, response time: 44.27ms (95%), errors: 0.00, reconnects:  0.00
[1770s] threads: 64, tps: 2072.00, reads: 28824.00, writes: 8222.00, response time: 44.90ms (95%), errors: 0.00, reconnects:  0.00
[1771s] threads: 64, tps: 1932.00, reads: 27163.01, writes: 7694.00, response time: 47.80ms (95%), errors: 0.00, reconnects:  0.00
[1772s] threads: 64, tps: 1667.00, reads: 23295.00, writes: 6663.00, response time: 57.12ms (95%), errors: 0.00, reconnects:  0.00
[1773s] threads: 64, tps: 1571.00, reads: 22074.99, writes: 6449.00, response time: 61.72ms (95%), errors: 0.00, reconnects:  0.00
[1774s] threads: 64, tps: 1367.00, reads: 19092.97, writes: 5290.99, response time: 69.91ms (95%), errors: 0.00, reconnects:  0.00
[1775s] threads: 64, tps: 1363.00, reads: 19031.01, writes: 5454.00, response time: 69.81ms (95%), errors: 0.00, reconnects:  0.00
[1776s] threads: 64, tps: 1387.00, reads: 19546.00, writes: 5610.00, response time: 64.91ms (95%), errors: 0.00, reconnects:  0.00
[1777s] threads: 64, tps: 1491.00, reads: 20759.02, writes: 5928.00, response time: 63.22ms (95%), errors: 0.00, reconnects:  0.00
[1778s] threads: 64, tps: 1600.00, reads: 22477.99, writes: 6454.00, response time: 56.71ms (95%), errors: 0.00, reconnects:  0.00
[1779s] threads: 64, tps: 1700.00, reads: 23762.02, writes: 6781.01, response time: 54.68ms (95%), errors: 0.00, reconnects:  0.00
[1780s] threads: 64, tps: 1808.00, reads: 25112.99, writes: 7169.00, response time: 51.36ms (95%), errors: 0.00, reconnects:  0.00
[1781s] threads: 64, tps: 1815.00, reads: 25539.98, writes: 7379.99, response time: 50.98ms (95%), errors: 0.00, reconnects:  0.00
[1782s] threads: 64, tps: 1833.00, reads: 25811.97, writes: 7288.99, response time: 50.64ms (95%), errors: 0.00, reconnects:  0.00
[1783s] threads: 64, tps: 1914.00, reads: 26621.06, writes: 7592.02, response time: 47.92ms (95%), errors: 0.00, reconnects:  0.00
[1784s] threads: 64, tps: 1907.00, reads: 26750.99, writes: 7642.00, response time: 46.07ms (95%), errors: 0.00, reconnects:  0.00
[1785s] threads: 64, tps: 1919.00, reads: 26811.97, writes: 7679.99, response time: 47.29ms (95%), errors: 0.00, reconnects:  0.00
[1786s] threads: 64, tps: 1820.00, reads: 25530.01, writes: 7322.00, response time: 49.18ms (95%), errors: 0.00, reconnects:  0.00
[1787s] threads: 64, tps: 1820.00, reads: 25470.01, writes: 7265.00, response time: 48.94ms (95%), errors: 0.00, reconnects:  0.00
[1788s] threads: 64, tps: 1796.99, reads: 25250.89, writes: 7215.97, response time: 50.70ms (95%), errors: 0.00, reconnects:  0.00
[1789s] threads: 64, tps: 1964.00, reads: 27384.99, writes: 7812.00, response time: 47.32ms (95%), errors: 0.00, reconnects:  0.00
[1790s] threads: 64, tps: 1910.00, reads: 26869.99, writes: 7693.00, response time: 47.42ms (95%), errors: 0.00, reconnects:  0.00
[1791s] threads: 64, tps: 1767.99, reads: 24566.91, writes: 7003.98, response time: 51.38ms (95%), errors: 0.00, reconnects:  0.00
[1792s] threads: 64, tps: 1807.02, reads: 25433.21, writes: 7274.06, response time: 49.39ms (95%), errors: 0.00, reconnects:  0.00
[1793s] threads: 64, tps: 1706.99, reads: 23782.86, writes: 6761.96, response time: 51.61ms (95%), errors: 0.00, reconnects:  0.00
[1794s] threads: 64, tps: 1698.01, reads: 23865.13, writes: 6874.04, response time: 54.66ms (95%), errors: 0.00, reconnects:  0.00
[1795s] threads: 64, tps: 1829.99, reads: 25587.89, writes: 7274.97, response time: 49.17ms (95%), errors: 0.00, reconnects:  0.00
[1796s] threads: 64, tps: 1853.01, reads: 25951.13, writes: 7427.04, response time: 48.17ms (95%), errors: 0.00, reconnects:  0.00
[1797s] threads: 64, tps: 1795.96, reads: 25208.40, writes: 7150.83, response time: 47.89ms (95%), errors: 0.00, reconnects:  0.00
[1798s] threads: 64, tps: 1760.03, reads: 24501.41, writes: 7022.12, response time: 50.18ms (95%), errors: 0.00, reconnects:  0.00
[1799s] threads: 64, tps: 1702.01, reads: 23912.18, writes: 6805.05, response time: 51.12ms (95%), errors: 0.00, reconnects:  0.00
[1800s] threads: 64, tps: 1621.00, reads: 22662.95, writes: 6483.99, response time: 56.68ms (95%), errors: 0.00, reconnects:  0.00
[1801s] threads: 64, tps: 1547.99, reads: 21730.93, writes: 6179.98, response time: 54.76ms (95%), errors: 0.00, reconnects:  0.00
[1802s] threads: 64, tps: 1570.00, reads: 21970.02, writes: 6295.00, response time: 55.35ms (95%), errors: 0.00, reconnects:  0.00
[1803s] threads: 64, tps: 1579.01, reads: 22057.10, writes: 6334.03, response time: 55.34ms (95%), errors: 0.00, reconnects:  0.00
[1804s] threads: 64, tps: 1595.00, reads: 22322.98, writes: 6361.99, response time: 55.87ms (95%), errors: 0.00, reconnects:  0.00
[1805s] threads: 64, tps: 1694.99, reads: 23729.89, writes: 6827.97, response time: 53.64ms (95%), errors: 0.00, reconnects:  0.00
[1806s] threads: 64, tps: 1593.00, reads: 22311.02, writes: 6369.01, response time: 55.52ms (95%), errors: 0.00, reconnects:  0.00
[1807s] threads: 64, tps: 1601.00, reads: 22305.00, writes: 6387.00, response time: 56.49ms (95%), errors: 0.00, reconnects:  0.00
[1808s] threads: 64, tps: 1681.88, reads: 23666.31, writes: 6791.52, response time: 54.03ms (95%), errors: 0.00, reconnects:  0.00
[1809s] threads: 64, tps: 1699.13, reads: 23946.79, writes: 6838.51, response time: 55.44ms (95%), errors: 0.00, reconnects:  0.00
[1810s] threads: 64, tps: 1694.99, reads: 23457.92, writes: 6627.98, response time: 55.35ms (95%), errors: 0.00, reconnects:  0.00
[1811s] threads: 64, tps: 1523.01, reads: 21296.08, writes: 6104.02, response time: 57.57ms (95%), errors: 0.00, reconnects:  0.00
[1812s] threads: 64, tps: 1483.99, reads: 20943.92, writes: 5959.98, response time: 58.80ms (95%), errors: 0.00, reconnects:  0.00
[1813s] threads: 64, tps: 1755.01, reads: 24477.08, writes: 7019.02, response time: 52.84ms (95%), errors: 0.00, reconnects:  0.00
[1814s] threads: 64, tps: 1808.00, reads: 25389.02, writes: 7270.01, response time: 50.36ms (95%), errors: 0.00, reconnects:  0.00
[1815s] threads: 64, tps: 1821.99, reads: 25594.88, writes: 7345.96, response time: 49.46ms (95%), errors: 0.00, reconnects:  0.00
[1816s] threads: 64, tps: 1879.01, reads: 26321.16, writes: 7529.05, response time: 47.73ms (95%), errors: 0.00, reconnects:  0.00
[1817s] threads: 64, tps: 1875.99, reads: 26138.88, writes: 7432.97, response time: 48.22ms (95%), errors: 0.00, reconnects:  0.00
[1818s] threads: 64, tps: 1801.00, reads: 25186.07, writes: 7179.02, response time: 50.12ms (95%), errors: 0.00, reconnects:  0.00
[1819s] threads: 64, tps: 1814.00, reads: 25429.01, writes: 7254.00, response time: 48.73ms (95%), errors: 0.00, reconnects:  0.00
[1820s] threads: 64, tps: 1806.00, reads: 25195.02, writes: 7195.00, response time: 49.88ms (95%), errors: 0.00, reconnects:  0.00
[1821s] threads: 64, tps: 1823.99, reads: 25667.87, writes: 7355.96, response time: 48.71ms (95%), errors: 0.00, reconnects:  0.00
[1822s] threads: 64, tps: 1845.01, reads: 25766.11, writes: 7389.03, response time: 49.77ms (95%), errors: 0.00, reconnects:  0.00
[1823s] threads: 64, tps: 1834.00, reads: 25643.99, writes: 7302.00, response time: 49.76ms (95%), errors: 0.00, reconnects:  0.00
[1824s] threads: 64, tps: 1865.00, reads: 26071.01, writes: 7432.00, response time: 48.32ms (95%), errors: 0.00, reconnects:  0.00
[1825s] threads: 64, tps: 1691.99, reads: 23759.91, writes: 6780.98, response time: 55.73ms (95%), errors: 0.00, reconnects:  0.00
[1826s] threads: 64, tps: 1756.01, reads: 24637.08, writes: 7009.02, response time: 51.73ms (95%), errors: 0.00, reconnects:  0.00
[1827s] threads: 64, tps: 1810.95, reads: 25308.30, writes: 7232.80, response time: 50.28ms (95%), errors: 0.00, reconnects:  0.00
[1828s] threads: 64, tps: 1673.05, reads: 23401.67, writes: 6692.19, response time: 55.58ms (95%), errors: 0.00, reconnects:  0.00
[1829s] threads: 64, tps: 1651.00, reads: 23250.02, writes: 6675.01, response time: 56.66ms (95%), errors: 0.00, reconnects:  0.00
[1830s] threads: 64, tps: 1673.00, reads: 23350.00, writes: 6632.00, response time: 52.67ms (95%), errors: 0.00, reconnects:  0.00
[1831s] threads: 64, tps: 1651.00, reads: 23024.00, writes: 6629.00, response time: 53.46ms (95%), errors: 0.00, reconnects:  0.00
[1832s] threads: 64, tps: 1722.99, reads: 24216.89, writes: 6863.97, response time: 50.92ms (95%), errors: 0.00, reconnects:  0.00
[1833s] threads: 64, tps: 1789.00, reads: 25020.03, writes: 7191.01, response time: 49.12ms (95%), errors: 0.00, reconnects:  0.00
[1834s] threads: 64, tps: 1878.00, reads: 26327.03, writes: 7501.01, response time: 46.54ms (95%), errors: 0.00, reconnects:  0.00
[1835s] threads: 64, tps: 1855.00, reads: 25974.97, writes: 7445.99, response time: 48.86ms (95%), errors: 0.00, reconnects:  0.00
[1836s] threads: 64, tps: 1936.01, reads: 26997.10, writes: 7701.03, response time: 47.37ms (95%), errors: 0.00, reconnects:  0.00
[1837s] threads: 64, tps: 1930.00, reads: 27095.97, writes: 7765.99, response time: 47.89ms (95%), errors: 0.00, reconnects:  0.00
[1838s] threads: 64, tps: 1902.99, reads: 26613.91, writes: 7620.97, response time: 47.36ms (95%), errors: 0.00, reconnects:  0.00
[1839s] threads: 64, tps: 1860.01, reads: 26026.11, writes: 7394.03, response time: 48.59ms (95%), errors: 0.00, reconnects:  0.00
[1840s] threads: 64, tps: 1993.00, reads: 27941.97, writes: 8024.99, response time: 44.42ms (95%), errors: 0.00, reconnects:  0.00
[1841s] threads: 64, tps: 2028.00, reads: 28243.98, writes: 8046.99, response time: 45.37ms (95%), errors: 0.00, reconnects:  0.00
[1842s] threads: 64, tps: 2008.00, reads: 28312.05, writes: 8088.01, response time: 43.40ms (95%), errors: 0.00, reconnects:  0.00
[1843s] threads: 64, tps: 2041.00, reads: 28435.99, writes: 8150.00, response time: 46.87ms (95%), errors: 0.00, reconnects:  0.00
[1844s] threads: 64, tps: 1985.00, reads: 27816.98, writes: 7885.99, response time: 47.19ms (95%), errors: 0.00, reconnects:  0.00
[1845s] threads: 64, tps: 2020.00, reads: 28275.94, writes: 8119.98, response time: 46.41ms (95%), errors: 0.00, reconnects:  0.00
[1846s] threads: 64, tps: 2203.98, reads: 30935.70, writes: 8878.91, response time: 41.49ms (95%), errors: 0.00, reconnects:  0.00
[1847s] threads: 64, tps: 2119.02, reads: 29636.32, writes: 8412.09, response time: 44.86ms (95%), errors: 0.00, reconnects:  0.00
[1848s] threads: 64, tps: 1991.00, reads: 27878.04, writes: 7955.01, response time: 46.88ms (95%), errors: 0.00, reconnects:  0.00
[1849s] threads: 64, tps: 1973.00, reads: 27760.03, writes: 7999.01, response time: 47.13ms (95%), errors: 0.00, reconnects:  0.00
[1850s] threads: 64, tps: 1970.94, reads: 27302.11, writes: 7763.75, response time: 54.20ms (95%), errors: 0.00, reconnects:  0.00
[1851s] threads: 64, tps: 2005.05, reads: 28254.76, writes: 8039.22, response time: 46.64ms (95%), errors: 0.00, reconnects:  0.00
[1852s] threads: 64, tps: 2097.01, reads: 29272.13, writes: 8369.04, response time: 45.88ms (95%), errors: 0.00, reconnects:  0.00
[1853s] threads: 64, tps: 1989.00, reads: 27831.02, writes: 7950.01, response time: 46.24ms (95%), errors: 0.00, reconnects:  0.00
[1854s] threads: 64, tps: 1941.00, reads: 27325.03, writes: 7818.01, response time: 47.54ms (95%), errors: 0.00, reconnects:  0.00
[1855s] threads: 64, tps: 1853.00, reads: 25809.99, writes: 7340.00, response time: 51.13ms (95%), errors: 0.00, reconnects:  0.00
[1856s] threads: 64, tps: 1653.00, reads: 23247.00, writes: 6653.00, response time: 55.79ms (95%), errors: 0.00, reconnects:  0.00
[1857s] threads: 64, tps: 1772.00, reads: 24770.98, writes: 7056.99, response time: 55.63ms (95%), errors: 0.00, reconnects:  0.00
[1858s] threads: 64, tps: 1808.00, reads: 25324.00, writes: 7243.00, response time: 49.42ms (95%), errors: 0.00, reconnects:  0.00
[1859s] threads: 64, tps: 1869.00, reads: 26128.97, writes: 7468.99, response time: 48.35ms (95%), errors: 0.00, reconnects:  0.00
[1860s] threads: 64, tps: 1865.00, reads: 26092.02, writes: 7461.01, response time: 48.07ms (95%), errors: 0.00, reconnects:  0.00
[1861s] threads: 64, tps: 1865.00, reads: 26048.03, writes: 7513.01, response time: 50.27ms (95%), errors: 0.00, reconnects:  0.00
[1862s] threads: 64, tps: 1951.00, reads: 27364.99, writes: 7811.00, response time: 48.19ms (95%), errors: 0.00, reconnects:  0.00
[1863s] threads: 64, tps: 2109.99, reads: 29651.84, writes: 8472.95, response time: 43.81ms (95%), errors: 0.00, reconnects:  0.00
[1864s] threads: 64, tps: 2091.01, reads: 29079.15, writes: 8254.04, response time: 45.58ms (95%), errors: 0.00, reconnects:  0.00
[1865s] threads: 64, tps: 2073.00, reads: 29110.98, writes: 8356.00, response time: 44.94ms (95%), errors: 0.00, reconnects:  0.00
[1866s] threads: 64, tps: 2117.00, reads: 29547.98, writes: 8472.99, response time: 44.41ms (95%), errors: 0.00, reconnects:  0.00
[1867s] threads: 64, tps: 2102.00, reads: 29501.02, writes: 8392.00, response time: 43.16ms (95%), errors: 0.00, reconnects:  0.00
[1868s] threads: 64, tps: 2178.00, reads: 30658.00, writes: 8766.00, response time: 43.72ms (95%), errors: 0.00, reconnects:  0.00
[1869s] threads: 64, tps: 2190.00, reads: 30380.05, writes: 8679.01, response time: 44.94ms (95%), errors: 0.00, reconnects:  0.00
[1870s] threads: 64, tps: 2174.00, reads: 30594.95, writes: 8739.99, response time: 42.33ms (95%), errors: 0.00, reconnects:  0.00
[1871s] threads: 64, tps: 2277.00, reads: 31780.97, writes: 9051.99, response time: 41.90ms (95%), errors: 0.00, reconnects:  0.00
[1872s] threads: 64, tps: 2198.00, reads: 30986.03, writes: 8907.01, response time: 43.18ms (95%), errors: 0.00, reconnects:  0.00
[1873s] threads: 64, tps: 2214.00, reads: 30914.00, writes: 8821.00, response time: 43.83ms (95%), errors: 0.00, reconnects:  0.00
[1874s] threads: 64, tps: 2242.00, reads: 31355.02, writes: 8946.01, response time: 43.98ms (95%), errors: 0.00, reconnects:  0.00
[1875s] threads: 64, tps: 2068.99, reads: 29090.85, writes: 8339.96, response time: 45.21ms (95%), errors: 0.00, reconnects:  0.00
[1876s] threads: 64, tps: 2112.01, reads: 29484.09, writes: 8381.03, response time: 45.29ms (95%), errors: 0.00, reconnects:  0.00
[1877s] threads: 64, tps: 2060.00, reads: 28777.01, writes: 8230.00, response time: 47.49ms (95%), errors: 0.00, reconnects:  0.00
[1878s] threads: 64, tps: 2019.00, reads: 28162.02, writes: 8071.01, response time: 47.19ms (95%), errors: 0.00, reconnects:  0.00
[1879s] threads: 64, tps: 1986.00, reads: 27962.01, writes: 7974.00, response time: 47.27ms (95%), errors: 0.00, reconnects:  0.00
[1880s] threads: 64, tps: 2054.00, reads: 28772.98, writes: 8205.99, response time: 46.94ms (95%), errors: 0.00, reconnects:  0.00
[1881s] threads: 64, tps: 2076.00, reads: 29119.00, writes: 8322.00, response time: 45.62ms (95%), errors: 0.00, reconnects:  0.00
[1882s] threads: 64, tps: 2038.00, reads: 28459.95, writes: 8113.99, response time: 47.08ms (95%), errors: 0.00, reconnects:  0.00
[1883s] threads: 64, tps: 2043.00, reads: 28399.02, writes: 8113.01, response time: 45.84ms (95%), errors: 0.00, reconnects:  0.00
[1884s] threads: 64, tps: 1822.00, reads: 25615.05, writes: 7302.01, response time: 51.62ms (95%), errors: 0.00, reconnects:  0.00
[1885s] threads: 64, tps: 1767.00, reads: 24819.96, writes: 7080.99, response time: 51.93ms (95%), errors: 0.00, reconnects:  0.00
[1886s] threads: 64, tps: 1846.00, reads: 25803.99, writes: 7370.00, response time: 50.55ms (95%), errors: 0.00, reconnects:  0.00
[1887s] threads: 64, tps: 1838.00, reads: 25762.03, writes: 7373.01, response time: 48.28ms (95%), errors: 0.00, reconnects:  0.00
[1888s] threads: 64, tps: 1911.00, reads: 26736.00, writes: 7687.00, response time: 47.32ms (95%), errors: 0.00, reconnects:  0.00
[1889s] threads: 64, tps: 1950.00, reads: 27323.01, writes: 7766.00, response time: 46.71ms (95%), errors: 0.00, reconnects:  0.00
[1890s] threads: 64, tps: 2013.00, reads: 28154.97, writes: 8045.99, response time: 46.57ms (95%), errors: 0.00, reconnects:  0.00
[1891s] threads: 64, tps: 2005.99, reads: 28193.88, writes: 8129.97, response time: 45.88ms (95%), errors: 0.00, reconnects:  0.00
[1892s] threads: 64, tps: 1944.01, reads: 26907.14, writes: 7631.04, response time: 48.41ms (95%), errors: 0.00, reconnects:  0.00
[1893s] threads: 64, tps: 2039.00, reads: 28711.99, writes: 8193.00, response time: 44.96ms (95%), errors: 0.00, reconnects:  0.00
[1894s] threads: 64, tps: 2053.00, reads: 28793.01, writes: 8222.00, response time: 45.04ms (95%), errors: 0.00, reconnects:  0.00
[1895s] threads: 64, tps: 2022.00, reads: 28357.01, writes: 8165.00, response time: 44.74ms (95%), errors: 0.00, reconnects:  0.00
[1896s] threads: 64, tps: 2015.00, reads: 28215.97, writes: 8018.99, response time: 46.36ms (95%), errors: 0.00, reconnects:  0.00
[1897s] threads: 64, tps: 1990.00, reads: 27817.01, writes: 7896.00, response time: 46.22ms (95%), errors: 0.00, reconnects:  0.00
[1898s] threads: 64, tps: 2003.96, reads: 28092.45, writes: 8089.84, response time: 47.08ms (95%), errors: 0.00, reconnects:  0.00
[1899s] threads: 64, tps: 2118.04, reads: 29701.57, writes: 8476.16, response time: 43.25ms (95%), errors: 0.00, reconnects:  0.00
[1900s] threads: 64, tps: 2040.00, reads: 28379.01, writes: 8110.00, response time: 45.73ms (95%), errors: 0.00, reconnects:  0.00
[1901s] threads: 64, tps: 2136.00, reads: 30005.99, writes: 8557.00, response time: 42.62ms (95%), errors: 0.00, reconnects:  0.00
[1902s] threads: 64, tps: 2099.00, reads: 29329.03, writes: 8424.01, response time: 45.12ms (95%), errors: 0.00, reconnects:  0.00
[1903s] threads: 64, tps: 2037.00, reads: 28596.96, writes: 8136.99, response time: 46.64ms (95%), errors: 0.00, reconnects:  0.00
[1904s] threads: 64, tps: 2141.00, reads: 29916.00, writes: 8540.00, response time: 44.51ms (95%), errors: 0.00, reconnects:  0.00
[1905s] threads: 64, tps: 2001.99, reads: 28085.83, writes: 8043.95, response time: 46.53ms (95%), errors: 0.00, reconnects:  0.00
[1906s] threads: 64, tps: 2064.00, reads: 28891.02, writes: 8278.01, response time: 45.27ms (95%), errors: 0.00, reconnects:  0.00
[1907s] threads: 64, tps: 2080.01, reads: 29046.15, writes: 8268.04, response time: 44.50ms (95%), errors: 0.00, reconnects:  0.00
[1908s] threads: 64, tps: 2083.00, reads: 29282.98, writes: 8379.99, response time: 44.08ms (95%), errors: 0.00, reconnects:  0.00
[1909s] threads: 64, tps: 2057.00, reads: 28726.99, writes: 8188.00, response time: 43.62ms (95%), errors: 0.00, reconnects:  0.00
[1910s] threads: 64, tps: 1938.99, reads: 27127.93, writes: 7716.98, response time: 47.64ms (95%), errors: 0.00, reconnects:  0.00
[1911s] threads: 64, tps: 1776.01, reads: 24990.07, writes: 7172.02, response time: 49.88ms (95%), errors: 0.00, reconnects:  0.00
[1912s] threads: 64, tps: 1832.00, reads: 25574.04, writes: 7251.01, response time: 54.51ms (95%), errors: 0.00, reconnects:  0.00
[1913s] threads: 64, tps: 1699.00, reads: 23731.99, writes: 6796.00, response time: 52.15ms (95%), errors: 0.00, reconnects:  0.00
[1914s] threads: 64, tps: 1778.95, reads: 24841.32, writes: 7111.81, response time: 48.55ms (95%), errors: 0.00, reconnects:  0.00
[1915s] threads: 64, tps: 1754.05, reads: 24563.64, writes: 7017.18, response time: 50.46ms (95%), errors: 0.00, reconnects:  0.00
[1916s] threads: 64, tps: 1773.00, reads: 24894.03, writes: 7129.01, response time: 50.22ms (95%), errors: 0.00, reconnects:  0.00
[1917s] threads: 64, tps: 1856.00, reads: 25952.98, writes: 7403.99, response time: 48.32ms (95%), errors: 0.00, reconnects:  0.00
[1918s] threads: 64, tps: 1926.00, reads: 26941.00, writes: 7767.00, response time: 46.80ms (95%), errors: 0.00, reconnects:  0.00
[1919s] threads: 64, tps: 1923.00, reads: 27053.99, writes: 7678.00, response time: 46.35ms (95%), errors: 0.00, reconnects:  0.00
[1920s] threads: 64, tps: 1983.00, reads: 27667.02, writes: 7937.00, response time: 47.77ms (95%), errors: 0.00, reconnects:  0.00
[1921s] threads: 64, tps: 2046.00, reads: 28694.02, writes: 8197.01, response time: 45.35ms (95%), errors: 0.00, reconnects:  0.00
[1922s] threads: 64, tps: 2021.00, reads: 28351.03, writes: 8089.01, response time: 45.13ms (95%), errors: 0.00, reconnects:  0.00
[1923s] threads: 64, tps: 2097.00, reads: 29186.98, writes: 8376.99, response time: 43.16ms (95%), errors: 0.00, reconnects:  0.00
[1924s] threads: 64, tps: 2116.00, reads: 29794.01, writes: 8491.00, response time: 41.88ms (95%), errors: 0.00, reconnects:  0.00
[1925s] threads: 64, tps: 2069.00, reads: 28794.96, writes: 8179.99, response time: 45.92ms (95%), errors: 0.00, reconnects:  0.00
[1926s] threads: 64, tps: 2143.00, reads: 30055.00, writes: 8568.00, response time: 43.24ms (95%), errors: 0.00, reconnects:  0.00
[1927s] threads: 64, tps: 2098.75, reads: 29380.55, writes: 8405.01, response time: 42.10ms (95%), errors: 0.00, reconnects:  0.00
[1928s] threads: 64, tps: 2184.84, reads: 30632.73, writes: 8791.31, response time: 40.74ms (95%), errors: 0.00, reconnects:  0.00
[1929s] threads: 64, tps: 2146.37, reads: 30018.21, writes: 8545.45, response time: 42.29ms (95%), errors: 0.00, reconnects:  0.00
[1930s] threads: 64, tps: 2138.00, reads: 29890.00, writes: 8574.00, response time: 44.29ms (95%), errors: 0.00, reconnects:  0.00
[1931s] threads: 64, tps: 2154.00, reads: 30203.00, writes: 8605.00, response time: 40.68ms (95%), errors: 0.00, reconnects:  0.00
[1932s] threads: 64, tps: 2097.00, reads: 29411.01, writes: 8447.00, response time: 42.80ms (95%), errors: 0.00, reconnects:  0.00
[1933s] threads: 64, tps: 2035.00, reads: 28446.95, writes: 8081.99, response time: 43.93ms (95%), errors: 0.00, reconnects:  0.00
[1934s] threads: 64, tps: 2008.00, reads: 28193.02, writes: 8084.01, response time: 44.96ms (95%), errors: 0.00, reconnects:  0.00
[1935s] threads: 64, tps: 2028.00, reads: 28217.99, writes: 8043.00, response time: 45.42ms (95%), errors: 0.00, reconnects:  0.00
[1936s] threads: 64, tps: 2027.00, reads: 28444.99, writes: 8114.00, response time: 44.26ms (95%), errors: 0.00, reconnects:  0.00
[1937s] threads: 64, tps: 2066.00, reads: 29007.01, writes: 8301.00, response time: 43.23ms (95%), errors: 0.00, reconnects:  0.00
[1938s] threads: 64, tps: 1958.99, reads: 27241.90, writes: 7795.97, response time: 47.67ms (95%), errors: 0.00, reconnects:  0.00
[1939s] threads: 64, tps: 1848.01, reads: 26005.09, writes: 7361.03, response time: 48.30ms (95%), errors: 0.00, reconnects:  0.00
[1940s] threads: 64, tps: 1796.00, reads: 25230.00, writes: 7274.00, response time: 50.63ms (95%), errors: 0.00, reconnects:  0.00
[1941s] threads: 64, tps: 1703.00, reads: 23825.98, writes: 6754.99, response time: 54.09ms (95%), errors: 0.00, reconnects:  0.00
[1942s] threads: 64, tps: 1723.99, reads: 24064.93, writes: 6890.98, response time: 52.40ms (95%), errors: 0.00, reconnects:  0.00
[1943s] threads: 64, tps: 1731.01, reads: 24217.13, writes: 6900.04, response time: 51.27ms (95%), errors: 0.00, reconnects:  0.00
[1944s] threads: 64, tps: 1733.00, reads: 24296.95, writes: 6977.99, response time: 50.15ms (95%), errors: 0.00, reconnects:  0.00
[1945s] threads: 64, tps: 1794.00, reads: 25149.02, writes: 7215.00, response time: 51.87ms (95%), errors: 0.00, reconnects:  0.00
[1946s] threads: 64, tps: 1805.00, reads: 25166.99, writes: 7167.00, response time: 50.34ms (95%), errors: 0.00, reconnects:  0.00
[1947s] threads: 64, tps: 1692.00, reads: 23683.94, writes: 6781.98, response time: 55.54ms (95%), errors: 0.00, reconnects:  0.00
[1948s] threads: 64, tps: 1804.01, reads: 25282.10, writes: 7220.03, response time: 50.15ms (95%), errors: 0.00, reconnects:  0.00
[1949s] threads: 64, tps: 1846.00, reads: 25956.96, writes: 7439.99, response time: 48.96ms (95%), errors: 0.00, reconnects:  0.00
[1950s] threads: 64, tps: 1832.00, reads: 25418.06, writes: 7231.02, response time: 50.58ms (95%), errors: 0.00, reconnects:  0.00
[1951s] threads: 64, tps: 1824.00, reads: 25501.94, writes: 7272.98, response time: 48.80ms (95%), errors: 0.00, reconnects:  0.00
[1952s] threads: 64, tps: 1781.00, reads: 25033.05, writes: 7169.02, response time: 51.81ms (95%), errors: 0.00, reconnects:  0.00
[1953s] threads: 64, tps: 1971.00, reads: 27736.96, writes: 7937.99, response time: 46.27ms (95%), errors: 0.00, reconnects:  0.00
[1954s] threads: 64, tps: 2009.00, reads: 28097.98, writes: 7986.99, response time: 44.93ms (95%), errors: 0.00, reconnects:  0.00
[1955s] threads: 64, tps: 1961.99, reads: 27526.87, writes: 7897.96, response time: 45.54ms (95%), errors: 0.00, reconnects:  0.00
[1956s] threads: 64, tps: 1949.01, reads: 27263.19, writes: 7829.06, response time: 46.45ms (95%), errors: 0.00, reconnects:  0.00
[1957s] threads: 64, tps: 1918.00, reads: 26734.98, writes: 7618.99, response time: 49.27ms (95%), errors: 0.00, reconnects:  0.00
[1958s] threads: 64, tps: 1918.99, reads: 26921.88, writes: 7651.97, response time: 46.43ms (95%), errors: 0.00, reconnects:  0.00
[1959s] threads: 64, tps: 1926.01, reads: 26862.12, writes: 7717.04, response time: 47.47ms (95%), errors: 0.00, reconnects:  0.00
[1960s] threads: 64, tps: 1962.00, reads: 27583.98, writes: 7864.00, response time: 45.39ms (95%), errors: 0.00, reconnects:  0.00
[1961s] threads: 64, tps: 1943.00, reads: 27162.01, writes: 7721.00, response time: 47.74ms (95%), errors: 0.00, reconnects:  0.00
[1962s] threads: 64, tps: 1971.99, reads: 27592.84, writes: 7921.95, response time: 46.20ms (95%), errors: 0.00, reconnects:  0.00
[1963s] threads: 64, tps: 1857.01, reads: 25890.14, writes: 7388.04, response time: 53.24ms (95%), errors: 0.00, reconnects:  0.00
[1964s] threads: 64, tps: 1947.00, reads: 27377.99, writes: 7838.00, response time: 45.98ms (95%), errors: 0.00, reconnects:  0.00
[1965s] threads: 64, tps: 1970.00, reads: 27571.00, writes: 7899.00, response time: 45.14ms (95%), errors: 0.00, reconnects:  0.00
[1966s] threads: 64, tps: 1864.00, reads: 26197.00, writes: 7458.00, response time: 47.87ms (95%), errors: 0.00, reconnects:  0.00
[1967s] threads: 64, tps: 1740.98, reads: 24215.76, writes: 6910.93, response time: 54.58ms (95%), errors: 0.00, reconnects:  0.00
[1968s] threads: 64, tps: 1678.02, reads: 23444.26, writes: 6667.07, response time: 55.97ms (95%), errors: 0.00, reconnects:  0.00
[1969s] threads: 64, tps: 1545.00, reads: 21729.96, writes: 6199.99, response time: 58.02ms (95%), errors: 0.00, reconnects:  0.00
[1970s] threads: 64, tps: 1620.71, reads: 22695.88, writes: 6470.83, response time: 57.12ms (95%), errors: 0.00, reconnects:  0.00
[1971s] threads: 64, tps: 1603.91, reads: 22535.77, writes: 6440.65, response time: 60.99ms (95%), errors: 0.00, reconnects:  0.00
[1972s] threads: 64, tps: 1650.39, reads: 23071.47, writes: 6610.57, response time: 55.25ms (95%), errors: 0.00, reconnects:  0.00
[1973s] threads: 64, tps: 1664.00, reads: 23327.00, writes: 6635.00, response time: 53.80ms (95%), errors: 0.00, reconnects:  0.00
[1974s] threads: 64, tps: 1696.00, reads: 23739.03, writes: 6805.01, response time: 52.53ms (95%), errors: 0.00, reconnects:  0.00
[1975s] threads: 64, tps: 1767.00, reads: 24654.98, writes: 7042.99, response time: 51.67ms (95%), errors: 0.00, reconnects:  0.00
[1976s] threads: 64, tps: 1780.00, reads: 25002.97, writes: 7169.99, response time: 49.56ms (95%), errors: 0.00, reconnects:  0.00
[1977s] threads: 64, tps: 1916.00, reads: 26687.02, writes: 7678.01, response time: 48.78ms (95%), errors: 0.00, reconnects:  0.00
[1978s] threads: 64, tps: 1853.00, reads: 25961.97, writes: 7393.99, response time: 49.83ms (95%), errors: 0.00, reconnects:  0.00
[1979s] threads: 64, tps: 1895.97, reads: 26607.64, writes: 7582.90, response time: 49.89ms (95%), errors: 0.00, reconnects:  0.00
[1980s] threads: 64, tps: 1999.03, reads: 28032.39, writes: 8038.11, response time: 44.26ms (95%), errors: 0.00, reconnects:  0.00
[1981s] threads: 64, tps: 2100.00, reads: 29116.02, writes: 8301.00, response time: 43.76ms (95%), errors: 0.00, reconnects:  0.00
[1982s] threads: 64, tps: 2009.00, reads: 28178.03, writes: 8051.01, response time: 46.80ms (95%), errors: 0.00, reconnects:  0.00
[1983s] threads: 64, tps: 1865.00, reads: 26370.95, writes: 7531.99, response time: 52.15ms (95%), errors: 0.00, reconnects:  0.00
[1984s] threads: 64, tps: 1890.00, reads: 26358.04, writes: 7532.01, response time: 51.35ms (95%), errors: 0.00, reconnects:  0.00
[1985s] threads: 64, tps: 1968.00, reads: 27608.00, writes: 7902.00, response time: 48.68ms (95%), errors: 0.00, reconnects:  0.00
[1986s] threads: 64, tps: 2045.95, reads: 28595.34, writes: 8155.81, response time: 46.07ms (95%), errors: 0.00, reconnects:  0.00
[1987s] threads: 64, tps: 2131.05, reads: 29832.69, writes: 8508.20, response time: 43.41ms (95%), errors: 0.00, reconnects:  0.00
[1988s] threads: 64, tps: 2184.00, reads: 30500.99, writes: 8792.00, response time: 43.50ms (95%), errors: 0.00, reconnects:  0.00
[1989s] threads: 64, tps: 2020.00, reads: 28311.99, writes: 8012.00, response time: 49.58ms (95%), errors: 0.00, reconnects:  0.00
[1990s] threads: 64, tps: 2180.00, reads: 30556.00, writes: 8709.00, response time: 44.58ms (95%), errors: 0.00, reconnects:  0.00
[1991s] threads: 64, tps: 2160.00, reads: 30240.01, writes: 8667.00, response time: 49.40ms (95%), errors: 0.00, reconnects:  0.00
[1992s] threads: 64, tps: 2138.00, reads: 29950.00, writes: 8592.00, response time: 44.29ms (95%), errors: 0.00, reconnects:  0.00
[1993s] threads: 64, tps: 2137.00, reads: 30004.02, writes: 8572.01, response time: 43.72ms (95%), errors: 0.00, reconnects:  0.00
[1994s] threads: 64, tps: 2089.00, reads: 29123.01, writes: 8259.00, response time: 44.61ms (95%), errors: 0.00, reconnects:  0.00
[1995s] threads: 64, tps: 2083.99, reads: 29365.85, writes: 8485.96, response time: 43.88ms (95%), errors: 0.00, reconnects:  0.00
[1996s] threads: 64, tps: 2181.01, reads: 30421.13, writes: 8668.04, response time: 42.41ms (95%), errors: 0.00, reconnects:  0.00
[1997s] threads: 64, tps: 2103.00, reads: 29386.00, writes: 8318.00, response time: 44.69ms (95%), errors: 0.00, reconnects:  0.00
[1998s] threads: 64, tps: 2118.00, reads: 29790.02, writes: 8587.01, response time: 46.28ms (95%), errors: 0.00, reconnects:  0.00
[1999s] threads: 64, tps: 1812.00, reads: 25234.01, writes: 7137.00, response time: 56.59ms (95%), errors: 0.00, reconnects:  0.00
[2000s] threads: 64, tps: 1842.00, reads: 25729.95, writes: 7385.99, response time: 55.89ms (95%), errors: 0.00, reconnects:  0.00
[2001s] threads: 64, tps: 1880.00, reads: 26402.98, writes: 7487.00, response time: 53.69ms (95%), errors: 0.00, reconnects:  0.00
[2002s] threads: 64, tps: 1845.00, reads: 25845.05, writes: 7373.02, response time: 51.79ms (95%), errors: 0.00, reconnects:  0.00
[2003s] threads: 64, tps: 1908.00, reads: 26699.96, writes: 7647.99, response time: 48.49ms (95%), errors: 0.00, reconnects:  0.00
[2004s] threads: 64, tps: 1795.00, reads: 25135.03, writes: 7185.01, response time: 53.67ms (95%), errors: 0.00, reconnects:  0.00
[2005s] threads: 64, tps: 1923.00, reads: 26869.96, writes: 7683.99, response time: 53.77ms (95%), errors: 0.00, reconnects:  0.00
[2006s] threads: 64, tps: 1888.00, reads: 26490.05, writes: 7605.01, response time: 51.19ms (95%), errors: 0.00, reconnects:  0.00
[2007s] threads: 64, tps: 2003.00, reads: 28147.01, writes: 8063.00, response time: 47.66ms (95%), errors: 0.00, reconnects:  0.00
[2008s] threads: 64, tps: 2091.00, reads: 29169.94, writes: 8363.98, response time: 46.49ms (95%), errors: 0.00, reconnects:  0.00
[2009s] threads: 64, tps: 2083.00, reads: 29172.05, writes: 8303.01, response time: 44.01ms (95%), errors: 0.00, reconnects:  0.00
[2010s] threads: 64, tps: 2138.00, reads: 29836.01, writes: 8524.00, response time: 44.35ms (95%), errors: 0.00, reconnects:  0.00
[2011s] threads: 64, tps: 2083.99, reads: 29290.92, writes: 8362.98, response time: 49.33ms (95%), errors: 0.00, reconnects:  0.00
[2012s] threads: 64, tps: 2103.00, reads: 29322.06, writes: 8348.02, response time: 45.05ms (95%), errors: 0.00, reconnects:  0.00
[2013s] threads: 64, tps: 2045.96, reads: 28794.45, writes: 8341.84, response time: 48.52ms (95%), errors: 0.00, reconnects:  0.00
[2014s] threads: 64, tps: 2126.04, reads: 29775.56, writes: 8351.16, response time: 46.21ms (95%), errors: 0.00, reconnects:  0.00
[2015s] threads: 64, tps: 2116.00, reads: 29540.93, writes: 8548.98, response time: 49.61ms (95%), errors: 0.00, reconnects:  0.00
[2016s] threads: 64, tps: 2218.97, reads: 31087.57, writes: 8834.88, response time: 43.47ms (95%), errors: 0.00, reconnects:  0.00
[2017s] threads: 64, tps: 1918.03, reads: 26817.43, writes: 7664.12, response time: 64.06ms (95%), errors: 0.00, reconnects:  0.00
[2018s] threads: 64, tps: 1945.00, reads: 27268.95, writes: 7774.99, response time: 53.26ms (95%), errors: 0.00, reconnects:  0.00
[2019s] threads: 64, tps: 2070.00, reads: 29032.04, writes: 8312.01, response time: 45.20ms (95%), errors: 0.00, reconnects:  0.00
[2020s] threads: 64, tps: 2071.00, reads: 29002.98, writes: 8287.99, response time: 48.80ms (95%), errors: 0.00, reconnects:  0.00
[2021s] threads: 64, tps: 2130.00, reads: 29782.02, writes: 8500.01, response time: 43.77ms (95%), errors: 0.00, reconnects:  0.00
[2022s] threads: 64, tps: 2104.00, reads: 29340.02, writes: 8392.00, response time: 44.75ms (95%), errors: 0.00, reconnects:  0.00
[2023s] threads: 64, tps: 2037.00, reads: 28604.99, writes: 8189.00, response time: 45.31ms (95%), errors: 0.00, reconnects:  0.00
[2024s] threads: 64, tps: 1958.00, reads: 27520.98, writes: 7868.99, response time: 47.43ms (95%), errors: 0.00, reconnects:  0.00
[2025s] threads: 64, tps: 2045.00, reads: 28595.05, writes: 8158.01, response time: 46.47ms (95%), errors: 0.00, reconnects:  0.00
[2026s] threads: 64, tps: 1944.96, reads: 26997.43, writes: 7696.84, response time: 52.00ms (95%), errors: 0.00, reconnects:  0.00
[2027s] threads: 64, tps: 1822.04, reads: 25626.52, writes: 7304.15, response time: 53.58ms (95%), errors: 0.00, reconnects:  0.00
[2028s] threads: 64, tps: 1823.00, reads: 25604.01, writes: 7354.00, response time: 52.53ms (95%), errors: 0.00, reconnects:  0.00
[2029s] threads: 64, tps: 1871.00, reads: 25847.00, writes: 7409.00, response time: 48.77ms (95%), errors: 0.00, reconnects:  0.00
[2030s] threads: 64, tps: 1811.99, reads: 25628.89, writes: 7220.97, response time: 50.55ms (95%), errors: 0.00, reconnects:  0.00
[2031s] threads: 64, tps: 1725.01, reads: 24185.11, writes: 6903.03, response time: 55.58ms (95%), errors: 0.00, reconnects:  0.00
[2032s] threads: 64, tps: 1725.00, reads: 24160.98, writes: 6918.99, response time: 56.85ms (95%), errors: 0.00, reconnects:  0.00
[2033s] threads: 64, tps: 1732.00, reads: 24163.98, writes: 6929.00, response time: 50.34ms (95%), errors: 0.00, reconnects:  0.00
[2034s] threads: 64, tps: 1733.00, reads: 24252.07, writes: 6943.02, response time: 52.15ms (95%), errors: 0.00, reconnects:  0.00
[2035s] threads: 64, tps: 1704.00, reads: 23918.98, writes: 6833.99, response time: 56.29ms (95%), errors: 0.00, reconnects:  0.00
[2036s] threads: 64, tps: 1774.00, reads: 24846.95, writes: 7153.99, response time: 54.82ms (95%), errors: 0.00, reconnects:  0.00
[2037s] threads: 64, tps: 1885.00, reads: 26427.03, writes: 7528.01, response time: 51.53ms (95%), errors: 0.00, reconnects:  0.00
[2038s] threads: 64, tps: 1893.00, reads: 26433.98, writes: 7533.00, response time: 48.13ms (95%), errors: 0.00, reconnects:  0.00
[2039s] threads: 64, tps: 1889.00, reads: 26619.99, writes: 7661.00, response time: 50.31ms (95%), errors: 0.00, reconnects:  0.00
[2040s] threads: 64, tps: 1876.00, reads: 26233.05, writes: 7477.01, response time: 51.32ms (95%), errors: 0.00, reconnects:  0.00
[2041s] threads: 64, tps: 1794.99, reads: 25002.88, writes: 7107.97, response time: 53.18ms (95%), errors: 0.00, reconnects:  0.00
[2042s] threads: 64, tps: 1950.00, reads: 27461.00, writes: 7868.00, response time: 46.74ms (95%), errors: 0.00, reconnects:  0.00
[2043s] threads: 64, tps: 1970.00, reads: 27507.95, writes: 7808.98, response time: 47.13ms (95%), errors: 0.00, reconnects:  0.00
[2044s] threads: 64, tps: 2000.00, reads: 27995.01, writes: 8048.00, response time: 46.05ms (95%), errors: 0.00, reconnects:  0.00
[2045s] threads: 64, tps: 1929.01, reads: 26888.13, writes: 7678.04, response time: 46.81ms (95%), errors: 0.00, reconnects:  0.00
[2046s] threads: 64, tps: 1993.99, reads: 28083.89, writes: 8027.97, response time: 47.13ms (95%), errors: 0.00, reconnects:  0.00
[2047s] threads: 64, tps: 2086.98, reads: 29207.66, writes: 8345.90, response time: 43.20ms (95%), errors: 0.00, reconnects:  0.00
[2048s] threads: 64, tps: 2123.02, reads: 29613.32, writes: 8471.09, response time: 43.75ms (95%), errors: 0.00, reconnects:  0.00
[2049s] threads: 64, tps: 2128.01, reads: 29860.13, writes: 8503.04, response time: 44.33ms (95%), errors: 0.00, reconnects:  0.00
[2050s] threads: 64, tps: 2171.00, reads: 30167.03, writes: 8648.01, response time: 41.50ms (95%), errors: 0.00, reconnects:  0.00
[2051s] threads: 64, tps: 2098.00, reads: 29532.00, writes: 8396.00, response time: 44.41ms (95%), errors: 0.00, reconnects:  0.00
[2052s] threads: 64, tps: 1883.00, reads: 26136.00, writes: 7500.00, response time: 48.65ms (95%), errors: 0.00, reconnects:  0.00
[2053s] threads: 64, tps: 1897.00, reads: 26808.00, writes: 7656.00, response time: 45.92ms (95%), errors: 0.00, reconnects:  0.00
[2054s] threads: 64, tps: 2008.00, reads: 28009.02, writes: 7982.01, response time: 46.00ms (95%), errors: 0.00, reconnects:  0.00
[2055s] threads: 64, tps: 1982.00, reads: 27959.02, writes: 8007.01, response time: 45.28ms (95%), errors: 0.00, reconnects:  0.00
[2056s] threads: 64, tps: 2070.00, reads: 28716.93, writes: 8202.98, response time: 45.16ms (95%), errors: 0.00, reconnects:  0.00
[2057s] threads: 64, tps: 2047.00, reads: 28763.02, writes: 8140.01, response time: 45.80ms (95%), errors: 0.00, reconnects:  0.00
[2058s] threads: 64, tps: 1966.00, reads: 27666.01, writes: 7978.00, response time: 45.55ms (95%), errors: 0.00, reconnects:  0.00
[2059s] threads: 64, tps: 1864.00, reads: 25936.96, writes: 7339.99, response time: 48.80ms (95%), errors: 0.00, reconnects:  0.00
[2060s] threads: 64, tps: 1713.00, reads: 23972.03, writes: 6862.01, response time: 55.14ms (95%), errors: 0.00, reconnects:  0.00
[2061s] threads: 64, tps: 1732.99, reads: 24377.86, writes: 6946.96, response time: 50.72ms (95%), errors: 0.00, reconnects:  0.00
[2062s] threads: 64, tps: 1715.01, reads: 23947.13, writes: 6840.04, response time: 52.20ms (95%), errors: 0.00, reconnects:  0.00
[2063s] threads: 64, tps: 1687.00, reads: 23540.01, writes: 6774.00, response time: 52.39ms (95%), errors: 0.00, reconnects:  0.00
[2064s] threads: 64, tps: 1698.00, reads: 23865.02, writes: 6817.01, response time: 54.42ms (95%), errors: 0.00, reconnects:  0.00
[2065s] threads: 64, tps: 1833.98, reads: 25713.76, writes: 7347.93, response time: 49.89ms (95%), errors: 0.00, reconnects:  0.00
[2066s] threads: 64, tps: 1955.02, reads: 27265.21, writes: 7818.06, response time: 46.00ms (95%), errors: 0.00, reconnects:  0.00
[2067s] threads: 64, tps: 1860.00, reads: 26169.01, writes: 7473.00, response time: 48.61ms (95%), errors: 0.00, reconnects:  0.00
[2068s] threads: 64, tps: 1978.00, reads: 27586.00, writes: 7897.00, response time: 44.75ms (95%), errors: 0.00, reconnects:  0.00
[2069s] threads: 64, tps: 2003.00, reads: 27930.98, writes: 7957.99, response time: 45.28ms (95%), errors: 0.00, reconnects:  0.00
[2070s] threads: 64, tps: 2030.00, reads: 28556.03, writes: 8176.01, response time: 43.98ms (95%), errors: 0.00, reconnects:  0.00
[2071s] threads: 64, tps: 1970.00, reads: 27692.00, writes: 7909.00, response time: 45.63ms (95%), errors: 0.00, reconnects:  0.00
[2072s] threads: 64, tps: 2025.00, reads: 28309.94, writes: 8115.98, response time: 43.85ms (95%), errors: 0.00, reconnects:  0.00
[2073s] threads: 64, tps: 2026.00, reads: 28216.04, writes: 8030.01, response time: 44.57ms (95%), errors: 0.00, reconnects:  0.00
[2074s] threads: 64, tps: 1990.00, reads: 27986.00, writes: 8005.00, response time: 44.54ms (95%), errors: 0.00, reconnects:  0.00
[2075s] threads: 64, tps: 2015.00, reads: 28055.03, writes: 8033.01, response time: 44.92ms (95%), errors: 0.00, reconnects:  0.00
[2076s] threads: 64, tps: 1992.00, reads: 28094.97, writes: 7991.99, response time: 44.22ms (95%), errors: 0.00, reconnects:  0.00
[2077s] threads: 64, tps: 1996.00, reads: 27779.98, writes: 7913.99, response time: 44.20ms (95%), errors: 0.00, reconnects:  0.00
[2078s] threads: 64, tps: 2035.97, reads: 28486.62, writes: 8197.89, response time: 45.61ms (95%), errors: 0.00, reconnects:  0.00
[2079s] threads: 64, tps: 1970.03, reads: 27644.38, writes: 7857.11, response time: 45.43ms (95%), errors: 0.00, reconnects:  0.00
[2080s] threads: 64, tps: 2017.00, reads: 28219.03, writes: 8040.01, response time: 44.67ms (95%), errors: 0.00, reconnects:  0.00
[2081s] threads: 64, tps: 1955.00, reads: 27285.97, writes: 7834.99, response time: 45.48ms (95%), errors: 0.00, reconnects:  0.00
[2082s] threads: 64, tps: 1844.96, reads: 26045.45, writes: 7436.84, response time: 48.33ms (95%), errors: 0.00, reconnects:  0.00
[2083s] threads: 64, tps: 1937.04, reads: 27081.59, writes: 7727.17, response time: 46.68ms (95%), errors: 0.00, reconnects:  0.00
[2084s] threads: 64, tps: 1964.00, reads: 27414.97, writes: 7837.99, response time: 46.63ms (95%), errors: 0.00, reconnects:  0.00
[2085s] threads: 64, tps: 2014.00, reads: 28113.99, writes: 8017.00, response time: 44.16ms (95%), errors: 0.00, reconnects:  0.00
[2086s] threads: 64, tps: 1825.00, reads: 25605.98, writes: 7315.99, response time: 50.19ms (95%), errors: 0.00, reconnects:  0.00
[2087s] threads: 64, tps: 1787.00, reads: 25025.04, writes: 7121.01, response time: 52.78ms (95%), errors: 0.00, reconnects:  0.00
[2088s] threads: 64, tps: 1564.00, reads: 21983.99, writes: 6292.00, response time: 59.32ms (95%), errors: 0.00, reconnects:  0.00
[2089s] threads: 64, tps: 1710.00, reads: 23835.04, writes: 6819.01, response time: 52.03ms (95%), errors: 0.00, reconnects:  0.00
[2090s] threads: 64, tps: 1631.00, reads: 22900.97, writes: 6507.99, response time: 58.45ms (95%), errors: 0.00, reconnects:  0.00
[2091s] threads: 64, tps: 1751.00, reads: 24496.02, writes: 7004.00, response time: 51.16ms (95%), errors: 0.00, reconnects:  0.00
[2092s] threads: 64, tps: 1773.00, reads: 24822.98, writes: 7102.00, response time: 48.75ms (95%), errors: 0.00, reconnects:  0.00
[2093s] threads: 64, tps: 1555.00, reads: 21754.02, writes: 6200.00, response time: 58.17ms (95%), errors: 0.00, reconnects:  0.00
[2094s] threads: 64, tps: 1612.00, reads: 22585.02, writes: 6489.01, response time: 56.86ms (95%), errors: 0.00, reconnects:  0.00
[2095s] threads: 64, tps: 1633.00, reads: 22752.96, writes: 6496.99, response time: 56.02ms (95%), errors: 0.00, reconnects:  0.00
[2096s] threads: 64, tps: 1920.00, reads: 26797.05, writes: 7708.01, response time: 48.62ms (95%), errors: 0.00, reconnects:  0.00
[2097s] threads: 64, tps: 1944.00, reads: 27421.99, writes: 7795.00, response time: 46.03ms (95%), errors: 0.00, reconnects:  0.00
[2098s] threads: 64, tps: 1913.00, reads: 26694.00, writes: 7627.00, response time: 47.37ms (95%), errors: 0.00, reconnects:  0.00
[2099s] threads: 64, tps: 1954.00, reads: 27331.01, writes: 7808.00, response time: 46.71ms (95%), errors: 0.00, reconnects:  0.00
[2100s] threads: 64, tps: 1927.55, reads: 27094.69, writes: 7760.19, response time: 48.07ms (95%), errors: 0.00, reconnects:  0.00
[2101s] threads: 64, tps: 1908.44, reads: 26691.20, writes: 7626.77, response time: 50.89ms (95%), errors: 0.00, reconnects:  0.00
[2102s] threads: 64, tps: 1925.00, reads: 26877.01, writes: 7670.00, response time: 47.56ms (95%), errors: 0.00, reconnects:  0.00
[2103s] threads: 64, tps: 1970.97, reads: 27678.61, writes: 7911.89, response time: 46.46ms (95%), errors: 0.00, reconnects:  0.00
[2104s] threads: 64, tps: 1946.03, reads: 27211.38, writes: 7763.11, response time: 47.66ms (95%), errors: 0.00, reconnects:  0.00
[2105s] threads: 64, tps: 1979.00, reads: 27779.02, writes: 7941.01, response time: 44.94ms (95%), errors: 0.00, reconnects:  0.00
[2106s] threads: 64, tps: 2005.00, reads: 28007.02, writes: 7987.01, response time: 47.03ms (95%), errors: 0.00, reconnects:  0.00
[2107s] threads: 64, tps: 1947.00, reads: 27213.99, writes: 7817.00, response time: 47.67ms (95%), errors: 0.00, reconnects:  0.00
[2108s] threads: 64, tps: 1993.99, reads: 28018.86, writes: 8015.96, response time: 45.39ms (95%), errors: 0.00, reconnects:  0.00
[2109s] threads: 64, tps: 2024.01, reads: 28271.11, writes: 8084.03, response time: 45.50ms (95%), errors: 0.00, reconnects:  0.00
[2110s] threads: 64, tps: 1993.99, reads: 27924.87, writes: 7940.96, response time: 46.20ms (95%), errors: 0.00, reconnects:  0.00
[2111s] threads: 64, tps: 1869.87, reads: 26229.23, writes: 7508.49, response time: 50.39ms (95%), errors: 0.00, reconnects:  0.00
[2112s] threads: 64, tps: 1769.13, reads: 24785.80, writes: 7060.51, response time: 50.61ms (95%), errors: 0.00, reconnects:  0.00
[2113s] threads: 64, tps: 1782.00, reads: 24892.01, writes: 7101.00, response time: 51.96ms (95%), errors: 0.00, reconnects:  0.00
[2114s] threads: 64, tps: 1730.00, reads: 24259.01, writes: 6955.00, response time: 51.89ms (95%), errors: 0.00, reconnects:  0.00
[2115s] threads: 64, tps: 1826.00, reads: 25542.99, writes: 7327.00, response time: 51.15ms (95%), errors: 0.00, reconnects:  0.00
[2116s] threads: 64, tps: 1802.00, reads: 25144.97, writes: 7163.99, response time: 51.16ms (95%), errors: 0.00, reconnects:  0.00
[2117s] threads: 64, tps: 1759.00, reads: 24733.01, writes: 7037.00, response time: 53.35ms (95%), errors: 0.00, reconnects:  0.00
[2118s] threads: 64, tps: 1670.00, reads: 23410.00, writes: 6693.00, response time: 53.54ms (95%), errors: 0.00, reconnects:  0.00
[2119s] threads: 64, tps: 1777.00, reads: 24810.01, writes: 7054.00, response time: 51.75ms (95%), errors: 0.00, reconnects:  0.00
[2120s] threads: 64, tps: 1668.00, reads: 23363.00, writes: 6671.00, response time: 54.97ms (95%), errors: 0.00, reconnects:  0.00
[2121s] threads: 64, tps: 1693.00, reads: 23709.99, writes: 6783.00, response time: 53.53ms (95%), errors: 0.00, reconnects:  0.00
[2122s] threads: 64, tps: 1707.00, reads: 23859.99, writes: 6812.00, response time: 55.15ms (95%), errors: 0.00, reconnects:  0.00
[2123s] threads: 64, tps: 1694.00, reads: 23666.99, writes: 6794.00, response time: 53.59ms (95%), errors: 0.00, reconnects:  0.00
[2124s] threads: 64, tps: 1727.00, reads: 24216.00, writes: 6923.00, response time: 53.34ms (95%), errors: 0.00, reconnects:  0.00
[2125s] threads: 64, tps: 1728.00, reads: 24118.00, writes: 6885.00, response time: 51.82ms (95%), errors: 0.00, reconnects:  0.00
[2126s] threads: 64, tps: 1858.00, reads: 26135.02, writes: 7478.01, response time: 47.94ms (95%), errors: 0.00, reconnects:  0.00
[2127s] threads: 64, tps: 1798.00, reads: 25215.00, writes: 7239.00, response time: 51.52ms (95%), errors: 0.00, reconnects:  0.00
[2128s] threads: 64, tps: 1884.00, reads: 26345.00, writes: 7498.00, response time: 50.39ms (95%), errors: 0.00, reconnects:  0.00
[2129s] threads: 64, tps: 1902.00, reads: 26656.97, writes: 7646.99, response time: 48.41ms (95%), errors: 0.00, reconnects:  0.00
[2130s] threads: 64, tps: 1879.00, reads: 26254.05, writes: 7452.01, response time: 49.91ms (95%), errors: 0.00, reconnects:  0.00
[2131s] threads: 64, tps: 1917.00, reads: 26797.97, writes: 7683.99, response time: 48.58ms (95%), errors: 0.00, reconnects:  0.00
[2132s] threads: 64, tps: 1963.00, reads: 27434.03, writes: 7820.01, response time: 44.38ms (95%), errors: 0.00, reconnects:  0.00
[2133s] threads: 64, tps: 1935.00, reads: 27065.95, writes: 7772.98, response time: 48.51ms (95%), errors: 0.00, reconnects:  0.00
[2134s] threads: 64, tps: 1965.00, reads: 27466.05, writes: 7837.01, response time: 47.16ms (95%), errors: 0.00, reconnects:  0.00
[2135s] threads: 64, tps: 1891.00, reads: 26559.99, writes: 7579.00, response time: 48.90ms (95%), errors: 0.00, reconnects:  0.00
[2136s] threads: 64, tps: 1940.00, reads: 27176.99, writes: 7769.00, response time: 48.03ms (95%), errors: 0.00, reconnects:  0.00
[2137s] threads: 64, tps: 1996.00, reads: 28028.01, writes: 8002.00, response time: 46.20ms (95%), errors: 0.00, reconnects:  0.00
[2138s] threads: 64, tps: 2013.00, reads: 28226.95, writes: 8056.99, response time: 43.84ms (95%), errors: 0.00, reconnects:  0.00
[2139s] threads: 64, tps: 1971.00, reads: 27479.02, writes: 7869.01, response time: 47.03ms (95%), errors: 0.00, reconnects:  0.00
[2140s] threads: 64, tps: 1905.96, reads: 26794.42, writes: 7644.83, response time: 47.02ms (95%), errors: 0.00, reconnects:  0.00
[2141s] threads: 64, tps: 1805.04, reads: 25171.53, writes: 7186.15, response time: 50.87ms (95%), errors: 0.00, reconnects:  0.00
[2142s] threads: 64, tps: 1741.00, reads: 24260.03, writes: 6946.01, response time: 52.31ms (95%), errors: 0.00, reconnects:  0.00
[2143s] threads: 64, tps: 1693.00, reads: 24003.99, writes: 6850.00, response time: 52.78ms (95%), errors: 0.00, reconnects:  0.00
[2144s] threads: 64, tps: 1811.71, reads: 25218.02, writes: 7183.88, response time: 50.01ms (95%), errors: 0.00, reconnects:  0.00
[2145s] threads: 64, tps: 1791.28, reads: 25006.83, writes: 7144.09, response time: 49.24ms (95%), errors: 0.00, reconnects:  0.00
[2146s] threads: 64, tps: 1813.00, reads: 25348.01, writes: 7242.00, response time: 48.17ms (95%), errors: 0.00, reconnects:  0.00
[2147s] threads: 64, tps: 1643.00, reads: 23237.01, writes: 6684.00, response time: 54.68ms (95%), errors: 0.00, reconnects:  0.00
[2148s] threads: 64, tps: 1639.00, reads: 22744.01, writes: 6423.00, response time: 56.83ms (95%), errors: 0.00, reconnects:  0.00
[2149s] threads: 64, tps: 1683.00, reads: 23561.98, writes: 6739.99, response time: 53.64ms (95%), errors: 0.00, reconnects:  0.00
[2150s] threads: 64, tps: 1564.00, reads: 21961.01, writes: 6317.00, response time: 60.19ms (95%), errors: 0.00, reconnects:  0.00
[2151s] threads: 64, tps: 1604.00, reads: 22532.00, writes: 6412.00, response time: 57.64ms (95%), errors: 0.00, reconnects:  0.00
[2152s] threads: 64, tps: 1612.00, reads: 22458.99, writes: 6396.00, response time: 56.58ms (95%), errors: 0.00, reconnects:  0.00
[2153s] threads: 64, tps: 1465.00, reads: 20610.02, writes: 5939.01, response time: 61.06ms (95%), errors: 0.00, reconnects:  0.00
[2154s] threads: 64, tps: 1517.00, reads: 21298.95, writes: 6156.98, response time: 59.81ms (95%), errors: 0.00, reconnects:  0.00
[2155s] threads: 64, tps: 1703.00, reads: 23653.06, writes: 6670.02, response time: 54.82ms (95%), errors: 0.00, reconnects:  0.00
[2156s] threads: 64, tps: 1820.00, reads: 25655.01, writes: 7379.00, response time: 49.97ms (95%), errors: 0.00, reconnects:  0.00
[2157s] threads: 64, tps: 1892.00, reads: 26331.98, writes: 7472.99, response time: 48.54ms (95%), errors: 0.00, reconnects:  0.00
[2158s] threads: 64, tps: 1848.00, reads: 25924.99, writes: 7387.00, response time: 47.49ms (95%), errors: 0.00, reconnects:  0.00
[2159s] threads: 64, tps: 1858.00, reads: 26091.03, writes: 7488.01, response time: 48.57ms (95%), errors: 0.00, reconnects:  0.00
[2160s] threads: 64, tps: 1790.00, reads: 25083.99, writes: 7213.00, response time: 51.58ms (95%), errors: 0.00, reconnects:  0.00
[2161s] threads: 64, tps: 1932.00, reads: 26857.99, writes: 7623.00, response time: 48.81ms (95%), errors: 0.00, reconnects:  0.00
[2162s] threads: 64, tps: 1925.00, reads: 26977.05, writes: 7712.01, response time: 48.62ms (95%), errors: 0.00, reconnects:  0.00
[2163s] threads: 64, tps: 1893.00, reads: 26577.97, writes: 7629.99, response time: 47.08ms (95%), errors: 0.00, reconnects:  0.00
[2164s] threads: 64, tps: 2028.00, reads: 28321.02, writes: 8037.01, response time: 45.05ms (95%), errors: 0.00, reconnects:  0.00
[2165s] threads: 64, tps: 1973.00, reads: 27601.97, writes: 7890.99, response time: 46.27ms (95%), errors: 0.00, reconnects:  0.00
[2166s] threads: 64, tps: 2050.00, reads: 28737.01, writes: 8249.00, response time: 45.91ms (95%), errors: 0.00, reconnects:  0.00
[2167s] threads: 64, tps: 1937.00, reads: 27201.01, writes: 7761.00, response time: 49.14ms (95%), errors: 0.00, reconnects:  0.00
[2168s] threads: 64, tps: 2009.00, reads: 28131.96, writes: 8030.99, response time: 46.29ms (95%), errors: 0.00, reconnects:  0.00
[2169s] threads: 64, tps: 2048.00, reads: 28681.97, writes: 8169.99, response time: 44.25ms (95%), errors: 0.00, reconnects:  0.00
[2170s] threads: 64, tps: 1927.99, reads: 27010.92, writes: 7752.98, response time: 47.63ms (95%), errors: 0.00, reconnects:  0.00
[2171s] threads: 64, tps: 1818.01, reads: 25354.15, writes: 7202.04, response time: 51.67ms (95%), errors: 0.00, reconnects:  0.00
[2172s] threads: 64, tps: 1744.00, reads: 24330.99, writes: 6964.00, response time: 52.51ms (95%), errors: 0.00, reconnects:  0.00
[2173s] threads: 64, tps: 1751.00, reads: 24611.98, writes: 7032.00, response time: 51.62ms (95%), errors: 0.00, reconnects:  0.00
[2174s] threads: 64, tps: 1870.00, reads: 26181.99, writes: 7520.00, response time: 49.39ms (95%), errors: 0.00, reconnects:  0.00
[2175s] threads: 64, tps: 1960.97, reads: 27527.60, writes: 7841.89, response time: 46.66ms (95%), errors: 0.00, reconnects:  0.00
[2176s] threads: 64, tps: 1880.03, reads: 26236.41, writes: 7487.12, response time: 48.74ms (95%), errors: 0.00, reconnects:  0.00
[2177s] threads: 64, tps: 1837.00, reads: 25606.99, writes: 7293.00, response time: 48.29ms (95%), errors: 0.00, reconnects:  0.00
[2178s] threads: 64, tps: 1841.00, reads: 25907.99, writes: 7432.00, response time: 49.73ms (95%), errors: 0.00, reconnects:  0.00
[2179s] threads: 64, tps: 1825.00, reads: 25506.97, writes: 7218.99, response time: 49.62ms (95%), errors: 0.00, reconnects:  0.00
[2180s] threads: 64, tps: 1812.00, reads: 25424.03, writes: 7312.01, response time: 48.81ms (95%), errors: 0.00, reconnects:  0.00
[2181s] threads: 64, tps: 1660.00, reads: 23249.01, writes: 6659.00, response time: 55.80ms (95%), errors: 0.00, reconnects:  0.00
[2182s] threads: 64, tps: 1723.00, reads: 24098.01, writes: 6818.00, response time: 52.09ms (95%), errors: 0.00, reconnects:  0.00
[2183s] threads: 64, tps: 1753.00, reads: 24554.98, writes: 7020.99, response time: 50.92ms (95%), errors: 0.00, reconnects:  0.00
[2184s] threads: 64, tps: 1805.00, reads: 25271.01, writes: 7267.00, response time: 50.83ms (95%), errors: 0.00, reconnects:  0.00
[2185s] threads: 64, tps: 1773.00, reads: 24848.97, writes: 7121.99, response time: 53.50ms (95%), errors: 0.00, reconnects:  0.00
[2186s] threads: 64, tps: 1718.00, reads: 24047.02, writes: 6843.01, response time: 54.71ms (95%), errors: 0.00, reconnects:  0.00
[2187s] threads: 64, tps: 1852.00, reads: 25881.98, writes: 7366.00, response time: 52.35ms (95%), errors: 0.00, reconnects:  0.00
[2188s] threads: 64, tps: 1911.00, reads: 26862.02, writes: 7746.00, response time: 47.73ms (95%), errors: 0.00, reconnects:  0.00
[2189s] threads: 64, tps: 1896.00, reads: 26441.97, writes: 7533.99, response time: 50.89ms (95%), errors: 0.00, reconnects:  0.00
[2190s] threads: 64, tps: 1889.00, reads: 26548.06, writes: 7619.02, response time: 49.88ms (95%), errors: 0.00, reconnects:  0.00
[2191s] threads: 64, tps: 1945.96, reads: 27105.40, writes: 7725.83, response time: 48.00ms (95%), errors: 0.00, reconnects:  0.00
[2192s] threads: 64, tps: 1931.94, reads: 27100.19, writes: 7755.77, response time: 47.83ms (95%), errors: 0.00, reconnects:  0.00
[2193s] threads: 64, tps: 1894.10, reads: 26448.37, writes: 7593.39, response time: 48.23ms (95%), errors: 0.00, reconnects:  0.00
[2194s] threads: 64, tps: 1902.00, reads: 26644.00, writes: 7553.00, response time: 48.16ms (95%), errors: 0.00, reconnects:  0.00
[2195s] threads: 64, tps: 2035.00, reads: 28501.94, writes: 8119.98, response time: 46.10ms (95%), errors: 0.00, reconnects:  0.00
[2196s] threads: 64, tps: 1917.00, reads: 26948.05, writes: 7789.02, response time: 47.77ms (95%), errors: 0.00, reconnects:  0.00
[2197s] threads: 64, tps: 2079.00, reads: 28876.99, writes: 8221.00, response time: 45.05ms (95%), errors: 0.00, reconnects:  0.00
[2198s] threads: 64, tps: 1978.93, reads: 27783.04, writes: 7925.73, response time: 46.53ms (95%), errors: 0.00, reconnects:  0.00
[2199s] threads: 64, tps: 1824.06, reads: 25598.89, writes: 7249.25, response time: 48.96ms (95%), errors: 0.00, reconnects:  0.00
[2200s] threads: 64, tps: 1942.00, reads: 27150.00, writes: 7744.00, response time: 45.63ms (95%), errors: 0.00, reconnects:  0.00
[2201s] threads: 64, tps: 1868.00, reads: 26145.99, writes: 7496.00, response time: 49.12ms (95%), errors: 0.00, reconnects:  0.00
[2202s] threads: 64, tps: 1902.00, reads: 26558.01, writes: 7574.00, response time: 47.08ms (95%), errors: 0.00, reconnects:  0.00
[2203s] threads: 64, tps: 1896.00, reads: 26596.95, writes: 7608.99, response time: 47.99ms (95%), errors: 0.00, reconnects:  0.00
[2204s] threads: 64, tps: 1870.00, reads: 26312.07, writes: 7591.02, response time: 48.06ms (95%), errors: 0.00, reconnects:  0.00
[2205s] threads: 64, tps: 1986.00, reads: 27774.95, writes: 7880.99, response time: 45.73ms (95%), errors: 0.00, reconnects:  0.00
[2206s] threads: 64, tps: 1922.00, reads: 26871.03, writes: 7677.01, response time: 45.84ms (95%), errors: 0.00, reconnects:  0.00
[2207s] threads: 64, tps: 1857.00, reads: 25946.99, writes: 7363.00, response time: 48.41ms (95%), errors: 0.00, reconnects:  0.00
[2208s] threads: 64, tps: 1797.00, reads: 25183.01, writes: 7227.00, response time: 49.80ms (95%), errors: 0.00, reconnects:  0.00
[2209s] threads: 64, tps: 1769.00, reads: 24769.99, writes: 7050.00, response time: 51.19ms (95%), errors: 0.00, reconnects:  0.00
[2210s] threads: 64, tps: 1769.00, reads: 24749.98, writes: 7101.99, response time: 50.84ms (95%), errors: 0.00, reconnects:  0.00
[2211s] threads: 64, tps: 1670.00, reads: 23388.98, writes: 6644.99, response time: 56.52ms (95%), errors: 0.00, reconnects:  0.00
[2212s] threads: 64, tps: 1669.00, reads: 23344.05, writes: 6705.01, response time: 53.99ms (95%), errors: 0.00, reconnects:  0.00
[2213s] threads: 64, tps: 1677.00, reads: 23418.98, writes: 6711.99, response time: 53.38ms (95%), errors: 0.00, reconnects:  0.00
[2214s] threads: 64, tps: 1774.00, reads: 24934.02, writes: 7132.00, response time: 51.79ms (95%), errors: 0.00, reconnects:  0.00
[2215s] threads: 64, tps: 1889.00, reads: 26388.98, writes: 7549.99, response time: 47.89ms (95%), errors: 0.00, reconnects:  0.00
[2216s] threads: 64, tps: 1963.00, reads: 27513.01, writes: 7800.00, response time: 46.67ms (95%), errors: 0.00, reconnects:  0.00
[2217s] threads: 64, tps: 1944.00, reads: 27168.97, writes: 7792.99, response time: 47.76ms (95%), errors: 0.00, reconnects:  0.00
[2218s] threads: 64, tps: 2061.00, reads: 28904.04, writes: 8264.01, response time: 43.32ms (95%), errors: 0.00, reconnects:  0.00
[2219s] threads: 64, tps: 1969.00, reads: 27682.99, writes: 7941.00, response time: 44.79ms (95%), errors: 0.00, reconnects:  0.00
[2220s] threads: 64, tps: 1970.00, reads: 27599.97, writes: 7906.99, response time: 44.90ms (95%), errors: 0.00, reconnects:  0.00
[2221s] threads: 64, tps: 2081.00, reads: 28930.04, writes: 8216.01, response time: 44.12ms (95%), errors: 0.00, reconnects:  0.00
[2222s] threads: 64, tps: 1996.00, reads: 28013.99, writes: 8041.00, response time: 45.33ms (95%), errors: 0.00, reconnects:  0.00
[2223s] threads: 64, tps: 2067.00, reads: 29077.02, writes: 8284.01, response time: 42.39ms (95%), errors: 0.00, reconnects:  0.00
[2224s] threads: 64, tps: 2122.00, reads: 29406.96, writes: 8394.99, response time: 41.84ms (95%), errors: 0.00, reconnects:  0.00
[2225s] threads: 64, tps: 2019.00, reads: 28477.02, writes: 8098.01, response time: 44.08ms (95%), errors: 0.00, reconnects:  0.00
[2226s] threads: 64, tps: 2097.00, reads: 29346.99, writes: 8465.00, response time: 43.24ms (95%), errors: 0.00, reconnects:  0.00
[2227s] threads: 64, tps: 2057.00, reads: 28755.00, writes: 8155.00, response time: 43.85ms (95%), errors: 0.00, reconnects:  0.00
[2228s] threads: 64, tps: 2058.00, reads: 28867.99, writes: 8294.00, response time: 42.74ms (95%), errors: 0.00, reconnects:  0.00
[2229s] threads: 64, tps: 2026.00, reads: 28264.05, writes: 8001.01, response time: 44.51ms (95%), errors: 0.00, reconnects:  0.00
[2230s] threads: 64, tps: 1889.99, reads: 26489.86, writes: 7578.96, response time: 48.12ms (95%), errors: 0.00, reconnects:  0.00
[2231s] threads: 64, tps: 1895.01, reads: 26679.12, writes: 7651.03, response time: 46.36ms (95%), errors: 0.00, reconnects:  0.00
[2232s] threads: 64, tps: 1947.00, reads: 27150.02, writes: 7704.00, response time: 46.11ms (95%), errors: 0.00, reconnects:  0.00
[2233s] threads: 64, tps: 1802.94, reads: 25229.13, writes: 7226.75, response time: 50.28ms (95%), errors: 0.00, reconnects:  0.00
[2234s] threads: 64, tps: 1873.98, reads: 26139.78, writes: 7501.94, response time: 49.12ms (95%), errors: 0.00, reconnects:  0.00
[2235s] threads: 64, tps: 1727.08, reads: 24302.06, writes: 6947.30, response time: 52.25ms (95%), errors: 0.00, reconnects:  0.00
[2236s] threads: 64, tps: 1826.00, reads: 25580.98, writes: 7309.99, response time: 49.62ms (95%), errors: 0.00, reconnects:  0.00
[2237s] threads: 64, tps: 1786.00, reads: 25020.01, writes: 7153.00, response time: 49.34ms (95%), errors: 0.00, reconnects:  0.00
[2238s] threads: 64, tps: 1736.00, reads: 24286.01, writes: 6905.00, response time: 51.64ms (95%), errors: 0.00, reconnects:  0.00
[2239s] threads: 64, tps: 1653.00, reads: 22913.01, writes: 6564.00, response time: 54.42ms (95%), errors: 0.00, reconnects:  0.00
[2240s] threads: 64, tps: 1530.00, reads: 21545.99, writes: 6136.00, response time: 58.36ms (95%), errors: 0.00, reconnects:  0.00
[2241s] threads: 64, tps: 1423.00, reads: 20007.97, writes: 5705.99, response time: 66.18ms (95%), errors: 0.00, reconnects:  0.00
[2242s] threads: 64, tps: 1684.00, reads: 23473.02, writes: 6715.01, response time: 54.96ms (95%), errors: 0.00, reconnects:  0.00
[2243s] threads: 64, tps: 1664.00, reads: 23344.98, writes: 6667.99, response time: 53.77ms (95%), errors: 0.00, reconnects:  0.00
[2244s] threads: 64, tps: 1683.00, reads: 23621.04, writes: 6798.01, response time: 54.37ms (95%), errors: 0.00, reconnects:  0.00
[2245s] threads: 64, tps: 1840.00, reads: 25639.01, writes: 7325.00, response time: 50.61ms (95%), errors: 0.00, reconnects:  0.00
[2246s] threads: 64, tps: 1882.00, reads: 26432.99, writes: 7537.00, response time: 48.07ms (95%), errors: 0.00, reconnects:  0.00
[2247s] threads: 64, tps: 1922.00, reads: 26822.98, writes: 7658.99, response time: 48.48ms (95%), errors: 0.00, reconnects:  0.00
[2248s] threads: 64, tps: 1802.00, reads: 25292.00, writes: 7216.00, response time: 51.10ms (95%), errors: 0.00, reconnects:  0.00
[2249s] threads: 64, tps: 1861.00, reads: 26022.05, writes: 7450.01, response time: 49.77ms (95%), errors: 0.00, reconnects:  0.00
[2250s] threads: 64, tps: 1913.00, reads: 26813.95, writes: 7678.99, response time: 46.14ms (95%), errors: 0.00, reconnects:  0.00
[2251s] threads: 64, tps: 1915.00, reads: 26888.02, writes: 7729.00, response time: 47.73ms (95%), errors: 0.00, reconnects:  0.00
[2252s] threads: 64, tps: 1960.00, reads: 27495.99, writes: 7836.00, response time: 48.51ms (95%), errors: 0.00, reconnects:  0.00
[2253s] threads: 64, tps: 1972.00, reads: 27519.01, writes: 7814.00, response time: 45.85ms (95%), errors: 0.00, reconnects:  0.00
[2254s] threads: 64, tps: 1945.00, reads: 27148.98, writes: 7793.99, response time: 48.16ms (95%), errors: 0.00, reconnects:  0.00
[2255s] threads: 64, tps: 2022.00, reads: 28315.99, writes: 8062.00, response time: 43.71ms (95%), errors: 0.00, reconnects:  0.00
[2256s] threads: 64, tps: 2023.00, reads: 28370.98, writes: 8104.99, response time: 46.10ms (95%), errors: 0.00, reconnects:  0.00
[2257s] threads: 64, tps: 1971.00, reads: 27597.06, writes: 7888.02, response time: 46.71ms (95%), errors: 0.00, reconnects:  0.00
[2258s] threads: 64, tps: 1840.00, reads: 25784.94, writes: 7379.98, response time: 49.36ms (95%), errors: 0.00, reconnects:  0.00
[2259s] threads: 64, tps: 1825.00, reads: 25450.07, writes: 7317.02, response time: 49.64ms (95%), errors: 0.00, reconnects:  0.00
[2260s] threads: 64, tps: 1741.00, reads: 24509.98, writes: 6939.00, response time: 50.16ms (95%), errors: 0.00, reconnects:  0.00
[2261s] threads: 64, tps: 1799.00, reads: 25138.00, writes: 7182.00, response time: 49.67ms (95%), errors: 0.00, reconnects:  0.00
[2262s] threads: 64, tps: 1793.00, reads: 25176.97, writes: 7208.99, response time: 50.77ms (95%), errors: 0.00, reconnects:  0.00
[2263s] threads: 64, tps: 1877.00, reads: 26149.99, writes: 7451.00, response time: 48.52ms (95%), errors: 0.00, reconnects:  0.00
[2264s] threads: 64, tps: 1901.00, reads: 26598.02, writes: 7615.01, response time: 46.70ms (95%), errors: 0.00, reconnects:  0.00
[2265s] threads: 64, tps: 1890.00, reads: 26612.01, writes: 7638.00, response time: 46.61ms (95%), errors: 0.00, reconnects:  0.00
[2266s] threads: 64, tps: 1891.00, reads: 26413.99, writes: 7523.00, response time: 47.84ms (95%), errors: 0.00, reconnects:  0.00
[2267s] threads: 64, tps: 1819.00, reads: 25527.01, writes: 7288.00, response time: 47.87ms (95%), errors: 0.00, reconnects:  0.00
[2268s] threads: 64, tps: 1837.00, reads: 25617.02, writes: 7273.01, response time: 49.45ms (95%), errors: 0.00, reconnects:  0.00
[2269s] threads: 64, tps: 1711.00, reads: 23991.98, writes: 6847.00, response time: 53.18ms (95%), errors: 0.00, reconnects:  0.00
[2270s] threads: 64, tps: 1576.00, reads: 22206.98, writes: 6422.99, response time: 59.09ms (95%), errors: 0.00, reconnects:  0.00
[2271s] threads: 64, tps: 1633.00, reads: 22672.02, writes: 6387.00, response time: 55.30ms (95%), errors: 0.00, reconnects:  0.00
[2272s] threads: 64, tps: 1669.00, reads: 23428.00, writes: 6690.00, response time: 54.35ms (95%), errors: 0.00, reconnects:  0.00
[2273s] threads: 64, tps: 1767.96, reads: 24779.39, writes: 7127.83, response time: 50.57ms (95%), errors: 0.00, reconnects:  0.00
[2274s] threads: 64, tps: 1830.04, reads: 25601.63, writes: 7320.18, response time: 51.42ms (95%), errors: 0.00, reconnects:  0.00
[2275s] threads: 64, tps: 1960.00, reads: 27334.00, writes: 7813.00, response time: 46.36ms (95%), errors: 0.00, reconnects:  0.00
[2276s] threads: 64, tps: 1974.00, reads: 27700.99, writes: 7936.00, response time: 46.54ms (95%), errors: 0.00, reconnects:  0.00
[2277s] threads: 64, tps: 1976.00, reads: 27606.05, writes: 7859.02, response time: 46.35ms (95%), errors: 0.00, reconnects:  0.00
[2278s] threads: 64, tps: 1979.00, reads: 27781.01, writes: 7952.00, response time: 44.85ms (95%), errors: 0.00, reconnects:  0.00
[2279s] threads: 64, tps: 1993.00, reads: 27860.98, writes: 7952.99, response time: 46.60ms (95%), errors: 0.00, reconnects:  0.00
[2280s] threads: 64, tps: 1927.00, reads: 27077.00, writes: 7737.00, response time: 47.25ms (95%), errors: 0.00, reconnects:  0.00
[2281s] threads: 64, tps: 1897.00, reads: 26535.98, writes: 7609.99, response time: 52.23ms (95%), errors: 0.00, reconnects:  0.00
[2282s] threads: 64, tps: 1927.00, reads: 26938.98, writes: 7684.99, response time: 48.71ms (95%), errors: 0.00, reconnects:  0.00
[2283s] threads: 64, tps: 1998.00, reads: 27925.01, writes: 7928.00, response time: 44.74ms (95%), errors: 0.00, reconnects:  0.00
[2284s] threads: 64, tps: 2019.00, reads: 28371.00, writes: 8168.00, response time: 45.96ms (95%), errors: 0.00, reconnects:  0.00
[2285s] threads: 64, tps: 1978.00, reads: 27588.05, writes: 7825.01, response time: 46.95ms (95%), errors: 0.00, reconnects:  0.00
[2286s] threads: 64, tps: 1928.00, reads: 27031.95, writes: 7774.99, response time: 47.60ms (95%), errors: 0.00, reconnects:  0.00
[2287s] threads: 64, tps: 1931.00, reads: 27028.01, writes: 7699.00, response time: 45.70ms (95%), errors: 0.00, reconnects:  0.00
[2288s] threads: 64, tps: 1832.00, reads: 25474.98, writes: 7314.00, response time: 49.06ms (95%), errors: 0.00, reconnects:  0.00
[2289s] threads: 64, tps: 1832.00, reads: 25773.00, writes: 7320.00, response time: 48.81ms (95%), errors: 0.00, reconnects:  0.00
[2290s] threads: 64, tps: 1792.99, reads: 25194.92, writes: 7219.98, response time: 49.34ms (95%), errors: 0.00, reconnects:  0.00
[2291s] threads: 64, tps: 1781.01, reads: 24817.10, writes: 7076.03, response time: 51.52ms (95%), errors: 0.00, reconnects:  0.00
[2292s] threads: 64, tps: 1824.99, reads: 25649.89, writes: 7323.97, response time: 52.07ms (95%), errors: 0.00, reconnects:  0.00
[2293s] threads: 64, tps: 1990.01, reads: 27914.11, writes: 8007.03, response time: 44.67ms (95%), errors: 0.00, reconnects:  0.00
[2294s] threads: 64, tps: 1970.00, reads: 27568.99, writes: 7889.00, response time: 44.92ms (95%), errors: 0.00, reconnects:  0.00
[2295s] threads: 64, tps: 1960.00, reads: 27373.02, writes: 7782.01, response time: 45.35ms (95%), errors: 0.00, reconnects:  0.00
[2296s] threads: 64, tps: 1877.00, reads: 26329.95, writes: 7534.99, response time: 48.64ms (95%), errors: 0.00, reconnects:  0.00
[2297s] threads: 64, tps: 1939.00, reads: 27088.02, writes: 7731.01, response time: 46.75ms (95%), errors: 0.00, reconnects:  0.00
[2298s] threads: 64, tps: 1879.00, reads: 26293.01, writes: 7459.00, response time: 49.25ms (95%), errors: 0.00, reconnects:  0.00
[2299s] threads: 64, tps: 1751.00, reads: 24511.99, writes: 7023.00, response time: 50.49ms (95%), errors: 0.00, reconnects:  0.00
[2300s] threads: 64, tps: 1642.00, reads: 22995.00, writes: 6580.00, response time: 56.80ms (95%), errors: 0.00, reconnects:  0.00
[2301s] threads: 64, tps: 1649.00, reads: 23062.01, writes: 6577.00, response time: 55.01ms (95%), errors: 0.00, reconnects:  0.00
[2302s] threads: 64, tps: 1643.00, reads: 23014.99, writes: 6570.00, response time: 55.07ms (95%), errors: 0.00, reconnects:  0.00
[2303s] threads: 64, tps: 1847.00, reads: 25893.00, writes: 7449.00, response time: 48.17ms (95%), errors: 0.00, reconnects:  0.00
[2304s] threads: 64, tps: 1890.00, reads: 26500.98, writes: 7586.99, response time: 49.45ms (95%), errors: 0.00, reconnects:  0.00
[2305s] threads: 64, tps: 1869.00, reads: 25999.99, writes: 7408.00, response time: 48.03ms (95%), errors: 0.00, reconnects:  0.00
[2306s] threads: 64, tps: 1934.00, reads: 27197.97, writes: 7748.99, response time: 47.49ms (95%), errors: 0.00, reconnects:  0.00
[2307s] threads: 64, tps: 1875.01, reads: 26290.08, writes: 7549.02, response time: 49.33ms (95%), errors: 0.00, reconnects:  0.00
[2308s] threads: 64, tps: 1887.00, reads: 26321.01, writes: 7483.00, response time: 49.79ms (95%), errors: 0.00, reconnects:  0.00
[2309s] threads: 64, tps: 1846.00, reads: 25826.96, writes: 7420.99, response time: 49.11ms (95%), errors: 0.00, reconnects:  0.00
[2310s] threads: 64, tps: 1927.00, reads: 27017.01, writes: 7721.00, response time: 47.62ms (95%), errors: 0.00, reconnects:  0.00
[2311s] threads: 64, tps: 1952.00, reads: 27450.01, writes: 7848.00, response time: 46.68ms (95%), errors: 0.00, reconnects:  0.00
[2312s] threads: 64, tps: 1955.00, reads: 27245.02, writes: 7745.00, response time: 49.18ms (95%), errors: 0.00, reconnects:  0.00
[2313s] threads: 64, tps: 2018.00, reads: 28042.99, writes: 8029.00, response time: 45.55ms (95%), errors: 0.00, reconnects:  0.00
[2314s] threads: 64, tps: 1994.00, reads: 28111.96, writes: 8026.99, response time: 45.12ms (95%), errors: 0.00, reconnects:  0.00
[2315s] threads: 64, tps: 1982.00, reads: 27736.02, writes: 7916.01, response time: 45.39ms (95%), errors: 0.00, reconnects:  0.00
[2316s] threads: 64, tps: 1919.00, reads: 26957.03, writes: 7699.01, response time: 47.13ms (95%), errors: 0.00, reconnects:  0.00
[2317s] threads: 64, tps: 1838.00, reads: 25690.00, writes: 7323.00, response time: 47.52ms (95%), errors: 0.00, reconnects:  0.00
[2318s] threads: 64, tps: 1713.00, reads: 23955.00, writes: 6846.00, response time: 52.78ms (95%), errors: 0.00, reconnects:  0.00
[2319s] threads: 64, tps: 1752.98, reads: 24586.66, writes: 7051.90, response time: 52.26ms (95%), errors: 0.00, reconnects:  0.00
[2320s] threads: 64, tps: 1912.01, reads: 26665.16, writes: 7630.05, response time: 47.35ms (95%), errors: 0.00, reconnects:  0.00
[2321s] threads: 64, tps: 1952.01, reads: 27530.20, writes: 7871.06, response time: 46.22ms (95%), errors: 0.00, reconnects:  0.00
[2322s] threads: 64, tps: 1911.00, reads: 26630.98, writes: 7609.99, response time: 50.01ms (95%), errors: 0.00, reconnects:  0.00
[2323s] threads: 64, tps: 2026.00, reads: 28363.04, writes: 8110.01, response time: 45.40ms (95%), errors: 0.00, reconnects:  0.00
[2324s] threads: 64, tps: 1965.00, reads: 27463.99, writes: 7847.00, response time: 45.20ms (95%), errors: 0.00, reconnects:  0.00
[2325s] threads: 64, tps: 2010.00, reads: 28167.00, writes: 7985.00, response time: 45.94ms (95%), errors: 0.00, reconnects:  0.00
[2326s] threads: 64, tps: 1943.00, reads: 27205.99, writes: 7815.00, response time: 47.62ms (95%), errors: 0.00, reconnects:  0.00
[2327s] threads: 64, tps: 1874.00, reads: 26254.97, writes: 7476.99, response time: 49.48ms (95%), errors: 0.00, reconnects:  0.00
[2328s] threads: 64, tps: 1852.00, reads: 25894.00, writes: 7375.00, response time: 47.97ms (95%), errors: 0.00, reconnects:  0.00
[2329s] threads: 64, tps: 1658.00, reads: 23251.02, writes: 6626.00, response time: 55.45ms (95%), errors: 0.00, reconnects:  0.00
[2330s] threads: 64, tps: 1716.99, reads: 23991.92, writes: 6881.98, response time: 52.07ms (95%), errors: 0.00, reconnects:  0.00
[2331s] threads: 64, tps: 1706.01, reads: 23894.08, writes: 6879.02, response time: 52.76ms (95%), errors: 0.00, reconnects:  0.00
[2332s] threads: 64, tps: 1883.00, reads: 26505.02, writes: 7591.01, response time: 47.29ms (95%), errors: 0.00, reconnects:  0.00
[2333s] threads: 64, tps: 2018.99, reads: 28145.81, writes: 8026.95, response time: 44.81ms (95%), errors: 0.00, reconnects:  0.00
[2334s] threads: 64, tps: 1948.01, reads: 27348.18, writes: 7795.05, response time: 45.35ms (95%), errors: 0.00, reconnects:  0.00
[2335s] threads: 64, tps: 2000.00, reads: 27806.02, writes: 7954.01, response time: 45.87ms (95%), errors: 0.00, reconnects:  0.00
[2336s] threads: 64, tps: 1970.00, reads: 27818.00, writes: 7968.00, response time: 46.17ms (95%), errors: 0.00, reconnects:  0.00
[2337s] threads: 64, tps: 2053.00, reads: 28563.95, writes: 8135.99, response time: 42.83ms (95%), errors: 0.00, reconnects:  0.00
[2338s] threads: 64, tps: 2062.00, reads: 28867.00, writes: 8234.00, response time: 43.73ms (95%), errors: 0.00, reconnects:  0.00
[2339s] threads: 64, tps: 2067.00, reads: 29010.01, writes: 8307.00, response time: 44.33ms (95%), errors: 0.00, reconnects:  0.00
[2340s] threads: 64, tps: 2040.00, reads: 28526.97, writes: 8130.99, response time: 44.22ms (95%), errors: 0.00, reconnects:  0.00
[2341s] threads: 64, tps: 2094.00, reads: 29318.01, writes: 8360.00, response time: 43.93ms (95%), errors: 0.00, reconnects:  0.00
[2342s] threads: 64, tps: 1995.00, reads: 27873.97, writes: 7947.99, response time: 45.67ms (95%), errors: 0.00, reconnects:  0.00
[2343s] threads: 64, tps: 1897.00, reads: 26762.04, writes: 7714.01, response time: 46.98ms (95%), errors: 0.00, reconnects:  0.00
[2344s] threads: 64, tps: 1985.00, reads: 27558.01, writes: 7854.00, response time: 47.32ms (95%), errors: 0.00, reconnects:  0.00
[2345s] threads: 64, tps: 1855.00, reads: 25986.98, writes: 7392.99, response time: 47.97ms (95%), errors: 0.00, reconnects:  0.00
[2346s] threads: 64, tps: 1786.99, reads: 25141.82, writes: 7205.95, response time: 48.80ms (95%), errors: 0.00, reconnects:  0.00
[2347s] threads: 64, tps: 1809.01, reads: 25293.10, writes: 7219.03, response time: 47.54ms (95%), errors: 0.00, reconnects:  0.00
[2348s] threads: 64, tps: 1880.01, reads: 26253.12, writes: 7464.03, response time: 47.47ms (95%), errors: 0.00, reconnects:  0.00
[2349s] threads: 64, tps: 1882.99, reads: 26404.86, writes: 7547.96, response time: 48.52ms (95%), errors: 0.00, reconnects:  0.00
[2350s] threads: 64, tps: 1954.01, reads: 27247.12, writes: 7837.04, response time: 47.16ms (95%), errors: 0.00, reconnects:  0.00
[2351s] threads: 64, tps: 1946.00, reads: 27329.01, writes: 7786.00, response time: 44.66ms (95%), errors: 0.00, reconnects:  0.00
[2352s] threads: 64, tps: 1935.99, reads: 27182.88, writes: 7757.97, response time: 45.76ms (95%), errors: 0.00, reconnects:  0.00
[2353s] threads: 64, tps: 1992.00, reads: 27891.98, writes: 7994.99, response time: 44.82ms (95%), errors: 0.00, reconnects:  0.00
[2354s] threads: 64, tps: 1895.01, reads: 26463.15, writes: 7569.04, response time: 46.61ms (95%), errors: 0.00, reconnects:  0.00
[2355s] threads: 64, tps: 1886.00, reads: 26509.01, writes: 7597.00, response time: 47.29ms (95%), errors: 0.00, reconnects:  0.00
[2356s] threads: 64, tps: 1887.00, reads: 26245.97, writes: 7446.99, response time: 49.39ms (95%), errors: 0.00, reconnects:  0.00
[2357s] threads: 64, tps: 1764.00, reads: 24724.01, writes: 7048.00, response time: 50.57ms (95%), errors: 0.00, reconnects:  0.00
[2358s] threads: 64, tps: 1690.00, reads: 23776.96, writes: 6793.99, response time: 54.42ms (95%), errors: 0.00, reconnects:  0.00
[2359s] threads: 64, tps: 1603.00, reads: 22424.96, writes: 6404.99, response time: 56.27ms (95%), errors: 0.00, reconnects:  0.00
[2360s] threads: 64, tps: 1669.99, reads: 23319.83, writes: 6693.95, response time: 53.53ms (95%), errors: 0.00, reconnects:  0.00
[2361s] threads: 64, tps: 1741.02, reads: 24423.25, writes: 6999.07, response time: 51.21ms (95%), errors: 0.00, reconnects:  0.00
[2362s] threads: 64, tps: 1842.00, reads: 25746.96, writes: 7321.99, response time: 50.10ms (95%), errors: 0.00, reconnects:  0.00
[2363s] threads: 64, tps: 1935.00, reads: 27243.03, writes: 7806.01, response time: 46.20ms (95%), errors: 0.00, reconnects:  0.00
[2364s] threads: 64, tps: 1949.00, reads: 27234.98, writes: 7812.00, response time: 46.27ms (95%), errors: 0.00, reconnects:  0.00
[2365s] threads: 64, tps: 1956.99, reads: 27305.91, writes: 7772.97, response time: 47.18ms (95%), errors: 0.00, reconnects:  0.00
[2366s] threads: 64, tps: 1989.01, reads: 27897.12, writes: 7955.03, response time: 44.93ms (95%), errors: 0.00, reconnects:  0.00
[2367s] threads: 64, tps: 2022.00, reads: 28166.01, writes: 8070.00, response time: 44.73ms (95%), errors: 0.00, reconnects:  0.00
[2368s] threads: 64, tps: 2013.00, reads: 28365.95, writes: 8117.99, response time: 43.16ms (95%), errors: 0.00, reconnects:  0.00
[2369s] threads: 64, tps: 1964.00, reads: 27379.04, writes: 7831.01, response time: 45.02ms (95%), errors: 0.00, reconnects:  0.00
[2370s] threads: 64, tps: 1986.99, reads: 27863.86, writes: 7911.96, response time: 43.94ms (95%), errors: 0.00, reconnects:  0.00
[2371s] threads: 64, tps: 2031.00, reads: 28280.99, writes: 8104.00, response time: 44.34ms (95%), errors: 0.00, reconnects:  0.00
[2372s] threads: 64, tps: 1998.01, reads: 28135.17, writes: 8048.05, response time: 44.09ms (95%), errors: 0.00, reconnects:  0.00
[2373s] threads: 64, tps: 2066.00, reads: 28938.00, writes: 8279.00, response time: 43.37ms (95%), errors: 0.00, reconnects:  0.00
[2374s] threads: 64, tps: 1972.00, reads: 27566.96, writes: 7842.99, response time: 44.12ms (95%), errors: 0.00, reconnects:  0.00
[2375s] threads: 64, tps: 1825.00, reads: 25540.01, writes: 7232.00, response time: 46.81ms (95%), errors: 0.00, reconnects:  0.00
[2376s] threads: 64, tps: 1710.00, reads: 23988.02, writes: 6898.01, response time: 50.49ms (95%), errors: 0.00, reconnects:  0.00
[2377s] threads: 64, tps: 1772.99, reads: 24698.84, writes: 7049.96, response time: 49.05ms (95%), errors: 0.00, reconnects:  0.00
[2378s] threads: 64, tps: 1799.00, reads: 25224.03, writes: 7206.01, response time: 51.70ms (95%), errors: 0.00, reconnects:  0.00
[2379s] threads: 64, tps: 1825.01, reads: 25561.09, writes: 7311.03, response time: 48.90ms (95%), errors: 0.00, reconnects:  0.00
[2380s] threads: 64, tps: 1688.00, reads: 23674.98, writes: 6780.00, response time: 53.95ms (95%), errors: 0.00, reconnects:  0.00
[2381s] threads: 64, tps: 1789.00, reads: 25147.03, writes: 7217.01, response time: 50.31ms (95%), errors: 0.00, reconnects:  0.00
[2382s] threads: 64, tps: 1811.00, reads: 25373.97, writes: 7240.99, response time: 49.79ms (95%), errors: 0.00, reconnects:  0.00
[2383s] threads: 64, tps: 1799.00, reads: 25139.01, writes: 7164.00, response time: 51.62ms (95%), errors: 0.00, reconnects:  0.00
[2384s] threads: 64, tps: 1766.00, reads: 24572.01, writes: 6997.00, response time: 51.27ms (95%), errors: 0.00, reconnects:  0.00
[2385s] threads: 64, tps: 1552.00, reads: 21818.99, writes: 6235.00, response time: 56.46ms (95%), errors: 0.00, reconnects:  0.00
[2386s] threads: 64, tps: 1531.00, reads: 21418.02, writes: 6130.01, response time: 58.84ms (95%), errors: 0.00, reconnects:  0.00
[2387s] threads: 64, tps: 1638.00, reads: 22957.97, writes: 6513.99, response time: 57.26ms (95%), errors: 0.00, reconnects:  0.00
[2388s] threads: 64, tps: 1701.99, reads: 23829.90, writes: 6816.97, response time: 53.34ms (95%), errors: 0.00, reconnects:  0.00
[2389s] threads: 64, tps: 1562.01, reads: 21900.09, writes: 6229.03, response time: 58.00ms (95%), errors: 0.00, reconnects:  0.00
[2390s] threads: 64, tps: 1646.00, reads: 23000.01, writes: 6609.00, response time: 54.08ms (95%), errors: 0.00, reconnects:  0.00
[2391s] threads: 64, tps: 1702.00, reads: 23785.00, writes: 6822.00, response time: 53.66ms (95%), errors: 0.00, reconnects:  0.00
[2392s] threads: 64, tps: 1780.00, reads: 24866.02, writes: 7120.00, response time: 51.64ms (95%), errors: 0.00, reconnects:  0.00
[2393s] threads: 64, tps: 1892.00, reads: 26549.97, writes: 7610.99, response time: 47.18ms (95%), errors: 0.00, reconnects:  0.00
[2394s] threads: 64, tps: 1830.00, reads: 25579.03, writes: 7276.01, response time: 51.18ms (95%), errors: 0.00, reconnects:  0.00
[2395s] threads: 64, tps: 1749.97, reads: 24598.65, writes: 7083.90, response time: 52.23ms (95%), errors: 0.00, reconnects:  0.00
[2396s] threads: 64, tps: 1837.03, reads: 25675.35, writes: 7250.10, response time: 49.52ms (95%), errors: 0.00, reconnects:  0.00
[2397s] threads: 64, tps: 1860.00, reads: 26075.04, writes: 7488.01, response time: 49.25ms (95%), errors: 0.00, reconnects:  0.00
[2398s] threads: 64, tps: 1938.00, reads: 27026.98, writes: 7742.00, response time: 44.77ms (95%), errors: 0.00, reconnects:  0.00
[2399s] threads: 64, tps: 1938.00, reads: 27211.99, writes: 7750.00, response time: 46.18ms (95%), errors: 0.00, reconnects:  0.00
[2400s] threads: 64, tps: 1923.00, reads: 26841.02, writes: 7647.01, response time: 47.99ms (95%), errors: 0.00, reconnects:  0.00
[2401s] threads: 64, tps: 1970.00, reads: 27697.97, writes: 7939.99, response time: 45.08ms (95%), errors: 0.00, reconnects:  0.00
[2402s] threads: 64, tps: 1969.00, reads: 27582.99, writes: 7880.00, response time: 45.27ms (95%), errors: 0.00, reconnects:  0.00
[2403s] threads: 64, tps: 1926.99, reads: 26936.90, writes: 7713.97, response time: 49.50ms (95%), errors: 0.00, reconnects:  0.00
[2404s] threads: 64, tps: 1815.01, reads: 25409.12, writes: 7260.03, response time: 51.15ms (95%), errors: 0.00, reconnects:  0.00
[2405s] threads: 64, tps: 1637.99, reads: 23029.89, writes: 6583.97, response time: 54.37ms (95%), errors: 0.00, reconnects:  0.00
[2406s] threads: 64, tps: 1595.01, reads: 22229.11, writes: 6338.03, response time: 57.93ms (95%), errors: 0.00, reconnects:  0.00
[2407s] threads: 64, tps: 1726.00, reads: 24121.97, writes: 6826.99, response time: 54.53ms (95%), errors: 0.00, reconnects:  0.00
[2408s] threads: 64, tps: 1730.00, reads: 24126.96, writes: 6941.99, response time: 52.67ms (95%), errors: 0.00, reconnects:  0.00
[2409s] threads: 64, tps: 1797.00, reads: 25151.07, writes: 7215.02, response time: 49.97ms (95%), errors: 0.00, reconnects:  0.00
[2410s] threads: 64, tps: 1862.00, reads: 26260.02, writes: 7483.00, response time: 47.15ms (95%), errors: 0.00, reconnects:  0.00
[2411s] threads: 64, tps: 1851.97, reads: 25780.58, writes: 7347.88, response time: 49.48ms (95%), errors: 0.00, reconnects:  0.00
[2412s] threads: 64, tps: 1906.03, reads: 26835.39, writes: 7691.11, response time: 47.23ms (95%), errors: 0.00, reconnects:  0.00
[2413s] threads: 64, tps: 1890.00, reads: 26336.03, writes: 7522.01, response time: 47.83ms (95%), errors: 0.00, reconnects:  0.00
[2414s] threads: 64, tps: 1887.00, reads: 26487.00, writes: 7523.00, response time: 50.16ms (95%), errors: 0.00, reconnects:  0.00
[2415s] threads: 64, tps: 1885.00, reads: 26435.97, writes: 7578.99, response time: 48.20ms (95%), errors: 0.00, reconnects:  0.00
[2416s] threads: 64, tps: 1878.00, reads: 26198.00, writes: 7473.00, response time: 48.41ms (95%), errors: 0.00, reconnects:  0.00
[2417s] threads: 64, tps: 1722.00, reads: 24155.04, writes: 6898.01, response time: 54.69ms (95%), errors: 0.00, reconnects:  0.00
[2418s] threads: 64, tps: 1728.00, reads: 24085.95, writes: 6864.99, response time: 52.48ms (95%), errors: 0.00, reconnects:  0.00
[2419s] threads: 64, tps: 1537.98, reads: 21651.73, writes: 6181.92, response time: 58.71ms (95%), errors: 0.00, reconnects:  0.00
[2420s] threads: 64, tps: 1656.02, reads: 23165.32, writes: 6633.09, response time: 54.20ms (95%), errors: 0.00, reconnects:  0.00
[2421s] threads: 64, tps: 1678.00, reads: 23496.01, writes: 6716.00, response time: 52.46ms (95%), errors: 0.00, reconnects:  0.00
[2422s] threads: 64, tps: 1786.91, reads: 25008.78, writes: 7157.65, response time: 52.04ms (95%), errors: 0.00, reconnects:  0.00
[2423s] threads: 64, tps: 1864.05, reads: 26063.73, writes: 7467.21, response time: 49.25ms (95%), errors: 0.00, reconnects:  0.00
[2424s] threads: 64, tps: 1863.03, reads: 26072.40, writes: 7438.12, response time: 47.13ms (95%), errors: 0.00, reconnects:  0.00
[2425s] threads: 64, tps: 1958.01, reads: 27401.11, writes: 7828.03, response time: 47.15ms (95%), errors: 0.00, reconnects:  0.00
[2426s] threads: 64, tps: 1924.00, reads: 27101.02, writes: 7766.01, response time: 46.05ms (95%), errors: 0.00, reconnects:  0.00
[2427s] threads: 64, tps: 1987.00, reads: 27725.00, writes: 7919.00, response time: 46.05ms (95%), errors: 0.00, reconnects:  0.00
[2428s] threads: 64, tps: 1944.00, reads: 27236.98, writes: 7826.99, response time: 45.06ms (95%), errors: 0.00, reconnects:  0.00
[2429s] threads: 64, tps: 1948.00, reads: 27198.02, writes: 7731.01, response time: 46.88ms (95%), errors: 0.00, reconnects:  0.00
[2430s] threads: 64, tps: 1978.00, reads: 27643.00, writes: 7879.00, response time: 46.73ms (95%), errors: 0.00, reconnects:  0.00
[2431s] threads: 64, tps: 1980.00, reads: 27951.98, writes: 8044.99, response time: 43.94ms (95%), errors: 0.00, reconnects:  0.00
[2432s] threads: 64, tps: 2028.00, reads: 28252.98, writes: 8024.99, response time: 45.05ms (95%), errors: 0.00, reconnects:  0.00
[2433s] threads: 64, tps: 1986.00, reads: 27772.03, writes: 7922.01, response time: 45.72ms (95%), errors: 0.00, reconnects:  0.00
[2434s] threads: 64, tps: 1903.00, reads: 26613.99, writes: 7604.00, response time: 47.01ms (95%), errors: 0.00, reconnects:  0.00
[2435s] threads: 64, tps: 1781.00, reads: 24951.04, writes: 7095.01, response time: 50.27ms (95%), errors: 0.00, reconnects:  0.00
[2436s] threads: 64, tps: 1746.00, reads: 24383.01, writes: 6995.00, response time: 51.52ms (95%), errors: 0.00, reconnects:  0.00
[2437s] threads: 64, tps: 1787.00, reads: 25081.98, writes: 7149.99, response time: 49.11ms (95%), errors: 0.00, reconnects:  0.00
[2438s] threads: 64, tps: 1860.00, reads: 26091.98, writes: 7447.00, response time: 49.18ms (95%), errors: 0.00, reconnects:  0.00
[2439s] threads: 64, tps: 1884.00, reads: 26383.05, writes: 7600.01, response time: 47.10ms (95%), errors: 0.00, reconnects:  0.00
[2440s] threads: 64, tps: 1957.00, reads: 27251.97, writes: 7789.99, response time: 46.42ms (95%), errors: 0.00, reconnects:  0.00
[2441s] threads: 64, tps: 2003.00, reads: 28056.00, writes: 7985.00, response time: 44.47ms (95%), errors: 0.00, reconnects:  0.00
[2442s] threads: 64, tps: 1896.00, reads: 26663.00, writes: 7626.00, response time: 49.36ms (95%), errors: 0.00, reconnects:  0.00
[2443s] threads: 64, tps: 1935.00, reads: 27055.96, writes: 7715.99, response time: 46.68ms (95%), errors: 0.00, reconnects:  0.00
[2444s] threads: 64, tps: 1917.99, reads: 26938.87, writes: 7703.96, response time: 45.50ms (95%), errors: 0.00, reconnects:  0.00
[2445s] threads: 64, tps: 1897.01, reads: 26477.18, writes: 7548.05, response time: 46.54ms (95%), errors: 0.00, reconnects:  0.00
[2446s] threads: 64, tps: 1844.00, reads: 25942.99, writes: 7468.00, response time: 47.46ms (95%), errors: 0.00, reconnects:  0.00
[2447s] threads: 64, tps: 1816.00, reads: 25258.94, writes: 7138.98, response time: 50.99ms (95%), errors: 0.00, reconnects:  0.00
[2448s] threads: 64, tps: 1759.00, reads: 24584.04, writes: 7023.01, response time: 53.51ms (95%), errors: 0.00, reconnects:  0.00
[2449s] threads: 64, tps: 1426.00, reads: 20019.93, writes: 5718.98, response time: 65.42ms (95%), errors: 0.00, reconnects:  0.00
[2450s] threads: 64, tps: 1395.00, reads: 19565.99, writes: 5599.00, response time: 68.71ms (95%), errors: 0.00, reconnects:  0.00
[2451s] threads: 64, tps: 1496.00, reads: 21043.06, writes: 6052.02, response time: 62.45ms (95%), errors: 0.00, reconnects:  0.00
[2452s] threads: 64, tps: 1572.00, reads: 21921.03, writes: 6196.01, response time: 57.21ms (95%), errors: 0.00, reconnects:  0.00
[2453s] threads: 64, tps: 1589.00, reads: 22320.01, writes: 6417.00, response time: 54.78ms (95%), errors: 0.00, reconnects:  0.00
[2454s] threads: 64, tps: 1716.87, reads: 23951.24, writes: 6859.50, response time: 52.42ms (95%), errors: 0.00, reconnects:  0.00
[2455s] threads: 64, tps: 1740.11, reads: 24366.55, writes: 6955.44, response time: 55.04ms (95%), errors: 0.00, reconnects:  0.00
[2456s] threads: 64, tps: 1834.01, reads: 25628.21, writes: 7313.06, response time: 49.33ms (95%), errors: 0.00, reconnects:  0.00
[2457s] threads: 64, tps: 1869.99, reads: 26168.91, writes: 7491.97, response time: 49.27ms (95%), errors: 0.00, reconnects:  0.00
[2458s] threads: 64, tps: 1942.01, reads: 27184.15, writes: 7783.04, response time: 46.71ms (95%), errors: 0.00, reconnects:  0.00
[2459s] threads: 64, tps: 1820.00, reads: 25480.97, writes: 7266.99, response time: 50.01ms (95%), errors: 0.00, reconnects:  0.00
[2460s] threads: 64, tps: 1790.00, reads: 25001.00, writes: 7153.00, response time: 54.74ms (95%), errors: 0.00, reconnects:  0.00
[2461s] threads: 64, tps: 1934.00, reads: 27098.99, writes: 7705.00, response time: 49.79ms (95%), errors: 0.00, reconnects:  0.00
[2462s] threads: 64, tps: 1930.00, reads: 27203.98, writes: 7807.00, response time: 46.49ms (95%), errors: 0.00, reconnects:  0.00
[2463s] threads: 64, tps: 1964.00, reads: 27507.03, writes: 7862.01, response time: 46.73ms (95%), errors: 0.00, reconnects:  0.00
[2464s] threads: 64, tps: 1934.00, reads: 26923.99, writes: 7678.00, response time: 47.54ms (95%), errors: 0.00, reconnects:  0.00
[2465s] threads: 64, tps: 1925.99, reads: 26971.89, writes: 7711.97, response time: 47.44ms (95%), errors: 0.00, reconnects:  0.00
[2466s] threads: 64, tps: 1833.00, reads: 25655.03, writes: 7322.01, response time: 48.59ms (95%), errors: 0.00, reconnects:  0.00
[2467s] threads: 64, tps: 1747.00, reads: 24502.07, writes: 7010.02, response time: 50.04ms (95%), errors: 0.00, reconnects:  0.00
[2468s] threads: 64, tps: 1709.00, reads: 23826.03, writes: 6794.01, response time: 52.78ms (95%), errors: 0.00, reconnects:  0.00
[2469s] threads: 64, tps: 1757.99, reads: 24714.87, writes: 7064.96, response time: 50.04ms (95%), errors: 0.00, reconnects:  0.00
[2470s] threads: 64, tps: 1814.01, reads: 25400.10, writes: 7261.03, response time: 49.45ms (95%), errors: 0.00, reconnects:  0.00
[2471s] threads: 64, tps: 1749.00, reads: 24567.05, writes: 7022.01, response time: 52.21ms (95%), errors: 0.00, reconnects:  0.00
[2472s] threads: 64, tps: 1828.00, reads: 25563.00, writes: 7305.00, response time: 49.50ms (95%), errors: 0.00, reconnects:  0.00
[2473s] threads: 64, tps: 1868.00, reads: 25933.99, writes: 7448.00, response time: 51.04ms (95%), errors: 0.00, reconnects:  0.00
[2474s] threads: 64, tps: 1913.98, reads: 26934.79, writes: 7675.94, response time: 46.16ms (95%), errors: 0.00, reconnects:  0.00
[2475s] threads: 64, tps: 1919.01, reads: 26907.20, writes: 7670.06, response time: 46.66ms (95%), errors: 0.00, reconnects:  0.00
[2476s] threads: 64, tps: 1888.00, reads: 26542.98, writes: 7613.99, response time: 47.06ms (95%), errors: 0.00, reconnects:  0.00
[2477s] threads: 64, tps: 1798.96, reads: 25068.49, writes: 7127.85, response time: 51.47ms (95%), errors: 0.00, reconnects:  0.00
[2478s] threads: 64, tps: 1816.04, reads: 25331.51, writes: 7235.15, response time: 49.37ms (95%), errors: 0.00, reconnects:  0.00
[2479s] threads: 64, tps: 1747.00, reads: 24455.04, writes: 6972.01, response time: 51.21ms (95%), errors: 0.00, reconnects:  0.00
[2480s] threads: 64, tps: 1720.00, reads: 24112.97, writes: 6889.99, response time: 50.87ms (95%), errors: 0.00, reconnects:  0.00
[2481s] threads: 64, tps: 1565.00, reads: 21976.03, writes: 6233.01, response time: 60.39ms (95%), errors: 0.00, reconnects:  0.00
[2482s] threads: 64, tps: 1492.00, reads: 20864.00, writes: 5962.00, response time: 66.86ms (95%), errors: 0.00, reconnects:  0.00
[2483s] threads: 64, tps: 1494.00, reads: 20960.00, writes: 6029.00, response time: 62.10ms (95%), errors: 0.00, reconnects:  0.00
[2484s] threads: 64, tps: 1657.00, reads: 23201.97, writes: 6656.99, response time: 52.97ms (95%), errors: 0.00, reconnects:  0.00
[2485s] threads: 64, tps: 1806.00, reads: 25239.01, writes: 7221.00, response time: 51.55ms (95%), errors: 0.00, reconnects:  0.00
[2486s] threads: 64, tps: 1808.99, reads: 25327.87, writes: 7188.96, response time: 49.08ms (95%), errors: 0.00, reconnects:  0.00
[2487s] threads: 64, tps: 1850.01, reads: 25884.13, writes: 7452.04, response time: 50.03ms (95%), errors: 0.00, reconnects:  0.00
[2488s] threads: 64, tps: 1762.00, reads: 24639.03, writes: 7025.01, response time: 50.73ms (95%), errors: 0.00, reconnects:  0.00
[2489s] threads: 64, tps: 1812.00, reads: 25422.00, writes: 7241.00, response time: 47.30ms (95%), errors: 0.00, reconnects:  0.00
[2490s] threads: 64, tps: 1801.99, reads: 25201.88, writes: 7239.97, response time: 49.43ms (95%), errors: 0.00, reconnects:  0.00
[2491s] threads: 64, tps: 1809.01, reads: 25391.09, writes: 7269.03, response time: 50.00ms (95%), errors: 0.00, reconnects:  0.00
[2492s] threads: 64, tps: 1909.00, reads: 26811.98, writes: 7649.00, response time: 48.83ms (95%), errors: 0.00, reconnects:  0.00
[2493s] threads: 64, tps: 1764.00, reads: 24500.02, writes: 6939.01, response time: 52.25ms (95%), errors: 0.00, reconnects:  0.00
[2494s] threads: 64, tps: 1837.00, reads: 25847.99, writes: 7401.00, response time: 48.13ms (95%), errors: 0.00, reconnects:  0.00
[2495s] threads: 64, tps: 1867.99, reads: 26082.87, writes: 7450.96, response time: 48.26ms (95%), errors: 0.00, reconnects:  0.00
[2496s] threads: 64, tps: 1767.01, reads: 24645.14, writes: 7048.04, response time: 50.06ms (95%), errors: 0.00, reconnects:  0.00
[2497s] threads: 64, tps: 1643.00, reads: 23112.99, writes: 6585.00, response time: 53.58ms (95%), errors: 0.00, reconnects:  0.00
[2498s] threads: 64, tps: 1650.97, reads: 23029.55, writes: 6583.87, response time: 52.53ms (95%), errors: 0.00, reconnects:  0.00
[2499s] threads: 64, tps: 1607.03, reads: 22490.43, writes: 6426.12, response time: 55.75ms (95%), errors: 0.00, reconnects:  0.00
[2500s] threads: 64, tps: 1657.00, reads: 23336.99, writes: 6712.00, response time: 53.77ms (95%), errors: 0.00, reconnects:  0.00
[2501s] threads: 64, tps: 1848.00, reads: 25661.98, writes: 7332.00, response time: 49.71ms (95%), errors: 0.00, reconnects:  0.00
[2502s] threads: 64, tps: 1776.00, reads: 24996.99, writes: 7123.00, response time: 51.12ms (95%), errors: 0.00, reconnects:  0.00
[2503s] threads: 64, tps: 1879.00, reads: 26251.97, writes: 7502.99, response time: 47.29ms (95%), errors: 0.00, reconnects:  0.00
[2504s] threads: 64, tps: 1872.00, reads: 26311.06, writes: 7500.02, response time: 47.66ms (95%), errors: 0.00, reconnects:  0.00
[2505s] threads: 64, tps: 1841.00, reads: 25754.02, writes: 7353.01, response time: 48.59ms (95%), errors: 0.00, reconnects:  0.00
[2506s] threads: 64, tps: 1825.00, reads: 25542.95, writes: 7305.99, response time: 50.83ms (95%), errors: 0.00, reconnects:  0.00
[2507s] threads: 64, tps: 1756.00, reads: 24633.06, writes: 7043.02, response time: 51.07ms (95%), errors: 0.00, reconnects:  0.00
[2508s] threads: 64, tps: 1791.00, reads: 25041.97, writes: 7156.99, response time: 49.59ms (95%), errors: 0.00, reconnects:  0.00
[2509s] threads: 64, tps: 1778.00, reads: 24808.02, writes: 7071.01, response time: 50.27ms (95%), errors: 0.00, reconnects:  0.00
[2510s] threads: 64, tps: 1674.00, reads: 23457.99, writes: 6692.00, response time: 52.75ms (95%), errors: 0.00, reconnects:  0.00
[2511s] threads: 64, tps: 1491.00, reads: 20924.01, writes: 5958.00, response time: 60.61ms (95%), errors: 0.00, reconnects:  0.00
[2512s] threads: 64, tps: 1266.00, reads: 17716.00, writes: 5059.00, response time: 75.36ms (95%), errors: 0.00, reconnects:  0.00
[2513s] threads: 64, tps: 1525.00, reads: 21326.97, writes: 6120.99, response time: 59.09ms (95%), errors: 0.00, reconnects:  0.00
[2514s] threads: 64, tps: 1593.00, reads: 22313.01, writes: 6425.00, response time: 55.29ms (95%), errors: 0.00, reconnects:  0.00
[2515s] threads: 64, tps: 1747.97, reads: 24418.57, writes: 6934.88, response time: 51.79ms (95%), errors: 0.00, reconnects:  0.00
[2516s] threads: 64, tps: 1741.03, reads: 24519.42, writes: 7035.12, response time: 52.31ms (95%), errors: 0.00, reconnects:  0.00
[2517s] threads: 64, tps: 1711.00, reads: 23920.97, writes: 6843.99, response time: 51.98ms (95%), errors: 0.00, reconnects:  0.00
[2518s] threads: 64, tps: 1718.00, reads: 23942.06, writes: 6810.02, response time: 52.61ms (95%), errors: 0.00, reconnects:  0.00
[2519s] threads: 64, tps: 1696.99, reads: 23708.89, writes: 6785.97, response time: 54.30ms (95%), errors: 0.00, reconnects:  0.00
[2520s] threads: 64, tps: 1675.01, reads: 23564.14, writes: 6718.04, response time: 52.92ms (95%), errors: 0.00, reconnects:  0.00
[2521s] threads: 64, tps: 1690.00, reads: 23646.99, writes: 6745.00, response time: 57.43ms (95%), errors: 0.00, reconnects:  0.00
[2522s] threads: 64, tps: 1808.00, reads: 25298.98, writes: 7266.99, response time: 48.48ms (95%), errors: 0.00, reconnects:  0.00
[2523s] threads: 64, tps: 1722.00, reads: 24264.04, writes: 6964.01, response time: 50.70ms (95%), errors: 0.00, reconnects:  0.00
[2524s] threads: 64, tps: 1771.00, reads: 24715.94, writes: 7025.98, response time: 50.58ms (95%), errors: 0.00, reconnects:  0.00
[2525s] threads: 64, tps: 1785.00, reads: 25037.02, writes: 7136.01, response time: 49.77ms (95%), errors: 0.00, reconnects:  0.00
[2526s] threads: 64, tps: 1714.00, reads: 23852.01, writes: 6801.00, response time: 51.58ms (95%), errors: 0.00, reconnects:  0.00
[2527s] threads: 64, tps: 1583.00, reads: 22153.00, writes: 6307.00, response time: 54.08ms (95%), errors: 0.00, reconnects:  0.00
[2528s] threads: 64, tps: 1545.00, reads: 21638.00, writes: 6182.00, response time: 55.80ms (95%), errors: 0.00, reconnects:  0.00
[2529s] threads: 64, tps: 1587.99, reads: 22193.82, writes: 6374.95, response time: 54.11ms (95%), errors: 0.00, reconnects:  0.00
[2530s] threads: 64, tps: 1728.01, reads: 24307.19, writes: 6971.05, response time: 50.77ms (95%), errors: 0.00, reconnects:  0.00
[2531s] threads: 64, tps: 1862.00, reads: 25957.01, writes: 7372.00, response time: 47.47ms (95%), errors: 0.00, reconnects:  0.00
[2532s] threads: 64, tps: 1767.00, reads: 24767.04, writes: 7134.01, response time: 50.55ms (95%), errors: 0.00, reconnects:  0.00
[2533s] threads: 64, tps: 1660.00, reads: 23242.96, writes: 6599.99, response time: 53.34ms (95%), errors: 0.00, reconnects:  0.00
[2534s] threads: 64, tps: 1748.00, reads: 24448.93, writes: 7003.98, response time: 49.53ms (95%), errors: 0.00, reconnects:  0.00
[2535s] threads: 64, tps: 1739.00, reads: 24498.02, writes: 6988.01, response time: 51.12ms (95%), errors: 0.00, reconnects:  0.00
[2536s] threads: 64, tps: 1696.00, reads: 23633.06, writes: 6740.02, response time: 53.83ms (95%), errors: 0.00, reconnects:  0.00
[2537s] threads: 64, tps: 1693.99, reads: 23749.90, writes: 6799.97, response time: 51.15ms (95%), errors: 0.00, reconnects:  0.00
[2538s] threads: 64, tps: 1735.00, reads: 24252.98, writes: 6925.99, response time: 51.27ms (95%), errors: 0.00, reconnects:  0.00
[2539s] threads: 64, tps: 1659.01, reads: 23238.11, writes: 6624.03, response time: 52.76ms (95%), errors: 0.00, reconnects:  0.00
[2540s] threads: 64, tps: 1637.00, reads: 22902.04, writes: 6522.01, response time: 54.32ms (95%), errors: 0.00, reconnects:  0.00
[2541s] threads: 64, tps: 1416.99, reads: 19882.88, writes: 5661.96, response time: 65.06ms (95%), errors: 0.00, reconnects:  0.00
[2542s] threads: 64, tps: 1489.01, reads: 20819.10, writes: 5962.03, response time: 60.55ms (95%), errors: 0.00, reconnects:  0.00
[2543s] threads: 64, tps: 1494.00, reads: 20852.02, writes: 5974.01, response time: 58.73ms (95%), errors: 0.00, reconnects:  0.00
[2544s] threads: 64, tps: 1529.98, reads: 21338.73, writes: 6140.92, response time: 58.66ms (95%), errors: 0.00, reconnects:  0.00
[2545s] threads: 64, tps: 1574.02, reads: 22207.27, writes: 6348.08, response time: 56.12ms (95%), errors: 0.00, reconnects:  0.00
[2546s] threads: 64, tps: 1618.00, reads: 22669.96, writes: 6470.99, response time: 55.87ms (95%), errors: 0.00, reconnects:  0.00
[2547s] threads: 64, tps: 1711.00, reads: 23748.04, writes: 6763.01, response time: 51.55ms (95%), errors: 0.00, reconnects:  0.00
[2548s] threads: 64, tps: 1662.00, reads: 23564.00, writes: 6774.00, response time: 52.03ms (95%), errors: 0.00, reconnects:  0.00
[2549s] threads: 64, tps: 1740.00, reads: 24298.99, writes: 6910.00, response time: 51.28ms (95%), errors: 0.00, reconnects:  0.00
[2550s] threads: 64, tps: 1681.00, reads: 23482.01, writes: 6706.00, response time: 56.31ms (95%), errors: 0.00, reconnects:  0.00
[2551s] threads: 64, tps: 1746.00, reads: 24447.01, writes: 6982.00, response time: 52.10ms (95%), errors: 0.00, reconnects:  0.00
[2552s] threads: 64, tps: 1724.00, reads: 24118.00, writes: 6904.00, response time: 51.36ms (95%), errors: 0.00, reconnects:  0.00
[2553s] threads: 64, tps: 1765.00, reads: 24534.97, writes: 7026.99, response time: 52.86ms (95%), errors: 0.00, reconnects:  0.00
[2554s] threads: 64, tps: 1677.00, reads: 23792.04, writes: 6778.01, response time: 52.59ms (95%), errors: 0.00, reconnects:  0.00
[2555s] threads: 64, tps: 1684.00, reads: 23406.00, writes: 6658.00, response time: 51.79ms (95%), errors: 0.00, reconnects:  0.00
[2556s] threads: 64, tps: 1598.00, reads: 22386.98, writes: 6365.99, response time: 54.84ms (95%), errors: 0.00, reconnects:  0.00
[2557s] threads: 64, tps: 1541.00, reads: 21479.00, writes: 6171.00, response time: 57.96ms (95%), errors: 0.00, reconnects:  0.00
[2558s] threads: 64, tps: 1463.00, reads: 20583.98, writes: 5847.99, response time: 61.67ms (95%), errors: 0.00, reconnects:  0.00
[2559s] threads: 64, tps: 1595.00, reads: 22299.04, writes: 6409.01, response time: 57.12ms (95%), errors: 0.00, reconnects:  0.00
[2560s] threads: 64, tps: 1771.00, reads: 24818.01, writes: 7119.00, response time: 51.22ms (95%), errors: 0.00, reconnects:  0.00
[2561s] threads: 64, tps: 1886.00, reads: 26389.00, writes: 7517.00, response time: 47.70ms (95%), errors: 0.00, reconnects:  0.00
[2562s] threads: 64, tps: 1843.00, reads: 25867.97, writes: 7438.99, response time: 48.74ms (95%), errors: 0.00, reconnects:  0.00
[2563s] threads: 64, tps: 1747.00, reads: 24532.02, writes: 7023.01, response time: 51.13ms (95%), errors: 0.00, reconnects:  0.00
[2564s] threads: 64, tps: 1804.00, reads: 25151.97, writes: 7105.99, response time: 51.59ms (95%), errors: 0.00, reconnects:  0.00
[2565s] threads: 64, tps: 1843.00, reads: 25770.01, writes: 7378.00, response time: 48.36ms (95%), errors: 0.00, reconnects:  0.00
[2566s] threads: 64, tps: 1773.00, reads: 24871.03, writes: 7137.01, response time: 48.97ms (95%), errors: 0.00, reconnects:  0.00
[2567s] threads: 64, tps: 1706.00, reads: 23911.96, writes: 6833.99, response time: 54.35ms (95%), errors: 0.00, reconnects:  0.00
[2568s] threads: 64, tps: 1763.00, reads: 24745.06, writes: 7081.02, response time: 50.73ms (95%), errors: 0.00, reconnects:  0.00
[2569s] threads: 64, tps: 1703.98, reads: 23777.77, writes: 6723.94, response time: 51.50ms (95%), errors: 0.00, reconnects:  0.00
[2570s] threads: 64, tps: 1668.01, reads: 23395.17, writes: 6770.05, response time: 54.11ms (95%), errors: 0.00, reconnects:  0.00
[2571s] threads: 64, tps: 1559.00, reads: 21714.02, writes: 6141.01, response time: 57.46ms (95%), errors: 0.00, reconnects:  0.00
[2572s] threads: 64, tps: 1554.00, reads: 21720.98, writes: 6194.99, response time: 56.20ms (95%), errors: 0.00, reconnects:  0.00
[2573s] threads: 64, tps: 1546.00, reads: 21278.01, writes: 6188.00, response time: 59.00ms (95%), errors: 0.00, reconnects:  0.00
[2574s] threads: 64, tps: 1457.00, reads: 20855.03, writes: 5865.01, response time: 61.34ms (95%), errors: 0.00, reconnects:  0.00
[2575s] threads: 64, tps: 1725.00, reads: 24031.94, writes: 6878.98, response time: 52.84ms (95%), errors: 0.00, reconnects:  0.00
[2576s] threads: 64, tps: 1762.00, reads: 24764.99, writes: 7058.00, response time: 50.15ms (95%), errors: 0.00, reconnects:  0.00
[2577s] threads: 64, tps: 1823.00, reads: 25596.00, writes: 7340.00, response time: 48.57ms (95%), errors: 0.00, reconnects:  0.00
[2578s] threads: 64, tps: 1905.00, reads: 26565.04, writes: 7580.01, response time: 46.59ms (95%), errors: 0.00, reconnects:  0.00
[2579s] threads: 64, tps: 1746.00, reads: 24384.97, writes: 6967.99, response time: 52.42ms (95%), errors: 0.00, reconnects:  0.00
[2580s] threads: 64, tps: 1711.00, reads: 24091.01, writes: 6889.00, response time: 51.98ms (95%), errors: 0.00, reconnects:  0.00
[2581s] threads: 64, tps: 1750.00, reads: 24289.04, writes: 6935.01, response time: 51.90ms (95%), errors: 0.00, reconnects:  0.00
[2582s] threads: 64, tps: 1801.00, reads: 25216.95, writes: 7207.99, response time: 50.73ms (95%), errors: 0.00, reconnects:  0.00
[2583s] threads: 64, tps: 1796.00, reads: 25346.05, writes: 7214.01, response time: 52.43ms (95%), errors: 0.00, reconnects:  0.00
[2584s] threads: 64, tps: 1740.00, reads: 24136.03, writes: 6918.01, response time: 52.73ms (95%), errors: 0.00, reconnects:  0.00
[2585s] threads: 64, tps: 1531.94, reads: 21581.16, writes: 6120.76, response time: 59.51ms (95%), errors: 0.00, reconnects:  0.00
[2586s] threads: 64, tps: 1463.05, reads: 20458.73, writes: 5859.21, response time: 60.50ms (95%), errors: 0.00, reconnects:  0.00
[2587s] threads: 64, tps: 1565.00, reads: 21977.03, writes: 6269.01, response time: 57.38ms (95%), errors: 0.00, reconnects:  0.00
[2588s] threads: 64, tps: 1505.00, reads: 21074.99, writes: 6056.00, response time: 60.59ms (95%), errors: 0.00, reconnects:  0.00
[2589s] threads: 64, tps: 1655.00, reads: 23210.02, writes: 6616.01, response time: 56.19ms (95%), errors: 0.00, reconnects:  0.00
[2590s] threads: 64, tps: 1741.00, reads: 24373.99, writes: 6984.00, response time: 51.82ms (95%), errors: 0.00, reconnects:  0.00
[2591s] threads: 64, tps: 1795.00, reads: 24958.00, writes: 7143.00, response time: 49.03ms (95%), errors: 0.00, reconnects:  0.00
[2592s] threads: 64, tps: 1863.00, reads: 26119.00, writes: 7466.00, response time: 48.71ms (95%), errors: 0.00, reconnects:  0.00
[2593s] threads: 64, tps: 1730.00, reads: 24330.99, writes: 6978.00, response time: 53.53ms (95%), errors: 0.00, reconnects:  0.00
[2594s] threads: 64, tps: 1821.00, reads: 25609.02, writes: 7303.00, response time: 49.79ms (95%), errors: 0.00, reconnects:  0.00
[2595s] threads: 64, tps: 1824.00, reads: 25360.98, writes: 7214.99, response time: 48.54ms (95%), errors: 0.00, reconnects:  0.00
[2596s] threads: 64, tps: 1784.00, reads: 24912.96, writes: 7145.99, response time: 49.06ms (95%), errors: 0.00, reconnects:  0.00
[2597s] threads: 64, tps: 1802.00, reads: 25268.06, writes: 7229.02, response time: 48.87ms (95%), errors: 0.00, reconnects:  0.00
[2598s] threads: 64, tps: 1791.00, reads: 25184.99, writes: 7155.00, response time: 49.98ms (95%), errors: 0.00, reconnects:  0.00
[2599s] threads: 64, tps: 1759.00, reads: 24592.99, writes: 7005.00, response time: 50.15ms (95%), errors: 0.00, reconnects:  0.00
[2600s] threads: 64, tps: 1616.00, reads: 22557.99, writes: 6433.00, response time: 54.42ms (95%), errors: 0.00, reconnects:  0.00
[2601s] threads: 64, tps: 1466.99, reads: 20597.92, writes: 5869.98, response time: 64.87ms (95%), errors: 0.00, reconnects:  0.00
[2602s] threads: 64, tps: 1479.00, reads: 20748.06, writes: 5949.02, response time: 61.43ms (95%), errors: 0.00, reconnects:  0.00
[2603s] threads: 64, tps: 1560.00, reads: 21915.05, writes: 6347.02, response time: 54.97ms (95%), errors: 0.00, reconnects:  0.00
[2604s] threads: 64, tps: 1705.99, reads: 23720.87, writes: 6708.96, response time: 53.54ms (95%), errors: 0.00, reconnects:  0.00
[2605s] threads: 64, tps: 1785.01, reads: 24929.11, writes: 7158.03, response time: 48.68ms (95%), errors: 0.00, reconnects:  0.00
[2606s] threads: 64, tps: 1771.00, reads: 24847.01, writes: 7103.00, response time: 50.55ms (95%), errors: 0.00, reconnects:  0.00
[2607s] threads: 64, tps: 1798.97, reads: 25242.65, writes: 7188.90, response time: 48.92ms (95%), errors: 0.00, reconnects:  0.00
[2608s] threads: 64, tps: 1845.03, reads: 25780.36, writes: 7381.10, response time: 48.26ms (95%), errors: 0.00, reconnects:  0.00
[2609s] threads: 64, tps: 1787.98, reads: 24968.75, writes: 7129.93, response time: 49.06ms (95%), errors: 0.00, reconnects:  0.00
[2610s] threads: 64, tps: 1829.02, reads: 25792.23, writes: 7421.07, response time: 49.45ms (95%), errors: 0.00, reconnects:  0.00
[2611s] threads: 64, tps: 1831.00, reads: 25680.01, writes: 7296.00, response time: 48.90ms (95%), errors: 0.00, reconnects:  0.00
[2612s] threads: 64, tps: 1787.00, reads: 24915.00, writes: 7114.00, response time: 49.67ms (95%), errors: 0.00, reconnects:  0.00
[2613s] threads: 64, tps: 1718.00, reads: 24011.00, writes: 6850.00, response time: 52.37ms (95%), errors: 0.00, reconnects:  0.00
[2614s] threads: 64, tps: 1671.00, reads: 23462.01, writes: 6698.00, response time: 51.75ms (95%), errors: 0.00, reconnects:  0.00
[2615s] threads: 64, tps: 1603.00, reads: 22281.02, writes: 6345.01, response time: 55.85ms (95%), errors: 0.00, reconnects:  0.00
[2616s] threads: 64, tps: 1518.00, reads: 21352.95, writes: 6117.98, response time: 59.85ms (95%), errors: 0.00, reconnects:  0.00
[2617s] threads: 64, tps: 1651.00, reads: 23078.03, writes: 6582.01, response time: 52.86ms (95%), errors: 0.00, reconnects:  0.00
[2618s] threads: 64, tps: 1702.00, reads: 23897.97, writes: 6832.99, response time: 50.96ms (95%), errors: 0.00, reconnects:  0.00
[2619s] threads: 64, tps: 1784.00, reads: 25001.01, writes: 7180.00, response time: 49.03ms (95%), errors: 0.00, reconnects:  0.00
[2620s] threads: 64, tps: 1845.00, reads: 25677.03, writes: 7328.01, response time: 48.97ms (95%), errors: 0.00, reconnects:  0.00
[2621s] threads: 64, tps: 1777.00, reads: 25001.98, writes: 7130.00, response time: 52.23ms (95%), errors: 0.00, reconnects:  0.00
[2622s] threads: 64, tps: 1825.00, reads: 25376.98, writes: 7300.00, response time: 51.12ms (95%), errors: 0.00, reconnects:  0.00
[2623s] threads: 64, tps: 1700.00, reads: 23928.02, writes: 6813.00, response time: 53.88ms (95%), errors: 0.00, reconnects:  0.00
[2624s] threads: 64, tps: 1757.00, reads: 24630.02, writes: 6978.01, response time: 51.38ms (95%), errors: 0.00, reconnects:  0.00
[2625s] threads: 64, tps: 1801.00, reads: 25265.98, writes: 7263.00, response time: 49.00ms (95%), errors: 0.00, reconnects:  0.00
[2626s] threads: 64, tps: 1777.00, reads: 24729.00, writes: 7053.00, response time: 50.63ms (95%), errors: 0.00, reconnects:  0.00
[2627s] threads: 64, tps: 1721.00, reads: 24093.00, writes: 6853.00, response time: 52.70ms (95%), errors: 0.00, reconnects:  0.00
[2628s] threads: 64, tps: 1692.00, reads: 23681.96, writes: 6790.99, response time: 56.14ms (95%), errors: 0.00, reconnects:  0.00
[2629s] threads: 64, tps: 1666.00, reads: 23343.05, writes: 6659.01, response time: 52.61ms (95%), errors: 0.00, reconnects:  0.00
[2630s] threads: 64, tps: 1569.00, reads: 22072.99, writes: 6312.00, response time: 58.21ms (95%), errors: 0.00, reconnects:  0.00
[2631s] threads: 64, tps: 1494.00, reads: 20914.01, writes: 5922.00, response time: 59.64ms (95%), errors: 0.00, reconnects:  0.00
[2632s] threads: 64, tps: 1477.00, reads: 20712.99, writes: 5946.00, response time: 62.36ms (95%), errors: 0.00, reconnects:  0.00
[2633s] threads: 64, tps: 1524.00, reads: 21220.99, writes: 6070.00, response time: 60.72ms (95%), errors: 0.00, reconnects:  0.00
[2634s] threads: 64, tps: 1624.00, reads: 22752.00, writes: 6477.00, response time: 55.57ms (95%), errors: 0.00, reconnects:  0.00
[2635s] threads: 64, tps: 1707.00, reads: 23814.02, writes: 6865.01, response time: 52.21ms (95%), errors: 0.00, reconnects:  0.00
[2636s] threads: 64, tps: 1732.00, reads: 24335.99, writes: 6996.00, response time: 50.81ms (95%), errors: 0.00, reconnects:  0.00
[2637s] threads: 64, tps: 1815.00, reads: 25413.02, writes: 7259.01, response time: 48.97ms (95%), errors: 0.00, reconnects:  0.00
[2638s] threads: 64, tps: 1867.00, reads: 26076.97, writes: 7415.99, response time: 48.58ms (95%), errors: 0.00, reconnects:  0.00
[2639s] threads: 64, tps: 1861.00, reads: 26221.02, writes: 7475.01, response time: 47.06ms (95%), errors: 0.00, reconnects:  0.00
[2640s] threads: 64, tps: 1764.00, reads: 24557.03, writes: 7024.01, response time: 52.00ms (95%), errors: 0.00, reconnects:  0.00
[2641s] threads: 64, tps: 1777.00, reads: 25013.97, writes: 7168.99, response time: 51.69ms (95%), errors: 0.00, reconnects:  0.00
[2642s] threads: 64, tps: 1884.00, reads: 26080.99, writes: 7478.00, response time: 47.53ms (95%), errors: 0.00, reconnects:  0.00
[2643s] threads: 64, tps: 1823.00, reads: 25844.00, writes: 7361.00, response time: 48.23ms (95%), errors: 0.00, reconnects:  0.00
[2644s] threads: 64, tps: 1716.00, reads: 23958.00, writes: 6838.00, response time: 51.13ms (95%), errors: 0.00, reconnects:  0.00
[2645s] threads: 64, tps: 1616.00, reads: 22603.98, writes: 6419.99, response time: 57.74ms (95%), errors: 0.00, reconnects:  0.00
[2646s] threads: 64, tps: 1602.00, reads: 22395.03, writes: 6385.01, response time: 55.19ms (95%), errors: 0.00, reconnects:  0.00
[2647s] threads: 64, tps: 1651.00, reads: 23053.00, writes: 6606.00, response time: 53.50ms (95%), errors: 0.00, reconnects:  0.00
[2648s] threads: 64, tps: 1696.00, reads: 23769.99, writes: 6820.00, response time: 52.42ms (95%), errors: 0.00, reconnects:  0.00
[2649s] threads: 64, tps: 1797.00, reads: 25069.01, writes: 7128.00, response time: 48.13ms (95%), errors: 0.00, reconnects:  0.00
[2650s] threads: 64, tps: 1792.00, reads: 25231.98, writes: 7235.99, response time: 50.27ms (95%), errors: 0.00, reconnects:  0.00
[2651s] threads: 64, tps: 1853.00, reads: 25815.03, writes: 7371.01, response time: 50.66ms (95%), errors: 0.00, reconnects:  0.00
[2652s] threads: 64, tps: 1827.00, reads: 25716.99, writes: 7329.00, response time: 51.59ms (95%), errors: 0.00, reconnects:  0.00
[2653s] threads: 64, tps: 1750.00, reads: 24483.97, writes: 7005.99, response time: 51.04ms (95%), errors: 0.00, reconnects:  0.00
[2654s] threads: 64, tps: 1850.00, reads: 25953.02, writes: 7438.01, response time: 49.27ms (95%), errors: 0.00, reconnects:  0.00
[2655s] threads: 64, tps: 1843.00, reads: 25785.00, writes: 7323.00, response time: 48.25ms (95%), errors: 0.00, reconnects:  0.00
[2656s] threads: 64, tps: 1780.00, reads: 24878.00, writes: 7098.00, response time: 49.37ms (95%), errors: 0.00, reconnects:  0.00
[2657s] threads: 64, tps: 1832.00, reads: 25711.02, writes: 7371.01, response time: 50.55ms (95%), errors: 0.00, reconnects:  0.00
[2658s] threads: 64, tps: 1752.00, reads: 24440.00, writes: 6962.00, response time: 51.59ms (95%), errors: 0.00, reconnects:  0.00
[2659s] threads: 64, tps: 1734.00, reads: 24248.97, writes: 6944.99, response time: 50.60ms (95%), errors: 0.00, reconnects:  0.00
[2660s] threads: 64, tps: 1686.00, reads: 23654.01, writes: 6727.00, response time: 54.74ms (95%), errors: 0.00, reconnects:  0.00
[2661s] threads: 64, tps: 1508.00, reads: 21120.02, writes: 6028.00, response time: 61.76ms (95%), errors: 0.00, reconnects:  0.00
[2662s] threads: 64, tps: 1543.00, reads: 21668.97, writes: 6171.99, response time: 57.45ms (95%), errors: 0.00, reconnects:  0.00
[2663s] threads: 64, tps: 1602.00, reads: 22329.01, writes: 6439.00, response time: 55.42ms (95%), errors: 0.00, reconnects:  0.00
[2664s] threads: 64, tps: 1614.99, reads: 22620.92, writes: 6437.98, response time: 54.22ms (95%), errors: 0.00, reconnects:  0.00
[2665s] threads: 64, tps: 1750.01, reads: 24617.11, writes: 7093.03, response time: 49.89ms (95%), errors: 0.00, reconnects:  0.00
[2666s] threads: 64, tps: 1808.00, reads: 25263.96, writes: 7223.99, response time: 48.74ms (95%), errors: 0.00, reconnects:  0.00
[2667s] threads: 64, tps: 1783.00, reads: 24958.01, writes: 7104.00, response time: 50.42ms (95%), errors: 0.00, reconnects:  0.00
[2668s] threads: 64, tps: 1745.00, reads: 24547.98, writes: 7079.00, response time: 53.27ms (95%), errors: 0.00, reconnects:  0.00
[2669s] threads: 64, tps: 1852.00, reads: 25717.02, writes: 7300.01, response time: 49.95ms (95%), errors: 0.00, reconnects:  0.00
[2670s] threads: 64, tps: 1840.99, reads: 25831.91, writes: 7331.97, response time: 48.41ms (95%), errors: 0.00, reconnects:  0.00
[2671s] threads: 64, tps: 1821.01, reads: 25619.10, writes: 7398.03, response time: 49.15ms (95%), errors: 0.00, reconnects:  0.00
[2672s] threads: 64, tps: 1781.00, reads: 24785.02, writes: 7010.01, response time: 51.93ms (95%), errors: 0.00, reconnects:  0.00
[2673s] threads: 64, tps: 1703.00, reads: 23778.99, writes: 6842.00, response time: 52.99ms (95%), errors: 0.00, reconnects:  0.00
[2674s] threads: 64, tps: 1580.00, reads: 22280.98, writes: 6358.99, response time: 56.04ms (95%), errors: 0.00, reconnects:  0.00
[2675s] threads: 64, tps: 1553.00, reads: 21742.02, writes: 6202.00, response time: 55.87ms (95%), errors: 0.00, reconnects:  0.00
[2676s] threads: 64, tps: 1647.89, reads: 22918.48, writes: 6508.57, response time: 54.71ms (95%), errors: 0.00, reconnects:  0.00
[2677s] threads: 64, tps: 1615.11, reads: 22589.49, writes: 6502.43, response time: 54.06ms (95%), errors: 0.00, reconnects:  0.00
[2678s] threads: 64, tps: 1691.00, reads: 23870.00, writes: 6823.00, response time: 51.22ms (95%), errors: 0.00, reconnects:  0.00
[2679s] threads: 64, tps: 1827.00, reads: 25460.00, writes: 7252.00, response time: 48.22ms (95%), errors: 0.00, reconnects:  0.00
[2680s] threads: 64, tps: 1834.00, reads: 25801.99, writes: 7404.00, response time: 47.62ms (95%), errors: 0.00, reconnects:  0.00
[2681s] threads: 64, tps: 1931.00, reads: 26915.00, writes: 7703.00, response time: 45.78ms (95%), errors: 0.00, reconnects:  0.00
[2682s] threads: 64, tps: 1886.00, reads: 26426.04, writes: 7512.01, response time: 48.19ms (95%), errors: 0.00, reconnects:  0.00
[2683s] threads: 64, tps: 1867.00, reads: 26081.97, writes: 7424.99, response time: 48.55ms (95%), errors: 0.00, reconnects:  0.00
[2684s] threads: 64, tps: 1934.00, reads: 27156.01, writes: 7817.00, response time: 46.24ms (95%), errors: 0.00, reconnects:  0.00
[2685s] threads: 64, tps: 1906.00, reads: 26696.99, writes: 7585.00, response time: 45.00ms (95%), errors: 0.00, reconnects:  0.00
[2686s] threads: 64, tps: 1861.00, reads: 26030.02, writes: 7437.01, response time: 46.73ms (95%), errors: 0.00, reconnects:  0.00
[2687s] threads: 64, tps: 1871.00, reads: 26191.93, writes: 7480.98, response time: 48.65ms (95%), errors: 0.00, reconnects:  0.00
[2688s] threads: 64, tps: 1878.01, reads: 26221.09, writes: 7499.03, response time: 47.82ms (95%), errors: 0.00, reconnects:  0.00
[2689s] threads: 64, tps: 1803.00, reads: 25284.95, writes: 7161.99, response time: 49.88ms (95%), errors: 0.00, reconnects:  0.00
[2690s] threads: 64, tps: 1603.00, reads: 22430.02, writes: 6443.00, response time: 56.04ms (95%), errors: 0.00, reconnects:  0.00
[2691s] threads: 64, tps: 1478.00, reads: 20685.99, writes: 5899.00, response time: 59.05ms (95%), errors: 0.00, reconnects:  0.00
[2692s] threads: 64, tps: 1479.98, reads: 20719.70, writes: 5952.91, response time: 60.39ms (95%), errors: 0.00, reconnects:  0.00
[2693s] threads: 64, tps: 1545.02, reads: 21657.31, writes: 6180.09, response time: 59.71ms (95%), errors: 0.00, reconnects:  0.00
[2694s] threads: 64, tps: 1629.00, reads: 22751.99, writes: 6525.00, response time: 57.65ms (95%), errors: 0.00, reconnects:  0.00
[2695s] threads: 64, tps: 1774.00, reads: 25016.05, writes: 7183.02, response time: 50.64ms (95%), errors: 0.00, reconnects:  0.00
[2696s] threads: 64, tps: 1779.00, reads: 24778.99, writes: 7049.00, response time: 51.48ms (95%), errors: 0.00, reconnects:  0.00
[2697s] threads: 64, tps: 1704.00, reads: 23778.98, writes: 6754.99, response time: 53.40ms (95%), errors: 0.00, reconnects:  0.00
[2698s] threads: 64, tps: 1561.00, reads: 21915.02, writes: 6321.01, response time: 58.82ms (95%), errors: 0.00, reconnects:  0.00
[2699s] threads: 64, tps: 1817.00, reads: 25392.96, writes: 7224.99, response time: 51.27ms (95%), errors: 0.00, reconnects:  0.00
[2700s] threads: 64, tps: 1878.00, reads: 26305.05, writes: 7506.01, response time: 49.28ms (95%), errors: 0.00, reconnects:  0.00
[2701s] threads: 64, tps: 1860.00, reads: 25966.98, writes: 7406.99, response time: 50.19ms (95%), errors: 0.00, reconnects:  0.00
[2702s] threads: 64, tps: 1824.00, reads: 25655.99, writes: 7336.00, response time: 49.45ms (95%), errors: 0.00, reconnects:  0.00
[2703s] threads: 64, tps: 1840.00, reads: 25731.01, writes: 7335.00, response time: 48.42ms (95%), errors: 0.00, reconnects:  0.00
[2704s] threads: 64, tps: 1702.00, reads: 23903.98, writes: 6874.00, response time: 52.81ms (95%), errors: 0.00, reconnects:  0.00
[2705s] threads: 64, tps: 1718.00, reads: 23996.98, writes: 6841.99, response time: 52.64ms (95%), errors: 0.00, reconnects:  0.00
[2706s] threads: 64, tps: 1749.00, reads: 24419.02, writes: 6966.01, response time: 51.93ms (95%), errors: 0.00, reconnects:  0.00
[2707s] threads: 64, tps: 1720.00, reads: 24240.00, writes: 6944.00, response time: 53.19ms (95%), errors: 0.00, reconnects:  0.00
[2708s] threads: 64, tps: 1817.00, reads: 25340.02, writes: 7222.01, response time: 49.67ms (95%), errors: 0.00, reconnects:  0.00
[2709s] threads: 64, tps: 1860.00, reads: 26100.01, writes: 7489.00, response time: 46.88ms (95%), errors: 0.00, reconnects:  0.00
[2710s] threads: 64, tps: 1946.00, reads: 27170.99, writes: 7738.00, response time: 45.74ms (95%), errors: 0.00, reconnects:  0.00
[2711s] threads: 64, tps: 1980.00, reads: 27737.00, writes: 7904.00, response time: 44.97ms (95%), errors: 0.00, reconnects:  0.00
[2712s] threads: 64, tps: 1901.95, reads: 26675.23, writes: 7674.78, response time: 46.80ms (95%), errors: 0.00, reconnects:  0.00
[2713s] threads: 64, tps: 1925.06, reads: 26825.77, writes: 7625.22, response time: 47.46ms (95%), errors: 0.00, reconnects:  0.00
[2714s] threads: 64, tps: 1966.00, reads: 27618.99, writes: 7958.00, response time: 44.34ms (95%), errors: 0.00, reconnects:  0.00
[2715s] threads: 64, tps: 1856.00, reads: 26107.03, writes: 7445.01, response time: 49.05ms (95%), errors: 0.00, reconnects:  0.00
[2716s] threads: 64, tps: 1869.99, reads: 26026.91, writes: 7399.97, response time: 48.03ms (95%), errors: 0.00, reconnects:  0.00
[2717s] threads: 64, tps: 1856.00, reads: 26147.06, writes: 7514.02, response time: 48.74ms (95%), errors: 0.00, reconnects:  0.00
[2718s] threads: 64, tps: 1839.00, reads: 25565.99, writes: 7223.00, response time: 50.73ms (95%), errors: 0.00, reconnects:  0.00
[2719s] threads: 64, tps: 1550.00, reads: 21732.02, writes: 6227.01, response time: 57.17ms (95%), errors: 0.00, reconnects:  0.00
[2720s] threads: 64, tps: 1519.00, reads: 21359.01, writes: 6128.00, response time: 61.47ms (95%), errors: 0.00, reconnects:  0.00
[2721s] threads: 64, tps: 1352.99, reads: 18880.93, writes: 5324.98, response time: 69.43ms (95%), errors: 0.00, reconnects:  0.00
[2722s] threads: 64, tps: 1446.00, reads: 20220.06, writes: 5839.02, response time: 63.05ms (95%), errors: 0.00, reconnects:  0.00
[2723s] threads: 64, tps: 1571.97, reads: 22046.64, writes: 6307.90, response time: 56.86ms (95%), errors: 0.00, reconnects:  0.00
[2724s] threads: 64, tps: 1782.03, reads: 24862.39, writes: 7135.11, response time: 52.20ms (95%), errors: 0.00, reconnects:  0.00
[2725s] threads: 64, tps: 1883.00, reads: 26211.02, writes: 7463.01, response time: 50.83ms (95%), errors: 0.00, reconnects:  0.00
[2726s] threads: 64, tps: 1816.00, reads: 25519.97, writes: 7336.99, response time: 48.92ms (95%), errors: 0.00, reconnects:  0.00
[2727s] threads: 64, tps: 1831.00, reads: 25797.03, writes: 7356.01, response time: 49.80ms (95%), errors: 0.00, reconnects:  0.00
[2728s] threads: 64, tps: 1901.00, reads: 26592.02, writes: 7558.01, response time: 50.27ms (95%), errors: 0.00, reconnects:  0.00
[2729s] threads: 64, tps: 1822.00, reads: 25517.97, writes: 7278.99, response time: 52.37ms (95%), errors: 0.00, reconnects:  0.00
[2730s] threads: 64, tps: 1879.99, reads: 26095.88, writes: 7450.97, response time: 49.92ms (95%), errors: 0.00, reconnects:  0.00
[2731s] threads: 64, tps: 1752.98, reads: 24771.70, writes: 7095.91, response time: 51.52ms (95%), errors: 0.00, reconnects:  0.00
[2732s] threads: 64, tps: 1781.03, reads: 24856.44, writes: 7092.13, response time: 51.56ms (95%), errors: 0.00, reconnects:  0.00
[2733s] threads: 64, tps: 1800.00, reads: 25204.02, writes: 7178.01, response time: 47.43ms (95%), errors: 0.00, reconnects:  0.00
[2734s] threads: 64, tps: 1715.00, reads: 23925.00, writes: 6835.00, response time: 51.42ms (95%), errors: 0.00, reconnects:  0.00
[2735s] threads: 64, tps: 1783.00, reads: 25019.97, writes: 7145.99, response time: 51.38ms (95%), errors: 0.00, reconnects:  0.00
[2736s] threads: 64, tps: 1774.97, reads: 24868.63, writes: 7092.89, response time: 49.73ms (95%), errors: 0.00, reconnects:  0.00
[2737s] threads: 64, tps: 1833.02, reads: 25722.30, writes: 7380.09, response time: 48.54ms (95%), errors: 0.00, reconnects:  0.00
[2738s] threads: 64, tps: 1899.01, reads: 26507.08, writes: 7598.02, response time: 47.36ms (95%), errors: 0.00, reconnects:  0.00
[2739s] threads: 64, tps: 1890.00, reads: 26515.06, writes: 7539.02, response time: 49.64ms (95%), errors: 0.00, reconnects:  0.00
[2740s] threads: 64, tps: 1878.00, reads: 26332.95, writes: 7500.98, response time: 51.96ms (95%), errors: 0.00, reconnects:  0.00
[2741s] threads: 64, tps: 2065.00, reads: 28824.03, writes: 8251.01, response time: 44.82ms (95%), errors: 0.00, reconnects:  0.00
[2742s] threads: 64, tps: 1985.00, reads: 27756.99, writes: 7964.00, response time: 46.22ms (95%), errors: 0.00, reconnects:  0.00
[2743s] threads: 64, tps: 1904.00, reads: 26786.98, writes: 7682.99, response time: 47.53ms (95%), errors: 0.00, reconnects:  0.00
[2744s] threads: 64, tps: 1795.99, reads: 25075.89, writes: 7096.97, response time: 50.84ms (95%), errors: 0.00, reconnects:  0.00
[2745s] threads: 64, tps: 1735.00, reads: 24293.03, writes: 6981.01, response time: 54.66ms (95%), errors: 0.00, reconnects:  0.00
[2746s] threads: 64, tps: 1784.00, reads: 25010.07, writes: 7162.02, response time: 50.25ms (95%), errors: 0.00, reconnects:  0.00
[2747s] threads: 64, tps: 1833.00, reads: 25524.00, writes: 7269.00, response time: 51.05ms (95%), errors: 0.00, reconnects:  0.00
[2748s] threads: 64, tps: 1768.00, reads: 24840.07, writes: 7060.02, response time: 51.35ms (95%), errors: 0.00, reconnects:  0.00
[2749s] threads: 64, tps: 1750.00, reads: 24465.98, writes: 6983.99, response time: 52.23ms (95%), errors: 0.00, reconnects:  0.00
[2750s] threads: 64, tps: 1440.00, reads: 20270.00, writes: 5785.00, response time: 63.96ms (95%), errors: 0.00, reconnects:  0.00
[2751s] threads: 64, tps: 1489.00, reads: 20767.98, writes: 5951.99, response time: 61.78ms (95%), errors: 0.00, reconnects:  0.00
[2752s] threads: 64, tps: 1605.00, reads: 22481.03, writes: 6413.01, response time: 54.45ms (95%), errors: 0.00, reconnects:  0.00
[2753s] threads: 64, tps: 1741.99, reads: 24350.88, writes: 7022.96, response time: 49.98ms (95%), errors: 0.00, reconnects:  0.00
[2754s] threads: 64, tps: 1728.01, reads: 24271.09, writes: 6915.02, response time: 53.11ms (95%), errors: 0.00, reconnects:  0.00
[2755s] threads: 64, tps: 1830.00, reads: 25718.03, writes: 7365.01, response time: 49.12ms (95%), errors: 0.00, reconnects:  0.00
[2756s] threads: 64, tps: 1887.00, reads: 26125.00, writes: 7438.00, response time: 47.53ms (95%), errors: 0.00, reconnects:  0.00
[2757s] threads: 64, tps: 1849.00, reads: 25996.00, writes: 7427.00, response time: 48.78ms (95%), errors: 0.00, reconnects:  0.00
[2758s] threads: 64, tps: 1941.00, reads: 27101.99, writes: 7776.00, response time: 47.16ms (95%), errors: 0.00, reconnects:  0.00
[2759s] threads: 64, tps: 1821.99, reads: 25710.84, writes: 7321.95, response time: 48.81ms (95%), errors: 0.00, reconnects:  0.00
[2760s] threads: 64, tps: 1859.01, reads: 25836.17, writes: 7390.05, response time: 51.96ms (95%), errors: 0.00, reconnects:  0.00
[2761s] threads: 64, tps: 1857.00, reads: 26069.04, writes: 7428.01, response time: 47.86ms (95%), errors: 0.00, reconnects:  0.00
[2762s] threads: 64, tps: 1723.00, reads: 24096.96, writes: 6862.99, response time: 53.03ms (95%), errors: 0.00, reconnects:  0.00
[2763s] threads: 64, tps: 1654.99, reads: 23206.89, writes: 6621.97, response time: 52.42ms (95%), errors: 0.00, reconnects:  0.00
[2764s] threads: 64, tps: 1632.01, reads: 22871.12, writes: 6548.03, response time: 55.25ms (95%), errors: 0.00, reconnects:  0.00
[2765s] threads: 64, tps: 1710.99, reads: 23978.90, writes: 6821.97, response time: 52.48ms (95%), errors: 0.00, reconnects:  0.00
[2766s] threads: 64, tps: 1747.01, reads: 24341.08, writes: 6985.02, response time: 53.26ms (95%), errors: 0.00, reconnects:  0.00
[2767s] threads: 64, tps: 1739.00, reads: 24512.00, writes: 7011.00, response time: 53.46ms (95%), errors: 0.00, reconnects:  0.00
[2768s] threads: 64, tps: 1809.00, reads: 25261.03, writes: 7186.01, response time: 50.24ms (95%), errors: 0.00, reconnects:  0.00
[2769s] threads: 64, tps: 1756.00, reads: 24551.96, writes: 7057.99, response time: 54.96ms (95%), errors: 0.00, reconnects:  0.00
[2770s] threads: 64, tps: 1874.00, reads: 26293.02, writes: 7527.01, response time: 50.09ms (95%), errors: 0.00, reconnects:  0.00
[2771s] threads: 64, tps: 1976.00, reads: 27645.00, writes: 7872.00, response time: 45.44ms (95%), errors: 0.00, reconnects:  0.00
[2772s] threads: 64, tps: 1893.00, reads: 26575.97, writes: 7632.99, response time: 46.56ms (95%), errors: 0.00, reconnects:  0.00
[2773s] threads: 64, tps: 1901.01, reads: 26605.09, writes: 7630.03, response time: 46.87ms (95%), errors: 0.00, reconnects:  0.00
[2774s] threads: 64, tps: 1880.00, reads: 26276.94, writes: 7434.98, response time: 49.64ms (95%), errors: 0.00, reconnects:  0.00
[2775s] threads: 64, tps: 1814.00, reads: 25371.00, writes: 7302.00, response time: 49.40ms (95%), errors: 0.00, reconnects:  0.00
[2776s] threads: 64, tps: 1883.00, reads: 26311.99, writes: 7466.00, response time: 47.76ms (95%), errors: 0.00, reconnects:  0.00
[2777s] threads: 64, tps: 1847.99, reads: 25684.91, writes: 7380.97, response time: 48.83ms (95%), errors: 0.00, reconnects:  0.00
[2778s] threads: 64, tps: 1638.00, reads: 23094.07, writes: 6564.02, response time: 54.24ms (95%), errors: 0.00, reconnects:  0.00
[2779s] threads: 64, tps: 1665.00, reads: 23375.94, writes: 6645.98, response time: 53.74ms (95%), errors: 0.00, reconnects:  0.00
[2780s] threads: 64, tps: 1465.01, reads: 20546.08, writes: 5843.02, response time: 64.02ms (95%), errors: 0.00, reconnects:  0.00
[2781s] threads: 64, tps: 1506.99, reads: 21096.92, writes: 6052.98, response time: 58.47ms (95%), errors: 0.00, reconnects:  0.00
[2782s] threads: 64, tps: 1583.01, reads: 22088.08, writes: 6334.02, response time: 55.42ms (95%), errors: 0.00, reconnects:  0.00
[2783s] threads: 64, tps: 1684.87, reads: 23616.13, writes: 6787.46, response time: 53.72ms (95%), errors: 0.00, reconnects:  0.00
[2784s] threads: 64, tps: 1823.14, reads: 25634.03, writes: 7310.58, response time: 50.27ms (95%), errors: 0.00, reconnects:  0.00
[2785s] threads: 64, tps: 1827.00, reads: 25357.97, writes: 7231.99, response time: 50.64ms (95%), errors: 0.00, reconnects:  0.00
[2786s] threads: 64, tps: 1805.99, reads: 25453.89, writes: 7265.97, response time: 48.20ms (95%), errors: 0.00, reconnects:  0.00
[2787s] threads: 64, tps: 1903.01, reads: 26562.13, writes: 7594.04, response time: 47.02ms (95%), errors: 0.00, reconnects:  0.00
[2788s] threads: 64, tps: 1838.00, reads: 25808.03, writes: 7419.01, response time: 48.12ms (95%), errors: 0.00, reconnects:  0.00
[2789s] threads: 64, tps: 1869.97, reads: 26127.63, writes: 7469.89, response time: 49.03ms (95%), errors: 0.00, reconnects:  0.00
[2790s] threads: 64, tps: 1766.02, reads: 24836.32, writes: 7064.09, response time: 54.92ms (95%), errors: 0.00, reconnects:  0.00
[2791s] threads: 64, tps: 1722.00, reads: 23981.98, writes: 6837.99, response time: 53.10ms (95%), errors: 0.00, reconnects:  0.00
[2792s] threads: 64, tps: 1560.99, reads: 21862.79, writes: 6251.94, response time: 57.96ms (95%), errors: 0.00, reconnects:  0.00
[2793s] threads: 64, tps: 1531.02, reads: 21450.22, writes: 6065.06, response time: 60.68ms (95%), errors: 0.00, reconnects:  0.00
[2794s] threads: 64, tps: 1484.99, reads: 20710.89, writes: 5970.97, response time: 64.83ms (95%), errors: 0.00, reconnects:  0.00
[2795s] threads: 64, tps: 1622.97, reads: 22770.59, writes: 6503.88, response time: 56.12ms (95%), errors: 0.00, reconnects:  0.00
[2796s] threads: 64, tps: 1639.04, reads: 22943.51, writes: 6571.15, response time: 57.45ms (95%), errors: 0.00, reconnects:  0.00
[2797s] threads: 64, tps: 1766.00, reads: 24879.02, writes: 7132.01, response time: 50.63ms (95%), errors: 0.00, reconnects:  0.00
[2798s] threads: 64, tps: 1912.99, reads: 26625.91, writes: 7600.98, response time: 48.22ms (95%), errors: 0.00, reconnects:  0.00
[2799s] threads: 64, tps: 1883.01, reads: 26249.12, writes: 7522.03, response time: 50.58ms (95%), errors: 0.00, reconnects:  0.00
[2800s] threads: 64, tps: 1838.00, reads: 25891.97, writes: 7365.99, response time: 48.74ms (95%), errors: 0.00, reconnects:  0.00
[2801s] threads: 64, tps: 1883.00, reads: 26432.01, writes: 7552.00, response time: 47.23ms (95%), errors: 0.00, reconnects:  0.00
[2802s] threads: 64, tps: 1862.00, reads: 26040.01, writes: 7472.00, response time: 48.84ms (95%), errors: 0.00, reconnects:  0.00
[2803s] threads: 64, tps: 1879.00, reads: 26385.96, writes: 7522.99, response time: 47.44ms (95%), errors: 0.00, reconnects:  0.00
[2804s] threads: 64, tps: 1794.99, reads: 24955.91, writes: 7125.97, response time: 50.24ms (95%), errors: 0.00, reconnects:  0.00
[2805s] threads: 64, tps: 1852.01, reads: 25844.12, writes: 7378.03, response time: 47.13ms (95%), errors: 0.00, reconnects:  0.00
[2806s] threads: 64, tps: 1762.00, reads: 24733.00, writes: 7052.00, response time: 50.40ms (95%), errors: 0.00, reconnects:  0.00
[2807s] threads: 64, tps: 1649.00, reads: 23062.99, writes: 6591.00, response time: 54.92ms (95%), errors: 0.00, reconnects:  0.00
[2808s] threads: 64, tps: 1622.00, reads: 22755.01, writes: 6448.00, response time: 53.93ms (95%), errors: 0.00, reconnects:  0.00
[2809s] threads: 64, tps: 1530.00, reads: 21518.01, writes: 6147.00, response time: 56.92ms (95%), errors: 0.00, reconnects:  0.00
[2810s] threads: 64, tps: 1434.00, reads: 20059.93, writes: 5717.98, response time: 62.88ms (95%), errors: 0.00, reconnects:  0.00
[2811s] threads: 64, tps: 1506.00, reads: 20986.03, writes: 6034.01, response time: 60.14ms (95%), errors: 0.00, reconnects:  0.00
[2812s] threads: 64, tps: 1553.00, reads: 21809.04, writes: 6211.01, response time: 57.34ms (95%), errors: 0.00, reconnects:  0.00
[2813s] threads: 64, tps: 1676.00, reads: 23503.04, writes: 6754.01, response time: 53.74ms (95%), errors: 0.00, reconnects:  0.00
[2814s] threads: 64, tps: 1710.00, reads: 23931.99, writes: 6832.00, response time: 53.35ms (95%), errors: 0.00, reconnects:  0.00
[2815s] threads: 64, tps: 1811.99, reads: 25422.82, writes: 7321.95, response time: 49.83ms (95%), errors: 0.00, reconnects:  0.00
[2816s] threads: 64, tps: 1801.01, reads: 25154.16, writes: 7150.05, response time: 51.44ms (95%), errors: 0.00, reconnects:  0.00
[2817s] threads: 64, tps: 1798.00, reads: 25207.96, writes: 7226.99, response time: 52.50ms (95%), errors: 0.00, reconnects:  0.00
[2818s] threads: 64, tps: 1843.00, reads: 25806.03, writes: 7341.01, response time: 48.93ms (95%), errors: 0.00, reconnects:  0.00
[2819s] threads: 64, tps: 1899.99, reads: 26451.85, writes: 7568.96, response time: 47.44ms (95%), errors: 0.00, reconnects:  0.00
[2820s] threads: 64, tps: 1827.01, reads: 25532.15, writes: 7266.04, response time: 48.90ms (95%), errors: 0.00, reconnects:  0.00
[2821s] threads: 64, tps: 1724.00, reads: 24213.96, writes: 6887.99, response time: 51.76ms (95%), errors: 0.00, reconnects:  0.00
[2822s] threads: 64, tps: 1649.00, reads: 23080.06, writes: 6605.02, response time: 54.22ms (95%), errors: 0.00, reconnects:  0.00
[2823s] threads: 64, tps: 1638.99, reads: 23005.87, writes: 6571.96, response time: 53.77ms (95%), errors: 0.00, reconnects:  0.00
[2824s] threads: 64, tps: 1656.01, reads: 23175.11, writes: 6631.03, response time: 55.20ms (95%), errors: 0.00, reconnects:  0.00
[2825s] threads: 64, tps: 1732.00, reads: 24128.98, writes: 6892.99, response time: 51.05ms (95%), errors: 0.00, reconnects:  0.00
[2826s] threads: 64, tps: 1653.00, reads: 23231.02, writes: 6669.01, response time: 55.04ms (95%), errors: 0.00, reconnects:  0.00
[2827s] threads: 64, tps: 1827.00, reads: 25626.01, writes: 7352.00, response time: 47.80ms (95%), errors: 0.00, reconnects:  0.00
[2828s] threads: 64, tps: 1905.99, reads: 26644.86, writes: 7598.96, response time: 46.67ms (95%), errors: 0.00, reconnects:  0.00
[2829s] threads: 64, tps: 1952.01, reads: 27224.14, writes: 7777.04, response time: 45.88ms (95%), errors: 0.00, reconnects:  0.00
[2830s] threads: 64, tps: 1937.00, reads: 27174.95, writes: 7745.98, response time: 45.94ms (95%), errors: 0.00, reconnects:  0.00
[2831s] threads: 64, tps: 1786.00, reads: 25067.06, writes: 7154.02, response time: 49.30ms (95%), errors: 0.00, reconnects:  0.00
[2832s] threads: 64, tps: 1901.00, reads: 26592.96, writes: 7625.99, response time: 46.98ms (95%), errors: 0.00, reconnects:  0.00
[2833s] threads: 64, tps: 1773.00, reads: 24868.02, writes: 7095.00, response time: 51.53ms (95%), errors: 0.00, reconnects:  0.00
[2834s] threads: 64, tps: 1798.00, reads: 25117.01, writes: 7161.00, response time: 51.69ms (95%), errors: 0.00, reconnects:  0.00
[2835s] threads: 64, tps: 1847.00, reads: 25794.96, writes: 7381.99, response time: 47.74ms (95%), errors: 0.00, reconnects:  0.00
[2836s] threads: 64, tps: 1881.00, reads: 26467.03, writes: 7557.01, response time: 49.36ms (95%), errors: 0.00, reconnects:  0.00
[2837s] threads: 64, tps: 1835.00, reads: 25739.95, writes: 7343.99, response time: 48.25ms (95%), errors: 0.00, reconnects:  0.00
[2838s] threads: 64, tps: 1747.00, reads: 24421.04, writes: 6982.01, response time: 51.19ms (95%), errors: 0.00, reconnects:  0.00
[2839s] threads: 64, tps: 1650.00, reads: 23169.01, writes: 6636.00, response time: 53.56ms (95%), errors: 0.00, reconnects:  0.00
[2840s] threads: 64, tps: 1524.00, reads: 21199.99, writes: 5990.00, response time: 59.09ms (95%), errors: 0.00, reconnects:  0.00
[2841s] threads: 64, tps: 1571.00, reads: 21951.00, writes: 6294.00, response time: 55.60ms (95%), errors: 0.00, reconnects:  0.00
[2842s] threads: 64, tps: 1687.00, reads: 23708.00, writes: 6776.00, response time: 53.72ms (95%), errors: 0.00, reconnects:  0.00
[2843s] threads: 64, tps: 1780.00, reads: 24951.97, writes: 7152.99, response time: 49.31ms (95%), errors: 0.00, reconnects:  0.00
[2844s] threads: 64, tps: 1883.00, reads: 26210.03, writes: 7461.01, response time: 48.15ms (95%), errors: 0.00, reconnects:  0.00
[2845s] threads: 64, tps: 1865.99, reads: 26072.89, writes: 7514.97, response time: 48.15ms (95%), errors: 0.00, reconnects:  0.00
[2846s] threads: 64, tps: 1691.01, reads: 23678.12, writes: 6707.03, response time: 54.35ms (95%), errors: 0.00, reconnects:  0.00
[2847s] threads: 64, tps: 1691.00, reads: 23693.00, writes: 6815.00, response time: 54.76ms (95%), errors: 0.00, reconnects:  0.00
[2848s] threads: 64, tps: 1795.00, reads: 25209.97, writes: 7139.99, response time: 52.04ms (95%), errors: 0.00, reconnects:  0.00
[2849s] threads: 64, tps: 1784.98, reads: 24970.67, writes: 7182.90, response time: 51.27ms (95%), errors: 0.00, reconnects:  0.00
[2850s] threads: 64, tps: 1690.02, reads: 23718.30, writes: 6778.09, response time: 53.42ms (95%), errors: 0.00, reconnects:  0.00
[2851s] threads: 64, tps: 1585.95, reads: 22155.35, writes: 6335.81, response time: 59.28ms (95%), errors: 0.00, reconnects:  0.00
[2852s] threads: 64, tps: 1421.83, reads: 19907.58, writes: 5660.31, response time: 62.47ms (95%), errors: 0.00, reconnects:  0.00
[2853s] threads: 64, tps: 1627.25, reads: 22831.49, writes: 6532.00, response time: 53.64ms (95%), errors: 0.00, reconnects:  0.00
[2854s] threads: 64, tps: 1673.00, reads: 23287.99, writes: 6657.00, response time: 55.55ms (95%), errors: 0.00, reconnects:  0.00
[2855s] threads: 64, tps: 1739.00, reads: 24421.97, writes: 6958.99, response time: 50.87ms (95%), errors: 0.00, reconnects:  0.00
[2856s] threads: 64, tps: 1700.99, reads: 23890.91, writes: 6873.97, response time: 53.26ms (95%), errors: 0.00, reconnects:  0.00
[2857s] threads: 64, tps: 1855.01, reads: 25892.11, writes: 7336.03, response time: 47.87ms (95%), errors: 0.00, reconnects:  0.00
[2858s] threads: 64, tps: 1848.00, reads: 25852.98, writes: 7417.00, response time: 47.92ms (95%), errors: 0.00, reconnects:  0.00
[2859s] threads: 64, tps: 1882.00, reads: 26522.03, writes: 7619.01, response time: 48.90ms (95%), errors: 0.00, reconnects:  0.00
[2860s] threads: 64, tps: 1894.00, reads: 26346.97, writes: 7475.99, response time: 47.63ms (95%), errors: 0.00, reconnects:  0.00
[2861s] threads: 64, tps: 1945.00, reads: 27159.04, writes: 7805.01, response time: 45.73ms (95%), errors: 0.00, reconnects:  0.00
[2862s] threads: 64, tps: 1888.00, reads: 26578.99, writes: 7587.00, response time: 45.31ms (95%), errors: 0.00, reconnects:  0.00
[2863s] threads: 64, tps: 1816.00, reads: 25463.00, writes: 7262.00, response time: 49.14ms (95%), errors: 0.00, reconnects:  0.00
[2864s] threads: 64, tps: 1927.00, reads: 26907.99, writes: 7675.00, response time: 47.12ms (95%), errors: 0.00, reconnects:  0.00
[2865s] threads: 64, tps: 1799.00, reads: 25201.04, writes: 7162.01, response time: 49.28ms (95%), errors: 0.00, reconnects:  0.00
[2866s] threads: 64, tps: 1790.00, reads: 25115.97, writes: 7206.99, response time: 51.41ms (95%), errors: 0.00, reconnects:  0.00
[2867s] threads: 64, tps: 1812.99, reads: 25217.88, writes: 7197.97, response time: 51.64ms (95%), errors: 0.00, reconnects:  0.00
[2868s] threads: 64, tps: 1832.98, reads: 25780.66, writes: 7328.90, response time: 48.62ms (95%), errors: 0.00, reconnects:  0.00
[2869s] threads: 64, tps: 1735.03, reads: 24329.45, writes: 6953.13, response time: 51.62ms (95%), errors: 0.00, reconnects:  0.00
[2870s] threads: 64, tps: 1600.00, reads: 22488.97, writes: 6532.99, response time: 54.89ms (95%), errors: 0.00, reconnects:  0.00
[2871s] threads: 64, tps: 1574.00, reads: 21848.03, writes: 6146.01, response time: 59.39ms (95%), errors: 0.00, reconnects:  0.00
[2872s] threads: 64, tps: 1596.00, reads: 22349.00, writes: 6386.00, response time: 55.75ms (95%), errors: 0.00, reconnects:  0.00
[2873s] threads: 64, tps: 1661.98, reads: 23270.75, writes: 6714.93, response time: 54.06ms (95%), errors: 0.00, reconnects:  0.00
[2874s] threads: 64, tps: 1763.02, reads: 24812.26, writes: 7093.08, response time: 54.01ms (95%), errors: 0.00, reconnects:  0.00
[2875s] threads: 64, tps: 1804.00, reads: 25132.02, writes: 7159.01, response time: 49.59ms (95%), errors: 0.00, reconnects:  0.00
[2876s] threads: 64, tps: 1775.00, reads: 24909.00, writes: 7117.00, response time: 50.93ms (95%), errors: 0.00, reconnects:  0.00
[2877s] threads: 64, tps: 1845.00, reads: 25774.00, writes: 7358.00, response time: 48.84ms (95%), errors: 0.00, reconnects:  0.00
[2878s] threads: 64, tps: 1881.00, reads: 26444.98, writes: 7582.99, response time: 47.25ms (95%), errors: 0.00, reconnects:  0.00
[2879s] threads: 64, tps: 1812.00, reads: 25282.01, writes: 7230.00, response time: 51.52ms (95%), errors: 0.00, reconnects:  0.00
[2880s] threads: 64, tps: 1789.00, reads: 24955.98, writes: 7102.99, response time: 50.39ms (95%), errors: 0.00, reconnects:  0.00
[2881s] threads: 64, tps: 1634.00, reads: 22914.00, writes: 6530.00, response time: 55.52ms (95%), errors: 0.00, reconnects:  0.00
[2882s] threads: 64, tps: 1570.00, reads: 21999.01, writes: 6285.00, response time: 56.20ms (95%), errors: 0.00, reconnects:  0.00
[2883s] threads: 64, tps: 1493.00, reads: 21043.99, writes: 6054.00, response time: 61.08ms (95%), errors: 0.00, reconnects:  0.00
[2884s] threads: 64, tps: 1581.00, reads: 22091.98, writes: 6266.99, response time: 58.09ms (95%), errors: 0.00, reconnects:  0.00
[2885s] threads: 64, tps: 1597.00, reads: 22218.01, writes: 6349.00, response time: 58.71ms (95%), errors: 0.00, reconnects:  0.00
[2886s] threads: 64, tps: 1583.00, reads: 22173.03, writes: 6338.01, response time: 56.88ms (95%), errors: 0.00, reconnects:  0.00
[2887s] threads: 64, tps: 1746.00, reads: 24522.98, writes: 7001.99, response time: 52.39ms (95%), errors: 0.00, reconnects:  0.00
[2888s] threads: 64, tps: 1786.00, reads: 24934.01, writes: 7145.00, response time: 51.58ms (95%), errors: 0.00, reconnects:  0.00
[2889s] threads: 64, tps: 1831.00, reads: 25681.01, writes: 7332.00, response time: 48.64ms (95%), errors: 0.00, reconnects:  0.00
[2890s] threads: 64, tps: 1882.99, reads: 26311.89, writes: 7506.97, response time: 47.66ms (95%), errors: 0.00, reconnects:  0.00
[2891s] threads: 64, tps: 1940.01, reads: 27305.07, writes: 7814.02, response time: 46.00ms (95%), errors: 0.00, reconnects:  0.00
[2892s] threads: 64, tps: 1899.99, reads: 26560.81, writes: 7568.95, response time: 47.29ms (95%), errors: 0.00, reconnects:  0.00
[2893s] threads: 64, tps: 1821.01, reads: 25484.20, writes: 7301.06, response time: 49.25ms (95%), errors: 0.00, reconnects:  0.00
[2894s] threads: 64, tps: 1820.00, reads: 25500.99, writes: 7289.00, response time: 48.23ms (95%), errors: 0.00, reconnects:  0.00
[2895s] threads: 64, tps: 1825.99, reads: 25417.88, writes: 7276.97, response time: 48.84ms (95%), errors: 0.00, reconnects:  0.00
[2896s] threads: 64, tps: 1849.94, reads: 25929.12, writes: 7377.75, response time: 48.17ms (95%), errors: 0.00, reconnects:  0.00
[2897s] threads: 64, tps: 1774.07, reads: 24838.93, writes: 7095.26, response time: 50.45ms (95%), errors: 0.00, reconnects:  0.00
[2898s] threads: 64, tps: 1703.00, reads: 23902.02, writes: 6820.01, response time: 52.46ms (95%), errors: 0.00, reconnects:  0.00
[2899s] threads: 64, tps: 1709.00, reads: 23902.02, writes: 6814.01, response time: 52.89ms (95%), errors: 0.00, reconnects:  0.00
[2900s] threads: 64, tps: 1512.99, reads: 21215.87, writes: 6064.96, response time: 60.72ms (95%), errors: 0.00, reconnects:  0.00
[2901s] threads: 64, tps: 1486.01, reads: 20792.12, writes: 5910.04, response time: 59.40ms (95%), errors: 0.00, reconnects:  0.00
[2902s] threads: 64, tps: 1528.00, reads: 21416.00, writes: 6189.00, response time: 56.78ms (95%), errors: 0.00, reconnects:  0.00
[2903s] threads: 64, tps: 1657.00, reads: 23138.00, writes: 6607.00, response time: 53.62ms (95%), errors: 0.00, reconnects:  0.00
[2904s] threads: 64, tps: 1795.00, reads: 25109.02, writes: 7191.01, response time: 48.62ms (95%), errors: 0.00, reconnects:  0.00
[2905s] threads: 64, tps: 1783.00, reads: 25173.96, writes: 7210.99, response time: 50.54ms (95%), errors: 0.00, reconnects:  0.00
[2906s] threads: 64, tps: 1816.80, reads: 25220.25, writes: 7169.22, response time: 48.99ms (95%), errors: 0.00, reconnects:  0.00
[2907s] threads: 64, tps: 1872.20, reads: 26262.86, writes: 7536.82, response time: 49.49ms (95%), errors: 0.00, reconnects:  0.00
[2908s] threads: 64, tps: 1860.00, reads: 26155.02, writes: 7451.01, response time: 48.97ms (95%), errors: 0.00, reconnects:  0.00
[2909s] threads: 64, tps: 1822.00, reads: 25377.99, writes: 7238.00, response time: 50.25ms (95%), errors: 0.00, reconnects:  0.00
[2910s] threads: 64, tps: 1764.00, reads: 24805.01, writes: 7095.00, response time: 52.25ms (95%), errors: 0.00, reconnects:  0.00
[2911s] threads: 64, tps: 1669.99, reads: 23318.88, writes: 6629.97, response time: 54.24ms (95%), errors: 0.00, reconnects:  0.00
[2912s] threads: 64, tps: 1661.01, reads: 23156.10, writes: 6616.03, response time: 54.17ms (95%), errors: 0.00, reconnects:  0.00
[2913s] threads: 64, tps: 1626.00, reads: 22909.01, writes: 6571.00, response time: 53.87ms (95%), errors: 0.00, reconnects:  0.00
[2914s] threads: 64, tps: 1677.00, reads: 23254.98, writes: 6627.00, response time: 52.75ms (95%), errors: 0.00, reconnects:  0.00
[2915s] threads: 64, tps: 1688.00, reads: 23810.98, writes: 6826.00, response time: 52.32ms (95%), errors: 0.00, reconnects:  0.00
[2916s] threads: 64, tps: 1783.97, reads: 24799.60, writes: 7076.89, response time: 50.95ms (95%), errors: 0.00, reconnects:  0.00
[2917s] threads: 64, tps: 1793.03, reads: 25191.45, writes: 7207.13, response time: 49.21ms (95%), errors: 0.00, reconnects:  0.00
[2918s] threads: 64, tps: 1776.00, reads: 24735.00, writes: 7063.00, response time: 50.75ms (95%), errors: 0.00, reconnects:  0.00
[2919s] threads: 64, tps: 1914.00, reads: 27035.98, writes: 7727.99, response time: 47.15ms (95%), errors: 0.00, reconnects:  0.00
[2920s] threads: 64, tps: 1938.00, reads: 27150.04, writes: 7777.01, response time: 45.13ms (95%), errors: 0.00, reconnects:  0.00
[2921s] threads: 64, tps: 1967.00, reads: 27415.97, writes: 7789.99, response time: 45.33ms (95%), errors: 0.00, reconnects:  0.00
[2922s] threads: 64, tps: 1815.00, reads: 25481.01, writes: 7312.00, response time: 49.80ms (95%), errors: 0.00, reconnects:  0.00
[2923s] threads: 64, tps: 1799.00, reads: 25110.97, writes: 7140.99, response time: 50.99ms (95%), errors: 0.00, reconnects:  0.00
[2924s] threads: 64, tps: 1736.00, reads: 24280.02, writes: 6949.01, response time: 51.35ms (95%), errors: 0.00, reconnects:  0.00
[2925s] threads: 64, tps: 1741.00, reads: 24552.97, writes: 7040.99, response time: 51.36ms (95%), errors: 0.00, reconnects:  0.00
[2926s] threads: 64, tps: 1826.00, reads: 25381.06, writes: 7226.02, response time: 48.94ms (95%), errors: 0.00, reconnects:  0.00
[2927s] threads: 64, tps: 1828.00, reads: 25743.94, writes: 7369.98, response time: 48.00ms (95%), errors: 0.00, reconnects:  0.00
[2928s] threads: 64, tps: 1771.00, reads: 24704.02, writes: 7009.01, response time: 50.52ms (95%), errors: 0.00, reconnects:  0.00
[2929s] threads: 64, tps: 1705.00, reads: 23875.00, writes: 6843.00, response time: 52.28ms (95%), errors: 0.00, reconnects:  0.00
[2930s] threads: 64, tps: 1540.00, reads: 21593.02, writes: 6151.00, response time: 59.87ms (95%), errors: 0.00, reconnects:  0.00
[2931s] threads: 64, tps: 1505.00, reads: 21057.00, writes: 5997.00, response time: 61.23ms (95%), errors: 0.00, reconnects:  0.00
[2932s] threads: 64, tps: 1564.00, reads: 21874.01, writes: 6293.00, response time: 56.42ms (95%), errors: 0.00, reconnects:  0.00
[2933s] threads: 64, tps: 1632.00, reads: 22846.98, writes: 6504.99, response time: 54.94ms (95%), errors: 0.00, reconnects:  0.00
[2934s] threads: 64, tps: 1716.00, reads: 24141.99, writes: 6914.00, response time: 51.01ms (95%), errors: 0.00, reconnects:  0.00
[2935s] threads: 64, tps: 1810.00, reads: 25144.99, writes: 7220.00, response time: 49.82ms (95%), errors: 0.00, reconnects:  0.00
[2936s] threads: 64, tps: 1833.00, reads: 25676.05, writes: 7327.01, response time: 48.54ms (95%), errors: 0.00, reconnects:  0.00
[2937s] threads: 64, tps: 1890.00, reads: 26483.95, writes: 7588.99, response time: 47.09ms (95%), errors: 0.00, reconnects:  0.00
[2938s] threads: 64, tps: 1799.00, reads: 25224.98, writes: 7172.99, response time: 49.58ms (95%), errors: 0.00, reconnects:  0.00
[2939s] threads: 64, tps: 1767.00, reads: 24864.05, writes: 7171.01, response time: 51.67ms (95%), errors: 0.00, reconnects:  0.00
[2940s] threads: 64, tps: 1676.99, reads: 23359.90, writes: 6596.97, response time: 53.85ms (95%), errors: 0.00, reconnects:  0.00
[2941s] threads: 64, tps: 1439.01, reads: 20121.09, writes: 5769.03, response time: 63.66ms (95%), errors: 0.00, reconnects:  0.00
[2942s] threads: 64, tps: 1417.00, reads: 19872.01, writes: 5660.00, response time: 63.60ms (95%), errors: 0.00, reconnects:  0.00
[2943s] threads: 64, tps: 1538.00, reads: 21506.00, writes: 6135.00, response time: 59.78ms (95%), errors: 0.00, reconnects:  0.00
[2944s] threads: 64, tps: 1642.00, reads: 22985.00, writes: 6597.00, response time: 54.99ms (95%), errors: 0.00, reconnects:  0.00
[2945s] threads: 64, tps: 1739.00, reads: 24296.97, writes: 6962.99, response time: 51.58ms (95%), errors: 0.00, reconnects:  0.00
[2946s] threads: 64, tps: 1755.00, reads: 24678.04, writes: 7033.01, response time: 50.75ms (95%), errors: 0.00, reconnects:  0.00
[2947s] threads: 64, tps: 1735.00, reads: 24340.97, writes: 6996.99, response time: 51.79ms (95%), errors: 0.00, reconnects:  0.00
[2948s] threads: 64, tps: 1844.00, reads: 25754.00, writes: 7290.00, response time: 47.29ms (95%), errors: 0.00, reconnects:  0.00
[2949s] threads: 64, tps: 1819.00, reads: 25475.03, writes: 7325.01, response time: 49.06ms (95%), errors: 0.00, reconnects:  0.00
[2950s] threads: 64, tps: 1888.00, reads: 26469.96, writes: 7576.99, response time: 46.88ms (95%), errors: 0.00, reconnects:  0.00
[2951s] threads: 64, tps: 1881.00, reads: 26111.99, writes: 7438.00, response time: 51.64ms (95%), errors: 0.00, reconnects:  0.00
[2952s] threads: 64, tps: 1903.00, reads: 26681.02, writes: 7592.01, response time: 46.78ms (95%), errors: 0.00, reconnects:  0.00
[2953s] threads: 64, tps: 1833.00, reads: 25758.03, writes: 7392.01, response time: 48.55ms (95%), errors: 0.00, reconnects:  0.00
[2954s] threads: 64, tps: 1807.00, reads: 25287.98, writes: 7177.00, response time: 50.31ms (95%), errors: 0.00, reconnects:  0.00
[2955s] threads: 64, tps: 1790.00, reads: 25135.02, writes: 7204.01, response time: 48.99ms (95%), errors: 0.00, reconnects:  0.00
[2956s] threads: 64, tps: 1861.00, reads: 26052.96, writes: 7465.99, response time: 48.25ms (95%), errors: 0.00, reconnects:  0.00
[2957s] threads: 64, tps: 1812.00, reads: 25277.03, writes: 7173.01, response time: 52.21ms (95%), errors: 0.00, reconnects:  0.00
[2958s] threads: 64, tps: 1760.00, reads: 24675.99, writes: 7023.00, response time: 51.69ms (95%), errors: 0.00, reconnects:  0.00
[2959s] threads: 64, tps: 1685.00, reads: 23596.99, writes: 6736.00, response time: 51.76ms (95%), errors: 0.00, reconnects:  0.00
[2960s] threads: 64, tps: 1468.00, reads: 20576.00, writes: 5876.00, response time: 64.15ms (95%), errors: 0.00, reconnects:  0.00
[2961s] threads: 64, tps: 1567.00, reads: 21950.02, writes: 6285.01, response time: 58.49ms (95%), errors: 0.00, reconnects:  0.00
[2962s] threads: 64, tps: 1552.00, reads: 21707.00, writes: 6240.00, response time: 57.62ms (95%), errors: 0.00, reconnects:  0.00
[2963s] threads: 64, tps: 1638.00, reads: 22901.01, writes: 6557.00, response time: 55.58ms (95%), errors: 0.00, reconnects:  0.00
[2964s] threads: 64, tps: 1683.97, reads: 23640.54, writes: 6785.87, response time: 53.21ms (95%), errors: 0.00, reconnects:  0.00
[2965s] threads: 64, tps: 1845.04, reads: 25871.51, writes: 7372.15, response time: 49.17ms (95%), errors: 0.00, reconnects:  0.00
[2966s] threads: 64, tps: 1853.00, reads: 25874.99, writes: 7311.00, response time: 47.44ms (95%), errors: 0.00, reconnects:  0.00
[2967s] threads: 64, tps: 1849.00, reads: 26015.00, writes: 7548.00, response time: 47.87ms (95%), errors: 0.00, reconnects:  0.00
[2968s] threads: 64, tps: 1919.00, reads: 26687.02, writes: 7574.01, response time: 46.56ms (95%), errors: 0.00, reconnects:  0.00
[2969s] threads: 64, tps: 1786.00, reads: 25021.97, writes: 7126.99, response time: 47.49ms (95%), errors: 0.00, reconnects:  0.00
[2970s] threads: 64, tps: 1714.00, reads: 23985.96, writes: 6856.99, response time: 51.72ms (95%), errors: 0.00, reconnects:  0.00
[2971s] threads: 64, tps: 1687.00, reads: 23620.00, writes: 6776.00, response time: 52.34ms (95%), errors: 0.00, reconnects:  0.00
[2972s] threads: 64, tps: 1657.00, reads: 23148.05, writes: 6572.01, response time: 53.34ms (95%), errors: 0.00, reconnects:  0.00
[2973s] threads: 64, tps: 1731.00, reads: 24265.00, writes: 6974.00, response time: 50.46ms (95%), errors: 0.00, reconnects:  0.00
[2974s] threads: 64, tps: 1806.00, reads: 25411.98, writes: 7240.99, response time: 49.55ms (95%), errors: 0.00, reconnects:  0.00
[2975s] threads: 64, tps: 1850.00, reads: 25791.98, writes: 7384.00, response time: 49.22ms (95%), errors: 0.00, reconnects:  0.00
[2976s] threads: 64, tps: 1879.00, reads: 26362.03, writes: 7573.01, response time: 46.94ms (95%), errors: 0.00, reconnects:  0.00
[2977s] threads: 64, tps: 1856.99, reads: 25880.89, writes: 7335.97, response time: 48.16ms (95%), errors: 0.00, reconnects:  0.00
[2978s] threads: 64, tps: 1947.01, reads: 27281.15, writes: 7799.04, response time: 45.09ms (95%), errors: 0.00, reconnects:  0.00
[2979s] threads: 64, tps: 1936.99, reads: 27291.92, writes: 7838.98, response time: 44.65ms (95%), errors: 0.00, reconnects:  0.00
[2980s] threads: 64, tps: 1973.00, reads: 27569.04, writes: 7880.01, response time: 44.06ms (95%), errors: 0.00, reconnects:  0.00
[2981s] threads: 64, tps: 1996.00, reads: 27772.04, writes: 7866.01, response time: 45.01ms (95%), errors: 0.00, reconnects:  0.00
[2982s] threads: 64, tps: 1885.00, reads: 26486.94, writes: 7606.98, response time: 45.51ms (95%), errors: 0.00, reconnects:  0.00
[2983s] threads: 64, tps: 1971.00, reads: 27462.02, writes: 7848.01, response time: 45.14ms (95%), errors: 0.00, reconnects:  0.00
[2984s] threads: 64, tps: 1813.00, reads: 25496.98, writes: 7291.99, response time: 48.00ms (95%), errors: 0.00, reconnects:  0.00
[2985s] threads: 64, tps: 1867.00, reads: 26095.01, writes: 7457.00, response time: 47.22ms (95%), errors: 0.00, reconnects:  0.00
[2986s] threads: 64, tps: 1838.00, reads: 25831.99, writes: 7366.00, response time: 48.90ms (95%), errors: 0.00, reconnects:  0.00
[2987s] threads: 64, tps: 1818.00, reads: 25411.99, writes: 7283.00, response time: 49.11ms (95%), errors: 0.00, reconnects:  0.00
[2988s] threads: 64, tps: 1660.00, reads: 23250.01, writes: 6576.00, response time: 53.35ms (95%), errors: 0.00, reconnects:  0.00
[2989s] threads: 64, tps: 1571.00, reads: 22013.00, writes: 6327.00, response time: 56.86ms (95%), errors: 0.00, reconnects:  0.00
[2990s] threads: 64, tps: 1459.00, reads: 20463.00, writes: 5810.00, response time: 60.07ms (95%), errors: 0.00, reconnects:  0.00
[2991s] threads: 64, tps: 1504.00, reads: 21017.93, writes: 6043.98, response time: 59.48ms (95%), errors: 0.00, reconnects:  0.00
[2992s] threads: 64, tps: 1608.00, reads: 22560.05, writes: 6460.01, response time: 55.15ms (95%), errors: 0.00, reconnects:  0.00
[2993s] threads: 64, tps: 1728.00, reads: 24202.00, writes: 6949.00, response time: 53.43ms (95%), errors: 0.00, reconnects:  0.00
[2994s] threads: 64, tps: 1837.00, reads: 25711.01, writes: 7333.00, response time: 47.09ms (95%), errors: 0.00, reconnects:  0.00
[2995s] threads: 64, tps: 1854.00, reads: 25995.04, writes: 7432.01, response time: 47.10ms (95%), errors: 0.00, reconnects:  0.00
[2996s] threads: 64, tps: 1875.00, reads: 26039.00, writes: 7426.00, response time: 46.52ms (95%), errors: 0.00, reconnects:  0.00
[2997s] threads: 64, tps: 1868.00, reads: 26300.94, writes: 7541.98, response time: 47.33ms (95%), errors: 0.00, reconnects:  0.00
[2998s] threads: 64, tps: 1839.00, reads: 25628.05, writes: 7254.01, response time: 48.20ms (95%), errors: 0.00, reconnects:  0.00
[2999s] threads: 64, tps: 1708.00, reads: 23936.99, writes: 6812.00, response time: 51.56ms (95%), errors: 0.00, reconnects:  0.00
[3000s] threads: 64, tps: 1589.00, reads: 22215.99, writes: 6371.00, response time: 54.79ms (95%), errors: 0.00, reconnects:  0.00
[3001s] threads: 64, tps: 1518.95, reads: 21284.29, writes: 6055.80, response time: 56.74ms (95%), errors: 0.00, reconnects:  0.00
[3002s] threads: 64, tps: 1528.05, reads: 21530.72, writes: 6208.21, response time: 57.72ms (95%), errors: 0.00, reconnects:  0.00
[3003s] threads: 64, tps: 1616.00, reads: 22551.99, writes: 6425.00, response time: 54.45ms (95%), errors: 0.00, reconnects:  0.00
[3004s] threads: 64, tps: 1716.00, reads: 23910.00, writes: 6838.00, response time: 52.87ms (95%), errors: 0.00, reconnects:  0.00
[3005s] threads: 64, tps: 1730.00, reads: 24323.01, writes: 6964.00, response time: 50.36ms (95%), errors: 0.00, reconnects:  0.00
[3006s] threads: 64, tps: 1696.00, reads: 23698.00, writes: 6783.00, response time: 52.99ms (95%), errors: 0.00, reconnects:  0.00
[3007s] threads: 64, tps: 1694.00, reads: 23671.00, writes: 6713.00, response time: 53.06ms (95%), errors: 0.00, reconnects:  0.00
[3008s] threads: 64, tps: 1555.00, reads: 21883.00, writes: 6253.00, response time: 56.58ms (95%), errors: 0.00, reconnects:  0.00
[3009s] threads: 64, tps: 1765.00, reads: 24655.02, writes: 7091.01, response time: 52.39ms (95%), errors: 0.00, reconnects:  0.00
[3010s] threads: 64, tps: 1895.00, reads: 26606.97, writes: 7572.99, response time: 44.94ms (95%), errors: 0.00, reconnects:  0.00
[3011s] threads: 64, tps: 1840.00, reads: 25600.99, writes: 7337.00, response time: 49.80ms (95%), errors: 0.00, reconnects:  0.00
[3012s] threads: 64, tps: 1803.00, reads: 25256.03, writes: 7178.01, response time: 49.12ms (95%), errors: 0.00, reconnects:  0.00
[3013s] threads: 64, tps: 1752.00, reads: 24655.95, writes: 7077.98, response time: 53.67ms (95%), errors: 0.00, reconnects:  0.00
[3014s] threads: 64, tps: 1738.00, reads: 24373.05, writes: 6979.01, response time: 52.01ms (95%), errors: 0.00, reconnects:  0.00
[3015s] threads: 64, tps: 1703.00, reads: 23745.02, writes: 6724.00, response time: 51.93ms (95%), errors: 0.00, reconnects:  0.00
[3016s] threads: 64, tps: 1751.00, reads: 24487.97, writes: 7028.99, response time: 51.95ms (95%), errors: 0.00, reconnects:  0.00
[3017s] threads: 64, tps: 1766.00, reads: 24698.00, writes: 7030.00, response time: 50.55ms (95%), errors: 0.00, reconnects:  0.00
[3018s] threads: 64, tps: 1660.00, reads: 23321.00, writes: 6671.00, response time: 55.99ms (95%), errors: 0.00, reconnects:  0.00
[3019s] threads: 64, tps: 1610.00, reads: 22529.99, writes: 6404.00, response time: 56.36ms (95%), errors: 0.00, reconnects:  0.00
[3020s] threads: 64, tps: 1498.00, reads: 21034.98, writes: 6006.00, response time: 62.97ms (95%), errors: 0.00, reconnects:  0.00
[3021s] threads: 64, tps: 1503.00, reads: 20982.02, writes: 6000.01, response time: 60.52ms (95%), errors: 0.00, reconnects:  0.00
[3022s] threads: 64, tps: 1548.00, reads: 21659.00, writes: 6225.00, response time: 56.14ms (95%), errors: 0.00, reconnects:  0.00
[3023s] threads: 64, tps: 1623.00, reads: 22771.99, writes: 6515.00, response time: 53.16ms (95%), errors: 0.00, reconnects:  0.00
[3024s] threads: 64, tps: 1561.00, reads: 21756.95, writes: 6253.99, response time: 59.14ms (95%), errors: 0.00, reconnects:  0.00
[3025s] threads: 64, tps: 1754.99, reads: 24822.83, writes: 7134.95, response time: 48.62ms (95%), errors: 0.00, reconnects:  0.00
[3026s] threads: 64, tps: 1837.02, reads: 25646.29, writes: 7279.08, response time: 48.86ms (95%), errors: 0.00, reconnects:  0.00
[3027s] threads: 64, tps: 1872.94, reads: 26092.12, writes: 7399.75, response time: 48.49ms (95%), errors: 0.00, reconnects:  0.00
[3028s] threads: 64, tps: 1803.06, reads: 25300.82, writes: 7270.24, response time: 48.26ms (95%), errors: 0.00, reconnects:  0.00
[3029s] threads: 64, tps: 1713.00, reads: 23856.95, writes: 6778.99, response time: 52.32ms (95%), errors: 0.00, reconnects:  0.00
[3030s] threads: 64, tps: 1546.00, reads: 21652.03, writes: 6197.01, response time: 59.19ms (95%), errors: 0.00, reconnects:  0.00
[3031s] threads: 64, tps: 1512.00, reads: 21196.02, writes: 6052.00, response time: 58.29ms (95%), errors: 0.00, reconnects:  0.00
[3032s] threads: 64, tps: 1497.00, reads: 20974.00, writes: 6014.00, response time: 60.41ms (95%), errors: 0.00, reconnects:  0.00
[3033s] threads: 64, tps: 1577.00, reads: 22165.00, writes: 6342.00, response time: 56.78ms (95%), errors: 0.00, reconnects:  0.00
[3034s] threads: 64, tps: 1644.00, reads: 22951.01, writes: 6545.00, response time: 54.25ms (95%), errors: 0.00, reconnects:  0.00
[3035s] threads: 64, tps: 1748.00, reads: 24513.01, writes: 7048.00, response time: 52.92ms (95%), errors: 0.00, reconnects:  0.00
[3036s] threads: 64, tps: 1698.00, reads: 23710.97, writes: 6758.99, response time: 51.52ms (95%), errors: 0.00, reconnects:  0.00
[3037s] threads: 64, tps: 1897.00, reads: 26563.01, writes: 7591.00, response time: 47.76ms (95%), errors: 0.00, reconnects:  0.00
[3038s] threads: 64, tps: 1804.00, reads: 25299.98, writes: 7232.00, response time: 49.22ms (95%), errors: 0.00, reconnects:  0.00
[3039s] threads: 64, tps: 1872.00, reads: 26205.98, writes: 7431.99, response time: 48.78ms (95%), errors: 0.00, reconnects:  0.00
[3040s] threads: 64, tps: 1906.00, reads: 26645.04, writes: 7665.01, response time: 45.74ms (95%), errors: 0.00, reconnects:  0.00
[3041s] threads: 64, tps: 1903.00, reads: 26546.99, writes: 7556.00, response time: 48.48ms (95%), errors: 0.00, reconnects:  0.00
[3042s] threads: 64, tps: 1672.00, reads: 23586.01, writes: 6780.00, response time: 55.47ms (95%), errors: 0.00, reconnects:  0.00
[3043s] threads: 64, tps: 1706.00, reads: 23753.00, writes: 6781.00, response time: 53.69ms (95%), errors: 0.00, reconnects:  0.00
[3044s] threads: 64, tps: 1791.00, reads: 25110.00, writes: 7137.00, response time: 49.88ms (95%), errors: 0.00, reconnects:  0.00
[3045s] threads: 64, tps: 1791.90, reads: 25049.55, writes: 7159.58, response time: 48.62ms (95%), errors: 0.00, reconnects:  0.00
[3046s] threads: 64, tps: 1849.10, reads: 25929.46, writes: 7389.42, response time: 47.37ms (95%), errors: 0.00, reconnects:  0.00
[3047s] threads: 64, tps: 1818.00, reads: 25415.03, writes: 7279.01, response time: 48.59ms (95%), errors: 0.00, reconnects:  0.00
[3048s] threads: 64, tps: 1688.00, reads: 23693.99, writes: 6734.00, response time: 53.46ms (95%), errors: 0.00, reconnects:  0.00
[3049s] threads: 64, tps: 1668.00, reads: 23362.03, writes: 6673.01, response time: 54.01ms (95%), errors: 0.00, reconnects:  0.00
[3050s] threads: 64, tps: 1461.00, reads: 20542.00, writes: 5843.00, response time: 61.03ms (95%), errors: 0.00, reconnects:  0.00
[3051s] threads: 64, tps: 1301.00, reads: 18127.98, writes: 5194.99, response time: 71.48ms (95%), errors: 0.00, reconnects:  0.00
[3052s] threads: 64, tps: 1276.00, reads: 17883.00, writes: 5123.00, response time: 76.16ms (95%), errors: 0.00, reconnects:  0.00
[3053s] threads: 64, tps: 1538.99, reads: 21468.88, writes: 6149.97, response time: 58.19ms (95%), errors: 0.00, reconnects:  0.00
[3054s] threads: 64, tps: 1720.01, reads: 24161.12, writes: 6916.03, response time: 51.22ms (95%), errors: 0.00, reconnects:  0.00
[3055s] threads: 64, tps: 1785.00, reads: 24811.07, writes: 7122.02, response time: 50.77ms (95%), errors: 0.00, reconnects:  0.00
[3056s] threads: 64, tps: 1768.96, reads: 24799.51, writes: 7108.86, response time: 50.43ms (95%), errors: 0.00, reconnects:  0.00
[3057s] threads: 64, tps: 1749.03, reads: 24567.37, writes: 7000.10, response time: 49.77ms (95%), errors: 0.00, reconnects:  0.00
[3058s] threads: 64, tps: 1752.01, reads: 24545.07, writes: 7013.02, response time: 50.92ms (95%), errors: 0.00, reconnects:  0.00
[3059s] threads: 64, tps: 1722.00, reads: 24124.01, writes: 6877.00, response time: 52.72ms (95%), errors: 0.00, reconnects:  0.00
[3060s] threads: 64, tps: 1610.00, reads: 22517.01, writes: 6387.00, response time: 57.74ms (95%), errors: 0.00, reconnects:  0.00
[3061s] threads: 64, tps: 1628.00, reads: 22773.00, writes: 6518.00, response time: 54.66ms (95%), errors: 0.00, reconnects:  0.00
[3062s] threads: 64, tps: 1644.00, reads: 23064.97, writes: 6575.99, response time: 52.89ms (95%), errors: 0.00, reconnects:  0.00
[3063s] threads: 64, tps: 1675.00, reads: 23405.02, writes: 6722.00, response time: 52.23ms (95%), errors: 0.00, reconnects:  0.00
[3064s] threads: 64, tps: 1685.00, reads: 23583.00, writes: 6710.00, response time: 51.53ms (95%), errors: 0.00, reconnects:  0.00
[3065s] threads: 64, tps: 1744.00, reads: 24437.01, writes: 6975.00, response time: 52.01ms (95%), errors: 0.00, reconnects:  0.00
[3066s] threads: 64, tps: 1822.00, reads: 25569.99, writes: 7324.00, response time: 49.24ms (95%), errors: 0.00, reconnects:  0.00
[3067s] threads: 64, tps: 1823.00, reads: 25484.02, writes: 7314.01, response time: 48.55ms (95%), errors: 0.00, reconnects:  0.00
[3068s] threads: 64, tps: 1907.00, reads: 26717.00, writes: 7614.00, response time: 45.95ms (95%), errors: 0.00, reconnects:  0.00
[3069s] threads: 64, tps: 1900.00, reads: 26691.99, writes: 7636.00, response time: 45.16ms (95%), errors: 0.00, reconnects:  0.00
[3070s] threads: 64, tps: 1953.00, reads: 27273.98, writes: 7831.99, response time: 45.33ms (95%), errors: 0.00, reconnects:  0.00
[3071s] threads: 64, tps: 1908.94, reads: 26758.17, writes: 7597.76, response time: 46.88ms (95%), errors: 0.00, reconnects:  0.00
[3072s] threads: 64, tps: 1895.06, reads: 26438.83, writes: 7587.24, response time: 48.16ms (95%), errors: 0.00, reconnects:  0.00
[3073s] threads: 64, tps: 1807.88, reads: 25480.34, writes: 7287.52, response time: 50.04ms (95%), errors: 0.00, reconnects:  0.00
[3074s] threads: 64, tps: 1809.12, reads: 25202.67, writes: 7170.48, response time: 49.42ms (95%), errors: 0.00, reconnects:  0.00
[3075s] threads: 64, tps: 1788.00, reads: 24958.00, writes: 7117.00, response time: 50.45ms (95%), errors: 0.00, reconnects:  0.00
[3076s] threads: 64, tps: 1821.00, reads: 25438.98, writes: 7241.00, response time: 48.51ms (95%), errors: 0.00, reconnects:  0.00
[3077s] threads: 64, tps: 1767.00, reads: 24803.99, writes: 7131.00, response time: 51.33ms (95%), errors: 0.00, reconnects:  0.00
[3078s] threads: 64, tps: 1743.00, reads: 24394.02, writes: 6943.00, response time: 50.66ms (95%), errors: 0.00, reconnects:  0.00
[3079s] threads: 64, tps: 1770.00, reads: 24781.98, writes: 7066.99, response time: 50.34ms (95%), errors: 0.00, reconnects:  0.00
[3080s] threads: 64, tps: 1541.00, reads: 21537.00, writes: 6146.00, response time: 59.48ms (95%), errors: 0.00, reconnects:  0.00
[3081s] threads: 64, tps: 1536.00, reads: 21617.01, writes: 6187.00, response time: 57.12ms (95%), errors: 0.00, reconnects:  0.00
[3082s] threads: 64, tps: 1408.00, reads: 19747.00, writes: 5598.00, response time: 67.67ms (95%), errors: 0.00, reconnects:  0.00
[3083s] threads: 64, tps: 1511.00, reads: 20980.99, writes: 6033.00, response time: 57.76ms (95%), errors: 0.00, reconnects:  0.00
[3084s] threads: 64, tps: 1598.00, reads: 22449.02, writes: 6443.01, response time: 57.02ms (95%), errors: 0.00, reconnects:  0.00
[3085s] threads: 64, tps: 1711.00, reads: 23917.97, writes: 6820.99, response time: 52.46ms (95%), errors: 0.00, reconnects:  0.00
[3086s] threads: 64, tps: 1757.00, reads: 24629.01, writes: 7070.00, response time: 49.82ms (95%), errors: 0.00, reconnects:  0.00
[3087s] threads: 64, tps: 1822.00, reads: 25616.02, writes: 7313.01, response time: 49.80ms (95%), errors: 0.00, reconnects:  0.00
[3088s] threads: 64, tps: 1839.00, reads: 25619.01, writes: 7290.00, response time: 48.33ms (95%), errors: 0.00, reconnects:  0.00
[3089s] threads: 64, tps: 1732.00, reads: 24252.00, writes: 6964.00, response time: 51.38ms (95%), errors: 0.00, reconnects:  0.00
[3090s] threads: 64, tps: 1699.00, reads: 23665.97, writes: 6743.99, response time: 51.76ms (95%), errors: 0.00, reconnects:  0.00
[3091s] threads: 64, tps: 1634.00, reads: 22990.02, writes: 6558.01, response time: 52.46ms (95%), errors: 0.00, reconnects:  0.00
[3092s] threads: 64, tps: 1611.00, reads: 22578.00, writes: 6424.00, response time: 55.94ms (95%), errors: 0.00, reconnects:  0.00
[3093s] threads: 64, tps: 1608.00, reads: 22565.99, writes: 6488.00, response time: 54.16ms (95%), errors: 0.00, reconnects:  0.00
[3094s] threads: 64, tps: 1716.00, reads: 24032.00, writes: 6846.00, response time: 50.73ms (95%), errors: 0.00, reconnects:  0.00
[3095s] threads: 64, tps: 1745.00, reads: 24453.99, writes: 7041.00, response time: 50.43ms (95%), errors: 0.00, reconnects:  0.00
[3096s] threads: 64, tps: 1797.00, reads: 25113.95, writes: 7155.99, response time: 49.83ms (95%), errors: 0.00, reconnects:  0.00
[3097s] threads: 64, tps: 1736.00, reads: 24246.04, writes: 6921.01, response time: 50.95ms (95%), errors: 0.00, reconnects:  0.00
[3098s] threads: 64, tps: 1692.00, reads: 23878.02, writes: 6837.00, response time: 53.64ms (95%), errors: 0.00, reconnects:  0.00
[3099s] threads: 64, tps: 1763.00, reads: 24529.00, writes: 6982.00, response time: 53.75ms (95%), errors: 0.00, reconnects:  0.00
[3100s] threads: 64, tps: 1795.00, reads: 25079.99, writes: 7172.00, response time: 51.76ms (95%), errors: 0.00, reconnects:  0.00
[3101s] threads: 64, tps: 1923.00, reads: 27001.00, writes: 7695.00, response time: 46.34ms (95%), errors: 0.00, reconnects:  0.00
[3102s] threads: 64, tps: 1838.00, reads: 25758.01, writes: 7361.00, response time: 50.04ms (95%), errors: 0.00, reconnects:  0.00
[3103s] threads: 64, tps: 1857.00, reads: 25988.03, writes: 7443.01, response time: 48.32ms (95%), errors: 0.00, reconnects:  0.00
[3104s] threads: 64, tps: 1864.00, reads: 25960.99, writes: 7392.00, response time: 48.02ms (95%), errors: 0.00, reconnects:  0.00
[3105s] threads: 64, tps: 1758.00, reads: 24732.01, writes: 7127.00, response time: 48.87ms (95%), errors: 0.00, reconnects:  0.00
[3106s] threads: 64, tps: 1799.00, reads: 25041.96, writes: 7148.99, response time: 48.78ms (95%), errors: 0.00, reconnects:  0.00
[3107s] threads: 64, tps: 1757.00, reads: 24731.02, writes: 7017.00, response time: 50.40ms (95%), errors: 0.00, reconnects:  0.00
[3108s] threads: 64, tps: 1846.00, reads: 25729.02, writes: 7357.01, response time: 48.12ms (95%), errors: 0.00, reconnects:  0.00
[3109s] threads: 64, tps: 1738.99, reads: 24573.92, writes: 7063.98, response time: 50.83ms (95%), errors: 0.00, reconnects:  0.00
[3110s] threads: 64, tps: 1612.00, reads: 22511.06, writes: 6381.02, response time: 54.12ms (95%), errors: 0.00, reconnects:  0.00
[3111s] threads: 64, tps: 1344.00, reads: 18788.00, writes: 5332.00, response time: 73.14ms (95%), errors: 0.00, reconnects:  0.00
[3112s] threads: 64, tps: 1454.00, reads: 20334.99, writes: 5844.00, response time: 63.91ms (95%), errors: 0.00, reconnects:  0.00
[3113s] threads: 64, tps: 1472.00, reads: 20600.00, writes: 5899.00, response time: 63.09ms (95%), errors: 0.00, reconnects:  0.00
[3114s] threads: 64, tps: 1572.00, reads: 22064.98, writes: 6329.99, response time: 57.22ms (95%), errors: 0.00, reconnects:  0.00
[3115s] threads: 64, tps: 1671.00, reads: 23327.05, writes: 6619.01, response time: 52.69ms (95%), errors: 0.00, reconnects:  0.00
[3116s] threads: 64, tps: 1634.00, reads: 22841.97, writes: 6554.99, response time: 57.17ms (95%), errors: 0.00, reconnects:  0.00
[3117s] threads: 64, tps: 1714.00, reads: 24098.01, writes: 6935.00, response time: 53.06ms (95%), errors: 0.00, reconnects:  0.00
[3118s] threads: 64, tps: 1708.99, reads: 23995.87, writes: 6838.96, response time: 55.02ms (95%), errors: 0.00, reconnects:  0.00
[3119s] threads: 64, tps: 1746.00, reads: 24338.03, writes: 6908.01, response time: 53.64ms (95%), errors: 0.00, reconnects:  0.00
[3120s] threads: 64, tps: 1556.01, reads: 21749.11, writes: 6180.03, response time: 58.68ms (95%), errors: 0.00, reconnects:  0.00
[3121s] threads: 64, tps: 1501.97, reads: 21025.60, writes: 6043.89, response time: 61.26ms (95%), errors: 0.00, reconnects:  0.00
[3122s] threads: 64, tps: 1644.03, reads: 22979.43, writes: 6526.12, response time: 52.18ms (95%), errors: 0.00, reconnects:  0.00
[3123s] threads: 64, tps: 1714.99, reads: 23983.87, writes: 6896.96, response time: 51.13ms (95%), errors: 0.00, reconnects:  0.00
[3124s] threads: 64, tps: 1796.01, reads: 25185.13, writes: 7187.04, response time: 49.76ms (95%), errors: 0.00, reconnects:  0.00
[3125s] threads: 64, tps: 1878.00, reads: 26379.00, writes: 7587.00, response time: 46.36ms (95%), errors: 0.00, reconnects:  0.00
[3126s] threads: 64, tps: 1927.99, reads: 26974.87, writes: 7674.96, response time: 46.60ms (95%), errors: 0.00, reconnects:  0.00
[3127s] threads: 64, tps: 1889.01, reads: 26510.10, writes: 7599.03, response time: 46.28ms (95%), errors: 0.00, reconnects:  0.00
[3128s] threads: 64, tps: 1923.00, reads: 26875.93, writes: 7667.98, response time: 45.61ms (95%), errors: 0.00, reconnects:  0.00
[3129s] threads: 64, tps: 1969.01, reads: 27549.10, writes: 7862.03, response time: 44.37ms (95%), errors: 0.00, reconnects:  0.00
[3130s] threads: 64, tps: 2001.00, reads: 27962.97, writes: 8002.99, response time: 43.94ms (95%), errors: 0.00, reconnects:  0.00
[3131s] threads: 64, tps: 2016.00, reads: 28214.04, writes: 8054.01, response time: 43.80ms (95%), errors: 0.00, reconnects:  0.00
[3132s] threads: 64, tps: 2046.99, reads: 28663.81, writes: 8171.95, response time: 43.15ms (95%), errors: 0.00, reconnects:  0.00
[3133s] threads: 64, tps: 1995.01, reads: 27955.16, writes: 7999.05, response time: 43.12ms (95%), errors: 0.00, reconnects:  0.00
[3134s] threads: 64, tps: 1911.00, reads: 26853.97, writes: 7687.99, response time: 46.18ms (95%), errors: 0.00, reconnects:  0.00
[3135s] threads: 64, tps: 1840.00, reads: 25767.94, writes: 7368.98, response time: 46.06ms (95%), errors: 0.00, reconnects:  0.00
[3136s] threads: 64, tps: 1904.01, reads: 26417.12, writes: 7531.03, response time: 48.09ms (95%), errors: 0.00, reconnects:  0.00
[3137s] threads: 64, tps: 1843.00, reads: 25924.02, writes: 7438.01, response time: 46.98ms (95%), errors: 0.00, reconnects:  0.00
[3138s] threads: 64, tps: 1893.00, reads: 26481.96, writes: 7522.99, response time: 46.46ms (95%), errors: 0.00, reconnects:  0.00
[3139s] threads: 64, tps: 1799.00, reads: 25174.98, writes: 7164.99, response time: 47.96ms (95%), errors: 0.00, reconnects:  0.00
[3140s] threads: 64, tps: 1748.97, reads: 24485.64, writes: 6972.90, response time: 49.91ms (95%), errors: 0.00, reconnects:  0.00
[3141s] threads: 64, tps: 1543.02, reads: 21592.35, writes: 6200.10, response time: 59.12ms (95%), errors: 0.00, reconnects:  0.00
[3142s] threads: 64, tps: 1494.00, reads: 20981.97, writes: 5959.99, response time: 58.70ms (95%), errors: 0.00, reconnects:  0.00
[3143s] threads: 64, tps: 1562.00, reads: 21867.00, writes: 6297.00, response time: 56.64ms (95%), errors: 0.00, reconnects:  0.00
[3144s] threads: 64, tps: 1662.00, reads: 23187.03, writes: 6640.01, response time: 53.74ms (95%), errors: 0.00, reconnects:  0.00
[3145s] threads: 64, tps: 1778.00, reads: 25113.95, writes: 7220.99, response time: 51.32ms (95%), errors: 0.00, reconnects:  0.00
[3146s] threads: 64, tps: 1870.00, reads: 26058.03, writes: 7389.01, response time: 49.70ms (95%), errors: 0.00, reconnects:  0.00
[3147s] threads: 64, tps: 1889.00, reads: 26388.98, writes: 7517.99, response time: 47.89ms (95%), errors: 0.00, reconnects:  0.00
[3148s] threads: 64, tps: 1863.00, reads: 26086.01, writes: 7474.00, response time: 47.30ms (95%), errors: 0.00, reconnects:  0.00
[3149s] threads: 64, tps: 1783.99, reads: 25072.91, writes: 7167.97, response time: 50.60ms (95%), errors: 0.00, reconnects:  0.00
[3150s] threads: 64, tps: 1678.00, reads: 23395.05, writes: 6623.01, response time: 53.05ms (95%), errors: 0.00, reconnects:  0.00
[3151s] threads: 64, tps: 1676.00, reads: 23442.07, writes: 6716.02, response time: 51.01ms (95%), errors: 0.00, reconnects:  0.00
[3152s] threads: 64, tps: 1681.00, reads: 23443.95, writes: 6706.99, response time: 52.94ms (95%), errors: 0.00, reconnects:  0.00
[3153s] threads: 64, tps: 1774.00, reads: 24891.97, writes: 7113.99, response time: 48.51ms (95%), errors: 0.00, reconnects:  0.00
[3154s] threads: 64, tps: 1857.00, reads: 26141.05, writes: 7529.02, response time: 49.46ms (95%), errors: 0.00, reconnects:  0.00
[3155s] threads: 64, tps: 1900.00, reads: 26539.98, writes: 7574.99, response time: 47.67ms (95%), errors: 0.00, reconnects:  0.00
[3156s] threads: 64, tps: 1952.00, reads: 27319.00, writes: 7799.00, response time: 47.25ms (95%), errors: 0.00, reconnects:  0.00
[3157s] threads: 64, tps: 1952.99, reads: 27376.89, writes: 7824.97, response time: 44.92ms (95%), errors: 0.00, reconnects:  0.00
[3158s] threads: 64, tps: 1850.01, reads: 25787.11, writes: 7338.03, response time: 49.85ms (95%), errors: 0.00, reconnects:  0.00
[3159s] threads: 64, tps: 1675.00, reads: 23420.03, writes: 6714.01, response time: 54.32ms (95%), errors: 0.00, reconnects:  0.00
[3160s] threads: 64, tps: 1799.86, reads: 25234.99, writes: 7172.45, response time: 49.39ms (95%), errors: 0.00, reconnects:  0.00
[3161s] threads: 64, tps: 1863.18, reads: 26135.55, writes: 7544.78, response time: 48.33ms (95%), errors: 0.00, reconnects:  0.00
[3162s] threads: 64, tps: 1868.00, reads: 26153.01, writes: 7430.00, response time: 48.57ms (95%), errors: 0.00, reconnects:  0.00
[3163s] threads: 64, tps: 1702.00, reads: 23824.02, writes: 6837.01, response time: 52.69ms (95%), errors: 0.00, reconnects:  0.00
[3164s] threads: 64, tps: 1663.99, reads: 23252.86, writes: 6576.96, response time: 53.61ms (95%), errors: 0.00, reconnects:  0.00
[3165s] threads: 64, tps: 1505.01, reads: 21224.11, writes: 6106.03, response time: 59.21ms (95%), errors: 0.00, reconnects:  0.00
[3166s] threads: 64, tps: 1748.00, reads: 24405.99, writes: 6960.00, response time: 51.25ms (95%), errors: 0.00, reconnects:  0.00
[3167s] threads: 64, tps: 1767.00, reads: 24834.04, writes: 7136.01, response time: 51.24ms (95%), errors: 0.00, reconnects:  0.00
[3168s] threads: 64, tps: 1785.00, reads: 24912.96, writes: 7086.99, response time: 51.79ms (95%), errors: 0.00, reconnects:  0.00
[3169s] threads: 64, tps: 1698.00, reads: 23677.03, writes: 6711.01, response time: 51.78ms (95%), errors: 0.00, reconnects:  0.00
[3170s] threads: 64, tps: 1637.00, reads: 22885.01, writes: 6540.00, response time: 55.67ms (95%), errors: 0.00, reconnects:  0.00
[3171s] threads: 64, tps: 1470.00, reads: 20688.01, writes: 5888.00, response time: 62.23ms (95%), errors: 0.00, reconnects:  0.00
[3172s] threads: 64, tps: 1461.00, reads: 20428.99, writes: 5839.00, response time: 62.06ms (95%), errors: 0.00, reconnects:  0.00
[3173s] threads: 64, tps: 1557.00, reads: 21715.01, writes: 6239.00, response time: 59.53ms (95%), errors: 0.00, reconnects:  0.00
[3174s] threads: 64, tps: 1597.97, reads: 22437.54, writes: 6428.87, response time: 56.71ms (95%), errors: 0.00, reconnects:  0.00
[3175s] threads: 64, tps: 1649.02, reads: 23052.29, writes: 6576.08, response time: 55.87ms (95%), errors: 0.00, reconnects:  0.00
[3176s] threads: 64, tps: 1706.01, reads: 23977.17, writes: 6867.05, response time: 52.23ms (95%), errors: 0.00, reconnects:  0.00
[3177s] threads: 64, tps: 1687.00, reads: 23550.99, writes: 6718.00, response time: 55.10ms (95%), errors: 0.00, reconnects:  0.00
[3178s] threads: 64, tps: 1783.00, reads: 24992.04, writes: 7205.01, response time: 50.48ms (95%), errors: 0.00, reconnects:  0.00
[3179s] threads: 64, tps: 1730.00, reads: 24112.98, writes: 6833.99, response time: 50.43ms (95%), errors: 0.00, reconnects:  0.00
[3180s] threads: 64, tps: 1641.00, reads: 22968.00, writes: 6545.00, response time: 53.69ms (95%), errors: 0.00, reconnects:  0.00
[3181s] threads: 64, tps: 1642.00, reads: 23040.97, writes: 6553.99, response time: 52.40ms (95%), errors: 0.00, reconnects:  0.00
[3182s] threads: 64, tps: 1693.99, reads: 23628.93, writes: 6783.98, response time: 51.50ms (95%), errors: 0.00, reconnects:  0.00
[3183s] threads: 64, tps: 1671.01, reads: 23511.12, writes: 6721.03, response time: 52.37ms (95%), errors: 0.00, reconnects:  0.00
[3184s] threads: 64, tps: 1807.00, reads: 25297.99, writes: 7240.00, response time: 47.29ms (95%), errors: 0.00, reconnects:  0.00
[3185s] threads: 64, tps: 1833.98, reads: 25542.73, writes: 7291.92, response time: 47.84ms (95%), errors: 0.00, reconnects:  0.00
[3186s] threads: 64, tps: 1913.02, reads: 26932.24, writes: 7731.07, response time: 45.27ms (95%), errors: 0.00, reconnects:  0.00
[3187s] threads: 64, tps: 1899.00, reads: 26738.04, writes: 7641.01, response time: 46.50ms (95%), errors: 0.00, reconnects:  0.00
[3188s] threads: 64, tps: 1918.00, reads: 26632.00, writes: 7596.00, response time: 45.80ms (95%), errors: 0.00, reconnects:  0.00
[3189s] threads: 64, tps: 1848.00, reads: 25870.97, writes: 7372.99, response time: 47.97ms (95%), errors: 0.00, reconnects:  0.00
[3190s] threads: 64, tps: 1902.90, reads: 26609.57, writes: 7615.59, response time: 47.66ms (95%), errors: 0.00, reconnects:  0.00
[3191s] threads: 64, tps: 1928.10, reads: 27071.47, writes: 7767.42, response time: 44.92ms (95%), errors: 0.00, reconnects:  0.00
[3192s] threads: 64, tps: 1968.00, reads: 27688.98, writes: 7894.99, response time: 44.61ms (95%), errors: 0.00, reconnects:  0.00
[3193s] threads: 64, tps: 1942.00, reads: 27109.03, writes: 7718.01, response time: 44.65ms (95%), errors: 0.00, reconnects:  0.00
[3194s] threads: 64, tps: 1837.00, reads: 25644.00, writes: 7315.00, response time: 47.69ms (95%), errors: 0.00, reconnects:  0.00
[3195s] threads: 64, tps: 1796.99, reads: 25327.85, writes: 7277.96, response time: 48.74ms (95%), errors: 0.00, reconnects:  0.00
[3196s] threads: 64, tps: 1853.01, reads: 25792.17, writes: 7321.05, response time: 49.85ms (95%), errors: 0.00, reconnects:  0.00
[3197s] threads: 64, tps: 1804.00, reads: 25330.98, writes: 7291.99, response time: 50.09ms (95%), errors: 0.00, reconnects:  0.00
[3198s] threads: 64, tps: 1609.00, reads: 22501.00, writes: 6390.00, response time: 58.02ms (95%), errors: 0.00, reconnects:  0.00
[3199s] threads: 64, tps: 1736.00, reads: 24271.97, writes: 6924.99, response time: 51.27ms (95%), errors: 0.00, reconnects:  0.00
[3200s] threads: 64, tps: 1689.00, reads: 23565.04, writes: 6724.01, response time: 52.67ms (95%), errors: 0.00, reconnects:  0.00
[3201s] threads: 64, tps: 1524.00, reads: 21397.96, writes: 6097.99, response time: 60.94ms (95%), errors: 0.00, reconnects:  0.00
[3202s] threads: 64, tps: 1427.00, reads: 19930.00, writes: 5692.00, response time: 63.01ms (95%), errors: 0.00, reconnects:  0.00
[3203s] threads: 64, tps: 1472.00, reads: 20667.01, writes: 5896.00, response time: 61.04ms (95%), errors: 0.00, reconnects:  0.00
[3204s] threads: 64, tps: 1611.00, reads: 22448.02, writes: 6474.01, response time: 57.45ms (95%), errors: 0.00, reconnects:  0.00
[3205s] threads: 64, tps: 1669.90, reads: 23532.59, writes: 6725.60, response time: 51.42ms (95%), errors: 0.00, reconnects:  0.00
[3206s] threads: 64, tps: 1815.11, reads: 25423.51, writes: 7226.43, response time: 48.89ms (95%), errors: 0.00, reconnects:  0.00
[3207s] threads: 64, tps: 1842.00, reads: 25776.98, writes: 7400.99, response time: 48.39ms (95%), errors: 0.00, reconnects:  0.00
[3208s] threads: 64, tps: 1688.00, reads: 23557.00, writes: 6706.00, response time: 51.58ms (95%), errors: 0.00, reconnects:  0.00
[3209s] threads: 64, tps: 1599.00, reads: 22369.99, writes: 6371.00, response time: 55.55ms (95%), errors: 0.00, reconnects:  0.00
[3210s] threads: 64, tps: 1548.00, reads: 21652.04, writes: 6172.01, response time: 57.48ms (95%), errors: 0.00, reconnects:  0.00
[3211s] threads: 64, tps: 1524.00, reads: 21370.98, writes: 6140.99, response time: 57.74ms (95%), errors: 0.00, reconnects:  0.00
[3212s] threads: 64, tps: 1546.00, reads: 21627.01, writes: 6161.00, response time: 56.36ms (95%), errors: 0.00, reconnects:  0.00
[3213s] threads: 64, tps: 1619.00, reads: 22699.97, writes: 6512.99, response time: 56.76ms (95%), errors: 0.00, reconnects:  0.00
[3214s] threads: 64, tps: 1699.99, reads: 23880.91, writes: 6835.97, response time: 54.30ms (95%), errors: 0.00, reconnects:  0.00
[3215s] threads: 64, tps: 1782.01, reads: 24979.13, writes: 7165.04, response time: 49.28ms (95%), errors: 0.00, reconnects:  0.00
[3216s] threads: 64, tps: 1828.00, reads: 25566.97, writes: 7291.99, response time: 48.26ms (95%), errors: 0.00, reconnects:  0.00
[3217s] threads: 64, tps: 1764.00, reads: 24711.98, writes: 7023.99, response time: 52.37ms (95%), errors: 0.00, reconnects:  0.00
[3218s] threads: 64, tps: 1818.00, reads: 25484.02, writes: 7314.01, response time: 48.78ms (95%), errors: 0.00, reconnects:  0.00
[3219s] threads: 64, tps: 1921.00, reads: 26783.02, writes: 7613.01, response time: 47.70ms (95%), errors: 0.00, reconnects:  0.00
[3220s] threads: 64, tps: 1956.00, reads: 27269.01, writes: 7803.00, response time: 44.88ms (95%), errors: 0.00, reconnects:  0.00
[3221s] threads: 64, tps: 1945.00, reads: 27294.96, writes: 7786.99, response time: 46.61ms (95%), errors: 0.00, reconnects:  0.00
[3222s] threads: 64, tps: 1910.00, reads: 26808.02, writes: 7683.01, response time: 46.38ms (95%), errors: 0.00, reconnects:  0.00
[3223s] threads: 64, tps: 1795.00, reads: 25084.96, writes: 7151.99, response time: 51.04ms (95%), errors: 0.00, reconnects:  0.00
[3224s] threads: 64, tps: 1806.00, reads: 25260.05, writes: 7236.01, response time: 48.57ms (95%), errors: 0.00, reconnects:  0.00
[3225s] threads: 64, tps: 1742.00, reads: 24355.00, writes: 6975.00, response time: 51.15ms (95%), errors: 0.00, reconnects:  0.00
[3226s] threads: 64, tps: 1779.00, reads: 24966.97, writes: 7117.99, response time: 50.42ms (95%), errors: 0.00, reconnects:  0.00
[3227s] threads: 64, tps: 1857.00, reads: 25935.04, writes: 7396.01, response time: 48.06ms (95%), errors: 0.00, reconnects:  0.00
[3228s] threads: 64, tps: 1859.00, reads: 26120.98, writes: 7446.99, response time: 47.42ms (95%), errors: 0.00, reconnects:  0.00
[3229s] threads: 64, tps: 1697.00, reads: 23784.02, writes: 6810.00, response time: 51.75ms (95%), errors: 0.00, reconnects:  0.00
[3230s] threads: 64, tps: 1675.00, reads: 23417.95, writes: 6655.98, response time: 52.09ms (95%), errors: 0.00, reconnects:  0.00
[3231s] threads: 64, tps: 1483.00, reads: 20853.04, writes: 5990.01, response time: 60.83ms (95%), errors: 0.00, reconnects:  0.00
[3232s] threads: 64, tps: 1507.00, reads: 21009.00, writes: 5961.00, response time: 59.33ms (95%), errors: 0.00, reconnects:  0.00
[3233s] threads: 64, tps: 1543.00, reads: 21668.02, writes: 6228.01, response time: 56.85ms (95%), errors: 0.00, reconnects:  0.00
[3234s] threads: 64, tps: 1632.00, reads: 22821.98, writes: 6538.99, response time: 53.37ms (95%), errors: 0.00, reconnects:  0.00
[3235s] threads: 64, tps: 1734.00, reads: 24231.00, writes: 6908.00, response time: 51.50ms (95%), errors: 0.00, reconnects:  0.00
[3236s] threads: 64, tps: 1726.00, reads: 23927.00, writes: 6872.00, response time: 51.92ms (95%), errors: 0.00, reconnects:  0.00
[3237s] threads: 64, tps: 1662.00, reads: 23415.96, writes: 6680.99, response time: 55.84ms (95%), errors: 0.00, reconnects:  0.00
[3238s] threads: 64, tps: 1511.00, reads: 21251.02, writes: 6002.01, response time: 58.07ms (95%), errors: 0.00, reconnects:  0.00
[3239s] threads: 64, tps: 1581.00, reads: 22094.00, writes: 6309.00, response time: 55.32ms (95%), errors: 0.00, reconnects:  0.00
[3240s] threads: 64, tps: 1579.00, reads: 22060.98, writes: 6351.00, response time: 55.50ms (95%), errors: 0.00, reconnects:  0.00
[3241s] threads: 64, tps: 1657.99, reads: 23273.90, writes: 6650.97, response time: 52.99ms (95%), errors: 0.00, reconnects:  0.00
[3242s] threads: 64, tps: 1682.01, reads: 23591.12, writes: 6741.04, response time: 51.42ms (95%), errors: 0.00, reconnects:  0.00
[3243s] threads: 64, tps: 1777.00, reads: 24829.00, writes: 7072.00, response time: 50.92ms (95%), errors: 0.00, reconnects:  0.00
[3244s] threads: 64, tps: 1749.00, reads: 24541.94, writes: 7026.98, response time: 50.22ms (95%), errors: 0.00, reconnects:  0.00
[3245s] threads: 64, tps: 1851.00, reads: 25835.07, writes: 7358.02, response time: 48.65ms (95%), errors: 0.00, reconnects:  0.00
[3246s] threads: 64, tps: 1755.00, reads: 24516.00, writes: 7059.00, response time: 53.06ms (95%), errors: 0.00, reconnects:  0.00
[3247s] threads: 64, tps: 1821.00, reads: 25716.00, writes: 7336.00, response time: 50.37ms (95%), errors: 0.00, reconnects:  0.00
[3248s] threads: 64, tps: 1835.00, reads: 25591.96, writes: 7307.99, response time: 47.96ms (95%), errors: 0.00, reconnects:  0.00
[3249s] threads: 64, tps: 1754.00, reads: 24552.01, writes: 6982.00, response time: 50.80ms (95%), errors: 0.00, reconnects:  0.00
[3250s] threads: 64, tps: 1849.00, reads: 25887.03, writes: 7435.01, response time: 48.49ms (95%), errors: 0.00, reconnects:  0.00
[3251s] threads: 64, tps: 1855.00, reads: 25961.00, writes: 7448.00, response time: 48.13ms (95%), errors: 0.00, reconnects:  0.00
[3252s] threads: 64, tps: 1791.99, reads: 25053.85, writes: 7152.96, response time: 50.61ms (95%), errors: 0.00, reconnects:  0.00
[3253s] threads: 64, tps: 1772.01, reads: 24828.14, writes: 7050.04, response time: 50.43ms (95%), errors: 0.00, reconnects:  0.00
[3254s] threads: 64, tps: 1758.00, reads: 24691.98, writes: 7054.99, response time: 52.09ms (95%), errors: 0.00, reconnects:  0.00
[3255s] threads: 64, tps: 1729.00, reads: 24214.02, writes: 6945.01, response time: 52.81ms (95%), errors: 0.00, reconnects:  0.00
[3256s] threads: 64, tps: 1754.00, reads: 24485.99, writes: 6987.00, response time: 51.13ms (95%), errors: 0.00, reconnects:  0.00
[3257s] threads: 64, tps: 1825.00, reads: 25523.03, writes: 7279.01, response time: 48.74ms (95%), errors: 0.00, reconnects:  0.00
[3258s] threads: 64, tps: 1766.00, reads: 24688.97, writes: 7034.99, response time: 50.31ms (95%), errors: 0.00, reconnects:  0.00
[3259s] threads: 64, tps: 1644.00, reads: 22966.98, writes: 6552.00, response time: 53.90ms (95%), errors: 0.00, reconnects:  0.00
[3260s] threads: 64, tps: 1610.00, reads: 22561.03, writes: 6440.01, response time: 54.33ms (95%), errors: 0.00, reconnects:  0.00
[3261s] threads: 64, tps: 1446.81, reads: 20316.33, writes: 5798.24, response time: 62.26ms (95%), errors: 0.00, reconnects:  0.00
[3262s] threads: 64, tps: 1508.20, reads: 21165.77, writes: 6083.80, response time: 56.69ms (95%), errors: 0.00, reconnects:  0.00
[3263s] threads: 64, tps: 1566.00, reads: 21876.96, writes: 6218.99, response time: 56.05ms (95%), errors: 0.00, reconnects:  0.00
[3264s] threads: 64, tps: 1679.00, reads: 23479.04, writes: 6714.01, response time: 52.43ms (95%), errors: 0.00, reconnects:  0.00
[3265s] threads: 64, tps: 1725.00, reads: 24128.98, writes: 6958.99, response time: 51.76ms (95%), errors: 0.00, reconnects:  0.00
[3266s] threads: 64, tps: 1781.00, reads: 24926.03, writes: 7046.01, response time: 50.49ms (95%), errors: 0.00, reconnects:  0.00
[3267s] threads: 64, tps: 1684.00, reads: 23646.99, writes: 6792.00, response time: 52.97ms (95%), errors: 0.00, reconnects:  0.00
[3268s] threads: 64, tps: 1589.00, reads: 22180.01, writes: 6302.00, response time: 55.94ms (95%), errors: 0.00, reconnects:  0.00
[3269s] threads: 64, tps: 1565.00, reads: 21950.01, writes: 6260.00, response time: 54.64ms (95%), errors: 0.00, reconnects:  0.00
[3270s] threads: 64, tps: 1576.00, reads: 22120.99, writes: 6342.00, response time: 55.27ms (95%), errors: 0.00, reconnects:  0.00
[3271s] threads: 64, tps: 1637.00, reads: 22795.99, writes: 6525.00, response time: 54.56ms (95%), errors: 0.00, reconnects:  0.00
[3272s] threads: 64, tps: 1700.00, reads: 23937.01, writes: 6879.00, response time: 50.60ms (95%), errors: 0.00, reconnects:  0.00
[3273s] threads: 64, tps: 1753.97, reads: 24445.56, writes: 7005.88, response time: 49.25ms (95%), errors: 0.00, reconnects:  0.00
[3274s] threads: 64, tps: 1793.03, reads: 25267.45, writes: 7211.13, response time: 48.06ms (95%), errors: 0.00, reconnects:  0.00
[3275s] threads: 64, tps: 1852.00, reads: 25773.98, writes: 7361.99, response time: 47.50ms (95%), errors: 0.00, reconnects:  0.00
[3276s] threads: 64, tps: 1847.00, reads: 25707.99, writes: 7337.00, response time: 47.42ms (95%), errors: 0.00, reconnects:  0.00
[3277s] threads: 64, tps: 1810.00, reads: 25384.99, writes: 7279.00, response time: 51.07ms (95%), errors: 0.00, reconnects:  0.00
[3278s] threads: 64, tps: 1663.99, reads: 23431.92, writes: 6635.98, response time: 52.86ms (95%), errors: 0.00, reconnects:  0.00
[3279s] threads: 64, tps: 1879.00, reads: 26340.01, writes: 7519.00, response time: 47.10ms (95%), errors: 0.00, reconnects:  0.00
[3280s] threads: 64, tps: 1838.00, reads: 25695.04, writes: 7395.01, response time: 50.84ms (95%), errors: 0.00, reconnects:  0.00
[3281s] threads: 64, tps: 1879.00, reads: 26294.05, writes: 7460.01, response time: 46.39ms (95%), errors: 0.00, reconnects:  0.00
[3282s] threads: 64, tps: 1807.00, reads: 25276.03, writes: 7243.01, response time: 49.82ms (95%), errors: 0.00, reconnects:  0.00
[3283s] threads: 64, tps: 1767.00, reads: 24765.99, writes: 7048.00, response time: 50.25ms (95%), errors: 0.00, reconnects:  0.00
[3284s] threads: 64, tps: 1749.00, reads: 24404.00, writes: 6990.00, response time: 50.99ms (95%), errors: 0.00, reconnects:  0.00
[3285s] threads: 64, tps: 1748.00, reads: 24414.02, writes: 6997.01, response time: 51.27ms (95%), errors: 0.00, reconnects:  0.00
[3286s] threads: 64, tps: 1765.00, reads: 24924.98, writes: 7097.00, response time: 50.80ms (95%), errors: 0.00, reconnects:  0.00
[3287s] threads: 64, tps: 1752.00, reads: 24469.02, writes: 7018.01, response time: 51.76ms (95%), errors: 0.00, reconnects:  0.00
[3288s] threads: 64, tps: 1689.00, reads: 23614.97, writes: 6725.99, response time: 53.43ms (95%), errors: 0.00, reconnects:  0.00
[3289s] threads: 64, tps: 1643.00, reads: 22967.02, writes: 6515.01, response time: 52.57ms (95%), errors: 0.00, reconnects:  0.00
[3290s] threads: 64, tps: 1405.00, reads: 19728.99, writes: 5633.00, response time: 65.87ms (95%), errors: 0.00, reconnects:  0.00
[3291s] threads: 64, tps: 1480.00, reads: 20719.99, writes: 5916.00, response time: 59.17ms (95%), errors: 0.00, reconnects:  0.00
[3292s] threads: 64, tps: 1546.00, reads: 21625.02, writes: 6208.01, response time: 55.60ms (95%), errors: 0.00, reconnects:  0.00
[3293s] threads: 64, tps: 1567.00, reads: 21895.00, writes: 6273.00, response time: 56.29ms (95%), errors: 0.00, reconnects:  0.00
[3294s] threads: 64, tps: 1720.00, reads: 24098.98, writes: 6888.99, response time: 51.21ms (95%), errors: 0.00, reconnects:  0.00
[3295s] threads: 64, tps: 1765.00, reads: 24707.03, writes: 7035.01, response time: 52.76ms (95%), errors: 0.00, reconnects:  0.00
[3296s] threads: 64, tps: 1688.00, reads: 23624.97, writes: 6787.99, response time: 53.32ms (95%), errors: 0.00, reconnects:  0.00
[3297s] threads: 64, tps: 1552.00, reads: 21738.03, writes: 6162.01, response time: 54.89ms (95%), errors: 0.00, reconnects:  0.00
[3298s] threads: 64, tps: 1518.99, reads: 21333.92, writes: 6101.98, response time: 57.50ms (95%), errors: 0.00, reconnects:  0.00
[3299s] threads: 64, tps: 1488.00, reads: 20765.05, writes: 5947.02, response time: 58.52ms (95%), errors: 0.00, reconnects:  0.00
[3300s] threads: 64, tps: 1487.00, reads: 20920.97, writes: 5994.99, response time: 58.31ms (95%), errors: 0.00, reconnects:  0.00
[3301s] threads: 64, tps: 1653.00, reads: 22981.06, writes: 6559.02, response time: 56.05ms (95%), errors: 0.00, reconnects:  0.00
[3302s] threads: 64, tps: 1657.00, reads: 23276.99, writes: 6687.00, response time: 52.91ms (95%), errors: 0.00, reconnects:  0.00
[3303s] threads: 64, tps: 1668.00, reads: 23390.00, writes: 6638.00, response time: 55.17ms (95%), errors: 0.00, reconnects:  0.00
[3304s] threads: 64, tps: 1690.98, reads: 23621.78, writes: 6799.94, response time: 54.94ms (95%), errors: 0.00, reconnects:  0.00
[3305s] threads: 64, tps: 1751.01, reads: 24536.19, writes: 7007.05, response time: 50.52ms (95%), errors: 0.00, reconnects:  0.00
[3306s] threads: 64, tps: 1766.00, reads: 24648.01, writes: 6997.00, response time: 51.32ms (95%), errors: 0.00, reconnects:  0.00
[3307s] threads: 64, tps: 1648.00, reads: 23318.01, writes: 6716.00, response time: 56.78ms (95%), errors: 0.00, reconnects:  0.00
[3308s] threads: 64, tps: 1789.00, reads: 24895.04, writes: 7092.01, response time: 51.50ms (95%), errors: 0.00, reconnects:  0.00
[3309s] threads: 64, tps: 1836.00, reads: 25711.98, writes: 7364.00, response time: 50.22ms (95%), errors: 0.00, reconnects:  0.00
[3310s] threads: 64, tps: 1772.00, reads: 24818.01, writes: 7140.00, response time: 50.51ms (95%), errors: 0.00, reconnects:  0.00
[3311s] threads: 64, tps: 1801.00, reads: 25141.97, writes: 7068.99, response time: 50.90ms (95%), errors: 0.00, reconnects:  0.00
[3312s] threads: 64, tps: 1777.00, reads: 24974.01, writes: 7177.00, response time: 49.79ms (95%), errors: 0.00, reconnects:  0.00
[3313s] threads: 64, tps: 1676.00, reads: 23426.97, writes: 6716.99, response time: 52.56ms (95%), errors: 0.00, reconnects:  0.00
[3314s] threads: 64, tps: 1690.00, reads: 23682.00, writes: 6764.00, response time: 52.94ms (95%), errors: 0.00, reconnects:  0.00
[3315s] threads: 64, tps: 1714.00, reads: 24127.00, writes: 6921.00, response time: 51.38ms (95%), errors: 0.00, reconnects:  0.00
[3316s] threads: 64, tps: 1801.00, reads: 25101.03, writes: 7126.01, response time: 50.34ms (95%), errors: 0.00, reconnects:  0.00
[3317s] threads: 64, tps: 1690.00, reads: 23551.99, writes: 6706.00, response time: 54.81ms (95%), errors: 0.00, reconnects:  0.00
[3318s] threads: 64, tps: 1514.00, reads: 21208.02, writes: 6049.00, response time: 57.29ms (95%), errors: 0.00, reconnects:  0.00
[3319s] threads: 64, tps: 1547.00, reads: 21674.99, writes: 6164.00, response time: 55.80ms (95%), errors: 0.00, reconnects:  0.00
[3320s] threads: 64, tps: 1354.99, reads: 19042.92, writes: 5420.98, response time: 65.85ms (95%), errors: 0.00, reconnects:  0.00
[3321s] threads: 64, tps: 1431.00, reads: 19967.99, writes: 5728.00, response time: 62.13ms (95%), errors: 0.00, reconnects:  0.00
[3322s] threads: 64, tps: 1484.01, reads: 20813.10, writes: 5942.03, response time: 57.79ms (95%), errors: 0.00, reconnects:  0.00
[3323s] threads: 64, tps: 1555.99, reads: 21674.91, writes: 6233.97, response time: 56.36ms (95%), errors: 0.00, reconnects:  0.00
[3324s] threads: 64, tps: 1592.00, reads: 22429.00, writes: 6425.00, response time: 54.87ms (95%), errors: 0.00, reconnects:  0.00
[3325s] threads: 64, tps: 1652.99, reads: 23073.80, writes: 6575.94, response time: 53.93ms (95%), errors: 0.00, reconnects:  0.00
[3326s] threads: 64, tps: 1540.02, reads: 21557.27, writes: 6116.08, response time: 56.24ms (95%), errors: 0.00, reconnects:  0.00
[3327s] threads: 64, tps: 1497.99, reads: 21016.91, writes: 6038.97, response time: 55.62ms (95%), errors: 0.00, reconnects:  0.00
[3328s] threads: 64, tps: 1463.99, reads: 20442.91, writes: 5828.97, response time: 58.35ms (95%), errors: 0.00, reconnects:  0.00
[3329s] threads: 64, tps: 1434.01, reads: 20045.09, writes: 5722.03, response time: 59.89ms (95%), errors: 0.00, reconnects:  0.00
[3330s] threads: 64, tps: 1502.01, reads: 21092.11, writes: 6018.03, response time: 58.82ms (95%), errors: 0.00, reconnects:  0.00
[3331s] threads: 64, tps: 1561.99, reads: 21894.91, writes: 6324.97, response time: 56.49ms (95%), errors: 0.00, reconnects:  0.00
[3332s] threads: 64, tps: 1634.00, reads: 22790.03, writes: 6488.01, response time: 54.51ms (95%), errors: 0.00, reconnects:  0.00
[3333s] threads: 64, tps: 1570.00, reads: 22133.05, writes: 6345.01, response time: 55.90ms (95%), errors: 0.00, reconnects:  0.00
[3334s] threads: 64, tps: 1612.99, reads: 22540.89, writes: 6414.97, response time: 53.11ms (95%), errors: 0.00, reconnects:  0.00
[3335s] threads: 64, tps: 1566.98, reads: 21788.75, writes: 6226.93, response time: 56.86ms (95%), errors: 0.00, reconnects:  0.00
[3336s] threads: 64, tps: 1697.02, reads: 23942.28, writes: 6836.08, response time: 50.70ms (95%), errors: 0.00, reconnects:  0.00
[3337s] threads: 64, tps: 1714.01, reads: 24002.13, writes: 6914.04, response time: 51.39ms (95%), errors: 0.00, reconnects:  0.00
[3338s] threads: 64, tps: 1774.00, reads: 24703.98, writes: 7008.99, response time: 49.43ms (95%), errors: 0.00, reconnects:  0.00
[3339s] threads: 64, tps: 1767.99, reads: 24803.90, writes: 7094.97, response time: 48.32ms (95%), errors: 0.00, reconnects:  0.00
[3340s] threads: 64, tps: 1778.01, reads: 24906.10, writes: 7115.03, response time: 50.15ms (95%), errors: 0.00, reconnects:  0.00
[3341s] threads: 64, tps: 1751.00, reads: 24513.01, writes: 7010.00, response time: 48.26ms (95%), errors: 0.00, reconnects:  0.00
[3342s] threads: 64, tps: 1737.00, reads: 24315.99, writes: 6940.00, response time: 52.94ms (95%), errors: 0.00, reconnects:  0.00
[3343s] threads: 64, tps: 1671.99, reads: 23412.89, writes: 6714.97, response time: 53.08ms (95%), errors: 0.00, reconnects:  0.00
[3344s] threads: 64, tps: 1637.01, reads: 22924.13, writes: 6520.04, response time: 53.16ms (95%), errors: 0.00, reconnects:  0.00
[3345s] threads: 64, tps: 1654.00, reads: 23208.99, writes: 6638.00, response time: 53.77ms (95%), errors: 0.00, reconnects:  0.00
[3346s] threads: 64, tps: 1680.00, reads: 23508.99, writes: 6722.00, response time: 51.78ms (95%), errors: 0.00, reconnects:  0.00
[3347s] threads: 64, tps: 1642.00, reads: 22944.99, writes: 6537.00, response time: 53.26ms (95%), errors: 0.00, reconnects:  0.00
[3348s] threads: 64, tps: 1558.99, reads: 21760.91, writes: 6166.97, response time: 56.12ms (95%), errors: 0.00, reconnects:  0.00
[3349s] threads: 64, tps: 1464.01, reads: 20624.11, writes: 5953.03, response time: 60.94ms (95%), errors: 0.00, reconnects:  0.00
[3350s] threads: 64, tps: 1391.00, reads: 19336.01, writes: 5512.00, response time: 66.14ms (95%), errors: 0.00, reconnects:  0.00
[3351s] threads: 64, tps: 1400.00, reads: 19692.98, writes: 5607.99, response time: 61.12ms (95%), errors: 0.00, reconnects:  0.00
[3352s] threads: 64, tps: 1440.00, reads: 20192.99, writes: 5788.00, response time: 61.19ms (95%), errors: 0.00, reconnects:  0.00
[3353s] threads: 64, tps: 1546.00, reads: 21619.01, writes: 6168.00, response time: 57.05ms (95%), errors: 0.00, reconnects:  0.00
[3354s] threads: 64, tps: 1584.99, reads: 22146.89, writes: 6322.97, response time: 56.17ms (95%), errors: 0.00, reconnects:  0.00
[3355s] threads: 64, tps: 1570.01, reads: 22021.12, writes: 6301.03, response time: 55.50ms (95%), errors: 0.00, reconnects:  0.00
[3356s] threads: 64, tps: 1479.00, reads: 20572.00, writes: 5865.00, response time: 58.86ms (95%), errors: 0.00, reconnects:  0.00
[3357s] threads: 64, tps: 1405.00, reads: 19700.99, writes: 5616.00, response time: 60.88ms (95%), errors: 0.00, reconnects:  0.00
[3358s] threads: 64, tps: 1396.98, reads: 19590.71, writes: 5598.92, response time: 61.43ms (95%), errors: 0.00, reconnects:  0.00
[3359s] threads: 64, tps: 1310.02, reads: 18338.28, writes: 5221.08, response time: 66.98ms (95%), errors: 0.00, reconnects:  0.00
[3360s] threads: 64, tps: 1318.00, reads: 18461.99, writes: 5295.00, response time: 66.96ms (95%), errors: 0.00, reconnects:  0.00
[3361s] threads: 64, tps: 1454.99, reads: 20369.92, writes: 5809.98, response time: 62.56ms (95%), errors: 0.00, reconnects:  0.00
[3362s] threads: 64, tps: 1302.01, reads: 18175.07, writes: 5204.02, response time: 73.56ms (95%), errors: 0.00, reconnects:  0.00
[3363s] threads: 64, tps: 1495.99, reads: 20976.87, writes: 5998.96, response time: 61.10ms (95%), errors: 0.00, reconnects:  0.00
[3364s] threads: 64, tps: 1485.01, reads: 20615.16, writes: 5946.05, response time: 65.18ms (95%), errors: 0.00, reconnects:  0.00
[3365s] threads: 64, tps: 1608.00, reads: 22776.02, writes: 6489.01, response time: 55.80ms (95%), errors: 0.00, reconnects:  0.00
[3366s] threads: 64, tps: 1584.00, reads: 22077.93, writes: 6281.98, response time: 58.87ms (95%), errors: 0.00, reconnects:  0.00
[3367s] threads: 64, tps: 1459.00, reads: 20352.04, writes: 5841.01, response time: 62.77ms (95%), errors: 0.00, reconnects:  0.00
[3368s] threads: 64, tps: 1495.00, reads: 20917.98, writes: 5943.99, response time: 60.92ms (95%), errors: 0.00, reconnects:  0.00
[3369s] threads: 64, tps: 1528.00, reads: 21457.02, writes: 6146.01, response time: 57.84ms (95%), errors: 0.00, reconnects:  0.00
[3370s] threads: 64, tps: 1745.00, reads: 24535.98, writes: 7018.00, response time: 52.21ms (95%), errors: 0.00, reconnects:  0.00
[3371s] threads: 64, tps: 1836.99, reads: 25687.89, writes: 7318.97, response time: 48.35ms (95%), errors: 0.00, reconnects:  0.00
[3372s] threads: 64, tps: 1895.01, reads: 26457.11, writes: 7595.03, response time: 45.70ms (95%), errors: 0.00, reconnects:  0.00
[3373s] threads: 64, tps: 1770.99, reads: 24760.84, writes: 7074.95, response time: 50.77ms (95%), errors: 0.00, reconnects:  0.00
[3374s] threads: 64, tps: 1715.00, reads: 24114.05, writes: 6882.01, response time: 50.51ms (95%), errors: 0.00, reconnects:  0.00
[3375s] threads: 64, tps: 1782.01, reads: 24937.15, writes: 7106.04, response time: 49.39ms (95%), errors: 0.00, reconnects:  0.00
[3376s] threads: 64, tps: 1820.00, reads: 25552.97, writes: 7326.99, response time: 48.97ms (95%), errors: 0.00, reconnects:  0.00
[3377s] threads: 64, tps: 1783.00, reads: 24813.01, writes: 7074.00, response time: 50.42ms (95%), errors: 0.00, reconnects:  0.00
[3378s] threads: 64, tps: 1657.97, reads: 23278.52, writes: 6623.86, response time: 54.74ms (95%), errors: 0.00, reconnects:  0.00
[3379s] threads: 64, tps: 1454.03, reads: 20327.42, writes: 5775.12, response time: 63.66ms (95%), errors: 0.00, reconnects:  0.00
[3380s] threads: 64, tps: 1193.00, reads: 16801.98, writes: 4782.99, response time: 76.07ms (95%), errors: 0.00, reconnects:  0.00
[3381s] threads: 64, tps: 1361.00, reads: 19083.00, writes: 5524.00, response time: 70.67ms (95%), errors: 0.00, reconnects:  0.00
[3382s] threads: 64, tps: 1481.00, reads: 20629.02, writes: 5881.01, response time: 61.01ms (95%), errors: 0.00, reconnects:  0.00
[3383s] threads: 64, tps: 1522.00, reads: 21448.01, writes: 6178.00, response time: 57.03ms (95%), errors: 0.00, reconnects:  0.00
[3384s] threads: 64, tps: 1533.99, reads: 21384.85, writes: 6087.96, response time: 59.37ms (95%), errors: 0.00, reconnects:  0.00
[3385s] threads: 64, tps: 1639.00, reads: 22868.06, writes: 6546.02, response time: 52.45ms (95%), errors: 0.00, reconnects:  0.00
[3386s] threads: 64, tps: 1656.01, reads: 23266.09, writes: 6625.03, response time: 52.18ms (95%), errors: 0.00, reconnects:  0.00
[3387s] threads: 64, tps: 1549.94, reads: 21631.20, writes: 6137.77, response time: 56.54ms (95%), errors: 0.00, reconnects:  0.00
[3388s] threads: 64, tps: 1543.06, reads: 21608.81, writes: 6155.23, response time: 55.25ms (95%), errors: 0.00, reconnects:  0.00
[3389s] threads: 64, tps: 1554.00, reads: 21825.97, writes: 6271.99, response time: 55.79ms (95%), errors: 0.00, reconnects:  0.00
[3390s] threads: 64, tps: 1672.00, reads: 23275.01, writes: 6655.00, response time: 53.00ms (95%), errors: 0.00, reconnects:  0.00
[3391s] threads: 64, tps: 1674.00, reads: 23475.01, writes: 6722.00, response time: 51.52ms (95%), errors: 0.00, reconnects:  0.00
[3392s] threads: 64, tps: 1616.00, reads: 22736.99, writes: 6510.00, response time: 55.62ms (95%), errors: 0.00, reconnects:  0.00
[3393s] threads: 64, tps: 1809.00, reads: 25152.02, writes: 7153.00, response time: 50.09ms (95%), errors: 0.00, reconnects:  0.00
[3394s] threads: 64, tps: 1679.00, reads: 23662.99, writes: 6801.00, response time: 53.72ms (95%), errors: 0.00, reconnects:  0.00
[3395s] threads: 64, tps: 1772.00, reads: 24700.00, writes: 7076.00, response time: 50.42ms (95%), errors: 0.00, reconnects:  0.00
[3396s] threads: 64, tps: 1794.99, reads: 25186.91, writes: 7194.98, response time: 49.25ms (95%), errors: 0.00, reconnects:  0.00
[3397s] threads: 64, tps: 1793.01, reads: 25068.10, writes: 7108.03, response time: 50.01ms (95%), errors: 0.00, reconnects:  0.00
[3398s] threads: 64, tps: 1749.00, reads: 24532.98, writes: 7033.99, response time: 51.56ms (95%), errors: 0.00, reconnects:  0.00
[3399s] threads: 64, tps: 1882.94, reads: 26374.21, writes: 7547.77, response time: 45.77ms (95%), errors: 0.00, reconnects:  0.00
[3400s] threads: 64, tps: 1927.06, reads: 26950.82, writes: 7670.23, response time: 46.91ms (95%), errors: 0.00, reconnects:  0.00
[3401s] threads: 64, tps: 1868.00, reads: 26169.99, writes: 7526.00, response time: 46.73ms (95%), errors: 0.00, reconnects:  0.00
[3402s] threads: 64, tps: 1808.00, reads: 25302.03, writes: 7184.01, response time: 50.12ms (95%), errors: 0.00, reconnects:  0.00
[3403s] threads: 64, tps: 1650.00, reads: 23082.99, writes: 6600.00, response time: 53.48ms (95%), errors: 0.00, reconnects:  0.00
[3404s] threads: 64, tps: 1529.00, reads: 21323.99, writes: 6132.00, response time: 55.97ms (95%), errors: 0.00, reconnects:  0.00
[3405s] threads: 64, tps: 1667.99, reads: 23452.89, writes: 6703.97, response time: 54.92ms (95%), errors: 0.00, reconnects:  0.00
[3406s] threads: 64, tps: 1747.00, reads: 24395.98, writes: 6919.99, response time: 52.39ms (95%), errors: 0.00, reconnects:  0.00
[3407s] threads: 64, tps: 1687.01, reads: 23668.11, writes: 6796.03, response time: 53.98ms (95%), errors: 0.00, reconnects:  0.00
[3408s] threads: 64, tps: 1570.00, reads: 21877.02, writes: 6213.01, response time: 58.63ms (95%), errors: 0.00, reconnects:  0.00
[3409s] threads: 64, tps: 1335.00, reads: 18834.02, writes: 5364.01, response time: 66.30ms (95%), errors: 0.00, reconnects:  0.00
[3410s] threads: 64, tps: 1217.00, reads: 16955.99, writes: 4831.00, response time: 78.07ms (95%), errors: 0.00, reconnects:  0.00
[3411s] threads: 64, tps: 1251.00, reads: 17593.99, writes: 5038.00, response time: 70.06ms (95%), errors: 0.00, reconnects:  0.00
[3412s] threads: 64, tps: 1370.00, reads: 19164.99, writes: 5478.00, response time: 65.12ms (95%), errors: 0.00, reconnects:  0.00
[3413s] threads: 64, tps: 1545.00, reads: 21494.02, writes: 6148.01, response time: 58.73ms (95%), errors: 0.00, reconnects:  0.00
[3414s] threads: 64, tps: 1593.00, reads: 22457.99, writes: 6437.00, response time: 57.24ms (95%), errors: 0.00, reconnects:  0.00
[3415s] threads: 64, tps: 1592.00, reads: 22203.93, writes: 6345.98, response time: 56.51ms (95%), errors: 0.00, reconnects:  0.00
[3416s] threads: 64, tps: 1552.00, reads: 21728.07, writes: 6168.02, response time: 55.01ms (95%), errors: 0.00, reconnects:  0.00
[3417s] threads: 64, tps: 1555.00, reads: 21829.93, writes: 6286.98, response time: 55.65ms (95%), errors: 0.00, reconnects:  0.00
[3418s] threads: 64, tps: 1580.00, reads: 22054.05, writes: 6268.02, response time: 54.56ms (95%), errors: 0.00, reconnects:  0.00
[3419s] threads: 64, tps: 1544.99, reads: 21681.89, writes: 6182.97, response time: 56.76ms (95%), errors: 0.00, reconnects:  0.00
[3420s] threads: 64, tps: 1592.01, reads: 22266.11, writes: 6387.03, response time: 56.95ms (95%), errors: 0.00, reconnects:  0.00
[3421s] threads: 64, tps: 1692.00, reads: 23845.02, writes: 6856.01, response time: 50.93ms (95%), errors: 0.00, reconnects:  0.00
[3422s] threads: 64, tps: 1783.00, reads: 24786.02, writes: 7055.01, response time: 49.11ms (95%), errors: 0.00, reconnects:  0.00
[3423s] threads: 64, tps: 1775.00, reads: 25023.98, writes: 7148.99, response time: 49.03ms (95%), errors: 0.00, reconnects:  0.00
[3424s] threads: 64, tps: 1800.97, reads: 25216.58, writes: 7242.88, response time: 48.59ms (95%), errors: 0.00, reconnects:  0.00
[3425s] threads: 64, tps: 1850.03, reads: 25702.45, writes: 7342.13, response time: 48.33ms (95%), errors: 0.00, reconnects:  0.00
[3426s] threads: 64, tps: 1818.00, reads: 25506.00, writes: 7266.00, response time: 47.77ms (95%), errors: 0.00, reconnects:  0.00
[3427s] threads: 64, tps: 1713.00, reads: 23884.97, writes: 6833.99, response time: 52.73ms (95%), errors: 0.00, reconnects:  0.00
[3428s] threads: 64, tps: 1817.91, reads: 25547.79, writes: 7268.66, response time: 48.13ms (95%), errors: 0.00, reconnects:  0.00
[3429s] threads: 64, tps: 1860.09, reads: 26013.27, writes: 7455.36, response time: 47.22ms (95%), errors: 0.00, reconnects:  0.00
[3430s] threads: 64, tps: 1838.00, reads: 25820.96, writes: 7359.99, response time: 47.16ms (95%), errors: 0.00, reconnects:  0.00
[3431s] threads: 64, tps: 1879.00, reads: 26270.99, writes: 7516.00, response time: 47.56ms (95%), errors: 0.00, reconnects:  0.00
[3432s] threads: 64, tps: 1833.00, reads: 25677.02, writes: 7359.01, response time: 49.00ms (95%), errors: 0.00, reconnects:  0.00
[3433s] threads: 64, tps: 1777.99, reads: 24893.87, writes: 7093.96, response time: 49.48ms (95%), errors: 0.00, reconnects:  0.00
[3434s] threads: 64, tps: 1759.00, reads: 24570.02, writes: 7049.01, response time: 50.57ms (95%), errors: 0.00, reconnects:  0.00
[3435s] threads: 64, tps: 1828.00, reads: 25497.01, writes: 7246.00, response time: 50.21ms (95%), errors: 0.00, reconnects:  0.00
[3436s] threads: 64, tps: 1723.01, reads: 24338.11, writes: 6967.03, response time: 51.18ms (95%), errors: 0.00, reconnects:  0.00
[3437s] threads: 64, tps: 1718.99, reads: 23842.88, writes: 6833.96, response time: 52.87ms (95%), errors: 0.00, reconnects:  0.00
[3438s] threads: 64, tps: 1675.01, reads: 23569.13, writes: 6689.04, response time: 52.23ms (95%), errors: 0.00, reconnects:  0.00
[3439s] threads: 64, tps: 1585.00, reads: 22163.95, writes: 6292.99, response time: 55.40ms (95%), errors: 0.00, reconnects:  0.00
[3440s] threads: 64, tps: 1488.00, reads: 20899.94, writes: 5961.98, response time: 65.38ms (95%), errors: 0.00, reconnects:  0.00
[3441s] threads: 64, tps: 1469.01, reads: 20510.10, writes: 5868.03, response time: 60.26ms (95%), errors: 0.00, reconnects:  0.00
[3442s] threads: 64, tps: 1531.99, reads: 21487.88, writes: 6163.97, response time: 58.10ms (95%), errors: 0.00, reconnects:  0.00
[3443s] threads: 64, tps: 1605.01, reads: 22377.09, writes: 6383.02, response time: 58.07ms (95%), errors: 0.00, reconnects:  0.00
[3444s] threads: 64, tps: 1499.99, reads: 21047.90, writes: 6010.97, response time: 61.63ms (95%), errors: 0.00, reconnects:  0.00
[3445s] threads: 64, tps: 1400.01, reads: 19543.13, writes: 5580.04, response time: 65.43ms (95%), errors: 0.00, reconnects:  0.00
[3446s] threads: 64, tps: 1497.00, reads: 21005.00, writes: 6010.00, response time: 59.26ms (95%), errors: 0.00, reconnects:  0.00
[3447s] threads: 64, tps: 1445.00, reads: 20235.97, writes: 5785.99, response time: 61.01ms (95%), errors: 0.00, reconnects:  0.00
[3448s] threads: 64, tps: 1429.00, reads: 20049.01, writes: 5779.00, response time: 63.91ms (95%), errors: 0.00, reconnects:  0.00
[3449s] threads: 64, tps: 1498.00, reads: 21036.99, writes: 5990.00, response time: 59.76ms (95%), errors: 0.00, reconnects:  0.00
[3450s] threads: 64, tps: 1644.98, reads: 22856.76, writes: 6515.93, response time: 55.68ms (95%), errors: 0.00, reconnects:  0.00
[3451s] threads: 64, tps: 1684.02, reads: 23643.24, writes: 6776.07, response time: 52.17ms (95%), errors: 0.00, reconnects:  0.00
[3452s] threads: 64, tps: 1675.00, reads: 23517.00, writes: 6725.00, response time: 52.61ms (95%), errors: 0.00, reconnects:  0.00
[3453s] threads: 64, tps: 1760.00, reads: 24723.03, writes: 7068.01, response time: 49.40ms (95%), errors: 0.00, reconnects:  0.00
[3454s] threads: 64, tps: 1792.00, reads: 24918.97, writes: 7115.99, response time: 51.18ms (95%), errors: 0.00, reconnects:  0.00
[3455s] threads: 64, tps: 1750.99, reads: 24487.89, writes: 6956.97, response time: 51.28ms (95%), errors: 0.00, reconnects:  0.00
[3456s] threads: 64, tps: 1810.01, reads: 25208.09, writes: 7257.03, response time: 49.25ms (95%), errors: 0.00, reconnects:  0.00
[3457s] threads: 64, tps: 1718.00, reads: 24186.02, writes: 6855.01, response time: 52.10ms (95%), errors: 0.00, reconnects:  0.00
[3458s] threads: 64, tps: 1748.00, reads: 24505.01, writes: 7015.00, response time: 50.75ms (95%), errors: 0.00, reconnects:  0.00
[3459s] threads: 64, tps: 1811.00, reads: 25376.97, writes: 7292.99, response time: 48.45ms (95%), errors: 0.00, reconnects:  0.00
[3460s] threads: 64, tps: 1738.00, reads: 24313.00, writes: 6901.00, response time: 50.73ms (95%), errors: 0.00, reconnects:  0.00
[3461s] threads: 64, tps: 1831.99, reads: 25555.93, writes: 7321.98, response time: 47.52ms (95%), errors: 0.00, reconnects:  0.00
[3462s] threads: 64, tps: 1782.00, reads: 24892.00, writes: 7093.00, response time: 49.64ms (95%), errors: 0.00, reconnects:  0.00
[3463s] threads: 64, tps: 1740.01, reads: 24577.08, writes: 7047.02, response time: 49.27ms (95%), errors: 0.00, reconnects:  0.00
[3464s] threads: 64, tps: 1721.00, reads: 24043.99, writes: 6848.00, response time: 50.96ms (95%), errors: 0.00, reconnects:  0.00
[3465s] threads: 64, tps: 1722.00, reads: 24280.04, writes: 7027.01, response time: 50.04ms (95%), errors: 0.00, reconnects:  0.00
[3466s] threads: 64, tps: 1807.99, reads: 25051.89, writes: 7100.97, response time: 52.06ms (95%), errors: 0.00, reconnects:  0.00
[3467s] threads: 64, tps: 1742.00, reads: 24496.06, writes: 6922.02, response time: 50.81ms (95%), errors: 0.00, reconnects:  0.00
[3468s] threads: 64, tps: 1480.00, reads: 20693.02, writes: 5932.01, response time: 61.72ms (95%), errors: 0.00, reconnects:  0.00
[3469s] threads: 64, tps: 1494.00, reads: 21092.97, writes: 6120.99, response time: 58.86ms (95%), errors: 0.00, reconnects:  0.00
[3470s] threads: 64, tps: 1378.00, reads: 19133.04, writes: 5345.01, response time: 66.66ms (95%), errors: 0.00, reconnects:  0.00
[3471s] threads: 64, tps: 1440.99, reads: 20151.90, writes: 5765.97, response time: 61.52ms (95%), errors: 0.00, reconnects:  0.00
[3472s] threads: 64, tps: 1419.00, reads: 19882.05, writes: 5731.01, response time: 65.16ms (95%), errors: 0.00, reconnects:  0.00
[3473s] threads: 64, tps: 1538.99, reads: 21675.91, writes: 6232.97, response time: 58.09ms (95%), errors: 0.00, reconnects:  0.00
[3474s] threads: 64, tps: 1549.01, reads: 21579.14, writes: 6131.04, response time: 59.58ms (95%), errors: 0.00, reconnects:  0.00
[3475s] threads: 64, tps: 1609.00, reads: 22435.98, writes: 6384.99, response time: 53.40ms (95%), errors: 0.00, reconnects:  0.00
[3476s] threads: 64, tps: 1538.00, reads: 21529.01, writes: 6152.00, response time: 56.93ms (95%), errors: 0.00, reconnects:  0.00
[3477s] threads: 64, tps: 1543.00, reads: 21637.99, writes: 6193.00, response time: 55.97ms (95%), errors: 0.00, reconnects:  0.00
[3478s] threads: 64, tps: 1372.00, reads: 19295.00, writes: 5482.00, response time: 66.16ms (95%), errors: 0.00, reconnects:  0.00
[3479s] threads: 64, tps: 1438.99, reads: 20025.91, writes: 5791.98, response time: 64.42ms (95%), errors: 0.00, reconnects:  0.00
[3480s] threads: 64, tps: 1521.97, reads: 21322.61, writes: 6026.89, response time: 58.96ms (95%), errors: 0.00, reconnects:  0.00
[3481s] threads: 64, tps: 1678.04, reads: 23620.56, writes: 6784.16, response time: 55.63ms (95%), errors: 0.00, reconnects:  0.00
[3482s] threads: 64, tps: 1702.99, reads: 23775.85, writes: 6806.96, response time: 52.46ms (95%), errors: 0.00, reconnects:  0.00
[3483s] threads: 64, tps: 1691.01, reads: 23643.13, writes: 6739.04, response time: 52.51ms (95%), errors: 0.00, reconnects:  0.00
[3484s] threads: 64, tps: 1830.00, reads: 25512.00, writes: 7274.00, response time: 48.12ms (95%), errors: 0.00, reconnects:  0.00
[3485s] threads: 64, tps: 1835.00, reads: 25812.00, writes: 7395.00, response time: 48.96ms (95%), errors: 0.00, reconnects:  0.00
[3486s] threads: 64, tps: 1756.00, reads: 24600.97, writes: 7009.99, response time: 51.13ms (95%), errors: 0.00, reconnects:  0.00
[3487s] threads: 64, tps: 1607.00, reads: 22536.04, writes: 6459.01, response time: 54.40ms (95%), errors: 0.00, reconnects:  0.00
[3488s] threads: 64, tps: 1802.95, reads: 25182.34, writes: 7160.81, response time: 48.61ms (95%), errors: 0.00, reconnects:  0.00
[3489s] threads: 64, tps: 1806.05, reads: 25244.65, writes: 7261.19, response time: 50.39ms (95%), errors: 0.00, reconnects:  0.00
[3490s] threads: 64, tps: 1857.00, reads: 26060.02, writes: 7404.01, response time: 47.83ms (95%), errors: 0.00, reconnects:  0.00
[3491s] threads: 64, tps: 1871.00, reads: 26155.99, writes: 7500.00, response time: 47.57ms (95%), errors: 0.00, reconnects:  0.00
[3492s] threads: 64, tps: 1859.98, reads: 26133.78, writes: 7467.94, response time: 47.06ms (95%), errors: 0.00, reconnects:  0.00
[3493s] threads: 64, tps: 1875.01, reads: 26156.20, writes: 7438.06, response time: 47.86ms (95%), errors: 0.00, reconnects:  0.00
[3494s] threads: 64, tps: 1806.00, reads: 25360.01, writes: 7255.00, response time: 49.11ms (95%), errors: 0.00, reconnects:  0.00
[3495s] threads: 64, tps: 1882.99, reads: 26277.88, writes: 7526.96, response time: 47.52ms (95%), errors: 0.00, reconnects:  0.00
[3496s] threads: 64, tps: 1882.01, reads: 26327.11, writes: 7537.03, response time: 47.15ms (95%), errors: 0.00, reconnects:  0.00
[3497s] threads: 64, tps: 1861.00, reads: 26028.03, writes: 7386.01, response time: 48.19ms (95%), errors: 0.00, reconnects:  0.00
[3498s] threads: 64, tps: 1771.00, reads: 24824.97, writes: 7089.99, response time: 50.75ms (95%), errors: 0.00, reconnects:  0.00
[3499s] threads: 64, tps: 1649.00, reads: 23151.00, writes: 6606.00, response time: 55.27ms (95%), errors: 0.00, reconnects:  0.00
[3500s] threads: 64, tps: 1414.00, reads: 19925.00, writes: 5771.00, response time: 63.47ms (95%), errors: 0.00, reconnects:  0.00
[3501s] threads: 64, tps: 1517.00, reads: 21132.03, writes: 5968.01, response time: 59.85ms (95%), errors: 0.00, reconnects:  0.00
[3502s] threads: 64, tps: 1587.00, reads: 22233.00, writes: 6372.00, response time: 55.73ms (95%), errors: 0.00, reconnects:  0.00
[3503s] threads: 64, tps: 1662.00, reads: 23351.97, writes: 6716.99, response time: 54.46ms (95%), errors: 0.00, reconnects:  0.00
[3504s] threads: 64, tps: 1729.00, reads: 24142.95, writes: 6866.99, response time: 51.30ms (95%), errors: 0.00, reconnects:  0.00
[3505s] threads: 64, tps: 1638.01, reads: 22751.08, writes: 6479.02, response time: 54.33ms (95%), errors: 0.00, reconnects:  0.00
[3506s] threads: 64, tps: 1598.00, reads: 22482.00, writes: 6433.00, response time: 53.24ms (95%), errors: 0.00, reconnects:  0.00
[3507s] threads: 64, tps: 1583.00, reads: 22050.01, writes: 6285.00, response time: 55.27ms (95%), errors: 0.00, reconnects:  0.00
[3508s] threads: 64, tps: 1605.00, reads: 22571.99, writes: 6450.00, response time: 53.93ms (95%), errors: 0.00, reconnects:  0.00
[3509s] threads: 64, tps: 1706.00, reads: 24021.00, writes: 6918.00, response time: 50.24ms (95%), errors: 0.00, reconnects:  0.00
[3510s] threads: 64, tps: 1756.00, reads: 24373.99, writes: 6920.00, response time: 49.03ms (95%), errors: 0.00, reconnects:  0.00
[3511s] threads: 64, tps: 1780.00, reads: 24915.01, writes: 7126.00, response time: 48.93ms (95%), errors: 0.00, reconnects:  0.00
[3512s] threads: 64, tps: 1851.00, reads: 26062.96, writes: 7481.99, response time: 47.47ms (95%), errors: 0.00, reconnects:  0.00
[3513s] threads: 64, tps: 1903.00, reads: 26674.06, writes: 7610.02, response time: 45.63ms (95%), errors: 0.00, reconnects:  0.00
[3514s] threads: 64, tps: 1912.23, reads: 26616.32, writes: 7588.96, response time: 45.85ms (95%), errors: 0.00, reconnects:  0.00
[3515s] threads: 64, tps: 1907.77, reads: 26753.80, writes: 7637.08, response time: 46.36ms (95%), errors: 0.00, reconnects:  0.00
[3516s] threads: 64, tps: 1942.00, reads: 27233.98, writes: 7769.99, response time: 45.76ms (95%), errors: 0.00, reconnects:  0.00
[3517s] threads: 64, tps: 1924.99, reads: 26957.82, writes: 7762.95, response time: 46.96ms (95%), errors: 0.00, reconnects:  0.00
[3518s] threads: 64, tps: 1976.01, reads: 27575.18, writes: 7821.05, response time: 46.07ms (95%), errors: 0.00, reconnects:  0.00
[3519s] threads: 64, tps: 1950.00, reads: 27374.02, writes: 7859.01, response time: 45.14ms (95%), errors: 0.00, reconnects:  0.00
[3520s] threads: 64, tps: 2002.00, reads: 28079.97, writes: 8011.99, response time: 43.89ms (95%), errors: 0.00, reconnects:  0.00
[3521s] threads: 64, tps: 1945.00, reads: 27232.04, writes: 7806.01, response time: 45.14ms (95%), errors: 0.00, reconnects:  0.00
[3522s] threads: 64, tps: 1887.00, reads: 26430.98, writes: 7512.00, response time: 48.90ms (95%), errors: 0.00, reconnects:  0.00
[3523s] threads: 64, tps: 1797.00, reads: 25012.99, writes: 7193.00, response time: 51.72ms (95%), errors: 0.00, reconnects:  0.00
[3524s] threads: 64, tps: 1756.00, reads: 24569.01, writes: 6950.00, response time: 49.86ms (95%), errors: 0.00, reconnects:  0.00
[3525s] threads: 64, tps: 1543.00, reads: 21618.97, writes: 6173.99, response time: 57.64ms (95%), errors: 0.00, reconnects:  0.00
[3526s] threads: 64, tps: 1667.00, reads: 23432.03, writes: 6718.01, response time: 53.72ms (95%), errors: 0.00, reconnects:  0.00
[3527s] threads: 64, tps: 1701.00, reads: 23753.00, writes: 6776.00, response time: 54.68ms (95%), errors: 0.00, reconnects:  0.00
[3528s] threads: 64, tps: 1499.00, reads: 21011.99, writes: 5962.00, response time: 57.55ms (95%), errors: 0.00, reconnects:  0.00
[3529s] threads: 64, tps: 1324.00, reads: 18687.03, writes: 5394.01, response time: 69.12ms (95%), errors: 0.00, reconnects:  0.00
[3530s] threads: 64, tps: 1288.00, reads: 17814.96, writes: 5044.99, response time: 74.11ms (95%), errors: 0.00, reconnects:  0.00
[3531s] threads: 64, tps: 1249.00, reads: 17543.04, writes: 5009.01, response time: 68.75ms (95%), errors: 0.00, reconnects:  0.00
[3532s] threads: 64, tps: 1406.00, reads: 19706.97, writes: 5687.99, response time: 62.81ms (95%), errors: 0.00, reconnects:  0.00
[3533s] threads: 64, tps: 1590.00, reads: 22186.00, writes: 6300.00, response time: 56.10ms (95%), errors: 0.00, reconnects:  0.00
[3534s] threads: 64, tps: 1576.00, reads: 22048.01, writes: 6339.00, response time: 55.57ms (95%), errors: 0.00, reconnects:  0.00
[3535s] threads: 64, tps: 1626.00, reads: 22759.99, writes: 6484.00, response time: 53.69ms (95%), errors: 0.00, reconnects:  0.00
[3536s] threads: 64, tps: 1632.00, reads: 22830.01, writes: 6533.00, response time: 51.44ms (95%), errors: 0.00, reconnects:  0.00
[3537s] threads: 64, tps: 1669.99, reads: 23486.91, writes: 6682.97, response time: 52.56ms (95%), errors: 0.00, reconnects:  0.00
[3538s] threads: 64, tps: 1642.01, reads: 22895.10, writes: 6553.03, response time: 54.01ms (95%), errors: 0.00, reconnects:  0.00
[3539s] threads: 64, tps: 1680.00, reads: 23469.02, writes: 6695.00, response time: 54.37ms (95%), errors: 0.00, reconnects:  0.00
[3540s] threads: 64, tps: 1742.00, reads: 24464.96, writes: 7024.99, response time: 50.52ms (95%), errors: 0.00, reconnects:  0.00
[3541s] threads: 64, tps: 1729.00, reads: 24261.00, writes: 6920.00, response time: 49.80ms (95%), errors: 0.00, reconnects:  0.00
[3542s] threads: 64, tps: 1777.00, reads: 24829.04, writes: 7128.01, response time: 50.80ms (95%), errors: 0.00, reconnects:  0.00
[3543s] threads: 64, tps: 1751.00, reads: 24475.99, writes: 7000.00, response time: 49.53ms (95%), errors: 0.00, reconnects:  0.00
[3544s] threads: 64, tps: 1886.00, reads: 26533.99, writes: 7574.00, response time: 46.81ms (95%), errors: 0.00, reconnects:  0.00
[3545s] threads: 64, tps: 1681.98, reads: 23519.77, writes: 6711.94, response time: 53.24ms (95%), errors: 0.00, reconnects:  0.00
[3546s] threads: 64, tps: 1802.02, reads: 25085.24, writes: 7173.07, response time: 49.00ms (95%), errors: 0.00, reconnects:  0.00
[3547s] threads: 64, tps: 1815.00, reads: 25530.00, writes: 7272.00, response time: 50.45ms (95%), errors: 0.00, reconnects:  0.00
[3548s] threads: 64, tps: 1873.00, reads: 26174.01, writes: 7450.00, response time: 47.01ms (95%), errors: 0.00, reconnects:  0.00
[3549s] threads: 64, tps: 1923.00, reads: 26998.02, writes: 7751.01, response time: 45.13ms (95%), errors: 0.00, reconnects:  0.00
[3550s] threads: 64, tps: 1914.99, reads: 26757.91, writes: 7688.97, response time: 44.37ms (95%), errors: 0.00, reconnects:  0.00
[3551s] threads: 64, tps: 1899.99, reads: 26542.93, writes: 7492.98, response time: 46.41ms (95%), errors: 0.00, reconnects:  0.00
[3552s] threads: 64, tps: 1737.82, reads: 24342.41, writes: 6994.26, response time: 53.59ms (95%), errors: 0.00, reconnects:  0.00
[3553s] threads: 64, tps: 1849.19, reads: 25991.71, writes: 7464.78, response time: 46.98ms (95%), errors: 0.00, reconnects:  0.00
[3554s] threads: 64, tps: 1886.01, reads: 26431.20, writes: 7493.06, response time: 46.81ms (95%), errors: 0.00, reconnects:  0.00
[3555s] threads: 64, tps: 1793.00, reads: 25152.95, writes: 7255.99, response time: 50.90ms (95%), errors: 0.00, reconnects:  0.00
[3556s] threads: 64, tps: 1899.00, reads: 26526.03, writes: 7531.01, response time: 46.36ms (95%), errors: 0.00, reconnects:  0.00
[3557s] threads: 64, tps: 1761.00, reads: 24620.00, writes: 7033.00, response time: 51.56ms (95%), errors: 0.00, reconnects:  0.00
[3558s] threads: 64, tps: 1757.00, reads: 24714.99, writes: 7046.00, response time: 48.57ms (95%), errors: 0.00, reconnects:  0.00
[3559s] threads: 64, tps: 1619.00, reads: 22620.00, writes: 6452.00, response time: 59.14ms (95%), errors: 0.00, reconnects:  0.00
[3560s] threads: 64, tps: 1482.00, reads: 20669.02, writes: 5882.01, response time: 60.32ms (95%), errors: 0.00, reconnects:  0.00
[3561s] threads: 64, tps: 1585.00, reads: 22110.96, writes: 6358.99, response time: 57.21ms (95%), errors: 0.00, reconnects:  0.00
[3562s] threads: 64, tps: 1684.00, reads: 23646.05, writes: 6767.01, response time: 52.50ms (95%), errors: 0.00, reconnects:  0.00
[3563s] threads: 64, tps: 1754.00, reads: 24516.00, writes: 6988.00, response time: 50.24ms (95%), errors: 0.00, reconnects:  0.00
[3564s] threads: 64, tps: 1698.00, reads: 23717.99, writes: 6780.00, response time: 53.46ms (95%), errors: 0.00, reconnects:  0.00
[3565s] threads: 64, tps: 1648.00, reads: 23123.99, writes: 6615.00, response time: 54.84ms (95%), errors: 0.00, reconnects:  0.00
[3566s] threads: 64, tps: 1719.00, reads: 24044.00, writes: 6836.00, response time: 51.95ms (95%), errors: 0.00, reconnects:  0.00
[3567s] threads: 64, tps: 1801.00, reads: 25206.99, writes: 7217.00, response time: 48.93ms (95%), errors: 0.00, reconnects:  0.00
[3568s] threads: 64, tps: 1770.00, reads: 24774.03, writes: 7093.01, response time: 48.36ms (95%), errors: 0.00, reconnects:  0.00
[3569s] threads: 64, tps: 1782.00, reads: 25007.98, writes: 7173.00, response time: 49.18ms (95%), errors: 0.00, reconnects:  0.00
[3570s] threads: 64, tps: 1828.00, reads: 25626.01, writes: 7315.00, response time: 47.57ms (95%), errors: 0.00, reconnects:  0.00
[3571s] threads: 64, tps: 1871.00, reads: 26236.97, writes: 7501.99, response time: 47.87ms (95%), errors: 0.00, reconnects:  0.00
[3572s] threads: 64, tps: 1914.99, reads: 26739.87, writes: 7662.96, response time: 46.24ms (95%), errors: 0.00, reconnects:  0.00
[3573s] threads: 64, tps: 1949.01, reads: 27174.15, writes: 7706.04, response time: 47.39ms (95%), errors: 0.00, reconnects:  0.00
[3574s] threads: 64, tps: 1932.00, reads: 27167.01, writes: 7758.00, response time: 46.75ms (95%), errors: 0.00, reconnects:  0.00
[3575s] threads: 64, tps: 1816.00, reads: 25238.99, writes: 7234.00, response time: 51.44ms (95%), errors: 0.00, reconnects:  0.00
[3576s] threads: 64, tps: 1916.00, reads: 26970.99, writes: 7694.00, response time: 47.10ms (95%), errors: 0.00, reconnects:  0.00
[3577s] threads: 64, tps: 1988.00, reads: 27789.02, writes: 7926.01, response time: 46.27ms (95%), errors: 0.00, reconnects:  0.00
[3578s] threads: 64, tps: 1941.00, reads: 27322.01, writes: 7814.00, response time: 46.81ms (95%), errors: 0.00, reconnects:  0.00
[3579s] threads: 64, tps: 1884.00, reads: 26356.00, writes: 7573.00, response time: 47.09ms (95%), errors: 0.00, reconnects:  0.00
[3580s] threads: 64, tps: 1862.00, reads: 26135.00, writes: 7456.00, response time: 46.68ms (95%), errors: 0.00, reconnects:  0.00
[3581s] threads: 64, tps: 1932.00, reads: 26874.96, writes: 7631.99, response time: 46.43ms (95%), errors: 0.00, reconnects:  0.00
[3582s] threads: 64, tps: 1859.00, reads: 26082.04, writes: 7498.01, response time: 47.05ms (95%), errors: 0.00, reconnects:  0.00
[3583s] threads: 64, tps: 1849.00, reads: 25880.98, writes: 7387.99, response time: 49.33ms (95%), errors: 0.00, reconnects:  0.00
[3584s] threads: 64, tps: 1901.00, reads: 26659.05, writes: 7648.01, response time: 47.73ms (95%), errors: 0.00, reconnects:  0.00
[3585s] threads: 64, tps: 1858.00, reads: 26024.97, writes: 7377.99, response time: 46.46ms (95%), errors: 0.00, reconnects:  0.00
[3586s] threads: 64, tps: 1753.00, reads: 24522.98, writes: 7055.99, response time: 51.22ms (95%), errors: 0.00, reconnects:  0.00
[3587s] threads: 64, tps: 1695.00, reads: 23841.01, writes: 6812.00, response time: 52.54ms (95%), errors: 0.00, reconnects:  0.00
[3588s] threads: 64, tps: 1645.00, reads: 23053.98, writes: 6573.99, response time: 55.97ms (95%), errors: 0.00, reconnects:  0.00
[3589s] threads: 64, tps: 1467.00, reads: 20312.03, writes: 5754.01, response time: 63.62ms (95%), errors: 0.00, reconnects:  0.00
[3590s] threads: 64, tps: 1513.00, reads: 21261.01, writes: 6048.00, response time: 59.64ms (95%), errors: 0.00, reconnects:  0.00
[3591s] threads: 64, tps: 1602.00, reads: 22463.97, writes: 6465.99, response time: 55.70ms (95%), errors: 0.00, reconnects:  0.00
[3592s] threads: 64, tps: 1524.00, reads: 21330.01, writes: 6144.00, response time: 60.14ms (95%), errors: 0.00, reconnects:  0.00
[3593s] threads: 64, tps: 1689.97, reads: 23533.56, writes: 6667.88, response time: 53.13ms (95%), errors: 0.00, reconnects:  0.00
[3594s] threads: 64, tps: 1647.03, reads: 23057.45, writes: 6587.13, response time: 53.22ms (95%), errors: 0.00, reconnects:  0.00
[3595s] threads: 64, tps: 1647.00, reads: 23077.98, writes: 6575.00, response time: 53.95ms (95%), errors: 0.00, reconnects:  0.00
[3596s] threads: 64, tps: 1694.00, reads: 23838.99, writes: 6865.00, response time: 51.36ms (95%), errors: 0.00, reconnects:  0.00
[3597s] threads: 64, tps: 1697.99, reads: 23848.91, writes: 6819.98, response time: 51.25ms (95%), errors: 0.00, reconnects:  0.00
[3598s] threads: 64, tps: 1804.01, reads: 25138.10, writes: 7152.03, response time: 49.33ms (95%), errors: 0.00, reconnects:  0.00
[3599s] threads: 64, tps: 1850.00, reads: 25765.01, writes: 7374.00, response time: 49.55ms (95%), errors: 0.00, reconnects:  0.00
[3600s] threads: 64, tps: 1801.00, reads: 25363.98, writes: 7292.99, response time: 49.45ms (95%), errors: 0.00, reconnects:  0.00
OLTP test statistics:
    queries performed:
        read:                            93395988
        write:                           26684568
        other:                           13342284
        total:                           133422840
    transactions:                        6671142 (1853.09 per sec.)
    read/write requests:                 120080556 (33355.57 per sec.)
    other operations:                    13342284 (3706.17 per sec.)
    ignored errors:                      0      (0.00 per sec.)
    reconnects:                          0      (0.00 per sec.)

General statistics:
    total time:                          3600.0149s
    total number of events:              6671142
    total time taken by event execution: 230388.6233s
    response time:
         min:                                  3.29ms
         avg:                                 34.54ms
         max:                                621.35ms
         approx.  95 percentile:              51.70ms

Threads fairness:
    events (avg/stddev):           104236.5938/644.32
    execution time (avg/stddev):   3599.8222/0.00

