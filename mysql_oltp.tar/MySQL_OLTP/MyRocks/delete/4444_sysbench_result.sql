sysbench 0.5:  multi-threaded system evaluation benchmark

Running the test with following options:
Number of threads: 64
Report intermediate results every 1 second(s)
Initializing random number generator from timer.

Random number generator seed is 0 and will be ignored


Threads started!

[   1s] threads: 64, tps: 0.00, reads: 0.00, writes: 20069.98, response time: 10.27ms (95%), errors: 0.00, reconnects:  0.00
[   2s] threads: 64, tps: 0.00, reads: 0.00, writes: 26899.16, response time: 8.62ms (95%), errors: 0.00, reconnects:  0.00
[   3s] threads: 64, tps: 0.00, reads: 0.00, writes: 30732.06, response time: 6.52ms (95%), errors: 0.00, reconnects:  0.00
[   4s] threads: 64, tps: 0.00, reads: 0.00, writes: 30834.95, response time: 6.37ms (95%), errors: 0.00, reconnects:  0.00
[   5s] threads: 64, tps: 0.00, reads: 0.00, writes: 32126.66, response time: 6.55ms (95%), errors: 0.00, reconnects:  0.00
[   6s] threads: 64, tps: 0.00, reads: 0.00, writes: 32513.31, response time: 5.57ms (95%), errors: 0.00, reconnects:  0.00
[   7s] threads: 64, tps: 0.00, reads: 0.00, writes: 27608.01, response time: 7.57ms (95%), errors: 0.00, reconnects:  0.00
[   8s] threads: 64, tps: 0.00, reads: 0.00, writes: 31291.99, response time: 6.31ms (95%), errors: 0.00, reconnects:  0.00
[   9s] threads: 64, tps: 0.00, reads: 0.00, writes: 31981.02, response time: 5.67ms (95%), errors: 0.00, reconnects:  0.00
[  10s] threads: 64, tps: 0.00, reads: 0.00, writes: 33765.97, response time: 5.11ms (95%), errors: 0.00, reconnects:  0.00
[  11s] threads: 64, tps: 0.00, reads: 0.00, writes: 34851.98, response time: 5.19ms (95%), errors: 0.00, reconnects:  0.00
[  12s] threads: 64, tps: 0.00, reads: 0.00, writes: 36389.07, response time: 4.87ms (95%), errors: 0.00, reconnects:  0.00
[  13s] threads: 64, tps: 0.00, reads: 0.00, writes: 35961.94, response time: 5.26ms (95%), errors: 0.00, reconnects:  0.00
[  14s] threads: 64, tps: 0.00, reads: 0.00, writes: 39089.87, response time: 3.84ms (95%), errors: 0.00, reconnects:  0.00
[  15s] threads: 64, tps: 0.00, reads: 0.00, writes: 37236.16, response time: 4.31ms (95%), errors: 0.00, reconnects:  0.00
[  16s] threads: 64, tps: 0.00, reads: 0.00, writes: 42845.26, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[  17s] threads: 64, tps: 0.00, reads: 0.00, writes: 39848.03, response time: 3.93ms (95%), errors: 0.00, reconnects:  0.00
[  18s] threads: 64, tps: 0.00, reads: 0.00, writes: 41612.86, response time: 3.81ms (95%), errors: 0.00, reconnects:  0.00
[  19s] threads: 64, tps: 0.00, reads: 0.00, writes: 41976.12, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[  20s] threads: 64, tps: 0.00, reads: 0.00, writes: 44619.02, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[  21s] threads: 64, tps: 0.00, reads: 0.00, writes: 42451.98, response time: 4.17ms (95%), errors: 0.00, reconnects:  0.00
[  22s] threads: 64, tps: 0.00, reads: 0.00, writes: 39202.05, response time: 4.81ms (95%), errors: 0.00, reconnects:  0.00
[  23s] threads: 64, tps: 0.00, reads: 0.00, writes: 38182.99, response time: 5.11ms (95%), errors: 0.00, reconnects:  0.00
[  24s] threads: 64, tps: 0.00, reads: 0.00, writes: 38389.01, response time: 5.11ms (95%), errors: 0.00, reconnects:  0.00
[  25s] threads: 64, tps: 0.00, reads: 0.00, writes: 38337.99, response time: 5.38ms (95%), errors: 0.00, reconnects:  0.00
[  26s] threads: 64, tps: 0.00, reads: 0.00, writes: 41364.97, response time: 5.23ms (95%), errors: 0.00, reconnects:  0.00
[  27s] threads: 64, tps: 0.00, reads: 0.00, writes: 42606.00, response time: 4.21ms (95%), errors: 0.00, reconnects:  0.00
[  28s] threads: 64, tps: 0.00, reads: 0.00, writes: 40795.90, response time: 4.86ms (95%), errors: 0.00, reconnects:  0.00
[  29s] threads: 64, tps: 0.00, reads: 0.00, writes: 42158.06, response time: 4.35ms (95%), errors: 0.00, reconnects:  0.00
[  30s] threads: 64, tps: 0.00, reads: 0.00, writes: 50926.47, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[  31s] threads: 64, tps: 0.00, reads: 0.00, writes: 55846.76, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[  32s] threads: 64, tps: 0.00, reads: 0.00, writes: 63615.93, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[  33s] threads: 64, tps: 0.00, reads: 0.00, writes: 67273.68, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[  34s] threads: 64, tps: 0.00, reads: 0.00, writes: 68509.32, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[  35s] threads: 64, tps: 0.00, reads: 0.00, writes: 71719.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[  36s] threads: 64, tps: 0.00, reads: 0.00, writes: 72463.95, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[  37s] threads: 64, tps: 0.00, reads: 0.00, writes: 72214.02, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[  38s] threads: 64, tps: 0.00, reads: 0.00, writes: 71081.99, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[  39s] threads: 64, tps: 0.00, reads: 0.00, writes: 75673.04, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[  40s] threads: 64, tps: 0.00, reads: 0.00, writes: 79044.77, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[  41s] threads: 64, tps: 0.00, reads: 0.00, writes: 76779.17, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[  42s] threads: 64, tps: 0.00, reads: 0.00, writes: 82502.94, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[  43s] threads: 64, tps: 0.00, reads: 0.00, writes: 85902.88, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[  44s] threads: 64, tps: 0.00, reads: 0.00, writes: 87344.14, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[  45s] threads: 64, tps: 0.00, reads: 0.00, writes: 88345.13, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[  46s] threads: 64, tps: 0.00, reads: 0.00, writes: 92675.89, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[  47s] threads: 64, tps: 0.00, reads: 0.00, writes: 93545.94, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[  48s] threads: 64, tps: 0.00, reads: 0.00, writes: 93278.98, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[  49s] threads: 64, tps: 0.00, reads: 0.00, writes: 93026.06, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[  50s] threads: 64, tps: 0.00, reads: 0.00, writes: 93748.10, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[  51s] threads: 64, tps: 0.00, reads: 0.00, writes: 95380.06, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[  52s] threads: 64, tps: 0.00, reads: 0.00, writes: 95668.13, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[  53s] threads: 64, tps: 0.00, reads: 0.00, writes: 95554.82, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[  54s] threads: 64, tps: 0.00, reads: 0.00, writes: 97305.76, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[  55s] threads: 64, tps: 0.00, reads: 0.00, writes: 99190.70, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[  56s] threads: 64, tps: 0.00, reads: 0.00, writes: 88988.43, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[  57s] threads: 64, tps: 0.00, reads: 0.00, writes: 100076.93, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[  58s] threads: 64, tps: 0.00, reads: 0.00, writes: 100777.96, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[  59s] threads: 64, tps: 0.00, reads: 0.00, writes: 95421.42, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[  60s] threads: 64, tps: 0.00, reads: 0.00, writes: 103509.54, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[  61s] threads: 64, tps: 0.00, reads: 0.00, writes: 103201.45, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[  62s] threads: 64, tps: 0.00, reads: 0.00, writes: 103197.34, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[  63s] threads: 64, tps: 0.00, reads: 0.00, writes: 101304.49, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[  64s] threads: 64, tps: 0.00, reads: 0.00, writes: 95291.07, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[  65s] threads: 64, tps: 0.00, reads: 0.00, writes: 95518.11, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[  66s] threads: 64, tps: 0.00, reads: 0.00, writes: 89774.95, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[  67s] threads: 64, tps: 0.00, reads: 0.00, writes: 88698.52, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[  68s] threads: 64, tps: 0.00, reads: 0.00, writes: 93347.49, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[  69s] threads: 64, tps: 0.00, reads: 0.00, writes: 86909.09, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[  70s] threads: 64, tps: 0.00, reads: 0.00, writes: 93328.97, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[  71s] threads: 64, tps: 0.00, reads: 0.00, writes: 92150.90, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[  72s] threads: 64, tps: 0.00, reads: 0.00, writes: 91986.04, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[  73s] threads: 64, tps: 0.00, reads: 0.00, writes: 95373.08, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[  74s] threads: 64, tps: 0.00, reads: 0.00, writes: 90171.75, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[  75s] threads: 64, tps: 0.00, reads: 0.00, writes: 93014.23, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[  76s] threads: 64, tps: 0.00, reads: 0.00, writes: 92677.99, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[  77s] threads: 64, tps: 0.00, reads: 0.00, writes: 93018.33, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[  78s] threads: 64, tps: 0.00, reads: 0.00, writes: 90216.61, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[  79s] threads: 64, tps: 0.00, reads: 0.00, writes: 95478.11, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[  80s] threads: 64, tps: 0.00, reads: 0.00, writes: 94956.98, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[  81s] threads: 64, tps: 0.00, reads: 0.00, writes: 91068.85, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[  82s] threads: 64, tps: 0.00, reads: 0.00, writes: 91556.12, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[  83s] threads: 64, tps: 0.00, reads: 0.00, writes: 92116.65, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[  84s] threads: 64, tps: 0.00, reads: 0.00, writes: 96155.28, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[  85s] threads: 64, tps: 0.00, reads: 0.00, writes: 94450.12, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[  86s] threads: 64, tps: 0.00, reads: 0.00, writes: 88634.98, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[  87s] threads: 64, tps: 0.00, reads: 0.00, writes: 92431.94, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[  88s] threads: 64, tps: 0.00, reads: 0.00, writes: 95443.22, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[  89s] threads: 64, tps: 0.00, reads: 0.00, writes: 97303.97, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[  90s] threads: 64, tps: 0.00, reads: 0.00, writes: 93637.81, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[  91s] threads: 64, tps: 0.00, reads: 0.00, writes: 99021.70, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[  92s] threads: 64, tps: 0.00, reads: 0.00, writes: 93452.37, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[  93s] threads: 64, tps: 0.00, reads: 0.00, writes: 100937.83, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[  94s] threads: 64, tps: 0.00, reads: 0.00, writes: 98093.14, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[  95s] threads: 64, tps: 0.00, reads: 0.00, writes: 99160.98, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[  96s] threads: 64, tps: 0.00, reads: 0.00, writes: 100385.44, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[  97s] threads: 64, tps: 0.00, reads: 0.00, writes: 101204.63, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[  98s] threads: 64, tps: 0.00, reads: 0.00, writes: 100926.99, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[  99s] threads: 64, tps: 0.00, reads: 0.00, writes: 104454.11, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 100s] threads: 64, tps: 0.00, reads: 0.00, writes: 102225.96, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[ 101s] threads: 64, tps: 0.00, reads: 0.00, writes: 100638.84, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 102s] threads: 64, tps: 0.00, reads: 0.00, writes: 95486.12, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[ 103s] threads: 64, tps: 0.00, reads: 0.00, writes: 95638.89, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 104s] threads: 64, tps: 0.00, reads: 0.00, writes: 95695.54, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[ 105s] threads: 64, tps: 0.00, reads: 0.00, writes: 101128.49, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[ 106s] threads: 64, tps: 0.00, reads: 0.00, writes: 105956.13, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[ 107s] threads: 64, tps: 0.00, reads: 0.00, writes: 103150.94, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[ 108s] threads: 64, tps: 0.00, reads: 0.00, writes: 100870.99, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 109s] threads: 64, tps: 0.00, reads: 0.00, writes: 89502.08, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[ 110s] threads: 64, tps: 0.00, reads: 0.00, writes: 80929.51, response time: 3.65ms (95%), errors: 0.00, reconnects:  0.00
[ 111s] threads: 64, tps: 0.00, reads: 0.00, writes: 81107.57, response time: 3.65ms (95%), errors: 0.00, reconnects:  0.00
[ 112s] threads: 64, tps: 0.00, reads: 0.00, writes: 80360.87, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 113s] threads: 64, tps: 0.00, reads: 0.00, writes: 81854.99, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 114s] threads: 64, tps: 0.00, reads: 0.00, writes: 81449.99, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[ 115s] threads: 64, tps: 0.00, reads: 0.00, writes: 81501.02, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[ 116s] threads: 64, tps: 0.00, reads: 0.00, writes: 81335.06, response time: 3.65ms (95%), errors: 0.00, reconnects:  0.00
[ 117s] threads: 64, tps: 0.00, reads: 0.00, writes: 82537.03, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[ 118s] threads: 64, tps: 0.00, reads: 0.00, writes: 82363.04, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 119s] threads: 64, tps: 0.00, reads: 0.00, writes: 82265.78, response time: 3.65ms (95%), errors: 0.00, reconnects:  0.00
[ 120s] threads: 64, tps: 0.00, reads: 0.00, writes: 83149.20, response time: 3.58ms (95%), errors: 0.00, reconnects:  0.00
[ 121s] threads: 64, tps: 0.00, reads: 0.00, writes: 81529.98, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 122s] threads: 64, tps: 0.00, reads: 0.00, writes: 82304.72, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[ 123s] threads: 64, tps: 0.00, reads: 0.00, writes: 81652.76, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[ 124s] threads: 64, tps: 0.00, reads: 0.00, writes: 82058.43, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[ 125s] threads: 64, tps: 0.00, reads: 0.00, writes: 82217.01, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[ 126s] threads: 64, tps: 0.00, reads: 0.00, writes: 81973.93, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[ 127s] threads: 64, tps: 0.00, reads: 0.00, writes: 81468.09, response time: 3.66ms (95%), errors: 0.00, reconnects:  0.00
[ 128s] threads: 64, tps: 0.00, reads: 0.00, writes: 83021.27, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 129s] threads: 64, tps: 0.00, reads: 0.00, writes: 65472.32, response time: 3.69ms (95%), errors: 0.00, reconnects:  0.00
[ 130s] threads: 64, tps: 0.00, reads: 0.00, writes: 82100.12, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[ 131s] threads: 64, tps: 0.00, reads: 0.00, writes: 82042.95, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[ 132s] threads: 64, tps: 0.00, reads: 0.00, writes: 81969.89, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 133s] threads: 64, tps: 0.00, reads: 0.00, writes: 82913.10, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[ 134s] threads: 64, tps: 0.00, reads: 0.00, writes: 82854.06, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[ 135s] threads: 64, tps: 0.00, reads: 0.00, writes: 82447.85, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[ 136s] threads: 64, tps: 0.00, reads: 0.00, writes: 83295.02, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[ 137s] threads: 64, tps: 0.00, reads: 0.00, writes: 83049.15, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[ 138s] threads: 64, tps: 0.00, reads: 0.00, writes: 83597.89, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[ 139s] threads: 64, tps: 0.00, reads: 0.00, writes: 82650.32, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[ 140s] threads: 64, tps: 0.00, reads: 0.00, writes: 84917.94, response time: 3.52ms (95%), errors: 0.00, reconnects:  0.00
[ 141s] threads: 64, tps: 0.00, reads: 0.00, writes: 103812.88, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[ 142s] threads: 64, tps: 0.00, reads: 0.00, writes: 102708.04, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 143s] threads: 64, tps: 0.00, reads: 0.00, writes: 102801.85, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 144s] threads: 64, tps: 0.00, reads: 0.00, writes: 104939.22, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 145s] threads: 64, tps: 0.00, reads: 0.00, writes: 102899.76, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[ 146s] threads: 64, tps: 0.00, reads: 0.00, writes: 102678.10, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[ 147s] threads: 64, tps: 0.00, reads: 0.00, writes: 104832.97, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[ 148s] threads: 64, tps: 0.00, reads: 0.00, writes: 106306.66, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[ 149s] threads: 64, tps: 0.00, reads: 0.00, writes: 101743.39, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[ 150s] threads: 64, tps: 0.00, reads: 0.00, writes: 107471.12, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[ 151s] threads: 64, tps: 0.00, reads: 0.00, writes: 102847.13, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 152s] threads: 64, tps: 0.00, reads: 0.00, writes: 100374.97, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 153s] threads: 64, tps: 0.00, reads: 0.00, writes: 102501.26, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[ 154s] threads: 64, tps: 0.00, reads: 0.00, writes: 95566.28, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[ 155s] threads: 64, tps: 0.00, reads: 0.00, writes: 84403.09, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[ 156s] threads: 64, tps: 0.00, reads: 0.00, writes: 83240.90, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[ 157s] threads: 64, tps: 0.00, reads: 0.00, writes: 67835.09, response time: 4.44ms (95%), errors: 0.00, reconnects:  0.00
[ 158s] threads: 64, tps: 0.00, reads: 0.00, writes: 83322.97, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[ 159s] threads: 64, tps: 0.00, reads: 0.00, writes: 82812.88, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[ 160s] threads: 64, tps: 0.00, reads: 0.00, writes: 81564.14, response time: 3.50ms (95%), errors: 0.00, reconnects:  0.00
[ 161s] threads: 64, tps: 0.00, reads: 0.00, writes: 63259.60, response time: 5.01ms (95%), errors: 0.00, reconnects:  0.00
[ 162s] threads: 64, tps: 0.00, reads: 0.00, writes: 63544.63, response time: 4.85ms (95%), errors: 0.00, reconnects:  0.00
[ 163s] threads: 64, tps: 0.00, reads: 0.00, writes: 55935.36, response time: 5.66ms (95%), errors: 0.00, reconnects:  0.00
[ 164s] threads: 64, tps: 0.00, reads: 0.00, writes: 67755.21, response time: 4.59ms (95%), errors: 0.00, reconnects:  0.00
[ 165s] threads: 64, tps: 0.00, reads: 0.00, writes: 78418.26, response time: 3.84ms (95%), errors: 0.00, reconnects:  0.00
[ 166s] threads: 64, tps: 0.00, reads: 0.00, writes: 70711.91, response time: 4.14ms (95%), errors: 0.00, reconnects:  0.00
[ 167s] threads: 64, tps: 0.00, reads: 0.00, writes: 78404.97, response time: 3.85ms (95%), errors: 0.00, reconnects:  0.00
[ 168s] threads: 64, tps: 0.00, reads: 0.00, writes: 75149.11, response time: 3.96ms (95%), errors: 0.00, reconnects:  0.00
[ 169s] threads: 64, tps: 0.00, reads: 0.00, writes: 80114.89, response time: 3.77ms (95%), errors: 0.00, reconnects:  0.00
[ 170s] threads: 64, tps: 0.00, reads: 0.00, writes: 76978.95, response time: 3.90ms (95%), errors: 0.00, reconnects:  0.00
[ 171s] threads: 64, tps: 0.00, reads: 0.00, writes: 78090.04, response time: 3.89ms (95%), errors: 0.00, reconnects:  0.00
[ 172s] threads: 64, tps: 0.00, reads: 0.00, writes: 74587.60, response time: 3.89ms (95%), errors: 0.00, reconnects:  0.00
[ 173s] threads: 64, tps: 0.00, reads: 0.00, writes: 74159.41, response time: 3.98ms (95%), errors: 0.00, reconnects:  0.00
[ 174s] threads: 64, tps: 0.00, reads: 0.00, writes: 74542.00, response time: 4.16ms (95%), errors: 0.00, reconnects:  0.00
[ 175s] threads: 64, tps: 0.00, reads: 0.00, writes: 72863.05, response time: 4.02ms (95%), errors: 0.00, reconnects:  0.00
[ 176s] threads: 64, tps: 0.00, reads: 0.00, writes: 74018.00, response time: 4.01ms (95%), errors: 0.00, reconnects:  0.00
[ 177s] threads: 64, tps: 0.00, reads: 0.00, writes: 59521.03, response time: 5.27ms (95%), errors: 0.00, reconnects:  0.00
[ 178s] threads: 64, tps: 0.00, reads: 0.00, writes: 63535.90, response time: 4.88ms (95%), errors: 0.00, reconnects:  0.00
[ 179s] threads: 64, tps: 0.00, reads: 0.00, writes: 63492.00, response time: 5.00ms (95%), errors: 0.00, reconnects:  0.00
[ 179s] threads: 64, tps: 0.00, reads: 0.00, writes: 51614.91, response time: 7.04ms (95%), errors: 0.00, reconnects:  0.00
[ 181s] threads: 64, tps: 0.00, reads: 0.00, writes: 64430.80, response time: 4.70ms (95%), errors: 0.00, reconnects:  0.00
[ 182s] threads: 64, tps: 0.00, reads: 0.00, writes: 61687.01, response time: 4.87ms (95%), errors: 0.00, reconnects:  0.00
[ 183s] threads: 64, tps: 0.00, reads: 0.00, writes: 65509.94, response time: 4.69ms (95%), errors: 0.00, reconnects:  0.00
[ 184s] threads: 64, tps: 0.00, reads: 0.00, writes: 65834.05, response time: 4.65ms (95%), errors: 0.00, reconnects:  0.00
[ 185s] threads: 64, tps: 0.00, reads: 0.00, writes: 64435.94, response time: 4.92ms (95%), errors: 0.00, reconnects:  0.00
[ 186s] threads: 64, tps: 0.00, reads: 0.00, writes: 65889.90, response time: 4.79ms (95%), errors: 0.00, reconnects:  0.00
[ 187s] threads: 64, tps: 0.00, reads: 0.00, writes: 67742.10, response time: 4.71ms (95%), errors: 0.00, reconnects:  0.00
[ 188s] threads: 64, tps: 0.00, reads: 0.00, writes: 66320.95, response time: 4.62ms (95%), errors: 0.00, reconnects:  0.00
[ 189s] threads: 64, tps: 0.00, reads: 0.00, writes: 63852.10, response time: 5.26ms (95%), errors: 0.00, reconnects:  0.00
[ 190s] threads: 64, tps: 0.00, reads: 0.00, writes: 65291.98, response time: 4.74ms (95%), errors: 0.00, reconnects:  0.00
[ 191s] threads: 64, tps: 0.00, reads: 0.00, writes: 72768.85, response time: 4.02ms (95%), errors: 0.00, reconnects:  0.00
[ 192s] threads: 64, tps: 0.00, reads: 0.00, writes: 72237.09, response time: 4.20ms (95%), errors: 0.00, reconnects:  0.00
[ 193s] threads: 64, tps: 0.00, reads: 0.00, writes: 73121.20, response time: 4.15ms (95%), errors: 0.00, reconnects:  0.00
[ 194s] threads: 64, tps: 0.00, reads: 0.00, writes: 74177.89, response time: 3.97ms (95%), errors: 0.00, reconnects:  0.00
[ 195s] threads: 64, tps: 0.00, reads: 0.00, writes: 73523.91, response time: 4.08ms (95%), errors: 0.00, reconnects:  0.00
[ 196s] threads: 64, tps: 0.00, reads: 0.00, writes: 75602.08, response time: 4.08ms (95%), errors: 0.00, reconnects:  0.00
[ 197s] threads: 64, tps: 0.00, reads: 0.00, writes: 78426.90, response time: 3.87ms (95%), errors: 0.00, reconnects:  0.00
[ 198s] threads: 64, tps: 0.00, reads: 0.00, writes: 74918.11, response time: 4.01ms (95%), errors: 0.00, reconnects:  0.00
[ 199s] threads: 64, tps: 0.00, reads: 0.00, writes: 76877.99, response time: 3.88ms (95%), errors: 0.00, reconnects:  0.00
[ 200s] threads: 64, tps: 0.00, reads: 0.00, writes: 76013.99, response time: 3.98ms (95%), errors: 0.00, reconnects:  0.00
[ 201s] threads: 64, tps: 0.00, reads: 0.00, writes: 79342.03, response time: 3.98ms (95%), errors: 0.00, reconnects:  0.00
[ 202s] threads: 64, tps: 0.00, reads: 0.00, writes: 74170.93, response time: 3.97ms (95%), errors: 0.00, reconnects:  0.00
[ 203s] threads: 64, tps: 0.00, reads: 0.00, writes: 78405.95, response time: 3.85ms (95%), errors: 0.00, reconnects:  0.00
[ 204s] threads: 64, tps: 0.00, reads: 0.00, writes: 80334.06, response time: 3.80ms (95%), errors: 0.00, reconnects:  0.00
[ 205s] threads: 64, tps: 0.00, reads: 0.00, writes: 78476.06, response time: 3.86ms (95%), errors: 0.00, reconnects:  0.00
[ 206s] threads: 64, tps: 0.00, reads: 0.00, writes: 79669.96, response time: 3.85ms (95%), errors: 0.00, reconnects:  0.00
[ 207s] threads: 64, tps: 0.00, reads: 0.00, writes: 75980.02, response time: 4.12ms (95%), errors: 0.00, reconnects:  0.00
[ 208s] threads: 64, tps: 0.00, reads: 0.00, writes: 76052.08, response time: 4.09ms (95%), errors: 0.00, reconnects:  0.00
[ 209s] threads: 64, tps: 0.00, reads: 0.00, writes: 75260.90, response time: 3.91ms (95%), errors: 0.00, reconnects:  0.00
[ 210s] threads: 64, tps: 0.00, reads: 0.00, writes: 75158.82, response time: 4.15ms (95%), errors: 0.00, reconnects:  0.00
[ 211s] threads: 64, tps: 0.00, reads: 0.00, writes: 75414.25, response time: 4.04ms (95%), errors: 0.00, reconnects:  0.00
[ 212s] threads: 64, tps: 0.00, reads: 0.00, writes: 76928.99, response time: 4.00ms (95%), errors: 0.00, reconnects:  0.00
[ 213s] threads: 64, tps: 0.00, reads: 0.00, writes: 76669.96, response time: 3.97ms (95%), errors: 0.00, reconnects:  0.00
[ 214s] threads: 64, tps: 0.00, reads: 0.00, writes: 77677.01, response time: 4.00ms (95%), errors: 0.00, reconnects:  0.00
[ 215s] threads: 64, tps: 0.00, reads: 0.00, writes: 75011.07, response time: 4.13ms (95%), errors: 0.00, reconnects:  0.00
[ 216s] threads: 64, tps: 0.00, reads: 0.00, writes: 67454.82, response time: 4.38ms (95%), errors: 0.00, reconnects:  0.00
[ 217s] threads: 64, tps: 0.00, reads: 0.00, writes: 62275.09, response time: 4.96ms (95%), errors: 0.00, reconnects:  0.00
[ 218s] threads: 64, tps: 0.00, reads: 0.00, writes: 66901.04, response time: 4.84ms (95%), errors: 0.00, reconnects:  0.00
[ 219s] threads: 64, tps: 0.00, reads: 0.00, writes: 71380.93, response time: 4.45ms (95%), errors: 0.00, reconnects:  0.00
[ 220s] threads: 64, tps: 0.00, reads: 0.00, writes: 68935.02, response time: 4.50ms (95%), errors: 0.00, reconnects:  0.00
[ 221s] threads: 64, tps: 0.00, reads: 0.00, writes: 57656.03, response time: 5.45ms (95%), errors: 0.00, reconnects:  0.00
[ 222s] threads: 64, tps: 0.00, reads: 0.00, writes: 53959.93, response time: 5.87ms (95%), errors: 0.00, reconnects:  0.00
[ 223s] threads: 64, tps: 0.00, reads: 0.00, writes: 53195.71, response time: 6.16ms (95%), errors: 0.00, reconnects:  0.00
[ 224s] threads: 64, tps: 0.00, reads: 0.00, writes: 56477.37, response time: 5.75ms (95%), errors: 0.00, reconnects:  0.00
[ 225s] threads: 64, tps: 0.00, reads: 0.00, writes: 53664.77, response time: 6.00ms (95%), errors: 0.00, reconnects:  0.00
[ 226s] threads: 64, tps: 0.00, reads: 0.00, writes: 52888.91, response time: 5.95ms (95%), errors: 0.00, reconnects:  0.00
[ 227s] threads: 64, tps: 0.00, reads: 0.00, writes: 51610.24, response time: 6.13ms (95%), errors: 0.00, reconnects:  0.00
[ 228s] threads: 64, tps: 0.00, reads: 0.00, writes: 55237.97, response time: 6.09ms (95%), errors: 0.00, reconnects:  0.00
[ 229s] threads: 64, tps: 0.00, reads: 0.00, writes: 50545.13, response time: 6.53ms (95%), errors: 0.00, reconnects:  0.00
[ 230s] threads: 64, tps: 0.00, reads: 0.00, writes: 58110.83, response time: 5.67ms (95%), errors: 0.00, reconnects:  0.00
[ 231s] threads: 64, tps: 0.00, reads: 0.00, writes: 50679.70, response time: 6.66ms (95%), errors: 0.00, reconnects:  0.00
[ 232s] threads: 64, tps: 0.00, reads: 0.00, writes: 49720.82, response time: 6.62ms (95%), errors: 0.00, reconnects:  0.00
[ 233s] threads: 64, tps: 0.00, reads: 0.00, writes: 54847.55, response time: 5.77ms (95%), errors: 0.00, reconnects:  0.00
[ 234s] threads: 64, tps: 0.00, reads: 0.00, writes: 50799.88, response time: 6.64ms (95%), errors: 0.00, reconnects:  0.00
[ 235s] threads: 64, tps: 0.00, reads: 0.00, writes: 51997.05, response time: 6.30ms (95%), errors: 0.00, reconnects:  0.00
[ 236s] threads: 64, tps: 0.00, reads: 0.00, writes: 50445.00, response time: 6.32ms (95%), errors: 0.00, reconnects:  0.00
[ 237s] threads: 64, tps: 0.00, reads: 0.00, writes: 54590.87, response time: 6.08ms (95%), errors: 0.00, reconnects:  0.00
[ 238s] threads: 64, tps: 0.00, reads: 0.00, writes: 53131.19, response time: 5.71ms (95%), errors: 0.00, reconnects:  0.00
[ 239s] threads: 64, tps: 0.00, reads: 0.00, writes: 51749.91, response time: 6.32ms (95%), errors: 0.00, reconnects:  0.00
[ 240s] threads: 64, tps: 0.00, reads: 0.00, writes: 49258.04, response time: 6.63ms (95%), errors: 0.00, reconnects:  0.00
[ 241s] threads: 64, tps: 0.00, reads: 0.00, writes: 50078.94, response time: 6.31ms (95%), errors: 0.00, reconnects:  0.00
[ 242s] threads: 64, tps: 0.00, reads: 0.00, writes: 53856.09, response time: 5.93ms (95%), errors: 0.00, reconnects:  0.00
[ 243s] threads: 64, tps: 0.00, reads: 0.00, writes: 52970.98, response time: 6.08ms (95%), errors: 0.00, reconnects:  0.00
[ 244s] threads: 64, tps: 0.00, reads: 0.00, writes: 51280.97, response time: 6.28ms (95%), errors: 0.00, reconnects:  0.00
[ 245s] threads: 64, tps: 0.00, reads: 0.00, writes: 53975.01, response time: 6.01ms (95%), errors: 0.00, reconnects:  0.00
[ 246s] threads: 64, tps: 0.00, reads: 0.00, writes: 56375.96, response time: 5.83ms (95%), errors: 0.00, reconnects:  0.00
[ 247s] threads: 64, tps: 0.00, reads: 0.00, writes: 52039.08, response time: 6.09ms (95%), errors: 0.00, reconnects:  0.00
[ 248s] threads: 64, tps: 0.00, reads: 0.00, writes: 55707.03, response time: 5.76ms (95%), errors: 0.00, reconnects:  0.00
[ 249s] threads: 64, tps: 0.00, reads: 0.00, writes: 54776.96, response time: 5.77ms (95%), errors: 0.00, reconnects:  0.00
[ 250s] threads: 64, tps: 0.00, reads: 0.00, writes: 54363.95, response time: 5.88ms (95%), errors: 0.00, reconnects:  0.00
[ 251s] threads: 64, tps: 0.00, reads: 0.00, writes: 53099.09, response time: 6.01ms (95%), errors: 0.00, reconnects:  0.00
[ 252s] threads: 64, tps: 0.00, reads: 0.00, writes: 49360.94, response time: 6.98ms (95%), errors: 0.00, reconnects:  0.00
[ 253s] threads: 64, tps: 0.00, reads: 0.00, writes: 62315.76, response time: 5.35ms (95%), errors: 0.00, reconnects:  0.00
[ 254s] threads: 64, tps: 0.00, reads: 0.00, writes: 69857.40, response time: 4.40ms (95%), errors: 0.00, reconnects:  0.00
[ 255s] threads: 64, tps: 0.00, reads: 0.00, writes: 59592.99, response time: 5.42ms (95%), errors: 0.00, reconnects:  0.00
[ 256s] threads: 64, tps: 0.00, reads: 0.00, writes: 57598.96, response time: 5.73ms (95%), errors: 0.00, reconnects:  0.00
[ 257s] threads: 64, tps: 0.00, reads: 0.00, writes: 57710.01, response time: 5.63ms (95%), errors: 0.00, reconnects:  0.00
[ 258s] threads: 64, tps: 0.00, reads: 0.00, writes: 54223.95, response time: 6.08ms (95%), errors: 0.00, reconnects:  0.00
[ 259s] threads: 64, tps: 0.00, reads: 0.00, writes: 56169.04, response time: 5.82ms (95%), errors: 0.00, reconnects:  0.00
[ 260s] threads: 64, tps: 0.00, reads: 0.00, writes: 52172.02, response time: 6.03ms (95%), errors: 0.00, reconnects:  0.00
[ 261s] threads: 64, tps: 0.00, reads: 0.00, writes: 54986.95, response time: 5.93ms (95%), errors: 0.00, reconnects:  0.00
[ 262s] threads: 64, tps: 0.00, reads: 0.00, writes: 59637.05, response time: 5.41ms (95%), errors: 0.00, reconnects:  0.00
[ 263s] threads: 64, tps: 0.00, reads: 0.00, writes: 53937.02, response time: 5.73ms (95%), errors: 0.00, reconnects:  0.00
[ 264s] threads: 64, tps: 0.00, reads: 0.00, writes: 55358.99, response time: 6.03ms (95%), errors: 0.00, reconnects:  0.00
[ 265s] threads: 64, tps: 0.00, reads: 0.00, writes: 47729.75, response time: 7.11ms (95%), errors: 0.00, reconnects:  0.00
[ 266s] threads: 64, tps: 0.00, reads: 0.00, writes: 54045.30, response time: 6.22ms (95%), errors: 0.00, reconnects:  0.00
[ 267s] threads: 64, tps: 0.00, reads: 0.00, writes: 51766.95, response time: 6.82ms (95%), errors: 0.00, reconnects:  0.00
[ 268s] threads: 64, tps: 0.00, reads: 0.00, writes: 56592.98, response time: 5.99ms (95%), errors: 0.00, reconnects:  0.00
[ 269s] threads: 64, tps: 0.00, reads: 0.00, writes: 56750.62, response time: 5.96ms (95%), errors: 0.00, reconnects:  0.00
[ 270s] threads: 64, tps: 0.00, reads: 0.00, writes: 55277.39, response time: 6.25ms (95%), errors: 0.00, reconnects:  0.00
[ 271s] threads: 64, tps: 0.00, reads: 0.00, writes: 61273.06, response time: 5.36ms (95%), errors: 0.00, reconnects:  0.00
[ 272s] threads: 64, tps: 0.00, reads: 0.00, writes: 69865.88, response time: 4.32ms (95%), errors: 0.00, reconnects:  0.00
[ 273s] threads: 64, tps: 0.00, reads: 0.00, writes: 67412.49, response time: 4.80ms (95%), errors: 0.00, reconnects:  0.00
[ 274s] threads: 64, tps: 0.00, reads: 0.00, writes: 75335.67, response time: 3.94ms (95%), errors: 0.00, reconnects:  0.00
[ 275s] threads: 64, tps: 0.00, reads: 0.00, writes: 88621.80, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[ 276s] threads: 64, tps: 0.00, reads: 0.00, writes: 87436.13, response time: 3.37ms (95%), errors: 0.00, reconnects:  0.00
[ 277s] threads: 64, tps: 0.00, reads: 0.00, writes: 93063.08, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 278s] threads: 64, tps: 0.00, reads: 0.00, writes: 88463.98, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[ 279s] threads: 64, tps: 0.00, reads: 0.00, writes: 83887.05, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[ 280s] threads: 64, tps: 0.00, reads: 0.00, writes: 98267.63, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 281s] threads: 64, tps: 0.00, reads: 0.00, writes: 96571.26, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 282s] threads: 64, tps: 0.00, reads: 0.00, writes: 97099.06, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 283s] threads: 64, tps: 0.00, reads: 0.00, writes: 93652.21, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 284s] threads: 64, tps: 0.00, reads: 0.00, writes: 94388.81, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[ 285s] threads: 64, tps: 0.00, reads: 0.00, writes: 80743.82, response time: 3.75ms (95%), errors: 0.00, reconnects:  0.00
[ 286s] threads: 64, tps: 0.00, reads: 0.00, writes: 84672.13, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[ 287s] threads: 64, tps: 0.00, reads: 0.00, writes: 83621.07, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[ 288s] threads: 64, tps: 0.00, reads: 0.00, writes: 87997.94, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[ 289s] threads: 64, tps: 0.00, reads: 0.00, writes: 91177.93, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 290s] threads: 64, tps: 0.00, reads: 0.00, writes: 99008.93, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 291s] threads: 64, tps: 0.00, reads: 0.00, writes: 95005.03, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 292s] threads: 64, tps: 0.00, reads: 0.00, writes: 101207.11, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 293s] threads: 64, tps: 0.00, reads: 0.00, writes: 95919.01, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 294s] threads: 64, tps: 0.00, reads: 0.00, writes: 91367.00, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 295s] threads: 64, tps: 0.00, reads: 0.00, writes: 101725.75, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 296s] threads: 64, tps: 0.00, reads: 0.00, writes: 100322.27, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 297s] threads: 64, tps: 0.00, reads: 0.00, writes: 100184.80, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 298s] threads: 64, tps: 0.00, reads: 0.00, writes: 102504.23, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 299s] threads: 64, tps: 0.00, reads: 0.00, writes: 103074.50, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 300s] threads: 64, tps: 0.00, reads: 0.00, writes: 100334.40, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 301s] threads: 64, tps: 0.00, reads: 0.00, writes: 96956.05, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 302s] threads: 64, tps: 0.00, reads: 0.00, writes: 96548.02, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 303s] threads: 64, tps: 0.00, reads: 0.00, writes: 98819.09, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 304s] threads: 64, tps: 0.00, reads: 0.00, writes: 101653.87, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 305s] threads: 64, tps: 0.00, reads: 0.00, writes: 101448.01, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 306s] threads: 64, tps: 0.00, reads: 0.00, writes: 103881.11, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 307s] threads: 64, tps: 0.00, reads: 0.00, writes: 104092.96, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[ 308s] threads: 64, tps: 0.00, reads: 0.00, writes: 106325.02, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[ 309s] threads: 64, tps: 0.00, reads: 0.00, writes: 102910.92, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 310s] threads: 64, tps: 0.00, reads: 0.00, writes: 103115.01, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 311s] threads: 64, tps: 0.00, reads: 0.00, writes: 103542.99, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 312s] threads: 64, tps: 0.00, reads: 0.00, writes: 103157.11, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 313s] threads: 64, tps: 0.00, reads: 0.00, writes: 103037.13, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 314s] threads: 64, tps: 0.00, reads: 0.00, writes: 104174.69, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 315s] threads: 64, tps: 0.00, reads: 0.00, writes: 102281.46, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 316s] threads: 64, tps: 0.00, reads: 0.00, writes: 106432.78, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 317s] threads: 64, tps: 0.00, reads: 0.00, writes: 100002.07, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 318s] threads: 64, tps: 0.00, reads: 0.00, writes: 102018.88, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 319s] threads: 64, tps: 0.00, reads: 0.00, writes: 102493.04, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 320s] threads: 64, tps: 0.00, reads: 0.00, writes: 103092.97, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 321s] threads: 64, tps: 0.00, reads: 0.00, writes: 98098.05, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 322s] threads: 64, tps: 0.00, reads: 0.00, writes: 101433.11, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 323s] threads: 64, tps: 0.00, reads: 0.00, writes: 105844.31, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 324s] threads: 64, tps: 0.00, reads: 0.00, writes: 104039.06, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 325s] threads: 64, tps: 0.00, reads: 0.00, writes: 106078.45, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[ 326s] threads: 64, tps: 0.00, reads: 0.00, writes: 104266.98, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 327s] threads: 64, tps: 0.00, reads: 0.00, writes: 104448.11, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 328s] threads: 64, tps: 0.00, reads: 0.00, writes: 103876.77, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 329s] threads: 64, tps: 0.00, reads: 0.00, writes: 105468.24, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 330s] threads: 64, tps: 0.00, reads: 0.00, writes: 104880.52, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 331s] threads: 64, tps: 0.00, reads: 0.00, writes: 104539.53, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[ 332s] threads: 64, tps: 0.00, reads: 0.00, writes: 103143.71, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 333s] threads: 64, tps: 0.00, reads: 0.00, writes: 102308.28, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 334s] threads: 64, tps: 0.00, reads: 0.00, writes: 105023.86, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[ 335s] threads: 64, tps: 0.00, reads: 0.00, writes: 103951.98, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 336s] threads: 64, tps: 0.00, reads: 0.00, writes: 104481.14, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 337s] threads: 64, tps: 0.00, reads: 0.00, writes: 102954.88, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 338s] threads: 64, tps: 0.00, reads: 0.00, writes: 102387.70, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 339s] threads: 64, tps: 0.00, reads: 0.00, writes: 102967.30, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 340s] threads: 64, tps: 0.00, reads: 0.00, writes: 101547.07, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 341s] threads: 64, tps: 0.00, reads: 0.00, writes: 106702.97, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 342s] threads: 64, tps: 0.00, reads: 0.00, writes: 106506.05, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 343s] threads: 64, tps: 0.00, reads: 0.00, writes: 107646.95, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[ 344s] threads: 64, tps: 0.00, reads: 0.00, writes: 103992.23, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 345s] threads: 64, tps: 0.00, reads: 0.00, writes: 106504.87, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 346s] threads: 64, tps: 0.00, reads: 0.00, writes: 104834.04, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[ 347s] threads: 64, tps: 0.00, reads: 0.00, writes: 105569.79, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 348s] threads: 64, tps: 0.00, reads: 0.00, writes: 104237.12, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 349s] threads: 64, tps: 0.00, reads: 0.00, writes: 104965.87, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 350s] threads: 64, tps: 0.00, reads: 0.00, writes: 105650.21, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 351s] threads: 64, tps: 0.00, reads: 0.00, writes: 102570.87, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 352s] threads: 64, tps: 0.00, reads: 0.00, writes: 103001.99, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 353s] threads: 64, tps: 0.00, reads: 0.00, writes: 103411.13, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 354s] threads: 64, tps: 0.00, reads: 0.00, writes: 102921.88, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 355s] threads: 64, tps: 0.00, reads: 0.00, writes: 105327.99, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 356s] threads: 64, tps: 0.00, reads: 0.00, writes: 105229.98, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 357s] threads: 64, tps: 0.00, reads: 0.00, writes: 102461.04, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 358s] threads: 64, tps: 0.00, reads: 0.00, writes: 103913.20, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 359s] threads: 64, tps: 0.00, reads: 0.00, writes: 103935.84, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 360s] threads: 64, tps: 0.00, reads: 0.00, writes: 105593.91, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 361s] threads: 64, tps: 0.00, reads: 0.00, writes: 101024.18, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 362s] threads: 64, tps: 0.00, reads: 0.00, writes: 102196.33, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 363s] threads: 64, tps: 0.00, reads: 0.00, writes: 104820.43, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 364s] threads: 64, tps: 0.00, reads: 0.00, writes: 104994.97, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 365s] threads: 64, tps: 0.00, reads: 0.00, writes: 103195.20, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 366s] threads: 64, tps: 0.00, reads: 0.00, writes: 103416.03, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 367s] threads: 64, tps: 0.00, reads: 0.00, writes: 100034.01, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 368s] threads: 64, tps: 0.00, reads: 0.00, writes: 103743.96, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 369s] threads: 64, tps: 0.00, reads: 0.00, writes: 102653.89, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[ 370s] threads: 64, tps: 0.00, reads: 0.00, writes: 100115.11, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 371s] threads: 64, tps: 0.00, reads: 0.00, writes: 103010.00, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 372s] threads: 64, tps: 0.00, reads: 0.00, writes: 103958.01, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 373s] threads: 64, tps: 0.00, reads: 0.00, writes: 103224.47, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 374s] threads: 64, tps: 0.00, reads: 0.00, writes: 101843.46, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 375s] threads: 64, tps: 0.00, reads: 0.00, writes: 101652.96, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 376s] threads: 64, tps: 0.00, reads: 0.00, writes: 104325.97, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 377s] threads: 64, tps: 0.00, reads: 0.00, writes: 101278.22, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 378s] threads: 64, tps: 0.00, reads: 0.00, writes: 100120.52, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 379s] threads: 64, tps: 0.00, reads: 0.00, writes: 99052.98, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 380s] threads: 64, tps: 0.00, reads: 0.00, writes: 95880.40, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[ 381s] threads: 64, tps: 0.00, reads: 0.00, writes: 92461.90, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[ 382s] threads: 64, tps: 0.00, reads: 0.00, writes: 96055.08, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[ 383s] threads: 64, tps: 0.00, reads: 0.00, writes: 90883.83, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 384s] threads: 64, tps: 0.00, reads: 0.00, writes: 103183.22, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 385s] threads: 64, tps: 0.00, reads: 0.00, writes: 100160.01, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 386s] threads: 64, tps: 0.00, reads: 0.00, writes: 103421.95, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 387s] threads: 64, tps: 0.00, reads: 0.00, writes: 100110.99, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 388s] threads: 64, tps: 0.00, reads: 0.00, writes: 101054.97, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 389s] threads: 64, tps: 0.00, reads: 0.00, writes: 101315.57, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 390s] threads: 64, tps: 0.00, reads: 0.00, writes: 101160.59, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 391s] threads: 64, tps: 0.00, reads: 0.00, writes: 100233.90, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 392s] threads: 64, tps: 0.00, reads: 0.00, writes: 99081.97, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 393s] threads: 64, tps: 0.00, reads: 0.00, writes: 100033.34, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 394s] threads: 64, tps: 0.00, reads: 0.00, writes: 100587.61, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 395s] threads: 64, tps: 0.00, reads: 0.00, writes: 99359.07, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 396s] threads: 64, tps: 0.00, reads: 0.00, writes: 99273.97, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 397s] threads: 64, tps: 0.00, reads: 0.00, writes: 100528.95, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 398s] threads: 64, tps: 0.00, reads: 0.00, writes: 97119.01, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 399s] threads: 64, tps: 0.00, reads: 0.00, writes: 100695.07, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 400s] threads: 64, tps: 0.00, reads: 0.00, writes: 98475.63, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 401s] threads: 64, tps: 0.00, reads: 0.00, writes: 94383.35, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[ 402s] threads: 64, tps: 0.00, reads: 0.00, writes: 100521.96, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 403s] threads: 64, tps: 0.00, reads: 0.00, writes: 99378.07, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 404s] threads: 64, tps: 0.00, reads: 0.00, writes: 101116.94, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 405s] threads: 64, tps: 0.00, reads: 0.00, writes: 98969.00, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 406s] threads: 64, tps: 0.00, reads: 0.00, writes: 99518.11, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 407s] threads: 64, tps: 0.00, reads: 0.00, writes: 103739.77, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 407s] threads: 64, tps: 0.00, reads: 0.00, writes: 95844.11, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 409s] threads: 64, tps: 0.00, reads: 0.00, writes: 102216.22, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 410s] threads: 64, tps: 0.00, reads: 0.00, writes: 97644.88, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 411s] threads: 64, tps: 0.00, reads: 0.00, writes: 100167.05, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 412s] threads: 64, tps: 0.00, reads: 0.00, writes: 100540.88, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 413s] threads: 64, tps: 0.00, reads: 0.00, writes: 100713.15, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 414s] threads: 64, tps: 0.00, reads: 0.00, writes: 101695.90, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 415s] threads: 64, tps: 0.00, reads: 0.00, writes: 100244.09, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 416s] threads: 64, tps: 0.00, reads: 0.00, writes: 100901.97, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 417s] threads: 64, tps: 0.00, reads: 0.00, writes: 100553.05, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 418s] threads: 64, tps: 0.00, reads: 0.00, writes: 99133.92, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 419s] threads: 64, tps: 0.00, reads: 0.00, writes: 96654.98, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 420s] threads: 64, tps: 0.00, reads: 0.00, writes: 100405.11, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 421s] threads: 64, tps: 0.00, reads: 0.00, writes: 95706.11, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 422s] threads: 64, tps: 0.00, reads: 0.00, writes: 100333.37, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 423s] threads: 64, tps: 0.00, reads: 0.00, writes: 99819.62, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 424s] threads: 64, tps: 0.00, reads: 0.00, writes: 99133.73, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 425s] threads: 64, tps: 0.00, reads: 0.00, writes: 102953.11, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 426s] threads: 64, tps: 0.00, reads: 0.00, writes: 101833.03, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 427s] threads: 64, tps: 0.00, reads: 0.00, writes: 98326.55, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 428s] threads: 64, tps: 0.00, reads: 0.00, writes: 98627.44, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 429s] threads: 64, tps: 0.00, reads: 0.00, writes: 101084.02, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 430s] threads: 64, tps: 0.00, reads: 0.00, writes: 98316.09, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 431s] threads: 64, tps: 0.00, reads: 0.00, writes: 99898.90, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 432s] threads: 64, tps: 0.00, reads: 0.00, writes: 98164.92, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 433s] threads: 64, tps: 0.00, reads: 0.00, writes: 98772.05, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 434s] threads: 64, tps: 0.00, reads: 0.00, writes: 102990.02, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 435s] threads: 64, tps: 0.00, reads: 0.00, writes: 102083.88, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 436s] threads: 64, tps: 0.00, reads: 0.00, writes: 101673.10, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 437s] threads: 64, tps: 0.00, reads: 0.00, writes: 102721.94, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 438s] threads: 64, tps: 0.00, reads: 0.00, writes: 101277.96, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 439s] threads: 64, tps: 0.00, reads: 0.00, writes: 100478.05, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 440s] threads: 64, tps: 0.00, reads: 0.00, writes: 98363.72, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[ 441s] threads: 64, tps: 0.00, reads: 0.00, writes: 101047.26, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 442s] threads: 64, tps: 0.00, reads: 0.00, writes: 99823.03, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 443s] threads: 64, tps: 0.00, reads: 0.00, writes: 100681.03, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 444s] threads: 64, tps: 0.00, reads: 0.00, writes: 100403.94, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[ 445s] threads: 64, tps: 0.00, reads: 0.00, writes: 96132.01, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[ 446s] threads: 64, tps: 0.00, reads: 0.00, writes: 98446.01, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 447s] threads: 64, tps: 0.00, reads: 0.00, writes: 100216.05, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 448s] threads: 64, tps: 0.00, reads: 0.00, writes: 96957.94, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[ 449s] threads: 64, tps: 0.00, reads: 0.00, writes: 97483.70, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[ 450s] threads: 64, tps: 0.00, reads: 0.00, writes: 98154.45, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 451s] threads: 64, tps: 0.00, reads: 0.00, writes: 98731.90, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[ 452s] threads: 64, tps: 0.00, reads: 0.00, writes: 100752.00, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 453s] threads: 64, tps: 0.00, reads: 0.00, writes: 100316.96, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 454s] threads: 64, tps: 0.00, reads: 0.00, writes: 100509.04, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 455s] threads: 64, tps: 0.00, reads: 0.00, writes: 99603.46, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 456s] threads: 64, tps: 0.00, reads: 0.00, writes: 101105.63, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 457s] threads: 64, tps: 0.00, reads: 0.00, writes: 99438.99, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 458s] threads: 64, tps: 0.00, reads: 0.00, writes: 98756.87, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 459s] threads: 64, tps: 0.00, reads: 0.00, writes: 97126.01, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[ 460s] threads: 64, tps: 0.00, reads: 0.00, writes: 98990.98, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 461s] threads: 64, tps: 0.00, reads: 0.00, writes: 100763.57, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 462s] threads: 64, tps: 0.00, reads: 0.00, writes: 100553.12, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 463s] threads: 64, tps: 0.00, reads: 0.00, writes: 100815.31, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 464s] threads: 64, tps: 0.00, reads: 0.00, writes: 103431.57, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 465s] threads: 64, tps: 0.00, reads: 0.00, writes: 102416.42, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 466s] threads: 64, tps: 0.00, reads: 0.00, writes: 98608.58, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[ 467s] threads: 64, tps: 0.00, reads: 0.00, writes: 100497.42, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 468s] threads: 64, tps: 0.00, reads: 0.00, writes: 102767.03, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 469s] threads: 64, tps: 0.00, reads: 0.00, writes: 102711.92, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 470s] threads: 64, tps: 0.00, reads: 0.00, writes: 102373.97, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 471s] threads: 64, tps: 0.00, reads: 0.00, writes: 104661.08, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 472s] threads: 64, tps: 0.00, reads: 0.00, writes: 104722.99, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 473s] threads: 64, tps: 0.00, reads: 0.00, writes: 104351.06, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 474s] threads: 64, tps: 0.00, reads: 0.00, writes: 104462.05, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 475s] threads: 64, tps: 0.00, reads: 0.00, writes: 99980.90, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[ 476s] threads: 64, tps: 0.00, reads: 0.00, writes: 102450.96, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 477s] threads: 64, tps: 0.00, reads: 0.00, writes: 102879.06, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 478s] threads: 64, tps: 0.00, reads: 0.00, writes: 102231.27, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 479s] threads: 64, tps: 0.00, reads: 0.00, writes: 101467.66, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 480s] threads: 64, tps: 0.00, reads: 0.00, writes: 104230.02, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 481s] threads: 64, tps: 0.00, reads: 0.00, writes: 102435.00, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 482s] threads: 64, tps: 0.00, reads: 0.00, writes: 102149.42, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 483s] threads: 64, tps: 0.00, reads: 0.00, writes: 102007.50, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 484s] threads: 64, tps: 0.00, reads: 0.00, writes: 103769.95, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 485s] threads: 64, tps: 0.00, reads: 0.00, writes: 96477.08, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[ 486s] threads: 64, tps: 0.00, reads: 0.00, writes: 101788.41, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 487s] threads: 64, tps: 0.00, reads: 0.00, writes: 106730.54, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 488s] threads: 64, tps: 0.00, reads: 0.00, writes: 107685.24, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 489s] threads: 64, tps: 0.00, reads: 0.00, writes: 108694.54, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 490s] threads: 64, tps: 0.00, reads: 0.00, writes: 109414.30, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 491s] threads: 64, tps: 0.00, reads: 0.00, writes: 107362.06, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 492s] threads: 64, tps: 0.00, reads: 0.00, writes: 108335.03, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 493s] threads: 64, tps: 0.00, reads: 0.00, writes: 109089.91, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 494s] threads: 64, tps: 0.00, reads: 0.00, writes: 109187.99, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 495s] threads: 64, tps: 0.00, reads: 0.00, writes: 107287.84, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 496s] threads: 64, tps: 0.00, reads: 0.00, writes: 105164.16, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 497s] threads: 64, tps: 0.00, reads: 0.00, writes: 107906.51, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 498s] threads: 64, tps: 0.00, reads: 0.00, writes: 108153.21, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 499s] threads: 64, tps: 0.00, reads: 0.00, writes: 109264.47, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 500s] threads: 64, tps: 0.00, reads: 0.00, writes: 108484.86, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 501s] threads: 64, tps: 0.00, reads: 0.00, writes: 104661.07, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 502s] threads: 64, tps: 0.00, reads: 0.00, writes: 105907.91, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[ 503s] threads: 64, tps: 0.00, reads: 0.00, writes: 108702.05, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 504s] threads: 64, tps: 0.00, reads: 0.00, writes: 106185.02, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 505s] threads: 64, tps: 0.00, reads: 0.00, writes: 101891.84, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 506s] threads: 64, tps: 0.00, reads: 0.00, writes: 105663.04, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 507s] threads: 64, tps: 0.00, reads: 0.00, writes: 105359.89, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 508s] threads: 64, tps: 0.00, reads: 0.00, writes: 107275.17, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 509s] threads: 64, tps: 0.00, reads: 0.00, writes: 109562.14, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 510s] threads: 64, tps: 0.00, reads: 0.00, writes: 107340.73, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[ 511s] threads: 64, tps: 0.00, reads: 0.00, writes: 103284.14, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 512s] threads: 64, tps: 0.00, reads: 0.00, writes: 107240.00, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 513s] threads: 64, tps: 0.00, reads: 0.00, writes: 103176.04, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 514s] threads: 64, tps: 0.00, reads: 0.00, writes: 106034.88, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 515s] threads: 64, tps: 0.00, reads: 0.00, writes: 106509.65, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 516s] threads: 64, tps: 0.00, reads: 0.00, writes: 103174.41, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 517s] threads: 64, tps: 0.00, reads: 0.00, writes: 107513.95, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 518s] threads: 64, tps: 0.00, reads: 0.00, writes: 107449.98, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 519s] threads: 64, tps: 0.00, reads: 0.00, writes: 107646.04, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 520s] threads: 64, tps: 0.00, reads: 0.00, writes: 107124.99, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 521s] threads: 64, tps: 0.00, reads: 0.00, writes: 107989.03, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 522s] threads: 64, tps: 0.00, reads: 0.00, writes: 105238.13, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 523s] threads: 64, tps: 0.00, reads: 0.00, writes: 105681.71, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 524s] threads: 64, tps: 0.00, reads: 0.00, writes: 100351.19, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 525s] threads: 64, tps: 0.00, reads: 0.00, writes: 106013.94, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 526s] threads: 64, tps: 0.00, reads: 0.00, writes: 107020.01, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 527s] threads: 64, tps: 0.00, reads: 0.00, writes: 106537.38, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 528s] threads: 64, tps: 0.00, reads: 0.00, writes: 105947.13, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 529s] threads: 64, tps: 0.00, reads: 0.00, writes: 106282.47, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 530s] threads: 64, tps: 0.00, reads: 0.00, writes: 108627.19, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 531s] threads: 64, tps: 0.00, reads: 0.00, writes: 105338.95, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 532s] threads: 64, tps: 0.00, reads: 0.00, writes: 106351.12, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 533s] threads: 64, tps: 0.00, reads: 0.00, writes: 107517.89, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 534s] threads: 64, tps: 0.00, reads: 0.00, writes: 106512.56, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 535s] threads: 64, tps: 0.00, reads: 0.00, writes: 109096.51, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 536s] threads: 64, tps: 0.00, reads: 0.00, writes: 105355.83, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 537s] threads: 64, tps: 0.00, reads: 0.00, writes: 105397.92, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 538s] threads: 64, tps: 0.00, reads: 0.00, writes: 104904.10, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 539s] threads: 64, tps: 0.00, reads: 0.00, writes: 109257.97, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 540s] threads: 64, tps: 0.00, reads: 0.00, writes: 107051.04, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 541s] threads: 64, tps: 0.00, reads: 0.00, writes: 106147.09, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 542s] threads: 64, tps: 0.00, reads: 0.00, writes: 108448.72, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 543s] threads: 64, tps: 0.00, reads: 0.00, writes: 105545.15, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 544s] threads: 64, tps: 0.00, reads: 0.00, writes: 107516.99, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 545s] threads: 64, tps: 0.00, reads: 0.00, writes: 106079.87, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 546s] threads: 64, tps: 0.00, reads: 0.00, writes: 107283.67, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 547s] threads: 64, tps: 0.00, reads: 0.00, writes: 109343.47, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 548s] threads: 64, tps: 0.00, reads: 0.00, writes: 108799.08, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 549s] threads: 64, tps: 0.00, reads: 0.00, writes: 107431.95, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 550s] threads: 64, tps: 0.00, reads: 0.00, writes: 109400.14, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 551s] threads: 64, tps: 0.00, reads: 0.00, writes: 107268.75, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 552s] threads: 64, tps: 0.00, reads: 0.00, writes: 108324.22, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 553s] threads: 64, tps: 0.00, reads: 0.00, writes: 110379.85, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 554s] threads: 64, tps: 0.00, reads: 0.00, writes: 110254.00, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 555s] threads: 64, tps: 0.00, reads: 0.00, writes: 106170.63, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 556s] threads: 64, tps: 0.00, reads: 0.00, writes: 108658.48, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 557s] threads: 64, tps: 0.00, reads: 0.00, writes: 105600.81, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 558s] threads: 64, tps: 0.00, reads: 0.00, writes: 107351.21, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 559s] threads: 64, tps: 0.00, reads: 0.00, writes: 108834.63, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 560s] threads: 64, tps: 0.00, reads: 0.00, writes: 107749.16, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 561s] threads: 64, tps: 0.00, reads: 0.00, writes: 106361.02, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 562s] threads: 64, tps: 0.00, reads: 0.00, writes: 108519.05, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 563s] threads: 64, tps: 0.00, reads: 0.00, writes: 107690.26, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 564s] threads: 64, tps: 0.00, reads: 0.00, writes: 107138.35, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 565s] threads: 64, tps: 0.00, reads: 0.00, writes: 109240.24, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 565s] threads: 64, tps: 0.00, reads: 0.00, writes: 105394.88, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 567s] threads: 64, tps: 0.00, reads: 0.00, writes: 107033.63, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 568s] threads: 64, tps: 0.00, reads: 0.00, writes: 109422.39, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 569s] threads: 64, tps: 0.00, reads: 0.00, writes: 109069.26, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 570s] threads: 64, tps: 0.00, reads: 0.00, writes: 109705.34, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 571s] threads: 64, tps: 0.00, reads: 0.00, writes: 106143.04, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 572s] threads: 64, tps: 0.00, reads: 0.00, writes: 108076.61, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 573s] threads: 64, tps: 0.00, reads: 0.00, writes: 108333.39, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 574s] threads: 64, tps: 0.00, reads: 0.00, writes: 109548.99, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 575s] threads: 64, tps: 0.00, reads: 0.00, writes: 107270.02, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 576s] threads: 64, tps: 0.00, reads: 0.00, writes: 108424.50, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 577s] threads: 64, tps: 0.00, reads: 0.00, writes: 107722.24, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 578s] threads: 64, tps: 0.00, reads: 0.00, writes: 109228.67, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 579s] threads: 64, tps: 0.00, reads: 0.00, writes: 110461.06, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 580s] threads: 64, tps: 0.00, reads: 0.00, writes: 108981.90, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 581s] threads: 64, tps: 0.00, reads: 0.00, writes: 107355.84, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 582s] threads: 64, tps: 0.00, reads: 0.00, writes: 109035.18, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 583s] threads: 64, tps: 0.00, reads: 0.00, writes: 110417.59, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 584s] threads: 64, tps: 0.00, reads: 0.00, writes: 109589.50, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 585s] threads: 64, tps: 0.00, reads: 0.00, writes: 109013.85, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 586s] threads: 64, tps: 0.00, reads: 0.00, writes: 108707.47, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 587s] threads: 64, tps: 0.00, reads: 0.00, writes: 107623.92, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 588s] threads: 64, tps: 0.00, reads: 0.00, writes: 107997.22, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 589s] threads: 64, tps: 0.00, reads: 0.00, writes: 107864.75, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 590s] threads: 64, tps: 0.00, reads: 0.00, writes: 112377.27, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[ 591s] threads: 64, tps: 0.00, reads: 0.00, writes: 109850.56, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[ 592s] threads: 64, tps: 0.00, reads: 0.00, writes: 111480.55, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 593s] threads: 64, tps: 0.00, reads: 0.00, writes: 109474.09, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 594s] threads: 64, tps: 0.00, reads: 0.00, writes: 111028.90, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[ 595s] threads: 64, tps: 0.00, reads: 0.00, writes: 109863.00, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 596s] threads: 64, tps: 0.00, reads: 0.00, writes: 111473.93, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[ 597s] threads: 64, tps: 0.00, reads: 0.00, writes: 108521.81, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[ 598s] threads: 64, tps: 0.00, reads: 0.00, writes: 109634.20, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 599s] threads: 64, tps: 0.00, reads: 0.00, writes: 108202.89, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[ 600s] threads: 64, tps: 0.00, reads: 0.00, writes: 110182.22, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[ 601s] threads: 64, tps: 0.00, reads: 0.00, writes: 109018.85, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 602s] threads: 64, tps: 0.00, reads: 0.00, writes: 110866.05, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 603s] threads: 64, tps: 0.00, reads: 0.00, writes: 107672.17, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 604s] threads: 64, tps: 0.00, reads: 0.00, writes: 109610.72, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 605s] threads: 64, tps: 0.00, reads: 0.00, writes: 108257.13, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[ 606s] threads: 64, tps: 0.00, reads: 0.00, writes: 109283.47, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 607s] threads: 64, tps: 0.00, reads: 0.00, writes: 111602.62, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 608s] threads: 64, tps: 0.00, reads: 0.00, writes: 109686.96, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 609s] threads: 64, tps: 0.00, reads: 0.00, writes: 112071.96, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 610s] threads: 64, tps: 0.00, reads: 0.00, writes: 108785.12, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 611s] threads: 64, tps: 0.00, reads: 0.00, writes: 109267.73, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 612s] threads: 64, tps: 0.00, reads: 0.00, writes: 110326.13, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 613s] threads: 64, tps: 0.00, reads: 0.00, writes: 108159.09, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 614s] threads: 64, tps: 0.00, reads: 0.00, writes: 109843.79, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 615s] threads: 64, tps: 0.00, reads: 0.00, writes: 105385.17, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 616s] threads: 64, tps: 0.00, reads: 0.00, writes: 109745.04, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[ 617s] threads: 64, tps: 0.00, reads: 0.00, writes: 109918.98, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 618s] threads: 64, tps: 0.00, reads: 0.00, writes: 99097.00, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 619s] threads: 64, tps: 0.00, reads: 0.00, writes: 109524.95, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 620s] threads: 64, tps: 0.00, reads: 0.00, writes: 108587.99, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 621s] threads: 64, tps: 0.00, reads: 0.00, writes: 110150.92, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 622s] threads: 64, tps: 0.00, reads: 0.00, writes: 111486.16, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 623s] threads: 64, tps: 0.00, reads: 0.00, writes: 107106.91, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 624s] threads: 64, tps: 0.00, reads: 0.00, writes: 110820.08, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 625s] threads: 64, tps: 0.00, reads: 0.00, writes: 109068.06, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 626s] threads: 64, tps: 0.00, reads: 0.00, writes: 110707.98, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 627s] threads: 64, tps: 0.00, reads: 0.00, writes: 111521.08, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 628s] threads: 64, tps: 0.00, reads: 0.00, writes: 113292.83, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 629s] threads: 64, tps: 0.00, reads: 0.00, writes: 111801.17, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 630s] threads: 64, tps: 0.00, reads: 0.00, writes: 113225.88, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[ 631s] threads: 64, tps: 0.00, reads: 0.00, writes: 111086.64, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 632s] threads: 64, tps: 0.00, reads: 0.00, writes: 112187.90, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 633s] threads: 64, tps: 0.00, reads: 0.00, writes: 113187.53, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[ 634s] threads: 64, tps: 0.00, reads: 0.00, writes: 110847.08, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 635s] threads: 64, tps: 0.00, reads: 0.00, writes: 109858.87, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 636s] threads: 64, tps: 0.00, reads: 0.00, writes: 110991.97, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 637s] threads: 64, tps: 0.00, reads: 0.00, writes: 110504.34, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 638s] threads: 64, tps: 0.00, reads: 0.00, writes: 112137.67, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 639s] threads: 64, tps: 0.00, reads: 0.00, writes: 109521.06, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 640s] threads: 64, tps: 0.00, reads: 0.00, writes: 111519.92, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 641s] threads: 64, tps: 0.00, reads: 0.00, writes: 109969.03, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 642s] threads: 64, tps: 0.00, reads: 0.00, writes: 112225.06, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 643s] threads: 64, tps: 0.00, reads: 0.00, writes: 112858.01, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 644s] threads: 64, tps: 0.00, reads: 0.00, writes: 114055.81, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 645s] threads: 64, tps: 0.00, reads: 0.00, writes: 110266.12, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 646s] threads: 64, tps: 0.00, reads: 0.00, writes: 113139.97, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 647s] threads: 64, tps: 0.00, reads: 0.00, writes: 112055.91, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 648s] threads: 64, tps: 0.00, reads: 0.00, writes: 108844.14, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 649s] threads: 64, tps: 0.00, reads: 0.00, writes: 110512.98, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[ 650s] threads: 64, tps: 0.00, reads: 0.00, writes: 111653.09, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 651s] threads: 64, tps: 0.00, reads: 0.00, writes: 112191.96, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 652s] threads: 64, tps: 0.00, reads: 0.00, writes: 109437.79, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[ 653s] threads: 64, tps: 0.00, reads: 0.00, writes: 109034.17, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 654s] threads: 64, tps: 0.00, reads: 0.00, writes: 110281.84, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 655s] threads: 64, tps: 0.00, reads: 0.00, writes: 109132.14, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 656s] threads: 64, tps: 0.00, reads: 0.00, writes: 108493.06, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 657s] threads: 64, tps: 0.00, reads: 0.00, writes: 108523.77, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 658s] threads: 64, tps: 0.00, reads: 0.00, writes: 107663.23, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 659s] threads: 64, tps: 0.00, reads: 0.00, writes: 107098.97, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 660s] threads: 64, tps: 0.00, reads: 0.00, writes: 104588.08, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 661s] threads: 64, tps: 0.00, reads: 0.00, writes: 97640.89, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[ 662s] threads: 64, tps: 0.00, reads: 0.00, writes: 102916.72, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 663s] threads: 64, tps: 0.00, reads: 0.00, writes: 96739.86, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[ 664s] threads: 64, tps: 0.00, reads: 0.00, writes: 97342.36, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 665s] threads: 64, tps: 0.00, reads: 0.00, writes: 97964.08, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[ 666s] threads: 64, tps: 0.00, reads: 0.00, writes: 104696.47, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 667s] threads: 64, tps: 0.00, reads: 0.00, writes: 101151.40, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 668s] threads: 64, tps: 0.00, reads: 0.00, writes: 98847.01, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 669s] threads: 64, tps: 0.00, reads: 0.00, writes: 99328.07, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[ 670s] threads: 64, tps: 0.00, reads: 0.00, writes: 99190.58, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[ 671s] threads: 64, tps: 0.00, reads: 0.00, writes: 96271.40, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 672s] threads: 64, tps: 0.00, reads: 0.00, writes: 95045.01, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[ 673s] threads: 64, tps: 0.00, reads: 0.00, writes: 85552.05, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[ 674s] threads: 64, tps: 0.00, reads: 0.00, writes: 93848.95, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[ 675s] threads: 64, tps: 0.00, reads: 0.00, writes: 97898.97, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[ 676s] threads: 64, tps: 0.00, reads: 0.00, writes: 98233.98, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[ 677s] threads: 64, tps: 0.00, reads: 0.00, writes: 95968.08, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 678s] threads: 64, tps: 0.00, reads: 0.00, writes: 99106.52, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[ 679s] threads: 64, tps: 0.00, reads: 0.00, writes: 97695.43, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[ 680s] threads: 64, tps: 0.00, reads: 0.00, writes: 93718.04, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[ 681s] threads: 64, tps: 0.00, reads: 0.00, writes: 94531.94, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 682s] threads: 64, tps: 0.00, reads: 0.00, writes: 95509.00, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[ 683s] threads: 64, tps: 0.00, reads: 0.00, writes: 91724.01, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[ 684s] threads: 64, tps: 0.00, reads: 0.00, writes: 92934.19, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[ 685s] threads: 64, tps: 0.00, reads: 0.00, writes: 93220.91, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[ 686s] threads: 64, tps: 0.00, reads: 0.00, writes: 91671.94, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[ 687s] threads: 64, tps: 0.00, reads: 0.00, writes: 90413.95, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[ 688s] threads: 64, tps: 0.00, reads: 0.00, writes: 97198.69, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 689s] threads: 64, tps: 0.00, reads: 0.00, writes: 88568.29, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[ 690s] threads: 64, tps: 0.00, reads: 0.00, writes: 87603.95, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[ 691s] threads: 64, tps: 0.00, reads: 0.00, writes: 87326.05, response time: 3.78ms (95%), errors: 0.00, reconnects:  0.00
[ 692s] threads: 64, tps: 0.00, reads: 0.00, writes: 87611.09, response time: 3.73ms (95%), errors: 0.00, reconnects:  0.00
[ 693s] threads: 64, tps: 0.00, reads: 0.00, writes: 66361.87, response time: 5.30ms (95%), errors: 0.00, reconnects:  0.00
[ 694s] threads: 64, tps: 0.00, reads: 0.00, writes: 72110.99, response time: 4.94ms (95%), errors: 0.00, reconnects:  0.00
[ 695s] threads: 64, tps: 0.00, reads: 0.00, writes: 79206.37, response time: 4.32ms (95%), errors: 0.00, reconnects:  0.00
[ 696s] threads: 64, tps: 0.00, reads: 0.00, writes: 74856.68, response time: 4.54ms (95%), errors: 0.00, reconnects:  0.00
[ 697s] threads: 64, tps: 0.00, reads: 0.00, writes: 75574.08, response time: 4.74ms (95%), errors: 0.00, reconnects:  0.00
[ 698s] threads: 64, tps: 0.00, reads: 0.00, writes: 71699.92, response time: 5.08ms (95%), errors: 0.00, reconnects:  0.00
[ 699s] threads: 64, tps: 0.00, reads: 0.00, writes: 72721.02, response time: 4.88ms (95%), errors: 0.00, reconnects:  0.00
[ 700s] threads: 64, tps: 0.00, reads: 0.00, writes: 73104.17, response time: 4.96ms (95%), errors: 0.00, reconnects:  0.00
[ 701s] threads: 64, tps: 0.00, reads: 0.00, writes: 75594.06, response time: 4.72ms (95%), errors: 0.00, reconnects:  0.00
[ 702s] threads: 64, tps: 0.00, reads: 0.00, writes: 73374.87, response time: 4.90ms (95%), errors: 0.00, reconnects:  0.00
[ 703s] threads: 64, tps: 0.00, reads: 0.00, writes: 72143.13, response time: 4.91ms (95%), errors: 0.00, reconnects:  0.00
[ 704s] threads: 64, tps: 0.00, reads: 0.00, writes: 72612.05, response time: 5.16ms (95%), errors: 0.00, reconnects:  0.00
[ 705s] threads: 64, tps: 0.00, reads: 0.00, writes: 68466.97, response time: 5.35ms (95%), errors: 0.00, reconnects:  0.00
[ 706s] threads: 64, tps: 0.00, reads: 0.00, writes: 69194.91, response time: 4.86ms (95%), errors: 0.00, reconnects:  0.00
[ 707s] threads: 64, tps: 0.00, reads: 0.00, writes: 74328.08, response time: 4.41ms (95%), errors: 0.00, reconnects:  0.00
[ 708s] threads: 64, tps: 0.00, reads: 0.00, writes: 67317.99, response time: 5.06ms (95%), errors: 0.00, reconnects:  0.00
[ 709s] threads: 64, tps: 0.00, reads: 0.00, writes: 71780.05, response time: 4.65ms (95%), errors: 0.00, reconnects:  0.00
[ 710s] threads: 64, tps: 0.00, reads: 0.00, writes: 71216.97, response time: 4.76ms (95%), errors: 0.00, reconnects:  0.00
[ 711s] threads: 64, tps: 0.00, reads: 0.00, writes: 77697.97, response time: 4.50ms (95%), errors: 0.00, reconnects:  0.00
[ 712s] threads: 64, tps: 0.00, reads: 0.00, writes: 69828.02, response time: 5.01ms (95%), errors: 0.00, reconnects:  0.00
[ 713s] threads: 64, tps: 0.00, reads: 0.00, writes: 75180.98, response time: 4.80ms (95%), errors: 0.00, reconnects:  0.00
[ 714s] threads: 64, tps: 0.00, reads: 0.00, writes: 69959.89, response time: 5.32ms (95%), errors: 0.00, reconnects:  0.00
[ 715s] threads: 64, tps: 0.00, reads: 0.00, writes: 72781.19, response time: 4.94ms (95%), errors: 0.00, reconnects:  0.00
[ 716s] threads: 64, tps: 0.00, reads: 0.00, writes: 74587.89, response time: 4.64ms (95%), errors: 0.00, reconnects:  0.00
[ 717s] threads: 64, tps: 0.00, reads: 0.00, writes: 75315.02, response time: 4.76ms (95%), errors: 0.00, reconnects:  0.00
[ 718s] threads: 64, tps: 0.00, reads: 0.00, writes: 78107.01, response time: 4.55ms (95%), errors: 0.00, reconnects:  0.00
[ 719s] threads: 64, tps: 0.00, reads: 0.00, writes: 67206.01, response time: 5.18ms (95%), errors: 0.00, reconnects:  0.00
[ 720s] threads: 64, tps: 0.00, reads: 0.00, writes: 66094.03, response time: 5.08ms (95%), errors: 0.00, reconnects:  0.00
[ 721s] threads: 64, tps: 0.00, reads: 0.00, writes: 67766.98, response time: 5.08ms (95%), errors: 0.00, reconnects:  0.00
[ 722s] threads: 64, tps: 0.00, reads: 0.00, writes: 72071.02, response time: 4.98ms (95%), errors: 0.00, reconnects:  0.00
[ 723s] threads: 64, tps: 0.00, reads: 0.00, writes: 68502.85, response time: 5.30ms (95%), errors: 0.00, reconnects:  0.00
[ 724s] threads: 64, tps: 0.00, reads: 0.00, writes: 67612.12, response time: 5.22ms (95%), errors: 0.00, reconnects:  0.00
[ 725s] threads: 64, tps: 0.00, reads: 0.00, writes: 66549.96, response time: 5.08ms (95%), errors: 0.00, reconnects:  0.00
[ 726s] threads: 64, tps: 0.00, reads: 0.00, writes: 64739.70, response time: 5.21ms (95%), errors: 0.00, reconnects:  0.00
[ 727s] threads: 64, tps: 0.00, reads: 0.00, writes: 60115.33, response time: 5.69ms (95%), errors: 0.00, reconnects:  0.00
[ 728s] threads: 64, tps: 0.00, reads: 0.00, writes: 67021.99, response time: 4.81ms (95%), errors: 0.00, reconnects:  0.00
[ 729s] threads: 64, tps: 0.00, reads: 0.00, writes: 61613.05, response time: 5.47ms (95%), errors: 0.00, reconnects:  0.00
[ 730s] threads: 64, tps: 0.00, reads: 0.00, writes: 63771.88, response time: 5.51ms (95%), errors: 0.00, reconnects:  0.00
[ 731s] threads: 64, tps: 0.00, reads: 0.00, writes: 61657.03, response time: 5.65ms (95%), errors: 0.00, reconnects:  0.00
[ 732s] threads: 64, tps: 0.00, reads: 0.00, writes: 65528.98, response time: 5.03ms (95%), errors: 0.00, reconnects:  0.00
[ 733s] threads: 64, tps: 0.00, reads: 0.00, writes: 64595.93, response time: 5.40ms (95%), errors: 0.00, reconnects:  0.00
[ 734s] threads: 64, tps: 0.00, reads: 0.00, writes: 65466.14, response time: 5.17ms (95%), errors: 0.00, reconnects:  0.00
[ 735s] threads: 64, tps: 0.00, reads: 0.00, writes: 72727.05, response time: 4.87ms (95%), errors: 0.00, reconnects:  0.00
[ 736s] threads: 64, tps: 0.00, reads: 0.00, writes: 70325.94, response time: 5.03ms (95%), errors: 0.00, reconnects:  0.00
[ 737s] threads: 64, tps: 0.00, reads: 0.00, writes: 67785.93, response time: 5.19ms (95%), errors: 0.00, reconnects:  0.00
[ 738s] threads: 64, tps: 0.00, reads: 0.00, writes: 71669.93, response time: 4.95ms (95%), errors: 0.00, reconnects:  0.00
[ 739s] threads: 64, tps: 0.00, reads: 0.00, writes: 69013.15, response time: 5.06ms (95%), errors: 0.00, reconnects:  0.00
[ 740s] threads: 64, tps: 0.00, reads: 0.00, writes: 67480.98, response time: 5.31ms (95%), errors: 0.00, reconnects:  0.00
[ 741s] threads: 64, tps: 0.00, reads: 0.00, writes: 68127.98, response time: 5.25ms (95%), errors: 0.00, reconnects:  0.00
[ 742s] threads: 64, tps: 0.00, reads: 0.00, writes: 69646.99, response time: 4.92ms (95%), errors: 0.00, reconnects:  0.00
[ 743s] threads: 64, tps: 0.00, reads: 0.00, writes: 73022.01, response time: 4.87ms (95%), errors: 0.00, reconnects:  0.00
[ 744s] threads: 64, tps: 0.00, reads: 0.00, writes: 78310.05, response time: 4.43ms (95%), errors: 0.00, reconnects:  0.00
[ 745s] threads: 64, tps: 0.00, reads: 0.00, writes: 79634.79, response time: 4.44ms (95%), errors: 0.00, reconnects:  0.00
[ 746s] threads: 64, tps: 0.00, reads: 0.00, writes: 73194.13, response time: 4.75ms (95%), errors: 0.00, reconnects:  0.00
[ 747s] threads: 64, tps: 0.00, reads: 0.00, writes: 70234.07, response time: 4.85ms (95%), errors: 0.00, reconnects:  0.00
[ 748s] threads: 64, tps: 0.00, reads: 0.00, writes: 75712.95, response time: 4.48ms (95%), errors: 0.00, reconnects:  0.00
[ 749s] threads: 64, tps: 0.00, reads: 0.00, writes: 85574.89, response time: 3.90ms (95%), errors: 0.00, reconnects:  0.00
[ 750s] threads: 64, tps: 0.00, reads: 0.00, writes: 83974.23, response time: 3.98ms (95%), errors: 0.00, reconnects:  0.00
[ 751s] threads: 64, tps: 0.00, reads: 0.00, writes: 88349.85, response time: 3.82ms (95%), errors: 0.00, reconnects:  0.00
[ 752s] threads: 64, tps: 0.00, reads: 0.00, writes: 85271.05, response time: 3.87ms (95%), errors: 0.00, reconnects:  0.00
[ 753s] threads: 64, tps: 0.00, reads: 0.00, writes: 86131.04, response time: 3.90ms (95%), errors: 0.00, reconnects:  0.00
[ 754s] threads: 64, tps: 0.00, reads: 0.00, writes: 82875.76, response time: 4.01ms (95%), errors: 0.00, reconnects:  0.00
[ 755s] threads: 64, tps: 0.00, reads: 0.00, writes: 75093.17, response time: 4.44ms (95%), errors: 0.00, reconnects:  0.00
[ 756s] threads: 64, tps: 0.00, reads: 0.00, writes: 84318.98, response time: 4.04ms (95%), errors: 0.00, reconnects:  0.00
[ 757s] threads: 64, tps: 0.00, reads: 0.00, writes: 86352.06, response time: 3.97ms (95%), errors: 0.00, reconnects:  0.00
[ 758s] threads: 64, tps: 0.00, reads: 0.00, writes: 84834.94, response time: 4.04ms (95%), errors: 0.00, reconnects:  0.00
[ 759s] threads: 64, tps: 0.00, reads: 0.00, writes: 86647.98, response time: 4.00ms (95%), errors: 0.00, reconnects:  0.00
[ 760s] threads: 64, tps: 0.00, reads: 0.00, writes: 86330.07, response time: 4.01ms (95%), errors: 0.00, reconnects:  0.00
[ 761s] threads: 64, tps: 0.00, reads: 0.00, writes: 88942.20, response time: 4.04ms (95%), errors: 0.00, reconnects:  0.00
[ 762s] threads: 64, tps: 0.00, reads: 0.00, writes: 88027.68, response time: 3.95ms (95%), errors: 0.00, reconnects:  0.00
[ 763s] threads: 64, tps: 0.00, reads: 0.00, writes: 86979.43, response time: 4.02ms (95%), errors: 0.00, reconnects:  0.00
[ 764s] threads: 64, tps: 0.00, reads: 0.00, writes: 88073.67, response time: 4.05ms (95%), errors: 0.00, reconnects:  0.00
[ 765s] threads: 64, tps: 0.00, reads: 0.00, writes: 86601.98, response time: 3.96ms (95%), errors: 0.00, reconnects:  0.00
[ 766s] threads: 64, tps: 0.00, reads: 0.00, writes: 88530.11, response time: 3.97ms (95%), errors: 0.00, reconnects:  0.00
[ 767s] threads: 64, tps: 0.00, reads: 0.00, writes: 86321.86, response time: 4.07ms (95%), errors: 0.00, reconnects:  0.00
[ 768s] threads: 64, tps: 0.00, reads: 0.00, writes: 88718.93, response time: 4.04ms (95%), errors: 0.00, reconnects:  0.00
[ 769s] threads: 64, tps: 0.00, reads: 0.00, writes: 71450.10, response time: 5.05ms (95%), errors: 0.00, reconnects:  0.00
[ 770s] threads: 64, tps: 0.00, reads: 0.00, writes: 71296.96, response time: 4.96ms (95%), errors: 0.00, reconnects:  0.00
[ 771s] threads: 64, tps: 0.00, reads: 0.00, writes: 71012.00, response time: 4.71ms (95%), errors: 0.00, reconnects:  0.00
[ 772s] threads: 64, tps: 0.00, reads: 0.00, writes: 68647.03, response time: 4.91ms (95%), errors: 0.00, reconnects:  0.00
[ 773s] threads: 64, tps: 0.00, reads: 0.00, writes: 72028.02, response time: 4.72ms (95%), errors: 0.00, reconnects:  0.00
[ 774s] threads: 64, tps: 0.00, reads: 0.00, writes: 74050.98, response time: 4.60ms (95%), errors: 0.00, reconnects:  0.00
[ 775s] threads: 64, tps: 0.00, reads: 0.00, writes: 77126.67, response time: 4.32ms (95%), errors: 0.00, reconnects:  0.00
[ 776s] threads: 64, tps: 0.00, reads: 0.00, writes: 78332.32, response time: 4.24ms (95%), errors: 0.00, reconnects:  0.00
[ 777s] threads: 64, tps: 0.00, reads: 0.00, writes: 73799.96, response time: 4.66ms (95%), errors: 0.00, reconnects:  0.00
[ 778s] threads: 64, tps: 0.00, reads: 0.00, writes: 72779.00, response time: 4.69ms (95%), errors: 0.00, reconnects:  0.00
[ 779s] threads: 64, tps: 0.00, reads: 0.00, writes: 78997.02, response time: 4.44ms (95%), errors: 0.00, reconnects:  0.00
[ 780s] threads: 64, tps: 0.00, reads: 0.00, writes: 73928.98, response time: 4.59ms (95%), errors: 0.00, reconnects:  0.00
[ 781s] threads: 64, tps: 0.00, reads: 0.00, writes: 72409.05, response time: 4.74ms (95%), errors: 0.00, reconnects:  0.00
[ 782s] threads: 64, tps: 0.00, reads: 0.00, writes: 74901.94, response time: 4.73ms (95%), errors: 0.00, reconnects:  0.00
[ 783s] threads: 64, tps: 0.00, reads: 0.00, writes: 73388.05, response time: 4.74ms (95%), errors: 0.00, reconnects:  0.00
[ 784s] threads: 64, tps: 0.00, reads: 0.00, writes: 74393.81, response time: 4.60ms (95%), errors: 0.00, reconnects:  0.00
[ 785s] threads: 64, tps: 0.00, reads: 0.00, writes: 73735.16, response time: 4.78ms (95%), errors: 0.00, reconnects:  0.00
[ 786s] threads: 64, tps: 0.00, reads: 0.00, writes: 65892.99, response time: 5.38ms (95%), errors: 0.00, reconnects:  0.00
[ 787s] threads: 64, tps: 0.00, reads: 0.00, writes: 64374.94, response time: 5.41ms (95%), errors: 0.00, reconnects:  0.00
[ 788s] threads: 64, tps: 0.00, reads: 0.00, writes: 62895.03, response time: 5.66ms (95%), errors: 0.00, reconnects:  0.00
[ 789s] threads: 64, tps: 0.00, reads: 0.00, writes: 61086.05, response time: 5.72ms (95%), errors: 0.00, reconnects:  0.00
[ 790s] threads: 64, tps: 0.00, reads: 0.00, writes: 59944.96, response time: 5.78ms (95%), errors: 0.00, reconnects:  0.00
[ 791s] threads: 64, tps: 0.00, reads: 0.00, writes: 53201.98, response time: 7.05ms (95%), errors: 0.00, reconnects:  0.00
[ 792s] threads: 64, tps: 0.00, reads: 0.00, writes: 54920.02, response time: 6.38ms (95%), errors: 0.00, reconnects:  0.00
[ 793s] threads: 64, tps: 0.00, reads: 0.00, writes: 51307.03, response time: 6.94ms (95%), errors: 0.00, reconnects:  0.00
[ 794s] threads: 64, tps: 0.00, reads: 0.00, writes: 45931.03, response time: 7.60ms (95%), errors: 0.00, reconnects:  0.00
[ 795s] threads: 64, tps: 0.00, reads: 0.00, writes: 48206.01, response time: 7.22ms (95%), errors: 0.00, reconnects:  0.00
[ 796s] threads: 64, tps: 0.00, reads: 0.00, writes: 48058.93, response time: 7.06ms (95%), errors: 0.00, reconnects:  0.00
[ 797s] threads: 64, tps: 0.00, reads: 0.00, writes: 59026.99, response time: 5.57ms (95%), errors: 0.00, reconnects:  0.00
[ 798s] threads: 64, tps: 0.00, reads: 0.00, writes: 52172.10, response time: 6.41ms (95%), errors: 0.00, reconnects:  0.00
[ 799s] threads: 64, tps: 0.00, reads: 0.00, writes: 49308.92, response time: 6.96ms (95%), errors: 0.00, reconnects:  0.00
[ 800s] threads: 64, tps: 0.00, reads: 0.00, writes: 55444.04, response time: 6.22ms (95%), errors: 0.00, reconnects:  0.00
[ 801s] threads: 64, tps: 0.00, reads: 0.00, writes: 58390.93, response time: 5.84ms (95%), errors: 0.00, reconnects:  0.00
[ 802s] threads: 64, tps: 0.00, reads: 0.00, writes: 64260.09, response time: 5.36ms (95%), errors: 0.00, reconnects:  0.00
[ 803s] threads: 64, tps: 0.00, reads: 0.00, writes: 70765.94, response time: 4.98ms (95%), errors: 0.00, reconnects:  0.00
[ 804s] threads: 64, tps: 0.00, reads: 0.00, writes: 71454.93, response time: 4.77ms (95%), errors: 0.00, reconnects:  0.00
[ 805s] threads: 64, tps: 0.00, reads: 0.00, writes: 76310.10, response time: 4.42ms (95%), errors: 0.00, reconnects:  0.00
[ 806s] threads: 64, tps: 0.00, reads: 0.00, writes: 74376.95, response time: 4.60ms (95%), errors: 0.00, reconnects:  0.00
[ 807s] threads: 64, tps: 0.00, reads: 0.00, writes: 70356.08, response time: 4.97ms (95%), errors: 0.00, reconnects:  0.00
[ 808s] threads: 64, tps: 0.00, reads: 0.00, writes: 74768.89, response time: 4.60ms (95%), errors: 0.00, reconnects:  0.00
[ 809s] threads: 64, tps: 0.00, reads: 0.00, writes: 72990.99, response time: 4.78ms (95%), errors: 0.00, reconnects:  0.00
[ 810s] threads: 64, tps: 0.00, reads: 0.00, writes: 70171.88, response time: 5.04ms (95%), errors: 0.00, reconnects:  0.00
[ 811s] threads: 64, tps: 0.00, reads: 0.00, writes: 70985.02, response time: 4.85ms (95%), errors: 0.00, reconnects:  0.00
[ 812s] threads: 64, tps: 0.00, reads: 0.00, writes: 64590.91, response time: 5.40ms (95%), errors: 0.00, reconnects:  0.00
[ 813s] threads: 64, tps: 0.00, reads: 0.00, writes: 71066.92, response time: 5.07ms (95%), errors: 0.00, reconnects:  0.00
[ 814s] threads: 64, tps: 0.00, reads: 0.00, writes: 69649.13, response time: 4.84ms (95%), errors: 0.00, reconnects:  0.00
[ 815s] threads: 64, tps: 0.00, reads: 0.00, writes: 69566.02, response time: 4.80ms (95%), errors: 0.00, reconnects:  0.00
[ 816s] threads: 64, tps: 0.00, reads: 0.00, writes: 80895.02, response time: 4.01ms (95%), errors: 0.00, reconnects:  0.00
[ 817s] threads: 64, tps: 0.00, reads: 0.00, writes: 84118.91, response time: 3.90ms (95%), errors: 0.00, reconnects:  0.00
[ 818s] threads: 64, tps: 0.00, reads: 0.00, writes: 84439.02, response time: 3.92ms (95%), errors: 0.00, reconnects:  0.00
[ 819s] threads: 64, tps: 0.00, reads: 0.00, writes: 86135.05, response time: 3.78ms (95%), errors: 0.00, reconnects:  0.00
[ 820s] threads: 64, tps: 0.00, reads: 0.00, writes: 85723.60, response time: 3.85ms (95%), errors: 0.00, reconnects:  0.00
[ 821s] threads: 64, tps: 0.00, reads: 0.00, writes: 84914.11, response time: 4.03ms (95%), errors: 0.00, reconnects:  0.00
[ 822s] threads: 64, tps: 0.00, reads: 0.00, writes: 86892.11, response time: 3.90ms (95%), errors: 0.00, reconnects:  0.00
[ 823s] threads: 64, tps: 0.00, reads: 0.00, writes: 84549.20, response time: 4.08ms (95%), errors: 0.00, reconnects:  0.00
[ 824s] threads: 64, tps: 0.00, reads: 0.00, writes: 88591.42, response time: 3.86ms (95%), errors: 0.00, reconnects:  0.00
[ 825s] threads: 64, tps: 0.00, reads: 0.00, writes: 89546.63, response time: 3.88ms (95%), errors: 0.00, reconnects:  0.00
[ 826s] threads: 64, tps: 0.00, reads: 0.00, writes: 90452.97, response time: 3.80ms (95%), errors: 0.00, reconnects:  0.00
[ 827s] threads: 64, tps: 0.00, reads: 0.00, writes: 86285.83, response time: 4.04ms (95%), errors: 0.00, reconnects:  0.00
[ 828s] threads: 64, tps: 0.00, reads: 0.00, writes: 82766.02, response time: 4.12ms (95%), errors: 0.00, reconnects:  0.00
[ 829s] threads: 64, tps: 0.00, reads: 0.00, writes: 89725.08, response time: 3.90ms (95%), errors: 0.00, reconnects:  0.00
[ 830s] threads: 64, tps: 0.00, reads: 0.00, writes: 90278.02, response time: 3.79ms (95%), errors: 0.00, reconnects:  0.00
[ 831s] threads: 64, tps: 0.00, reads: 0.00, writes: 90474.81, response time: 3.81ms (95%), errors: 0.00, reconnects:  0.00
[ 832s] threads: 64, tps: 0.00, reads: 0.00, writes: 89300.04, response time: 3.96ms (95%), errors: 0.00, reconnects:  0.00
[ 833s] threads: 64, tps: 0.00, reads: 0.00, writes: 87368.04, response time: 4.00ms (95%), errors: 0.00, reconnects:  0.00
[ 834s] threads: 64, tps: 0.00, reads: 0.00, writes: 84106.52, response time: 4.09ms (95%), errors: 0.00, reconnects:  0.00
[ 835s] threads: 64, tps: 0.00, reads: 0.00, writes: 88652.53, response time: 4.08ms (95%), errors: 0.00, reconnects:  0.00
[ 836s] threads: 64, tps: 0.00, reads: 0.00, writes: 85976.98, response time: 4.17ms (95%), errors: 0.00, reconnects:  0.00
[ 837s] threads: 64, tps: 0.00, reads: 0.00, writes: 79324.98, response time: 4.38ms (95%), errors: 0.00, reconnects:  0.00
[ 838s] threads: 64, tps: 0.00, reads: 0.00, writes: 78440.97, response time: 4.32ms (95%), errors: 0.00, reconnects:  0.00
[ 839s] threads: 64, tps: 0.00, reads: 0.00, writes: 73893.98, response time: 4.67ms (95%), errors: 0.00, reconnects:  0.00
[ 840s] threads: 64, tps: 0.00, reads: 0.00, writes: 72477.58, response time: 4.75ms (95%), errors: 0.00, reconnects:  0.00
[ 843s] threads: 64, tps: 0.00, reads: 0.00, writes: 20029.47, response time: 5.66ms (95%), errors: 0.00, reconnects:  0.00
[ 845s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 846s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 847s] threads: 64, tps: 0.00, reads: 0.00, writes: 9000.28, response time: 4.77ms (95%), errors: 0.00, reconnects:  0.00
[ 848s] threads: 64, tps: 0.00, reads: 0.00, writes: 50385.04, response time: 6.32ms (95%), errors: 0.00, reconnects:  0.00
[ 849s] threads: 64, tps: 0.00, reads: 0.00, writes: 26395.98, response time: 8.07ms (95%), errors: 0.00, reconnects:  0.00
[ 850s] threads: 64, tps: 0.00, reads: 0.00, writes: 55411.97, response time: 6.52ms (95%), errors: 0.00, reconnects:  0.00
[ 851s] threads: 64, tps: 0.00, reads: 0.00, writes: 61913.62, response time: 5.70ms (95%), errors: 0.00, reconnects:  0.00
[ 852s] threads: 64, tps: 0.00, reads: 0.00, writes: 61617.89, response time: 6.07ms (95%), errors: 0.00, reconnects:  0.00
[ 853s] threads: 64, tps: 0.00, reads: 0.00, writes: 64309.15, response time: 5.45ms (95%), errors: 0.00, reconnects:  0.00
[ 854s] threads: 64, tps: 0.00, reads: 0.00, writes: 61456.93, response time: 5.88ms (95%), errors: 0.00, reconnects:  0.00
[ 855s] threads: 64, tps: 0.00, reads: 0.00, writes: 64822.02, response time: 5.30ms (95%), errors: 0.00, reconnects:  0.00
[ 856s] threads: 64, tps: 0.00, reads: 0.00, writes: 84354.03, response time: 4.03ms (95%), errors: 0.00, reconnects:  0.00
[ 857s] threads: 64, tps: 0.00, reads: 0.00, writes: 81054.61, response time: 4.21ms (95%), errors: 0.00, reconnects:  0.00
[ 858s] threads: 64, tps: 0.00, reads: 0.00, writes: 66609.05, response time: 5.14ms (95%), errors: 0.00, reconnects:  0.00
[ 859s] threads: 64, tps: 0.00, reads: 0.00, writes: 65696.87, response time: 5.15ms (95%), errors: 0.00, reconnects:  0.00
[ 860s] threads: 64, tps: 0.00, reads: 0.00, writes: 69258.68, response time: 5.13ms (95%), errors: 0.00, reconnects:  0.00
[ 861s] threads: 64, tps: 0.00, reads: 0.00, writes: 72091.37, response time: 4.76ms (95%), errors: 0.00, reconnects:  0.00
[ 862s] threads: 64, tps: 0.00, reads: 0.00, writes: 71428.05, response time: 4.81ms (95%), errors: 0.00, reconnects:  0.00
[ 863s] threads: 64, tps: 0.00, reads: 0.00, writes: 65145.96, response time: 5.77ms (95%), errors: 0.00, reconnects:  0.00
[ 864s] threads: 64, tps: 0.00, reads: 0.00, writes: 63965.96, response time: 5.66ms (95%), errors: 0.00, reconnects:  0.00
[ 865s] threads: 64, tps: 0.00, reads: 0.00, writes: 63399.65, response time: 5.54ms (95%), errors: 0.00, reconnects:  0.00
[ 866s] threads: 64, tps: 0.00, reads: 0.00, writes: 62056.35, response time: 5.54ms (95%), errors: 0.00, reconnects:  0.00
[ 867s] threads: 64, tps: 0.00, reads: 0.00, writes: 58160.97, response time: 6.22ms (95%), errors: 0.00, reconnects:  0.00
[ 868s] threads: 64, tps: 0.00, reads: 0.00, writes: 55353.07, response time: 6.27ms (95%), errors: 0.00, reconnects:  0.00
[ 869s] threads: 64, tps: 0.00, reads: 0.00, writes: 60342.99, response time: 5.81ms (95%), errors: 0.00, reconnects:  0.00
[ 870s] threads: 64, tps: 0.00, reads: 0.00, writes: 66501.96, response time: 4.88ms (95%), errors: 0.00, reconnects:  0.00
[ 871s] threads: 64, tps: 0.00, reads: 0.00, writes: 72288.89, response time: 4.60ms (95%), errors: 0.00, reconnects:  0.00
[ 872s] threads: 64, tps: 0.00, reads: 0.00, writes: 67327.25, response time: 5.15ms (95%), errors: 0.00, reconnects:  0.00
[ 873s] threads: 64, tps: 0.00, reads: 0.00, writes: 73282.92, response time: 4.58ms (95%), errors: 0.00, reconnects:  0.00
[ 874s] threads: 64, tps: 0.00, reads: 0.00, writes: 74510.99, response time: 4.47ms (95%), errors: 0.00, reconnects:  0.00
[ 875s] threads: 64, tps: 0.00, reads: 0.00, writes: 66382.08, response time: 5.17ms (95%), errors: 0.00, reconnects:  0.00
[ 876s] threads: 64, tps: 0.00, reads: 0.00, writes: 66827.89, response time: 5.10ms (95%), errors: 0.00, reconnects:  0.00
[ 877s] threads: 64, tps: 0.00, reads: 0.00, writes: 70743.02, response time: 4.85ms (95%), errors: 0.00, reconnects:  0.00
[ 878s] threads: 64, tps: 0.00, reads: 0.00, writes: 72874.00, response time: 4.53ms (95%), errors: 0.00, reconnects:  0.00
[ 879s] threads: 64, tps: 0.00, reads: 0.00, writes: 77444.89, response time: 4.42ms (95%), errors: 0.00, reconnects:  0.00
[ 882s] threads: 64, tps: 0.00, reads: 0.00, writes: 79885.30, response time: 4.23ms (95%), errors: 0.00, reconnects:  0.00
[ 884s] threads: 64, tps: 0.00, reads: 0.00, writes: 16.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 885s] threads: 64, tps: 0.00, reads: 0.00, writes: 52393.63, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[ 886s] threads: 64, tps: 0.00, reads: 0.00, writes: 77268.13, response time: 4.37ms (95%), errors: 0.00, reconnects:  0.00
[ 887s] threads: 64, tps: 0.00, reads: 0.00, writes: 72377.81, response time: 4.67ms (95%), errors: 0.00, reconnects:  0.00
[ 888s] threads: 64, tps: 0.00, reads: 0.00, writes: 77938.10, response time: 4.36ms (95%), errors: 0.00, reconnects:  0.00
[ 889s] threads: 64, tps: 0.00, reads: 0.00, writes: 82364.09, response time: 4.31ms (95%), errors: 0.00, reconnects:  0.00
[ 890s] threads: 64, tps: 0.00, reads: 0.00, writes: 84051.03, response time: 3.82ms (95%), errors: 0.00, reconnects:  0.00
[ 891s] threads: 64, tps: 0.00, reads: 0.00, writes: 83949.92, response time: 4.02ms (95%), errors: 0.00, reconnects:  0.00
[ 892s] threads: 64, tps: 0.00, reads: 0.00, writes: 83313.12, response time: 4.00ms (95%), errors: 0.00, reconnects:  0.00
[ 893s] threads: 64, tps: 0.00, reads: 0.00, writes: 79724.87, response time: 4.04ms (95%), errors: 0.00, reconnects:  0.00
[ 894s] threads: 64, tps: 0.00, reads: 0.00, writes: 81006.02, response time: 4.00ms (95%), errors: 0.00, reconnects:  0.00
[ 895s] threads: 64, tps: 0.00, reads: 0.00, writes: 74936.26, response time: 4.45ms (95%), errors: 0.00, reconnects:  0.00
[ 897s] threads: 64, tps: 0.00, reads: 0.00, writes: 71237.23, response time: 4.54ms (95%), errors: 0.00, reconnects:  0.00
[ 897s] threads: 64, tps: 0.00, reads: 0.00, writes: 27872.03, response time: 6.01ms (95%), errors: 0.00, reconnects:  0.00
[ 898s] threads: 64, tps: 0.00, reads: 0.00, writes: 61074.08, response time: 5.66ms (95%), errors: 0.00, reconnects:  0.00
[ 899s] threads: 64, tps: 0.00, reads: 0.00, writes: 67813.01, response time: 5.08ms (95%), errors: 0.00, reconnects:  0.00
[ 900s] threads: 64, tps: 0.00, reads: 0.00, writes: 71230.15, response time: 4.79ms (95%), errors: 0.00, reconnects:  0.00
[ 901s] threads: 64, tps: 0.00, reads: 0.00, writes: 71164.82, response time: 4.83ms (95%), errors: 0.00, reconnects:  0.00
[ 902s] threads: 64, tps: 0.00, reads: 0.00, writes: 66174.13, response time: 5.22ms (95%), errors: 0.00, reconnects:  0.00
[ 903s] threads: 64, tps: 0.00, reads: 0.00, writes: 61762.94, response time: 5.77ms (95%), errors: 0.00, reconnects:  0.00
[ 904s] threads: 64, tps: 0.00, reads: 0.00, writes: 63697.98, response time: 5.41ms (95%), errors: 0.00, reconnects:  0.00
[ 905s] threads: 64, tps: 0.00, reads: 0.00, writes: 65023.04, response time: 5.34ms (95%), errors: 0.00, reconnects:  0.00
[ 906s] threads: 64, tps: 0.00, reads: 0.00, writes: 60634.91, response time: 5.76ms (95%), errors: 0.00, reconnects:  0.00
[ 907s] threads: 64, tps: 0.00, reads: 0.00, writes: 59049.02, response time: 5.87ms (95%), errors: 0.00, reconnects:  0.00
[ 908s] threads: 64, tps: 0.00, reads: 0.00, writes: 60109.00, response time: 6.02ms (95%), errors: 0.00, reconnects:  0.00
[ 909s] threads: 64, tps: 0.00, reads: 0.00, writes: 61129.93, response time: 5.81ms (95%), errors: 0.00, reconnects:  0.00
[ 910s] threads: 64, tps: 0.00, reads: 0.00, writes: 58108.96, response time: 5.98ms (95%), errors: 0.00, reconnects:  0.00
[ 911s] threads: 64, tps: 0.00, reads: 0.00, writes: 57082.10, response time: 6.52ms (95%), errors: 0.00, reconnects:  0.00
[ 912s] threads: 64, tps: 0.00, reads: 0.00, writes: 61829.78, response time: 6.03ms (95%), errors: 0.00, reconnects:  0.00
[ 913s] threads: 64, tps: 0.00, reads: 0.00, writes: 64676.28, response time: 5.72ms (95%), errors: 0.00, reconnects:  0.00
[ 914s] threads: 64, tps: 0.00, reads: 0.00, writes: 65313.88, response time: 5.52ms (95%), errors: 0.00, reconnects:  0.00
[ 917s] threads: 64, tps: 0.00, reads: 0.00, writes: 60996.90, response time: 5.78ms (95%), errors: 0.00, reconnects:  0.00
[ 918s] threads: 64, tps: 0.00, reads: 0.00, writes: 702.67, response time: 20.48ms (95%), errors: 0.00, reconnects:  0.00
[ 919s] threads: 64, tps: 0.00, reads: 0.00, writes: 54089.25, response time: 6.01ms (95%), errors: 0.00, reconnects:  0.00
[ 920s] threads: 64, tps: 0.00, reads: 0.00, writes: 58861.18, response time: 5.47ms (95%), errors: 0.00, reconnects:  0.00
[ 921s] threads: 64, tps: 0.00, reads: 0.00, writes: 62006.99, response time: 5.30ms (95%), errors: 0.00, reconnects:  0.00
[ 922s] threads: 64, tps: 0.00, reads: 0.00, writes: 63271.84, response time: 5.39ms (95%), errors: 0.00, reconnects:  0.00
[ 923s] threads: 64, tps: 0.00, reads: 0.00, writes: 64648.11, response time: 5.38ms (95%), errors: 0.00, reconnects:  0.00
[ 924s] threads: 64, tps: 0.00, reads: 0.00, writes: 67957.91, response time: 5.02ms (95%), errors: 0.00, reconnects:  0.00
[ 925s] threads: 64, tps: 0.00, reads: 0.00, writes: 66843.95, response time: 5.15ms (95%), errors: 0.00, reconnects:  0.00
[ 926s] threads: 64, tps: 0.00, reads: 0.00, writes: 71713.16, response time: 4.55ms (95%), errors: 0.00, reconnects:  0.00
[ 927s] threads: 64, tps: 0.00, reads: 0.00, writes: 75474.87, response time: 4.43ms (95%), errors: 0.00, reconnects:  0.00
[ 928s] threads: 64, tps: 0.00, reads: 0.00, writes: 76456.97, response time: 4.07ms (95%), errors: 0.00, reconnects:  0.00
[ 929s] threads: 64, tps: 0.00, reads: 0.00, writes: 86804.82, response time: 3.43ms (95%), errors: 0.00, reconnects:  0.00
[ 930s] threads: 64, tps: 0.00, reads: 0.00, writes: 84267.76, response time: 3.71ms (95%), errors: 0.00, reconnects:  0.00
[ 931s] threads: 64, tps: 0.00, reads: 0.00, writes: 81588.21, response time: 3.87ms (95%), errors: 0.00, reconnects:  0.00
[ 932s] threads: 64, tps: 0.00, reads: 0.00, writes: 84278.97, response time: 3.78ms (95%), errors: 0.00, reconnects:  0.00
[ 933s] threads: 64, tps: 0.00, reads: 0.00, writes: 83528.25, response time: 3.93ms (95%), errors: 0.00, reconnects:  0.00
[ 934s] threads: 64, tps: 0.00, reads: 0.00, writes: 64642.23, response time: 5.48ms (95%), errors: 0.00, reconnects:  0.00
[ 935s] threads: 64, tps: 0.00, reads: 0.00, writes: 61475.10, response time: 5.56ms (95%), errors: 0.00, reconnects:  0.00
[ 936s] threads: 64, tps: 0.00, reads: 0.00, writes: 59777.35, response time: 5.75ms (95%), errors: 0.00, reconnects:  0.00
[ 937s] threads: 64, tps: 0.00, reads: 0.00, writes: 70886.80, response time: 4.49ms (95%), errors: 0.00, reconnects:  0.00
[ 938s] threads: 64, tps: 0.00, reads: 0.00, writes: 72067.28, response time: 4.57ms (95%), errors: 0.00, reconnects:  0.00
[ 939s] threads: 64, tps: 0.00, reads: 0.00, writes: 76694.03, response time: 4.32ms (95%), errors: 0.00, reconnects:  0.00
[ 940s] threads: 64, tps: 0.00, reads: 0.00, writes: 74375.31, response time: 4.45ms (95%), errors: 0.00, reconnects:  0.00
[ 941s] threads: 64, tps: 0.00, reads: 0.00, writes: 71495.12, response time: 4.68ms (95%), errors: 0.00, reconnects:  0.00
[ 942s] threads: 64, tps: 0.00, reads: 0.00, writes: 67585.52, response time: 5.18ms (95%), errors: 0.00, reconnects:  0.00
[ 943s] threads: 64, tps: 0.00, reads: 0.00, writes: 41782.97, response time: 4.72ms (95%), errors: 0.00, reconnects:  0.00
[ 944s] threads: 64, tps: 0.00, reads: 0.00, writes: 68626.93, response time: 4.81ms (95%), errors: 0.00, reconnects:  0.00
[ 945s] threads: 64, tps: 0.00, reads: 0.00, writes: 73003.03, response time: 4.51ms (95%), errors: 0.00, reconnects:  0.00
[ 946s] threads: 64, tps: 0.00, reads: 0.00, writes: 72212.89, response time: 4.28ms (95%), errors: 0.00, reconnects:  0.00
[ 947s] threads: 64, tps: 0.00, reads: 0.00, writes: 72428.94, response time: 4.62ms (95%), errors: 0.00, reconnects:  0.00
[ 948s] threads: 64, tps: 0.00, reads: 0.00, writes: 73978.37, response time: 4.39ms (95%), errors: 0.00, reconnects:  0.00
[ 949s] threads: 64, tps: 0.00, reads: 0.00, writes: 78917.06, response time: 4.18ms (95%), errors: 0.00, reconnects:  0.00
[ 950s] threads: 64, tps: 0.00, reads: 0.00, writes: 83870.86, response time: 3.76ms (95%), errors: 0.00, reconnects:  0.00
[ 951s] threads: 64, tps: 0.00, reads: 0.00, writes: 79535.94, response time: 4.21ms (95%), errors: 0.00, reconnects:  0.00
[ 952s] threads: 64, tps: 0.00, reads: 0.00, writes: 72128.05, response time: 4.59ms (95%), errors: 0.00, reconnects:  0.00
[ 953s] threads: 64, tps: 0.00, reads: 0.00, writes: 65032.03, response time: 5.34ms (95%), errors: 0.00, reconnects:  0.00
[ 954s] threads: 64, tps: 0.00, reads: 0.00, writes: 64262.98, response time: 5.40ms (95%), errors: 0.00, reconnects:  0.00
[ 955s] threads: 64, tps: 0.00, reads: 0.00, writes: 64513.03, response time: 5.29ms (95%), errors: 0.00, reconnects:  0.00
[ 956s] threads: 64, tps: 0.00, reads: 0.00, writes: 64723.05, response time: 5.35ms (95%), errors: 0.00, reconnects:  0.00
[ 957s] threads: 64, tps: 0.00, reads: 0.00, writes: 64151.90, response time: 5.41ms (95%), errors: 0.00, reconnects:  0.00
[ 958s] threads: 64, tps: 0.00, reads: 0.00, writes: 61036.12, response time: 5.68ms (95%), errors: 0.00, reconnects:  0.00
[ 959s] threads: 64, tps: 0.00, reads: 0.00, writes: 64029.87, response time: 5.35ms (95%), errors: 0.00, reconnects:  0.00
[ 960s] threads: 64, tps: 0.00, reads: 0.00, writes: 62967.03, response time: 5.67ms (95%), errors: 0.00, reconnects:  0.00
[ 961s] threads: 64, tps: 0.00, reads: 0.00, writes: 49557.99, response time: 5.56ms (95%), errors: 0.00, reconnects:  0.00
[ 962s] threads: 64, tps: 0.00, reads: 0.00, writes: 66490.91, response time: 5.01ms (95%), errors: 0.00, reconnects:  0.00
[ 963s] threads: 64, tps: 0.00, reads: 0.00, writes: 71212.10, response time: 4.69ms (95%), errors: 0.00, reconnects:  0.00
[ 964s] threads: 64, tps: 0.00, reads: 0.00, writes: 73506.12, response time: 4.71ms (95%), errors: 0.00, reconnects:  0.00
[ 965s] threads: 64, tps: 0.00, reads: 0.00, writes: 77839.82, response time: 4.34ms (95%), errors: 0.00, reconnects:  0.00
[ 966s] threads: 64, tps: 0.00, reads: 0.00, writes: 82798.03, response time: 3.95ms (95%), errors: 0.00, reconnects:  0.00
[ 967s] threads: 64, tps: 0.00, reads: 0.00, writes: 80307.10, response time: 3.88ms (95%), errors: 0.00, reconnects:  0.00
[ 968s] threads: 64, tps: 0.00, reads: 0.00, writes: 96310.04, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[ 969s] threads: 64, tps: 0.00, reads: 0.00, writes: 100620.89, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[ 970s] threads: 64, tps: 0.00, reads: 0.00, writes: 95030.07, response time: 3.37ms (95%), errors: 0.00, reconnects:  0.00
[ 971s] threads: 64, tps: 0.00, reads: 0.00, writes: 96623.88, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[ 972s] threads: 64, tps: 0.00, reads: 0.00, writes: 99347.96, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[ 973s] threads: 64, tps: 0.00, reads: 0.00, writes: 98804.09, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[ 974s] threads: 64, tps: 0.00, reads: 0.00, writes: 100481.96, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 975s] threads: 64, tps: 0.00, reads: 0.00, writes: 104722.93, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 976s] threads: 64, tps: 0.00, reads: 0.00, writes: 101646.10, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[ 977s] threads: 64, tps: 0.00, reads: 0.00, writes: 103609.95, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[ 978s] threads: 64, tps: 0.00, reads: 0.00, writes: 101381.07, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 979s] threads: 64, tps: 0.00, reads: 0.00, writes: 104836.98, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[ 980s] threads: 64, tps: 0.00, reads: 0.00, writes: 100585.02, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 981s] threads: 64, tps: 0.00, reads: 0.00, writes: 96607.85, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[ 982s] threads: 64, tps: 0.00, reads: 0.00, writes: 98362.41, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[ 983s] threads: 64, tps: 0.00, reads: 0.00, writes: 102795.15, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[ 984s] threads: 64, tps: 0.00, reads: 0.00, writes: 102406.48, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[ 985s] threads: 64, tps: 0.00, reads: 0.00, writes: 104099.06, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[ 986s] threads: 64, tps: 0.00, reads: 0.00, writes: 105544.12, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[ 987s] threads: 64, tps: 0.00, reads: 0.00, writes: 109580.23, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 988s] threads: 64, tps: 0.00, reads: 0.00, writes: 107296.66, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 989s] threads: 64, tps: 0.00, reads: 0.00, writes: 109946.67, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 990s] threads: 64, tps: 0.00, reads: 0.00, writes: 106362.04, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 991s] threads: 64, tps: 0.00, reads: 0.00, writes: 104799.52, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[ 992s] threads: 64, tps: 0.00, reads: 0.00, writes: 77950.67, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 993s] threads: 64, tps: 0.00, reads: 0.00, writes: 106659.58, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 994s] threads: 64, tps: 0.00, reads: 0.00, writes: 88862.80, response time: 3.73ms (95%), errors: 0.00, reconnects:  0.00
[ 995s] threads: 64, tps: 0.00, reads: 0.00, writes: 87973.04, response time: 3.79ms (95%), errors: 0.00, reconnects:  0.00
[ 996s] threads: 64, tps: 0.00, reads: 0.00, writes: 106189.02, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 997s] threads: 64, tps: 0.00, reads: 0.00, writes: 113198.99, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[ 998s] threads: 64, tps: 0.00, reads: 0.00, writes: 106439.01, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[ 999s] threads: 64, tps: 0.00, reads: 0.00, writes: 104893.95, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1000s] threads: 64, tps: 0.00, reads: 0.00, writes: 105529.54, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1001s] threads: 64, tps: 0.00, reads: 0.00, writes: 105288.45, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[1002s] threads: 64, tps: 0.00, reads: 0.00, writes: 103820.02, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[1003s] threads: 64, tps: 0.00, reads: 0.00, writes: 104462.98, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[1004s] threads: 64, tps: 0.00, reads: 0.00, writes: 108021.02, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1005s] threads: 64, tps: 0.00, reads: 0.00, writes: 111722.84, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1006s] threads: 64, tps: 0.00, reads: 0.00, writes: 113165.02, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1007s] threads: 64, tps: 0.00, reads: 0.00, writes: 108987.23, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1008s] threads: 64, tps: 0.00, reads: 0.00, writes: 109673.39, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[1009s] threads: 64, tps: 0.00, reads: 0.00, writes: 109519.36, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[1010s] threads: 64, tps: 0.00, reads: 0.00, writes: 107475.41, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1011s] threads: 64, tps: 0.00, reads: 0.00, writes: 106672.31, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[1012s] threads: 64, tps: 0.00, reads: 0.00, writes: 106100.90, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1013s] threads: 64, tps: 0.00, reads: 0.00, writes: 109718.91, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[1014s] threads: 64, tps: 0.00, reads: 0.00, writes: 104892.52, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1015s] threads: 64, tps: 0.00, reads: 0.00, writes: 108260.22, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[1016s] threads: 64, tps: 0.00, reads: 0.00, writes: 106643.37, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[1017s] threads: 64, tps: 0.00, reads: 0.00, writes: 106098.90, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1018s] threads: 64, tps: 0.00, reads: 0.00, writes: 92523.07, response time: 3.49ms (95%), errors: 0.00, reconnects:  0.00
[1019s] threads: 64, tps: 0.00, reads: 0.00, writes: 105079.40, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1020s] threads: 64, tps: 0.00, reads: 0.00, writes: 76932.48, response time: 3.72ms (95%), errors: 0.00, reconnects:  0.00
[1021s] threads: 64, tps: 0.00, reads: 0.00, writes: 39320.15, response time: 4.41ms (95%), errors: 0.00, reconnects:  0.00
[1022s] threads: 64, tps: 0.00, reads: 0.00, writes: 15388.37, response time: 5.39ms (95%), errors: 0.00, reconnects:  0.00
[1023s] threads: 64, tps: 0.00, reads: 0.00, writes: 22890.24, response time: 4.10ms (95%), errors: 0.00, reconnects:  0.00
[1024s] threads: 64, tps: 0.00, reads: 0.00, writes: 93301.74, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[1025s] threads: 64, tps: 0.00, reads: 0.00, writes: 99239.15, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[1026s] threads: 64, tps: 0.00, reads: 0.00, writes: 97134.96, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[1027s] threads: 64, tps: 0.00, reads: 0.00, writes: 102479.97, response time: 3.42ms (95%), errors: 0.00, reconnects:  0.00
[1028s] threads: 64, tps: 0.00, reads: 0.00, writes: 102148.07, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[1029s] threads: 64, tps: 0.00, reads: 0.00, writes: 97527.06, response time: 3.58ms (95%), errors: 0.00, reconnects:  0.00
[1030s] threads: 64, tps: 0.00, reads: 0.00, writes: 98034.12, response time: 3.53ms (95%), errors: 0.00, reconnects:  0.00
[1031s] threads: 64, tps: 0.00, reads: 0.00, writes: 101177.98, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[1032s] threads: 64, tps: 0.00, reads: 0.00, writes: 100811.97, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[1033s] threads: 64, tps: 0.00, reads: 0.00, writes: 98138.95, response time: 3.52ms (95%), errors: 0.00, reconnects:  0.00
[1034s] threads: 64, tps: 0.00, reads: 0.00, writes: 103272.94, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[1035s] threads: 64, tps: 0.00, reads: 0.00, writes: 102230.03, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[1036s] threads: 64, tps: 0.00, reads: 0.00, writes: 98022.76, response time: 3.58ms (95%), errors: 0.00, reconnects:  0.00
[1037s] threads: 64, tps: 0.00, reads: 0.00, writes: 100843.21, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[1038s] threads: 64, tps: 0.00, reads: 0.00, writes: 110055.04, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[1039s] threads: 64, tps: 0.00, reads: 0.00, writes: 111583.03, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1040s] threads: 64, tps: 0.00, reads: 0.00, writes: 108165.16, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1041s] threads: 64, tps: 0.00, reads: 0.00, writes: 111992.87, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1042s] threads: 64, tps: 0.00, reads: 0.00, writes: 107826.86, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[1043s] threads: 64, tps: 0.00, reads: 0.00, writes: 109947.17, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[1044s] threads: 64, tps: 0.00, reads: 0.00, writes: 110987.11, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[1045s] threads: 64, tps: 0.00, reads: 0.00, writes: 108804.93, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1046s] threads: 64, tps: 0.00, reads: 0.00, writes: 110789.95, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1047s] threads: 64, tps: 0.00, reads: 0.00, writes: 112695.82, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[1048s] threads: 64, tps: 0.00, reads: 0.00, writes: 110645.32, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1049s] threads: 64, tps: 0.00, reads: 0.00, writes: 113622.90, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1050s] threads: 64, tps: 0.00, reads: 0.00, writes: 109088.09, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[1051s] threads: 64, tps: 0.00, reads: 0.00, writes: 109449.17, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1052s] threads: 64, tps: 0.00, reads: 0.00, writes: 114728.79, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1053s] threads: 64, tps: 0.00, reads: 0.00, writes: 107233.09, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[1054s] threads: 64, tps: 0.00, reads: 0.00, writes: 111682.85, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[1055s] threads: 64, tps: 0.00, reads: 0.00, writes: 111437.45, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[1056s] threads: 64, tps: 0.00, reads: 0.00, writes: 108361.59, response time: 3.34ms (95%), errors: 0.00, reconnects:  0.00
[1057s] threads: 64, tps: 0.00, reads: 0.00, writes: 112148.83, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1058s] threads: 64, tps: 0.00, reads: 0.00, writes: 111052.43, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[1059s] threads: 64, tps: 0.00, reads: 0.00, writes: 109832.95, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1060s] threads: 64, tps: 0.00, reads: 0.00, writes: 111377.82, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[1061s] threads: 64, tps: 0.00, reads: 0.00, writes: 112868.96, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[1062s] threads: 64, tps: 0.00, reads: 0.00, writes: 112479.91, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1063s] threads: 64, tps: 0.00, reads: 0.00, writes: 112754.04, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1064s] threads: 64, tps: 0.00, reads: 0.00, writes: 109871.87, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[1065s] threads: 64, tps: 0.00, reads: 0.00, writes: 110738.05, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1066s] threads: 64, tps: 0.00, reads: 0.00, writes: 112385.15, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1067s] threads: 64, tps: 0.00, reads: 0.00, writes: 113282.95, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1068s] threads: 64, tps: 0.00, reads: 0.00, writes: 110678.06, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[1069s] threads: 64, tps: 0.00, reads: 0.00, writes: 111464.75, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[1070s] threads: 64, tps: 0.00, reads: 0.00, writes: 111896.10, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[1071s] threads: 64, tps: 0.00, reads: 0.00, writes: 111607.98, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[1072s] threads: 64, tps: 0.00, reads: 0.00, writes: 112789.22, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1073s] threads: 64, tps: 0.00, reads: 0.00, writes: 114174.05, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1074s] threads: 64, tps: 0.00, reads: 0.00, writes: 110283.15, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[1075s] threads: 64, tps: 0.00, reads: 0.00, writes: 111720.53, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[1076s] threads: 64, tps: 0.00, reads: 0.00, writes: 111611.90, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1077s] threads: 64, tps: 0.00, reads: 0.00, writes: 114007.15, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1078s] threads: 64, tps: 0.00, reads: 0.00, writes: 111092.99, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1079s] threads: 64, tps: 0.00, reads: 0.00, writes: 100802.95, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[1080s] threads: 64, tps: 0.00, reads: 0.00, writes: 112649.01, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[1081s] threads: 64, tps: 0.00, reads: 0.00, writes: 112512.05, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1082s] threads: 64, tps: 0.00, reads: 0.00, writes: 115124.93, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[1083s] threads: 64, tps: 0.00, reads: 0.00, writes: 106353.72, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1084s] threads: 64, tps: 0.00, reads: 0.00, writes: 107253.60, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1085s] threads: 64, tps: 0.00, reads: 0.00, writes: 108832.78, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1086s] threads: 64, tps: 0.00, reads: 0.00, writes: 108183.03, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1087s] threads: 64, tps: 0.00, reads: 0.00, writes: 116712.96, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1088s] threads: 64, tps: 0.00, reads: 0.00, writes: 116738.10, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1089s] threads: 64, tps: 0.00, reads: 0.00, writes: 114902.92, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1090s] threads: 64, tps: 0.00, reads: 0.00, writes: 113023.04, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1091s] threads: 64, tps: 0.00, reads: 0.00, writes: 109552.80, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1092s] threads: 64, tps: 0.00, reads: 0.00, writes: 113693.14, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1093s] threads: 64, tps: 0.00, reads: 0.00, writes: 113484.59, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[1094s] threads: 64, tps: 0.00, reads: 0.00, writes: 115746.42, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1095s] threads: 64, tps: 0.00, reads: 0.00, writes: 115993.95, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1096s] threads: 64, tps: 0.00, reads: 0.00, writes: 115373.11, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1097s] threads: 64, tps: 0.00, reads: 0.00, writes: 113769.87, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1098s] threads: 64, tps: 0.00, reads: 0.00, writes: 116749.50, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1099s] threads: 64, tps: 0.00, reads: 0.00, writes: 115435.09, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1100s] threads: 64, tps: 0.00, reads: 0.00, writes: 113607.50, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1101s] threads: 64, tps: 0.00, reads: 0.00, writes: 115333.96, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1102s] threads: 64, tps: 0.00, reads: 0.00, writes: 113692.16, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1103s] threads: 64, tps: 0.00, reads: 0.00, writes: 115696.42, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1104s] threads: 64, tps: 0.00, reads: 0.00, writes: 116778.57, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1105s] threads: 64, tps: 0.00, reads: 0.00, writes: 116642.92, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1106s] threads: 64, tps: 0.00, reads: 0.00, writes: 114744.87, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1107s] threads: 64, tps: 0.00, reads: 0.00, writes: 116357.95, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[1108s] threads: 64, tps: 0.00, reads: 0.00, writes: 116879.04, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1109s] threads: 64, tps: 0.00, reads: 0.00, writes: 113759.91, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1110s] threads: 64, tps: 0.00, reads: 0.00, writes: 114833.25, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1111s] threads: 64, tps: 0.00, reads: 0.00, writes: 115555.36, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1112s] threads: 64, tps: 0.00, reads: 0.00, writes: 114652.54, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1113s] threads: 64, tps: 0.00, reads: 0.00, writes: 113782.78, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1114s] threads: 64, tps: 0.00, reads: 0.00, writes: 111819.18, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1115s] threads: 64, tps: 0.00, reads: 0.00, writes: 115983.17, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1116s] threads: 64, tps: 0.00, reads: 0.00, writes: 114770.85, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1117s] threads: 64, tps: 0.00, reads: 0.00, writes: 115641.96, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1118s] threads: 64, tps: 0.00, reads: 0.00, writes: 115329.02, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1119s] threads: 64, tps: 0.00, reads: 0.00, writes: 116143.05, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1120s] threads: 64, tps: 0.00, reads: 0.00, writes: 116225.89, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1121s] threads: 64, tps: 0.00, reads: 0.00, writes: 115542.12, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1122s] threads: 64, tps: 0.00, reads: 0.00, writes: 113642.70, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1123s] threads: 64, tps: 0.00, reads: 0.00, writes: 115929.23, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1124s] threads: 64, tps: 0.00, reads: 0.00, writes: 115135.89, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1125s] threads: 64, tps: 0.00, reads: 0.00, writes: 115916.15, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1126s] threads: 64, tps: 0.00, reads: 0.00, writes: 115001.96, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1127s] threads: 64, tps: 0.00, reads: 0.00, writes: 114370.99, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1128s] threads: 64, tps: 0.00, reads: 0.00, writes: 116090.94, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1129s] threads: 64, tps: 0.00, reads: 0.00, writes: 115516.08, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1130s] threads: 64, tps: 0.00, reads: 0.00, writes: 115219.19, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1131s] threads: 64, tps: 0.00, reads: 0.00, writes: 115127.89, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1132s] threads: 64, tps: 0.00, reads: 0.00, writes: 115206.02, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1133s] threads: 64, tps: 0.00, reads: 0.00, writes: 113833.71, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[1134s] threads: 64, tps: 0.00, reads: 0.00, writes: 113634.40, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1135s] threads: 64, tps: 0.00, reads: 0.00, writes: 112665.90, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1136s] threads: 64, tps: 0.00, reads: 0.00, writes: 114503.84, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[1137s] threads: 64, tps: 0.00, reads: 0.00, writes: 114440.19, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1138s] threads: 64, tps: 0.00, reads: 0.00, writes: 115380.96, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[1139s] threads: 64, tps: 0.00, reads: 0.00, writes: 114140.99, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1140s] threads: 64, tps: 0.00, reads: 0.00, writes: 114985.92, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1141s] threads: 64, tps: 0.00, reads: 0.00, writes: 116158.08, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1142s] threads: 64, tps: 0.00, reads: 0.00, writes: 115688.04, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1143s] threads: 64, tps: 0.00, reads: 0.00, writes: 116296.81, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1144s] threads: 64, tps: 0.00, reads: 0.00, writes: 113062.13, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1145s] threads: 64, tps: 0.00, reads: 0.00, writes: 114585.02, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[1146s] threads: 64, tps: 0.00, reads: 0.00, writes: 113882.99, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1147s] threads: 64, tps: 0.00, reads: 0.00, writes: 113942.10, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[1148s] threads: 64, tps: 0.00, reads: 0.00, writes: 116157.97, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1149s] threads: 64, tps: 0.00, reads: 0.00, writes: 115180.08, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1150s] threads: 64, tps: 0.00, reads: 0.00, writes: 114977.89, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1151s] threads: 64, tps: 0.00, reads: 0.00, writes: 112392.95, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1152s] threads: 64, tps: 0.00, reads: 0.00, writes: 114271.10, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1153s] threads: 64, tps: 0.00, reads: 0.00, writes: 115027.95, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1154s] threads: 64, tps: 0.00, reads: 0.00, writes: 115867.00, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1155s] threads: 64, tps: 0.00, reads: 0.00, writes: 115684.18, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1156s] threads: 64, tps: 0.00, reads: 0.00, writes: 115912.83, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1157s] threads: 64, tps: 0.00, reads: 0.00, writes: 115110.44, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1158s] threads: 64, tps: 0.00, reads: 0.00, writes: 114674.67, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1159s] threads: 64, tps: 0.00, reads: 0.00, writes: 114881.38, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1160s] threads: 64, tps: 0.00, reads: 0.00, writes: 112729.37, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[1161s] threads: 64, tps: 0.00, reads: 0.00, writes: 115365.89, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1162s] threads: 64, tps: 0.00, reads: 0.00, writes: 114878.28, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1163s] threads: 64, tps: 0.00, reads: 0.00, writes: 112536.93, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1164s] threads: 64, tps: 0.00, reads: 0.00, writes: 114604.05, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1165s] threads: 64, tps: 0.00, reads: 0.00, writes: 115473.01, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1166s] threads: 64, tps: 0.00, reads: 0.00, writes: 115591.00, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1167s] threads: 64, tps: 0.00, reads: 0.00, writes: 113946.93, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1168s] threads: 64, tps: 0.00, reads: 0.00, writes: 113992.05, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1169s] threads: 64, tps: 0.00, reads: 0.00, writes: 115588.05, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1170s] threads: 64, tps: 0.00, reads: 0.00, writes: 115050.28, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1171s] threads: 64, tps: 0.00, reads: 0.00, writes: 114674.63, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1172s] threads: 64, tps: 0.00, reads: 0.00, writes: 116048.46, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1173s] threads: 64, tps: 0.00, reads: 0.00, writes: 113863.70, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1174s] threads: 64, tps: 0.00, reads: 0.00, writes: 114292.04, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1175s] threads: 64, tps: 0.00, reads: 0.00, writes: 115666.95, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1176s] threads: 64, tps: 0.00, reads: 0.00, writes: 115895.95, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1177s] threads: 64, tps: 0.00, reads: 0.00, writes: 116063.95, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1178s] threads: 64, tps: 0.00, reads: 0.00, writes: 116723.64, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1179s] threads: 64, tps: 0.00, reads: 0.00, writes: 113482.29, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1180s] threads: 64, tps: 0.00, reads: 0.00, writes: 116376.34, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1181s] threads: 64, tps: 0.00, reads: 0.00, writes: 115893.72, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1182s] threads: 64, tps: 0.00, reads: 0.00, writes: 116839.93, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1183s] threads: 64, tps: 0.00, reads: 0.00, writes: 115932.97, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1184s] threads: 64, tps: 0.00, reads: 0.00, writes: 115187.01, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1185s] threads: 64, tps: 0.00, reads: 0.00, writes: 116366.75, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1186s] threads: 64, tps: 0.00, reads: 0.00, writes: 116034.38, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1187s] threads: 64, tps: 0.00, reads: 0.00, writes: 116506.82, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1188s] threads: 64, tps: 0.00, reads: 0.00, writes: 115923.38, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1189s] threads: 64, tps: 0.00, reads: 0.00, writes: 115448.79, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1190s] threads: 64, tps: 0.00, reads: 0.00, writes: 113991.86, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[1191s] threads: 64, tps: 0.00, reads: 0.00, writes: 115028.85, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1192s] threads: 64, tps: 0.00, reads: 0.00, writes: 116387.07, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1193s] threads: 64, tps: 0.00, reads: 0.00, writes: 116130.11, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1194s] threads: 64, tps: 0.00, reads: 0.00, writes: 115421.94, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1195s] threads: 64, tps: 0.00, reads: 0.00, writes: 116657.07, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[1196s] threads: 64, tps: 0.00, reads: 0.00, writes: 114393.79, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1197s] threads: 64, tps: 0.00, reads: 0.00, writes: 117141.23, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1198s] threads: 64, tps: 0.00, reads: 0.00, writes: 117093.06, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1199s] threads: 64, tps: 0.00, reads: 0.00, writes: 116139.84, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[1200s] threads: 64, tps: 0.00, reads: 0.00, writes: 118196.90, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1201s] threads: 64, tps: 0.00, reads: 0.00, writes: 115471.82, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[1202s] threads: 64, tps: 0.00, reads: 0.00, writes: 117053.40, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1203s] threads: 64, tps: 0.00, reads: 0.00, writes: 117798.85, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1204s] threads: 64, tps: 0.00, reads: 0.00, writes: 114475.14, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[1205s] threads: 64, tps: 0.00, reads: 0.00, writes: 114617.00, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1206s] threads: 64, tps: 0.00, reads: 0.00, writes: 115708.95, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1207s] threads: 64, tps: 0.00, reads: 0.00, writes: 112982.79, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[1208s] threads: 64, tps: 0.00, reads: 0.00, writes: 116960.08, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[1209s] threads: 64, tps: 0.00, reads: 0.00, writes: 116886.57, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1210s] threads: 64, tps: 0.00, reads: 0.00, writes: 116279.87, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1211s] threads: 64, tps: 0.00, reads: 0.00, writes: 116637.06, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1212s] threads: 64, tps: 0.00, reads: 0.00, writes: 115426.95, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1213s] threads: 64, tps: 0.00, reads: 0.00, writes: 115718.09, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[1214s] threads: 64, tps: 0.00, reads: 0.00, writes: 114066.92, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[1215s] threads: 64, tps: 0.00, reads: 0.00, writes: 115632.06, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1216s] threads: 64, tps: 0.00, reads: 0.00, writes: 113727.05, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[1217s] threads: 64, tps: 0.00, reads: 0.00, writes: 114422.70, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1218s] threads: 64, tps: 0.00, reads: 0.00, writes: 116173.29, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1219s] threads: 64, tps: 0.00, reads: 0.00, writes: 115587.85, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1220s] threads: 64, tps: 0.00, reads: 0.00, writes: 116002.02, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1221s] threads: 64, tps: 0.00, reads: 0.00, writes: 115910.94, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1222s] threads: 64, tps: 0.00, reads: 0.00, writes: 116227.20, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1223s] threads: 64, tps: 0.00, reads: 0.00, writes: 116074.91, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1224s] threads: 64, tps: 0.00, reads: 0.00, writes: 116109.01, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[1225s] threads: 64, tps: 0.00, reads: 0.00, writes: 117610.87, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1226s] threads: 64, tps: 0.00, reads: 0.00, writes: 116144.87, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1227s] threads: 64, tps: 0.00, reads: 0.00, writes: 115862.33, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[1228s] threads: 64, tps: 0.00, reads: 0.00, writes: 116661.95, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1229s] threads: 64, tps: 0.00, reads: 0.00, writes: 114175.05, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[1230s] threads: 64, tps: 0.00, reads: 0.00, writes: 116684.88, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1231s] threads: 64, tps: 0.00, reads: 0.00, writes: 115050.03, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1232s] threads: 64, tps: 0.00, reads: 0.00, writes: 116039.21, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1233s] threads: 64, tps: 0.00, reads: 0.00, writes: 113364.99, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1234s] threads: 64, tps: 0.00, reads: 0.00, writes: 112176.85, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1235s] threads: 64, tps: 0.00, reads: 0.00, writes: 115679.08, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1236s] threads: 64, tps: 0.00, reads: 0.00, writes: 117484.38, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1237s] threads: 64, tps: 0.00, reads: 0.00, writes: 118920.72, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1238s] threads: 64, tps: 0.00, reads: 0.00, writes: 119548.90, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1239s] threads: 64, tps: 0.00, reads: 0.00, writes: 115887.96, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1240s] threads: 64, tps: 0.00, reads: 0.00, writes: 115923.35, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1241s] threads: 64, tps: 0.00, reads: 0.00, writes: 113550.60, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1242s] threads: 64, tps: 0.00, reads: 0.00, writes: 114689.99, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[1243s] threads: 64, tps: 0.00, reads: 0.00, writes: 113615.99, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1244s] threads: 64, tps: 0.00, reads: 0.00, writes: 116098.96, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1245s] threads: 64, tps: 0.00, reads: 0.00, writes: 111038.01, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1246s] threads: 64, tps: 0.00, reads: 0.00, writes: 112870.81, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1247s] threads: 64, tps: 0.00, reads: 0.00, writes: 114900.19, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1248s] threads: 64, tps: 0.00, reads: 0.00, writes: 116926.54, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1249s] threads: 64, tps: 0.00, reads: 0.00, writes: 116982.56, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1250s] threads: 64, tps: 0.00, reads: 0.00, writes: 115549.70, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1251s] threads: 64, tps: 0.00, reads: 0.00, writes: 117630.10, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1252s] threads: 64, tps: 0.00, reads: 0.00, writes: 115783.47, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1253s] threads: 64, tps: 0.00, reads: 0.00, writes: 115866.41, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1254s] threads: 64, tps: 0.00, reads: 0.00, writes: 116816.18, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1255s] threads: 64, tps: 0.00, reads: 0.00, writes: 117276.31, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1256s] threads: 64, tps: 0.00, reads: 0.00, writes: 117196.55, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1257s] threads: 64, tps: 0.00, reads: 0.00, writes: 117575.18, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1258s] threads: 64, tps: 0.00, reads: 0.00, writes: 118337.90, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1259s] threads: 64, tps: 0.00, reads: 0.00, writes: 118339.08, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1260s] threads: 64, tps: 0.00, reads: 0.00, writes: 118001.81, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1261s] threads: 64, tps: 0.00, reads: 0.00, writes: 117518.14, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[1262s] threads: 64, tps: 0.00, reads: 0.00, writes: 118672.12, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1263s] threads: 64, tps: 0.00, reads: 0.00, writes: 119636.67, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1264s] threads: 64, tps: 0.00, reads: 0.00, writes: 119055.33, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1265s] threads: 64, tps: 0.00, reads: 0.00, writes: 117423.94, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1266s] threads: 64, tps: 0.00, reads: 0.00, writes: 118784.92, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1266s] threads: 64, tps: 0.00, reads: 0.00, writes: 120669.58, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1268s] threads: 64, tps: 0.00, reads: 0.00, writes: 118139.03, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1269s] threads: 64, tps: 0.00, reads: 0.00, writes: 118019.24, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1270s] threads: 64, tps: 0.00, reads: 0.00, writes: 112176.17, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1271s] threads: 64, tps: 0.00, reads: 0.00, writes: 117408.86, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1272s] threads: 64, tps: 0.00, reads: 0.00, writes: 116934.68, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1273s] threads: 64, tps: 0.00, reads: 0.00, writes: 114774.63, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[1274s] threads: 64, tps: 0.00, reads: 0.00, writes: 115785.41, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1275s] threads: 64, tps: 0.00, reads: 0.00, writes: 116867.35, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1276s] threads: 64, tps: 0.00, reads: 0.00, writes: 118079.04, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1277s] threads: 64, tps: 0.00, reads: 0.00, writes: 117151.01, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1278s] threads: 64, tps: 0.00, reads: 0.00, writes: 116109.04, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1279s] threads: 64, tps: 0.00, reads: 0.00, writes: 117658.86, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1280s] threads: 64, tps: 0.00, reads: 0.00, writes: 115331.03, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1281s] threads: 64, tps: 0.00, reads: 0.00, writes: 107183.05, response time: 3.34ms (95%), errors: 0.00, reconnects:  0.00
[1282s] threads: 64, tps: 0.00, reads: 0.00, writes: 114652.92, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1283s] threads: 64, tps: 0.00, reads: 0.00, writes: 112313.25, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[1284s] threads: 64, tps: 0.00, reads: 0.00, writes: 115035.91, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[1285s] threads: 64, tps: 0.00, reads: 0.00, writes: 116420.99, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1286s] threads: 64, tps: 0.00, reads: 0.00, writes: 117808.09, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1287s] threads: 64, tps: 0.00, reads: 0.00, writes: 117671.78, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1288s] threads: 64, tps: 0.00, reads: 0.00, writes: 114612.99, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[1289s] threads: 64, tps: 0.00, reads: 0.00, writes: 115440.16, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[1290s] threads: 64, tps: 0.00, reads: 0.00, writes: 115754.97, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1291s] threads: 64, tps: 0.00, reads: 0.00, writes: 114776.92, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1292s] threads: 64, tps: 0.00, reads: 0.00, writes: 119742.92, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1293s] threads: 64, tps: 0.00, reads: 0.00, writes: 114207.08, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1294s] threads: 64, tps: 0.00, reads: 0.00, writes: 118253.96, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1295s] threads: 64, tps: 0.00, reads: 0.00, writes: 115708.22, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1296s] threads: 64, tps: 0.00, reads: 0.00, writes: 117821.96, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1297s] threads: 64, tps: 0.00, reads: 0.00, writes: 117616.90, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1298s] threads: 64, tps: 0.00, reads: 0.00, writes: 117715.05, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1299s] threads: 64, tps: 0.00, reads: 0.00, writes: 117939.21, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1300s] threads: 64, tps: 0.00, reads: 0.00, writes: 120335.94, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1301s] threads: 64, tps: 0.00, reads: 0.00, writes: 118852.43, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1302s] threads: 64, tps: 0.00, reads: 0.00, writes: 116473.48, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1303s] threads: 64, tps: 0.00, reads: 0.00, writes: 118544.22, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[1304s] threads: 64, tps: 0.00, reads: 0.00, writes: 115494.70, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[1305s] threads: 64, tps: 0.00, reads: 0.00, writes: 116397.67, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1306s] threads: 64, tps: 0.00, reads: 0.00, writes: 118206.77, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1307s] threads: 64, tps: 0.00, reads: 0.00, writes: 117295.50, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1308s] threads: 64, tps: 0.00, reads: 0.00, writes: 118966.14, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1309s] threads: 64, tps: 0.00, reads: 0.00, writes: 116777.87, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[1310s] threads: 64, tps: 0.00, reads: 0.00, writes: 117222.91, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1311s] threads: 64, tps: 0.00, reads: 0.00, writes: 117603.11, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1312s] threads: 64, tps: 0.00, reads: 0.00, writes: 115202.18, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1313s] threads: 64, tps: 0.00, reads: 0.00, writes: 118231.73, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1314s] threads: 64, tps: 0.00, reads: 0.00, writes: 119494.08, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1315s] threads: 64, tps: 0.00, reads: 0.00, writes: 117837.81, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1316s] threads: 64, tps: 0.00, reads: 0.00, writes: 118520.47, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1317s] threads: 64, tps: 0.00, reads: 0.00, writes: 118858.66, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1318s] threads: 64, tps: 0.00, reads: 0.00, writes: 118597.27, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1319s] threads: 64, tps: 0.00, reads: 0.00, writes: 119207.51, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1320s] threads: 64, tps: 0.00, reads: 0.00, writes: 115343.93, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[1321s] threads: 64, tps: 0.00, reads: 0.00, writes: 114995.35, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1322s] threads: 64, tps: 0.00, reads: 0.00, writes: 120115.05, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1323s] threads: 64, tps: 0.00, reads: 0.00, writes: 119500.87, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1324s] threads: 64, tps: 0.00, reads: 0.00, writes: 116175.87, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1325s] threads: 64, tps: 0.00, reads: 0.00, writes: 117207.19, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[1326s] threads: 64, tps: 0.00, reads: 0.00, writes: 114452.15, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[1327s] threads: 64, tps: 0.00, reads: 0.00, writes: 118910.90, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1328s] threads: 64, tps: 0.00, reads: 0.00, writes: 117914.52, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1329s] threads: 64, tps: 0.00, reads: 0.00, writes: 119030.03, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1330s] threads: 64, tps: 0.00, reads: 0.00, writes: 117147.11, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[1331s] threads: 64, tps: 0.00, reads: 0.00, writes: 117425.26, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[1332s] threads: 64, tps: 0.00, reads: 0.00, writes: 117729.09, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1333s] threads: 64, tps: 0.00, reads: 0.00, writes: 116923.97, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1334s] threads: 64, tps: 0.00, reads: 0.00, writes: 115340.37, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1335s] threads: 64, tps: 0.00, reads: 0.00, writes: 118119.73, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1336s] threads: 64, tps: 0.00, reads: 0.00, writes: 114228.89, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[1337s] threads: 64, tps: 0.00, reads: 0.00, writes: 116342.88, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1338s] threads: 64, tps: 0.00, reads: 0.00, writes: 109979.25, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1339s] threads: 64, tps: 0.00, reads: 0.00, writes: 109731.97, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1340s] threads: 64, tps: 0.00, reads: 0.00, writes: 114863.92, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1341s] threads: 64, tps: 0.00, reads: 0.00, writes: 115476.10, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1342s] threads: 64, tps: 0.00, reads: 0.00, writes: 118761.90, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1343s] threads: 64, tps: 0.00, reads: 0.00, writes: 116818.03, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1344s] threads: 64, tps: 0.00, reads: 0.00, writes: 119909.09, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1345s] threads: 64, tps: 0.00, reads: 0.00, writes: 117897.86, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1346s] threads: 64, tps: 0.00, reads: 0.00, writes: 118061.01, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1347s] threads: 64, tps: 0.00, reads: 0.00, writes: 118026.72, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1348s] threads: 64, tps: 0.00, reads: 0.00, writes: 118875.37, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1349s] threads: 64, tps: 0.00, reads: 0.00, writes: 118279.01, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1350s] threads: 64, tps: 0.00, reads: 0.00, writes: 118421.95, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1351s] threads: 64, tps: 0.00, reads: 0.00, writes: 118278.03, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1352s] threads: 64, tps: 0.00, reads: 0.00, writes: 118919.96, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1353s] threads: 64, tps: 0.00, reads: 0.00, writes: 119112.00, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1354s] threads: 64, tps: 0.00, reads: 0.00, writes: 120437.05, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[1355s] threads: 64, tps: 0.00, reads: 0.00, writes: 119881.08, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1356s] threads: 64, tps: 0.00, reads: 0.00, writes: 119368.89, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1357s] threads: 64, tps: 0.00, reads: 0.00, writes: 118424.07, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1358s] threads: 64, tps: 0.00, reads: 0.00, writes: 119617.86, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1359s] threads: 64, tps: 0.00, reads: 0.00, writes: 114172.08, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[1360s] threads: 64, tps: 0.00, reads: 0.00, writes: 119972.03, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[1361s] threads: 64, tps: 0.00, reads: 0.00, writes: 117242.78, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1362s] threads: 64, tps: 0.00, reads: 0.00, writes: 119019.25, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[1363s] threads: 64, tps: 0.00, reads: 0.00, writes: 117935.98, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1364s] threads: 64, tps: 0.00, reads: 0.00, writes: 118367.00, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1365s] threads: 64, tps: 0.00, reads: 0.00, writes: 119318.77, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1366s] threads: 64, tps: 0.00, reads: 0.00, writes: 117410.62, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1367s] threads: 64, tps: 0.00, reads: 0.00, writes: 117783.57, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[1368s] threads: 64, tps: 0.00, reads: 0.00, writes: 118635.98, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[1369s] threads: 64, tps: 0.00, reads: 0.00, writes: 117623.91, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1370s] threads: 64, tps: 0.00, reads: 0.00, writes: 117649.94, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1371s] threads: 64, tps: 0.00, reads: 0.00, writes: 117861.15, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1372s] threads: 64, tps: 0.00, reads: 0.00, writes: 117999.90, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1373s] threads: 64, tps: 0.00, reads: 0.00, writes: 117982.02, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1374s] threads: 64, tps: 0.00, reads: 0.00, writes: 118246.99, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1375s] threads: 64, tps: 0.00, reads: 0.00, writes: 118797.10, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1376s] threads: 64, tps: 0.00, reads: 0.00, writes: 119337.90, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1377s] threads: 64, tps: 0.00, reads: 0.00, writes: 117415.08, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1378s] threads: 64, tps: 0.00, reads: 0.00, writes: 118245.99, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1379s] threads: 64, tps: 0.00, reads: 0.00, writes: 117830.89, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1380s] threads: 64, tps: 0.00, reads: 0.00, writes: 117605.11, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1381s] threads: 64, tps: 0.00, reads: 0.00, writes: 117477.90, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1382s] threads: 64, tps: 0.00, reads: 0.00, writes: 118690.17, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[1383s] threads: 64, tps: 0.00, reads: 0.00, writes: 115203.85, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[1384s] threads: 64, tps: 0.00, reads: 0.00, writes: 117378.11, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1385s] threads: 64, tps: 0.00, reads: 0.00, writes: 118336.94, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1386s] threads: 64, tps: 0.00, reads: 0.00, writes: 118935.13, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1387s] threads: 64, tps: 0.00, reads: 0.00, writes: 117958.91, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1388s] threads: 64, tps: 0.00, reads: 0.00, writes: 117844.92, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1389s] threads: 64, tps: 0.00, reads: 0.00, writes: 117177.72, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[1390s] threads: 64, tps: 0.00, reads: 0.00, writes: 116757.36, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[1391s] threads: 64, tps: 0.00, reads: 0.00, writes: 119453.00, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1392s] threads: 64, tps: 0.00, reads: 0.00, writes: 118791.03, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1393s] threads: 64, tps: 0.00, reads: 0.00, writes: 117208.67, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1394s] threads: 64, tps: 0.00, reads: 0.00, writes: 117960.33, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1395s] threads: 64, tps: 0.00, reads: 0.00, writes: 115044.90, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1396s] threads: 64, tps: 0.00, reads: 0.00, writes: 117766.17, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[1397s] threads: 64, tps: 0.00, reads: 0.00, writes: 119112.06, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1398s] threads: 64, tps: 0.00, reads: 0.00, writes: 117502.90, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1399s] threads: 64, tps: 0.00, reads: 0.00, writes: 115651.92, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1400s] threads: 64, tps: 0.00, reads: 0.00, writes: 116390.08, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1401s] threads: 64, tps: 0.00, reads: 0.00, writes: 115398.17, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1402s] threads: 64, tps: 0.00, reads: 0.00, writes: 118036.91, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1403s] threads: 64, tps: 0.00, reads: 0.00, writes: 121692.81, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1404s] threads: 64, tps: 0.00, reads: 0.00, writes: 119652.73, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1405s] threads: 64, tps: 0.00, reads: 0.00, writes: 120162.32, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1406s] threads: 64, tps: 0.00, reads: 0.00, writes: 125562.03, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1407s] threads: 64, tps: 0.00, reads: 0.00, writes: 123015.94, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1408s] threads: 64, tps: 0.00, reads: 0.00, writes: 118730.09, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1409s] threads: 64, tps: 0.00, reads: 0.00, writes: 118660.77, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1410s] threads: 64, tps: 0.00, reads: 0.00, writes: 120106.22, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1411s] threads: 64, tps: 0.00, reads: 0.00, writes: 117053.99, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1412s] threads: 64, tps: 0.00, reads: 0.00, writes: 121025.13, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1413s] threads: 64, tps: 0.00, reads: 0.00, writes: 121172.82, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1414s] threads: 64, tps: 0.00, reads: 0.00, writes: 120548.12, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1415s] threads: 64, tps: 0.00, reads: 0.00, writes: 120708.14, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[1416s] threads: 64, tps: 0.00, reads: 0.00, writes: 119572.87, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1417s] threads: 64, tps: 0.00, reads: 0.00, writes: 120224.04, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1418s] threads: 64, tps: 0.00, reads: 0.00, writes: 120537.97, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1419s] threads: 64, tps: 0.00, reads: 0.00, writes: 109947.89, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1420s] threads: 64, tps: 0.00, reads: 0.00, writes: 113169.10, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1421s] threads: 64, tps: 0.00, reads: 0.00, writes: 110796.93, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1422s] threads: 64, tps: 0.00, reads: 0.00, writes: 112207.11, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[1423s] threads: 64, tps: 0.00, reads: 0.00, writes: 113796.83, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1424s] threads: 64, tps: 0.00, reads: 0.00, writes: 111562.09, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1425s] threads: 64, tps: 0.00, reads: 0.00, writes: 116715.01, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1426s] threads: 64, tps: 0.00, reads: 0.00, writes: 114737.94, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[1427s] threads: 64, tps: 0.00, reads: 0.00, writes: 111056.66, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1428s] threads: 64, tps: 0.00, reads: 0.00, writes: 115030.07, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1429s] threads: 64, tps: 0.00, reads: 0.00, writes: 113748.12, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[1430s] threads: 64, tps: 0.00, reads: 0.00, writes: 115138.73, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1431s] threads: 64, tps: 0.00, reads: 0.00, writes: 116471.23, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[1432s] threads: 64, tps: 0.00, reads: 0.00, writes: 116168.94, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1433s] threads: 64, tps: 0.00, reads: 0.00, writes: 116126.91, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1434s] threads: 64, tps: 0.00, reads: 0.00, writes: 116961.05, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1435s] threads: 64, tps: 0.00, reads: 0.00, writes: 115904.05, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1436s] threads: 64, tps: 0.00, reads: 0.00, writes: 116590.99, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1437s] threads: 64, tps: 0.00, reads: 0.00, writes: 119339.95, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1438s] threads: 64, tps: 0.00, reads: 0.00, writes: 117422.06, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1439s] threads: 64, tps: 0.00, reads: 0.00, writes: 114305.00, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1440s] threads: 64, tps: 0.00, reads: 0.00, writes: 117546.91, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1441s] threads: 64, tps: 0.00, reads: 0.00, writes: 113606.94, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[1442s] threads: 64, tps: 0.00, reads: 0.00, writes: 112102.19, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1443s] threads: 64, tps: 0.00, reads: 0.00, writes: 119225.94, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[1444s] threads: 64, tps: 0.00, reads: 0.00, writes: 119172.02, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1445s] threads: 64, tps: 0.00, reads: 0.00, writes: 119652.57, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1446s] threads: 64, tps: 0.00, reads: 0.00, writes: 118409.51, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1447s] threads: 64, tps: 0.00, reads: 0.00, writes: 117942.33, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[1448s] threads: 64, tps: 0.00, reads: 0.00, writes: 119078.70, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1449s] threads: 64, tps: 0.00, reads: 0.00, writes: 120372.92, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1450s] threads: 64, tps: 0.00, reads: 0.00, writes: 120598.95, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1451s] threads: 64, tps: 0.00, reads: 0.00, writes: 117625.18, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1452s] threads: 64, tps: 0.00, reads: 0.00, writes: 118914.87, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1453s] threads: 64, tps: 0.00, reads: 0.00, writes: 117014.97, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1454s] threads: 64, tps: 0.00, reads: 0.00, writes: 115812.86, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[1455s] threads: 64, tps: 0.00, reads: 0.00, writes: 118665.38, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1456s] threads: 64, tps: 0.00, reads: 0.00, writes: 120109.76, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1457s] threads: 64, tps: 0.00, reads: 0.00, writes: 116136.92, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1458s] threads: 64, tps: 0.00, reads: 0.00, writes: 114711.17, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1459s] threads: 64, tps: 0.00, reads: 0.00, writes: 114143.04, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[1460s] threads: 64, tps: 0.00, reads: 0.00, writes: 118471.41, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1461s] threads: 64, tps: 0.00, reads: 0.00, writes: 114380.09, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[1462s] threads: 64, tps: 0.00, reads: 0.00, writes: 120019.13, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[1463s] threads: 64, tps: 0.00, reads: 0.00, writes: 119550.56, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1464s] threads: 64, tps: 0.00, reads: 0.00, writes: 118491.86, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1465s] threads: 64, tps: 0.00, reads: 0.00, writes: 115329.11, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1466s] threads: 64, tps: 0.00, reads: 0.00, writes: 119015.87, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1467s] threads: 64, tps: 0.00, reads: 0.00, writes: 118101.72, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[1468s] threads: 64, tps: 0.00, reads: 0.00, writes: 121468.14, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1469s] threads: 64, tps: 0.00, reads: 0.00, writes: 121817.39, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1470s] threads: 64, tps: 0.00, reads: 0.00, writes: 119829.94, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1471s] threads: 64, tps: 0.00, reads: 0.00, writes: 122251.96, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1472s] threads: 64, tps: 0.00, reads: 0.00, writes: 121706.13, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1473s] threads: 64, tps: 0.00, reads: 0.00, writes: 120282.97, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1474s] threads: 64, tps: 0.00, reads: 0.00, writes: 121964.22, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1475s] threads: 64, tps: 0.00, reads: 0.00, writes: 123465.73, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1476s] threads: 64, tps: 0.00, reads: 0.00, writes: 121612.91, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[1477s] threads: 64, tps: 0.00, reads: 0.00, writes: 122286.05, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1478s] threads: 64, tps: 0.00, reads: 0.00, writes: 122296.61, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1479s] threads: 64, tps: 0.00, reads: 0.00, writes: 122996.34, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1480s] threads: 64, tps: 0.00, reads: 0.00, writes: 121831.06, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1481s] threads: 64, tps: 0.00, reads: 0.00, writes: 124016.10, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1482s] threads: 64, tps: 0.00, reads: 0.00, writes: 124851.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1483s] threads: 64, tps: 0.00, reads: 0.00, writes: 120810.83, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[1484s] threads: 64, tps: 0.00, reads: 0.00, writes: 123004.01, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1485s] threads: 64, tps: 0.00, reads: 0.00, writes: 120714.06, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1486s] threads: 64, tps: 0.00, reads: 0.00, writes: 122009.98, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[1487s] threads: 64, tps: 0.00, reads: 0.00, writes: 119254.93, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1488s] threads: 64, tps: 0.00, reads: 0.00, writes: 121444.10, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1489s] threads: 64, tps: 0.00, reads: 0.00, writes: 122596.03, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1490s] threads: 64, tps: 0.00, reads: 0.00, writes: 123487.96, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1491s] threads: 64, tps: 0.00, reads: 0.00, writes: 121879.90, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1492s] threads: 64, tps: 0.00, reads: 0.00, writes: 123484.11, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1493s] threads: 64, tps: 0.00, reads: 0.00, writes: 123927.87, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1494s] threads: 64, tps: 0.00, reads: 0.00, writes: 123525.03, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1495s] threads: 64, tps: 0.00, reads: 0.00, writes: 121452.02, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1496s] threads: 64, tps: 0.00, reads: 0.00, writes: 121569.00, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1497s] threads: 64, tps: 0.00, reads: 0.00, writes: 121632.64, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1498s] threads: 64, tps: 0.00, reads: 0.00, writes: 122067.57, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1499s] threads: 64, tps: 0.00, reads: 0.00, writes: 122162.75, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1500s] threads: 64, tps: 0.00, reads: 0.00, writes: 123837.98, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1501s] threads: 64, tps: 0.00, reads: 0.00, writes: 124253.20, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1502s] threads: 64, tps: 0.00, reads: 0.00, writes: 119571.96, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1503s] threads: 64, tps: 0.00, reads: 0.00, writes: 121876.59, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1504s] threads: 64, tps: 0.00, reads: 0.00, writes: 121013.39, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1505s] threads: 64, tps: 0.00, reads: 0.00, writes: 122454.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1506s] threads: 64, tps: 0.00, reads: 0.00, writes: 121131.00, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1507s] threads: 64, tps: 0.00, reads: 0.00, writes: 120568.11, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1508s] threads: 64, tps: 0.00, reads: 0.00, writes: 122518.98, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1509s] threads: 64, tps: 0.00, reads: 0.00, writes: 121811.97, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1510s] threads: 64, tps: 0.00, reads: 0.00, writes: 123074.01, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1511s] threads: 64, tps: 0.00, reads: 0.00, writes: 121577.13, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1512s] threads: 64, tps: 0.00, reads: 0.00, writes: 122393.82, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1513s] threads: 64, tps: 0.00, reads: 0.00, writes: 124182.68, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1514s] threads: 64, tps: 0.00, reads: 0.00, writes: 122711.20, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1515s] threads: 64, tps: 0.00, reads: 0.00, writes: 122474.09, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1516s] threads: 64, tps: 0.00, reads: 0.00, writes: 124138.63, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1517s] threads: 64, tps: 0.00, reads: 0.00, writes: 121230.33, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1518s] threads: 64, tps: 0.00, reads: 0.00, writes: 122530.98, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1519s] threads: 64, tps: 0.00, reads: 0.00, writes: 124222.12, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1520s] threads: 64, tps: 0.00, reads: 0.00, writes: 122056.33, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1521s] threads: 64, tps: 0.00, reads: 0.00, writes: 120260.64, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[1522s] threads: 64, tps: 0.00, reads: 0.00, writes: 121416.85, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1523s] threads: 64, tps: 0.00, reads: 0.00, writes: 119843.75, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1524s] threads: 64, tps: 0.00, reads: 0.00, writes: 122878.30, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1525s] threads: 64, tps: 0.00, reads: 0.00, writes: 123579.99, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1526s] threads: 64, tps: 0.00, reads: 0.00, writes: 122733.08, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1527s] threads: 64, tps: 0.00, reads: 0.00, writes: 123119.86, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1528s] threads: 64, tps: 0.00, reads: 0.00, writes: 121948.04, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1529s] threads: 64, tps: 0.00, reads: 0.00, writes: 123838.03, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1530s] threads: 64, tps: 0.00, reads: 0.00, writes: 121946.08, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1531s] threads: 64, tps: 0.00, reads: 0.00, writes: 122340.81, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1532s] threads: 64, tps: 0.00, reads: 0.00, writes: 123234.29, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1533s] threads: 64, tps: 0.00, reads: 0.00, writes: 123926.84, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[1534s] threads: 64, tps: 0.00, reads: 0.00, writes: 119909.22, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1535s] threads: 64, tps: 0.00, reads: 0.00, writes: 121076.94, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1536s] threads: 64, tps: 0.00, reads: 0.00, writes: 122122.68, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1537s] threads: 64, tps: 0.00, reads: 0.00, writes: 122928.14, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1538s] threads: 64, tps: 0.00, reads: 0.00, writes: 122363.12, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1539s] threads: 64, tps: 0.00, reads: 0.00, writes: 123290.01, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1540s] threads: 64, tps: 0.00, reads: 0.00, writes: 121866.17, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1541s] threads: 64, tps: 0.00, reads: 0.00, writes: 122452.79, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[1542s] threads: 64, tps: 0.00, reads: 0.00, writes: 121883.12, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1543s] threads: 64, tps: 0.00, reads: 0.00, writes: 123133.66, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1544s] threads: 64, tps: 0.00, reads: 0.00, writes: 124244.23, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1545s] threads: 64, tps: 0.00, reads: 0.00, writes: 120562.03, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[1546s] threads: 64, tps: 0.00, reads: 0.00, writes: 121542.92, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1547s] threads: 64, tps: 0.00, reads: 0.00, writes: 120719.00, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1548s] threads: 64, tps: 0.00, reads: 0.00, writes: 122238.98, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1549s] threads: 64, tps: 0.00, reads: 0.00, writes: 121770.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1550s] threads: 64, tps: 0.00, reads: 0.00, writes: 120279.02, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1551s] threads: 64, tps: 0.00, reads: 0.00, writes: 122353.97, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1552s] threads: 64, tps: 0.00, reads: 0.00, writes: 121507.07, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1553s] threads: 64, tps: 0.00, reads: 0.00, writes: 121227.07, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1554s] threads: 64, tps: 0.00, reads: 0.00, writes: 121921.97, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1555s] threads: 64, tps: 0.00, reads: 0.00, writes: 121594.48, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1556s] threads: 64, tps: 0.00, reads: 0.00, writes: 123191.54, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1557s] threads: 64, tps: 0.00, reads: 0.00, writes: 122434.98, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[1558s] threads: 64, tps: 0.00, reads: 0.00, writes: 125382.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1559s] threads: 64, tps: 0.00, reads: 0.00, writes: 124646.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1560s] threads: 64, tps: 0.00, reads: 0.00, writes: 123491.03, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1561s] threads: 64, tps: 0.00, reads: 0.00, writes: 119276.44, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[1562s] threads: 64, tps: 0.00, reads: 0.00, writes: 122920.50, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1563s] threads: 64, tps: 0.00, reads: 0.00, writes: 123062.01, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1564s] threads: 64, tps: 0.00, reads: 0.00, writes: 120963.06, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1565s] threads: 64, tps: 0.00, reads: 0.00, writes: 122993.86, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1566s] threads: 64, tps: 0.00, reads: 0.00, writes: 119860.84, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1567s] threads: 64, tps: 0.00, reads: 0.00, writes: 120630.24, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1568s] threads: 64, tps: 0.00, reads: 0.00, writes: 122242.12, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1569s] threads: 64, tps: 0.00, reads: 0.00, writes: 120472.03, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1570s] threads: 64, tps: 0.00, reads: 0.00, writes: 122695.88, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1571s] threads: 64, tps: 0.00, reads: 0.00, writes: 121802.95, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1572s] threads: 64, tps: 0.00, reads: 0.00, writes: 121867.09, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1573s] threads: 64, tps: 0.00, reads: 0.00, writes: 118485.96, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1574s] threads: 64, tps: 0.00, reads: 0.00, writes: 122022.06, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1575s] threads: 64, tps: 0.00, reads: 0.00, writes: 120868.98, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1576s] threads: 64, tps: 0.00, reads: 0.00, writes: 120799.89, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1577s] threads: 64, tps: 0.00, reads: 0.00, writes: 120218.76, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1578s] threads: 64, tps: 0.00, reads: 0.00, writes: 118938.32, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1579s] threads: 64, tps: 0.00, reads: 0.00, writes: 121772.84, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1580s] threads: 64, tps: 0.00, reads: 0.00, writes: 121130.68, response time: 1.63ms (95%), errors: 0.00, reconnects:  0.00
[1581s] threads: 64, tps: 0.00, reads: 0.00, writes: 120404.50, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[1582s] threads: 64, tps: 0.00, reads: 0.00, writes: 117990.87, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1583s] threads: 64, tps: 0.00, reads: 0.00, writes: 119435.92, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1584s] threads: 64, tps: 0.00, reads: 0.00, writes: 121413.16, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1585s] threads: 64, tps: 0.00, reads: 0.00, writes: 122256.61, response time: 1.50ms (95%), errors: 0.00, reconnects:  0.00
[1586s] threads: 64, tps: 0.00, reads: 0.00, writes: 120864.28, response time: 1.34ms (95%), errors: 0.00, reconnects:  0.00
[1587s] threads: 64, tps: 0.00, reads: 0.00, writes: 118489.04, response time: 1.52ms (95%), errors: 0.00, reconnects:  0.00
[1588s] threads: 64, tps: 0.00, reads: 0.00, writes: 117638.11, response time: 1.57ms (95%), errors: 0.00, reconnects:  0.00
[1589s] threads: 64, tps: 0.00, reads: 0.00, writes: 126360.87, response time: 1.51ms (95%), errors: 0.00, reconnects:  0.00
[1590s] threads: 64, tps: 0.00, reads: 0.00, writes: 114091.02, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1591s] threads: 64, tps: 0.00, reads: 0.00, writes: 125286.01, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1592s] threads: 64, tps: 0.00, reads: 0.00, writes: 126275.01, response time: 1.59ms (95%), errors: 0.00, reconnects:  0.00
[1593s] threads: 64, tps: 0.00, reads: 0.00, writes: 126874.96, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1594s] threads: 64, tps: 0.00, reads: 0.00, writes: 123984.08, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1595s] threads: 64, tps: 0.00, reads: 0.00, writes: 127281.95, response time: 1.61ms (95%), errors: 0.00, reconnects:  0.00
[1596s] threads: 64, tps: 0.00, reads: 0.00, writes: 128397.24, response time: 1.66ms (95%), errors: 0.00, reconnects:  0.00
[1597s] threads: 64, tps: 0.00, reads: 0.00, writes: 123651.74, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1598s] threads: 64, tps: 0.00, reads: 0.00, writes: 125715.20, response time: 1.64ms (95%), errors: 0.00, reconnects:  0.00
[1599s] threads: 64, tps: 0.00, reads: 0.00, writes: 124846.65, response time: 1.67ms (95%), errors: 0.00, reconnects:  0.00
[1600s] threads: 64, tps: 0.00, reads: 0.00, writes: 123089.20, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1601s] threads: 64, tps: 0.00, reads: 0.00, writes: 122355.95, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1602s] threads: 64, tps: 0.00, reads: 0.00, writes: 124120.11, response time: 1.57ms (95%), errors: 0.00, reconnects:  0.00
[1603s] threads: 64, tps: 0.00, reads: 0.00, writes: 122543.98, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1604s] threads: 64, tps: 0.00, reads: 0.00, writes: 123859.10, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1605s] threads: 64, tps: 0.00, reads: 0.00, writes: 125338.89, response time: 1.56ms (95%), errors: 0.00, reconnects:  0.00
[1606s] threads: 64, tps: 0.00, reads: 0.00, writes: 124544.03, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1607s] threads: 64, tps: 0.00, reads: 0.00, writes: 125839.94, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1608s] threads: 64, tps: 0.00, reads: 0.00, writes: 124752.98, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1609s] threads: 64, tps: 0.00, reads: 0.00, writes: 121992.14, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1610s] threads: 64, tps: 0.00, reads: 0.00, writes: 124662.35, response time: 1.37ms (95%), errors: 0.00, reconnects:  0.00
[1611s] threads: 64, tps: 0.00, reads: 0.00, writes: 123326.56, response time: 1.47ms (95%), errors: 0.00, reconnects:  0.00
[1612s] threads: 64, tps: 0.00, reads: 0.00, writes: 123616.00, response time: 1.60ms (95%), errors: 0.00, reconnects:  0.00
[1613s] threads: 64, tps: 0.00, reads: 0.00, writes: 123701.99, response time: 1.50ms (95%), errors: 0.00, reconnects:  0.00
[1614s] threads: 64, tps: 0.00, reads: 0.00, writes: 124405.82, response time: 1.46ms (95%), errors: 0.00, reconnects:  0.00
[1615s] threads: 64, tps: 0.00, reads: 0.00, writes: 122947.48, response time: 1.49ms (95%), errors: 0.00, reconnects:  0.00
[1616s] threads: 64, tps: 0.00, reads: 0.00, writes: 123225.66, response time: 1.43ms (95%), errors: 0.00, reconnects:  0.00
[1617s] threads: 64, tps: 0.00, reads: 0.00, writes: 124086.16, response time: 1.65ms (95%), errors: 0.00, reconnects:  0.00
[1618s] threads: 64, tps: 0.00, reads: 0.00, writes: 124376.92, response time: 1.47ms (95%), errors: 0.00, reconnects:  0.00
[1619s] threads: 64, tps: 0.00, reads: 0.00, writes: 124251.86, response time: 1.59ms (95%), errors: 0.00, reconnects:  0.00
[1620s] threads: 64, tps: 0.00, reads: 0.00, writes: 123243.90, response time: 1.54ms (95%), errors: 0.00, reconnects:  0.00
[1621s] threads: 64, tps: 0.00, reads: 0.00, writes: 124577.49, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[1622s] threads: 64, tps: 0.00, reads: 0.00, writes: 123739.69, response time: 1.47ms (95%), errors: 0.00, reconnects:  0.00
[1623s] threads: 64, tps: 0.00, reads: 0.00, writes: 122638.72, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1624s] threads: 64, tps: 0.00, reads: 0.00, writes: 124825.43, response time: 1.63ms (95%), errors: 0.00, reconnects:  0.00
[1625s] threads: 64, tps: 0.00, reads: 0.00, writes: 124871.32, response time: 1.56ms (95%), errors: 0.00, reconnects:  0.00
[1626s] threads: 64, tps: 0.00, reads: 0.00, writes: 123419.30, response time: 1.58ms (95%), errors: 0.00, reconnects:  0.00
[1627s] threads: 64, tps: 0.00, reads: 0.00, writes: 122845.27, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1628s] threads: 64, tps: 0.00, reads: 0.00, writes: 125162.20, response time: 1.39ms (95%), errors: 0.00, reconnects:  0.00
[1629s] threads: 64, tps: 0.00, reads: 0.00, writes: 122547.85, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1630s] threads: 64, tps: 0.00, reads: 0.00, writes: 123517.02, response time: 1.67ms (95%), errors: 0.00, reconnects:  0.00
[1631s] threads: 64, tps: 0.00, reads: 0.00, writes: 123308.47, response time: 1.54ms (95%), errors: 0.00, reconnects:  0.00
[1632s] threads: 64, tps: 0.00, reads: 0.00, writes: 123362.47, response time: 1.55ms (95%), errors: 0.00, reconnects:  0.00
[1633s] threads: 64, tps: 0.00, reads: 0.00, writes: 122933.56, response time: 1.60ms (95%), errors: 0.00, reconnects:  0.00
[1634s] threads: 64, tps: 0.00, reads: 0.00, writes: 125051.80, response time: 1.45ms (95%), errors: 0.00, reconnects:  0.00
[1635s] threads: 64, tps: 0.00, reads: 0.00, writes: 125568.61, response time: 1.46ms (95%), errors: 0.00, reconnects:  0.00
[1636s] threads: 64, tps: 0.00, reads: 0.00, writes: 123448.97, response time: 1.39ms (95%), errors: 0.00, reconnects:  0.00
[1637s] threads: 64, tps: 0.00, reads: 0.00, writes: 121786.88, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1638s] threads: 64, tps: 0.00, reads: 0.00, writes: 123653.16, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1639s] threads: 64, tps: 0.00, reads: 0.00, writes: 122096.04, response time: 1.66ms (95%), errors: 0.00, reconnects:  0.00
[1640s] threads: 64, tps: 0.00, reads: 0.00, writes: 122808.94, response time: 1.54ms (95%), errors: 0.00, reconnects:  0.00
[1641s] threads: 64, tps: 0.00, reads: 0.00, writes: 123789.55, response time: 1.56ms (95%), errors: 0.00, reconnects:  0.00
[1642s] threads: 64, tps: 0.00, reads: 0.00, writes: 123205.63, response time: 1.67ms (95%), errors: 0.00, reconnects:  0.00
[1643s] threads: 64, tps: 0.00, reads: 0.00, writes: 122972.06, response time: 1.64ms (95%), errors: 0.00, reconnects:  0.00
[1644s] threads: 64, tps: 0.00, reads: 0.00, writes: 122927.76, response time: 1.61ms (95%), errors: 0.00, reconnects:  0.00
[1645s] threads: 64, tps: 0.00, reads: 0.00, writes: 123183.08, response time: 1.40ms (95%), errors: 0.00, reconnects:  0.00
[1646s] threads: 64, tps: 0.00, reads: 0.00, writes: 123300.07, response time: 1.35ms (95%), errors: 0.00, reconnects:  0.00
[1647s] threads: 64, tps: 0.00, reads: 0.00, writes: 123891.05, response time: 1.36ms (95%), errors: 0.00, reconnects:  0.00
[1648s] threads: 64, tps: 0.00, reads: 0.00, writes: 123769.82, response time: 1.54ms (95%), errors: 0.00, reconnects:  0.00
[1649s] threads: 64, tps: 0.00, reads: 0.00, writes: 122451.03, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1650s] threads: 64, tps: 0.00, reads: 0.00, writes: 121770.13, response time: 1.52ms (95%), errors: 0.00, reconnects:  0.00
[1651s] threads: 64, tps: 0.00, reads: 0.00, writes: 124277.06, response time: 1.43ms (95%), errors: 0.00, reconnects:  0.00
[1652s] threads: 64, tps: 0.00, reads: 0.00, writes: 123963.90, response time: 1.62ms (95%), errors: 0.00, reconnects:  0.00
[1653s] threads: 64, tps: 0.00, reads: 0.00, writes: 122813.47, response time: 1.40ms (95%), errors: 0.00, reconnects:  0.00
[1654s] threads: 64, tps: 0.00, reads: 0.00, writes: 123570.57, response time: 1.50ms (95%), errors: 0.00, reconnects:  0.00
[1655s] threads: 64, tps: 0.00, reads: 0.00, writes: 123058.97, response time: 1.42ms (95%), errors: 0.00, reconnects:  0.00
[1656s] threads: 64, tps: 0.00, reads: 0.00, writes: 125491.87, response time: 1.42ms (95%), errors: 0.00, reconnects:  0.00
[1657s] threads: 64, tps: 0.00, reads: 0.00, writes: 123690.14, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1658s] threads: 64, tps: 0.00, reads: 0.00, writes: 122028.03, response time: 1.51ms (95%), errors: 0.00, reconnects:  0.00
[1659s] threads: 64, tps: 0.00, reads: 0.00, writes: 123133.87, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1660s] threads: 64, tps: 0.00, reads: 0.00, writes: 125347.06, response time: 1.42ms (95%), errors: 0.00, reconnects:  0.00
[1661s] threads: 64, tps: 0.00, reads: 0.00, writes: 123643.84, response time: 1.50ms (95%), errors: 0.00, reconnects:  0.00
[1662s] threads: 64, tps: 0.00, reads: 0.00, writes: 122866.13, response time: 1.62ms (95%), errors: 0.00, reconnects:  0.00
[1663s] threads: 64, tps: 0.00, reads: 0.00, writes: 123982.05, response time: 1.56ms (95%), errors: 0.00, reconnects:  0.00
[1664s] threads: 64, tps: 0.00, reads: 0.00, writes: 122857.01, response time: 1.56ms (95%), errors: 0.00, reconnects:  0.00
[1665s] threads: 64, tps: 0.00, reads: 0.00, writes: 123468.05, response time: 1.66ms (95%), errors: 0.00, reconnects:  0.00
[1666s] threads: 64, tps: 0.00, reads: 0.00, writes: 124890.58, response time: 1.51ms (95%), errors: 0.00, reconnects:  0.00
[1667s] threads: 64, tps: 0.00, reads: 0.00, writes: 122784.46, response time: 1.46ms (95%), errors: 0.00, reconnects:  0.00
[1668s] threads: 64, tps: 0.00, reads: 0.00, writes: 122647.83, response time: 1.56ms (95%), errors: 0.00, reconnects:  0.00
[1669s] threads: 64, tps: 0.00, reads: 0.00, writes: 124330.11, response time: 1.39ms (95%), errors: 0.00, reconnects:  0.00
[1670s] threads: 64, tps: 0.00, reads: 0.00, writes: 122633.84, response time: 1.56ms (95%), errors: 0.00, reconnects:  0.00
[1671s] threads: 64, tps: 0.00, reads: 0.00, writes: 123659.08, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[1672s] threads: 64, tps: 0.00, reads: 0.00, writes: 122600.02, response time: 1.58ms (95%), errors: 0.00, reconnects:  0.00
[1673s] threads: 64, tps: 0.00, reads: 0.00, writes: 122725.95, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1674s] threads: 64, tps: 0.00, reads: 0.00, writes: 125443.08, response time: 1.48ms (95%), errors: 0.00, reconnects:  0.00
[1675s] threads: 64, tps: 0.00, reads: 0.00, writes: 124837.17, response time: 1.40ms (95%), errors: 0.00, reconnects:  0.00
[1676s] threads: 64, tps: 0.00, reads: 0.00, writes: 123988.84, response time: 1.70ms (95%), errors: 0.00, reconnects:  0.00
[1677s] threads: 64, tps: 0.00, reads: 0.00, writes: 123488.83, response time: 1.62ms (95%), errors: 0.00, reconnects:  0.00
[1678s] threads: 64, tps: 0.00, reads: 0.00, writes: 122788.21, response time: 1.61ms (95%), errors: 0.00, reconnects:  0.00
[1679s] threads: 64, tps: 0.00, reads: 0.00, writes: 124922.59, response time: 1.39ms (95%), errors: 0.00, reconnects:  0.00
[1680s] threads: 64, tps: 0.00, reads: 0.00, writes: 124307.23, response time: 1.45ms (95%), errors: 0.00, reconnects:  0.00
[1681s] threads: 64, tps: 0.00, reads: 0.00, writes: 122751.58, response time: 1.38ms (95%), errors: 0.00, reconnects:  0.00
[1682s] threads: 64, tps: 0.00, reads: 0.00, writes: 125049.57, response time: 1.59ms (95%), errors: 0.00, reconnects:  0.00
[1683s] threads: 64, tps: 0.00, reads: 0.00, writes: 125912.91, response time: 1.55ms (95%), errors: 0.00, reconnects:  0.00
[1684s] threads: 64, tps: 0.00, reads: 0.00, writes: 124485.11, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[1685s] threads: 64, tps: 0.00, reads: 0.00, writes: 121431.92, response time: 1.36ms (95%), errors: 0.00, reconnects:  0.00
[1686s] threads: 64, tps: 0.00, reads: 0.00, writes: 125371.06, response time: 1.34ms (95%), errors: 0.00, reconnects:  0.00
[1687s] threads: 64, tps: 0.00, reads: 0.00, writes: 125885.07, response time: 1.49ms (95%), errors: 0.00, reconnects:  0.00
[1688s] threads: 64, tps: 0.00, reads: 0.00, writes: 124499.99, response time: 1.57ms (95%), errors: 0.00, reconnects:  0.00
[1689s] threads: 64, tps: 0.00, reads: 0.00, writes: 124219.86, response time: 1.66ms (95%), errors: 0.00, reconnects:  0.00
[1690s] threads: 64, tps: 0.00, reads: 0.00, writes: 125154.09, response time: 1.28ms (95%), errors: 0.00, reconnects:  0.00
[1691s] threads: 64, tps: 0.00, reads: 0.00, writes: 125300.68, response time: 1.40ms (95%), errors: 0.00, reconnects:  0.00
[1692s] threads: 64, tps: 0.00, reads: 0.00, writes: 125082.23, response time: 1.27ms (95%), errors: 0.00, reconnects:  0.00
[1693s] threads: 64, tps: 0.00, reads: 0.00, writes: 124626.08, response time: 1.56ms (95%), errors: 0.00, reconnects:  0.00
[1694s] threads: 64, tps: 0.00, reads: 0.00, writes: 125173.86, response time: 1.51ms (95%), errors: 0.00, reconnects:  0.00
[1695s] threads: 64, tps: 0.00, reads: 0.00, writes: 124489.22, response time: 1.32ms (95%), errors: 0.00, reconnects:  0.00
[1696s] threads: 64, tps: 0.00, reads: 0.00, writes: 124230.28, response time: 1.35ms (95%), errors: 0.00, reconnects:  0.00
[1697s] threads: 64, tps: 0.00, reads: 0.00, writes: 123761.54, response time: 1.42ms (95%), errors: 0.00, reconnects:  0.00
[1698s] threads: 64, tps: 0.00, reads: 0.00, writes: 125504.07, response time: 1.45ms (95%), errors: 0.00, reconnects:  0.00
[1699s] threads: 64, tps: 0.00, reads: 0.00, writes: 125728.13, response time: 1.44ms (95%), errors: 0.00, reconnects:  0.00
[1700s] threads: 64, tps: 0.00, reads: 0.00, writes: 125297.92, response time: 1.33ms (95%), errors: 0.00, reconnects:  0.00
[1701s] threads: 64, tps: 0.00, reads: 0.00, writes: 124895.03, response time: 1.49ms (95%), errors: 0.00, reconnects:  0.00
[1702s] threads: 64, tps: 0.00, reads: 0.00, writes: 124942.97, response time: 1.51ms (95%), errors: 0.00, reconnects:  0.00
[1703s] threads: 64, tps: 0.00, reads: 0.00, writes: 123275.89, response time: 1.35ms (95%), errors: 0.00, reconnects:  0.00
[1704s] threads: 64, tps: 0.00, reads: 0.00, writes: 124278.26, response time: 1.36ms (95%), errors: 0.00, reconnects:  0.00
[1705s] threads: 64, tps: 0.00, reads: 0.00, writes: 123073.68, response time: 1.28ms (95%), errors: 0.00, reconnects:  0.00
[1706s] threads: 64, tps: 0.00, reads: 0.00, writes: 124218.07, response time: 1.33ms (95%), errors: 0.00, reconnects:  0.00
[1707s] threads: 64, tps: 0.00, reads: 0.00, writes: 125817.00, response time: 1.47ms (95%), errors: 0.00, reconnects:  0.00
[1708s] threads: 64, tps: 0.00, reads: 0.00, writes: 123925.02, response time: 1.41ms (95%), errors: 0.00, reconnects:  0.00
[1709s] threads: 64, tps: 0.00, reads: 0.00, writes: 125595.11, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1710s] threads: 64, tps: 0.00, reads: 0.00, writes: 124551.04, response time: 1.29ms (95%), errors: 0.00, reconnects:  0.00
[1711s] threads: 64, tps: 0.00, reads: 0.00, writes: 124413.85, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1712s] threads: 64, tps: 0.00, reads: 0.00, writes: 123388.25, response time: 1.46ms (95%), errors: 0.00, reconnects:  0.00
[1713s] threads: 64, tps: 0.00, reads: 0.00, writes: 124754.82, response time: 1.40ms (95%), errors: 0.00, reconnects:  0.00
[1714s] threads: 64, tps: 0.00, reads: 0.00, writes: 124212.01, response time: 1.27ms (95%), errors: 0.00, reconnects:  0.00
[1715s] threads: 64, tps: 0.00, reads: 0.00, writes: 123116.86, response time: 1.64ms (95%), errors: 0.00, reconnects:  0.00
[1716s] threads: 64, tps: 0.00, reads: 0.00, writes: 124260.61, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1717s] threads: 64, tps: 0.00, reads: 0.00, writes: 123646.56, response time: 1.29ms (95%), errors: 0.00, reconnects:  0.00
[1718s] threads: 64, tps: 0.00, reads: 0.00, writes: 126102.95, response time: 1.40ms (95%), errors: 0.00, reconnects:  0.00
[1719s] threads: 64, tps: 0.00, reads: 0.00, writes: 124503.22, response time: 1.42ms (95%), errors: 0.00, reconnects:  0.00
[1720s] threads: 64, tps: 0.00, reads: 0.00, writes: 125940.77, response time: 1.32ms (95%), errors: 0.00, reconnects:  0.00
[1721s] threads: 64, tps: 0.00, reads: 0.00, writes: 124712.47, response time: 1.45ms (95%), errors: 0.00, reconnects:  0.00
[1722s] threads: 64, tps: 0.00, reads: 0.00, writes: 122933.52, response time: 1.54ms (95%), errors: 0.00, reconnects:  0.00
[1723s] threads: 64, tps: 0.00, reads: 0.00, writes: 123487.10, response time: 1.56ms (95%), errors: 0.00, reconnects:  0.00
[1724s] threads: 64, tps: 0.00, reads: 0.00, writes: 127256.94, response time: 1.35ms (95%), errors: 0.00, reconnects:  0.00
[1725s] threads: 64, tps: 0.00, reads: 0.00, writes: 124292.05, response time: 1.40ms (95%), errors: 0.00, reconnects:  0.00
[1726s] threads: 64, tps: 0.00, reads: 0.00, writes: 124362.13, response time: 1.46ms (95%), errors: 0.00, reconnects:  0.00
[1727s] threads: 64, tps: 0.00, reads: 0.00, writes: 125920.70, response time: 1.28ms (95%), errors: 0.00, reconnects:  0.00
[1728s] threads: 64, tps: 0.00, reads: 0.00, writes: 124148.27, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[1729s] threads: 64, tps: 0.00, reads: 0.00, writes: 124081.90, response time: 1.45ms (95%), errors: 0.00, reconnects:  0.00
[1730s] threads: 64, tps: 0.00, reads: 0.00, writes: 125834.13, response time: 1.43ms (95%), errors: 0.00, reconnects:  0.00
[1731s] threads: 64, tps: 0.00, reads: 0.00, writes: 125276.79, response time: 1.38ms (95%), errors: 0.00, reconnects:  0.00
[1732s] threads: 64, tps: 0.00, reads: 0.00, writes: 124747.65, response time: 1.30ms (95%), errors: 0.00, reconnects:  0.00
[1733s] threads: 64, tps: 0.00, reads: 0.00, writes: 124392.28, response time: 1.54ms (95%), errors: 0.00, reconnects:  0.00
[1734s] threads: 64, tps: 0.00, reads: 0.00, writes: 125987.74, response time: 1.20ms (95%), errors: 0.00, reconnects:  0.00
[1735s] threads: 64, tps: 0.00, reads: 0.00, writes: 126131.42, response time: 1.27ms (95%), errors: 0.00, reconnects:  0.00
[1736s] threads: 64, tps: 0.00, reads: 0.00, writes: 125965.86, response time: 1.57ms (95%), errors: 0.00, reconnects:  0.00
[1737s] threads: 64, tps: 0.00, reads: 0.00, writes: 125282.68, response time: 1.43ms (95%), errors: 0.00, reconnects:  0.00
[1738s] threads: 64, tps: 0.00, reads: 0.00, writes: 123491.27, response time: 1.49ms (95%), errors: 0.00, reconnects:  0.00
[1739s] threads: 64, tps: 0.00, reads: 0.00, writes: 125119.70, response time: 1.16ms (95%), errors: 0.00, reconnects:  0.00
[1740s] threads: 64, tps: 0.00, reads: 0.00, writes: 123971.28, response time: 1.32ms (95%), errors: 0.00, reconnects:  0.00
[1741s] threads: 64, tps: 0.00, reads: 0.00, writes: 126717.13, response time: 1.24ms (95%), errors: 0.00, reconnects:  0.00
[1742s] threads: 64, tps: 0.00, reads: 0.00, writes: 124222.08, response time: 1.33ms (95%), errors: 0.00, reconnects:  0.00
[1743s] threads: 64, tps: 0.00, reads: 0.00, writes: 126070.82, response time: 1.24ms (95%), errors: 0.00, reconnects:  0.00
[1744s] threads: 64, tps: 0.00, reads: 0.00, writes: 127334.20, response time: 1.29ms (95%), errors: 0.00, reconnects:  0.00
[1745s] threads: 64, tps: 0.00, reads: 0.00, writes: 124174.88, response time: 1.33ms (95%), errors: 0.00, reconnects:  0.00
[1746s] threads: 64, tps: 0.00, reads: 0.00, writes: 124434.38, response time: 1.39ms (95%), errors: 0.00, reconnects:  0.00
[1747s] threads: 64, tps: 0.00, reads: 0.00, writes: 124790.27, response time: 1.63ms (95%), errors: 0.00, reconnects:  0.00
[1748s] threads: 64, tps: 0.00, reads: 0.00, writes: 124233.36, response time: 1.25ms (95%), errors: 0.00, reconnects:  0.00
[1749s] threads: 64, tps: 0.00, reads: 0.00, writes: 125474.62, response time: 1.27ms (95%), errors: 0.00, reconnects:  0.00
[1750s] threads: 64, tps: 0.00, reads: 0.00, writes: 125450.20, response time: 1.22ms (95%), errors: 0.00, reconnects:  0.00
[1751s] threads: 64, tps: 0.00, reads: 0.00, writes: 124823.65, response time: 1.44ms (95%), errors: 0.00, reconnects:  0.00
[1752s] threads: 64, tps: 0.00, reads: 0.00, writes: 124951.86, response time: 1.34ms (95%), errors: 0.00, reconnects:  0.00
[1753s] threads: 64, tps: 0.00, reads: 0.00, writes: 126755.78, response time: 1.44ms (95%), errors: 0.00, reconnects:  0.00
[1754s] threads: 64, tps: 0.00, reads: 0.00, writes: 125655.10, response time: 1.16ms (95%), errors: 0.00, reconnects:  0.00
[1755s] threads: 64, tps: 0.00, reads: 0.00, writes: 127009.84, response time: 1.38ms (95%), errors: 0.00, reconnects:  0.00
[1756s] threads: 64, tps: 0.00, reads: 0.00, writes: 123736.99, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1757s] threads: 64, tps: 0.00, reads: 0.00, writes: 124687.01, response time: 1.54ms (95%), errors: 0.00, reconnects:  0.00
[1758s] threads: 64, tps: 0.00, reads: 0.00, writes: 122929.15, response time: 1.40ms (95%), errors: 0.00, reconnects:  0.00
[1759s] threads: 64, tps: 0.00, reads: 0.00, writes: 126582.70, response time: 1.17ms (95%), errors: 0.00, reconnects:  0.00
[1760s] threads: 64, tps: 0.00, reads: 0.00, writes: 125521.26, response time: 1.32ms (95%), errors: 0.00, reconnects:  0.00
[1761s] threads: 64, tps: 0.00, reads: 0.00, writes: 123925.13, response time: 1.63ms (95%), errors: 0.00, reconnects:  0.00
[1762s] threads: 64, tps: 0.00, reads: 0.00, writes: 123663.79, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[1763s] threads: 64, tps: 0.00, reads: 0.00, writes: 125112.04, response time: 1.40ms (95%), errors: 0.00, reconnects:  0.00
[1764s] threads: 64, tps: 0.00, reads: 0.00, writes: 126655.08, response time: 1.35ms (95%), errors: 0.00, reconnects:  0.00
[1765s] threads: 64, tps: 0.00, reads: 0.00, writes: 126745.89, response time: 1.38ms (95%), errors: 0.00, reconnects:  0.00
[1766s] threads: 64, tps: 0.00, reads: 0.00, writes: 126923.65, response time: 1.38ms (95%), errors: 0.00, reconnects:  0.00
[1767s] threads: 64, tps: 0.00, reads: 0.00, writes: 125567.26, response time: 1.27ms (95%), errors: 0.00, reconnects:  0.00
[1768s] threads: 64, tps: 0.00, reads: 0.00, writes: 126454.10, response time: 1.29ms (95%), errors: 0.00, reconnects:  0.00
[1769s] threads: 64, tps: 0.00, reads: 0.00, writes: 126104.91, response time: 1.37ms (95%), errors: 0.00, reconnects:  0.00
[1770s] threads: 64, tps: 0.00, reads: 0.00, writes: 126364.03, response time: 1.31ms (95%), errors: 0.00, reconnects:  0.00
[1771s] threads: 64, tps: 0.00, reads: 0.00, writes: 124147.22, response time: 1.52ms (95%), errors: 0.00, reconnects:  0.00
[1772s] threads: 64, tps: 0.00, reads: 0.00, writes: 123709.72, response time: 1.37ms (95%), errors: 0.00, reconnects:  0.00
[1773s] threads: 64, tps: 0.00, reads: 0.00, writes: 124642.94, response time: 1.52ms (95%), errors: 0.00, reconnects:  0.00
[1774s] threads: 64, tps: 0.00, reads: 0.00, writes: 127877.01, response time: 1.19ms (95%), errors: 0.00, reconnects:  0.00
[1775s] threads: 64, tps: 0.00, reads: 0.00, writes: 127872.79, response time: 1.26ms (95%), errors: 0.00, reconnects:  0.00
[1776s] threads: 64, tps: 0.00, reads: 0.00, writes: 121915.93, response time: 1.34ms (95%), errors: 0.00, reconnects:  0.00
[1777s] threads: 64, tps: 0.00, reads: 0.00, writes: 126067.33, response time: 1.33ms (95%), errors: 0.00, reconnects:  0.00
[1778s] threads: 64, tps: 0.00, reads: 0.00, writes: 127261.18, response time: 1.28ms (95%), errors: 0.00, reconnects:  0.00
[1779s] threads: 64, tps: 0.00, reads: 0.00, writes: 124852.02, response time: 1.33ms (95%), errors: 0.00, reconnects:  0.00
[1780s] threads: 64, tps: 0.00, reads: 0.00, writes: 127731.71, response time: 1.31ms (95%), errors: 0.00, reconnects:  0.00
[1781s] threads: 64, tps: 0.00, reads: 0.00, writes: 126412.25, response time: 1.28ms (95%), errors: 0.00, reconnects:  0.00
[1782s] threads: 64, tps: 0.00, reads: 0.00, writes: 124058.04, response time: 1.21ms (95%), errors: 0.00, reconnects:  0.00
[1783s] threads: 64, tps: 0.00, reads: 0.00, writes: 123053.84, response time: 1.31ms (95%), errors: 0.00, reconnects:  0.00
[1784s] threads: 64, tps: 0.00, reads: 0.00, writes: 125178.99, response time: 1.27ms (95%), errors: 0.00, reconnects:  0.00
[1785s] threads: 64, tps: 0.00, reads: 0.00, writes: 129054.65, response time: 1.10ms (95%), errors: 0.00, reconnects:  0.00
[1786s] threads: 64, tps: 0.00, reads: 0.00, writes: 126136.27, response time: 1.26ms (95%), errors: 0.00, reconnects:  0.00
[1787s] threads: 64, tps: 0.00, reads: 0.00, writes: 123999.99, response time: 1.34ms (95%), errors: 0.00, reconnects:  0.00
[1788s] threads: 64, tps: 0.00, reads: 0.00, writes: 126046.56, response time: 1.18ms (95%), errors: 0.00, reconnects:  0.00
[1789s] threads: 64, tps: 0.00, reads: 0.00, writes: 122972.05, response time: 1.58ms (95%), errors: 0.00, reconnects:  0.00
[1790s] threads: 64, tps: 0.00, reads: 0.00, writes: 123591.23, response time: 1.41ms (95%), errors: 0.00, reconnects:  0.00
[1791s] threads: 64, tps: 0.00, reads: 0.00, writes: 125459.95, response time: 1.18ms (95%), errors: 0.00, reconnects:  0.00
[1792s] threads: 64, tps: 0.00, reads: 0.00, writes: 124362.08, response time: 1.25ms (95%), errors: 0.00, reconnects:  0.00
[1793s] threads: 64, tps: 0.00, reads: 0.00, writes: 125520.08, response time: 1.20ms (95%), errors: 0.00, reconnects:  0.00
[1794s] threads: 64, tps: 0.00, reads: 0.00, writes: 125762.98, response time: 1.37ms (95%), errors: 0.00, reconnects:  0.00
[1795s] threads: 64, tps: 0.00, reads: 0.00, writes: 126024.96, response time: 1.14ms (95%), errors: 0.00, reconnects:  0.00
[1796s] threads: 64, tps: 0.00, reads: 0.00, writes: 123980.80, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1797s] threads: 64, tps: 0.00, reads: 0.00, writes: 119609.21, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[1798s] threads: 64, tps: 0.00, reads: 0.00, writes: 124122.05, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1799s] threads: 64, tps: 0.00, reads: 0.00, writes: 128480.03, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1800s] threads: 64, tps: 0.00, reads: 0.00, writes: 128153.79, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1801s] threads: 64, tps: 0.00, reads: 0.00, writes: 128205.29, response time: 1.15ms (95%), errors: 0.00, reconnects:  0.00
[1802s] threads: 64, tps: 0.00, reads: 0.00, writes: 127789.71, response time: 1.10ms (95%), errors: 0.00, reconnects:  0.00
[1803s] threads: 64, tps: 0.00, reads: 0.00, writes: 126207.93, response time: 1.09ms (95%), errors: 0.00, reconnects:  0.00
[1804s] threads: 64, tps: 0.00, reads: 0.00, writes: 127757.88, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1805s] threads: 64, tps: 0.00, reads: 0.00, writes: 128743.29, response time: 1.15ms (95%), errors: 0.00, reconnects:  0.00
[1806s] threads: 64, tps: 0.00, reads: 0.00, writes: 129363.96, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1807s] threads: 64, tps: 0.00, reads: 0.00, writes: 129864.87, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1808s] threads: 64, tps: 0.00, reads: 0.00, writes: 127514.08, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1809s] threads: 64, tps: 0.00, reads: 0.00, writes: 125175.16, response time: 1.16ms (95%), errors: 0.00, reconnects:  0.00
[1810s] threads: 64, tps: 0.00, reads: 0.00, writes: 126968.77, response time: 1.35ms (95%), errors: 0.00, reconnects:  0.00
[1811s] threads: 64, tps: 0.00, reads: 0.00, writes: 130737.08, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1812s] threads: 64, tps: 0.00, reads: 0.00, writes: 128942.10, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1813s] threads: 64, tps: 0.00, reads: 0.00, writes: 129772.95, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1814s] threads: 64, tps: 0.00, reads: 0.00, writes: 129563.27, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1815s] threads: 64, tps: 0.00, reads: 0.00, writes: 128067.67, response time: 1.21ms (95%), errors: 0.00, reconnects:  0.00
[1816s] threads: 64, tps: 0.00, reads: 0.00, writes: 130062.22, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1817s] threads: 64, tps: 0.00, reads: 0.00, writes: 127984.87, response time: 1.29ms (95%), errors: 0.00, reconnects:  0.00
[1818s] threads: 64, tps: 0.00, reads: 0.00, writes: 127403.88, response time: 1.27ms (95%), errors: 0.00, reconnects:  0.00
[1819s] threads: 64, tps: 0.00, reads: 0.00, writes: 129800.03, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1820s] threads: 64, tps: 0.00, reads: 0.00, writes: 127144.20, response time: 1.17ms (95%), errors: 0.00, reconnects:  0.00
[1821s] threads: 64, tps: 0.00, reads: 0.00, writes: 129211.94, response time: 1.21ms (95%), errors: 0.00, reconnects:  0.00
[1822s] threads: 64, tps: 0.00, reads: 0.00, writes: 129490.60, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1823s] threads: 64, tps: 0.00, reads: 0.00, writes: 128263.24, response time: 1.31ms (95%), errors: 0.00, reconnects:  0.00
[1824s] threads: 64, tps: 0.00, reads: 0.00, writes: 128128.07, response time: 1.27ms (95%), errors: 0.00, reconnects:  0.00
[1825s] threads: 64, tps: 0.00, reads: 0.00, writes: 128255.95, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1826s] threads: 64, tps: 0.00, reads: 0.00, writes: 129485.18, response time: 1.14ms (95%), errors: 0.00, reconnects:  0.00
[1827s] threads: 64, tps: 0.00, reads: 0.00, writes: 127144.03, response time: 1.24ms (95%), errors: 0.00, reconnects:  0.00
[1828s] threads: 64, tps: 0.00, reads: 0.00, writes: 129058.75, response time: 1.15ms (95%), errors: 0.00, reconnects:  0.00
[1829s] threads: 64, tps: 0.00, reads: 0.00, writes: 129662.18, response time: 1.20ms (95%), errors: 0.00, reconnects:  0.00
[1830s] threads: 64, tps: 0.00, reads: 0.00, writes: 127038.91, response time: 1.10ms (95%), errors: 0.00, reconnects:  0.00
[1831s] threads: 64, tps: 0.00, reads: 0.00, writes: 125977.02, response time: 1.16ms (95%), errors: 0.00, reconnects:  0.00
[1832s] threads: 64, tps: 0.00, reads: 0.00, writes: 127430.01, response time: 1.09ms (95%), errors: 0.00, reconnects:  0.00
[1833s] threads: 64, tps: 0.00, reads: 0.00, writes: 128358.92, response time: 1.14ms (95%), errors: 0.00, reconnects:  0.00
[1834s] threads: 64, tps: 0.00, reads: 0.00, writes: 129865.19, response time: 1.10ms (95%), errors: 0.00, reconnects:  0.00
[1835s] threads: 64, tps: 0.00, reads: 0.00, writes: 127604.72, response time: 1.24ms (95%), errors: 0.00, reconnects:  0.00
[1836s] threads: 64, tps: 0.00, reads: 0.00, writes: 129508.22, response time: 1.17ms (95%), errors: 0.00, reconnects:  0.00
[1837s] threads: 64, tps: 0.00, reads: 0.00, writes: 127674.04, response time: 1.10ms (95%), errors: 0.00, reconnects:  0.00
[1838s] threads: 64, tps: 0.00, reads: 0.00, writes: 130454.78, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1839s] threads: 64, tps: 0.00, reads: 0.00, writes: 128606.99, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1840s] threads: 64, tps: 0.00, reads: 0.00, writes: 127675.02, response time: 1.30ms (95%), errors: 0.00, reconnects:  0.00
[1841s] threads: 64, tps: 0.00, reads: 0.00, writes: 128187.26, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1842s] threads: 64, tps: 0.00, reads: 0.00, writes: 127672.91, response time: 1.15ms (95%), errors: 0.00, reconnects:  0.00
[1843s] threads: 64, tps: 0.00, reads: 0.00, writes: 129524.67, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1844s] threads: 64, tps: 0.00, reads: 0.00, writes: 127499.24, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1845s] threads: 64, tps: 0.00, reads: 0.00, writes: 127008.10, response time: 1.23ms (95%), errors: 0.00, reconnects:  0.00
[1846s] threads: 64, tps: 0.00, reads: 0.00, writes: 125058.10, response time: 1.28ms (95%), errors: 0.00, reconnects:  0.00
[1847s] threads: 64, tps: 0.00, reads: 0.00, writes: 127001.27, response time: 1.15ms (95%), errors: 0.00, reconnects:  0.00
[1848s] threads: 64, tps: 0.00, reads: 0.00, writes: 127559.77, response time: 1.34ms (95%), errors: 0.00, reconnects:  0.00
[1849s] threads: 64, tps: 0.00, reads: 0.00, writes: 125511.78, response time: 1.18ms (95%), errors: 0.00, reconnects:  0.00
[1850s] threads: 64, tps: 0.00, reads: 0.00, writes: 128180.03, response time: 1.17ms (95%), errors: 0.00, reconnects:  0.00
[1851s] threads: 64, tps: 0.00, reads: 0.00, writes: 126332.00, response time: 1.14ms (95%), errors: 0.00, reconnects:  0.00
[1852s] threads: 64, tps: 0.00, reads: 0.00, writes: 127785.11, response time: 1.17ms (95%), errors: 0.00, reconnects:  0.00
[1853s] threads: 64, tps: 0.00, reads: 0.00, writes: 126473.81, response time: 1.21ms (95%), errors: 0.00, reconnects:  0.00
[1854s] threads: 64, tps: 0.00, reads: 0.00, writes: 124645.12, response time: 1.41ms (95%), errors: 0.00, reconnects:  0.00
[1855s] threads: 64, tps: 0.00, reads: 0.00, writes: 127236.70, response time: 1.20ms (95%), errors: 0.00, reconnects:  0.00
[1856s] threads: 64, tps: 0.00, reads: 0.00, writes: 125360.37, response time: 1.15ms (95%), errors: 0.00, reconnects:  0.00
[1857s] threads: 64, tps: 0.00, reads: 0.00, writes: 125550.95, response time: 1.26ms (95%), errors: 0.00, reconnects:  0.00
[1858s] threads: 64, tps: 0.00, reads: 0.00, writes: 126829.53, response time: 1.16ms (95%), errors: 0.00, reconnects:  0.00
[1859s] threads: 64, tps: 0.00, reads: 0.00, writes: 125183.78, response time: 1.19ms (95%), errors: 0.00, reconnects:  0.00
[1860s] threads: 64, tps: 0.00, reads: 0.00, writes: 124780.75, response time: 1.30ms (95%), errors: 0.00, reconnects:  0.00
[1861s] threads: 64, tps: 0.00, reads: 0.00, writes: 125470.70, response time: 1.24ms (95%), errors: 0.00, reconnects:  0.00
[1862s] threads: 64, tps: 0.00, reads: 0.00, writes: 126934.24, response time: 1.10ms (95%), errors: 0.00, reconnects:  0.00
[1863s] threads: 64, tps: 0.00, reads: 0.00, writes: 127264.97, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1864s] threads: 64, tps: 0.00, reads: 0.00, writes: 127135.08, response time: 1.23ms (95%), errors: 0.00, reconnects:  0.00
[1865s] threads: 64, tps: 0.00, reads: 0.00, writes: 126151.97, response time: 1.26ms (95%), errors: 0.00, reconnects:  0.00
[1866s] threads: 64, tps: 0.00, reads: 0.00, writes: 125515.92, response time: 1.18ms (95%), errors: 0.00, reconnects:  0.00
[1867s] threads: 64, tps: 0.00, reads: 0.00, writes: 126894.04, response time: 1.23ms (95%), errors: 0.00, reconnects:  0.00
[1868s] threads: 64, tps: 0.00, reads: 0.00, writes: 126932.02, response time: 1.16ms (95%), errors: 0.00, reconnects:  0.00
[1869s] threads: 64, tps: 0.00, reads: 0.00, writes: 126817.81, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1870s] threads: 64, tps: 0.00, reads: 0.00, writes: 127404.10, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1871s] threads: 64, tps: 0.00, reads: 0.00, writes: 126920.52, response time: 1.09ms (95%), errors: 0.00, reconnects:  0.00
[1872s] threads: 64, tps: 0.00, reads: 0.00, writes: 128325.48, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1873s] threads: 64, tps: 0.00, reads: 0.00, writes: 126875.07, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1874s] threads: 64, tps: 0.00, reads: 0.00, writes: 125904.10, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1875s] threads: 64, tps: 0.00, reads: 0.00, writes: 128165.91, response time: 1.09ms (95%), errors: 0.00, reconnects:  0.00
[1876s] threads: 64, tps: 0.00, reads: 0.00, writes: 125929.10, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1877s] threads: 64, tps: 0.00, reads: 0.00, writes: 124463.65, response time: 1.15ms (95%), errors: 0.00, reconnects:  0.00
[1878s] threads: 64, tps: 0.00, reads: 0.00, writes: 126618.96, response time: 1.10ms (95%), errors: 0.00, reconnects:  0.00
[1879s] threads: 64, tps: 0.00, reads: 0.00, writes: 126971.40, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1880s] threads: 64, tps: 0.00, reads: 0.00, writes: 124578.96, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1881s] threads: 64, tps: 0.00, reads: 0.00, writes: 127484.46, response time: 1.09ms (95%), errors: 0.00, reconnects:  0.00
[1882s] threads: 64, tps: 0.00, reads: 0.00, writes: 125187.32, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1883s] threads: 64, tps: 0.00, reads: 0.00, writes: 126478.13, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1884s] threads: 64, tps: 0.00, reads: 0.00, writes: 127281.08, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1885s] threads: 64, tps: 0.00, reads: 0.00, writes: 125478.36, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1886s] threads: 64, tps: 0.00, reads: 0.00, writes: 124826.84, response time: 1.25ms (95%), errors: 0.00, reconnects:  0.00
[1887s] threads: 64, tps: 0.00, reads: 0.00, writes: 126338.83, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1888s] threads: 64, tps: 0.00, reads: 0.00, writes: 125065.95, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1889s] threads: 64, tps: 0.00, reads: 0.00, writes: 126653.09, response time: 1.15ms (95%), errors: 0.00, reconnects:  0.00
[1890s] threads: 64, tps: 0.00, reads: 0.00, writes: 126734.60, response time: 1.16ms (95%), errors: 0.00, reconnects:  0.00
[1891s] threads: 64, tps: 0.00, reads: 0.00, writes: 125565.22, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1892s] threads: 64, tps: 0.00, reads: 0.00, writes: 128265.68, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1893s] threads: 64, tps: 0.00, reads: 0.00, writes: 127223.41, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[1894s] threads: 64, tps: 0.00, reads: 0.00, writes: 126975.05, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1895s] threads: 64, tps: 0.00, reads: 0.00, writes: 126319.97, response time: 1.14ms (95%), errors: 0.00, reconnects:  0.00
[1896s] threads: 64, tps: 0.00, reads: 0.00, writes: 128314.02, response time: 1.09ms (95%), errors: 0.00, reconnects:  0.00
[1897s] threads: 64, tps: 0.00, reads: 0.00, writes: 127910.01, response time: 1.13ms (95%), errors: 0.00, reconnects:  0.00
[1898s] threads: 64, tps: 0.00, reads: 0.00, writes: 128025.93, response time: 1.16ms (95%), errors: 0.00, reconnects:  0.00
[1899s] threads: 64, tps: 0.00, reads: 0.00, writes: 127543.08, response time: 1.17ms (95%), errors: 0.00, reconnects:  0.00
[1900s] threads: 64, tps: 0.00, reads: 0.00, writes: 125247.96, response time: 1.21ms (95%), errors: 0.00, reconnects:  0.00
[1901s] threads: 64, tps: 0.00, reads: 0.00, writes: 124849.97, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1902s] threads: 64, tps: 0.00, reads: 0.00, writes: 126694.03, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1903s] threads: 64, tps: 0.00, reads: 0.00, writes: 124551.18, response time: 1.16ms (95%), errors: 0.00, reconnects:  0.00
[1904s] threads: 64, tps: 0.00, reads: 0.00, writes: 124983.72, response time: 1.10ms (95%), errors: 0.00, reconnects:  0.00
[1905s] threads: 64, tps: 0.00, reads: 0.00, writes: 127089.21, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1906s] threads: 64, tps: 0.00, reads: 0.00, writes: 126559.47, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1907s] threads: 64, tps: 0.00, reads: 0.00, writes: 127749.60, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[1908s] threads: 64, tps: 0.00, reads: 0.00, writes: 127985.82, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[1909s] threads: 64, tps: 0.00, reads: 0.00, writes: 126471.21, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1910s] threads: 64, tps: 0.00, reads: 0.00, writes: 125808.78, response time: 1.16ms (95%), errors: 0.00, reconnects:  0.00
[1911s] threads: 64, tps: 0.00, reads: 0.00, writes: 126797.99, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1912s] threads: 64, tps: 0.00, reads: 0.00, writes: 125960.72, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1913s] threads: 64, tps: 0.00, reads: 0.00, writes: 126604.48, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[1914s] threads: 64, tps: 0.00, reads: 0.00, writes: 127178.88, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1915s] threads: 64, tps: 0.00, reads: 0.00, writes: 124052.89, response time: 1.19ms (95%), errors: 0.00, reconnects:  0.00
[1916s] threads: 64, tps: 0.00, reads: 0.00, writes: 127076.03, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1917s] threads: 64, tps: 0.00, reads: 0.00, writes: 127999.94, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1918s] threads: 64, tps: 0.00, reads: 0.00, writes: 126597.10, response time: 1.18ms (95%), errors: 0.00, reconnects:  0.00
[1919s] threads: 64, tps: 0.00, reads: 0.00, writes: 127104.15, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1920s] threads: 64, tps: 0.00, reads: 0.00, writes: 127429.85, response time: 1.18ms (95%), errors: 0.00, reconnects:  0.00
[1921s] threads: 64, tps: 0.00, reads: 0.00, writes: 129462.05, response time: 0.98ms (95%), errors: 0.00, reconnects:  0.00
[1922s] threads: 64, tps: 0.00, reads: 0.00, writes: 127169.19, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1923s] threads: 64, tps: 0.00, reads: 0.00, writes: 127190.74, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[1924s] threads: 64, tps: 0.00, reads: 0.00, writes: 127428.05, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[1925s] threads: 64, tps: 0.00, reads: 0.00, writes: 127237.95, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1926s] threads: 64, tps: 0.00, reads: 0.00, writes: 124855.07, response time: 1.20ms (95%), errors: 0.00, reconnects:  0.00
[1927s] threads: 64, tps: 0.00, reads: 0.00, writes: 127589.96, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1928s] threads: 64, tps: 0.00, reads: 0.00, writes: 127191.04, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[1929s] threads: 64, tps: 0.00, reads: 0.00, writes: 130155.02, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[1930s] threads: 64, tps: 0.00, reads: 0.00, writes: 126503.55, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1931s] threads: 64, tps: 0.00, reads: 0.00, writes: 124738.40, response time: 1.10ms (95%), errors: 0.00, reconnects:  0.00
[1932s] threads: 64, tps: 0.00, reads: 0.00, writes: 125004.95, response time: 1.10ms (95%), errors: 0.00, reconnects:  0.00
[1933s] threads: 64, tps: 0.00, reads: 0.00, writes: 127706.93, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1934s] threads: 64, tps: 0.00, reads: 0.00, writes: 126992.06, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1935s] threads: 64, tps: 0.00, reads: 0.00, writes: 125407.05, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1936s] threads: 64, tps: 0.00, reads: 0.00, writes: 127519.18, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[1937s] threads: 64, tps: 0.00, reads: 0.00, writes: 125839.79, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[1938s] threads: 64, tps: 0.00, reads: 0.00, writes: 127648.98, response time: 1.15ms (95%), errors: 0.00, reconnects:  0.00
[1939s] threads: 64, tps: 0.00, reads: 0.00, writes: 123781.75, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1940s] threads: 64, tps: 0.00, reads: 0.00, writes: 125519.51, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1941s] threads: 64, tps: 0.00, reads: 0.00, writes: 128010.21, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[1942s] threads: 64, tps: 0.00, reads: 0.00, writes: 126665.72, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[1943s] threads: 64, tps: 0.00, reads: 0.00, writes: 125631.01, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1944s] threads: 64, tps: 0.00, reads: 0.00, writes: 127457.96, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[1945s] threads: 64, tps: 0.00, reads: 0.00, writes: 126368.76, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1946s] threads: 64, tps: 0.00, reads: 0.00, writes: 127883.17, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1947s] threads: 64, tps: 0.00, reads: 0.00, writes: 127419.00, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[1948s] threads: 64, tps: 0.00, reads: 0.00, writes: 128611.84, response time: 1.01ms (95%), errors: 0.00, reconnects:  0.00
[1949s] threads: 64, tps: 0.00, reads: 0.00, writes: 125798.02, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1950s] threads: 64, tps: 0.00, reads: 0.00, writes: 127155.30, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1951s] threads: 64, tps: 0.00, reads: 0.00, writes: 128603.00, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1952s] threads: 64, tps: 0.00, reads: 0.00, writes: 128860.81, response time: 0.98ms (95%), errors: 0.00, reconnects:  0.00
[1953s] threads: 64, tps: 0.00, reads: 0.00, writes: 128214.03, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1954s] threads: 64, tps: 0.00, reads: 0.00, writes: 127339.02, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1955s] threads: 64, tps: 0.00, reads: 0.00, writes: 127488.08, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1956s] threads: 64, tps: 0.00, reads: 0.00, writes: 127086.92, response time: 1.14ms (95%), errors: 0.00, reconnects:  0.00
[1957s] threads: 64, tps: 0.00, reads: 0.00, writes: 126058.83, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1958s] threads: 64, tps: 0.00, reads: 0.00, writes: 129015.24, response time: 1.00ms (95%), errors: 0.00, reconnects:  0.00
[1959s] threads: 64, tps: 0.00, reads: 0.00, writes: 126261.93, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[1960s] threads: 64, tps: 0.00, reads: 0.00, writes: 127599.95, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1961s] threads: 64, tps: 0.00, reads: 0.00, writes: 127978.01, response time: 1.01ms (95%), errors: 0.00, reconnects:  0.00
[1962s] threads: 64, tps: 0.00, reads: 0.00, writes: 127354.54, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1963s] threads: 64, tps: 0.00, reads: 0.00, writes: 126766.16, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[1964s] threads: 64, tps: 0.00, reads: 0.00, writes: 128484.39, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1965s] threads: 64, tps: 0.00, reads: 0.00, writes: 127965.02, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[1966s] threads: 64, tps: 0.00, reads: 0.00, writes: 127904.06, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[1967s] threads: 64, tps: 0.00, reads: 0.00, writes: 128068.90, response time: 1.00ms (95%), errors: 0.00, reconnects:  0.00
[1968s] threads: 64, tps: 0.00, reads: 0.00, writes: 128896.91, response time: 0.97ms (95%), errors: 0.00, reconnects:  0.00
[1969s] threads: 64, tps: 0.00, reads: 0.00, writes: 128118.11, response time: 1.00ms (95%), errors: 0.00, reconnects:  0.00
[1970s] threads: 64, tps: 0.00, reads: 0.00, writes: 127995.22, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1971s] threads: 64, tps: 0.00, reads: 0.00, writes: 129509.60, response time: 0.98ms (95%), errors: 0.00, reconnects:  0.00
[1972s] threads: 64, tps: 0.00, reads: 0.00, writes: 129652.76, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1973s] threads: 64, tps: 0.00, reads: 0.00, writes: 128588.17, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[1974s] threads: 64, tps: 0.00, reads: 0.00, writes: 128575.01, response time: 0.97ms (95%), errors: 0.00, reconnects:  0.00
[1975s] threads: 64, tps: 0.00, reads: 0.00, writes: 125497.22, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[1976s] threads: 64, tps: 0.00, reads: 0.00, writes: 125949.87, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1977s] threads: 64, tps: 0.00, reads: 0.00, writes: 129156.08, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[1978s] threads: 64, tps: 0.00, reads: 0.00, writes: 126087.00, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1979s] threads: 64, tps: 0.00, reads: 0.00, writes: 129052.04, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[1980s] threads: 64, tps: 0.00, reads: 0.00, writes: 127704.96, response time: 1.01ms (95%), errors: 0.00, reconnects:  0.00
[1981s] threads: 64, tps: 0.00, reads: 0.00, writes: 127432.58, response time: 1.01ms (95%), errors: 0.00, reconnects:  0.00
[1982s] threads: 64, tps: 0.00, reads: 0.00, writes: 128501.52, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[1983s] threads: 64, tps: 0.00, reads: 0.00, writes: 125874.87, response time: 1.00ms (95%), errors: 0.00, reconnects:  0.00
[1984s] threads: 64, tps: 0.00, reads: 0.00, writes: 128786.15, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[1985s] threads: 64, tps: 0.00, reads: 0.00, writes: 125844.99, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[1986s] threads: 64, tps: 0.00, reads: 0.00, writes: 127494.96, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[1987s] threads: 64, tps: 0.00, reads: 0.00, writes: 129696.76, response time: 0.95ms (95%), errors: 0.00, reconnects:  0.00
[1988s] threads: 64, tps: 0.00, reads: 0.00, writes: 126916.04, response time: 1.01ms (95%), errors: 0.00, reconnects:  0.00
[1989s] threads: 64, tps: 0.00, reads: 0.00, writes: 127044.09, response time: 1.00ms (95%), errors: 0.00, reconnects:  0.00
[1990s] threads: 64, tps: 0.00, reads: 0.00, writes: 126900.06, response time: 0.99ms (95%), errors: 0.00, reconnects:  0.00
[1991s] threads: 64, tps: 0.00, reads: 0.00, writes: 128800.95, response time: 1.00ms (95%), errors: 0.00, reconnects:  0.00
[1992s] threads: 64, tps: 0.00, reads: 0.00, writes: 125043.33, response time: 0.98ms (95%), errors: 0.00, reconnects:  0.00
[1993s] threads: 64, tps: 0.00, reads: 0.00, writes: 125103.23, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[1994s] threads: 64, tps: 0.00, reads: 0.00, writes: 125927.35, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[1995s] threads: 64, tps: 0.00, reads: 0.00, writes: 126844.05, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[1996s] threads: 64, tps: 0.00, reads: 0.00, writes: 128286.60, response time: 1.01ms (95%), errors: 0.00, reconnects:  0.00
[1997s] threads: 64, tps: 0.00, reads: 0.00, writes: 127670.45, response time: 0.95ms (95%), errors: 0.00, reconnects:  0.00
[1998s] threads: 64, tps: 0.00, reads: 0.00, writes: 127176.94, response time: 0.99ms (95%), errors: 0.00, reconnects:  0.00
[1999s] threads: 64, tps: 0.00, reads: 0.00, writes: 127291.11, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[2000s] threads: 64, tps: 0.00, reads: 0.00, writes: 126610.93, response time: 0.94ms (95%), errors: 0.00, reconnects:  0.00
[2001s] threads: 64, tps: 0.00, reads: 0.00, writes: 129519.14, response time: 0.98ms (95%), errors: 0.00, reconnects:  0.00
[2002s] threads: 64, tps: 0.00, reads: 0.00, writes: 124172.01, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[2003s] threads: 64, tps: 0.00, reads: 0.00, writes: 129292.87, response time: 0.94ms (95%), errors: 0.00, reconnects:  0.00
[2004s] threads: 64, tps: 0.00, reads: 0.00, writes: 126553.02, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[2005s] threads: 64, tps: 0.00, reads: 0.00, writes: 126711.93, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[2006s] threads: 64, tps: 0.00, reads: 0.00, writes: 127432.97, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[2007s] threads: 64, tps: 0.00, reads: 0.00, writes: 128701.93, response time: 0.98ms (95%), errors: 0.00, reconnects:  0.00
[2008s] threads: 64, tps: 0.00, reads: 0.00, writes: 126577.05, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[2009s] threads: 64, tps: 0.00, reads: 0.00, writes: 126263.20, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[2010s] threads: 64, tps: 0.00, reads: 0.00, writes: 127956.63, response time: 1.00ms (95%), errors: 0.00, reconnects:  0.00
[2011s] threads: 64, tps: 0.00, reads: 0.00, writes: 128293.30, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[2012s] threads: 64, tps: 0.00, reads: 0.00, writes: 128074.99, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[2013s] threads: 64, tps: 0.00, reads: 0.00, writes: 128308.90, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[2014s] threads: 64, tps: 0.00, reads: 0.00, writes: 128937.96, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[2015s] threads: 64, tps: 0.00, reads: 0.00, writes: 129434.07, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[2016s] threads: 64, tps: 0.00, reads: 0.00, writes: 127855.96, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[2017s] threads: 64, tps: 0.00, reads: 0.00, writes: 129726.54, response time: 0.96ms (95%), errors: 0.00, reconnects:  0.00
[2018s] threads: 64, tps: 0.00, reads: 0.00, writes: 127158.44, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[2019s] threads: 64, tps: 0.00, reads: 0.00, writes: 129510.00, response time: 0.98ms (95%), errors: 0.00, reconnects:  0.00
[2020s] threads: 64, tps: 0.00, reads: 0.00, writes: 126266.03, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[2021s] threads: 64, tps: 0.00, reads: 0.00, writes: 129662.84, response time: 0.95ms (95%), errors: 0.00, reconnects:  0.00
[2022s] threads: 64, tps: 0.00, reads: 0.00, writes: 124286.32, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[2023s] threads: 64, tps: 0.00, reads: 0.00, writes: 128728.74, response time: 0.99ms (95%), errors: 0.00, reconnects:  0.00
[2024s] threads: 64, tps: 0.00, reads: 0.00, writes: 127781.12, response time: 1.07ms (95%), errors: 0.00, reconnects:  0.00
[2025s] threads: 64, tps: 0.00, reads: 0.00, writes: 127354.47, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[2026s] threads: 64, tps: 0.00, reads: 0.00, writes: 126529.15, response time: 1.09ms (95%), errors: 0.00, reconnects:  0.00
[2027s] threads: 64, tps: 0.00, reads: 0.00, writes: 129125.46, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[2028s] threads: 64, tps: 0.00, reads: 0.00, writes: 127802.93, response time: 1.06ms (95%), errors: 0.00, reconnects:  0.00
[2029s] threads: 64, tps: 0.00, reads: 0.00, writes: 130532.91, response time: 0.98ms (95%), errors: 0.00, reconnects:  0.00
[2030s] threads: 64, tps: 0.00, reads: 0.00, writes: 128345.25, response time: 1.01ms (95%), errors: 0.00, reconnects:  0.00
[2031s] threads: 64, tps: 0.00, reads: 0.00, writes: 128913.86, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[2032s] threads: 64, tps: 0.00, reads: 0.00, writes: 128994.05, response time: 0.96ms (95%), errors: 0.00, reconnects:  0.00
[2033s] threads: 64, tps: 0.00, reads: 0.00, writes: 128271.00, response time: 0.97ms (95%), errors: 0.00, reconnects:  0.00
[2034s] threads: 64, tps: 0.00, reads: 0.00, writes: 129016.97, response time: 0.95ms (95%), errors: 0.00, reconnects:  0.00
[2035s] threads: 64, tps: 0.00, reads: 0.00, writes: 128273.86, response time: 0.95ms (95%), errors: 0.00, reconnects:  0.00
[2036s] threads: 64, tps: 0.00, reads: 0.00, writes: 127221.54, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[2037s] threads: 64, tps: 0.00, reads: 0.00, writes: 128450.56, response time: 0.97ms (95%), errors: 0.00, reconnects:  0.00
[2038s] threads: 64, tps: 0.00, reads: 0.00, writes: 129626.04, response time: 1.01ms (95%), errors: 0.00, reconnects:  0.00
[2039s] threads: 64, tps: 0.00, reads: 0.00, writes: 129765.11, response time: 0.96ms (95%), errors: 0.00, reconnects:  0.00
[2040s] threads: 64, tps: 0.00, reads: 0.00, writes: 126255.89, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2041s] threads: 64, tps: 0.00, reads: 0.00, writes: 126771.09, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2042s] threads: 64, tps: 0.00, reads: 0.00, writes: 121785.38, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[2043s] threads: 64, tps: 0.00, reads: 0.00, writes: 132401.68, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2044s] threads: 64, tps: 0.00, reads: 0.00, writes: 132007.36, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2045s] threads: 64, tps: 0.00, reads: 0.00, writes: 132686.05, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2046s] threads: 64, tps: 0.00, reads: 0.00, writes: 133049.46, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2047s] threads: 64, tps: 0.00, reads: 0.00, writes: 132821.48, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2048s] threads: 64, tps: 0.00, reads: 0.00, writes: 132241.79, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2049s] threads: 64, tps: 0.00, reads: 0.00, writes: 131801.23, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2050s] threads: 64, tps: 0.00, reads: 0.00, writes: 131841.98, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2051s] threads: 64, tps: 0.00, reads: 0.00, writes: 131253.06, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2052s] threads: 64, tps: 0.00, reads: 0.00, writes: 132876.96, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2053s] threads: 64, tps: 0.00, reads: 0.00, writes: 131806.07, response time: 0.93ms (95%), errors: 0.00, reconnects:  0.00
[2054s] threads: 64, tps: 0.00, reads: 0.00, writes: 128086.09, response time: 0.93ms (95%), errors: 0.00, reconnects:  0.00
[2055s] threads: 64, tps: 0.00, reads: 0.00, writes: 130904.97, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2056s] threads: 64, tps: 0.00, reads: 0.00, writes: 132442.90, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2057s] threads: 64, tps: 0.00, reads: 0.00, writes: 132039.07, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2058s] threads: 64, tps: 0.00, reads: 0.00, writes: 131181.86, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2059s] threads: 64, tps: 0.00, reads: 0.00, writes: 131803.92, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2060s] threads: 64, tps: 0.00, reads: 0.00, writes: 131991.13, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2061s] threads: 64, tps: 0.00, reads: 0.00, writes: 130243.25, response time: 0.93ms (95%), errors: 0.00, reconnects:  0.00
[2062s] threads: 64, tps: 0.00, reads: 0.00, writes: 131227.70, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2063s] threads: 64, tps: 0.00, reads: 0.00, writes: 129457.03, response time: 0.93ms (95%), errors: 0.00, reconnects:  0.00
[2064s] threads: 64, tps: 0.00, reads: 0.00, writes: 130513.08, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2065s] threads: 64, tps: 0.00, reads: 0.00, writes: 131662.35, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2066s] threads: 64, tps: 0.00, reads: 0.00, writes: 129243.69, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2067s] threads: 64, tps: 0.00, reads: 0.00, writes: 131852.49, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2068s] threads: 64, tps: 0.00, reads: 0.00, writes: 130418.30, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2069s] threads: 64, tps: 0.00, reads: 0.00, writes: 130337.29, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2070s] threads: 64, tps: 0.00, reads: 0.00, writes: 131691.82, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2071s] threads: 64, tps: 0.00, reads: 0.00, writes: 130419.02, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2072s] threads: 64, tps: 0.00, reads: 0.00, writes: 131472.86, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2073s] threads: 64, tps: 0.00, reads: 0.00, writes: 129455.02, response time: 0.94ms (95%), errors: 0.00, reconnects:  0.00
[2074s] threads: 64, tps: 0.00, reads: 0.00, writes: 131362.53, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2075s] threads: 64, tps: 0.00, reads: 0.00, writes: 128826.39, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2076s] threads: 64, tps: 0.00, reads: 0.00, writes: 129890.42, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2077s] threads: 64, tps: 0.00, reads: 0.00, writes: 130586.62, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2078s] threads: 64, tps: 0.00, reads: 0.00, writes: 130639.12, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2079s] threads: 64, tps: 0.00, reads: 0.00, writes: 131280.90, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2080s] threads: 64, tps: 0.00, reads: 0.00, writes: 129184.65, response time: 0.95ms (95%), errors: 0.00, reconnects:  0.00
[2081s] threads: 64, tps: 0.00, reads: 0.00, writes: 130224.45, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2082s] threads: 64, tps: 0.00, reads: 0.00, writes: 128989.13, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2083s] threads: 64, tps: 0.00, reads: 0.00, writes: 130428.83, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2084s] threads: 64, tps: 0.00, reads: 0.00, writes: 130270.07, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2085s] threads: 64, tps: 0.00, reads: 0.00, writes: 131668.82, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2086s] threads: 64, tps: 0.00, reads: 0.00, writes: 128932.04, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2087s] threads: 64, tps: 0.00, reads: 0.00, writes: 129831.18, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2088s] threads: 64, tps: 0.00, reads: 0.00, writes: 128255.93, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2089s] threads: 64, tps: 0.00, reads: 0.00, writes: 127888.14, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2090s] threads: 64, tps: 0.00, reads: 0.00, writes: 129068.70, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2091s] threads: 64, tps: 0.00, reads: 0.00, writes: 128821.99, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2092s] threads: 64, tps: 0.00, reads: 0.00, writes: 126734.27, response time: 0.98ms (95%), errors: 0.00, reconnects:  0.00
[2093s] threads: 64, tps: 0.00, reads: 0.00, writes: 129148.91, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2094s] threads: 64, tps: 0.00, reads: 0.00, writes: 129213.97, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2095s] threads: 64, tps: 0.00, reads: 0.00, writes: 129138.97, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2096s] threads: 64, tps: 0.00, reads: 0.00, writes: 127608.98, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2097s] threads: 64, tps: 0.00, reads: 0.00, writes: 128179.98, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2098s] threads: 64, tps: 0.00, reads: 0.00, writes: 129471.94, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2099s] threads: 64, tps: 0.00, reads: 0.00, writes: 129274.00, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2100s] threads: 64, tps: 0.00, reads: 0.00, writes: 128097.11, response time: 0.95ms (95%), errors: 0.00, reconnects:  0.00
[2101s] threads: 64, tps: 0.00, reads: 0.00, writes: 127734.04, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2102s] threads: 64, tps: 0.00, reads: 0.00, writes: 128757.03, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2103s] threads: 64, tps: 0.00, reads: 0.00, writes: 130772.05, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2104s] threads: 64, tps: 0.00, reads: 0.00, writes: 128893.90, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2105s] threads: 64, tps: 0.00, reads: 0.00, writes: 129301.96, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2106s] threads: 64, tps: 0.00, reads: 0.00, writes: 130564.79, response time: 0.93ms (95%), errors: 0.00, reconnects:  0.00
[2107s] threads: 64, tps: 0.00, reads: 0.00, writes: 129633.28, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2108s] threads: 64, tps: 0.00, reads: 0.00, writes: 131075.97, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2109s] threads: 64, tps: 0.00, reads: 0.00, writes: 130342.95, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2110s] threads: 64, tps: 0.00, reads: 0.00, writes: 129234.99, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2111s] threads: 64, tps: 0.00, reads: 0.00, writes: 130414.03, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2112s] threads: 64, tps: 0.00, reads: 0.00, writes: 129513.19, response time: 0.93ms (95%), errors: 0.00, reconnects:  0.00
[2113s] threads: 64, tps: 0.00, reads: 0.00, writes: 130430.86, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2114s] threads: 64, tps: 0.00, reads: 0.00, writes: 131953.94, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2115s] threads: 64, tps: 0.00, reads: 0.00, writes: 129475.99, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2116s] threads: 64, tps: 0.00, reads: 0.00, writes: 128666.91, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2117s] threads: 64, tps: 0.00, reads: 0.00, writes: 128533.62, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2118s] threads: 64, tps: 0.00, reads: 0.00, writes: 130445.45, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2119s] threads: 64, tps: 0.00, reads: 0.00, writes: 127931.03, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2120s] threads: 64, tps: 0.00, reads: 0.00, writes: 130761.02, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2121s] threads: 64, tps: 0.00, reads: 0.00, writes: 130411.02, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2122s] threads: 64, tps: 0.00, reads: 0.00, writes: 130485.91, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2123s] threads: 64, tps: 0.00, reads: 0.00, writes: 129113.74, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2124s] threads: 64, tps: 0.00, reads: 0.00, writes: 130090.39, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2125s] threads: 64, tps: 0.00, reads: 0.00, writes: 127870.01, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2126s] threads: 64, tps: 0.00, reads: 0.00, writes: 129255.81, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2127s] threads: 64, tps: 0.00, reads: 0.00, writes: 129967.03, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2128s] threads: 64, tps: 0.00, reads: 0.00, writes: 130771.09, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2129s] threads: 64, tps: 0.00, reads: 0.00, writes: 127543.04, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2130s] threads: 64, tps: 0.00, reads: 0.00, writes: 128557.89, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2131s] threads: 64, tps: 0.00, reads: 0.00, writes: 129148.04, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2132s] threads: 64, tps: 0.00, reads: 0.00, writes: 128035.00, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2133s] threads: 64, tps: 0.00, reads: 0.00, writes: 130618.02, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2134s] threads: 64, tps: 0.00, reads: 0.00, writes: 129225.95, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2135s] threads: 64, tps: 0.00, reads: 0.00, writes: 129144.17, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2136s] threads: 64, tps: 0.00, reads: 0.00, writes: 127591.90, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2137s] threads: 64, tps: 0.00, reads: 0.00, writes: 128018.90, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2138s] threads: 64, tps: 0.00, reads: 0.00, writes: 129590.48, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2139s] threads: 64, tps: 0.00, reads: 0.00, writes: 129489.47, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2140s] threads: 64, tps: 0.00, reads: 0.00, writes: 131514.12, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2141s] threads: 64, tps: 0.00, reads: 0.00, writes: 130846.16, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2142s] threads: 64, tps: 0.00, reads: 0.00, writes: 128974.78, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2143s] threads: 64, tps: 0.00, reads: 0.00, writes: 129969.95, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2144s] threads: 64, tps: 0.00, reads: 0.00, writes: 128466.21, response time: 0.93ms (95%), errors: 0.00, reconnects:  0.00
[2145s] threads: 64, tps: 0.00, reads: 0.00, writes: 130138.87, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2146s] threads: 64, tps: 0.00, reads: 0.00, writes: 127359.66, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2147s] threads: 64, tps: 0.00, reads: 0.00, writes: 126412.24, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[2148s] threads: 64, tps: 0.00, reads: 0.00, writes: 129259.04, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2149s] threads: 64, tps: 0.00, reads: 0.00, writes: 130993.94, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2150s] threads: 64, tps: 0.00, reads: 0.00, writes: 129069.17, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2151s] threads: 64, tps: 0.00, reads: 0.00, writes: 128579.91, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2152s] threads: 64, tps: 0.00, reads: 0.00, writes: 128686.09, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2153s] threads: 64, tps: 0.00, reads: 0.00, writes: 127611.88, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2154s] threads: 64, tps: 0.00, reads: 0.00, writes: 128990.98, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2155s] threads: 64, tps: 0.00, reads: 0.00, writes: 129966.89, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2156s] threads: 64, tps: 0.00, reads: 0.00, writes: 127979.27, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2157s] threads: 64, tps: 0.00, reads: 0.00, writes: 129175.93, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2158s] threads: 64, tps: 0.00, reads: 0.00, writes: 127807.00, response time: 0.93ms (95%), errors: 0.00, reconnects:  0.00
[2159s] threads: 64, tps: 0.00, reads: 0.00, writes: 129406.97, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2160s] threads: 64, tps: 0.00, reads: 0.00, writes: 129154.93, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2161s] threads: 64, tps: 0.00, reads: 0.00, writes: 128249.17, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2162s] threads: 64, tps: 0.00, reads: 0.00, writes: 129607.96, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2163s] threads: 64, tps: 0.00, reads: 0.00, writes: 129533.89, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2164s] threads: 64, tps: 0.00, reads: 0.00, writes: 127703.32, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2165s] threads: 64, tps: 0.00, reads: 0.00, writes: 129585.79, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2166s] threads: 64, tps: 0.00, reads: 0.00, writes: 128777.98, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2167s] threads: 64, tps: 0.00, reads: 0.00, writes: 128259.05, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2168s] threads: 64, tps: 0.00, reads: 0.00, writes: 129037.93, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2169s] threads: 64, tps: 0.00, reads: 0.00, writes: 127417.12, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2170s] threads: 64, tps: 0.00, reads: 0.00, writes: 127954.98, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2171s] threads: 64, tps: 0.00, reads: 0.00, writes: 129695.58, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2172s] threads: 64, tps: 0.00, reads: 0.00, writes: 128015.40, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2173s] threads: 64, tps: 0.00, reads: 0.00, writes: 129855.88, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2174s] threads: 64, tps: 0.00, reads: 0.00, writes: 130520.95, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2175s] threads: 64, tps: 0.00, reads: 0.00, writes: 129314.99, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2176s] threads: 64, tps: 0.00, reads: 0.00, writes: 128887.94, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2177s] threads: 64, tps: 0.00, reads: 0.00, writes: 129641.39, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2178s] threads: 64, tps: 0.00, reads: 0.00, writes: 129464.78, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2179s] threads: 64, tps: 0.00, reads: 0.00, writes: 130019.07, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2180s] threads: 64, tps: 0.00, reads: 0.00, writes: 128275.97, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2181s] threads: 64, tps: 0.00, reads: 0.00, writes: 130289.00, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2182s] threads: 64, tps: 0.00, reads: 0.00, writes: 130023.96, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2183s] threads: 64, tps: 0.00, reads: 0.00, writes: 130889.97, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2184s] threads: 64, tps: 0.00, reads: 0.00, writes: 130254.68, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2185s] threads: 64, tps: 0.00, reads: 0.00, writes: 129697.42, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2186s] threads: 64, tps: 0.00, reads: 0.00, writes: 130618.01, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2187s] threads: 64, tps: 0.00, reads: 0.00, writes: 130296.38, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2188s] threads: 64, tps: 0.00, reads: 0.00, writes: 129077.00, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2189s] threads: 64, tps: 0.00, reads: 0.00, writes: 130507.68, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2190s] threads: 64, tps: 0.00, reads: 0.00, writes: 129673.56, response time: 0.93ms (95%), errors: 0.00, reconnects:  0.00
[2191s] threads: 64, tps: 0.00, reads: 0.00, writes: 129634.36, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2192s] threads: 64, tps: 0.00, reads: 0.00, writes: 130001.89, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2193s] threads: 64, tps: 0.00, reads: 0.00, writes: 127908.13, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2194s] threads: 64, tps: 0.00, reads: 0.00, writes: 128893.02, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2195s] threads: 64, tps: 0.00, reads: 0.00, writes: 130641.12, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2196s] threads: 64, tps: 0.00, reads: 0.00, writes: 129673.81, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2197s] threads: 64, tps: 0.00, reads: 0.00, writes: 129879.96, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2198s] threads: 64, tps: 0.00, reads: 0.00, writes: 130251.11, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2199s] threads: 64, tps: 0.00, reads: 0.00, writes: 130569.05, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2200s] threads: 64, tps: 0.00, reads: 0.00, writes: 129637.45, response time: 0.93ms (95%), errors: 0.00, reconnects:  0.00
[2201s] threads: 64, tps: 0.00, reads: 0.00, writes: 129099.52, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2202s] threads: 64, tps: 0.00, reads: 0.00, writes: 130103.95, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2203s] threads: 64, tps: 0.00, reads: 0.00, writes: 128127.08, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2204s] threads: 64, tps: 0.00, reads: 0.00, writes: 129559.81, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2205s] threads: 64, tps: 0.00, reads: 0.00, writes: 130374.10, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2206s] threads: 64, tps: 0.00, reads: 0.00, writes: 129291.97, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2207s] threads: 64, tps: 0.00, reads: 0.00, writes: 129578.02, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2208s] threads: 64, tps: 0.00, reads: 0.00, writes: 129313.22, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[2209s] threads: 64, tps: 0.00, reads: 0.00, writes: 129047.92, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2210s] threads: 64, tps: 0.00, reads: 0.00, writes: 130506.78, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2211s] threads: 64, tps: 0.00, reads: 0.00, writes: 129891.17, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2212s] threads: 64, tps: 0.00, reads: 0.00, writes: 123712.95, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2213s] threads: 64, tps: 0.00, reads: 0.00, writes: 130504.79, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2214s] threads: 64, tps: 0.00, reads: 0.00, writes: 128717.42, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2215s] threads: 64, tps: 0.00, reads: 0.00, writes: 129294.69, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2216s] threads: 64, tps: 0.00, reads: 0.00, writes: 129907.01, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2217s] threads: 64, tps: 0.00, reads: 0.00, writes: 130024.34, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2218s] threads: 64, tps: 0.00, reads: 0.00, writes: 129643.55, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2219s] threads: 64, tps: 0.00, reads: 0.00, writes: 129631.14, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2220s] threads: 64, tps: 0.00, reads: 0.00, writes: 129798.94, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2221s] threads: 64, tps: 0.00, reads: 0.00, writes: 130001.93, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2222s] threads: 64, tps: 0.00, reads: 0.00, writes: 130936.13, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2223s] threads: 64, tps: 0.00, reads: 0.00, writes: 129403.89, response time: 0.94ms (95%), errors: 0.00, reconnects:  0.00
[2224s] threads: 64, tps: 0.00, reads: 0.00, writes: 130467.19, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2225s] threads: 64, tps: 0.00, reads: 0.00, writes: 129684.89, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2226s] threads: 64, tps: 0.00, reads: 0.00, writes: 127661.99, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2227s] threads: 64, tps: 0.00, reads: 0.00, writes: 129386.64, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2228s] threads: 64, tps: 0.00, reads: 0.00, writes: 129348.43, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2229s] threads: 64, tps: 0.00, reads: 0.00, writes: 128840.07, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2230s] threads: 64, tps: 0.00, reads: 0.00, writes: 131032.84, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2231s] threads: 64, tps: 0.00, reads: 0.00, writes: 129370.19, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2232s] threads: 64, tps: 0.00, reads: 0.00, writes: 129795.34, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2233s] threads: 64, tps: 0.00, reads: 0.00, writes: 130247.61, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2234s] threads: 64, tps: 0.00, reads: 0.00, writes: 131656.72, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2235s] threads: 64, tps: 0.00, reads: 0.00, writes: 128211.21, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2236s] threads: 64, tps: 0.00, reads: 0.00, writes: 129987.94, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2237s] threads: 64, tps: 0.00, reads: 0.00, writes: 130541.04, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2238s] threads: 64, tps: 0.00, reads: 0.00, writes: 129169.91, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2239s] threads: 64, tps: 0.00, reads: 0.00, writes: 127986.08, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2240s] threads: 64, tps: 0.00, reads: 0.00, writes: 130943.00, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2241s] threads: 64, tps: 0.00, reads: 0.00, writes: 129623.91, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2242s] threads: 64, tps: 0.00, reads: 0.00, writes: 131068.23, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2243s] threads: 64, tps: 0.00, reads: 0.00, writes: 130062.94, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2244s] threads: 64, tps: 0.00, reads: 0.00, writes: 131207.37, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2245s] threads: 64, tps: 0.00, reads: 0.00, writes: 130219.60, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2246s] threads: 64, tps: 0.00, reads: 0.00, writes: 130280.93, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2247s] threads: 64, tps: 0.00, reads: 0.00, writes: 131064.06, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2248s] threads: 64, tps: 0.00, reads: 0.00, writes: 131191.89, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2249s] threads: 64, tps: 0.00, reads: 0.00, writes: 131276.31, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2250s] threads: 64, tps: 0.00, reads: 0.00, writes: 127592.82, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2251s] threads: 64, tps: 0.00, reads: 0.00, writes: 128299.75, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2252s] threads: 64, tps: 0.00, reads: 0.00, writes: 127671.15, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2253s] threads: 64, tps: 0.00, reads: 0.00, writes: 128685.85, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[2254s] threads: 64, tps: 0.00, reads: 0.00, writes: 124864.22, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2255s] threads: 64, tps: 0.00, reads: 0.00, writes: 128725.93, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2256s] threads: 64, tps: 0.00, reads: 0.00, writes: 128739.99, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[2257s] threads: 64, tps: 0.00, reads: 0.00, writes: 130101.97, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2258s] threads: 64, tps: 0.00, reads: 0.00, writes: 130298.25, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2259s] threads: 64, tps: 0.00, reads: 0.00, writes: 129320.73, response time: 0.92ms (95%), errors: 0.00, reconnects:  0.00
[2260s] threads: 64, tps: 0.00, reads: 0.00, writes: 129811.03, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2261s] threads: 64, tps: 0.00, reads: 0.00, writes: 129064.05, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2262s] threads: 64, tps: 0.00, reads: 0.00, writes: 129729.94, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2263s] threads: 64, tps: 0.00, reads: 0.00, writes: 129483.08, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[2264s] threads: 64, tps: 0.00, reads: 0.00, writes: 130072.13, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2265s] threads: 64, tps: 0.00, reads: 0.00, writes: 130237.85, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2266s] threads: 64, tps: 0.00, reads: 0.00, writes: 130480.57, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2267s] threads: 64, tps: 0.00, reads: 0.00, writes: 130079.36, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2268s] threads: 64, tps: 0.00, reads: 0.00, writes: 128847.99, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2269s] threads: 64, tps: 0.00, reads: 0.00, writes: 130303.13, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2270s] threads: 64, tps: 0.00, reads: 0.00, writes: 129448.98, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2271s] threads: 64, tps: 0.00, reads: 0.00, writes: 130404.17, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2272s] threads: 64, tps: 0.00, reads: 0.00, writes: 129401.77, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2273s] threads: 64, tps: 0.00, reads: 0.00, writes: 130309.04, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2274s] threads: 64, tps: 0.00, reads: 0.00, writes: 130831.02, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2275s] threads: 64, tps: 0.00, reads: 0.00, writes: 129941.94, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2276s] threads: 64, tps: 0.00, reads: 0.00, writes: 130588.06, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2277s] threads: 64, tps: 0.00, reads: 0.00, writes: 128461.02, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2278s] threads: 64, tps: 0.00, reads: 0.00, writes: 130510.98, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2279s] threads: 64, tps: 0.00, reads: 0.00, writes: 130184.89, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2280s] threads: 64, tps: 0.00, reads: 0.00, writes: 130693.16, response time: 0.85ms (95%), errors: 0.00, reconnects:  0.00
[2281s] threads: 64, tps: 0.00, reads: 0.00, writes: 129818.06, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2282s] threads: 64, tps: 0.00, reads: 0.00, writes: 131011.86, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2283s] threads: 64, tps: 0.00, reads: 0.00, writes: 129589.30, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2284s] threads: 64, tps: 0.00, reads: 0.00, writes: 129790.74, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2285s] threads: 64, tps: 0.00, reads: 0.00, writes: 131227.94, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2286s] threads: 64, tps: 0.00, reads: 0.00, writes: 129690.00, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2287s] threads: 64, tps: 0.00, reads: 0.00, writes: 130552.83, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2288s] threads: 64, tps: 0.00, reads: 0.00, writes: 130873.31, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2289s] threads: 64, tps: 0.00, reads: 0.00, writes: 129740.75, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2290s] threads: 64, tps: 0.00, reads: 0.00, writes: 129933.15, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2291s] threads: 64, tps: 0.00, reads: 0.00, writes: 130855.06, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2292s] threads: 64, tps: 0.00, reads: 0.00, writes: 130374.12, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2293s] threads: 64, tps: 0.00, reads: 0.00, writes: 130738.77, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2294s] threads: 64, tps: 0.00, reads: 0.00, writes: 130315.16, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2295s] threads: 64, tps: 0.00, reads: 0.00, writes: 129323.85, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2296s] threads: 64, tps: 0.00, reads: 0.00, writes: 130646.94, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2297s] threads: 64, tps: 0.00, reads: 0.00, writes: 130159.07, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2298s] threads: 64, tps: 0.00, reads: 0.00, writes: 130975.39, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2299s] threads: 64, tps: 0.00, reads: 0.00, writes: 129291.05, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[2300s] threads: 64, tps: 0.00, reads: 0.00, writes: 131279.62, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2301s] threads: 64, tps: 0.00, reads: 0.00, writes: 130667.07, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2302s] threads: 64, tps: 0.00, reads: 0.00, writes: 130578.96, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2303s] threads: 64, tps: 0.00, reads: 0.00, writes: 128884.37, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2304s] threads: 64, tps: 0.00, reads: 0.00, writes: 127348.80, response time: 0.86ms (95%), errors: 0.00, reconnects:  0.00
[2305s] threads: 64, tps: 0.00, reads: 0.00, writes: 130682.81, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2306s] threads: 64, tps: 0.00, reads: 0.00, writes: 130985.09, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2307s] threads: 64, tps: 0.00, reads: 0.00, writes: 129201.84, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2308s] threads: 64, tps: 0.00, reads: 0.00, writes: 130899.98, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2309s] threads: 64, tps: 0.00, reads: 0.00, writes: 130060.98, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2310s] threads: 64, tps: 0.00, reads: 0.00, writes: 130260.17, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2311s] threads: 64, tps: 0.00, reads: 0.00, writes: 128637.94, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2312s] threads: 64, tps: 0.00, reads: 0.00, writes: 129547.86, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[2313s] threads: 64, tps: 0.00, reads: 0.00, writes: 130904.11, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2314s] threads: 64, tps: 0.00, reads: 0.00, writes: 130606.16, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2315s] threads: 64, tps: 0.00, reads: 0.00, writes: 130420.83, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2316s] threads: 64, tps: 0.00, reads: 0.00, writes: 130604.99, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2317s] threads: 64, tps: 0.00, reads: 0.00, writes: 129050.59, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2318s] threads: 64, tps: 0.00, reads: 0.00, writes: 129800.41, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2319s] threads: 64, tps: 0.00, reads: 0.00, writes: 130626.95, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2320s] threads: 64, tps: 0.00, reads: 0.00, writes: 130982.12, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2321s] threads: 64, tps: 0.00, reads: 0.00, writes: 130043.02, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2322s] threads: 64, tps: 0.00, reads: 0.00, writes: 130926.06, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2323s] threads: 64, tps: 0.00, reads: 0.00, writes: 129937.78, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2324s] threads: 64, tps: 0.00, reads: 0.00, writes: 130284.19, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2325s] threads: 64, tps: 0.00, reads: 0.00, writes: 131026.05, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2326s] threads: 64, tps: 0.00, reads: 0.00, writes: 130692.97, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2327s] threads: 64, tps: 0.00, reads: 0.00, writes: 130514.84, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2328s] threads: 64, tps: 0.00, reads: 0.00, writes: 130934.07, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2329s] threads: 64, tps: 0.00, reads: 0.00, writes: 129943.27, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2330s] threads: 64, tps: 0.00, reads: 0.00, writes: 126479.67, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2331s] threads: 64, tps: 0.00, reads: 0.00, writes: 125470.39, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2332s] threads: 64, tps: 0.00, reads: 0.00, writes: 124983.66, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2333s] threads: 64, tps: 0.00, reads: 0.00, writes: 132593.96, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2334s] threads: 64, tps: 0.00, reads: 0.00, writes: 133211.00, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2335s] threads: 64, tps: 0.00, reads: 0.00, writes: 132703.02, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2336s] threads: 64, tps: 0.00, reads: 0.00, writes: 132769.92, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2337s] threads: 64, tps: 0.00, reads: 0.00, writes: 132806.03, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2338s] threads: 64, tps: 0.00, reads: 0.00, writes: 132220.05, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2339s] threads: 64, tps: 0.00, reads: 0.00, writes: 131868.82, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2340s] threads: 64, tps: 0.00, reads: 0.00, writes: 133217.14, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2341s] threads: 64, tps: 0.00, reads: 0.00, writes: 133142.23, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2342s] threads: 64, tps: 0.00, reads: 0.00, writes: 132510.77, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2343s] threads: 64, tps: 0.00, reads: 0.00, writes: 132560.18, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2344s] threads: 64, tps: 0.00, reads: 0.00, writes: 132442.96, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2345s] threads: 64, tps: 0.00, reads: 0.00, writes: 132280.77, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2346s] threads: 64, tps: 0.00, reads: 0.00, writes: 131891.09, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2347s] threads: 64, tps: 0.00, reads: 0.00, writes: 131830.52, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2348s] threads: 64, tps: 0.00, reads: 0.00, writes: 132673.65, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2349s] threads: 64, tps: 0.00, reads: 0.00, writes: 132761.84, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2350s] threads: 64, tps: 0.00, reads: 0.00, writes: 132032.99, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2351s] threads: 64, tps: 0.00, reads: 0.00, writes: 131141.09, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2352s] threads: 64, tps: 0.00, reads: 0.00, writes: 132125.92, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2353s] threads: 64, tps: 0.00, reads: 0.00, writes: 131614.15, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2354s] threads: 64, tps: 0.00, reads: 0.00, writes: 132243.88, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2355s] threads: 64, tps: 0.00, reads: 0.00, writes: 131174.96, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2356s] threads: 64, tps: 0.00, reads: 0.00, writes: 132478.03, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2357s] threads: 64, tps: 0.00, reads: 0.00, writes: 129913.02, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2358s] threads: 64, tps: 0.00, reads: 0.00, writes: 131270.95, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2359s] threads: 64, tps: 0.00, reads: 0.00, writes: 129127.14, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2360s] threads: 64, tps: 0.00, reads: 0.00, writes: 131675.92, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2361s] threads: 64, tps: 0.00, reads: 0.00, writes: 131515.96, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2362s] threads: 64, tps: 0.00, reads: 0.00, writes: 131775.01, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2363s] threads: 64, tps: 0.00, reads: 0.00, writes: 131718.93, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2364s] threads: 64, tps: 0.00, reads: 0.00, writes: 131775.29, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2365s] threads: 64, tps: 0.00, reads: 0.00, writes: 131256.66, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2366s] threads: 64, tps: 0.00, reads: 0.00, writes: 128372.79, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2367s] threads: 64, tps: 0.00, reads: 0.00, writes: 131797.41, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2368s] threads: 64, tps: 0.00, reads: 0.00, writes: 131856.87, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2369s] threads: 64, tps: 0.00, reads: 0.00, writes: 130295.63, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2370s] threads: 64, tps: 0.00, reads: 0.00, writes: 129137.62, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2371s] threads: 64, tps: 0.00, reads: 0.00, writes: 130462.51, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2372s] threads: 64, tps: 0.00, reads: 0.00, writes: 129504.10, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2373s] threads: 64, tps: 0.00, reads: 0.00, writes: 128051.27, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2374s] threads: 64, tps: 0.00, reads: 0.00, writes: 130189.97, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2375s] threads: 64, tps: 0.00, reads: 0.00, writes: 128483.82, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2376s] threads: 64, tps: 0.00, reads: 0.00, writes: 129223.23, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2377s] threads: 64, tps: 0.00, reads: 0.00, writes: 129981.85, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2378s] threads: 64, tps: 0.00, reads: 0.00, writes: 129750.15, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2379s] threads: 64, tps: 0.00, reads: 0.00, writes: 130401.96, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2380s] threads: 64, tps: 0.00, reads: 0.00, writes: 130197.60, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2381s] threads: 64, tps: 0.00, reads: 0.00, writes: 130611.36, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2382s] threads: 64, tps: 0.00, reads: 0.00, writes: 129338.01, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2383s] threads: 64, tps: 0.00, reads: 0.00, writes: 128509.24, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2384s] threads: 64, tps: 0.00, reads: 0.00, writes: 128945.75, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2385s] threads: 64, tps: 0.00, reads: 0.00, writes: 131081.93, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2386s] threads: 64, tps: 0.00, reads: 0.00, writes: 129507.22, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2387s] threads: 64, tps: 0.00, reads: 0.00, writes: 128409.33, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2388s] threads: 64, tps: 0.00, reads: 0.00, writes: 129970.51, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2389s] threads: 64, tps: 0.00, reads: 0.00, writes: 130573.94, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2390s] threads: 64, tps: 0.00, reads: 0.00, writes: 129735.13, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2391s] threads: 64, tps: 0.00, reads: 0.00, writes: 131136.70, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2392s] threads: 64, tps: 0.00, reads: 0.00, writes: 131398.17, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2393s] threads: 64, tps: 0.00, reads: 0.00, writes: 131401.21, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2394s] threads: 64, tps: 0.00, reads: 0.00, writes: 131492.90, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[2395s] threads: 64, tps: 0.00, reads: 0.00, writes: 128411.04, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2396s] threads: 64, tps: 0.00, reads: 0.00, writes: 131720.90, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2397s] threads: 64, tps: 0.00, reads: 0.00, writes: 129225.12, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2398s] threads: 64, tps: 0.00, reads: 0.00, writes: 131276.79, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2399s] threads: 64, tps: 0.00, reads: 0.00, writes: 128518.09, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[2400s] threads: 64, tps: 0.00, reads: 0.00, writes: 132105.93, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2401s] threads: 64, tps: 0.00, reads: 0.00, writes: 133337.01, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2402s] threads: 64, tps: 0.00, reads: 0.00, writes: 132549.45, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2403s] threads: 64, tps: 0.00, reads: 0.00, writes: 133802.61, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2404s] threads: 64, tps: 0.00, reads: 0.00, writes: 133766.38, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2405s] threads: 64, tps: 0.00, reads: 0.00, writes: 131174.80, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2406s] threads: 64, tps: 0.00, reads: 0.00, writes: 132274.78, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[2407s] threads: 64, tps: 0.00, reads: 0.00, writes: 131955.01, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2408s] threads: 64, tps: 0.00, reads: 0.00, writes: 131773.06, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2409s] threads: 64, tps: 0.00, reads: 0.00, writes: 132804.82, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2410s] threads: 64, tps: 0.00, reads: 0.00, writes: 131885.17, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2411s] threads: 64, tps: 0.00, reads: 0.00, writes: 133048.88, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2412s] threads: 64, tps: 0.00, reads: 0.00, writes: 133450.57, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2413s] threads: 64, tps: 0.00, reads: 0.00, writes: 133343.40, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2414s] threads: 64, tps: 0.00, reads: 0.00, writes: 130609.11, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2415s] threads: 64, tps: 0.00, reads: 0.00, writes: 131015.89, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[2416s] threads: 64, tps: 0.00, reads: 0.00, writes: 131595.10, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2417s] threads: 64, tps: 0.00, reads: 0.00, writes: 131391.85, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2418s] threads: 64, tps: 0.00, reads: 0.00, writes: 132793.16, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2419s] threads: 64, tps: 0.00, reads: 0.00, writes: 132469.85, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2420s] threads: 64, tps: 0.00, reads: 0.00, writes: 131945.01, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2421s] threads: 64, tps: 0.00, reads: 0.00, writes: 133035.11, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2422s] threads: 64, tps: 0.00, reads: 0.00, writes: 131964.03, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2423s] threads: 64, tps: 0.00, reads: 0.00, writes: 133007.17, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2424s] threads: 64, tps: 0.00, reads: 0.00, writes: 131261.70, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2425s] threads: 64, tps: 0.00, reads: 0.00, writes: 128103.21, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2426s] threads: 64, tps: 0.00, reads: 0.00, writes: 133354.33, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2427s] threads: 64, tps: 0.00, reads: 0.00, writes: 132600.49, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2428s] threads: 64, tps: 0.00, reads: 0.00, writes: 126932.02, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2429s] threads: 64, tps: 0.00, reads: 0.00, writes: 130878.98, response time: 0.80ms (95%), errors: 0.00, reconnects:  0.00
[2430s] threads: 64, tps: 0.00, reads: 0.00, writes: 132565.10, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2431s] threads: 64, tps: 0.00, reads: 0.00, writes: 133112.87, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2432s] threads: 64, tps: 0.00, reads: 0.00, writes: 132369.11, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2433s] threads: 64, tps: 0.00, reads: 0.00, writes: 132714.88, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2434s] threads: 64, tps: 0.00, reads: 0.00, writes: 132734.16, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2435s] threads: 64, tps: 0.00, reads: 0.00, writes: 133003.94, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2436s] threads: 64, tps: 0.00, reads: 0.00, writes: 132774.85, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2437s] threads: 64, tps: 0.00, reads: 0.00, writes: 132858.34, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2438s] threads: 64, tps: 0.00, reads: 0.00, writes: 133011.23, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2439s] threads: 64, tps: 0.00, reads: 0.00, writes: 132841.53, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2440s] threads: 64, tps: 0.00, reads: 0.00, writes: 132957.01, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2441s] threads: 64, tps: 0.00, reads: 0.00, writes: 132654.13, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2442s] threads: 64, tps: 0.00, reads: 0.00, writes: 129962.01, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2443s] threads: 64, tps: 0.00, reads: 0.00, writes: 130581.79, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2444s] threads: 64, tps: 0.00, reads: 0.00, writes: 131565.20, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2445s] threads: 64, tps: 0.00, reads: 0.00, writes: 133349.09, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2446s] threads: 64, tps: 0.00, reads: 0.00, writes: 133632.75, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2447s] threads: 64, tps: 0.00, reads: 0.00, writes: 131623.09, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2448s] threads: 64, tps: 0.00, reads: 0.00, writes: 133332.04, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2449s] threads: 64, tps: 0.00, reads: 0.00, writes: 132368.34, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2450s] threads: 64, tps: 0.00, reads: 0.00, writes: 128852.48, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2451s] threads: 64, tps: 0.00, reads: 0.00, writes: 133445.14, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2452s] threads: 64, tps: 0.00, reads: 0.00, writes: 133201.92, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2453s] threads: 64, tps: 0.00, reads: 0.00, writes: 132694.71, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2454s] threads: 64, tps: 0.00, reads: 0.00, writes: 132410.99, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2455s] threads: 64, tps: 0.00, reads: 0.00, writes: 133252.21, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2456s] threads: 64, tps: 0.00, reads: 0.00, writes: 133353.08, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2457s] threads: 64, tps: 0.00, reads: 0.00, writes: 133884.05, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2458s] threads: 64, tps: 0.00, reads: 0.00, writes: 133137.99, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2459s] threads: 64, tps: 0.00, reads: 0.00, writes: 132418.03, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2460s] threads: 64, tps: 0.00, reads: 0.00, writes: 130784.95, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2461s] threads: 64, tps: 0.00, reads: 0.00, writes: 129830.04, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2462s] threads: 64, tps: 0.00, reads: 0.00, writes: 133113.48, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2463s] threads: 64, tps: 0.00, reads: 0.00, writes: 132440.63, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2464s] threads: 64, tps: 0.00, reads: 0.00, writes: 133529.94, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2465s] threads: 64, tps: 0.00, reads: 0.00, writes: 133773.94, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2466s] threads: 64, tps: 0.00, reads: 0.00, writes: 132830.93, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2467s] threads: 64, tps: 0.00, reads: 0.00, writes: 130797.91, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2468s] threads: 64, tps: 0.00, reads: 0.00, writes: 130085.13, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2469s] threads: 64, tps: 0.00, reads: 0.00, writes: 133468.00, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2470s] threads: 64, tps: 0.00, reads: 0.00, writes: 130549.07, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2471s] threads: 64, tps: 0.00, reads: 0.00, writes: 131480.66, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2472s] threads: 64, tps: 0.00, reads: 0.00, writes: 133176.16, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2473s] threads: 64, tps: 0.00, reads: 0.00, writes: 133041.81, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2474s] threads: 64, tps: 0.00, reads: 0.00, writes: 131142.38, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2475s] threads: 64, tps: 0.00, reads: 0.00, writes: 133259.91, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2476s] threads: 64, tps: 0.00, reads: 0.00, writes: 128894.93, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2477s] threads: 64, tps: 0.00, reads: 0.00, writes: 132197.02, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2478s] threads: 64, tps: 0.00, reads: 0.00, writes: 132994.16, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2479s] threads: 64, tps: 0.00, reads: 0.00, writes: 133368.88, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2480s] threads: 64, tps: 0.00, reads: 0.00, writes: 131953.17, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2481s] threads: 64, tps: 0.00, reads: 0.00, writes: 132560.01, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2482s] threads: 64, tps: 0.00, reads: 0.00, writes: 132589.85, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2483s] threads: 64, tps: 0.00, reads: 0.00, writes: 127634.05, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2484s] threads: 64, tps: 0.00, reads: 0.00, writes: 133148.05, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2485s] threads: 64, tps: 0.00, reads: 0.00, writes: 132562.59, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2486s] threads: 64, tps: 0.00, reads: 0.00, writes: 132836.76, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2487s] threads: 64, tps: 0.00, reads: 0.00, writes: 133095.52, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2488s] threads: 64, tps: 0.00, reads: 0.00, writes: 132911.13, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2489s] threads: 64, tps: 0.00, reads: 0.00, writes: 133272.91, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2490s] threads: 64, tps: 0.00, reads: 0.00, writes: 132300.05, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2491s] threads: 64, tps: 0.00, reads: 0.00, writes: 132117.85, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2492s] threads: 64, tps: 0.00, reads: 0.00, writes: 131525.46, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2493s] threads: 64, tps: 0.00, reads: 0.00, writes: 131667.69, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2494s] threads: 64, tps: 0.00, reads: 0.00, writes: 132419.53, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2495s] threads: 64, tps: 0.00, reads: 0.00, writes: 132074.68, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2496s] threads: 64, tps: 0.00, reads: 0.00, writes: 133668.69, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2497s] threads: 64, tps: 0.00, reads: 0.00, writes: 132750.00, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2498s] threads: 64, tps: 0.00, reads: 0.00, writes: 131518.03, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2499s] threads: 64, tps: 0.00, reads: 0.00, writes: 132910.03, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2500s] threads: 64, tps: 0.00, reads: 0.00, writes: 132172.10, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2501s] threads: 64, tps: 0.00, reads: 0.00, writes: 128210.63, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2502s] threads: 64, tps: 0.00, reads: 0.00, writes: 133128.13, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2503s] threads: 64, tps: 0.00, reads: 0.00, writes: 130239.15, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2504s] threads: 64, tps: 0.00, reads: 0.00, writes: 130934.03, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2505s] threads: 64, tps: 0.00, reads: 0.00, writes: 133041.98, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2506s] threads: 64, tps: 0.00, reads: 0.00, writes: 130754.65, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2507s] threads: 64, tps: 0.00, reads: 0.00, writes: 133174.10, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2508s] threads: 64, tps: 0.00, reads: 0.00, writes: 132863.24, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2509s] threads: 64, tps: 0.00, reads: 0.00, writes: 132968.43, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2510s] threads: 64, tps: 0.00, reads: 0.00, writes: 131808.61, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2511s] threads: 64, tps: 0.00, reads: 0.00, writes: 131907.90, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2512s] threads: 64, tps: 0.00, reads: 0.00, writes: 132914.07, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2513s] threads: 64, tps: 0.00, reads: 0.00, writes: 133471.16, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2514s] threads: 64, tps: 0.00, reads: 0.00, writes: 132481.90, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2515s] threads: 64, tps: 0.00, reads: 0.00, writes: 133000.92, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2516s] threads: 64, tps: 0.00, reads: 0.00, writes: 131860.14, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2517s] threads: 64, tps: 0.00, reads: 0.00, writes: 132112.91, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2518s] threads: 64, tps: 0.00, reads: 0.00, writes: 132728.05, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2519s] threads: 64, tps: 0.00, reads: 0.00, writes: 133008.94, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2520s] threads: 64, tps: 0.00, reads: 0.00, writes: 133529.07, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2521s] threads: 64, tps: 0.00, reads: 0.00, writes: 131164.06, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2522s] threads: 64, tps: 0.00, reads: 0.00, writes: 132821.90, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2523s] threads: 64, tps: 0.00, reads: 0.00, writes: 130354.92, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2524s] threads: 64, tps: 0.00, reads: 0.00, writes: 131806.18, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2525s] threads: 64, tps: 0.00, reads: 0.00, writes: 132560.38, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2526s] threads: 64, tps: 0.00, reads: 0.00, writes: 132875.63, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2527s] threads: 64, tps: 0.00, reads: 0.00, writes: 133242.83, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2528s] threads: 64, tps: 0.00, reads: 0.00, writes: 132375.60, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2529s] threads: 64, tps: 0.00, reads: 0.00, writes: 132751.44, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2530s] threads: 64, tps: 0.00, reads: 0.00, writes: 132645.18, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2531s] threads: 64, tps: 0.00, reads: 0.00, writes: 132492.92, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2532s] threads: 64, tps: 0.00, reads: 0.00, writes: 132118.94, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2533s] threads: 64, tps: 0.00, reads: 0.00, writes: 131890.93, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2534s] threads: 64, tps: 0.00, reads: 0.00, writes: 128025.47, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2535s] threads: 64, tps: 0.00, reads: 0.00, writes: 133386.69, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2536s] threads: 64, tps: 0.00, reads: 0.00, writes: 132218.21, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2537s] threads: 64, tps: 0.00, reads: 0.00, writes: 132962.88, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2538s] threads: 64, tps: 0.00, reads: 0.00, writes: 132873.93, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2539s] threads: 64, tps: 0.00, reads: 0.00, writes: 130871.93, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2540s] threads: 64, tps: 0.00, reads: 0.00, writes: 132692.42, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2541s] threads: 64, tps: 0.00, reads: 0.00, writes: 133064.64, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2542s] threads: 64, tps: 0.00, reads: 0.00, writes: 132816.75, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2543s] threads: 64, tps: 0.00, reads: 0.00, writes: 128602.36, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2544s] threads: 64, tps: 0.00, reads: 0.00, writes: 130510.85, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2545s] threads: 64, tps: 0.00, reads: 0.00, writes: 133165.00, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2546s] threads: 64, tps: 0.00, reads: 0.00, writes: 132930.97, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2547s] threads: 64, tps: 0.00, reads: 0.00, writes: 132999.04, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2548s] threads: 64, tps: 0.00, reads: 0.00, writes: 128656.11, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2549s] threads: 64, tps: 0.00, reads: 0.00, writes: 127997.38, response time: 0.79ms (95%), errors: 0.00, reconnects:  0.00
[2550s] threads: 64, tps: 0.00, reads: 0.00, writes: 130354.62, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2551s] threads: 64, tps: 0.00, reads: 0.00, writes: 130388.90, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2552s] threads: 64, tps: 0.00, reads: 0.00, writes: 132939.11, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2553s] threads: 64, tps: 0.00, reads: 0.00, writes: 132829.91, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2554s] threads: 64, tps: 0.00, reads: 0.00, writes: 132569.95, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2555s] threads: 64, tps: 0.00, reads: 0.00, writes: 133033.20, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2556s] threads: 64, tps: 0.00, reads: 0.00, writes: 131967.91, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2557s] threads: 64, tps: 0.00, reads: 0.00, writes: 131504.12, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2558s] threads: 64, tps: 0.00, reads: 0.00, writes: 133532.74, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2559s] threads: 64, tps: 0.00, reads: 0.00, writes: 132777.71, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2560s] threads: 64, tps: 0.00, reads: 0.00, writes: 132691.45, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2561s] threads: 64, tps: 0.00, reads: 0.00, writes: 132742.04, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2562s] threads: 64, tps: 0.00, reads: 0.00, writes: 133101.85, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2563s] threads: 64, tps: 0.00, reads: 0.00, writes: 133009.95, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2564s] threads: 64, tps: 0.00, reads: 0.00, writes: 131076.54, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2565s] threads: 64, tps: 0.00, reads: 0.00, writes: 133921.60, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2566s] threads: 64, tps: 0.00, reads: 0.00, writes: 131646.02, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2567s] threads: 64, tps: 0.00, reads: 0.00, writes: 131361.01, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2568s] threads: 64, tps: 0.00, reads: 0.00, writes: 132751.92, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2569s] threads: 64, tps: 0.00, reads: 0.00, writes: 132681.21, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2570s] threads: 64, tps: 0.00, reads: 0.00, writes: 133130.94, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2571s] threads: 64, tps: 0.00, reads: 0.00, writes: 133088.98, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2572s] threads: 64, tps: 0.00, reads: 0.00, writes: 132092.13, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2573s] threads: 64, tps: 0.00, reads: 0.00, writes: 133431.85, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2574s] threads: 64, tps: 0.00, reads: 0.00, writes: 133088.08, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2575s] threads: 64, tps: 0.00, reads: 0.00, writes: 133486.05, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2576s] threads: 64, tps: 0.00, reads: 0.00, writes: 133133.35, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2577s] threads: 64, tps: 0.00, reads: 0.00, writes: 132843.66, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2578s] threads: 64, tps: 0.00, reads: 0.00, writes: 132184.87, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2579s] threads: 64, tps: 0.00, reads: 0.00, writes: 133390.07, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2580s] threads: 64, tps: 0.00, reads: 0.00, writes: 133656.96, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2581s] threads: 64, tps: 0.00, reads: 0.00, writes: 132847.14, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2582s] threads: 64, tps: 0.00, reads: 0.00, writes: 130313.94, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2583s] threads: 64, tps: 0.00, reads: 0.00, writes: 132850.95, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2584s] threads: 64, tps: 0.00, reads: 0.00, writes: 133043.92, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2585s] threads: 64, tps: 0.00, reads: 0.00, writes: 133307.84, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2586s] threads: 64, tps: 0.00, reads: 0.00, writes: 132484.21, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2587s] threads: 64, tps: 0.00, reads: 0.00, writes: 129523.00, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2588s] threads: 64, tps: 0.00, reads: 0.00, writes: 133606.50, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2589s] threads: 64, tps: 0.00, reads: 0.00, writes: 133352.86, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2590s] threads: 64, tps: 0.00, reads: 0.00, writes: 132971.52, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2591s] threads: 64, tps: 0.00, reads: 0.00, writes: 132662.03, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2592s] threads: 64, tps: 0.00, reads: 0.00, writes: 133017.95, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2593s] threads: 64, tps: 0.00, reads: 0.00, writes: 132923.53, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2594s] threads: 64, tps: 0.00, reads: 0.00, writes: 132574.69, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2595s] threads: 64, tps: 0.00, reads: 0.00, writes: 133088.89, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2596s] threads: 64, tps: 0.00, reads: 0.00, writes: 133205.07, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2597s] threads: 64, tps: 0.00, reads: 0.00, writes: 130165.90, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2598s] threads: 64, tps: 0.00, reads: 0.00, writes: 132783.99, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2599s] threads: 64, tps: 0.00, reads: 0.00, writes: 133029.02, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2600s] threads: 64, tps: 0.00, reads: 0.00, writes: 132743.95, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2601s] threads: 64, tps: 0.00, reads: 0.00, writes: 133208.07, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2602s] threads: 64, tps: 0.00, reads: 0.00, writes: 130145.91, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2603s] threads: 64, tps: 0.00, reads: 0.00, writes: 130625.66, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2604s] threads: 64, tps: 0.00, reads: 0.00, writes: 132806.62, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2605s] threads: 64, tps: 0.00, reads: 0.00, writes: 132768.34, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2606s] threads: 64, tps: 0.00, reads: 0.00, writes: 132194.52, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2607s] threads: 64, tps: 0.00, reads: 0.00, writes: 132348.99, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2608s] threads: 64, tps: 0.00, reads: 0.00, writes: 132733.88, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2609s] threads: 64, tps: 0.00, reads: 0.00, writes: 132162.03, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2610s] threads: 64, tps: 0.00, reads: 0.00, writes: 132736.93, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2611s] threads: 64, tps: 0.00, reads: 0.00, writes: 132413.70, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2612s] threads: 64, tps: 0.00, reads: 0.00, writes: 132678.40, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2613s] threads: 64, tps: 0.00, reads: 0.00, writes: 132688.95, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2614s] threads: 64, tps: 0.00, reads: 0.00, writes: 131945.97, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2615s] threads: 64, tps: 0.00, reads: 0.00, writes: 132992.06, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2616s] threads: 64, tps: 0.00, reads: 0.00, writes: 133153.05, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2617s] threads: 64, tps: 0.00, reads: 0.00, writes: 133814.92, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2618s] threads: 64, tps: 0.00, reads: 0.00, writes: 133046.94, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2619s] threads: 64, tps: 0.00, reads: 0.00, writes: 132836.07, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2620s] threads: 64, tps: 0.00, reads: 0.00, writes: 133073.00, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2621s] threads: 64, tps: 0.00, reads: 0.00, writes: 132973.04, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2622s] threads: 64, tps: 0.00, reads: 0.00, writes: 132564.92, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2623s] threads: 64, tps: 0.00, reads: 0.00, writes: 132726.96, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2624s] threads: 64, tps: 0.00, reads: 0.00, writes: 133445.15, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2625s] threads: 64, tps: 0.00, reads: 0.00, writes: 132301.11, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2626s] threads: 64, tps: 0.00, reads: 0.00, writes: 133001.91, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2627s] threads: 64, tps: 0.00, reads: 0.00, writes: 132851.03, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2628s] threads: 64, tps: 0.00, reads: 0.00, writes: 132655.01, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2629s] threads: 64, tps: 0.00, reads: 0.00, writes: 132769.80, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2630s] threads: 64, tps: 0.00, reads: 0.00, writes: 132871.17, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2631s] threads: 64, tps: 0.00, reads: 0.00, writes: 133220.96, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2632s] threads: 64, tps: 0.00, reads: 0.00, writes: 131713.09, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2633s] threads: 64, tps: 0.00, reads: 0.00, writes: 132858.85, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2634s] threads: 64, tps: 0.00, reads: 0.00, writes: 133045.11, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2635s] threads: 64, tps: 0.00, reads: 0.00, writes: 132951.90, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2636s] threads: 64, tps: 0.00, reads: 0.00, writes: 130116.92, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2637s] threads: 64, tps: 0.00, reads: 0.00, writes: 133025.00, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2638s] threads: 64, tps: 0.00, reads: 0.00, writes: 133335.07, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2639s] threads: 64, tps: 0.00, reads: 0.00, writes: 132777.98, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2640s] threads: 64, tps: 0.00, reads: 0.00, writes: 132889.04, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2641s] threads: 64, tps: 0.00, reads: 0.00, writes: 133229.92, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2642s] threads: 64, tps: 0.00, reads: 0.00, writes: 133102.16, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2643s] threads: 64, tps: 0.00, reads: 0.00, writes: 130734.84, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2644s] threads: 64, tps: 0.00, reads: 0.00, writes: 133361.11, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2645s] threads: 64, tps: 0.00, reads: 0.00, writes: 133671.09, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2646s] threads: 64, tps: 0.00, reads: 0.00, writes: 132658.10, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2647s] threads: 64, tps: 0.00, reads: 0.00, writes: 132332.35, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2648s] threads: 64, tps: 0.00, reads: 0.00, writes: 131932.99, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2649s] threads: 64, tps: 0.00, reads: 0.00, writes: 132590.66, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2650s] threads: 64, tps: 0.00, reads: 0.00, writes: 132336.49, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2651s] threads: 64, tps: 0.00, reads: 0.00, writes: 132676.28, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2652s] threads: 64, tps: 0.00, reads: 0.00, writes: 133252.86, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2653s] threads: 64, tps: 0.00, reads: 0.00, writes: 132705.16, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2654s] threads: 64, tps: 0.00, reads: 0.00, writes: 132829.95, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2655s] threads: 64, tps: 0.00, reads: 0.00, writes: 132882.02, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2656s] threads: 64, tps: 0.00, reads: 0.00, writes: 133011.05, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2657s] threads: 64, tps: 0.00, reads: 0.00, writes: 132652.99, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2658s] threads: 64, tps: 0.00, reads: 0.00, writes: 132798.02, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2659s] threads: 64, tps: 0.00, reads: 0.00, writes: 132821.94, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2660s] threads: 64, tps: 0.00, reads: 0.00, writes: 132729.15, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2661s] threads: 64, tps: 0.00, reads: 0.00, writes: 132481.97, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2662s] threads: 64, tps: 0.00, reads: 0.00, writes: 132644.11, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2663s] threads: 64, tps: 0.00, reads: 0.00, writes: 132723.68, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2664s] threads: 64, tps: 0.00, reads: 0.00, writes: 132924.12, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2665s] threads: 64, tps: 0.00, reads: 0.00, writes: 131997.10, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2666s] threads: 64, tps: 0.00, reads: 0.00, writes: 132918.01, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2667s] threads: 64, tps: 0.00, reads: 0.00, writes: 132618.02, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2668s] threads: 64, tps: 0.00, reads: 0.00, writes: 131969.01, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2669s] threads: 64, tps: 0.00, reads: 0.00, writes: 130982.90, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2670s] threads: 64, tps: 0.00, reads: 0.00, writes: 131598.73, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2671s] threads: 64, tps: 0.00, reads: 0.00, writes: 127266.03, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[2672s] threads: 64, tps: 0.00, reads: 0.00, writes: 131617.19, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2673s] threads: 64, tps: 0.00, reads: 0.00, writes: 131703.21, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2674s] threads: 64, tps: 0.00, reads: 0.00, writes: 132948.00, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2675s] threads: 64, tps: 0.00, reads: 0.00, writes: 132787.79, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2676s] threads: 64, tps: 0.00, reads: 0.00, writes: 132896.02, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2677s] threads: 64, tps: 0.00, reads: 0.00, writes: 131890.12, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2678s] threads: 64, tps: 0.00, reads: 0.00, writes: 132785.97, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2679s] threads: 64, tps: 0.00, reads: 0.00, writes: 132547.86, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2680s] threads: 64, tps: 0.00, reads: 0.00, writes: 132803.11, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2681s] threads: 64, tps: 0.00, reads: 0.00, writes: 133473.94, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2682s] threads: 64, tps: 0.00, reads: 0.00, writes: 131513.09, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2683s] threads: 64, tps: 0.00, reads: 0.00, writes: 132592.61, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2684s] threads: 64, tps: 0.00, reads: 0.00, writes: 132913.45, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2685s] threads: 64, tps: 0.00, reads: 0.00, writes: 132239.78, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2686s] threads: 64, tps: 0.00, reads: 0.00, writes: 131574.63, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2687s] threads: 64, tps: 0.00, reads: 0.00, writes: 131095.04, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2688s] threads: 64, tps: 0.00, reads: 0.00, writes: 130327.49, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[2689s] threads: 64, tps: 0.00, reads: 0.00, writes: 130736.02, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2690s] threads: 64, tps: 0.00, reads: 0.00, writes: 130380.00, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2691s] threads: 64, tps: 0.00, reads: 0.00, writes: 130261.87, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2692s] threads: 64, tps: 0.00, reads: 0.00, writes: 129772.02, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2693s] threads: 64, tps: 0.00, reads: 0.00, writes: 133365.21, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2694s] threads: 64, tps: 0.00, reads: 0.00, writes: 134404.31, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2695s] threads: 64, tps: 0.00, reads: 0.00, writes: 134976.66, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[2696s] threads: 64, tps: 0.00, reads: 0.00, writes: 134282.89, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2697s] threads: 64, tps: 0.00, reads: 0.00, writes: 134032.06, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2698s] threads: 64, tps: 0.00, reads: 0.00, writes: 133797.93, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2699s] threads: 64, tps: 0.00, reads: 0.00, writes: 133585.02, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2700s] threads: 64, tps: 0.00, reads: 0.00, writes: 133992.95, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2701s] threads: 64, tps: 0.00, reads: 0.00, writes: 133995.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2702s] threads: 64, tps: 0.00, reads: 0.00, writes: 133176.12, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2703s] threads: 64, tps: 0.00, reads: 0.00, writes: 133943.91, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2704s] threads: 64, tps: 0.00, reads: 0.00, writes: 133900.99, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2705s] threads: 64, tps: 0.00, reads: 0.00, writes: 134187.04, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2706s] threads: 64, tps: 0.00, reads: 0.00, writes: 133991.34, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2707s] threads: 64, tps: 0.00, reads: 0.00, writes: 134289.52, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2708s] threads: 64, tps: 0.00, reads: 0.00, writes: 134271.66, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2709s] threads: 64, tps: 0.00, reads: 0.00, writes: 135229.44, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2710s] threads: 64, tps: 0.00, reads: 0.00, writes: 134566.76, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2711s] threads: 64, tps: 0.00, reads: 0.00, writes: 134754.57, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2712s] threads: 64, tps: 0.00, reads: 0.00, writes: 134589.58, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2713s] threads: 64, tps: 0.00, reads: 0.00, writes: 134699.10, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2714s] threads: 64, tps: 0.00, reads: 0.00, writes: 135081.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2715s] threads: 64, tps: 0.00, reads: 0.00, writes: 135291.04, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2716s] threads: 64, tps: 0.00, reads: 0.00, writes: 135402.97, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2717s] threads: 64, tps: 0.00, reads: 0.00, writes: 134944.02, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2718s] threads: 64, tps: 0.00, reads: 0.00, writes: 134167.99, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2719s] threads: 64, tps: 0.00, reads: 0.00, writes: 134598.05, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2720s] threads: 64, tps: 0.00, reads: 0.00, writes: 134653.79, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2721s] threads: 64, tps: 0.00, reads: 0.00, writes: 134071.25, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2722s] threads: 64, tps: 0.00, reads: 0.00, writes: 134466.95, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2723s] threads: 64, tps: 0.00, reads: 0.00, writes: 135112.22, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2724s] threads: 64, tps: 0.00, reads: 0.00, writes: 133590.23, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2725s] threads: 64, tps: 0.00, reads: 0.00, writes: 134587.88, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2726s] threads: 64, tps: 0.00, reads: 0.00, writes: 134037.62, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2727s] threads: 64, tps: 0.00, reads: 0.00, writes: 134521.93, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2728s] threads: 64, tps: 0.00, reads: 0.00, writes: 133698.02, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2729s] threads: 64, tps: 0.00, reads: 0.00, writes: 134187.01, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2730s] threads: 64, tps: 0.00, reads: 0.00, writes: 134540.08, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2731s] threads: 64, tps: 0.00, reads: 0.00, writes: 134073.89, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2732s] threads: 64, tps: 0.00, reads: 0.00, writes: 134072.08, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2733s] threads: 64, tps: 0.00, reads: 0.00, writes: 133959.96, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2734s] threads: 64, tps: 0.00, reads: 0.00, writes: 134088.01, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2735s] threads: 64, tps: 0.00, reads: 0.00, writes: 133876.73, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2736s] threads: 64, tps: 0.00, reads: 0.00, writes: 134244.29, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2737s] threads: 64, tps: 0.00, reads: 0.00, writes: 134419.64, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2738s] threads: 64, tps: 0.00, reads: 0.00, writes: 134129.42, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2739s] threads: 64, tps: 0.00, reads: 0.00, writes: 134096.94, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2740s] threads: 64, tps: 0.00, reads: 0.00, writes: 134019.02, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2741s] threads: 64, tps: 0.00, reads: 0.00, writes: 134082.93, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2742s] threads: 64, tps: 0.00, reads: 0.00, writes: 133942.07, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2743s] threads: 64, tps: 0.00, reads: 0.00, writes: 134098.06, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2744s] threads: 64, tps: 0.00, reads: 0.00, writes: 134715.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2745s] threads: 64, tps: 0.00, reads: 0.00, writes: 134333.97, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2746s] threads: 64, tps: 0.00, reads: 0.00, writes: 134384.81, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2747s] threads: 64, tps: 0.00, reads: 0.00, writes: 133589.23, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2748s] threads: 64, tps: 0.00, reads: 0.00, writes: 133936.51, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2749s] threads: 64, tps: 0.00, reads: 0.00, writes: 132531.76, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2750s] threads: 64, tps: 0.00, reads: 0.00, writes: 134341.05, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2751s] threads: 64, tps: 0.00, reads: 0.00, writes: 134587.54, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2752s] threads: 64, tps: 0.00, reads: 0.00, writes: 134795.13, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2753s] threads: 64, tps: 0.00, reads: 0.00, writes: 134376.92, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2754s] threads: 64, tps: 0.00, reads: 0.00, writes: 134248.11, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2755s] threads: 64, tps: 0.00, reads: 0.00, writes: 133873.95, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2756s] threads: 64, tps: 0.00, reads: 0.00, writes: 133943.06, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2757s] threads: 64, tps: 0.00, reads: 0.00, writes: 134281.04, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2758s] threads: 64, tps: 0.00, reads: 0.00, writes: 133486.89, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2759s] threads: 64, tps: 0.00, reads: 0.00, writes: 133695.83, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2760s] threads: 64, tps: 0.00, reads: 0.00, writes: 133566.32, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2761s] threads: 64, tps: 0.00, reads: 0.00, writes: 134146.86, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2762s] threads: 64, tps: 0.00, reads: 0.00, writes: 133610.41, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2763s] threads: 64, tps: 0.00, reads: 0.00, writes: 134335.47, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2764s] threads: 64, tps: 0.00, reads: 0.00, writes: 134155.04, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2765s] threads: 64, tps: 0.00, reads: 0.00, writes: 134185.59, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2766s] threads: 64, tps: 0.00, reads: 0.00, writes: 134400.44, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2767s] threads: 64, tps: 0.00, reads: 0.00, writes: 133560.65, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2768s] threads: 64, tps: 0.00, reads: 0.00, writes: 133926.61, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2769s] threads: 64, tps: 0.00, reads: 0.00, writes: 133811.10, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2770s] threads: 64, tps: 0.00, reads: 0.00, writes: 132476.04, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2771s] threads: 64, tps: 0.00, reads: 0.00, writes: 132203.51, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2772s] threads: 64, tps: 0.00, reads: 0.00, writes: 134266.20, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2773s] threads: 64, tps: 0.00, reads: 0.00, writes: 134298.08, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2774s] threads: 64, tps: 0.00, reads: 0.00, writes: 134359.84, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2775s] threads: 64, tps: 0.00, reads: 0.00, writes: 133802.02, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2776s] threads: 64, tps: 0.00, reads: 0.00, writes: 133985.07, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2777s] threads: 64, tps: 0.00, reads: 0.00, writes: 134206.07, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2778s] threads: 64, tps: 0.00, reads: 0.00, writes: 134089.10, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2779s] threads: 64, tps: 0.00, reads: 0.00, writes: 133362.64, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2780s] threads: 64, tps: 0.00, reads: 0.00, writes: 132962.12, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2781s] threads: 64, tps: 0.00, reads: 0.00, writes: 134613.01, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2782s] threads: 64, tps: 0.00, reads: 0.00, writes: 134047.49, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2783s] threads: 64, tps: 0.00, reads: 0.00, writes: 134123.36, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2784s] threads: 64, tps: 0.00, reads: 0.00, writes: 133753.01, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2785s] threads: 64, tps: 0.00, reads: 0.00, writes: 133331.04, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2786s] threads: 64, tps: 0.00, reads: 0.00, writes: 132575.07, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2787s] threads: 64, tps: 0.00, reads: 0.00, writes: 133353.15, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2788s] threads: 64, tps: 0.00, reads: 0.00, writes: 134213.50, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2789s] threads: 64, tps: 0.00, reads: 0.00, writes: 133604.22, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2790s] threads: 64, tps: 0.00, reads: 0.00, writes: 133556.82, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2791s] threads: 64, tps: 0.00, reads: 0.00, writes: 133984.94, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2792s] threads: 64, tps: 0.00, reads: 0.00, writes: 133804.42, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2793s] threads: 64, tps: 0.00, reads: 0.00, writes: 133602.26, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2794s] threads: 64, tps: 0.00, reads: 0.00, writes: 133320.18, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2795s] threads: 64, tps: 0.00, reads: 0.00, writes: 134520.40, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2796s] threads: 64, tps: 0.00, reads: 0.00, writes: 134087.97, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2797s] threads: 64, tps: 0.00, reads: 0.00, writes: 133666.23, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2798s] threads: 64, tps: 0.00, reads: 0.00, writes: 133998.90, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2799s] threads: 64, tps: 0.00, reads: 0.00, writes: 133890.98, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2800s] threads: 64, tps: 0.00, reads: 0.00, writes: 133953.36, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2801s] threads: 64, tps: 0.00, reads: 0.00, writes: 134096.13, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2802s] threads: 64, tps: 0.00, reads: 0.00, writes: 133558.64, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2803s] threads: 64, tps: 0.00, reads: 0.00, writes: 133906.40, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2804s] threads: 64, tps: 0.00, reads: 0.00, writes: 132421.43, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2805s] threads: 64, tps: 0.00, reads: 0.00, writes: 133955.02, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2806s] threads: 64, tps: 0.00, reads: 0.00, writes: 133380.83, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2807s] threads: 64, tps: 0.00, reads: 0.00, writes: 133797.05, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2808s] threads: 64, tps: 0.00, reads: 0.00, writes: 133974.01, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2809s] threads: 64, tps: 0.00, reads: 0.00, writes: 134102.92, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2810s] threads: 64, tps: 0.00, reads: 0.00, writes: 133593.11, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2811s] threads: 64, tps: 0.00, reads: 0.00, writes: 133503.98, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2812s] threads: 64, tps: 0.00, reads: 0.00, writes: 133227.13, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2813s] threads: 64, tps: 0.00, reads: 0.00, writes: 133353.06, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2814s] threads: 64, tps: 0.00, reads: 0.00, writes: 133425.84, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2815s] threads: 64, tps: 0.00, reads: 0.00, writes: 133938.06, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2816s] threads: 64, tps: 0.00, reads: 0.00, writes: 134304.03, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2817s] threads: 64, tps: 0.00, reads: 0.00, writes: 133660.92, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2818s] threads: 64, tps: 0.00, reads: 0.00, writes: 133455.06, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2819s] threads: 64, tps: 0.00, reads: 0.00, writes: 133334.14, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2820s] threads: 64, tps: 0.00, reads: 0.00, writes: 133800.92, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2821s] threads: 64, tps: 0.00, reads: 0.00, writes: 133514.84, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2822s] threads: 64, tps: 0.00, reads: 0.00, writes: 133697.09, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2823s] threads: 64, tps: 0.00, reads: 0.00, writes: 134051.05, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2824s] threads: 64, tps: 0.00, reads: 0.00, writes: 132965.86, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2825s] threads: 64, tps: 0.00, reads: 0.00, writes: 133415.15, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2826s] threads: 64, tps: 0.00, reads: 0.00, writes: 133740.93, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2827s] threads: 64, tps: 0.00, reads: 0.00, writes: 133180.05, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2828s] threads: 64, tps: 0.00, reads: 0.00, writes: 133764.94, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2829s] threads: 64, tps: 0.00, reads: 0.00, writes: 133306.07, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2830s] threads: 64, tps: 0.00, reads: 0.00, writes: 133915.95, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2831s] threads: 64, tps: 0.00, reads: 0.00, writes: 133637.16, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2832s] threads: 64, tps: 0.00, reads: 0.00, writes: 133662.89, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2833s] threads: 64, tps: 0.00, reads: 0.00, writes: 133366.86, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2834s] threads: 64, tps: 0.00, reads: 0.00, writes: 133443.12, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2835s] threads: 64, tps: 0.00, reads: 0.00, writes: 133239.17, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2836s] threads: 64, tps: 0.00, reads: 0.00, writes: 133234.43, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2837s] threads: 64, tps: 0.00, reads: 0.00, writes: 132191.40, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2838s] threads: 64, tps: 0.00, reads: 0.00, writes: 134394.07, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[2839s] threads: 64, tps: 0.00, reads: 0.00, writes: 133496.62, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2840s] threads: 64, tps: 0.00, reads: 0.00, writes: 133442.30, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2841s] threads: 64, tps: 0.00, reads: 0.00, writes: 133627.90, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2842s] threads: 64, tps: 0.00, reads: 0.00, writes: 133537.14, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2843s] threads: 64, tps: 0.00, reads: 0.00, writes: 133048.35, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2844s] threads: 64, tps: 0.00, reads: 0.00, writes: 133733.56, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2845s] threads: 64, tps: 0.00, reads: 0.00, writes: 134137.06, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2846s] threads: 64, tps: 0.00, reads: 0.00, writes: 133351.08, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2847s] threads: 64, tps: 0.00, reads: 0.00, writes: 132631.02, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2848s] threads: 64, tps: 0.00, reads: 0.00, writes: 132353.04, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2849s] threads: 64, tps: 0.00, reads: 0.00, writes: 132406.94, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2850s] threads: 64, tps: 0.00, reads: 0.00, writes: 133054.94, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2851s] threads: 64, tps: 0.00, reads: 0.00, writes: 132774.90, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[2852s] threads: 64, tps: 0.00, reads: 0.00, writes: 133372.09, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2853s] threads: 64, tps: 0.00, reads: 0.00, writes: 132834.22, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2854s] threads: 64, tps: 0.00, reads: 0.00, writes: 132758.97, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2855s] threads: 64, tps: 0.00, reads: 0.00, writes: 132709.88, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2856s] threads: 64, tps: 0.00, reads: 0.00, writes: 133255.89, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2857s] threads: 64, tps: 0.00, reads: 0.00, writes: 133422.10, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2858s] threads: 64, tps: 0.00, reads: 0.00, writes: 133714.77, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2859s] threads: 64, tps: 0.00, reads: 0.00, writes: 134122.17, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2860s] threads: 64, tps: 0.00, reads: 0.00, writes: 133617.17, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2861s] threads: 64, tps: 0.00, reads: 0.00, writes: 133159.01, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2862s] threads: 64, tps: 0.00, reads: 0.00, writes: 133234.39, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2863s] threads: 64, tps: 0.00, reads: 0.00, writes: 133135.04, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2864s] threads: 64, tps: 0.00, reads: 0.00, writes: 133027.88, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2865s] threads: 64, tps: 0.00, reads: 0.00, writes: 131753.46, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[2866s] threads: 64, tps: 0.00, reads: 0.00, writes: 133678.03, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2867s] threads: 64, tps: 0.00, reads: 0.00, writes: 133152.38, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2868s] threads: 64, tps: 0.00, reads: 0.00, writes: 133302.15, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2869s] threads: 64, tps: 0.00, reads: 0.00, writes: 133091.44, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2870s] threads: 64, tps: 0.00, reads: 0.00, writes: 133162.06, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2871s] threads: 64, tps: 0.00, reads: 0.00, writes: 132971.60, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2872s] threads: 64, tps: 0.00, reads: 0.00, writes: 133202.27, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2873s] threads: 64, tps: 0.00, reads: 0.00, writes: 133502.17, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2874s] threads: 64, tps: 0.00, reads: 0.00, writes: 133705.91, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2875s] threads: 64, tps: 0.00, reads: 0.00, writes: 132958.10, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2876s] threads: 64, tps: 0.00, reads: 0.00, writes: 133155.99, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2877s] threads: 64, tps: 0.00, reads: 0.00, writes: 133422.96, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2878s] threads: 64, tps: 0.00, reads: 0.00, writes: 133463.94, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2879s] threads: 64, tps: 0.00, reads: 0.00, writes: 133267.13, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2880s] threads: 64, tps: 0.00, reads: 0.00, writes: 132148.63, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2881s] threads: 64, tps: 0.00, reads: 0.00, writes: 133507.81, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2882s] threads: 64, tps: 0.00, reads: 0.00, writes: 132726.49, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2883s] threads: 64, tps: 0.00, reads: 0.00, writes: 133250.13, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2884s] threads: 64, tps: 0.00, reads: 0.00, writes: 133194.97, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2885s] threads: 64, tps: 0.00, reads: 0.00, writes: 132982.09, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2886s] threads: 64, tps: 0.00, reads: 0.00, writes: 133116.99, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2887s] threads: 64, tps: 0.00, reads: 0.00, writes: 133260.86, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2888s] threads: 64, tps: 0.00, reads: 0.00, writes: 133626.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2889s] threads: 64, tps: 0.00, reads: 0.00, writes: 133242.17, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2890s] threads: 64, tps: 0.00, reads: 0.00, writes: 133261.84, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2891s] threads: 64, tps: 0.00, reads: 0.00, writes: 133205.00, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2892s] threads: 64, tps: 0.00, reads: 0.00, writes: 132805.94, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2893s] threads: 64, tps: 0.00, reads: 0.00, writes: 133173.82, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2894s] threads: 64, tps: 0.00, reads: 0.00, writes: 133481.28, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2895s] threads: 64, tps: 0.00, reads: 0.00, writes: 132594.99, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2896s] threads: 64, tps: 0.00, reads: 0.00, writes: 132235.83, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2897s] threads: 64, tps: 0.00, reads: 0.00, writes: 133210.78, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2898s] threads: 64, tps: 0.00, reads: 0.00, writes: 133589.31, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2899s] threads: 64, tps: 0.00, reads: 0.00, writes: 132908.99, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2900s] threads: 64, tps: 0.00, reads: 0.00, writes: 133277.12, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2901s] threads: 64, tps: 0.00, reads: 0.00, writes: 133692.95, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2902s] threads: 64, tps: 0.00, reads: 0.00, writes: 133836.90, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2903s] threads: 64, tps: 0.00, reads: 0.00, writes: 133092.03, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2904s] threads: 64, tps: 0.00, reads: 0.00, writes: 133541.17, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2905s] threads: 64, tps: 0.00, reads: 0.00, writes: 133487.01, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2906s] threads: 64, tps: 0.00, reads: 0.00, writes: 133032.98, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2907s] threads: 64, tps: 0.00, reads: 0.00, writes: 132807.97, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2908s] threads: 64, tps: 0.00, reads: 0.00, writes: 132995.95, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2909s] threads: 64, tps: 0.00, reads: 0.00, writes: 132512.92, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2910s] threads: 64, tps: 0.00, reads: 0.00, writes: 132192.19, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[2911s] threads: 64, tps: 0.00, reads: 0.00, writes: 132661.97, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2912s] threads: 64, tps: 0.00, reads: 0.00, writes: 133434.93, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2913s] threads: 64, tps: 0.00, reads: 0.00, writes: 132942.91, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2914s] threads: 64, tps: 0.00, reads: 0.00, writes: 132837.70, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2915s] threads: 64, tps: 0.00, reads: 0.00, writes: 133377.35, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2916s] threads: 64, tps: 0.00, reads: 0.00, writes: 133699.51, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2917s] threads: 64, tps: 0.00, reads: 0.00, writes: 133214.91, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2918s] threads: 64, tps: 0.00, reads: 0.00, writes: 133215.65, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2919s] threads: 64, tps: 0.00, reads: 0.00, writes: 132418.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2920s] threads: 64, tps: 0.00, reads: 0.00, writes: 133147.00, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2921s] threads: 64, tps: 0.00, reads: 0.00, writes: 133402.96, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2922s] threads: 64, tps: 0.00, reads: 0.00, writes: 133314.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2923s] threads: 64, tps: 0.00, reads: 0.00, writes: 133675.32, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2924s] threads: 64, tps: 0.00, reads: 0.00, writes: 133053.82, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2925s] threads: 64, tps: 0.00, reads: 0.00, writes: 133270.80, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2926s] threads: 64, tps: 0.00, reads: 0.00, writes: 132812.09, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2927s] threads: 64, tps: 0.00, reads: 0.00, writes: 133164.99, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2928s] threads: 64, tps: 0.00, reads: 0.00, writes: 132082.56, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2929s] threads: 64, tps: 0.00, reads: 0.00, writes: 133048.52, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2930s] threads: 64, tps: 0.00, reads: 0.00, writes: 133746.90, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2931s] threads: 64, tps: 0.00, reads: 0.00, writes: 133481.32, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2932s] threads: 64, tps: 0.00, reads: 0.00, writes: 132887.75, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2933s] threads: 64, tps: 0.00, reads: 0.00, writes: 132900.02, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2934s] threads: 64, tps: 0.00, reads: 0.00, writes: 132855.01, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[2935s] threads: 64, tps: 0.00, reads: 0.00, writes: 133532.85, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2936s] threads: 64, tps: 0.00, reads: 0.00, writes: 133272.06, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2937s] threads: 64, tps: 0.00, reads: 0.00, writes: 133694.51, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2938s] threads: 64, tps: 0.00, reads: 0.00, writes: 133423.66, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2939s] threads: 64, tps: 0.00, reads: 0.00, writes: 133294.68, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2940s] threads: 64, tps: 0.00, reads: 0.00, writes: 133348.13, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2941s] threads: 64, tps: 0.00, reads: 0.00, writes: 133200.20, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2942s] threads: 64, tps: 0.00, reads: 0.00, writes: 133381.73, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2943s] threads: 64, tps: 0.00, reads: 0.00, writes: 133270.79, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2944s] threads: 64, tps: 0.00, reads: 0.00, writes: 133705.70, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2945s] threads: 64, tps: 0.00, reads: 0.00, writes: 133579.69, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2946s] threads: 64, tps: 0.00, reads: 0.00, writes: 132539.93, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2947s] threads: 64, tps: 0.00, reads: 0.00, writes: 133216.87, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2948s] threads: 64, tps: 0.00, reads: 0.00, writes: 133048.93, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2949s] threads: 64, tps: 0.00, reads: 0.00, writes: 133006.33, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2950s] threads: 64, tps: 0.00, reads: 0.00, writes: 132913.32, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2951s] threads: 64, tps: 0.00, reads: 0.00, writes: 133295.62, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2952s] threads: 64, tps: 0.00, reads: 0.00, writes: 132953.90, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2953s] threads: 64, tps: 0.00, reads: 0.00, writes: 132292.18, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2954s] threads: 64, tps: 0.00, reads: 0.00, writes: 133143.93, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2955s] threads: 64, tps: 0.00, reads: 0.00, writes: 133327.99, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2956s] threads: 64, tps: 0.00, reads: 0.00, writes: 132944.88, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2957s] threads: 64, tps: 0.00, reads: 0.00, writes: 133004.62, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2958s] threads: 64, tps: 0.00, reads: 0.00, writes: 133124.43, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2959s] threads: 64, tps: 0.00, reads: 0.00, writes: 132999.52, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2960s] threads: 64, tps: 0.00, reads: 0.00, writes: 133006.55, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2961s] threads: 64, tps: 0.00, reads: 0.00, writes: 132866.94, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2962s] threads: 64, tps: 0.00, reads: 0.00, writes: 132889.03, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2963s] threads: 64, tps: 0.00, reads: 0.00, writes: 133167.35, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2964s] threads: 64, tps: 0.00, reads: 0.00, writes: 133266.93, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2965s] threads: 64, tps: 0.00, reads: 0.00, writes: 133390.74, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2966s] threads: 64, tps: 0.00, reads: 0.00, writes: 132808.05, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2967s] threads: 64, tps: 0.00, reads: 0.00, writes: 131985.81, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2968s] threads: 64, tps: 0.00, reads: 0.00, writes: 132821.20, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2969s] threads: 64, tps: 0.00, reads: 0.00, writes: 132371.04, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2970s] threads: 64, tps: 0.00, reads: 0.00, writes: 132139.89, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2971s] threads: 64, tps: 0.00, reads: 0.00, writes: 132832.98, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2972s] threads: 64, tps: 0.00, reads: 0.00, writes: 133274.12, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[2973s] threads: 64, tps: 0.00, reads: 0.00, writes: 133236.98, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2974s] threads: 64, tps: 0.00, reads: 0.00, writes: 133010.02, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2975s] threads: 64, tps: 0.00, reads: 0.00, writes: 131643.82, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2976s] threads: 64, tps: 0.00, reads: 0.00, writes: 132858.96, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2977s] threads: 64, tps: 0.00, reads: 0.00, writes: 132952.01, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2978s] threads: 64, tps: 0.00, reads: 0.00, writes: 133197.05, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2979s] threads: 64, tps: 0.00, reads: 0.00, writes: 133628.09, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[2980s] threads: 64, tps: 0.00, reads: 0.00, writes: 133014.96, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2981s] threads: 64, tps: 0.00, reads: 0.00, writes: 132901.94, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2982s] threads: 64, tps: 0.00, reads: 0.00, writes: 133152.25, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2983s] threads: 64, tps: 0.00, reads: 0.00, writes: 131952.76, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2984s] threads: 64, tps: 0.00, reads: 0.00, writes: 132996.05, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2985s] threads: 64, tps: 0.00, reads: 0.00, writes: 133088.92, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2986s] threads: 64, tps: 0.00, reads: 0.00, writes: 133534.53, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2987s] threads: 64, tps: 0.00, reads: 0.00, writes: 132984.45, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2988s] threads: 64, tps: 0.00, reads: 0.00, writes: 131944.00, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[2989s] threads: 64, tps: 0.00, reads: 0.00, writes: 132563.11, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[2990s] threads: 64, tps: 0.00, reads: 0.00, writes: 132886.03, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2991s] threads: 64, tps: 0.00, reads: 0.00, writes: 132847.99, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2992s] threads: 64, tps: 0.00, reads: 0.00, writes: 132973.99, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2993s] threads: 64, tps: 0.00, reads: 0.00, writes: 133884.04, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[2994s] threads: 64, tps: 0.00, reads: 0.00, writes: 132964.52, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2995s] threads: 64, tps: 0.00, reads: 0.00, writes: 133093.36, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2996s] threads: 64, tps: 0.00, reads: 0.00, writes: 133216.38, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[2997s] threads: 64, tps: 0.00, reads: 0.00, writes: 133191.73, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2998s] threads: 64, tps: 0.00, reads: 0.00, writes: 132937.88, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[2999s] threads: 64, tps: 0.00, reads: 0.00, writes: 133369.18, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3000s] threads: 64, tps: 0.00, reads: 0.00, writes: 133409.87, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3001s] threads: 64, tps: 0.00, reads: 0.00, writes: 132723.66, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3002s] threads: 64, tps: 0.00, reads: 0.00, writes: 132659.44, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3003s] threads: 64, tps: 0.00, reads: 0.00, writes: 133234.51, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3004s] threads: 64, tps: 0.00, reads: 0.00, writes: 133115.40, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3005s] threads: 64, tps: 0.00, reads: 0.00, writes: 133190.93, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3006s] threads: 64, tps: 0.00, reads: 0.00, writes: 133334.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3007s] threads: 64, tps: 0.00, reads: 0.00, writes: 133319.15, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3008s] threads: 64, tps: 0.00, reads: 0.00, writes: 132742.05, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3009s] threads: 64, tps: 0.00, reads: 0.00, writes: 132998.83, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3010s] threads: 64, tps: 0.00, reads: 0.00, writes: 132453.78, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3011s] threads: 64, tps: 0.00, reads: 0.00, writes: 132804.41, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3012s] threads: 64, tps: 0.00, reads: 0.00, writes: 132960.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3013s] threads: 64, tps: 0.00, reads: 0.00, writes: 133003.94, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3014s] threads: 64, tps: 0.00, reads: 0.00, writes: 133596.13, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3015s] threads: 64, tps: 0.00, reads: 0.00, writes: 133026.94, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3016s] threads: 64, tps: 0.00, reads: 0.00, writes: 132985.93, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3017s] threads: 64, tps: 0.00, reads: 0.00, writes: 132613.45, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3018s] threads: 64, tps: 0.00, reads: 0.00, writes: 132676.53, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3019s] threads: 64, tps: 0.00, reads: 0.00, writes: 132741.08, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3020s] threads: 64, tps: 0.00, reads: 0.00, writes: 132993.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3021s] threads: 64, tps: 0.00, reads: 0.00, writes: 133188.98, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3022s] threads: 64, tps: 0.00, reads: 0.00, writes: 133210.10, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3023s] threads: 64, tps: 0.00, reads: 0.00, writes: 132995.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3024s] threads: 64, tps: 0.00, reads: 0.00, writes: 132942.98, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3025s] threads: 64, tps: 0.00, reads: 0.00, writes: 133108.71, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3026s] threads: 64, tps: 0.00, reads: 0.00, writes: 132806.59, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3027s] threads: 64, tps: 0.00, reads: 0.00, writes: 132897.75, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3028s] threads: 64, tps: 0.00, reads: 0.00, writes: 132634.06, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3029s] threads: 64, tps: 0.00, reads: 0.00, writes: 133135.92, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3030s] threads: 64, tps: 0.00, reads: 0.00, writes: 131997.03, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[3031s] threads: 64, tps: 0.00, reads: 0.00, writes: 132342.01, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[3032s] threads: 64, tps: 0.00, reads: 0.00, writes: 130232.14, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[3033s] threads: 64, tps: 0.00, reads: 0.00, writes: 132458.82, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[3034s] threads: 64, tps: 0.00, reads: 0.00, writes: 132347.04, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3035s] threads: 64, tps: 0.00, reads: 0.00, writes: 132482.77, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[3036s] threads: 64, tps: 0.00, reads: 0.00, writes: 132802.23, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3037s] threads: 64, tps: 0.00, reads: 0.00, writes: 132030.99, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[3038s] threads: 64, tps: 0.00, reads: 0.00, writes: 132206.93, response time: 0.73ms (95%), errors: 0.00, reconnects:  0.00
[3039s] threads: 64, tps: 0.00, reads: 0.00, writes: 132717.19, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3040s] threads: 64, tps: 0.00, reads: 0.00, writes: 133021.77, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3041s] threads: 64, tps: 0.00, reads: 0.00, writes: 132814.49, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3042s] threads: 64, tps: 0.00, reads: 0.00, writes: 132806.68, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3043s] threads: 64, tps: 0.00, reads: 0.00, writes: 133441.57, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3044s] threads: 64, tps: 0.00, reads: 0.00, writes: 133007.31, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3045s] threads: 64, tps: 0.00, reads: 0.00, writes: 133013.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3046s] threads: 64, tps: 0.00, reads: 0.00, writes: 132986.66, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3047s] threads: 64, tps: 0.00, reads: 0.00, writes: 132954.70, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3048s] threads: 64, tps: 0.00, reads: 0.00, writes: 132702.69, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3049s] threads: 64, tps: 0.00, reads: 0.00, writes: 133662.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3050s] threads: 64, tps: 0.00, reads: 0.00, writes: 131259.06, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3051s] threads: 64, tps: 0.00, reads: 0.00, writes: 132719.82, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3052s] threads: 64, tps: 0.00, reads: 0.00, writes: 132425.14, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3053s] threads: 64, tps: 0.00, reads: 0.00, writes: 132590.52, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3054s] threads: 64, tps: 0.00, reads: 0.00, writes: 132765.59, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3055s] threads: 64, tps: 0.00, reads: 0.00, writes: 133104.94, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3056s] threads: 64, tps: 0.00, reads: 0.00, writes: 133390.27, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3057s] threads: 64, tps: 0.00, reads: 0.00, writes: 132338.72, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3058s] threads: 64, tps: 0.00, reads: 0.00, writes: 133079.85, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3059s] threads: 64, tps: 0.00, reads: 0.00, writes: 133193.07, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3060s] threads: 64, tps: 0.00, reads: 0.00, writes: 132976.18, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3061s] threads: 64, tps: 0.00, reads: 0.00, writes: 132819.88, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3062s] threads: 64, tps: 0.00, reads: 0.00, writes: 132985.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3063s] threads: 64, tps: 0.00, reads: 0.00, writes: 131954.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3064s] threads: 64, tps: 0.00, reads: 0.00, writes: 132885.02, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3065s] threads: 64, tps: 0.00, reads: 0.00, writes: 132340.92, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3066s] threads: 64, tps: 0.00, reads: 0.00, writes: 132506.21, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3067s] threads: 64, tps: 0.00, reads: 0.00, writes: 133009.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3068s] threads: 64, tps: 0.00, reads: 0.00, writes: 132812.41, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3069s] threads: 64, tps: 0.00, reads: 0.00, writes: 132770.44, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3070s] threads: 64, tps: 0.00, reads: 0.00, writes: 133480.12, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3071s] threads: 64, tps: 0.00, reads: 0.00, writes: 132748.98, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3072s] threads: 64, tps: 0.00, reads: 0.00, writes: 132631.94, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3073s] threads: 64, tps: 0.00, reads: 0.00, writes: 132612.04, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3074s] threads: 64, tps: 0.00, reads: 0.00, writes: 132975.02, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3075s] threads: 64, tps: 0.00, reads: 0.00, writes: 133274.88, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3076s] threads: 64, tps: 0.00, reads: 0.00, writes: 132968.06, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3077s] threads: 64, tps: 0.00, reads: 0.00, writes: 133272.63, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3078s] threads: 64, tps: 0.00, reads: 0.00, writes: 132672.37, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3079s] threads: 64, tps: 0.00, reads: 0.00, writes: 132789.08, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3080s] threads: 64, tps: 0.00, reads: 0.00, writes: 132988.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3081s] threads: 64, tps: 0.00, reads: 0.00, writes: 132681.98, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3082s] threads: 64, tps: 0.00, reads: 0.00, writes: 132445.89, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3083s] threads: 64, tps: 0.00, reads: 0.00, writes: 132880.74, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3084s] threads: 64, tps: 0.00, reads: 0.00, writes: 133344.41, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3085s] threads: 64, tps: 0.00, reads: 0.00, writes: 132942.71, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3086s] threads: 64, tps: 0.00, reads: 0.00, writes: 133080.37, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3087s] threads: 64, tps: 0.00, reads: 0.00, writes: 132801.43, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3088s] threads: 64, tps: 0.00, reads: 0.00, writes: 132596.96, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3089s] threads: 64, tps: 0.00, reads: 0.00, writes: 132853.52, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3090s] threads: 64, tps: 0.00, reads: 0.00, writes: 132567.98, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3091s] threads: 64, tps: 0.00, reads: 0.00, writes: 133496.06, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3092s] threads: 64, tps: 0.00, reads: 0.00, writes: 132843.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3093s] threads: 64, tps: 0.00, reads: 0.00, writes: 132985.87, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3094s] threads: 64, tps: 0.00, reads: 0.00, writes: 133150.99, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3095s] threads: 64, tps: 0.00, reads: 0.00, writes: 132685.13, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3096s] threads: 64, tps: 0.00, reads: 0.00, writes: 133265.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3097s] threads: 64, tps: 0.00, reads: 0.00, writes: 133302.06, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3098s] threads: 64, tps: 0.00, reads: 0.00, writes: 133547.03, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3099s] threads: 64, tps: 0.00, reads: 0.00, writes: 133207.82, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3100s] threads: 64, tps: 0.00, reads: 0.00, writes: 133086.05, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3101s] threads: 64, tps: 0.00, reads: 0.00, writes: 133038.13, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3102s] threads: 64, tps: 0.00, reads: 0.00, writes: 133053.92, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3103s] threads: 64, tps: 0.00, reads: 0.00, writes: 132889.93, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3104s] threads: 64, tps: 0.00, reads: 0.00, writes: 133294.54, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3105s] threads: 64, tps: 0.00, reads: 0.00, writes: 133691.65, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3106s] threads: 64, tps: 0.00, reads: 0.00, writes: 133027.00, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3107s] threads: 64, tps: 0.00, reads: 0.00, writes: 131603.80, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[3108s] threads: 64, tps: 0.00, reads: 0.00, writes: 132604.02, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3109s] threads: 64, tps: 0.00, reads: 0.00, writes: 132744.16, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3110s] threads: 64, tps: 0.00, reads: 0.00, writes: 132653.04, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3111s] threads: 64, tps: 0.00, reads: 0.00, writes: 133253.89, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3112s] threads: 64, tps: 0.00, reads: 0.00, writes: 133408.93, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3113s] threads: 64, tps: 0.00, reads: 0.00, writes: 132967.21, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3114s] threads: 64, tps: 0.00, reads: 0.00, writes: 133036.15, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3115s] threads: 64, tps: 0.00, reads: 0.00, writes: 133230.82, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3116s] threads: 64, tps: 0.00, reads: 0.00, writes: 132457.83, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3117s] threads: 64, tps: 0.00, reads: 0.00, writes: 133081.96, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3118s] threads: 64, tps: 0.00, reads: 0.00, writes: 133179.91, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3119s] threads: 64, tps: 0.00, reads: 0.00, writes: 133461.09, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3120s] threads: 64, tps: 0.00, reads: 0.00, writes: 132745.07, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3121s] threads: 64, tps: 0.00, reads: 0.00, writes: 132547.88, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3122s] threads: 64, tps: 0.00, reads: 0.00, writes: 132911.28, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3123s] threads: 64, tps: 0.00, reads: 0.00, writes: 132798.83, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3124s] threads: 64, tps: 0.00, reads: 0.00, writes: 132844.90, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3125s] threads: 64, tps: 0.00, reads: 0.00, writes: 133131.15, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3126s] threads: 64, tps: 0.00, reads: 0.00, writes: 133202.06, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3127s] threads: 64, tps: 0.00, reads: 0.00, writes: 132976.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3128s] threads: 64, tps: 0.00, reads: 0.00, writes: 132873.99, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3129s] threads: 64, tps: 0.00, reads: 0.00, writes: 132695.05, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3130s] threads: 64, tps: 0.00, reads: 0.00, writes: 130299.95, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3131s] threads: 64, tps: 0.00, reads: 0.00, writes: 130082.94, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3132s] threads: 64, tps: 0.00, reads: 0.00, writes: 132428.03, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3133s] threads: 64, tps: 0.00, reads: 0.00, writes: 131775.15, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3134s] threads: 64, tps: 0.00, reads: 0.00, writes: 131193.93, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3135s] threads: 64, tps: 0.00, reads: 0.00, writes: 130815.56, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3136s] threads: 64, tps: 0.00, reads: 0.00, writes: 130444.89, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3137s] threads: 64, tps: 0.00, reads: 0.00, writes: 132662.67, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3138s] threads: 64, tps: 0.00, reads: 0.00, writes: 134794.90, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3139s] threads: 64, tps: 0.00, reads: 0.00, writes: 134633.86, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3140s] threads: 64, tps: 0.00, reads: 0.00, writes: 134156.09, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3141s] threads: 64, tps: 0.00, reads: 0.00, writes: 134696.40, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3142s] threads: 64, tps: 0.00, reads: 0.00, writes: 134455.51, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3143s] threads: 64, tps: 0.00, reads: 0.00, writes: 134579.23, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3144s] threads: 64, tps: 0.00, reads: 0.00, writes: 134038.85, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3145s] threads: 64, tps: 0.00, reads: 0.00, writes: 134097.02, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3146s] threads: 64, tps: 0.00, reads: 0.00, writes: 134650.09, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3147s] threads: 64, tps: 0.00, reads: 0.00, writes: 133838.84, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3148s] threads: 64, tps: 0.00, reads: 0.00, writes: 133446.08, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3149s] threads: 64, tps: 0.00, reads: 0.00, writes: 133060.84, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3150s] threads: 64, tps: 0.00, reads: 0.00, writes: 133333.06, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3151s] threads: 64, tps: 0.00, reads: 0.00, writes: 133673.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3152s] threads: 64, tps: 0.00, reads: 0.00, writes: 133766.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3153s] threads: 64, tps: 0.00, reads: 0.00, writes: 134184.77, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3154s] threads: 64, tps: 0.00, reads: 0.00, writes: 134152.25, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3155s] threads: 64, tps: 0.00, reads: 0.00, writes: 133911.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3156s] threads: 64, tps: 0.00, reads: 0.00, writes: 133800.03, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3157s] threads: 64, tps: 0.00, reads: 0.00, writes: 133885.77, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3158s] threads: 64, tps: 0.00, reads: 0.00, writes: 133514.31, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3159s] threads: 64, tps: 0.00, reads: 0.00, writes: 133972.93, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3160s] threads: 64, tps: 0.00, reads: 0.00, writes: 134316.08, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3161s] threads: 64, tps: 0.00, reads: 0.00, writes: 134417.78, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3162s] threads: 64, tps: 0.00, reads: 0.00, writes: 133479.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3163s] threads: 64, tps: 0.00, reads: 0.00, writes: 133550.49, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3164s] threads: 64, tps: 0.00, reads: 0.00, writes: 133953.54, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3165s] threads: 64, tps: 0.00, reads: 0.00, writes: 133513.98, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3166s] threads: 64, tps: 0.00, reads: 0.00, writes: 134026.05, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3167s] threads: 64, tps: 0.00, reads: 0.00, writes: 134320.99, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3168s] threads: 64, tps: 0.00, reads: 0.00, writes: 133772.41, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3169s] threads: 64, tps: 0.00, reads: 0.00, writes: 133428.52, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3170s] threads: 64, tps: 0.00, reads: 0.00, writes: 133753.77, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3171s] threads: 64, tps: 0.00, reads: 0.00, writes: 133846.28, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3172s] threads: 64, tps: 0.00, reads: 0.00, writes: 133552.91, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3173s] threads: 64, tps: 0.00, reads: 0.00, writes: 133652.04, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3174s] threads: 64, tps: 0.00, reads: 0.00, writes: 133879.60, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3175s] threads: 64, tps: 0.00, reads: 0.00, writes: 133738.43, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3176s] threads: 64, tps: 0.00, reads: 0.00, writes: 133500.67, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3177s] threads: 64, tps: 0.00, reads: 0.00, writes: 133498.39, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3178s] threads: 64, tps: 0.00, reads: 0.00, writes: 133231.10, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3179s] threads: 64, tps: 0.00, reads: 0.00, writes: 133229.94, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3180s] threads: 64, tps: 0.00, reads: 0.00, writes: 133983.93, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3181s] threads: 64, tps: 0.00, reads: 0.00, writes: 133748.88, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3182s] threads: 64, tps: 0.00, reads: 0.00, writes: 133497.08, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3183s] threads: 64, tps: 0.00, reads: 0.00, writes: 133478.10, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3184s] threads: 64, tps: 0.00, reads: 0.00, writes: 132992.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3185s] threads: 64, tps: 0.00, reads: 0.00, writes: 132975.94, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3186s] threads: 64, tps: 0.00, reads: 0.00, writes: 133039.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3187s] threads: 64, tps: 0.00, reads: 0.00, writes: 133208.07, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3188s] threads: 64, tps: 0.00, reads: 0.00, writes: 133000.15, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3189s] threads: 64, tps: 0.00, reads: 0.00, writes: 132923.82, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3190s] threads: 64, tps: 0.00, reads: 0.00, writes: 132958.97, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3191s] threads: 64, tps: 0.00, reads: 0.00, writes: 132768.53, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3192s] threads: 64, tps: 0.00, reads: 0.00, writes: 132618.09, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3193s] threads: 64, tps: 0.00, reads: 0.00, writes: 132518.32, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3194s] threads: 64, tps: 0.00, reads: 0.00, writes: 132757.88, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3195s] threads: 64, tps: 0.00, reads: 0.00, writes: 133441.28, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3196s] threads: 64, tps: 0.00, reads: 0.00, writes: 132525.42, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3197s] threads: 64, tps: 0.00, reads: 0.00, writes: 133054.13, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3198s] threads: 64, tps: 0.00, reads: 0.00, writes: 133096.52, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3199s] threads: 64, tps: 0.00, reads: 0.00, writes: 132822.86, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3200s] threads: 64, tps: 0.00, reads: 0.00, writes: 132747.27, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3201s] threads: 64, tps: 0.00, reads: 0.00, writes: 132724.73, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3202s] threads: 64, tps: 0.00, reads: 0.00, writes: 133188.14, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3203s] threads: 64, tps: 0.00, reads: 0.00, writes: 132768.86, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3204s] threads: 64, tps: 0.00, reads: 0.00, writes: 132836.93, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3205s] threads: 64, tps: 0.00, reads: 0.00, writes: 132467.00, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3206s] threads: 64, tps: 0.00, reads: 0.00, writes: 133105.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3207s] threads: 64, tps: 0.00, reads: 0.00, writes: 132766.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3208s] threads: 64, tps: 0.00, reads: 0.00, writes: 132991.92, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3209s] threads: 64, tps: 0.00, reads: 0.00, writes: 132385.43, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3210s] threads: 64, tps: 0.00, reads: 0.00, writes: 132876.61, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3211s] threads: 64, tps: 0.00, reads: 0.00, writes: 132744.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3212s] threads: 64, tps: 0.00, reads: 0.00, writes: 132845.13, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3213s] threads: 64, tps: 0.00, reads: 0.00, writes: 133189.92, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3214s] threads: 64, tps: 0.00, reads: 0.00, writes: 132987.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3215s] threads: 64, tps: 0.00, reads: 0.00, writes: 133383.97, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3216s] threads: 64, tps: 0.00, reads: 0.00, writes: 133872.05, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3217s] threads: 64, tps: 0.00, reads: 0.00, writes: 133379.97, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3218s] threads: 64, tps: 0.00, reads: 0.00, writes: 131339.23, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3219s] threads: 64, tps: 0.00, reads: 0.00, writes: 132720.64, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3220s] threads: 64, tps: 0.00, reads: 0.00, writes: 133052.98, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3221s] threads: 64, tps: 0.00, reads: 0.00, writes: 132821.09, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3222s] threads: 64, tps: 0.00, reads: 0.00, writes: 133143.01, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3223s] threads: 64, tps: 0.00, reads: 0.00, writes: 133118.97, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3224s] threads: 64, tps: 0.00, reads: 0.00, writes: 131730.04, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3225s] threads: 64, tps: 0.00, reads: 0.00, writes: 132518.09, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3226s] threads: 64, tps: 0.00, reads: 0.00, writes: 132912.94, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3227s] threads: 64, tps: 0.00, reads: 0.00, writes: 132047.77, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3228s] threads: 64, tps: 0.00, reads: 0.00, writes: 132433.26, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3229s] threads: 64, tps: 0.00, reads: 0.00, writes: 132593.85, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3230s] threads: 64, tps: 0.00, reads: 0.00, writes: 132920.96, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3231s] threads: 64, tps: 0.00, reads: 0.00, writes: 132501.19, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3232s] threads: 64, tps: 0.00, reads: 0.00, writes: 132403.91, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3233s] threads: 64, tps: 0.00, reads: 0.00, writes: 131498.08, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3234s] threads: 64, tps: 0.00, reads: 0.00, writes: 132075.03, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3235s] threads: 64, tps: 0.00, reads: 0.00, writes: 132404.06, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3236s] threads: 64, tps: 0.00, reads: 0.00, writes: 132786.81, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3237s] threads: 64, tps: 0.00, reads: 0.00, writes: 132580.94, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3238s] threads: 64, tps: 0.00, reads: 0.00, writes: 132217.02, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3239s] threads: 64, tps: 0.00, reads: 0.00, writes: 132239.27, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3240s] threads: 64, tps: 0.00, reads: 0.00, writes: 132299.88, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3241s] threads: 64, tps: 0.00, reads: 0.00, writes: 131994.04, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3242s] threads: 64, tps: 0.00, reads: 0.00, writes: 132344.86, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3243s] threads: 64, tps: 0.00, reads: 0.00, writes: 132666.96, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3244s] threads: 64, tps: 0.00, reads: 0.00, writes: 132818.09, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3245s] threads: 64, tps: 0.00, reads: 0.00, writes: 132265.99, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3246s] threads: 64, tps: 0.00, reads: 0.00, writes: 130873.66, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3247s] threads: 64, tps: 0.00, reads: 0.00, writes: 131652.36, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3248s] threads: 64, tps: 0.00, reads: 0.00, writes: 131757.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3249s] threads: 64, tps: 0.00, reads: 0.00, writes: 131948.19, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3250s] threads: 64, tps: 0.00, reads: 0.00, writes: 131988.88, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3251s] threads: 64, tps: 0.00, reads: 0.00, writes: 131994.96, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3252s] threads: 64, tps: 0.00, reads: 0.00, writes: 132108.87, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3253s] threads: 64, tps: 0.00, reads: 0.00, writes: 131701.72, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3254s] threads: 64, tps: 0.00, reads: 0.00, writes: 131824.68, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3255s] threads: 64, tps: 0.00, reads: 0.00, writes: 131842.65, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3256s] threads: 64, tps: 0.00, reads: 0.00, writes: 132099.04, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3257s] threads: 64, tps: 0.00, reads: 0.00, writes: 132640.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3258s] threads: 64, tps: 0.00, reads: 0.00, writes: 131826.29, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3259s] threads: 64, tps: 0.00, reads: 0.00, writes: 131555.87, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3260s] threads: 64, tps: 0.00, reads: 0.00, writes: 131256.57, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3261s] threads: 64, tps: 0.00, reads: 0.00, writes: 132420.65, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3262s] threads: 64, tps: 0.00, reads: 0.00, writes: 132069.92, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3263s] threads: 64, tps: 0.00, reads: 0.00, writes: 132285.13, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3264s] threads: 64, tps: 0.00, reads: 0.00, writes: 132818.88, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3265s] threads: 64, tps: 0.00, reads: 0.00, writes: 132316.38, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3266s] threads: 64, tps: 0.00, reads: 0.00, writes: 132408.57, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3267s] threads: 64, tps: 0.00, reads: 0.00, writes: 131689.50, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3268s] threads: 64, tps: 0.00, reads: 0.00, writes: 131967.50, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3269s] threads: 64, tps: 0.00, reads: 0.00, writes: 132245.05, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3270s] threads: 64, tps: 0.00, reads: 0.00, writes: 131973.03, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3271s] threads: 64, tps: 0.00, reads: 0.00, writes: 132737.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3272s] threads: 64, tps: 0.00, reads: 0.00, writes: 132137.90, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3273s] threads: 64, tps: 0.00, reads: 0.00, writes: 132457.98, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3274s] threads: 64, tps: 0.00, reads: 0.00, writes: 132404.10, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3275s] threads: 64, tps: 0.00, reads: 0.00, writes: 132012.90, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3276s] threads: 64, tps: 0.00, reads: 0.00, writes: 132094.06, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3277s] threads: 64, tps: 0.00, reads: 0.00, writes: 132753.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3278s] threads: 64, tps: 0.00, reads: 0.00, writes: 132239.12, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3279s] threads: 64, tps: 0.00, reads: 0.00, writes: 131947.85, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3280s] threads: 64, tps: 0.00, reads: 0.00, writes: 131773.38, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3281s] threads: 64, tps: 0.00, reads: 0.00, writes: 132176.63, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3282s] threads: 64, tps: 0.00, reads: 0.00, writes: 132954.16, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3283s] threads: 64, tps: 0.00, reads: 0.00, writes: 132621.88, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3284s] threads: 64, tps: 0.00, reads: 0.00, writes: 133256.91, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3285s] threads: 64, tps: 0.00, reads: 0.00, writes: 132477.68, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3286s] threads: 64, tps: 0.00, reads: 0.00, writes: 131897.31, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3287s] threads: 64, tps: 0.00, reads: 0.00, writes: 132388.84, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3288s] threads: 64, tps: 0.00, reads: 0.00, writes: 132206.56, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3289s] threads: 64, tps: 0.00, reads: 0.00, writes: 131718.30, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3290s] threads: 64, tps: 0.00, reads: 0.00, writes: 130998.41, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[3291s] threads: 64, tps: 0.00, reads: 0.00, writes: 132686.93, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3292s] threads: 64, tps: 0.00, reads: 0.00, writes: 132008.30, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3293s] threads: 64, tps: 0.00, reads: 0.00, writes: 132350.70, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3294s] threads: 64, tps: 0.00, reads: 0.00, writes: 131931.99, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3295s] threads: 64, tps: 0.00, reads: 0.00, writes: 131464.74, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3296s] threads: 64, tps: 0.00, reads: 0.00, writes: 131309.50, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3297s] threads: 64, tps: 0.00, reads: 0.00, writes: 132359.72, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3298s] threads: 64, tps: 0.00, reads: 0.00, writes: 132859.09, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3299s] threads: 64, tps: 0.00, reads: 0.00, writes: 132281.08, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3300s] threads: 64, tps: 0.00, reads: 0.00, writes: 132410.79, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3301s] threads: 64, tps: 0.00, reads: 0.00, writes: 132182.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3302s] threads: 64, tps: 0.00, reads: 0.00, writes: 132135.11, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3303s] threads: 64, tps: 0.00, reads: 0.00, writes: 131921.14, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3304s] threads: 64, tps: 0.00, reads: 0.00, writes: 132283.24, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3305s] threads: 64, tps: 0.00, reads: 0.00, writes: 132371.67, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3306s] threads: 64, tps: 0.00, reads: 0.00, writes: 131805.97, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3307s] threads: 64, tps: 0.00, reads: 0.00, writes: 132086.06, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3308s] threads: 64, tps: 0.00, reads: 0.00, writes: 132220.94, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3309s] threads: 64, tps: 0.00, reads: 0.00, writes: 132301.19, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3310s] threads: 64, tps: 0.00, reads: 0.00, writes: 132257.82, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3311s] threads: 64, tps: 0.00, reads: 0.00, writes: 133166.96, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3312s] threads: 64, tps: 0.00, reads: 0.00, writes: 132691.55, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3313s] threads: 64, tps: 0.00, reads: 0.00, writes: 132654.04, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3314s] threads: 64, tps: 0.00, reads: 0.00, writes: 132475.38, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3315s] threads: 64, tps: 0.00, reads: 0.00, writes: 132170.93, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3316s] threads: 64, tps: 0.00, reads: 0.00, writes: 132148.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3317s] threads: 64, tps: 0.00, reads: 0.00, writes: 132624.88, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3318s] threads: 64, tps: 0.00, reads: 0.00, writes: 132937.18, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3319s] threads: 64, tps: 0.00, reads: 0.00, writes: 132471.98, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3320s] threads: 64, tps: 0.00, reads: 0.00, writes: 132329.28, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3321s] threads: 64, tps: 0.00, reads: 0.00, writes: 132481.19, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3322s] threads: 64, tps: 0.00, reads: 0.00, writes: 132588.48, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3323s] threads: 64, tps: 0.00, reads: 0.00, writes: 132138.94, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3324s] threads: 64, tps: 0.00, reads: 0.00, writes: 131031.10, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[3325s] threads: 64, tps: 0.00, reads: 0.00, writes: 132080.98, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3326s] threads: 64, tps: 0.00, reads: 0.00, writes: 132909.06, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3327s] threads: 64, tps: 0.00, reads: 0.00, writes: 132277.78, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3328s] threads: 64, tps: 0.00, reads: 0.00, writes: 132510.04, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3329s] threads: 64, tps: 0.00, reads: 0.00, writes: 132642.10, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3330s] threads: 64, tps: 0.00, reads: 0.00, writes: 132546.47, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3331s] threads: 64, tps: 0.00, reads: 0.00, writes: 132357.61, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3332s] threads: 64, tps: 0.00, reads: 0.00, writes: 133386.07, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3333s] threads: 64, tps: 0.00, reads: 0.00, writes: 133052.89, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3334s] threads: 64, tps: 0.00, reads: 0.00, writes: 133122.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3335s] threads: 64, tps: 0.00, reads: 0.00, writes: 132833.63, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3336s] threads: 64, tps: 0.00, reads: 0.00, writes: 133043.45, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3337s] threads: 64, tps: 0.00, reads: 0.00, writes: 133197.42, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3338s] threads: 64, tps: 0.00, reads: 0.00, writes: 133213.37, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3339s] threads: 64, tps: 0.00, reads: 0.00, writes: 133525.75, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3340s] threads: 64, tps: 0.00, reads: 0.00, writes: 133211.36, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3341s] threads: 64, tps: 0.00, reads: 0.00, writes: 132709.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3342s] threads: 64, tps: 0.00, reads: 0.00, writes: 132536.21, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3343s] threads: 64, tps: 0.00, reads: 0.00, writes: 133216.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3344s] threads: 64, tps: 0.00, reads: 0.00, writes: 132761.83, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3345s] threads: 64, tps: 0.00, reads: 0.00, writes: 132322.05, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3346s] threads: 64, tps: 0.00, reads: 0.00, writes: 131853.19, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3347s] threads: 64, tps: 0.00, reads: 0.00, writes: 132307.88, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3348s] threads: 64, tps: 0.00, reads: 0.00, writes: 132754.06, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3349s] threads: 64, tps: 0.00, reads: 0.00, writes: 132961.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3350s] threads: 64, tps: 0.00, reads: 0.00, writes: 132570.90, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3351s] threads: 64, tps: 0.00, reads: 0.00, writes: 132400.01, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3352s] threads: 64, tps: 0.00, reads: 0.00, writes: 132272.12, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3353s] threads: 64, tps: 0.00, reads: 0.00, writes: 133310.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3354s] threads: 64, tps: 0.00, reads: 0.00, writes: 132766.32, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3355s] threads: 64, tps: 0.00, reads: 0.00, writes: 132840.66, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3356s] threads: 64, tps: 0.00, reads: 0.00, writes: 132297.95, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3357s] threads: 64, tps: 0.00, reads: 0.00, writes: 132824.13, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3358s] threads: 64, tps: 0.00, reads: 0.00, writes: 132551.80, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3359s] threads: 64, tps: 0.00, reads: 0.00, writes: 133105.92, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3360s] threads: 64, tps: 0.00, reads: 0.00, writes: 133112.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3361s] threads: 64, tps: 0.00, reads: 0.00, writes: 129690.92, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3362s] threads: 64, tps: 0.00, reads: 0.00, writes: 132495.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3363s] threads: 64, tps: 0.00, reads: 0.00, writes: 132786.84, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3364s] threads: 64, tps: 0.00, reads: 0.00, writes: 132969.12, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3365s] threads: 64, tps: 0.00, reads: 0.00, writes: 132189.99, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3366s] threads: 64, tps: 0.00, reads: 0.00, writes: 132653.12, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3367s] threads: 64, tps: 0.00, reads: 0.00, writes: 132882.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3368s] threads: 64, tps: 0.00, reads: 0.00, writes: 132451.67, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3369s] threads: 64, tps: 0.00, reads: 0.00, writes: 132397.39, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3370s] threads: 64, tps: 0.00, reads: 0.00, writes: 131901.74, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3371s] threads: 64, tps: 0.00, reads: 0.00, writes: 132487.96, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3372s] threads: 64, tps: 0.00, reads: 0.00, writes: 132626.13, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3373s] threads: 64, tps: 0.00, reads: 0.00, writes: 133388.17, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3374s] threads: 64, tps: 0.00, reads: 0.00, writes: 132626.81, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3375s] threads: 64, tps: 0.00, reads: 0.00, writes: 132154.97, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3376s] threads: 64, tps: 0.00, reads: 0.00, writes: 132620.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3377s] threads: 64, tps: 0.00, reads: 0.00, writes: 132375.13, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3378s] threads: 64, tps: 0.00, reads: 0.00, writes: 132333.35, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3379s] threads: 64, tps: 0.00, reads: 0.00, writes: 132715.63, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3380s] threads: 64, tps: 0.00, reads: 0.00, writes: 132491.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3381s] threads: 64, tps: 0.00, reads: 0.00, writes: 131537.91, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3382s] threads: 64, tps: 0.00, reads: 0.00, writes: 132285.49, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3383s] threads: 64, tps: 0.00, reads: 0.00, writes: 132583.09, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3384s] threads: 64, tps: 0.00, reads: 0.00, writes: 132556.41, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3385s] threads: 64, tps: 0.00, reads: 0.00, writes: 132536.97, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3386s] threads: 64, tps: 0.00, reads: 0.00, writes: 132787.99, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3387s] threads: 64, tps: 0.00, reads: 0.00, writes: 133224.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3388s] threads: 64, tps: 0.00, reads: 0.00, writes: 132328.99, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3389s] threads: 64, tps: 0.00, reads: 0.00, writes: 132555.84, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3390s] threads: 64, tps: 0.00, reads: 0.00, writes: 132425.13, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3391s] threads: 64, tps: 0.00, reads: 0.00, writes: 132464.84, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3392s] threads: 64, tps: 0.00, reads: 0.00, writes: 132858.17, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3393s] threads: 64, tps: 0.00, reads: 0.00, writes: 133109.03, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3394s] threads: 64, tps: 0.00, reads: 0.00, writes: 133423.88, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3395s] threads: 64, tps: 0.00, reads: 0.00, writes: 133394.93, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3396s] threads: 64, tps: 0.00, reads: 0.00, writes: 132852.03, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3397s] threads: 64, tps: 0.00, reads: 0.00, writes: 132519.15, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3398s] threads: 64, tps: 0.00, reads: 0.00, writes: 132888.83, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3399s] threads: 64, tps: 0.00, reads: 0.00, writes: 132688.02, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3400s] threads: 64, tps: 0.00, reads: 0.00, writes: 132919.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3401s] threads: 64, tps: 0.00, reads: 0.00, writes: 133033.97, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3402s] threads: 64, tps: 0.00, reads: 0.00, writes: 132885.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3403s] threads: 64, tps: 0.00, reads: 0.00, writes: 132733.99, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3404s] threads: 64, tps: 0.00, reads: 0.00, writes: 132551.85, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3405s] threads: 64, tps: 0.00, reads: 0.00, writes: 132724.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3406s] threads: 64, tps: 0.00, reads: 0.00, writes: 132447.59, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3407s] threads: 64, tps: 0.00, reads: 0.00, writes: 133269.35, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3408s] threads: 64, tps: 0.00, reads: 0.00, writes: 132943.65, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3409s] threads: 64, tps: 0.00, reads: 0.00, writes: 132606.41, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3410s] threads: 64, tps: 0.00, reads: 0.00, writes: 133054.08, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3411s] threads: 64, tps: 0.00, reads: 0.00, writes: 132653.35, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3412s] threads: 64, tps: 0.00, reads: 0.00, writes: 132649.55, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3413s] threads: 64, tps: 0.00, reads: 0.00, writes: 132350.73, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3414s] threads: 64, tps: 0.00, reads: 0.00, writes: 132950.16, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3415s] threads: 64, tps: 0.00, reads: 0.00, writes: 132625.58, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3416s] threads: 64, tps: 0.00, reads: 0.00, writes: 132390.65, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3417s] threads: 64, tps: 0.00, reads: 0.00, writes: 132619.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3418s] threads: 64, tps: 0.00, reads: 0.00, writes: 132706.38, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3419s] threads: 64, tps: 0.00, reads: 0.00, writes: 132401.56, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3420s] threads: 64, tps: 0.00, reads: 0.00, writes: 132595.73, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3421s] threads: 64, tps: 0.00, reads: 0.00, writes: 132497.32, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3422s] threads: 64, tps: 0.00, reads: 0.00, writes: 132616.04, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3423s] threads: 64, tps: 0.00, reads: 0.00, writes: 132389.02, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3424s] threads: 64, tps: 0.00, reads: 0.00, writes: 132192.21, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3425s] threads: 64, tps: 0.00, reads: 0.00, writes: 132288.59, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3426s] threads: 64, tps: 0.00, reads: 0.00, writes: 131919.16, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3427s] threads: 64, tps: 0.00, reads: 0.00, writes: 132105.91, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3428s] threads: 64, tps: 0.00, reads: 0.00, writes: 132452.68, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3429s] threads: 64, tps: 0.00, reads: 0.00, writes: 132592.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3430s] threads: 64, tps: 0.00, reads: 0.00, writes: 132084.79, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3431s] threads: 64, tps: 0.00, reads: 0.00, writes: 132365.48, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3432s] threads: 64, tps: 0.00, reads: 0.00, writes: 132247.46, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3433s] threads: 64, tps: 0.00, reads: 0.00, writes: 132338.79, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3434s] threads: 64, tps: 0.00, reads: 0.00, writes: 132130.74, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3435s] threads: 64, tps: 0.00, reads: 0.00, writes: 132707.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3436s] threads: 64, tps: 0.00, reads: 0.00, writes: 132467.78, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3437s] threads: 64, tps: 0.00, reads: 0.00, writes: 131925.33, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3438s] threads: 64, tps: 0.00, reads: 0.00, writes: 131959.24, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3439s] threads: 64, tps: 0.00, reads: 0.00, writes: 132169.70, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3440s] threads: 64, tps: 0.00, reads: 0.00, writes: 132223.89, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3441s] threads: 64, tps: 0.00, reads: 0.00, writes: 132028.08, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3442s] threads: 64, tps: 0.00, reads: 0.00, writes: 131720.01, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3443s] threads: 64, tps: 0.00, reads: 0.00, writes: 131685.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3444s] threads: 64, tps: 0.00, reads: 0.00, writes: 132299.80, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3445s] threads: 64, tps: 0.00, reads: 0.00, writes: 132716.82, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3446s] threads: 64, tps: 0.00, reads: 0.00, writes: 131753.68, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3447s] threads: 64, tps: 0.00, reads: 0.00, writes: 131902.11, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3448s] threads: 64, tps: 0.00, reads: 0.00, writes: 132247.40, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3449s] threads: 64, tps: 0.00, reads: 0.00, writes: 132229.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3450s] threads: 64, tps: 0.00, reads: 0.00, writes: 132372.93, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3451s] threads: 64, tps: 0.00, reads: 0.00, writes: 132387.07, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3452s] threads: 64, tps: 0.00, reads: 0.00, writes: 132203.47, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3453s] threads: 64, tps: 0.00, reads: 0.00, writes: 132322.89, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3454s] threads: 64, tps: 0.00, reads: 0.00, writes: 132414.89, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3455s] threads: 64, tps: 0.00, reads: 0.00, writes: 132958.62, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3456s] threads: 64, tps: 0.00, reads: 0.00, writes: 132900.60, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3457s] threads: 64, tps: 0.00, reads: 0.00, writes: 132361.51, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3458s] threads: 64, tps: 0.00, reads: 0.00, writes: 132474.98, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3459s] threads: 64, tps: 0.00, reads: 0.00, writes: 132425.08, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3460s] threads: 64, tps: 0.00, reads: 0.00, writes: 132267.83, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3461s] threads: 64, tps: 0.00, reads: 0.00, writes: 132411.12, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3462s] threads: 64, tps: 0.00, reads: 0.00, writes: 132588.13, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3463s] threads: 64, tps: 0.00, reads: 0.00, writes: 132597.74, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3464s] threads: 64, tps: 0.00, reads: 0.00, writes: 132510.19, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3465s] threads: 64, tps: 0.00, reads: 0.00, writes: 132420.41, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3466s] threads: 64, tps: 0.00, reads: 0.00, writes: 132669.49, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3467s] threads: 64, tps: 0.00, reads: 0.00, writes: 132190.08, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3468s] threads: 64, tps: 0.00, reads: 0.00, writes: 132363.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3469s] threads: 64, tps: 0.00, reads: 0.00, writes: 132656.02, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3470s] threads: 64, tps: 0.00, reads: 0.00, writes: 132588.46, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3471s] threads: 64, tps: 0.00, reads: 0.00, writes: 132628.35, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3472s] threads: 64, tps: 0.00, reads: 0.00, writes: 131829.03, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3473s] threads: 64, tps: 0.00, reads: 0.00, writes: 132678.78, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3474s] threads: 64, tps: 0.00, reads: 0.00, writes: 132535.40, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3475s] threads: 64, tps: 0.00, reads: 0.00, writes: 132641.86, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3476s] threads: 64, tps: 0.00, reads: 0.00, writes: 132701.18, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3477s] threads: 64, tps: 0.00, reads: 0.00, writes: 132148.99, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3478s] threads: 64, tps: 0.00, reads: 0.00, writes: 131921.93, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3479s] threads: 64, tps: 0.00, reads: 0.00, writes: 132315.87, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3480s] threads: 64, tps: 0.00, reads: 0.00, writes: 132083.08, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3481s] threads: 64, tps: 0.00, reads: 0.00, writes: 132440.77, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3482s] threads: 64, tps: 0.00, reads: 0.00, writes: 132445.20, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3483s] threads: 64, tps: 0.00, reads: 0.00, writes: 132867.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3484s] threads: 64, tps: 0.00, reads: 0.00, writes: 132170.51, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3485s] threads: 64, tps: 0.00, reads: 0.00, writes: 132007.43, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3486s] threads: 64, tps: 0.00, reads: 0.00, writes: 132005.92, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3487s] threads: 64, tps: 0.00, reads: 0.00, writes: 131741.04, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3488s] threads: 64, tps: 0.00, reads: 0.00, writes: 131754.02, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3489s] threads: 64, tps: 0.00, reads: 0.00, writes: 131743.01, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3490s] threads: 64, tps: 0.00, reads: 0.00, writes: 132953.94, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3491s] threads: 64, tps: 0.00, reads: 0.00, writes: 132371.86, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3492s] threads: 64, tps: 0.00, reads: 0.00, writes: 132310.64, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3493s] threads: 64, tps: 0.00, reads: 0.00, writes: 132225.50, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3494s] threads: 64, tps: 0.00, reads: 0.00, writes: 132318.10, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3495s] threads: 64, tps: 0.00, reads: 0.00, writes: 132065.94, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3496s] threads: 64, tps: 0.00, reads: 0.00, writes: 132400.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3497s] threads: 64, tps: 0.00, reads: 0.00, writes: 132464.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3498s] threads: 64, tps: 0.00, reads: 0.00, writes: 132285.47, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3499s] threads: 64, tps: 0.00, reads: 0.00, writes: 131753.39, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3500s] threads: 64, tps: 0.00, reads: 0.00, writes: 132232.04, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3501s] threads: 64, tps: 0.00, reads: 0.00, writes: 131363.01, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3502s] threads: 64, tps: 0.00, reads: 0.00, writes: 132115.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3503s] threads: 64, tps: 0.00, reads: 0.00, writes: 132114.25, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3504s] threads: 64, tps: 0.00, reads: 0.00, writes: 131760.73, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3505s] threads: 64, tps: 0.00, reads: 0.00, writes: 131437.12, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3506s] threads: 64, tps: 0.00, reads: 0.00, writes: 131882.28, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3507s] threads: 64, tps: 0.00, reads: 0.00, writes: 131790.93, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3508s] threads: 64, tps: 0.00, reads: 0.00, writes: 132060.62, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3509s] threads: 64, tps: 0.00, reads: 0.00, writes: 131565.03, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3510s] threads: 64, tps: 0.00, reads: 0.00, writes: 131916.09, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3511s] threads: 64, tps: 0.00, reads: 0.00, writes: 132620.94, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3512s] threads: 64, tps: 0.00, reads: 0.00, writes: 132441.86, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3513s] threads: 64, tps: 0.00, reads: 0.00, writes: 132056.19, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3514s] threads: 64, tps: 0.00, reads: 0.00, writes: 131938.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3515s] threads: 64, tps: 0.00, reads: 0.00, writes: 132222.17, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3516s] threads: 64, tps: 0.00, reads: 0.00, writes: 132162.77, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3517s] threads: 64, tps: 0.00, reads: 0.00, writes: 132294.17, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3518s] threads: 64, tps: 0.00, reads: 0.00, writes: 132599.01, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3519s] threads: 64, tps: 0.00, reads: 0.00, writes: 131989.79, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3520s] threads: 64, tps: 0.00, reads: 0.00, writes: 132106.19, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3521s] threads: 64, tps: 0.00, reads: 0.00, writes: 132358.94, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3522s] threads: 64, tps: 0.00, reads: 0.00, writes: 132158.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3523s] threads: 64, tps: 0.00, reads: 0.00, writes: 131832.35, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3524s] threads: 64, tps: 0.00, reads: 0.00, writes: 132365.54, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3525s] threads: 64, tps: 0.00, reads: 0.00, writes: 132512.03, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3526s] threads: 64, tps: 0.00, reads: 0.00, writes: 132214.02, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3527s] threads: 64, tps: 0.00, reads: 0.00, writes: 132347.98, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3528s] threads: 64, tps: 0.00, reads: 0.00, writes: 131725.05, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3529s] threads: 64, tps: 0.00, reads: 0.00, writes: 131992.04, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3530s] threads: 64, tps: 0.00, reads: 0.00, writes: 132104.08, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3531s] threads: 64, tps: 0.00, reads: 0.00, writes: 132476.88, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3532s] threads: 64, tps: 0.00, reads: 0.00, writes: 132206.81, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3533s] threads: 64, tps: 0.00, reads: 0.00, writes: 132100.13, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3534s] threads: 64, tps: 0.00, reads: 0.00, writes: 131926.19, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3535s] threads: 64, tps: 0.00, reads: 0.00, writes: 131829.78, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3536s] threads: 64, tps: 0.00, reads: 0.00, writes: 132262.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3537s] threads: 64, tps: 0.00, reads: 0.00, writes: 132041.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3538s] threads: 64, tps: 0.00, reads: 0.00, writes: 132353.99, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3539s] threads: 64, tps: 0.00, reads: 0.00, writes: 132230.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3540s] threads: 64, tps: 0.00, reads: 0.00, writes: 132117.19, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3541s] threads: 64, tps: 0.00, reads: 0.00, writes: 131751.89, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3542s] threads: 64, tps: 0.00, reads: 0.00, writes: 131462.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3543s] threads: 64, tps: 0.00, reads: 0.00, writes: 131625.25, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3544s] threads: 64, tps: 0.00, reads: 0.00, writes: 131837.78, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3545s] threads: 64, tps: 0.00, reads: 0.00, writes: 132218.02, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3546s] threads: 64, tps: 0.00, reads: 0.00, writes: 131361.09, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3547s] threads: 64, tps: 0.00, reads: 0.00, writes: 131533.92, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3548s] threads: 64, tps: 0.00, reads: 0.00, writes: 131661.04, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3549s] threads: 64, tps: 0.00, reads: 0.00, writes: 131350.88, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3550s] threads: 64, tps: 0.00, reads: 0.00, writes: 131724.11, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3551s] threads: 64, tps: 0.00, reads: 0.00, writes: 131785.01, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3552s] threads: 64, tps: 0.00, reads: 0.00, writes: 132305.07, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3553s] threads: 64, tps: 0.00, reads: 0.00, writes: 131463.90, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3554s] threads: 64, tps: 0.00, reads: 0.00, writes: 131624.05, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3555s] threads: 64, tps: 0.00, reads: 0.00, writes: 131919.46, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3556s] threads: 64, tps: 0.00, reads: 0.00, writes: 131476.48, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3557s] threads: 64, tps: 0.00, reads: 0.00, writes: 131837.85, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3558s] threads: 64, tps: 0.00, reads: 0.00, writes: 131889.80, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3559s] threads: 64, tps: 0.00, reads: 0.00, writes: 132062.50, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3560s] threads: 64, tps: 0.00, reads: 0.00, writes: 131450.84, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3561s] threads: 64, tps: 0.00, reads: 0.00, writes: 131360.94, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3562s] threads: 64, tps: 0.00, reads: 0.00, writes: 131770.18, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3563s] threads: 64, tps: 0.00, reads: 0.00, writes: 131192.94, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3564s] threads: 64, tps: 0.00, reads: 0.00, writes: 131630.09, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3565s] threads: 64, tps: 0.00, reads: 0.00, writes: 132155.78, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3566s] threads: 64, tps: 0.00, reads: 0.00, writes: 132271.06, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3567s] threads: 64, tps: 0.00, reads: 0.00, writes: 132002.46, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3568s] threads: 64, tps: 0.00, reads: 0.00, writes: 131722.78, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3569s] threads: 64, tps: 0.00, reads: 0.00, writes: 132080.88, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3570s] threads: 64, tps: 0.00, reads: 0.00, writes: 131819.01, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3571s] threads: 64, tps: 0.00, reads: 0.00, writes: 131596.78, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3572s] threads: 64, tps: 0.00, reads: 0.00, writes: 132284.21, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3573s] threads: 64, tps: 0.00, reads: 0.00, writes: 132099.07, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3574s] threads: 64, tps: 0.00, reads: 0.00, writes: 131724.88, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3575s] threads: 64, tps: 0.00, reads: 0.00, writes: 131774.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3576s] threads: 64, tps: 0.00, reads: 0.00, writes: 131729.07, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3577s] threads: 64, tps: 0.00, reads: 0.00, writes: 131434.88, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3578s] threads: 64, tps: 0.00, reads: 0.00, writes: 131869.05, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3579s] threads: 64, tps: 0.00, reads: 0.00, writes: 132472.85, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3580s] threads: 64, tps: 0.00, reads: 0.00, writes: 131895.21, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3581s] threads: 64, tps: 0.00, reads: 0.00, writes: 132087.01, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3582s] threads: 64, tps: 0.00, reads: 0.00, writes: 132280.03, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3583s] threads: 64, tps: 0.00, reads: 0.00, writes: 131720.88, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3584s] threads: 64, tps: 0.00, reads: 0.00, writes: 132213.95, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3585s] threads: 64, tps: 0.00, reads: 0.00, writes: 132604.18, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3586s] threads: 64, tps: 0.00, reads: 0.00, writes: 132660.78, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3587s] threads: 64, tps: 0.00, reads: 0.00, writes: 132211.65, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3588s] threads: 64, tps: 0.00, reads: 0.00, writes: 131593.89, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3589s] threads: 64, tps: 0.00, reads: 0.00, writes: 131713.62, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[3590s] threads: 64, tps: 0.00, reads: 0.00, writes: 131942.93, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3591s] threads: 64, tps: 0.00, reads: 0.00, writes: 131862.44, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3592s] threads: 64, tps: 0.00, reads: 0.00, writes: 132163.49, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3593s] threads: 64, tps: 0.00, reads: 0.00, writes: 133018.19, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[3594s] threads: 64, tps: 0.00, reads: 0.00, writes: 132385.98, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3595s] threads: 64, tps: 0.00, reads: 0.00, writes: 132236.64, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3596s] threads: 64, tps: 0.00, reads: 0.00, writes: 132455.26, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3597s] threads: 64, tps: 0.00, reads: 0.00, writes: 132023.21, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3598s] threads: 64, tps: 0.00, reads: 0.00, writes: 132127.77, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3599s] threads: 64, tps: 0.00, reads: 0.00, writes: 132434.11, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[3600s] threads: 64, tps: 0.00, reads: 0.00, writes: 132644.87, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
OLTP test statistics:
    queries performed:
        read:                            0
        write:                           416527287
        other:                           0
        total:                           416527287
    transactions:                        0      (0.00 per sec.)
    read/write requests:                 416527287 (115702.00 per sec.)
    other operations:                    0      (0.00 per sec.)
    ignored errors:                      0      (0.00 per sec.)
    reconnects:                          0      (0.00 per sec.)

General statistics:
    total time:                          3600.0007s
    total number of events:              416527287
    total time taken by event execution: 229602.5883s
    response time:
         min:                                  0.06ms
         avg:                                  0.55ms
         max:                               5987.17ms
         approx.  95 percentile:               1.82ms

Threads fairness:
    events (avg/stddev):           6508238.8594/10804.85
    execution time (avg/stddev):   3587.5404/0.04

