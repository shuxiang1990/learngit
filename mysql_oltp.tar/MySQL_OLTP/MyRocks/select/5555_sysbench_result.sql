sysbench 0.5:  multi-threaded system evaluation benchmark

Running the test with following options:
Number of threads: 64
Report intermediate results every 1 second(s)
Initializing random number generator from timer.

Random number generator seed is 0 and will be ignored


Threads started!

[   1s] threads: 64, tps: 0.00, reads: 48671.84, writes: 0.00, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[   2s] threads: 64, tps: 0.00, reads: 80360.47, writes: 0.00, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[   3s] threads: 64, tps: 0.00, reads: 87176.98, writes: 0.00, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[   4s] threads: 64, tps: 0.00, reads: 75932.13, writes: 0.00, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[   5s] threads: 64, tps: 0.00, reads: 77575.93, writes: 0.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[   6s] threads: 64, tps: 0.00, reads: 74647.00, writes: 0.00, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[   7s] threads: 64, tps: 0.00, reads: 76918.01, writes: 0.00, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[   8s] threads: 64, tps: 0.00, reads: 77914.93, writes: 0.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[   9s] threads: 64, tps: 0.00, reads: 82619.06, writes: 0.00, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[  10s] threads: 64, tps: 0.00, reads: 79258.02, writes: 0.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[  11s] threads: 64, tps: 0.00, reads: 90030.95, writes: 0.00, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[  12s] threads: 64, tps: 0.00, reads: 98283.09, writes: 0.00, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[  13s] threads: 64, tps: 0.00, reads: 96042.98, writes: 0.00, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[  14s] threads: 64, tps: 0.00, reads: 88744.12, writes: 0.00, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[  15s] threads: 64, tps: 0.00, reads: 80763.93, writes: 0.00, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[  16s] threads: 64, tps: 0.00, reads: 92836.08, writes: 0.00, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[  17s] threads: 64, tps: 0.00, reads: 95429.83, writes: 0.00, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[  18s] threads: 64, tps: 0.00, reads: 101388.07, writes: 0.00, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[  19s] threads: 64, tps: 0.00, reads: 95223.03, writes: 0.00, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[  20s] threads: 64, tps: 0.00, reads: 94027.94, writes: 0.00, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[  21s] threads: 64, tps: 0.00, reads: 83881.84, writes: 0.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[  22s] threads: 64, tps: 0.00, reads: 94658.34, writes: 0.00, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[  23s] threads: 64, tps: 0.00, reads: 89096.91, writes: 0.00, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[  24s] threads: 64, tps: 0.00, reads: 93260.11, writes: 0.00, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[  25s] threads: 64, tps: 0.00, reads: 87220.97, writes: 0.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[  26s] threads: 64, tps: 0.00, reads: 94774.91, writes: 0.00, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[  27s] threads: 64, tps: 0.00, reads: 95286.11, writes: 0.00, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[  28s] threads: 64, tps: 0.00, reads: 104192.88, writes: 0.00, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[  29s] threads: 64, tps: 0.00, reads: 91742.07, writes: 0.00, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[  30s] threads: 64, tps: 0.00, reads: 94276.94, writes: 0.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[  31s] threads: 64, tps: 0.00, reads: 102681.19, writes: 0.00, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[  32s] threads: 64, tps: 0.00, reads: 117429.84, writes: 0.00, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[  33s] threads: 64, tps: 0.00, reads: 116078.44, writes: 0.00, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[  34s] threads: 64, tps: 0.00, reads: 114309.69, writes: 0.00, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[  35s] threads: 64, tps: 0.00, reads: 106905.57, writes: 0.00, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[  36s] threads: 64, tps: 0.00, reads: 109881.80, writes: 0.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[  37s] threads: 64, tps: 0.00, reads: 118583.72, writes: 0.00, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[  38s] threads: 64, tps: 0.00, reads: 118897.75, writes: 0.00, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[  39s] threads: 64, tps: 0.00, reads: 120276.21, writes: 0.00, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[  40s] threads: 64, tps: 0.00, reads: 113603.02, writes: 0.00, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[  41s] threads: 64, tps: 0.00, reads: 113621.79, writes: 0.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[  42s] threads: 64, tps: 0.00, reads: 116876.22, writes: 0.00, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[  43s] threads: 64, tps: 0.00, reads: 120728.82, writes: 0.00, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[  44s] threads: 64, tps: 0.00, reads: 121170.16, writes: 0.00, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[  45s] threads: 64, tps: 0.00, reads: 123766.47, writes: 0.00, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[  46s] threads: 64, tps: 0.00, reads: 104857.00, writes: 0.00, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[  47s] threads: 64, tps: 0.00, reads: 118870.37, writes: 0.00, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[  48s] threads: 64, tps: 0.00, reads: 114791.61, writes: 0.00, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[  49s] threads: 64, tps: 0.00, reads: 120501.39, writes: 0.00, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[  50s] threads: 64, tps: 0.00, reads: 125431.14, writes: 0.00, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[  51s] threads: 64, tps: 0.00, reads: 125847.97, writes: 0.00, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[  52s] threads: 64, tps: 0.00, reads: 127643.86, writes: 0.00, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[  53s] threads: 64, tps: 0.00, reads: 125742.21, writes: 0.00, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[  54s] threads: 64, tps: 0.00, reads: 121259.81, writes: 0.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[  55s] threads: 64, tps: 0.00, reads: 120182.09, writes: 0.00, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[  56s] threads: 64, tps: 0.00, reads: 123825.09, writes: 0.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[  57s] threads: 64, tps: 0.00, reads: 128580.13, writes: 0.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[  58s] threads: 64, tps: 0.00, reads: 128368.95, writes: 0.00, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[  59s] threads: 64, tps: 0.00, reads: 129559.94, writes: 0.00, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[  60s] threads: 64, tps: 0.00, reads: 129541.90, writes: 0.00, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[  61s] threads: 64, tps: 0.00, reads: 127634.22, writes: 0.00, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[  62s] threads: 64, tps: 0.00, reads: 123658.31, writes: 0.00, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[  63s] threads: 64, tps: 0.00, reads: 121488.47, writes: 0.00, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[  64s] threads: 64, tps: 0.00, reads: 129654.63, writes: 0.00, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[  65s] threads: 64, tps: 0.00, reads: 131410.44, writes: 0.00, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[  66s] threads: 64, tps: 0.00, reads: 132994.18, writes: 0.00, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[  67s] threads: 64, tps: 0.00, reads: 131630.49, writes: 0.00, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[  68s] threads: 64, tps: 0.00, reads: 132882.54, writes: 0.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[  69s] threads: 64, tps: 0.00, reads: 126710.93, writes: 0.00, response time: 1.70ms (95%), errors: 0.00, reconnects:  0.00
[  70s] threads: 64, tps: 0.00, reads: 125331.73, writes: 0.00, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[  71s] threads: 64, tps: 0.00, reads: 131205.43, writes: 0.00, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[  72s] threads: 64, tps: 0.00, reads: 134089.16, writes: 0.00, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[  73s] threads: 64, tps: 0.00, reads: 133263.96, writes: 0.00, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[  74s] threads: 64, tps: 0.00, reads: 136226.25, writes: 0.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[  75s] threads: 64, tps: 0.00, reads: 135918.00, writes: 0.00, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[  76s] threads: 64, tps: 0.00, reads: 132957.84, writes: 0.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[  77s] threads: 64, tps: 0.00, reads: 129809.02, writes: 0.00, response time: 1.61ms (95%), errors: 0.00, reconnects:  0.00
[  78s] threads: 64, tps: 0.00, reads: 129871.86, writes: 0.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[  79s] threads: 64, tps: 0.00, reads: 135022.12, writes: 0.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[  80s] threads: 64, tps: 0.00, reads: 137137.86, writes: 0.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[  81s] threads: 64, tps: 0.00, reads: 137870.28, writes: 0.00, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[  82s] threads: 64, tps: 0.00, reads: 138950.63, writes: 0.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[  83s] threads: 64, tps: 0.00, reads: 137889.62, writes: 0.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[  84s] threads: 64, tps: 0.00, reads: 135486.50, writes: 0.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[  85s] threads: 64, tps: 0.00, reads: 133980.92, writes: 0.00, response time: 1.59ms (95%), errors: 0.00, reconnects:  0.00
[  86s] threads: 64, tps: 0.00, reads: 134876.19, writes: 0.00, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[  87s] threads: 64, tps: 0.00, reads: 137504.99, writes: 0.00, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[  88s] threads: 64, tps: 0.00, reads: 140422.89, writes: 0.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[  89s] threads: 64, tps: 0.00, reads: 141376.36, writes: 0.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[  90s] threads: 64, tps: 0.00, reads: 140879.07, writes: 0.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[  91s] threads: 64, tps: 0.00, reads: 142585.90, writes: 0.00, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[  92s] threads: 64, tps: 0.00, reads: 142483.70, writes: 0.00, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[  93s] threads: 64, tps: 0.00, reads: 137807.11, writes: 0.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[  94s] threads: 64, tps: 0.00, reads: 138064.20, writes: 0.00, response time: 1.58ms (95%), errors: 0.00, reconnects:  0.00
[  95s] threads: 64, tps: 0.00, reads: 138596.20, writes: 0.00, response time: 1.63ms (95%), errors: 0.00, reconnects:  0.00
[  96s] threads: 64, tps: 0.00, reads: 142279.54, writes: 0.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[  97s] threads: 64, tps: 0.00, reads: 145198.04, writes: 0.00, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[  98s] threads: 64, tps: 0.00, reads: 144843.82, writes: 0.00, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[  99s] threads: 64, tps: 0.00, reads: 144492.18, writes: 0.00, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 100s] threads: 64, tps: 0.00, reads: 144563.70, writes: 0.00, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 101s] threads: 64, tps: 0.00, reads: 145575.11, writes: 0.00, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 102s] threads: 64, tps: 0.00, reads: 144345.39, writes: 0.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 103s] threads: 64, tps: 0.00, reads: 140049.78, writes: 0.00, response time: 1.58ms (95%), errors: 0.00, reconnects:  0.00
[ 104s] threads: 64, tps: 0.00, reads: 139932.27, writes: 0.00, response time: 1.54ms (95%), errors: 0.00, reconnects:  0.00
[ 105s] threads: 64, tps: 0.00, reads: 144696.58, writes: 0.00, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[ 106s] threads: 64, tps: 0.00, reads: 145535.63, writes: 0.00, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 107s] threads: 64, tps: 0.00, reads: 148309.42, writes: 0.00, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 108s] threads: 64, tps: 0.00, reads: 147486.85, writes: 0.00, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 109s] threads: 64, tps: 0.00, reads: 147748.20, writes: 0.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 110s] threads: 64, tps: 0.00, reads: 147069.20, writes: 0.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 111s] threads: 64, tps: 0.00, reads: 148458.79, writes: 0.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 112s] threads: 64, tps: 0.00, reads: 149129.96, writes: 0.00, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 113s] threads: 64, tps: 0.00, reads: 144514.88, writes: 0.00, response time: 1.50ms (95%), errors: 0.00, reconnects:  0.00
[ 114s] threads: 64, tps: 0.00, reads: 144526.20, writes: 0.00, response time: 1.50ms (95%), errors: 0.00, reconnects:  0.00
[ 115s] threads: 64, tps: 0.00, reads: 146999.29, writes: 0.00, response time: 1.66ms (95%), errors: 0.00, reconnects:  0.00
[ 116s] threads: 64, tps: 0.00, reads: 150723.61, writes: 0.00, response time: 1.70ms (95%), errors: 0.00, reconnects:  0.00
[ 117s] threads: 64, tps: 0.00, reads: 148936.91, writes: 0.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 118s] threads: 64, tps: 0.00, reads: 151336.88, writes: 0.00, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 119s] threads: 64, tps: 0.00, reads: 151306.92, writes: 0.00, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 120s] threads: 64, tps: 0.00, reads: 152959.06, writes: 0.00, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[ 121s] threads: 64, tps: 0.00, reads: 152824.09, writes: 0.00, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 122s] threads: 64, tps: 0.00, reads: 153232.10, writes: 0.00, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 123s] threads: 64, tps: 0.00, reads: 151470.04, writes: 0.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 124s] threads: 64, tps: 0.00, reads: 151475.84, writes: 0.00, response time: 1.49ms (95%), errors: 0.00, reconnects:  0.00
[ 125s] threads: 64, tps: 0.00, reads: 150138.94, writes: 0.00, response time: 1.39ms (95%), errors: 0.00, reconnects:  0.00
[ 126s] threads: 64, tps: 0.00, reads: 149607.11, writes: 0.00, response time: 1.54ms (95%), errors: 0.00, reconnects:  0.00
[ 127s] threads: 64, tps: 0.00, reads: 153893.11, writes: 0.00, response time: 1.56ms (95%), errors: 0.00, reconnects:  0.00
[ 128s] threads: 64, tps: 0.00, reads: 152381.90, writes: 0.00, response time: 1.62ms (95%), errors: 0.00, reconnects:  0.00
[ 129s] threads: 64, tps: 0.00, reads: 154550.55, writes: 0.00, response time: 1.62ms (95%), errors: 0.00, reconnects:  0.00
[ 130s] threads: 64, tps: 0.00, reads: 155216.15, writes: 0.00, response time: 1.52ms (95%), errors: 0.00, reconnects:  0.00
[ 131s] threads: 64, tps: 0.00, reads: 156060.27, writes: 0.00, response time: 1.51ms (95%), errors: 0.00, reconnects:  0.00
[ 132s] threads: 64, tps: 0.00, reads: 155283.07, writes: 0.00, response time: 1.54ms (95%), errors: 0.00, reconnects:  0.00
[ 133s] threads: 64, tps: 0.00, reads: 156048.09, writes: 0.00, response time: 1.51ms (95%), errors: 0.00, reconnects:  0.00
[ 134s] threads: 64, tps: 0.00, reads: 153174.97, writes: 0.00, response time: 1.34ms (95%), errors: 0.00, reconnects:  0.00
[ 135s] threads: 64, tps: 0.00, reads: 151683.99, writes: 0.00, response time: 1.32ms (95%), errors: 0.00, reconnects:  0.00
[ 136s] threads: 64, tps: 0.00, reads: 154308.91, writes: 0.00, response time: 1.48ms (95%), errors: 0.00, reconnects:  0.00
[ 137s] threads: 64, tps: 0.00, reads: 155423.95, writes: 0.00, response time: 1.50ms (95%), errors: 0.00, reconnects:  0.00
[ 138s] threads: 64, tps: 0.00, reads: 157177.01, writes: 0.00, response time: 1.48ms (95%), errors: 0.00, reconnects:  0.00
[ 139s] threads: 64, tps: 0.00, reads: 155879.34, writes: 0.00, response time: 1.58ms (95%), errors: 0.00, reconnects:  0.00
[ 140s] threads: 64, tps: 0.00, reads: 158744.65, writes: 0.00, response time: 1.40ms (95%), errors: 0.00, reconnects:  0.00
[ 141s] threads: 64, tps: 0.00, reads: 158010.73, writes: 0.00, response time: 1.41ms (95%), errors: 0.00, reconnects:  0.00
[ 142s] threads: 64, tps: 0.00, reads: 157103.13, writes: 0.00, response time: 1.49ms (95%), errors: 0.00, reconnects:  0.00
[ 143s] threads: 64, tps: 0.00, reads: 159777.35, writes: 0.00, response time: 1.44ms (95%), errors: 0.00, reconnects:  0.00
[ 144s] threads: 64, tps: 0.00, reads: 157151.69, writes: 0.00, response time: 1.42ms (95%), errors: 0.00, reconnects:  0.00
[ 145s] threads: 64, tps: 0.00, reads: 158261.04, writes: 0.00, response time: 1.18ms (95%), errors: 0.00, reconnects:  0.00
[ 146s] threads: 64, tps: 0.00, reads: 154272.63, writes: 0.00, response time: 1.35ms (95%), errors: 0.00, reconnects:  0.00
[ 147s] threads: 64, tps: 0.00, reads: 158794.20, writes: 0.00, response time: 1.37ms (95%), errors: 0.00, reconnects:  0.00
[ 148s] threads: 64, tps: 0.00, reads: 160309.33, writes: 0.00, response time: 1.33ms (95%), errors: 0.00, reconnects:  0.00
[ 149s] threads: 64, tps: 0.00, reads: 162126.66, writes: 0.00, response time: 1.24ms (95%), errors: 0.00, reconnects:  0.00
[ 150s] threads: 64, tps: 0.00, reads: 159899.09, writes: 0.00, response time: 1.31ms (95%), errors: 0.00, reconnects:  0.00
[ 151s] threads: 64, tps: 0.00, reads: 160457.87, writes: 0.00, response time: 1.32ms (95%), errors: 0.00, reconnects:  0.00
[ 152s] threads: 64, tps: 0.00, reads: 161865.32, writes: 0.00, response time: 1.18ms (95%), errors: 0.00, reconnects:  0.00
[ 153s] threads: 64, tps: 0.00, reads: 163076.57, writes: 0.00, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[ 154s] threads: 64, tps: 0.00, reads: 163139.09, writes: 0.00, response time: 1.08ms (95%), errors: 0.00, reconnects:  0.00
[ 155s] threads: 64, tps: 0.00, reads: 162380.08, writes: 0.00, response time: 1.11ms (95%), errors: 0.00, reconnects:  0.00
[ 156s] threads: 64, tps: 0.00, reads: 164215.98, writes: 0.00, response time: 1.04ms (95%), errors: 0.00, reconnects:  0.00
[ 157s] threads: 64, tps: 0.00, reads: 159194.03, writes: 0.00, response time: 1.12ms (95%), errors: 0.00, reconnects:  0.00
[ 158s] threads: 64, tps: 0.00, reads: 159111.00, writes: 0.00, response time: 1.15ms (95%), errors: 0.00, reconnects:  0.00
[ 159s] threads: 64, tps: 0.00, reads: 161318.95, writes: 0.00, response time: 1.20ms (95%), errors: 0.00, reconnects:  0.00
[ 160s] threads: 64, tps: 0.00, reads: 164686.16, writes: 0.00, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[ 161s] threads: 64, tps: 0.00, reads: 163913.93, writes: 0.00, response time: 1.00ms (95%), errors: 0.00, reconnects:  0.00
[ 162s] threads: 64, tps: 0.00, reads: 163947.93, writes: 0.00, response time: 1.05ms (95%), errors: 0.00, reconnects:  0.00
[ 163s] threads: 64, tps: 0.00, reads: 165091.11, writes: 0.00, response time: 0.94ms (95%), errors: 0.00, reconnects:  0.00
[ 164s] threads: 64, tps: 0.00, reads: 167351.86, writes: 0.00, response time: 0.82ms (95%), errors: 0.00, reconnects:  0.00
[ 165s] threads: 64, tps: 0.00, reads: 165592.35, writes: 0.00, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[ 166s] threads: 64, tps: 0.00, reads: 167474.85, writes: 0.00, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[ 167s] threads: 64, tps: 0.00, reads: 163824.29, writes: 0.00, response time: 0.94ms (95%), errors: 0.00, reconnects:  0.00
[ 168s] threads: 64, tps: 0.00, reads: 165307.59, writes: 0.00, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[ 169s] threads: 64, tps: 0.00, reads: 163788.16, writes: 0.00, response time: 0.89ms (95%), errors: 0.00, reconnects:  0.00
[ 170s] threads: 64, tps: 0.00, reads: 162284.90, writes: 0.00, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[ 171s] threads: 64, tps: 0.00, reads: 161807.28, writes: 0.00, response time: 1.01ms (95%), errors: 0.00, reconnects:  0.00
[ 172s] threads: 64, tps: 0.00, reads: 163108.94, writes: 0.00, response time: 1.03ms (95%), errors: 0.00, reconnects:  0.00
[ 173s] threads: 64, tps: 0.00, reads: 164694.91, writes: 0.00, response time: 0.98ms (95%), errors: 0.00, reconnects:  0.00
[ 174s] threads: 64, tps: 0.00, reads: 163556.14, writes: 0.00, response time: 1.02ms (95%), errors: 0.00, reconnects:  0.00
[ 175s] threads: 64, tps: 0.00, reads: 165831.83, writes: 0.00, response time: 0.84ms (95%), errors: 0.00, reconnects:  0.00
[ 176s] threads: 64, tps: 0.00, reads: 166704.48, writes: 0.00, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[ 177s] threads: 64, tps: 0.00, reads: 166821.03, writes: 0.00, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[ 178s] threads: 64, tps: 0.00, reads: 165551.65, writes: 0.00, response time: 0.90ms (95%), errors: 0.00, reconnects:  0.00
[ 179s] threads: 64, tps: 0.00, reads: 165932.91, writes: 0.00, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[ 180s] threads: 64, tps: 0.00, reads: 163235.06, writes: 0.00, response time: 0.91ms (95%), errors: 0.00, reconnects:  0.00
[ 181s] threads: 64, tps: 0.00, reads: 166156.86, writes: 0.00, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[ 182s] threads: 64, tps: 0.00, reads: 167269.08, writes: 0.00, response time: 0.78ms (95%), errors: 0.00, reconnects:  0.00
[ 183s] threads: 64, tps: 0.00, reads: 168969.99, writes: 0.00, response time: 0.61ms (95%), errors: 0.00, reconnects:  0.00
[ 184s] threads: 64, tps: 0.00, reads: 165839.82, writes: 0.00, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[ 185s] threads: 64, tps: 0.00, reads: 167799.96, writes: 0.00, response time: 0.66ms (95%), errors: 0.00, reconnects:  0.00
[ 186s] threads: 64, tps: 0.00, reads: 166320.04, writes: 0.00, response time: 0.77ms (95%), errors: 0.00, reconnects:  0.00
[ 187s] threads: 64, tps: 0.00, reads: 164280.02, writes: 0.00, response time: 0.87ms (95%), errors: 0.00, reconnects:  0.00
[ 188s] threads: 64, tps: 0.00, reads: 165833.11, writes: 0.00, response time: 0.83ms (95%), errors: 0.00, reconnects:  0.00
[ 189s] threads: 64, tps: 0.00, reads: 167597.86, writes: 0.00, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[ 190s] threads: 64, tps: 0.00, reads: 166795.82, writes: 0.00, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[ 191s] threads: 64, tps: 0.00, reads: 167341.09, writes: 0.00, response time: 0.75ms (95%), errors: 0.00, reconnects:  0.00
[ 192s] threads: 64, tps: 0.00, reads: 168588.95, writes: 0.00, response time: 0.65ms (95%), errors: 0.00, reconnects:  0.00
[ 193s] threads: 64, tps: 0.00, reads: 166982.34, writes: 0.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[ 194s] threads: 64, tps: 0.00, reads: 167706.56, writes: 0.00, response time: 0.67ms (95%), errors: 0.00, reconnects:  0.00
[ 195s] threads: 64, tps: 0.00, reads: 167583.46, writes: 0.00, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[ 196s] threads: 64, tps: 0.00, reads: 168491.70, writes: 0.00, response time: 0.64ms (95%), errors: 0.00, reconnects:  0.00
[ 197s] threads: 64, tps: 0.00, reads: 166655.07, writes: 0.00, response time: 0.74ms (95%), errors: 0.00, reconnects:  0.00
[ 198s] threads: 64, tps: 0.00, reads: 167525.94, writes: 0.00, response time: 0.58ms (95%), errors: 0.00, reconnects:  0.00
[ 199s] threads: 64, tps: 0.00, reads: 164525.75, writes: 0.00, response time: 0.88ms (95%), errors: 0.00, reconnects:  0.00
[ 200s] threads: 64, tps: 0.00, reads: 168376.36, writes: 0.00, response time: 0.64ms (95%), errors: 0.00, reconnects:  0.00
[ 201s] threads: 64, tps: 0.00, reads: 168516.92, writes: 0.00, response time: 0.69ms (95%), errors: 0.00, reconnects:  0.00
[ 202s] threads: 64, tps: 0.00, reads: 167096.98, writes: 0.00, response time: 0.71ms (95%), errors: 0.00, reconnects:  0.00
[ 203s] threads: 64, tps: 0.00, reads: 166827.35, writes: 0.00, response time: 0.67ms (95%), errors: 0.00, reconnects:  0.00
[ 204s] threads: 64, tps: 0.00, reads: 165531.75, writes: 0.00, response time: 0.76ms (95%), errors: 0.00, reconnects:  0.00
[ 205s] threads: 64, tps: 0.00, reads: 168393.13, writes: 0.00, response time: 0.70ms (95%), errors: 0.00, reconnects:  0.00
[ 206s] threads: 64, tps: 0.00, reads: 164310.27, writes: 0.00, response time: 0.81ms (95%), errors: 0.00, reconnects:  0.00
[ 207s] threads: 64, tps: 0.00, reads: 167076.65, writes: 0.00, response time: 0.72ms (95%), errors: 0.00, reconnects:  0.00
[ 208s] threads: 64, tps: 0.00, reads: 168476.40, writes: 0.00, response time: 0.63ms (95%), errors: 0.00, reconnects:  0.00
[ 209s] threads: 64, tps: 0.00, reads: 168617.86, writes: 0.00, response time: 0.62ms (95%), errors: 0.00, reconnects:  0.00
[ 210s] threads: 64, tps: 0.00, reads: 169439.94, writes: 0.00, response time: 0.66ms (95%), errors: 0.00, reconnects:  0.00
[ 211s] threads: 64, tps: 0.00, reads: 167742.24, writes: 0.00, response time: 0.64ms (95%), errors: 0.00, reconnects:  0.00
[ 212s] threads: 64, tps: 0.00, reads: 169991.81, writes: 0.00, response time: 0.61ms (95%), errors: 0.00, reconnects:  0.00
[ 213s] threads: 64, tps: 0.00, reads: 167632.04, writes: 0.00, response time: 0.61ms (95%), errors: 0.00, reconnects:  0.00
[ 214s] threads: 64, tps: 0.00, reads: 168499.08, writes: 0.00, response time: 0.68ms (95%), errors: 0.00, reconnects:  0.00
[ 215s] threads: 64, tps: 0.00, reads: 168972.92, writes: 0.00, response time: 0.61ms (95%), errors: 0.00, reconnects:  0.00
[ 216s] threads: 64, tps: 0.00, reads: 169272.52, writes: 0.00, response time: 0.58ms (95%), errors: 0.00, reconnects:  0.00
[ 217s] threads: 64, tps: 0.00, reads: 168688.63, writes: 0.00, response time: 0.59ms (95%), errors: 0.00, reconnects:  0.00
[ 218s] threads: 64, tps: 0.00, reads: 169389.78, writes: 0.00, response time: 0.59ms (95%), errors: 0.00, reconnects:  0.00
[ 219s] threads: 64, tps: 0.00, reads: 168883.87, writes: 0.00, response time: 0.60ms (95%), errors: 0.00, reconnects:  0.00
[ 220s] threads: 64, tps: 0.00, reads: 169127.63, writes: 0.00, response time: 0.64ms (95%), errors: 0.00, reconnects:  0.00
[ 221s] threads: 64, tps: 0.00, reads: 168149.63, writes: 0.00, response time: 0.59ms (95%), errors: 0.00, reconnects:  0.00
[ 222s] threads: 64, tps: 0.00, reads: 167870.86, writes: 0.00, response time: 0.58ms (95%), errors: 0.00, reconnects:  0.00
[ 223s] threads: 64, tps: 0.00, reads: 168292.62, writes: 0.00, response time: 0.61ms (95%), errors: 0.00, reconnects:  0.00
[ 224s] threads: 64, tps: 0.00, reads: 166565.56, writes: 0.00, response time: 0.62ms (95%), errors: 0.00, reconnects:  0.00
[ 225s] threads: 64, tps: 0.00, reads: 169013.93, writes: 0.00, response time: 0.63ms (95%), errors: 0.00, reconnects:  0.00
[ 226s] threads: 64, tps: 0.00, reads: 169422.00, writes: 0.00, response time: 0.65ms (95%), errors: 0.00, reconnects:  0.00
[ 227s] threads: 64, tps: 0.00, reads: 168584.08, writes: 0.00, response time: 0.60ms (95%), errors: 0.00, reconnects:  0.00
[ 228s] threads: 64, tps: 0.00, reads: 167904.80, writes: 0.00, response time: 0.65ms (95%), errors: 0.00, reconnects:  0.00
[ 229s] threads: 64, tps: 0.00, reads: 168167.02, writes: 0.00, response time: 0.60ms (95%), errors: 0.00, reconnects:  0.00
[ 230s] threads: 64, tps: 0.00, reads: 169606.17, writes: 0.00, response time: 0.55ms (95%), errors: 0.00, reconnects:  0.00
[ 231s] threads: 64, tps: 0.00, reads: 167241.01, writes: 0.00, response time: 0.64ms (95%), errors: 0.00, reconnects:  0.00
[ 232s] threads: 64, tps: 0.00, reads: 168636.97, writes: 0.00, response time: 0.58ms (95%), errors: 0.00, reconnects:  0.00
[ 233s] threads: 64, tps: 0.00, reads: 169686.82, writes: 0.00, response time: 0.56ms (95%), errors: 0.00, reconnects:  0.00
[ 234s] threads: 64, tps: 0.00, reads: 169760.04, writes: 0.00, response time: 0.58ms (95%), errors: 0.00, reconnects:  0.00
[ 235s] threads: 64, tps: 0.00, reads: 170469.99, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 236s] threads: 64, tps: 0.00, reads: 169939.35, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 237s] threads: 64, tps: 0.00, reads: 170180.92, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 238s] threads: 64, tps: 0.00, reads: 170448.94, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 239s] threads: 64, tps: 0.00, reads: 169771.91, writes: 0.00, response time: 0.57ms (95%), errors: 0.00, reconnects:  0.00
[ 240s] threads: 64, tps: 0.00, reads: 168973.08, writes: 0.00, response time: 0.57ms (95%), errors: 0.00, reconnects:  0.00
[ 241s] threads: 64, tps: 0.00, reads: 169181.95, writes: 0.00, response time: 0.55ms (95%), errors: 0.00, reconnects:  0.00
[ 242s] threads: 64, tps: 0.00, reads: 168826.85, writes: 0.00, response time: 0.56ms (95%), errors: 0.00, reconnects:  0.00
[ 243s] threads: 64, tps: 0.00, reads: 167698.12, writes: 0.00, response time: 0.61ms (95%), errors: 0.00, reconnects:  0.00
[ 244s] threads: 64, tps: 0.00, reads: 165690.18, writes: 0.00, response time: 0.64ms (95%), errors: 0.00, reconnects:  0.00
[ 245s] threads: 64, tps: 0.00, reads: 167470.67, writes: 0.00, response time: 0.60ms (95%), errors: 0.00, reconnects:  0.00
[ 246s] threads: 64, tps: 0.00, reads: 169277.08, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 247s] threads: 64, tps: 0.00, reads: 170139.20, writes: 0.00, response time: 0.55ms (95%), errors: 0.00, reconnects:  0.00
[ 248s] threads: 64, tps: 0.00, reads: 169516.71, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 249s] threads: 64, tps: 0.00, reads: 168544.65, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 250s] threads: 64, tps: 0.00, reads: 169420.58, writes: 0.00, response time: 0.55ms (95%), errors: 0.00, reconnects:  0.00
[ 251s] threads: 64, tps: 0.00, reads: 169525.86, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 252s] threads: 64, tps: 0.00, reads: 170496.86, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 253s] threads: 64, tps: 0.00, reads: 171412.21, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 254s] threads: 64, tps: 0.00, reads: 168773.04, writes: 0.00, response time: 0.57ms (95%), errors: 0.00, reconnects:  0.00
[ 255s] threads: 64, tps: 0.00, reads: 169311.11, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 256s] threads: 64, tps: 0.00, reads: 170037.86, writes: 0.00, response time: 0.56ms (95%), errors: 0.00, reconnects:  0.00
[ 257s] threads: 64, tps: 0.00, reads: 170977.15, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 258s] threads: 64, tps: 0.00, reads: 168334.77, writes: 0.00, response time: 0.57ms (95%), errors: 0.00, reconnects:  0.00
[ 259s] threads: 64, tps: 0.00, reads: 168670.21, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 260s] threads: 64, tps: 0.00, reads: 170210.95, writes: 0.00, response time: 0.53ms (95%), errors: 0.00, reconnects:  0.00
[ 261s] threads: 64, tps: 0.00, reads: 171335.10, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 262s] threads: 64, tps: 0.00, reads: 169546.94, writes: 0.00, response time: 0.52ms (95%), errors: 0.00, reconnects:  0.00
[ 263s] threads: 64, tps: 0.00, reads: 169732.89, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 264s] threads: 64, tps: 0.00, reads: 168329.24, writes: 0.00, response time: 0.52ms (95%), errors: 0.00, reconnects:  0.00
[ 265s] threads: 64, tps: 0.00, reads: 169341.83, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 266s] threads: 64, tps: 0.00, reads: 170111.98, writes: 0.00, response time: 0.55ms (95%), errors: 0.00, reconnects:  0.00
[ 267s] threads: 64, tps: 0.00, reads: 168098.21, writes: 0.00, response time: 0.59ms (95%), errors: 0.00, reconnects:  0.00
[ 268s] threads: 64, tps: 0.00, reads: 168490.93, writes: 0.00, response time: 0.57ms (95%), errors: 0.00, reconnects:  0.00
[ 269s] threads: 64, tps: 0.00, reads: 168899.09, writes: 0.00, response time: 0.55ms (95%), errors: 0.00, reconnects:  0.00
[ 270s] threads: 64, tps: 0.00, reads: 169376.61, writes: 0.00, response time: 0.55ms (95%), errors: 0.00, reconnects:  0.00
[ 271s] threads: 64, tps: 0.00, reads: 169876.84, writes: 0.00, response time: 0.59ms (95%), errors: 0.00, reconnects:  0.00
[ 272s] threads: 64, tps: 0.00, reads: 170427.24, writes: 0.00, response time: 0.52ms (95%), errors: 0.00, reconnects:  0.00
[ 273s] threads: 64, tps: 0.00, reads: 169798.06, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 274s] threads: 64, tps: 0.00, reads: 170445.93, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 275s] threads: 64, tps: 0.00, reads: 171064.15, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 276s] threads: 64, tps: 0.00, reads: 170570.06, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 277s] threads: 64, tps: 0.00, reads: 171657.07, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 278s] threads: 64, tps: 0.00, reads: 169677.65, writes: 0.00, response time: 0.53ms (95%), errors: 0.00, reconnects:  0.00
[ 279s] threads: 64, tps: 0.00, reads: 169450.31, writes: 0.00, response time: 0.56ms (95%), errors: 0.00, reconnects:  0.00
[ 280s] threads: 64, tps: 0.00, reads: 170054.91, writes: 0.00, response time: 0.52ms (95%), errors: 0.00, reconnects:  0.00
[ 281s] threads: 64, tps: 0.00, reads: 170395.85, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 282s] threads: 64, tps: 0.00, reads: 170733.08, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 283s] threads: 64, tps: 0.00, reads: 171842.92, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 284s] threads: 64, tps: 0.00, reads: 170529.15, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 285s] threads: 64, tps: 0.00, reads: 170728.96, writes: 0.00, response time: 0.52ms (95%), errors: 0.00, reconnects:  0.00
[ 286s] threads: 64, tps: 0.00, reads: 171808.91, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 287s] threads: 64, tps: 0.00, reads: 170455.48, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 288s] threads: 64, tps: 0.00, reads: 171899.67, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 289s] threads: 64, tps: 0.00, reads: 170098.92, writes: 0.00, response time: 0.53ms (95%), errors: 0.00, reconnects:  0.00
[ 290s] threads: 64, tps: 0.00, reads: 170758.00, writes: 0.00, response time: 0.52ms (95%), errors: 0.00, reconnects:  0.00
[ 291s] threads: 64, tps: 0.00, reads: 170323.05, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 292s] threads: 64, tps: 0.00, reads: 170327.37, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 293s] threads: 64, tps: 0.00, reads: 168957.58, writes: 0.00, response time: 0.53ms (95%), errors: 0.00, reconnects:  0.00
[ 294s] threads: 64, tps: 0.00, reads: 168171.53, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 295s] threads: 64, tps: 0.00, reads: 170370.47, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 296s] threads: 64, tps: 0.00, reads: 168097.96, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 297s] threads: 64, tps: 0.00, reads: 169099.45, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 298s] threads: 64, tps: 0.00, reads: 171858.61, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 299s] threads: 64, tps: 0.00, reads: 171392.72, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 300s] threads: 64, tps: 0.00, reads: 171490.74, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 301s] threads: 64, tps: 0.00, reads: 170030.49, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 302s] threads: 64, tps: 0.00, reads: 171624.99, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 303s] threads: 64, tps: 0.00, reads: 172070.59, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 304s] threads: 64, tps: 0.00, reads: 169679.45, writes: 0.00, response time: 0.53ms (95%), errors: 0.00, reconnects:  0.00
[ 305s] threads: 64, tps: 0.00, reads: 171449.86, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 306s] threads: 64, tps: 0.00, reads: 170358.90, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 307s] threads: 64, tps: 0.00, reads: 171899.27, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 308s] threads: 64, tps: 0.00, reads: 170288.66, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 309s] threads: 64, tps: 0.00, reads: 171325.62, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 310s] threads: 64, tps: 0.00, reads: 170896.62, writes: 0.00, response time: 0.53ms (95%), errors: 0.00, reconnects:  0.00
[ 311s] threads: 64, tps: 0.00, reads: 170520.97, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 312s] threads: 64, tps: 0.00, reads: 171310.36, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 313s] threads: 64, tps: 0.00, reads: 169173.89, writes: 0.00, response time: 0.53ms (95%), errors: 0.00, reconnects:  0.00
[ 314s] threads: 64, tps: 0.00, reads: 170156.93, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 315s] threads: 64, tps: 0.00, reads: 171269.79, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 316s] threads: 64, tps: 0.00, reads: 170532.16, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 317s] threads: 64, tps: 0.00, reads: 169395.07, writes: 0.00, response time: 0.53ms (95%), errors: 0.00, reconnects:  0.00
[ 318s] threads: 64, tps: 0.00, reads: 170292.88, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 319s] threads: 64, tps: 0.00, reads: 169249.06, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 320s] threads: 64, tps: 0.00, reads: 166384.13, writes: 0.00, response time: 0.56ms (95%), errors: 0.00, reconnects:  0.00
[ 321s] threads: 64, tps: 0.00, reads: 170330.77, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 322s] threads: 64, tps: 0.00, reads: 169776.77, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 323s] threads: 64, tps: 0.00, reads: 169086.45, writes: 0.00, response time: 0.55ms (95%), errors: 0.00, reconnects:  0.00
[ 324s] threads: 64, tps: 0.00, reads: 168697.10, writes: 0.00, response time: 0.54ms (95%), errors: 0.00, reconnects:  0.00
[ 325s] threads: 64, tps: 0.00, reads: 170880.51, writes: 0.00, response time: 0.52ms (95%), errors: 0.00, reconnects:  0.00
[ 326s] threads: 64, tps: 0.00, reads: 171837.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 327s] threads: 64, tps: 0.00, reads: 171307.85, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 328s] threads: 64, tps: 0.00, reads: 171900.05, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 329s] threads: 64, tps: 0.00, reads: 171816.75, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 330s] threads: 64, tps: 0.00, reads: 172241.19, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 331s] threads: 64, tps: 0.00, reads: 171742.98, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 332s] threads: 64, tps: 0.00, reads: 170601.36, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 333s] threads: 64, tps: 0.00, reads: 170328.97, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 334s] threads: 64, tps: 0.00, reads: 170895.65, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 335s] threads: 64, tps: 0.00, reads: 171256.90, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 336s] threads: 64, tps: 0.00, reads: 171342.22, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 337s] threads: 64, tps: 0.00, reads: 172136.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 338s] threads: 64, tps: 0.00, reads: 171857.72, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 339s] threads: 64, tps: 0.00, reads: 171122.94, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 340s] threads: 64, tps: 0.00, reads: 171164.82, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 341s] threads: 64, tps: 0.00, reads: 170941.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 342s] threads: 64, tps: 0.00, reads: 170533.20, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 343s] threads: 64, tps: 0.00, reads: 170253.92, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 344s] threads: 64, tps: 0.00, reads: 172145.99, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 345s] threads: 64, tps: 0.00, reads: 170622.84, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 346s] threads: 64, tps: 0.00, reads: 171869.86, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 347s] threads: 64, tps: 0.00, reads: 171489.07, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 348s] threads: 64, tps: 0.00, reads: 170759.01, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 349s] threads: 64, tps: 0.00, reads: 167644.98, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 350s] threads: 64, tps: 0.00, reads: 169860.07, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 351s] threads: 64, tps: 0.00, reads: 170434.13, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 352s] threads: 64, tps: 0.00, reads: 171574.95, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 353s] threads: 64, tps: 0.00, reads: 170940.10, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 354s] threads: 64, tps: 0.00, reads: 170205.84, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 355s] threads: 64, tps: 0.00, reads: 171237.84, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 356s] threads: 64, tps: 0.00, reads: 170142.07, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 357s] threads: 64, tps: 0.00, reads: 170575.07, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 358s] threads: 64, tps: 0.00, reads: 171788.56, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 359s] threads: 64, tps: 0.00, reads: 171120.25, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 360s] threads: 64, tps: 0.00, reads: 172306.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 361s] threads: 64, tps: 0.00, reads: 172079.97, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 362s] threads: 64, tps: 0.00, reads: 171763.12, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 363s] threads: 64, tps: 0.00, reads: 171895.93, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 364s] threads: 64, tps: 0.00, reads: 171303.82, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 365s] threads: 64, tps: 0.00, reads: 171416.57, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 366s] threads: 64, tps: 0.00, reads: 172005.51, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 367s] threads: 64, tps: 0.00, reads: 169509.04, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 368s] threads: 64, tps: 0.00, reads: 171995.00, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 369s] threads: 64, tps: 0.00, reads: 171642.08, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 370s] threads: 64, tps: 0.00, reads: 170123.22, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 371s] threads: 64, tps: 0.00, reads: 171257.66, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 372s] threads: 64, tps: 0.00, reads: 171787.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 373s] threads: 64, tps: 0.00, reads: 169434.12, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 374s] threads: 64, tps: 0.00, reads: 170391.29, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 375s] threads: 64, tps: 0.00, reads: 170779.55, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 376s] threads: 64, tps: 0.00, reads: 171575.02, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 377s] threads: 64, tps: 0.00, reads: 171963.83, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 378s] threads: 64, tps: 0.00, reads: 170118.74, writes: 0.00, response time: 0.51ms (95%), errors: 0.00, reconnects:  0.00
[ 379s] threads: 64, tps: 0.00, reads: 169868.42, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 380s] threads: 64, tps: 0.00, reads: 171250.24, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 381s] threads: 64, tps: 0.00, reads: 170325.86, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 382s] threads: 64, tps: 0.00, reads: 171336.60, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 383s] threads: 64, tps: 0.00, reads: 170875.12, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 384s] threads: 64, tps: 0.00, reads: 171531.11, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 385s] threads: 64, tps: 0.00, reads: 171992.13, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 386s] threads: 64, tps: 0.00, reads: 171455.57, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 387s] threads: 64, tps: 0.00, reads: 171874.27, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 388s] threads: 64, tps: 0.00, reads: 171582.20, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 389s] threads: 64, tps: 0.00, reads: 172055.96, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 390s] threads: 64, tps: 0.00, reads: 171756.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 391s] threads: 64, tps: 0.00, reads: 172704.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 392s] threads: 64, tps: 0.00, reads: 171572.08, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 393s] threads: 64, tps: 0.00, reads: 171801.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 394s] threads: 64, tps: 0.00, reads: 171951.54, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 395s] threads: 64, tps: 0.00, reads: 172000.01, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 396s] threads: 64, tps: 0.00, reads: 171828.96, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 397s] threads: 64, tps: 0.00, reads: 172316.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 398s] threads: 64, tps: 0.00, reads: 172450.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 399s] threads: 64, tps: 0.00, reads: 171917.03, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 400s] threads: 64, tps: 0.00, reads: 172143.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 401s] threads: 64, tps: 0.00, reads: 170985.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 402s] threads: 64, tps: 0.00, reads: 171899.05, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 403s] threads: 64, tps: 0.00, reads: 171753.03, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 404s] threads: 64, tps: 0.00, reads: 172025.87, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 405s] threads: 64, tps: 0.00, reads: 172582.20, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 406s] threads: 64, tps: 0.00, reads: 171783.99, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 407s] threads: 64, tps: 0.00, reads: 171650.29, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 408s] threads: 64, tps: 0.00, reads: 171693.53, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 409s] threads: 64, tps: 0.00, reads: 171227.11, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 410s] threads: 64, tps: 0.00, reads: 170811.31, writes: 0.00, response time: 0.49ms (95%), errors: 0.00, reconnects:  0.00
[ 411s] threads: 64, tps: 0.00, reads: 171729.79, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 412s] threads: 64, tps: 0.00, reads: 172383.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 413s] threads: 64, tps: 0.00, reads: 171582.18, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 414s] threads: 64, tps: 0.00, reads: 171353.09, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 415s] threads: 64, tps: 0.00, reads: 171022.85, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 416s] threads: 64, tps: 0.00, reads: 170109.31, writes: 0.00, response time: 0.50ms (95%), errors: 0.00, reconnects:  0.00
[ 417s] threads: 64, tps: 0.00, reads: 170352.02, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 418s] threads: 64, tps: 0.00, reads: 170889.11, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 419s] threads: 64, tps: 0.00, reads: 170666.80, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[ 420s] threads: 64, tps: 0.00, reads: 171565.28, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 421s] threads: 64, tps: 0.00, reads: 171416.80, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 422s] threads: 64, tps: 0.00, reads: 171891.03, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 423s] threads: 64, tps: 0.00, reads: 171782.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 424s] threads: 64, tps: 0.00, reads: 172050.16, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 425s] threads: 64, tps: 0.00, reads: 172651.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 426s] threads: 64, tps: 0.00, reads: 172233.22, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 427s] threads: 64, tps: 0.00, reads: 172089.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 428s] threads: 64, tps: 0.00, reads: 171815.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 429s] threads: 64, tps: 0.00, reads: 172199.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 430s] threads: 64, tps: 0.00, reads: 172344.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 431s] threads: 64, tps: 0.00, reads: 170934.94, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 432s] threads: 64, tps: 0.00, reads: 172969.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 433s] threads: 64, tps: 0.00, reads: 172116.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 434s] threads: 64, tps: 0.00, reads: 172264.94, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 435s] threads: 64, tps: 0.00, reads: 171976.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 436s] threads: 64, tps: 0.00, reads: 172007.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 437s] threads: 64, tps: 0.00, reads: 172144.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 438s] threads: 64, tps: 0.00, reads: 171972.26, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 439s] threads: 64, tps: 0.00, reads: 172242.06, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 440s] threads: 64, tps: 0.00, reads: 172152.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 441s] threads: 64, tps: 0.00, reads: 172184.06, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 442s] threads: 64, tps: 0.00, reads: 172135.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 443s] threads: 64, tps: 0.00, reads: 172051.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 444s] threads: 64, tps: 0.00, reads: 172102.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 445s] threads: 64, tps: 0.00, reads: 172756.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 446s] threads: 64, tps: 0.00, reads: 171885.94, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 447s] threads: 64, tps: 0.00, reads: 172321.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 448s] threads: 64, tps: 0.00, reads: 171723.14, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 449s] threads: 64, tps: 0.00, reads: 171784.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 450s] threads: 64, tps: 0.00, reads: 171891.22, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 451s] threads: 64, tps: 0.00, reads: 171715.01, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 452s] threads: 64, tps: 0.00, reads: 172078.00, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 453s] threads: 64, tps: 0.00, reads: 171553.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 454s] threads: 64, tps: 0.00, reads: 171867.32, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 455s] threads: 64, tps: 0.00, reads: 169888.54, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 456s] threads: 64, tps: 0.00, reads: 171097.93, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 457s] threads: 64, tps: 0.00, reads: 171084.03, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 458s] threads: 64, tps: 0.00, reads: 171402.48, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 459s] threads: 64, tps: 0.00, reads: 171777.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 460s] threads: 64, tps: 0.00, reads: 170432.04, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 461s] threads: 64, tps: 0.00, reads: 171884.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 462s] threads: 64, tps: 0.00, reads: 171967.07, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 463s] threads: 64, tps: 0.00, reads: 171773.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 464s] threads: 64, tps: 0.00, reads: 172124.04, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 465s] threads: 64, tps: 0.00, reads: 172373.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 466s] threads: 64, tps: 0.00, reads: 172622.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 467s] threads: 64, tps: 0.00, reads: 171889.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 468s] threads: 64, tps: 0.00, reads: 172225.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 469s] threads: 64, tps: 0.00, reads: 172108.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 470s] threads: 64, tps: 0.00, reads: 172054.65, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 471s] threads: 64, tps: 0.00, reads: 172229.16, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 472s] threads: 64, tps: 0.00, reads: 172555.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 473s] threads: 64, tps: 0.00, reads: 171524.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 474s] threads: 64, tps: 0.00, reads: 172074.74, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 475s] threads: 64, tps: 0.00, reads: 172421.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 476s] threads: 64, tps: 0.00, reads: 172405.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 477s] threads: 64, tps: 0.00, reads: 172252.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 478s] threads: 64, tps: 0.00, reads: 172586.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 479s] threads: 64, tps: 0.00, reads: 172807.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 480s] threads: 64, tps: 0.00, reads: 172359.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 481s] threads: 64, tps: 0.00, reads: 171369.04, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 482s] threads: 64, tps: 0.00, reads: 171384.18, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 483s] threads: 64, tps: 0.00, reads: 171669.05, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 484s] threads: 64, tps: 0.00, reads: 171617.43, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 485s] threads: 64, tps: 0.00, reads: 171179.57, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 486s] threads: 64, tps: 0.00, reads: 171677.32, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 487s] threads: 64, tps: 0.00, reads: 172085.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 488s] threads: 64, tps: 0.00, reads: 172202.86, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 489s] threads: 64, tps: 0.00, reads: 172312.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 490s] threads: 64, tps: 0.00, reads: 172088.89, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 491s] threads: 64, tps: 0.00, reads: 172682.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 492s] threads: 64, tps: 0.00, reads: 171959.72, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 493s] threads: 64, tps: 0.00, reads: 172112.93, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 494s] threads: 64, tps: 0.00, reads: 171800.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 495s] threads: 64, tps: 0.00, reads: 172064.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 496s] threads: 64, tps: 0.00, reads: 172187.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 497s] threads: 64, tps: 0.00, reads: 172066.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 498s] threads: 64, tps: 0.00, reads: 172477.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 499s] threads: 64, tps: 0.00, reads: 171830.99, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 500s] threads: 64, tps: 0.00, reads: 171185.01, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 501s] threads: 64, tps: 0.00, reads: 171748.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 502s] threads: 64, tps: 0.00, reads: 170403.58, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 503s] threads: 64, tps: 0.00, reads: 170750.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 504s] threads: 64, tps: 0.00, reads: 171344.54, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 505s] threads: 64, tps: 0.00, reads: 172186.01, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 506s] threads: 64, tps: 0.00, reads: 172137.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 507s] threads: 64, tps: 0.00, reads: 171656.84, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 508s] threads: 64, tps: 0.00, reads: 172083.48, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 509s] threads: 64, tps: 0.00, reads: 171621.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 510s] threads: 64, tps: 0.00, reads: 172223.97, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 511s] threads: 64, tps: 0.00, reads: 172829.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 512s] threads: 64, tps: 0.00, reads: 172386.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 513s] threads: 64, tps: 0.00, reads: 172375.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 514s] threads: 64, tps: 0.00, reads: 172287.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 515s] threads: 64, tps: 0.00, reads: 172351.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 516s] threads: 64, tps: 0.00, reads: 172441.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 517s] threads: 64, tps: 0.00, reads: 171106.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 518s] threads: 64, tps: 0.00, reads: 172702.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 519s] threads: 64, tps: 0.00, reads: 171998.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 520s] threads: 64, tps: 0.00, reads: 172209.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 521s] threads: 64, tps: 0.00, reads: 172449.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 522s] threads: 64, tps: 0.00, reads: 172303.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 523s] threads: 64, tps: 0.00, reads: 172042.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 524s] threads: 64, tps: 0.00, reads: 172174.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 525s] threads: 64, tps: 0.00, reads: 173060.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 526s] threads: 64, tps: 0.00, reads: 171970.99, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 527s] threads: 64, tps: 0.00, reads: 170723.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 528s] threads: 64, tps: 0.00, reads: 172040.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 529s] threads: 64, tps: 0.00, reads: 172172.55, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 530s] threads: 64, tps: 0.00, reads: 171521.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 531s] threads: 64, tps: 0.00, reads: 172644.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 532s] threads: 64, tps: 0.00, reads: 171985.99, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 533s] threads: 64, tps: 0.00, reads: 172831.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 534s] threads: 64, tps: 0.00, reads: 171976.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 535s] threads: 64, tps: 0.00, reads: 172173.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 536s] threads: 64, tps: 0.00, reads: 172131.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 537s] threads: 64, tps: 0.00, reads: 169773.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 538s] threads: 64, tps: 0.00, reads: 172231.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 539s] threads: 64, tps: 0.00, reads: 172445.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 540s] threads: 64, tps: 0.00, reads: 172599.14, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 541s] threads: 64, tps: 0.00, reads: 171477.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 542s] threads: 64, tps: 0.00, reads: 171480.43, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 543s] threads: 64, tps: 0.00, reads: 171808.91, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 544s] threads: 64, tps: 0.00, reads: 172096.10, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 545s] threads: 64, tps: 0.00, reads: 171036.07, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 546s] threads: 64, tps: 0.00, reads: 172434.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 547s] threads: 64, tps: 0.00, reads: 171765.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 548s] threads: 64, tps: 0.00, reads: 171442.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 549s] threads: 64, tps: 0.00, reads: 171308.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 550s] threads: 64, tps: 0.00, reads: 171814.90, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 551s] threads: 64, tps: 0.00, reads: 171876.09, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 552s] threads: 64, tps: 0.00, reads: 171569.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 553s] threads: 64, tps: 0.00, reads: 172177.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 554s] threads: 64, tps: 0.00, reads: 172341.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 555s] threads: 64, tps: 0.00, reads: 171673.05, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 556s] threads: 64, tps: 0.00, reads: 171261.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 557s] threads: 64, tps: 0.00, reads: 172416.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 558s] threads: 64, tps: 0.00, reads: 172243.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 559s] threads: 64, tps: 0.00, reads: 170746.80, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 560s] threads: 64, tps: 0.00, reads: 172627.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 561s] threads: 64, tps: 0.00, reads: 172493.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 562s] threads: 64, tps: 0.00, reads: 171612.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 563s] threads: 64, tps: 0.00, reads: 172347.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 564s] threads: 64, tps: 0.00, reads: 171953.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 565s] threads: 64, tps: 0.00, reads: 172556.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 566s] threads: 64, tps: 0.00, reads: 172996.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 567s] threads: 64, tps: 0.00, reads: 173117.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 568s] threads: 64, tps: 0.00, reads: 172069.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 569s] threads: 64, tps: 0.00, reads: 172354.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 570s] threads: 64, tps: 0.00, reads: 172530.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 571s] threads: 64, tps: 0.00, reads: 172317.59, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 572s] threads: 64, tps: 0.00, reads: 172185.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 573s] threads: 64, tps: 0.00, reads: 173090.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 574s] threads: 64, tps: 0.00, reads: 172478.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 575s] threads: 64, tps: 0.00, reads: 172369.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 576s] threads: 64, tps: 0.00, reads: 172161.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 577s] threads: 64, tps: 0.00, reads: 172212.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 578s] threads: 64, tps: 0.00, reads: 172277.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 579s] threads: 64, tps: 0.00, reads: 172880.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 580s] threads: 64, tps: 0.00, reads: 172685.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 581s] threads: 64, tps: 0.00, reads: 172288.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 582s] threads: 64, tps: 0.00, reads: 172498.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 583s] threads: 64, tps: 0.00, reads: 172762.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 584s] threads: 64, tps: 0.00, reads: 172325.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 585s] threads: 64, tps: 0.00, reads: 172346.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 586s] threads: 64, tps: 0.00, reads: 172913.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 587s] threads: 64, tps: 0.00, reads: 171947.33, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 588s] threads: 64, tps: 0.00, reads: 171969.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 589s] threads: 64, tps: 0.00, reads: 171765.84, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 590s] threads: 64, tps: 0.00, reads: 171940.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 591s] threads: 64, tps: 0.00, reads: 172550.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 592s] threads: 64, tps: 0.00, reads: 172666.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 593s] threads: 64, tps: 0.00, reads: 171143.65, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 594s] threads: 64, tps: 0.00, reads: 171360.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 595s] threads: 64, tps: 0.00, reads: 171951.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 596s] threads: 64, tps: 0.00, reads: 171139.67, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 597s] threads: 64, tps: 0.00, reads: 171361.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 598s] threads: 64, tps: 0.00, reads: 171798.97, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 599s] threads: 64, tps: 0.00, reads: 172247.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 600s] threads: 64, tps: 0.00, reads: 171781.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 601s] threads: 64, tps: 0.00, reads: 171920.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 602s] threads: 64, tps: 0.00, reads: 172021.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 603s] threads: 64, tps: 0.00, reads: 172286.08, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 604s] threads: 64, tps: 0.00, reads: 171920.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 605s] threads: 64, tps: 0.00, reads: 172697.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 606s] threads: 64, tps: 0.00, reads: 172783.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 607s] threads: 64, tps: 0.00, reads: 172211.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 608s] threads: 64, tps: 0.00, reads: 172307.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 609s] threads: 64, tps: 0.00, reads: 172697.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 610s] threads: 64, tps: 0.00, reads: 172686.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 611s] threads: 64, tps: 0.00, reads: 172839.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 612s] threads: 64, tps: 0.00, reads: 172939.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 613s] threads: 64, tps: 0.00, reads: 171476.98, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 614s] threads: 64, tps: 0.00, reads: 172482.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 615s] threads: 64, tps: 0.00, reads: 172465.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 616s] threads: 64, tps: 0.00, reads: 172682.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 617s] threads: 64, tps: 0.00, reads: 172620.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 618s] threads: 64, tps: 0.00, reads: 172181.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 619s] threads: 64, tps: 0.00, reads: 172293.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 620s] threads: 64, tps: 0.00, reads: 172067.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 621s] threads: 64, tps: 0.00, reads: 172239.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 622s] threads: 64, tps: 0.00, reads: 172743.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 623s] threads: 64, tps: 0.00, reads: 172410.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 624s] threads: 64, tps: 0.00, reads: 172556.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 625s] threads: 64, tps: 0.00, reads: 173022.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 626s] threads: 64, tps: 0.00, reads: 172489.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 627s] threads: 64, tps: 0.00, reads: 172213.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 628s] threads: 64, tps: 0.00, reads: 172563.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 629s] threads: 64, tps: 0.00, reads: 172331.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 630s] threads: 64, tps: 0.00, reads: 172362.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 631s] threads: 64, tps: 0.00, reads: 172843.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 632s] threads: 64, tps: 0.00, reads: 172293.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 633s] threads: 64, tps: 0.00, reads: 172511.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 634s] threads: 64, tps: 0.00, reads: 172180.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 635s] threads: 64, tps: 0.00, reads: 172584.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 636s] threads: 64, tps: 0.00, reads: 172089.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 637s] threads: 64, tps: 0.00, reads: 172518.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 638s] threads: 64, tps: 0.00, reads: 172769.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 639s] threads: 64, tps: 0.00, reads: 172211.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 640s] threads: 64, tps: 0.00, reads: 172328.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 641s] threads: 64, tps: 0.00, reads: 171406.21, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 642s] threads: 64, tps: 0.00, reads: 172173.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 643s] threads: 64, tps: 0.00, reads: 172189.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 644s] threads: 64, tps: 0.00, reads: 172929.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 645s] threads: 64, tps: 0.00, reads: 172347.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 646s] threads: 64, tps: 0.00, reads: 171909.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 647s] threads: 64, tps: 0.00, reads: 171536.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 648s] threads: 64, tps: 0.00, reads: 172067.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 649s] threads: 64, tps: 0.00, reads: 171663.87, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 650s] threads: 64, tps: 0.00, reads: 171657.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 651s] threads: 64, tps: 0.00, reads: 172369.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 652s] threads: 64, tps: 0.00, reads: 171929.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 653s] threads: 64, tps: 0.00, reads: 172267.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 654s] threads: 64, tps: 0.00, reads: 171522.75, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 655s] threads: 64, tps: 0.00, reads: 172261.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 656s] threads: 64, tps: 0.00, reads: 172211.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 657s] threads: 64, tps: 0.00, reads: 172983.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 658s] threads: 64, tps: 0.00, reads: 172297.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 659s] threads: 64, tps: 0.00, reads: 172291.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 660s] threads: 64, tps: 0.00, reads: 172217.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 661s] threads: 64, tps: 0.00, reads: 171691.35, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 662s] threads: 64, tps: 0.00, reads: 172317.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 663s] threads: 64, tps: 0.00, reads: 172551.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 664s] threads: 64, tps: 0.00, reads: 171784.82, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 665s] threads: 64, tps: 0.00, reads: 171974.70, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 666s] threads: 64, tps: 0.00, reads: 170778.93, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 667s] threads: 64, tps: 0.00, reads: 171722.75, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 668s] threads: 64, tps: 0.00, reads: 170730.54, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 669s] threads: 64, tps: 0.00, reads: 172316.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 670s] threads: 64, tps: 0.00, reads: 173331.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 671s] threads: 64, tps: 0.00, reads: 172873.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 672s] threads: 64, tps: 0.00, reads: 172496.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 673s] threads: 64, tps: 0.00, reads: 172282.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 674s] threads: 64, tps: 0.00, reads: 172601.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 675s] threads: 64, tps: 0.00, reads: 172656.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 676s] threads: 64, tps: 0.00, reads: 173157.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 677s] threads: 64, tps: 0.00, reads: 172546.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 678s] threads: 64, tps: 0.00, reads: 171124.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 679s] threads: 64, tps: 0.00, reads: 172770.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 680s] threads: 64, tps: 0.00, reads: 171792.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 681s] threads: 64, tps: 0.00, reads: 172351.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 682s] threads: 64, tps: 0.00, reads: 172841.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 683s] threads: 64, tps: 0.00, reads: 172906.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 684s] threads: 64, tps: 0.00, reads: 172041.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 685s] threads: 64, tps: 0.00, reads: 172353.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 686s] threads: 64, tps: 0.00, reads: 171765.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 687s] threads: 64, tps: 0.00, reads: 172385.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 688s] threads: 64, tps: 0.00, reads: 172516.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 689s] threads: 64, tps: 0.00, reads: 172272.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 690s] threads: 64, tps: 0.00, reads: 172621.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 691s] threads: 64, tps: 0.00, reads: 172449.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 692s] threads: 64, tps: 0.00, reads: 172399.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 693s] threads: 64, tps: 0.00, reads: 172156.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 694s] threads: 64, tps: 0.00, reads: 172242.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 695s] threads: 64, tps: 0.00, reads: 172345.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 696s] threads: 64, tps: 0.00, reads: 173095.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 697s] threads: 64, tps: 0.00, reads: 172781.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 698s] threads: 64, tps: 0.00, reads: 172249.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 699s] threads: 64, tps: 0.00, reads: 172306.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 700s] threads: 64, tps: 0.00, reads: 171793.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 701s] threads: 64, tps: 0.00, reads: 171701.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 702s] threads: 64, tps: 0.00, reads: 172347.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 703s] threads: 64, tps: 0.00, reads: 171507.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 704s] threads: 64, tps: 0.00, reads: 171913.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 705s] threads: 64, tps: 0.00, reads: 170410.91, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 706s] threads: 64, tps: 0.00, reads: 171937.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 707s] threads: 64, tps: 0.00, reads: 171834.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 708s] threads: 64, tps: 0.00, reads: 172469.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 709s] threads: 64, tps: 0.00, reads: 172767.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 710s] threads: 64, tps: 0.00, reads: 172069.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 711s] threads: 64, tps: 0.00, reads: 172295.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 712s] threads: 64, tps: 0.00, reads: 172467.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 713s] threads: 64, tps: 0.00, reads: 172100.03, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 714s] threads: 64, tps: 0.00, reads: 172978.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 715s] threads: 64, tps: 0.00, reads: 173027.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 716s] threads: 64, tps: 0.00, reads: 172611.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 717s] threads: 64, tps: 0.00, reads: 172637.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 718s] threads: 64, tps: 0.00, reads: 172330.69, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 719s] threads: 64, tps: 0.00, reads: 172744.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 720s] threads: 64, tps: 0.00, reads: 172626.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 721s] threads: 64, tps: 0.00, reads: 172875.05, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[ 722s] threads: 64, tps: 0.00, reads: 173152.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 723s] threads: 64, tps: 0.00, reads: 172898.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 724s] threads: 64, tps: 0.00, reads: 172482.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 725s] threads: 64, tps: 0.00, reads: 172743.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 726s] threads: 64, tps: 0.00, reads: 172717.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 727s] threads: 64, tps: 0.00, reads: 172645.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 728s] threads: 64, tps: 0.00, reads: 173163.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 729s] threads: 64, tps: 0.00, reads: 172814.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 730s] threads: 64, tps: 0.00, reads: 172348.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 731s] threads: 64, tps: 0.00, reads: 172016.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 732s] threads: 64, tps: 0.00, reads: 172716.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 733s] threads: 64, tps: 0.00, reads: 172275.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 734s] threads: 64, tps: 0.00, reads: 172612.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 735s] threads: 64, tps: 0.00, reads: 172760.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 736s] threads: 64, tps: 0.00, reads: 172697.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 737s] threads: 64, tps: 0.00, reads: 172500.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 738s] threads: 64, tps: 0.00, reads: 172389.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 739s] threads: 64, tps: 0.00, reads: 172802.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 740s] threads: 64, tps: 0.00, reads: 172650.88, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[ 741s] threads: 64, tps: 0.00, reads: 173248.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 742s] threads: 64, tps: 0.00, reads: 171897.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 743s] threads: 64, tps: 0.00, reads: 172672.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 744s] threads: 64, tps: 0.00, reads: 172535.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 745s] threads: 64, tps: 0.00, reads: 172306.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 746s] threads: 64, tps: 0.00, reads: 172597.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 747s] threads: 64, tps: 0.00, reads: 172836.64, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 748s] threads: 64, tps: 0.00, reads: 172665.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 749s] threads: 64, tps: 0.00, reads: 172331.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 750s] threads: 64, tps: 0.00, reads: 171903.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 751s] threads: 64, tps: 0.00, reads: 172253.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 752s] threads: 64, tps: 0.00, reads: 172255.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 753s] threads: 64, tps: 0.00, reads: 172404.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 754s] threads: 64, tps: 0.00, reads: 172807.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 755s] threads: 64, tps: 0.00, reads: 171553.52, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 756s] threads: 64, tps: 0.00, reads: 171817.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 757s] threads: 64, tps: 0.00, reads: 172107.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 758s] threads: 64, tps: 0.00, reads: 171991.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 759s] threads: 64, tps: 0.00, reads: 171670.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 760s] threads: 64, tps: 0.00, reads: 172243.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 761s] threads: 64, tps: 0.00, reads: 171793.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 762s] threads: 64, tps: 0.00, reads: 171958.96, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 763s] threads: 64, tps: 0.00, reads: 172036.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 764s] threads: 64, tps: 0.00, reads: 171792.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 765s] threads: 64, tps: 0.00, reads: 172123.72, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 766s] threads: 64, tps: 0.00, reads: 172697.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 767s] threads: 64, tps: 0.00, reads: 173045.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 768s] threads: 64, tps: 0.00, reads: 172533.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 769s] threads: 64, tps: 0.00, reads: 172413.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 770s] threads: 64, tps: 0.00, reads: 172461.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 771s] threads: 64, tps: 0.00, reads: 172424.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 772s] threads: 64, tps: 0.00, reads: 172666.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 773s] threads: 64, tps: 0.00, reads: 173076.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 774s] threads: 64, tps: 0.00, reads: 172575.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 775s] threads: 64, tps: 0.00, reads: 172684.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 776s] threads: 64, tps: 0.00, reads: 172348.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 777s] threads: 64, tps: 0.00, reads: 172400.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 778s] threads: 64, tps: 0.00, reads: 172600.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 779s] threads: 64, tps: 0.00, reads: 172306.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 780s] threads: 64, tps: 0.00, reads: 173379.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 781s] threads: 64, tps: 0.00, reads: 171933.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 782s] threads: 64, tps: 0.00, reads: 172461.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 783s] threads: 64, tps: 0.00, reads: 172812.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 784s] threads: 64, tps: 0.00, reads: 172597.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 785s] threads: 64, tps: 0.00, reads: 172718.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 786s] threads: 64, tps: 0.00, reads: 172888.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 787s] threads: 64, tps: 0.00, reads: 172752.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 788s] threads: 64, tps: 0.00, reads: 172594.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 789s] threads: 64, tps: 0.00, reads: 172354.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 790s] threads: 64, tps: 0.00, reads: 172895.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 791s] threads: 64, tps: 0.00, reads: 172724.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 792s] threads: 64, tps: 0.00, reads: 173009.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 793s] threads: 64, tps: 0.00, reads: 172766.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 794s] threads: 64, tps: 0.00, reads: 172460.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 795s] threads: 64, tps: 0.00, reads: 172404.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 796s] threads: 64, tps: 0.00, reads: 172125.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 797s] threads: 64, tps: 0.00, reads: 172548.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 798s] threads: 64, tps: 0.00, reads: 172585.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 799s] threads: 64, tps: 0.00, reads: 173167.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 800s] threads: 64, tps: 0.00, reads: 172276.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 801s] threads: 64, tps: 0.00, reads: 172348.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 802s] threads: 64, tps: 0.00, reads: 172563.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 803s] threads: 64, tps: 0.00, reads: 172434.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 804s] threads: 64, tps: 0.00, reads: 172317.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 805s] threads: 64, tps: 0.00, reads: 172840.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 806s] threads: 64, tps: 0.00, reads: 172926.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 807s] threads: 64, tps: 0.00, reads: 172538.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 808s] threads: 64, tps: 0.00, reads: 172658.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 809s] threads: 64, tps: 0.00, reads: 172193.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 810s] threads: 64, tps: 0.00, reads: 171812.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 811s] threads: 64, tps: 0.00, reads: 171981.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 812s] threads: 64, tps: 0.00, reads: 172748.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 813s] threads: 64, tps: 0.00, reads: 171858.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 814s] threads: 64, tps: 0.00, reads: 171401.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 815s] threads: 64, tps: 0.00, reads: 172120.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 816s] threads: 64, tps: 0.00, reads: 171781.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 817s] threads: 64, tps: 0.00, reads: 171869.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 818s] threads: 64, tps: 0.00, reads: 172379.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 819s] threads: 64, tps: 0.00, reads: 172479.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 820s] threads: 64, tps: 0.00, reads: 172459.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 821s] threads: 64, tps: 0.00, reads: 172111.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 822s] threads: 64, tps: 0.00, reads: 172133.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 823s] threads: 64, tps: 0.00, reads: 172604.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 824s] threads: 64, tps: 0.00, reads: 172582.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 825s] threads: 64, tps: 0.00, reads: 173220.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 826s] threads: 64, tps: 0.00, reads: 172412.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 827s] threads: 64, tps: 0.00, reads: 172538.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 828s] threads: 64, tps: 0.00, reads: 172361.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 829s] threads: 64, tps: 0.00, reads: 172506.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 830s] threads: 64, tps: 0.00, reads: 172394.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 831s] threads: 64, tps: 0.00, reads: 173091.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 832s] threads: 64, tps: 0.00, reads: 173395.50, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 833s] threads: 64, tps: 0.00, reads: 172590.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 834s] threads: 64, tps: 0.00, reads: 172254.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 835s] threads: 64, tps: 0.00, reads: 172600.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 836s] threads: 64, tps: 0.00, reads: 172594.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 837s] threads: 64, tps: 0.00, reads: 172238.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 838s] threads: 64, tps: 0.00, reads: 173252.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 839s] threads: 64, tps: 0.00, reads: 172487.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 840s] threads: 64, tps: 0.00, reads: 172837.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 841s] threads: 64, tps: 0.00, reads: 172346.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 842s] threads: 64, tps: 0.00, reads: 172097.19, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 843s] threads: 64, tps: 0.00, reads: 172213.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 844s] threads: 64, tps: 0.00, reads: 173155.08, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[ 845s] threads: 64, tps: 0.00, reads: 172971.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 846s] threads: 64, tps: 0.00, reads: 172530.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 847s] threads: 64, tps: 0.00, reads: 172358.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 848s] threads: 64, tps: 0.00, reads: 172298.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 849s] threads: 64, tps: 0.00, reads: 172826.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 850s] threads: 64, tps: 0.00, reads: 172719.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 851s] threads: 64, tps: 0.00, reads: 173196.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 852s] threads: 64, tps: 0.00, reads: 172835.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 853s] threads: 64, tps: 0.00, reads: 172454.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 854s] threads: 64, tps: 0.00, reads: 172104.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 855s] threads: 64, tps: 0.00, reads: 172092.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 856s] threads: 64, tps: 0.00, reads: 172614.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 857s] threads: 64, tps: 0.00, reads: 172543.92, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[ 858s] threads: 64, tps: 0.00, reads: 173111.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 859s] threads: 64, tps: 0.00, reads: 172068.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 860s] threads: 64, tps: 0.00, reads: 172211.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 861s] threads: 64, tps: 0.00, reads: 172154.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 862s] threads: 64, tps: 0.00, reads: 172123.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 863s] threads: 64, tps: 0.00, reads: 172437.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 864s] threads: 64, tps: 0.00, reads: 173113.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 865s] threads: 64, tps: 0.00, reads: 171821.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 866s] threads: 64, tps: 0.00, reads: 172259.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 867s] threads: 64, tps: 0.00, reads: 171726.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 868s] threads: 64, tps: 0.00, reads: 171692.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 869s] threads: 64, tps: 0.00, reads: 171933.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 870s] threads: 64, tps: 0.00, reads: 172382.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 871s] threads: 64, tps: 0.00, reads: 172396.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 872s] threads: 64, tps: 0.00, reads: 171588.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 873s] threads: 64, tps: 0.00, reads: 171895.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 874s] threads: 64, tps: 0.00, reads: 171928.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 875s] threads: 64, tps: 0.00, reads: 172180.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 876s] threads: 64, tps: 0.00, reads: 172340.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 877s] threads: 64, tps: 0.00, reads: 172887.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 878s] threads: 64, tps: 0.00, reads: 172779.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 879s] threads: 64, tps: 0.00, reads: 172652.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 880s] threads: 64, tps: 0.00, reads: 172565.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 881s] threads: 64, tps: 0.00, reads: 172333.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 882s] threads: 64, tps: 0.00, reads: 172721.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 883s] threads: 64, tps: 0.00, reads: 172973.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 884s] threads: 64, tps: 0.00, reads: 173096.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 885s] threads: 64, tps: 0.00, reads: 172493.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 886s] threads: 64, tps: 0.00, reads: 172672.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 887s] threads: 64, tps: 0.00, reads: 172288.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 888s] threads: 64, tps: 0.00, reads: 172780.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 889s] threads: 64, tps: 0.00, reads: 172798.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 890s] threads: 64, tps: 0.00, reads: 172985.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 891s] threads: 64, tps: 0.00, reads: 172678.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 892s] threads: 64, tps: 0.00, reads: 171938.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 893s] threads: 64, tps: 0.00, reads: 172462.16, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 894s] threads: 64, tps: 0.00, reads: 172824.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 895s] threads: 64, tps: 0.00, reads: 172995.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 896s] threads: 64, tps: 0.00, reads: 173274.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 897s] threads: 64, tps: 0.00, reads: 172391.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 898s] threads: 64, tps: 0.00, reads: 172500.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 899s] threads: 64, tps: 0.00, reads: 172734.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 900s] threads: 64, tps: 0.00, reads: 172636.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 901s] threads: 64, tps: 0.00, reads: 172572.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 902s] threads: 64, tps: 0.00, reads: 173229.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 903s] threads: 64, tps: 0.00, reads: 172354.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 904s] threads: 64, tps: 0.00, reads: 172476.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 905s] threads: 64, tps: 0.00, reads: 172659.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 906s] threads: 64, tps: 0.00, reads: 172690.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 907s] threads: 64, tps: 0.00, reads: 172609.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 908s] threads: 64, tps: 0.00, reads: 172741.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 909s] threads: 64, tps: 0.00, reads: 173237.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 910s] threads: 64, tps: 0.00, reads: 172448.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 911s] threads: 64, tps: 0.00, reads: 172627.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 912s] threads: 64, tps: 0.00, reads: 171940.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 913s] threads: 64, tps: 0.00, reads: 172369.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 914s] threads: 64, tps: 0.00, reads: 172280.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 915s] threads: 64, tps: 0.00, reads: 173160.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 916s] threads: 64, tps: 0.00, reads: 172486.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 917s] threads: 64, tps: 0.00, reads: 172418.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 918s] threads: 64, tps: 0.00, reads: 172444.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 919s] threads: 64, tps: 0.00, reads: 171672.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 920s] threads: 64, tps: 0.00, reads: 171322.58, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 921s] threads: 64, tps: 0.00, reads: 172404.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 922s] threads: 64, tps: 0.00, reads: 172431.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 923s] threads: 64, tps: 0.00, reads: 172508.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 924s] threads: 64, tps: 0.00, reads: 171296.79, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 925s] threads: 64, tps: 0.00, reads: 171790.06, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 926s] threads: 64, tps: 0.00, reads: 172030.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 927s] threads: 64, tps: 0.00, reads: 172182.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 928s] threads: 64, tps: 0.00, reads: 172303.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 929s] threads: 64, tps: 0.00, reads: 171051.50, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 930s] threads: 64, tps: 0.00, reads: 172034.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 931s] threads: 64, tps: 0.00, reads: 172230.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 932s] threads: 64, tps: 0.00, reads: 172255.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 933s] threads: 64, tps: 0.00, reads: 171998.64, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 934s] threads: 64, tps: 0.00, reads: 173101.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 935s] threads: 64, tps: 0.00, reads: 172536.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 936s] threads: 64, tps: 0.00, reads: 172548.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 937s] threads: 64, tps: 0.00, reads: 172498.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 938s] threads: 64, tps: 0.00, reads: 172235.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 939s] threads: 64, tps: 0.00, reads: 172733.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 940s] threads: 64, tps: 0.00, reads: 173780.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 941s] threads: 64, tps: 0.00, reads: 172804.87, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[ 942s] threads: 64, tps: 0.00, reads: 172529.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 943s] threads: 64, tps: 0.00, reads: 172598.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 944s] threads: 64, tps: 0.00, reads: 172713.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 945s] threads: 64, tps: 0.00, reads: 172859.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 946s] threads: 64, tps: 0.00, reads: 173296.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 947s] threads: 64, tps: 0.00, reads: 173009.37, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[ 948s] threads: 64, tps: 0.00, reads: 172919.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 949s] threads: 64, tps: 0.00, reads: 172338.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 950s] threads: 64, tps: 0.00, reads: 172492.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 951s] threads: 64, tps: 0.00, reads: 171729.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 952s] threads: 64, tps: 0.00, reads: 172728.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 953s] threads: 64, tps: 0.00, reads: 173263.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 954s] threads: 64, tps: 0.00, reads: 172686.00, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[ 955s] threads: 64, tps: 0.00, reads: 172733.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 956s] threads: 64, tps: 0.00, reads: 171910.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 957s] threads: 64, tps: 0.00, reads: 169236.12, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 958s] threads: 64, tps: 0.00, reads: 171985.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 959s] threads: 64, tps: 0.00, reads: 172971.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 960s] threads: 64, tps: 0.00, reads: 173200.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 961s] threads: 64, tps: 0.00, reads: 172564.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 962s] threads: 64, tps: 0.00, reads: 172315.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 963s] threads: 64, tps: 0.00, reads: 172218.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 964s] threads: 64, tps: 0.00, reads: 172401.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 965s] threads: 64, tps: 0.00, reads: 172750.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 966s] threads: 64, tps: 0.00, reads: 173320.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 967s] threads: 64, tps: 0.00, reads: 172352.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 968s] threads: 64, tps: 0.00, reads: 172460.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 969s] threads: 64, tps: 0.00, reads: 172529.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 970s] threads: 64, tps: 0.00, reads: 172429.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 971s] threads: 64, tps: 0.00, reads: 172539.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 972s] threads: 64, tps: 0.00, reads: 172674.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 973s] threads: 64, tps: 0.00, reads: 172936.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 974s] threads: 64, tps: 0.00, reads: 171733.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 975s] threads: 64, tps: 0.00, reads: 172422.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 976s] threads: 64, tps: 0.00, reads: 172281.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 977s] threads: 64, tps: 0.00, reads: 172132.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 978s] threads: 64, tps: 0.00, reads: 172359.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 979s] threads: 64, tps: 0.00, reads: 171886.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 980s] threads: 64, tps: 0.00, reads: 171200.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 981s] threads: 64, tps: 0.00, reads: 171782.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 982s] threads: 64, tps: 0.00, reads: 171286.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 983s] threads: 64, tps: 0.00, reads: 171661.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 984s] threads: 64, tps: 0.00, reads: 171829.86, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 985s] threads: 64, tps: 0.00, reads: 172652.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 986s] threads: 64, tps: 0.00, reads: 172306.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 987s] threads: 64, tps: 0.00, reads: 172047.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 988s] threads: 64, tps: 0.00, reads: 172455.89, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[ 989s] threads: 64, tps: 0.00, reads: 172479.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 990s] threads: 64, tps: 0.00, reads: 172778.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 991s] threads: 64, tps: 0.00, reads: 172808.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 992s] threads: 64, tps: 0.00, reads: 172609.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 993s] threads: 64, tps: 0.00, reads: 172465.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 994s] threads: 64, tps: 0.00, reads: 172516.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 995s] threads: 64, tps: 0.00, reads: 172586.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 996s] threads: 64, tps: 0.00, reads: 172352.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 997s] threads: 64, tps: 0.00, reads: 172444.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 998s] threads: 64, tps: 0.00, reads: 173141.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[ 999s] threads: 64, tps: 0.00, reads: 172731.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1000s] threads: 64, tps: 0.00, reads: 172284.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1001s] threads: 64, tps: 0.00, reads: 172678.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1002s] threads: 64, tps: 0.00, reads: 172413.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1003s] threads: 64, tps: 0.00, reads: 172553.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1004s] threads: 64, tps: 0.00, reads: 173305.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1005s] threads: 64, tps: 0.00, reads: 172535.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1006s] threads: 64, tps: 0.00, reads: 172549.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1007s] threads: 64, tps: 0.00, reads: 172325.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1008s] threads: 64, tps: 0.00, reads: 172757.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1009s] threads: 64, tps: 0.00, reads: 172554.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1010s] threads: 64, tps: 0.00, reads: 172567.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1011s] threads: 64, tps: 0.00, reads: 173246.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1012s] threads: 64, tps: 0.00, reads: 172406.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1013s] threads: 64, tps: 0.00, reads: 172583.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1014s] threads: 64, tps: 0.00, reads: 172278.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1015s] threads: 64, tps: 0.00, reads: 172827.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1016s] threads: 64, tps: 0.00, reads: 172382.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1017s] threads: 64, tps: 0.00, reads: 172686.82, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1018s] threads: 64, tps: 0.00, reads: 173262.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1019s] threads: 64, tps: 0.00, reads: 172546.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1020s] threads: 64, tps: 0.00, reads: 172357.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1021s] threads: 64, tps: 0.00, reads: 172287.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1022s] threads: 64, tps: 0.00, reads: 172013.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1023s] threads: 64, tps: 0.00, reads: 172615.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1024s] threads: 64, tps: 0.00, reads: 173185.92, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1025s] threads: 64, tps: 0.00, reads: 172745.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1026s] threads: 64, tps: 0.00, reads: 172743.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1027s] threads: 64, tps: 0.00, reads: 172130.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1028s] threads: 64, tps: 0.00, reads: 172424.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1029s] threads: 64, tps: 0.00, reads: 172339.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1030s] threads: 64, tps: 0.00, reads: 172862.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1031s] threads: 64, tps: 0.00, reads: 172357.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1032s] threads: 64, tps: 0.00, reads: 172527.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1033s] threads: 64, tps: 0.00, reads: 172283.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1034s] threads: 64, tps: 0.00, reads: 171975.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1035s] threads: 64, tps: 0.00, reads: 171607.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1036s] threads: 64, tps: 0.00, reads: 171678.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1037s] threads: 64, tps: 0.00, reads: 172384.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1038s] threads: 64, tps: 0.00, reads: 172076.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1039s] threads: 64, tps: 0.00, reads: 171961.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1040s] threads: 64, tps: 0.00, reads: 172053.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1041s] threads: 64, tps: 0.00, reads: 171715.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1042s] threads: 64, tps: 0.00, reads: 171972.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1043s] threads: 64, tps: 0.00, reads: 172489.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1044s] threads: 64, tps: 0.00, reads: 172592.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1045s] threads: 64, tps: 0.00, reads: 172466.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1046s] threads: 64, tps: 0.00, reads: 172404.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1047s] threads: 64, tps: 0.00, reads: 172417.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1048s] threads: 64, tps: 0.00, reads: 172726.01, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1049s] threads: 64, tps: 0.00, reads: 173050.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1050s] threads: 64, tps: 0.00, reads: 173035.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1051s] threads: 64, tps: 0.00, reads: 172806.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1052s] threads: 64, tps: 0.00, reads: 172474.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1053s] threads: 64, tps: 0.00, reads: 172416.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1054s] threads: 64, tps: 0.00, reads: 172497.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1055s] threads: 64, tps: 0.00, reads: 173010.23, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1056s] threads: 64, tps: 0.00, reads: 173379.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1057s] threads: 64, tps: 0.00, reads: 172851.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1058s] threads: 64, tps: 0.00, reads: 172681.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1059s] threads: 64, tps: 0.00, reads: 172379.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1060s] threads: 64, tps: 0.00, reads: 172738.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1061s] threads: 64, tps: 0.00, reads: 172767.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1062s] threads: 64, tps: 0.00, reads: 173474.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1063s] threads: 64, tps: 0.00, reads: 172626.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1064s] threads: 64, tps: 0.00, reads: 172678.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1065s] threads: 64, tps: 0.00, reads: 172401.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1066s] threads: 64, tps: 0.00, reads: 172961.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1067s] threads: 64, tps: 0.00, reads: 172615.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1068s] threads: 64, tps: 0.00, reads: 173095.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1069s] threads: 64, tps: 0.00, reads: 172563.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1070s] threads: 64, tps: 0.00, reads: 172731.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1071s] threads: 64, tps: 0.00, reads: 172600.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1072s] threads: 64, tps: 0.00, reads: 172773.14, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1073s] threads: 64, tps: 0.00, reads: 172388.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1074s] threads: 64, tps: 0.00, reads: 171530.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1075s] threads: 64, tps: 0.00, reads: 173497.71, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1076s] threads: 64, tps: 0.00, reads: 172557.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1077s] threads: 64, tps: 0.00, reads: 172545.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1078s] threads: 64, tps: 0.00, reads: 172348.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1079s] threads: 64, tps: 0.00, reads: 172387.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1080s] threads: 64, tps: 0.00, reads: 172150.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1081s] threads: 64, tps: 0.00, reads: 172722.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1082s] threads: 64, tps: 0.00, reads: 172724.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1083s] threads: 64, tps: 0.00, reads: 172436.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1084s] threads: 64, tps: 0.00, reads: 172478.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1085s] threads: 64, tps: 0.00, reads: 172124.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1086s] threads: 64, tps: 0.00, reads: 172595.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1087s] threads: 64, tps: 0.00, reads: 172912.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1088s] threads: 64, tps: 0.00, reads: 172772.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1089s] threads: 64, tps: 0.00, reads: 172590.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1090s] threads: 64, tps: 0.00, reads: 171863.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1091s] threads: 64, tps: 0.00, reads: 172206.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1092s] threads: 64, tps: 0.00, reads: 172316.79, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1093s] threads: 64, tps: 0.00, reads: 171836.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1094s] threads: 64, tps: 0.00, reads: 172853.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1095s] threads: 64, tps: 0.00, reads: 172083.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1096s] threads: 64, tps: 0.00, reads: 171910.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1097s] threads: 64, tps: 0.00, reads: 171700.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1098s] threads: 64, tps: 0.00, reads: 171883.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1099s] threads: 64, tps: 0.00, reads: 172480.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1100s] threads: 64, tps: 0.00, reads: 173058.01, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1101s] threads: 64, tps: 0.00, reads: 172381.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1102s] threads: 64, tps: 0.00, reads: 172209.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1103s] threads: 64, tps: 0.00, reads: 172177.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1104s] threads: 64, tps: 0.00, reads: 172321.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1105s] threads: 64, tps: 0.00, reads: 172334.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1106s] threads: 64, tps: 0.00, reads: 172778.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1107s] threads: 64, tps: 0.00, reads: 173285.07, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1108s] threads: 64, tps: 0.00, reads: 172666.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1109s] threads: 64, tps: 0.00, reads: 172868.88, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1110s] threads: 64, tps: 0.00, reads: 172331.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1111s] threads: 64, tps: 0.00, reads: 172546.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1112s] threads: 64, tps: 0.00, reads: 172442.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1113s] threads: 64, tps: 0.00, reads: 173286.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1114s] threads: 64, tps: 0.00, reads: 172864.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1115s] threads: 64, tps: 0.00, reads: 172381.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1116s] threads: 64, tps: 0.00, reads: 172891.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1117s] threads: 64, tps: 0.00, reads: 173100.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1118s] threads: 64, tps: 0.00, reads: 172289.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1119s] threads: 64, tps: 0.00, reads: 172785.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1120s] threads: 64, tps: 0.00, reads: 172648.64, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1121s] threads: 64, tps: 0.00, reads: 172229.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1122s] threads: 64, tps: 0.00, reads: 172758.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1123s] threads: 64, tps: 0.00, reads: 172105.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1124s] threads: 64, tps: 0.00, reads: 172622.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1125s] threads: 64, tps: 0.00, reads: 172931.28, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1126s] threads: 64, tps: 0.00, reads: 173504.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1127s] threads: 64, tps: 0.00, reads: 172467.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1128s] threads: 64, tps: 0.00, reads: 172529.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1129s] threads: 64, tps: 0.00, reads: 172487.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1130s] threads: 64, tps: 0.00, reads: 172544.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1131s] threads: 64, tps: 0.00, reads: 172453.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1132s] threads: 64, tps: 0.00, reads: 173381.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1133s] threads: 64, tps: 0.00, reads: 172588.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1134s] threads: 64, tps: 0.00, reads: 172785.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1135s] threads: 64, tps: 0.00, reads: 172399.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1136s] threads: 64, tps: 0.00, reads: 172357.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1137s] threads: 64, tps: 0.00, reads: 172135.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1138s] threads: 64, tps: 0.00, reads: 172353.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1139s] threads: 64, tps: 0.00, reads: 172631.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1140s] threads: 64, tps: 0.00, reads: 171950.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1141s] threads: 64, tps: 0.00, reads: 172007.19, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1142s] threads: 64, tps: 0.00, reads: 172010.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1143s] threads: 64, tps: 0.00, reads: 172262.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1144s] threads: 64, tps: 0.00, reads: 172321.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1145s] threads: 64, tps: 0.00, reads: 172661.70, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1146s] threads: 64, tps: 0.00, reads: 171936.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1147s] threads: 64, tps: 0.00, reads: 171894.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1148s] threads: 64, tps: 0.00, reads: 171863.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1149s] threads: 64, tps: 0.00, reads: 172132.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1150s] threads: 64, tps: 0.00, reads: 172061.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1151s] threads: 64, tps: 0.00, reads: 173127.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1152s] threads: 64, tps: 0.00, reads: 171008.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1153s] threads: 64, tps: 0.00, reads: 171910.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1154s] threads: 64, tps: 0.00, reads: 171964.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1155s] threads: 64, tps: 0.00, reads: 171677.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1156s] threads: 64, tps: 0.00, reads: 172116.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1157s] threads: 64, tps: 0.00, reads: 172813.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1158s] threads: 64, tps: 0.00, reads: 173052.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1159s] threads: 64, tps: 0.00, reads: 172406.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1160s] threads: 64, tps: 0.00, reads: 172367.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1161s] threads: 64, tps: 0.00, reads: 172165.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1162s] threads: 64, tps: 0.00, reads: 172430.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1163s] threads: 64, tps: 0.00, reads: 172371.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1164s] threads: 64, tps: 0.00, reads: 173147.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1165s] threads: 64, tps: 0.00, reads: 172707.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1166s] threads: 64, tps: 0.00, reads: 172428.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1167s] threads: 64, tps: 0.00, reads: 173092.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1168s] threads: 64, tps: 0.00, reads: 172693.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1169s] threads: 64, tps: 0.00, reads: 172807.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1170s] threads: 64, tps: 0.00, reads: 173104.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1171s] threads: 64, tps: 0.00, reads: 173031.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1172s] threads: 64, tps: 0.00, reads: 172743.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1173s] threads: 64, tps: 0.00, reads: 172855.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1174s] threads: 64, tps: 0.00, reads: 172731.41, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1175s] threads: 64, tps: 0.00, reads: 172705.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1176s] threads: 64, tps: 0.00, reads: 172569.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1177s] threads: 64, tps: 0.00, reads: 173097.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1178s] threads: 64, tps: 0.00, reads: 172704.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1179s] threads: 64, tps: 0.00, reads: 172810.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1180s] threads: 64, tps: 0.00, reads: 172857.88, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1181s] threads: 64, tps: 0.00, reads: 172548.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1182s] threads: 64, tps: 0.00, reads: 172989.68, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1183s] threads: 64, tps: 0.00, reads: 173020.89, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1184s] threads: 64, tps: 0.00, reads: 172726.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1185s] threads: 64, tps: 0.00, reads: 172503.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1186s] threads: 64, tps: 0.00, reads: 172277.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1187s] threads: 64, tps: 0.00, reads: 172326.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1188s] threads: 64, tps: 0.00, reads: 172664.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1189s] threads: 64, tps: 0.00, reads: 173036.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1190s] threads: 64, tps: 0.00, reads: 172614.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1191s] threads: 64, tps: 0.00, reads: 171857.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1192s] threads: 64, tps: 0.00, reads: 172472.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1193s] threads: 64, tps: 0.00, reads: 172548.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1194s] threads: 64, tps: 0.00, reads: 172222.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1195s] threads: 64, tps: 0.00, reads: 172664.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1196s] threads: 64, tps: 0.00, reads: 172859.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1197s] threads: 64, tps: 0.00, reads: 172378.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1198s] threads: 64, tps: 0.00, reads: 172479.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1199s] threads: 64, tps: 0.00, reads: 172218.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1200s] threads: 64, tps: 0.00, reads: 172168.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1201s] threads: 64, tps: 0.00, reads: 171838.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1202s] threads: 64, tps: 0.00, reads: 172343.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1203s] threads: 64, tps: 0.00, reads: 171854.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1204s] threads: 64, tps: 0.00, reads: 171855.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1205s] threads: 64, tps: 0.00, reads: 172090.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1206s] threads: 64, tps: 0.00, reads: 171686.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1207s] threads: 64, tps: 0.00, reads: 172120.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1208s] threads: 64, tps: 0.00, reads: 172167.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1209s] threads: 64, tps: 0.00, reads: 172835.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1210s] threads: 64, tps: 0.00, reads: 172410.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1211s] threads: 64, tps: 0.00, reads: 171908.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1212s] threads: 64, tps: 0.00, reads: 172350.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1213s] threads: 64, tps: 0.00, reads: 172358.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1214s] threads: 64, tps: 0.00, reads: 172793.27, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1215s] threads: 64, tps: 0.00, reads: 173264.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1216s] threads: 64, tps: 0.00, reads: 172262.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1217s] threads: 64, tps: 0.00, reads: 172508.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1218s] threads: 64, tps: 0.00, reads: 172643.02, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1219s] threads: 64, tps: 0.00, reads: 172159.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1220s] threads: 64, tps: 0.00, reads: 172836.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1221s] threads: 64, tps: 0.00, reads: 172232.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1222s] threads: 64, tps: 0.00, reads: 171795.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1223s] threads: 64, tps: 0.00, reads: 172350.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1224s] threads: 64, tps: 0.00, reads: 172735.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1225s] threads: 64, tps: 0.00, reads: 172768.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1226s] threads: 64, tps: 0.00, reads: 172297.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1227s] threads: 64, tps: 0.00, reads: 173238.10, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1228s] threads: 64, tps: 0.00, reads: 172538.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1229s] threads: 64, tps: 0.00, reads: 172601.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1230s] threads: 64, tps: 0.00, reads: 172537.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1231s] threads: 64, tps: 0.00, reads: 172451.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1232s] threads: 64, tps: 0.00, reads: 172676.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1233s] threads: 64, tps: 0.00, reads: 173069.31, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1234s] threads: 64, tps: 0.00, reads: 173186.52, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1235s] threads: 64, tps: 0.00, reads: 172857.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1236s] threads: 64, tps: 0.00, reads: 172375.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1237s] threads: 64, tps: 0.00, reads: 172567.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1238s] threads: 64, tps: 0.00, reads: 172132.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1239s] threads: 64, tps: 0.00, reads: 172360.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1240s] threads: 64, tps: 0.00, reads: 173247.40, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1241s] threads: 64, tps: 0.00, reads: 172484.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1242s] threads: 64, tps: 0.00, reads: 172717.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1243s] threads: 64, tps: 0.00, reads: 172488.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1244s] threads: 64, tps: 0.00, reads: 172377.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1245s] threads: 64, tps: 0.00, reads: 172401.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1246s] threads: 64, tps: 0.00, reads: 173043.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1247s] threads: 64, tps: 0.00, reads: 172344.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1248s] threads: 64, tps: 0.00, reads: 172309.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1249s] threads: 64, tps: 0.00, reads: 172340.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1250s] threads: 64, tps: 0.00, reads: 172385.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1251s] threads: 64, tps: 0.00, reads: 172808.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1252s] threads: 64, tps: 0.00, reads: 172531.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1253s] threads: 64, tps: 0.00, reads: 172752.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1254s] threads: 64, tps: 0.00, reads: 172017.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1255s] threads: 64, tps: 0.00, reads: 172211.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1256s] threads: 64, tps: 0.00, reads: 172193.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1257s] threads: 64, tps: 0.00, reads: 171896.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1258s] threads: 64, tps: 0.00, reads: 171929.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1259s] threads: 64, tps: 0.00, reads: 172967.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1260s] threads: 64, tps: 0.00, reads: 172214.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1261s] threads: 64, tps: 0.00, reads: 172074.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1262s] threads: 64, tps: 0.00, reads: 171804.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1263s] threads: 64, tps: 0.00, reads: 171897.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1264s] threads: 64, tps: 0.00, reads: 172022.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1265s] threads: 64, tps: 0.00, reads: 172081.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1266s] threads: 64, tps: 0.00, reads: 171986.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1267s] threads: 64, tps: 0.00, reads: 172047.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1268s] threads: 64, tps: 0.00, reads: 172418.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1269s] threads: 64, tps: 0.00, reads: 172501.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1270s] threads: 64, tps: 0.00, reads: 172541.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1271s] threads: 64, tps: 0.00, reads: 172884.05, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1272s] threads: 64, tps: 0.00, reads: 173083.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1273s] threads: 64, tps: 0.00, reads: 172102.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1274s] threads: 64, tps: 0.00, reads: 172320.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1275s] threads: 64, tps: 0.00, reads: 172638.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1276s] threads: 64, tps: 0.00, reads: 172856.68, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1277s] threads: 64, tps: 0.00, reads: 172584.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1278s] threads: 64, tps: 0.00, reads: 172796.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1279s] threads: 64, tps: 0.00, reads: 172860.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1280s] threads: 64, tps: 0.00, reads: 172542.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1281s] threads: 64, tps: 0.00, reads: 172873.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1282s] threads: 64, tps: 0.00, reads: 171826.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1283s] threads: 64, tps: 0.00, reads: 172696.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1284s] threads: 64, tps: 0.00, reads: 173320.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1285s] threads: 64, tps: 0.00, reads: 172830.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1286s] threads: 64, tps: 0.00, reads: 172773.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1287s] threads: 64, tps: 0.00, reads: 172473.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1288s] threads: 64, tps: 0.00, reads: 172603.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1289s] threads: 64, tps: 0.00, reads: 172778.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1290s] threads: 64, tps: 0.00, reads: 173070.33, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1291s] threads: 64, tps: 0.00, reads: 173076.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1292s] threads: 64, tps: 0.00, reads: 172488.64, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1293s] threads: 64, tps: 0.00, reads: 172622.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1294s] threads: 64, tps: 0.00, reads: 172597.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1295s] threads: 64, tps: 0.00, reads: 172409.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1296s] threads: 64, tps: 0.00, reads: 172919.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1297s] threads: 64, tps: 0.00, reads: 173204.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1298s] threads: 64, tps: 0.00, reads: 172463.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1299s] threads: 64, tps: 0.00, reads: 172692.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1300s] threads: 64, tps: 0.00, reads: 172530.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1301s] threads: 64, tps: 0.00, reads: 172561.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1302s] threads: 64, tps: 0.00, reads: 172479.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1303s] threads: 64, tps: 0.00, reads: 172741.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1304s] threads: 64, tps: 0.00, reads: 172442.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1305s] threads: 64, tps: 0.00, reads: 172501.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1306s] threads: 64, tps: 0.00, reads: 172388.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1307s] threads: 64, tps: 0.00, reads: 172301.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1308s] threads: 64, tps: 0.00, reads: 172488.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1309s] threads: 64, tps: 0.00, reads: 173507.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1310s] threads: 64, tps: 0.00, reads: 172229.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1311s] threads: 64, tps: 0.00, reads: 171776.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1312s] threads: 64, tps: 0.00, reads: 172086.03, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1313s] threads: 64, tps: 0.00, reads: 172012.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1314s] threads: 64, tps: 0.00, reads: 172087.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1315s] threads: 64, tps: 0.00, reads: 172703.59, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1316s] threads: 64, tps: 0.00, reads: 171887.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1317s] threads: 64, tps: 0.00, reads: 172001.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1318s] threads: 64, tps: 0.00, reads: 171907.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1319s] threads: 64, tps: 0.00, reads: 172115.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1320s] threads: 64, tps: 0.00, reads: 172097.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1321s] threads: 64, tps: 0.00, reads: 172108.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1322s] threads: 64, tps: 0.00, reads: 171874.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1323s] threads: 64, tps: 0.00, reads: 171069.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1324s] threads: 64, tps: 0.00, reads: 172277.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1325s] threads: 64, tps: 0.00, reads: 172493.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1326s] threads: 64, tps: 0.00, reads: 172726.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1327s] threads: 64, tps: 0.00, reads: 172777.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1328s] threads: 64, tps: 0.00, reads: 173003.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1329s] threads: 64, tps: 0.00, reads: 172681.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1330s] threads: 64, tps: 0.00, reads: 172349.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1331s] threads: 64, tps: 0.00, reads: 172410.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1332s] threads: 64, tps: 0.00, reads: 172522.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1333s] threads: 64, tps: 0.00, reads: 172324.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1334s] threads: 64, tps: 0.00, reads: 173598.09, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1335s] threads: 64, tps: 0.00, reads: 172689.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1336s] threads: 64, tps: 0.00, reads: 172815.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1337s] threads: 64, tps: 0.00, reads: 172767.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1338s] threads: 64, tps: 0.00, reads: 172572.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1339s] threads: 64, tps: 0.00, reads: 172874.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1340s] threads: 64, tps: 0.00, reads: 172626.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1341s] threads: 64, tps: 0.00, reads: 173204.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1342s] threads: 64, tps: 0.00, reads: 172664.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1343s] threads: 64, tps: 0.00, reads: 172118.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1344s] threads: 64, tps: 0.00, reads: 172780.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1345s] threads: 64, tps: 0.00, reads: 172575.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1346s] threads: 64, tps: 0.00, reads: 172832.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1347s] threads: 64, tps: 0.00, reads: 173221.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1348s] threads: 64, tps: 0.00, reads: 172784.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1349s] threads: 64, tps: 0.00, reads: 172758.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1350s] threads: 64, tps: 0.00, reads: 172733.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1351s] threads: 64, tps: 0.00, reads: 172619.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1352s] threads: 64, tps: 0.00, reads: 172608.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1353s] threads: 64, tps: 0.00, reads: 172612.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1354s] threads: 64, tps: 0.00, reads: 173102.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1355s] threads: 64, tps: 0.00, reads: 172542.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1356s] threads: 64, tps: 0.00, reads: 172418.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1357s] threads: 64, tps: 0.00, reads: 172583.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1358s] threads: 64, tps: 0.00, reads: 172562.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1359s] threads: 64, tps: 0.00, reads: 172909.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1360s] threads: 64, tps: 0.00, reads: 173294.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1361s] threads: 64, tps: 0.00, reads: 172334.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1362s] threads: 64, tps: 0.00, reads: 172234.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1363s] threads: 64, tps: 0.00, reads: 172141.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1364s] threads: 64, tps: 0.00, reads: 172120.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1365s] threads: 64, tps: 0.00, reads: 172600.40, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1366s] threads: 64, tps: 0.00, reads: 172726.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1367s] threads: 64, tps: 0.00, reads: 172437.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1368s] threads: 64, tps: 0.00, reads: 172275.50, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1369s] threads: 64, tps: 0.00, reads: 172426.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1370s] threads: 64, tps: 0.00, reads: 172391.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1371s] threads: 64, tps: 0.00, reads: 172083.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1372s] threads: 64, tps: 0.00, reads: 172555.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1373s] threads: 64, tps: 0.00, reads: 172085.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1374s] threads: 64, tps: 0.00, reads: 171826.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1375s] threads: 64, tps: 0.00, reads: 172126.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1376s] threads: 64, tps: 0.00, reads: 171801.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1377s] threads: 64, tps: 0.00, reads: 171852.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1378s] threads: 64, tps: 0.00, reads: 172136.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1379s] threads: 64, tps: 0.00, reads: 172777.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1380s] threads: 64, tps: 0.00, reads: 172301.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1381s] threads: 64, tps: 0.00, reads: 171107.50, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1382s] threads: 64, tps: 0.00, reads: 172141.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1383s] threads: 64, tps: 0.00, reads: 172140.37, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1384s] threads: 64, tps: 0.00, reads: 172443.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1385s] threads: 64, tps: 0.00, reads: 172923.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1386s] threads: 64, tps: 0.00, reads: 172541.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1387s] threads: 64, tps: 0.00, reads: 172715.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1388s] threads: 64, tps: 0.00, reads: 172270.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1389s] threads: 64, tps: 0.00, reads: 172756.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1390s] threads: 64, tps: 0.00, reads: 172852.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1391s] threads: 64, tps: 0.00, reads: 173650.73, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1392s] threads: 64, tps: 0.00, reads: 172590.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1393s] threads: 64, tps: 0.00, reads: 172309.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1394s] threads: 64, tps: 0.00, reads: 172748.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1395s] threads: 64, tps: 0.00, reads: 172650.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1396s] threads: 64, tps: 0.00, reads: 172882.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1397s] threads: 64, tps: 0.00, reads: 173330.15, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1398s] threads: 64, tps: 0.00, reads: 172959.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1399s] threads: 64, tps: 0.00, reads: 172593.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1400s] threads: 64, tps: 0.00, reads: 172604.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1401s] threads: 64, tps: 0.00, reads: 172595.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1402s] threads: 64, tps: 0.00, reads: 172761.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1403s] threads: 64, tps: 0.00, reads: 172310.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1404s] threads: 64, tps: 0.00, reads: 173132.06, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1405s] threads: 64, tps: 0.00, reads: 172767.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1406s] threads: 64, tps: 0.00, reads: 172741.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1407s] threads: 64, tps: 0.00, reads: 172745.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1408s] threads: 64, tps: 0.00, reads: 172753.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1409s] threads: 64, tps: 0.00, reads: 172797.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1410s] threads: 64, tps: 0.00, reads: 173340.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1411s] threads: 64, tps: 0.00, reads: 172785.85, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1412s] threads: 64, tps: 0.00, reads: 172474.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1413s] threads: 64, tps: 0.00, reads: 172407.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1414s] threads: 64, tps: 0.00, reads: 172218.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1415s] threads: 64, tps: 0.00, reads: 172649.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1416s] threads: 64, tps: 0.00, reads: 172642.71, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1417s] threads: 64, tps: 0.00, reads: 172879.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1418s] threads: 64, tps: 0.00, reads: 172317.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1419s] threads: 64, tps: 0.00, reads: 172593.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1420s] threads: 64, tps: 0.00, reads: 172737.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1421s] threads: 64, tps: 0.00, reads: 172787.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1422s] threads: 64, tps: 0.00, reads: 172775.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1423s] threads: 64, tps: 0.00, reads: 172833.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1424s] threads: 64, tps: 0.00, reads: 172339.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1425s] threads: 64, tps: 0.00, reads: 172423.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1426s] threads: 64, tps: 0.00, reads: 172081.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1427s] threads: 64, tps: 0.00, reads: 172302.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1428s] threads: 64, tps: 0.00, reads: 172158.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1429s] threads: 64, tps: 0.00, reads: 172896.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1430s] threads: 64, tps: 0.00, reads: 172297.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1431s] threads: 64, tps: 0.00, reads: 172296.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1432s] threads: 64, tps: 0.00, reads: 172593.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1433s] threads: 64, tps: 0.00, reads: 171687.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1434s] threads: 64, tps: 0.00, reads: 171982.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1435s] threads: 64, tps: 0.00, reads: 172034.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1436s] threads: 64, tps: 0.00, reads: 172501.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1437s] threads: 64, tps: 0.00, reads: 171306.23, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1438s] threads: 64, tps: 0.00, reads: 171752.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1439s] threads: 64, tps: 0.00, reads: 171994.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1440s] threads: 64, tps: 0.00, reads: 172246.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1441s] threads: 64, tps: 0.00, reads: 171879.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1442s] threads: 64, tps: 0.00, reads: 172388.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1443s] threads: 64, tps: 0.00, reads: 172503.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1444s] threads: 64, tps: 0.00, reads: 172337.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1445s] threads: 64, tps: 0.00, reads: 172304.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1446s] threads: 64, tps: 0.00, reads: 172167.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1447s] threads: 64, tps: 0.00, reads: 172408.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1448s] threads: 64, tps: 0.00, reads: 172624.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1449s] threads: 64, tps: 0.00, reads: 173335.13, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1450s] threads: 64, tps: 0.00, reads: 172803.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1451s] threads: 64, tps: 0.00, reads: 172522.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1452s] threads: 64, tps: 0.00, reads: 172645.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1453s] threads: 64, tps: 0.00, reads: 172650.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1454s] threads: 64, tps: 0.00, reads: 172403.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1455s] threads: 64, tps: 0.00, reads: 172767.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1456s] threads: 64, tps: 0.00, reads: 172596.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1457s] threads: 64, tps: 0.00, reads: 173140.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1458s] threads: 64, tps: 0.00, reads: 172686.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1459s] threads: 64, tps: 0.00, reads: 172763.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1460s] threads: 64, tps: 0.00, reads: 172175.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1461s] threads: 64, tps: 0.00, reads: 173146.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1462s] threads: 64, tps: 0.00, reads: 172986.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1463s] threads: 64, tps: 0.00, reads: 172718.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1464s] threads: 64, tps: 0.00, reads: 172036.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1465s] threads: 64, tps: 0.00, reads: 172537.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1466s] threads: 64, tps: 0.00, reads: 172723.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1467s] threads: 64, tps: 0.00, reads: 173097.09, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1468s] threads: 64, tps: 0.00, reads: 172982.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1469s] threads: 64, tps: 0.00, reads: 172549.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1470s] threads: 64, tps: 0.00, reads: 172418.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1471s] threads: 64, tps: 0.00, reads: 172509.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1472s] threads: 64, tps: 0.00, reads: 172675.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1473s] threads: 64, tps: 0.00, reads: 173114.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1474s] threads: 64, tps: 0.00, reads: 173063.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1475s] threads: 64, tps: 0.00, reads: 172383.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1476s] threads: 64, tps: 0.00, reads: 172509.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1477s] threads: 64, tps: 0.00, reads: 172232.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1478s] threads: 64, tps: 0.00, reads: 172578.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1479s] threads: 64, tps: 0.00, reads: 172540.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1480s] threads: 64, tps: 0.00, reads: 172967.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1481s] threads: 64, tps: 0.00, reads: 172546.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1482s] threads: 64, tps: 0.00, reads: 172744.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1483s] threads: 64, tps: 0.00, reads: 172613.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1484s] threads: 64, tps: 0.00, reads: 172589.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1485s] threads: 64, tps: 0.00, reads: 172114.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1486s] threads: 64, tps: 0.00, reads: 172964.54, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1487s] threads: 64, tps: 0.00, reads: 172229.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1488s] threads: 64, tps: 0.00, reads: 172312.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1489s] threads: 64, tps: 0.00, reads: 172209.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1490s] threads: 64, tps: 0.00, reads: 172058.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1491s] threads: 64, tps: 0.00, reads: 172033.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1492s] threads: 64, tps: 0.00, reads: 172066.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1493s] threads: 64, tps: 0.00, reads: 172736.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1494s] threads: 64, tps: 0.00, reads: 172158.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1495s] threads: 64, tps: 0.00, reads: 171465.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1496s] threads: 64, tps: 0.00, reads: 172056.94, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1497s] threads: 64, tps: 0.00, reads: 171422.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1498s] threads: 64, tps: 0.00, reads: 171890.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1499s] threads: 64, tps: 0.00, reads: 172321.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1500s] threads: 64, tps: 0.00, reads: 172160.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1501s] threads: 64, tps: 0.00, reads: 172178.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1502s] threads: 64, tps: 0.00, reads: 172116.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1503s] threads: 64, tps: 0.00, reads: 172485.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1504s] threads: 64, tps: 0.00, reads: 172617.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1505s] threads: 64, tps: 0.00, reads: 172649.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1506s] threads: 64, tps: 0.00, reads: 173149.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1507s] threads: 64, tps: 0.00, reads: 172908.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1508s] threads: 64, tps: 0.00, reads: 172471.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1509s] threads: 64, tps: 0.00, reads: 172331.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1510s] threads: 64, tps: 0.00, reads: 172164.99, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1511s] threads: 64, tps: 0.00, reads: 172674.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1512s] threads: 64, tps: 0.00, reads: 173413.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1513s] threads: 64, tps: 0.00, reads: 172772.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1514s] threads: 64, tps: 0.00, reads: 172810.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1515s] threads: 64, tps: 0.00, reads: 172554.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1516s] threads: 64, tps: 0.00, reads: 172771.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1517s] threads: 64, tps: 0.00, reads: 172687.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1518s] threads: 64, tps: 0.00, reads: 173452.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1519s] threads: 64, tps: 0.00, reads: 172269.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1520s] threads: 64, tps: 0.00, reads: 171507.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1521s] threads: 64, tps: 0.00, reads: 171800.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1522s] threads: 64, tps: 0.00, reads: 172151.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1523s] threads: 64, tps: 0.00, reads: 172545.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1524s] threads: 64, tps: 0.00, reads: 172491.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1525s] threads: 64, tps: 0.00, reads: 172788.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1526s] threads: 64, tps: 0.00, reads: 172802.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1527s] threads: 64, tps: 0.00, reads: 172667.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1528s] threads: 64, tps: 0.00, reads: 172812.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1529s] threads: 64, tps: 0.00, reads: 172641.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1530s] threads: 64, tps: 0.00, reads: 172918.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1531s] threads: 64, tps: 0.00, reads: 173462.25, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1532s] threads: 64, tps: 0.00, reads: 172794.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1533s] threads: 64, tps: 0.00, reads: 172779.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1534s] threads: 64, tps: 0.00, reads: 172499.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1535s] threads: 64, tps: 0.00, reads: 172363.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1536s] threads: 64, tps: 0.00, reads: 172320.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1537s] threads: 64, tps: 0.00, reads: 173156.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1538s] threads: 64, tps: 0.00, reads: 172487.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1539s] threads: 64, tps: 0.00, reads: 172382.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1540s] threads: 64, tps: 0.00, reads: 172516.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1541s] threads: 64, tps: 0.00, reads: 172380.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1542s] threads: 64, tps: 0.00, reads: 172325.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1543s] threads: 64, tps: 0.00, reads: 172758.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1544s] threads: 64, tps: 0.00, reads: 172863.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1545s] threads: 64, tps: 0.00, reads: 172164.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1546s] threads: 64, tps: 0.00, reads: 172479.04, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1547s] threads: 64, tps: 0.00, reads: 172300.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1548s] threads: 64, tps: 0.00, reads: 172810.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1549s] threads: 64, tps: 0.00, reads: 172378.39, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[1550s] threads: 64, tps: 0.00, reads: 172211.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1551s] threads: 64, tps: 0.00, reads: 171645.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1552s] threads: 64, tps: 0.00, reads: 171645.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1553s] threads: 64, tps: 0.00, reads: 171225.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1554s] threads: 64, tps: 0.00, reads: 172001.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1555s] threads: 64, tps: 0.00, reads: 171965.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1556s] threads: 64, tps: 0.00, reads: 172225.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1557s] threads: 64, tps: 0.00, reads: 172499.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1558s] threads: 64, tps: 0.00, reads: 172249.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1559s] threads: 64, tps: 0.00, reads: 172451.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1560s] threads: 64, tps: 0.00, reads: 172503.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1561s] threads: 64, tps: 0.00, reads: 172046.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1562s] threads: 64, tps: 0.00, reads: 172351.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1563s] threads: 64, tps: 0.00, reads: 173013.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1564s] threads: 64, tps: 0.00, reads: 172565.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1565s] threads: 64, tps: 0.00, reads: 172411.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1566s] threads: 64, tps: 0.00, reads: 172268.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1567s] threads: 64, tps: 0.00, reads: 172314.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1568s] threads: 64, tps: 0.00, reads: 172911.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1569s] threads: 64, tps: 0.00, reads: 173330.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1570s] threads: 64, tps: 0.00, reads: 172814.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1571s] threads: 64, tps: 0.00, reads: 172659.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1572s] threads: 64, tps: 0.00, reads: 172589.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1573s] threads: 64, tps: 0.00, reads: 172870.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1574s] threads: 64, tps: 0.00, reads: 172751.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1575s] threads: 64, tps: 0.00, reads: 173186.94, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1576s] threads: 64, tps: 0.00, reads: 172697.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1577s] threads: 64, tps: 0.00, reads: 172423.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1578s] threads: 64, tps: 0.00, reads: 172827.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1579s] threads: 64, tps: 0.00, reads: 172729.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1580s] threads: 64, tps: 0.00, reads: 172924.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1581s] threads: 64, tps: 0.00, reads: 172824.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1582s] threads: 64, tps: 0.00, reads: 173242.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1583s] threads: 64, tps: 0.00, reads: 172852.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1584s] threads: 64, tps: 0.00, reads: 172712.28, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1585s] threads: 64, tps: 0.00, reads: 172884.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1586s] threads: 64, tps: 0.00, reads: 172478.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1587s] threads: 64, tps: 0.00, reads: 172835.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1588s] threads: 64, tps: 0.00, reads: 173361.45, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1589s] threads: 64, tps: 0.00, reads: 172579.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1590s] threads: 64, tps: 0.00, reads: 172858.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1591s] threads: 64, tps: 0.00, reads: 172669.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1592s] threads: 64, tps: 0.00, reads: 172442.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1593s] threads: 64, tps: 0.00, reads: 172646.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1594s] threads: 64, tps: 0.00, reads: 173346.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1595s] threads: 64, tps: 0.00, reads: 172856.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1596s] threads: 64, tps: 0.00, reads: 172686.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1597s] threads: 64, tps: 0.00, reads: 172731.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1598s] threads: 64, tps: 0.00, reads: 172440.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1599s] threads: 64, tps: 0.00, reads: 172577.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1600s] threads: 64, tps: 0.00, reads: 173259.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1601s] threads: 64, tps: 0.00, reads: 172238.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1602s] threads: 64, tps: 0.00, reads: 172049.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1603s] threads: 64, tps: 0.00, reads: 172312.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1604s] threads: 64, tps: 0.00, reads: 172371.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1605s] threads: 64, tps: 0.00, reads: 172751.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1606s] threads: 64, tps: 0.00, reads: 172850.05, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1607s] threads: 64, tps: 0.00, reads: 172441.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1608s] threads: 64, tps: 0.00, reads: 172560.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1609s] threads: 64, tps: 0.00, reads: 172707.50, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1610s] threads: 64, tps: 0.00, reads: 172103.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1611s] threads: 64, tps: 0.00, reads: 171643.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1612s] threads: 64, tps: 0.00, reads: 172506.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1613s] threads: 64, tps: 0.00, reads: 172666.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1614s] threads: 64, tps: 0.00, reads: 171874.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1615s] threads: 64, tps: 0.00, reads: 171953.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1616s] threads: 64, tps: 0.00, reads: 171639.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1617s] threads: 64, tps: 0.00, reads: 171959.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1618s] threads: 64, tps: 0.00, reads: 172352.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1619s] threads: 64, tps: 0.00, reads: 172922.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1620s] threads: 64, tps: 0.00, reads: 172554.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1621s] threads: 64, tps: 0.00, reads: 172405.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1622s] threads: 64, tps: 0.00, reads: 172469.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1623s] threads: 64, tps: 0.00, reads: 172759.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1624s] threads: 64, tps: 0.00, reads: 172810.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1625s] threads: 64, tps: 0.00, reads: 173472.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1626s] threads: 64, tps: 0.00, reads: 172653.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1627s] threads: 64, tps: 0.00, reads: 172366.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1628s] threads: 64, tps: 0.00, reads: 172647.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1629s] threads: 64, tps: 0.00, reads: 172853.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1630s] threads: 64, tps: 0.00, reads: 172420.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1631s] threads: 64, tps: 0.00, reads: 173087.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1632s] threads: 64, tps: 0.00, reads: 172886.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1633s] threads: 64, tps: 0.00, reads: 172863.94, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1634s] threads: 64, tps: 0.00, reads: 172896.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1635s] threads: 64, tps: 0.00, reads: 172902.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1636s] threads: 64, tps: 0.00, reads: 173092.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1637s] threads: 64, tps: 0.00, reads: 172841.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1638s] threads: 64, tps: 0.00, reads: 173774.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1639s] threads: 64, tps: 0.00, reads: 172608.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1640s] threads: 64, tps: 0.00, reads: 172580.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1641s] threads: 64, tps: 0.00, reads: 172382.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1642s] threads: 64, tps: 0.00, reads: 172427.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1643s] threads: 64, tps: 0.00, reads: 173131.24, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1644s] threads: 64, tps: 0.00, reads: 173227.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1645s] threads: 64, tps: 0.00, reads: 172985.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1646s] threads: 64, tps: 0.00, reads: 173282.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1647s] threads: 64, tps: 0.00, reads: 172562.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1648s] threads: 64, tps: 0.00, reads: 172776.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1649s] threads: 64, tps: 0.00, reads: 173065.55, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1650s] threads: 64, tps: 0.00, reads: 173579.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1651s] threads: 64, tps: 0.00, reads: 172400.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1652s] threads: 64, tps: 0.00, reads: 172327.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1653s] threads: 64, tps: 0.00, reads: 172527.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1654s] threads: 64, tps: 0.00, reads: 172743.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1655s] threads: 64, tps: 0.00, reads: 172504.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1656s] threads: 64, tps: 0.00, reads: 173282.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1657s] threads: 64, tps: 0.00, reads: 172717.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1658s] threads: 64, tps: 0.00, reads: 172440.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1659s] threads: 64, tps: 0.00, reads: 172661.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1660s] threads: 64, tps: 0.00, reads: 172596.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1661s] threads: 64, tps: 0.00, reads: 172600.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1662s] threads: 64, tps: 0.00, reads: 172684.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1663s] threads: 64, tps: 0.00, reads: 173045.48, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1664s] threads: 64, tps: 0.00, reads: 172563.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1665s] threads: 64, tps: 0.00, reads: 172540.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1666s] threads: 64, tps: 0.00, reads: 172499.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1667s] threads: 64, tps: 0.00, reads: 172119.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1668s] threads: 64, tps: 0.00, reads: 172449.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1669s] threads: 64, tps: 0.00, reads: 172625.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1670s] threads: 64, tps: 0.00, reads: 171872.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1671s] threads: 64, tps: 0.00, reads: 171932.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1672s] threads: 64, tps: 0.00, reads: 171691.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1673s] threads: 64, tps: 0.00, reads: 171838.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1674s] threads: 64, tps: 0.00, reads: 171957.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1675s] threads: 64, tps: 0.00, reads: 172621.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1676s] threads: 64, tps: 0.00, reads: 171957.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1677s] threads: 64, tps: 0.00, reads: 171903.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1678s] threads: 64, tps: 0.00, reads: 172391.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1679s] threads: 64, tps: 0.00, reads: 172820.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1680s] threads: 64, tps: 0.00, reads: 172217.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1681s] threads: 64, tps: 0.00, reads: 172936.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1682s] threads: 64, tps: 0.00, reads: 172322.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1683s] threads: 64, tps: 0.00, reads: 172388.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1684s] threads: 64, tps: 0.00, reads: 172724.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1685s] threads: 64, tps: 0.00, reads: 172761.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1686s] threads: 64, tps: 0.00, reads: 172605.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1687s] threads: 64, tps: 0.00, reads: 172845.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1688s] threads: 64, tps: 0.00, reads: 173451.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1689s] threads: 64, tps: 0.00, reads: 172865.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1690s] threads: 64, tps: 0.00, reads: 172938.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1691s] threads: 64, tps: 0.00, reads: 172722.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1692s] threads: 64, tps: 0.00, reads: 172590.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1693s] threads: 64, tps: 0.00, reads: 173056.09, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1694s] threads: 64, tps: 0.00, reads: 173310.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1695s] threads: 64, tps: 0.00, reads: 172771.94, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1696s] threads: 64, tps: 0.00, reads: 172928.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1697s] threads: 64, tps: 0.00, reads: 172319.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1698s] threads: 64, tps: 0.00, reads: 173030.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1699s] threads: 64, tps: 0.00, reads: 173118.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1700s] threads: 64, tps: 0.00, reads: 173719.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1701s] threads: 64, tps: 0.00, reads: 172745.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1702s] threads: 64, tps: 0.00, reads: 172484.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1703s] threads: 64, tps: 0.00, reads: 172806.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1704s] threads: 64, tps: 0.00, reads: 172547.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1705s] threads: 64, tps: 0.00, reads: 173192.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1706s] threads: 64, tps: 0.00, reads: 173595.76, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1707s] threads: 64, tps: 0.00, reads: 173046.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1708s] threads: 64, tps: 0.00, reads: 172444.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1709s] threads: 64, tps: 0.00, reads: 172564.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1710s] threads: 64, tps: 0.00, reads: 172789.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1711s] threads: 64, tps: 0.00, reads: 172621.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1712s] threads: 64, tps: 0.00, reads: 172174.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1713s] threads: 64, tps: 0.00, reads: 173409.54, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1714s] threads: 64, tps: 0.00, reads: 172710.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1715s] threads: 64, tps: 0.00, reads: 172645.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1716s] threads: 64, tps: 0.00, reads: 172719.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1717s] threads: 64, tps: 0.00, reads: 172558.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1718s] threads: 64, tps: 0.00, reads: 172434.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1719s] threads: 64, tps: 0.00, reads: 173494.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1720s] threads: 64, tps: 0.00, reads: 172870.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1721s] threads: 64, tps: 0.00, reads: 172638.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1722s] threads: 64, tps: 0.00, reads: 172204.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1723s] threads: 64, tps: 0.00, reads: 171954.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1724s] threads: 64, tps: 0.00, reads: 172446.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1725s] threads: 64, tps: 0.00, reads: 172641.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1726s] threads: 64, tps: 0.00, reads: 172863.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1727s] threads: 64, tps: 0.00, reads: 172317.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1728s] threads: 64, tps: 0.00, reads: 171794.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1729s] threads: 64, tps: 0.00, reads: 172431.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1730s] threads: 64, tps: 0.00, reads: 172324.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1731s] threads: 64, tps: 0.00, reads: 172145.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1732s] threads: 64, tps: 0.00, reads: 172699.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1733s] threads: 64, tps: 0.00, reads: 172094.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1734s] threads: 64, tps: 0.00, reads: 171947.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1735s] threads: 64, tps: 0.00, reads: 171924.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1736s] threads: 64, tps: 0.00, reads: 171919.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1737s] threads: 64, tps: 0.00, reads: 171861.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1738s] threads: 64, tps: 0.00, reads: 172683.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1739s] threads: 64, tps: 0.00, reads: 172403.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1740s] threads: 64, tps: 0.00, reads: 172477.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1741s] threads: 64, tps: 0.00, reads: 171908.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1742s] threads: 64, tps: 0.00, reads: 172044.90, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1743s] threads: 64, tps: 0.00, reads: 172328.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1744s] threads: 64, tps: 0.00, reads: 173185.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1745s] threads: 64, tps: 0.00, reads: 172861.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1746s] threads: 64, tps: 0.00, reads: 172872.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1747s] threads: 64, tps: 0.00, reads: 173004.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1748s] threads: 64, tps: 0.00, reads: 172683.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1749s] threads: 64, tps: 0.00, reads: 172682.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1750s] threads: 64, tps: 0.00, reads: 172890.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1751s] threads: 64, tps: 0.00, reads: 173095.66, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1752s] threads: 64, tps: 0.00, reads: 172622.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1753s] threads: 64, tps: 0.00, reads: 172491.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1754s] threads: 64, tps: 0.00, reads: 173052.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1755s] threads: 64, tps: 0.00, reads: 172382.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1756s] threads: 64, tps: 0.00, reads: 173282.09, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1757s] threads: 64, tps: 0.00, reads: 173022.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1758s] threads: 64, tps: 0.00, reads: 172725.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1759s] threads: 64, tps: 0.00, reads: 172443.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1760s] threads: 64, tps: 0.00, reads: 172673.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1761s] threads: 64, tps: 0.00, reads: 172734.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1762s] threads: 64, tps: 0.00, reads: 172751.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1763s] threads: 64, tps: 0.00, reads: 173609.15, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1764s] threads: 64, tps: 0.00, reads: 172386.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1765s] threads: 64, tps: 0.00, reads: 172527.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1766s] threads: 64, tps: 0.00, reads: 172786.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1767s] threads: 64, tps: 0.00, reads: 172696.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1768s] threads: 64, tps: 0.00, reads: 172823.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1769s] threads: 64, tps: 0.00, reads: 173397.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1770s] threads: 64, tps: 0.00, reads: 172635.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1771s] threads: 64, tps: 0.00, reads: 173074.10, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1772s] threads: 64, tps: 0.00, reads: 172739.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1773s] threads: 64, tps: 0.00, reads: 172661.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1774s] threads: 64, tps: 0.00, reads: 172499.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1775s] threads: 64, tps: 0.00, reads: 173227.58, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1776s] threads: 64, tps: 0.00, reads: 172588.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1777s] threads: 64, tps: 0.00, reads: 172530.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1778s] threads: 64, tps: 0.00, reads: 172511.78, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1779s] threads: 64, tps: 0.00, reads: 172647.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1780s] threads: 64, tps: 0.00, reads: 172275.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1781s] threads: 64, tps: 0.00, reads: 173010.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1782s] threads: 64, tps: 0.00, reads: 172753.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1783s] threads: 64, tps: 0.00, reads: 172534.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1784s] threads: 64, tps: 0.00, reads: 172616.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1785s] threads: 64, tps: 0.00, reads: 172586.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1786s] threads: 64, tps: 0.00, reads: 172747.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1787s] threads: 64, tps: 0.00, reads: 172995.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1788s] threads: 64, tps: 0.00, reads: 172842.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1789s] threads: 64, tps: 0.00, reads: 171795.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1790s] threads: 64, tps: 0.00, reads: 170697.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1791s] threads: 64, tps: 0.00, reads: 171713.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1792s] threads: 64, tps: 0.00, reads: 171776.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1793s] threads: 64, tps: 0.00, reads: 171936.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1794s] threads: 64, tps: 0.00, reads: 172100.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1795s] threads: 64, tps: 0.00, reads: 172165.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1796s] threads: 64, tps: 0.00, reads: 172028.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1797s] threads: 64, tps: 0.00, reads: 172060.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1798s] threads: 64, tps: 0.00, reads: 172174.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1799s] threads: 64, tps: 0.00, reads: 172117.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1800s] threads: 64, tps: 0.00, reads: 172640.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1801s] threads: 64, tps: 0.00, reads: 173254.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1802s] threads: 64, tps: 0.00, reads: 172578.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1803s] threads: 64, tps: 0.00, reads: 172919.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1804s] threads: 64, tps: 0.00, reads: 172656.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1805s] threads: 64, tps: 0.00, reads: 172241.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1806s] threads: 64, tps: 0.00, reads: 172518.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1807s] threads: 64, tps: 0.00, reads: 172908.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1808s] threads: 64, tps: 0.00, reads: 172821.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1809s] threads: 64, tps: 0.00, reads: 172437.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1810s] threads: 64, tps: 0.00, reads: 172516.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1811s] threads: 64, tps: 0.00, reads: 172782.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1812s] threads: 64, tps: 0.00, reads: 172818.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1813s] threads: 64, tps: 0.00, reads: 173028.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1814s] threads: 64, tps: 0.00, reads: 173121.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1815s] threads: 64, tps: 0.00, reads: 172623.04, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1816s] threads: 64, tps: 0.00, reads: 172853.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1817s] threads: 64, tps: 0.00, reads: 172833.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1818s] threads: 64, tps: 0.00, reads: 172657.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1819s] threads: 64, tps: 0.00, reads: 171693.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1820s] threads: 64, tps: 0.00, reads: 173332.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1821s] threads: 64, tps: 0.00, reads: 172558.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1822s] threads: 64, tps: 0.00, reads: 172268.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1823s] threads: 64, tps: 0.00, reads: 171957.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1824s] threads: 64, tps: 0.00, reads: 172443.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1825s] threads: 64, tps: 0.00, reads: 172691.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1826s] threads: 64, tps: 0.00, reads: 172713.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1827s] threads: 64, tps: 0.00, reads: 172940.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1828s] threads: 64, tps: 0.00, reads: 172816.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1829s] threads: 64, tps: 0.00, reads: 172387.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1830s] threads: 64, tps: 0.00, reads: 172617.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1831s] threads: 64, tps: 0.00, reads: 172617.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1832s] threads: 64, tps: 0.00, reads: 173158.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1833s] threads: 64, tps: 0.00, reads: 173252.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1834s] threads: 64, tps: 0.00, reads: 172727.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1835s] threads: 64, tps: 0.00, reads: 172917.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1836s] threads: 64, tps: 0.00, reads: 172486.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1837s] threads: 64, tps: 0.00, reads: 172542.08, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1838s] threads: 64, tps: 0.00, reads: 172912.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1839s] threads: 64, tps: 0.00, reads: 172792.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1840s] threads: 64, tps: 0.00, reads: 172514.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1841s] threads: 64, tps: 0.00, reads: 171994.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1842s] threads: 64, tps: 0.00, reads: 172302.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1843s] threads: 64, tps: 0.00, reads: 172315.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1844s] threads: 64, tps: 0.00, reads: 172574.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1845s] threads: 64, tps: 0.00, reads: 173413.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1846s] threads: 64, tps: 0.00, reads: 172671.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1847s] threads: 64, tps: 0.00, reads: 172249.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1848s] threads: 64, tps: 0.00, reads: 172458.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1849s] threads: 64, tps: 0.00, reads: 172408.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1850s] threads: 64, tps: 0.00, reads: 172172.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1851s] threads: 64, tps: 0.00, reads: 172404.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1852s] threads: 64, tps: 0.00, reads: 171553.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1853s] threads: 64, tps: 0.00, reads: 172106.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1854s] threads: 64, tps: 0.00, reads: 172203.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1855s] threads: 64, tps: 0.00, reads: 172001.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1856s] threads: 64, tps: 0.00, reads: 171630.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1857s] threads: 64, tps: 0.00, reads: 172245.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1858s] threads: 64, tps: 0.00, reads: 172568.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1859s] threads: 64, tps: 0.00, reads: 171866.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1860s] threads: 64, tps: 0.00, reads: 172132.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1861s] threads: 64, tps: 0.00, reads: 172426.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1862s] threads: 64, tps: 0.00, reads: 172943.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1863s] threads: 64, tps: 0.00, reads: 172926.13, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1864s] threads: 64, tps: 0.00, reads: 173053.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1865s] threads: 64, tps: 0.00, reads: 172654.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1866s] threads: 64, tps: 0.00, reads: 172566.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1867s] threads: 64, tps: 0.00, reads: 172848.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1868s] threads: 64, tps: 0.00, reads: 172705.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1869s] threads: 64, tps: 0.00, reads: 172613.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1870s] threads: 64, tps: 0.00, reads: 173572.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1871s] threads: 64, tps: 0.00, reads: 172531.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1872s] threads: 64, tps: 0.00, reads: 172747.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1873s] threads: 64, tps: 0.00, reads: 172464.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1874s] threads: 64, tps: 0.00, reads: 172803.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1875s] threads: 64, tps: 0.00, reads: 172605.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1876s] threads: 64, tps: 0.00, reads: 173475.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1877s] threads: 64, tps: 0.00, reads: 172777.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1878s] threads: 64, tps: 0.00, reads: 173016.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1879s] threads: 64, tps: 0.00, reads: 173004.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1880s] threads: 64, tps: 0.00, reads: 172223.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1881s] threads: 64, tps: 0.00, reads: 172804.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1882s] threads: 64, tps: 0.00, reads: 172825.16, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1883s] threads: 64, tps: 0.00, reads: 172933.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1884s] threads: 64, tps: 0.00, reads: 172579.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1885s] threads: 64, tps: 0.00, reads: 172457.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1886s] threads: 64, tps: 0.00, reads: 172750.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1887s] threads: 64, tps: 0.00, reads: 172577.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1888s] threads: 64, tps: 0.00, reads: 173014.63, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1889s] threads: 64, tps: 0.00, reads: 173182.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1890s] threads: 64, tps: 0.00, reads: 172728.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1891s] threads: 64, tps: 0.00, reads: 172553.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1892s] threads: 64, tps: 0.00, reads: 172827.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1893s] threads: 64, tps: 0.00, reads: 172631.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1894s] threads: 64, tps: 0.00, reads: 173196.23, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1895s] threads: 64, tps: 0.00, reads: 173007.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1896s] threads: 64, tps: 0.00, reads: 172624.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1897s] threads: 64, tps: 0.00, reads: 172632.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1898s] threads: 64, tps: 0.00, reads: 172612.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1899s] threads: 64, tps: 0.00, reads: 172717.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1900s] threads: 64, tps: 0.00, reads: 172524.27, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1901s] threads: 64, tps: 0.00, reads: 173003.73, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1902s] threads: 64, tps: 0.00, reads: 172577.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1903s] threads: 64, tps: 0.00, reads: 172426.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1904s] threads: 64, tps: 0.00, reads: 171798.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1905s] threads: 64, tps: 0.00, reads: 172067.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1906s] threads: 64, tps: 0.00, reads: 172053.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1907s] threads: 64, tps: 0.00, reads: 173058.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1908s] threads: 64, tps: 0.00, reads: 172806.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1909s] threads: 64, tps: 0.00, reads: 172284.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1910s] threads: 64, tps: 0.00, reads: 172013.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1911s] threads: 64, tps: 0.00, reads: 171882.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1912s] threads: 64, tps: 0.00, reads: 171915.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1913s] threads: 64, tps: 0.00, reads: 172157.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1914s] threads: 64, tps: 0.00, reads: 172378.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1915s] threads: 64, tps: 0.00, reads: 172145.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1916s] threads: 64, tps: 0.00, reads: 172027.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1917s] threads: 64, tps: 0.00, reads: 172238.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1918s] threads: 64, tps: 0.00, reads: 172226.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1919s] threads: 64, tps: 0.00, reads: 172760.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1920s] threads: 64, tps: 0.00, reads: 173099.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1921s] threads: 64, tps: 0.00, reads: 172557.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1922s] threads: 64, tps: 0.00, reads: 172280.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1923s] threads: 64, tps: 0.00, reads: 172466.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1924s] threads: 64, tps: 0.00, reads: 172484.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1925s] threads: 64, tps: 0.00, reads: 172245.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1926s] threads: 64, tps: 0.00, reads: 172572.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1927s] threads: 64, tps: 0.00, reads: 173071.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1928s] threads: 64, tps: 0.00, reads: 172934.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1929s] threads: 64, tps: 0.00, reads: 172730.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1930s] threads: 64, tps: 0.00, reads: 172579.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1931s] threads: 64, tps: 0.00, reads: 172644.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1932s] threads: 64, tps: 0.00, reads: 172822.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1933s] threads: 64, tps: 0.00, reads: 173577.17, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1934s] threads: 64, tps: 0.00, reads: 172907.79, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1935s] threads: 64, tps: 0.00, reads: 172850.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1936s] threads: 64, tps: 0.00, reads: 172862.95, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1937s] threads: 64, tps: 0.00, reads: 172921.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1938s] threads: 64, tps: 0.00, reads: 172970.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1939s] threads: 64, tps: 0.00, reads: 173628.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1940s] threads: 64, tps: 0.00, reads: 172503.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1941s] threads: 64, tps: 0.00, reads: 172496.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1942s] threads: 64, tps: 0.00, reads: 172647.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1943s] threads: 64, tps: 0.00, reads: 172794.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1944s] threads: 64, tps: 0.00, reads: 173100.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1945s] threads: 64, tps: 0.00, reads: 173085.33, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1946s] threads: 64, tps: 0.00, reads: 172822.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1947s] threads: 64, tps: 0.00, reads: 172806.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1948s] threads: 64, tps: 0.00, reads: 172854.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1949s] threads: 64, tps: 0.00, reads: 172961.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1950s] threads: 64, tps: 0.00, reads: 172861.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1951s] threads: 64, tps: 0.00, reads: 172739.48, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1952s] threads: 64, tps: 0.00, reads: 173361.07, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1953s] threads: 64, tps: 0.00, reads: 172784.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1954s] threads: 64, tps: 0.00, reads: 172774.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1955s] threads: 64, tps: 0.00, reads: 172743.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1956s] threads: 64, tps: 0.00, reads: 172485.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1957s] threads: 64, tps: 0.00, reads: 172811.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1958s] threads: 64, tps: 0.00, reads: 173104.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1959s] threads: 64, tps: 0.00, reads: 172704.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1960s] threads: 64, tps: 0.00, reads: 172739.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1961s] threads: 64, tps: 0.00, reads: 172375.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1962s] threads: 64, tps: 0.00, reads: 172185.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1963s] threads: 64, tps: 0.00, reads: 172417.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1964s] threads: 64, tps: 0.00, reads: 173101.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1965s] threads: 64, tps: 0.00, reads: 172497.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1966s] threads: 64, tps: 0.00, reads: 172096.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1967s] threads: 64, tps: 0.00, reads: 172403.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1968s] threads: 64, tps: 0.00, reads: 172543.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1969s] threads: 64, tps: 0.00, reads: 172591.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1970s] threads: 64, tps: 0.00, reads: 172621.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1971s] threads: 64, tps: 0.00, reads: 172213.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1972s] threads: 64, tps: 0.00, reads: 171867.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1973s] threads: 64, tps: 0.00, reads: 172040.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1974s] threads: 64, tps: 0.00, reads: 172054.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1975s] threads: 64, tps: 0.00, reads: 172201.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1976s] threads: 64, tps: 0.00, reads: 171940.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1977s] threads: 64, tps: 0.00, reads: 172860.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1978s] threads: 64, tps: 0.00, reads: 172181.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1979s] threads: 64, tps: 0.00, reads: 172457.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1980s] threads: 64, tps: 0.00, reads: 172561.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1981s] threads: 64, tps: 0.00, reads: 171419.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1982s] threads: 64, tps: 0.00, reads: 172554.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1983s] threads: 64, tps: 0.00, reads: 173201.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1984s] threads: 64, tps: 0.00, reads: 172706.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1985s] threads: 64, tps: 0.00, reads: 172553.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1986s] threads: 64, tps: 0.00, reads: 172565.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1987s] threads: 64, tps: 0.00, reads: 172471.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1988s] threads: 64, tps: 0.00, reads: 172515.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1989s] threads: 64, tps: 0.00, reads: 173086.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1990s] threads: 64, tps: 0.00, reads: 173031.73, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1991s] threads: 64, tps: 0.00, reads: 171993.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1992s] threads: 64, tps: 0.00, reads: 172579.90, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[1993s] threads: 64, tps: 0.00, reads: 172767.23, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1994s] threads: 64, tps: 0.00, reads: 173156.86, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1995s] threads: 64, tps: 0.00, reads: 173276.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1996s] threads: 64, tps: 0.00, reads: 172807.90, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[1997s] threads: 64, tps: 0.00, reads: 172814.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1998s] threads: 64, tps: 0.00, reads: 172954.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[1999s] threads: 64, tps: 0.00, reads: 173033.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2000s] threads: 64, tps: 0.00, reads: 172749.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2001s] threads: 64, tps: 0.00, reads: 172674.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2002s] threads: 64, tps: 0.00, reads: 173538.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2003s] threads: 64, tps: 0.00, reads: 172811.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2004s] threads: 64, tps: 0.00, reads: 172674.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2005s] threads: 64, tps: 0.00, reads: 172773.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2006s] threads: 64, tps: 0.00, reads: 172419.50, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2007s] threads: 64, tps: 0.00, reads: 172873.27, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2008s] threads: 64, tps: 0.00, reads: 173393.87, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2009s] threads: 64, tps: 0.00, reads: 172724.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2010s] threads: 64, tps: 0.00, reads: 172994.09, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2011s] threads: 64, tps: 0.00, reads: 172579.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2012s] threads: 64, tps: 0.00, reads: 172939.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2013s] threads: 64, tps: 0.00, reads: 172105.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2014s] threads: 64, tps: 0.00, reads: 173454.08, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2015s] threads: 64, tps: 0.00, reads: 172533.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2016s] threads: 64, tps: 0.00, reads: 172376.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2017s] threads: 64, tps: 0.00, reads: 172512.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2018s] threads: 64, tps: 0.00, reads: 172521.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2019s] threads: 64, tps: 0.00, reads: 172739.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2020s] threads: 64, tps: 0.00, reads: 173128.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2021s] threads: 64, tps: 0.00, reads: 172501.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2022s] threads: 64, tps: 0.00, reads: 172501.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2023s] threads: 64, tps: 0.00, reads: 172382.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2024s] threads: 64, tps: 0.00, reads: 172480.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2025s] threads: 64, tps: 0.00, reads: 172311.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2026s] threads: 64, tps: 0.00, reads: 172697.92, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2027s] threads: 64, tps: 0.00, reads: 172641.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2028s] threads: 64, tps: 0.00, reads: 172727.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2029s] threads: 64, tps: 0.00, reads: 172447.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2030s] threads: 64, tps: 0.00, reads: 172215.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2031s] threads: 64, tps: 0.00, reads: 171627.82, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2032s] threads: 64, tps: 0.00, reads: 172029.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2033s] threads: 64, tps: 0.00, reads: 172975.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2034s] threads: 64, tps: 0.00, reads: 172232.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2035s] threads: 64, tps: 0.00, reads: 171066.38, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2036s] threads: 64, tps: 0.00, reads: 171911.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2037s] threads: 64, tps: 0.00, reads: 171391.85, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2038s] threads: 64, tps: 0.00, reads: 171738.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2039s] threads: 64, tps: 0.00, reads: 172866.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2040s] threads: 64, tps: 0.00, reads: 171867.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2041s] threads: 64, tps: 0.00, reads: 172020.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2042s] threads: 64, tps: 0.00, reads: 172006.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2043s] threads: 64, tps: 0.00, reads: 172654.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2044s] threads: 64, tps: 0.00, reads: 172602.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2045s] threads: 64, tps: 0.00, reads: 173459.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2046s] threads: 64, tps: 0.00, reads: 172976.34, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2047s] threads: 64, tps: 0.00, reads: 172684.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2048s] threads: 64, tps: 0.00, reads: 172886.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2049s] threads: 64, tps: 0.00, reads: 172698.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2050s] threads: 64, tps: 0.00, reads: 172052.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2051s] threads: 64, tps: 0.00, reads: 173030.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2052s] threads: 64, tps: 0.00, reads: 172790.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2053s] threads: 64, tps: 0.00, reads: 172867.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2054s] threads: 64, tps: 0.00, reads: 171991.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2055s] threads: 64, tps: 0.00, reads: 172533.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2056s] threads: 64, tps: 0.00, reads: 172739.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2057s] threads: 64, tps: 0.00, reads: 172806.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2058s] threads: 64, tps: 0.00, reads: 172962.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2059s] threads: 64, tps: 0.00, reads: 172061.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2060s] threads: 64, tps: 0.00, reads: 172855.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2061s] threads: 64, tps: 0.00, reads: 172648.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2062s] threads: 64, tps: 0.00, reads: 172449.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2063s] threads: 64, tps: 0.00, reads: 172766.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2064s] threads: 64, tps: 0.00, reads: 173015.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2065s] threads: 64, tps: 0.00, reads: 172846.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2066s] threads: 64, tps: 0.00, reads: 172910.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2067s] threads: 64, tps: 0.00, reads: 172747.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2068s] threads: 64, tps: 0.00, reads: 172585.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2069s] threads: 64, tps: 0.00, reads: 172794.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2070s] threads: 64, tps: 0.00, reads: 173274.11, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2071s] threads: 64, tps: 0.00, reads: 172487.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2072s] threads: 64, tps: 0.00, reads: 172372.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2073s] threads: 64, tps: 0.00, reads: 172449.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2074s] threads: 64, tps: 0.00, reads: 172639.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2075s] threads: 64, tps: 0.00, reads: 172516.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2076s] threads: 64, tps: 0.00, reads: 173143.79, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2077s] threads: 64, tps: 0.00, reads: 172871.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2078s] threads: 64, tps: 0.00, reads: 172583.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2079s] threads: 64, tps: 0.00, reads: 172664.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2080s] threads: 64, tps: 0.00, reads: 172594.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2081s] threads: 64, tps: 0.00, reads: 172625.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2082s] threads: 64, tps: 0.00, reads: 172755.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2083s] threads: 64, tps: 0.00, reads: 172838.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2084s] threads: 64, tps: 0.00, reads: 172311.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2085s] threads: 64, tps: 0.00, reads: 172653.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2086s] threads: 64, tps: 0.00, reads: 172395.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2087s] threads: 64, tps: 0.00, reads: 172416.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2088s] threads: 64, tps: 0.00, reads: 172407.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2089s] threads: 64, tps: 0.00, reads: 173039.10, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2090s] threads: 64, tps: 0.00, reads: 172240.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2091s] threads: 64, tps: 0.00, reads: 171479.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2092s] threads: 64, tps: 0.00, reads: 171429.89, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2093s] threads: 64, tps: 0.00, reads: 171842.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2094s] threads: 64, tps: 0.00, reads: 171862.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2095s] threads: 64, tps: 0.00, reads: 172476.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2096s] threads: 64, tps: 0.00, reads: 172047.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2097s] threads: 64, tps: 0.00, reads: 171963.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2098s] threads: 64, tps: 0.00, reads: 172053.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2099s] threads: 64, tps: 0.00, reads: 172386.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2100s] threads: 64, tps: 0.00, reads: 172520.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2101s] threads: 64, tps: 0.00, reads: 173096.10, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2102s] threads: 64, tps: 0.00, reads: 173105.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2103s] threads: 64, tps: 0.00, reads: 172463.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2104s] threads: 64, tps: 0.00, reads: 172645.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2105s] threads: 64, tps: 0.00, reads: 172558.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2106s] threads: 64, tps: 0.00, reads: 172279.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2107s] threads: 64, tps: 0.00, reads: 172377.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2108s] threads: 64, tps: 0.00, reads: 172868.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2109s] threads: 64, tps: 0.00, reads: 172450.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2110s] threads: 64, tps: 0.00, reads: 172599.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2111s] threads: 64, tps: 0.00, reads: 172800.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2112s] threads: 64, tps: 0.00, reads: 172553.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2113s] threads: 64, tps: 0.00, reads: 172386.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2114s] threads: 64, tps: 0.00, reads: 173364.28, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2115s] threads: 64, tps: 0.00, reads: 172820.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2116s] threads: 64, tps: 0.00, reads: 172923.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2117s] threads: 64, tps: 0.00, reads: 172867.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2118s] threads: 64, tps: 0.00, reads: 172619.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2119s] threads: 64, tps: 0.00, reads: 172870.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2120s] threads: 64, tps: 0.00, reads: 173405.99, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2121s] threads: 64, tps: 0.00, reads: 171617.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2122s] threads: 64, tps: 0.00, reads: 172661.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2123s] threads: 64, tps: 0.00, reads: 172567.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2124s] threads: 64, tps: 0.00, reads: 172669.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2125s] threads: 64, tps: 0.00, reads: 172948.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2126s] threads: 64, tps: 0.00, reads: 173452.14, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2127s] threads: 64, tps: 0.00, reads: 173374.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2128s] threads: 64, tps: 0.00, reads: 172702.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2129s] threads: 64, tps: 0.00, reads: 172520.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2130s] threads: 64, tps: 0.00, reads: 172668.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2131s] threads: 64, tps: 0.00, reads: 172662.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2132s] threads: 64, tps: 0.00, reads: 172688.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2133s] threads: 64, tps: 0.00, reads: 173195.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2134s] threads: 64, tps: 0.00, reads: 172496.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2135s] threads: 64, tps: 0.00, reads: 172899.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2136s] threads: 64, tps: 0.00, reads: 172565.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2137s] threads: 64, tps: 0.00, reads: 172427.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2138s] threads: 64, tps: 0.00, reads: 172434.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2139s] threads: 64, tps: 0.00, reads: 172900.86, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2140s] threads: 64, tps: 0.00, reads: 172914.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2141s] threads: 64, tps: 0.00, reads: 172734.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2142s] threads: 64, tps: 0.00, reads: 172636.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2143s] threads: 64, tps: 0.00, reads: 172662.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2144s] threads: 64, tps: 0.00, reads: 172362.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2145s] threads: 64, tps: 0.00, reads: 172846.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2146s] threads: 64, tps: 0.00, reads: 173046.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2147s] threads: 64, tps: 0.00, reads: 172615.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2148s] threads: 64, tps: 0.00, reads: 172303.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2149s] threads: 64, tps: 0.00, reads: 171963.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2150s] threads: 64, tps: 0.00, reads: 172313.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2151s] threads: 64, tps: 0.00, reads: 172234.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2152s] threads: 64, tps: 0.00, reads: 172574.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2153s] threads: 64, tps: 0.00, reads: 171717.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2154s] threads: 64, tps: 0.00, reads: 171761.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2155s] threads: 64, tps: 0.00, reads: 171980.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2156s] threads: 64, tps: 0.00, reads: 171950.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2157s] threads: 64, tps: 0.00, reads: 171924.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2158s] threads: 64, tps: 0.00, reads: 172499.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2159s] threads: 64, tps: 0.00, reads: 172104.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2160s] threads: 64, tps: 0.00, reads: 172314.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2161s] threads: 64, tps: 0.00, reads: 172306.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2162s] threads: 64, tps: 0.00, reads: 172459.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2163s] threads: 64, tps: 0.00, reads: 172495.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2164s] threads: 64, tps: 0.00, reads: 172777.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2165s] threads: 64, tps: 0.00, reads: 172746.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2166s] threads: 64, tps: 0.00, reads: 172411.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2167s] threads: 64, tps: 0.00, reads: 172746.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2168s] threads: 64, tps: 0.00, reads: 172935.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2169s] threads: 64, tps: 0.00, reads: 172620.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2170s] threads: 64, tps: 0.00, reads: 172913.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2171s] threads: 64, tps: 0.00, reads: 173658.93, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2172s] threads: 64, tps: 0.00, reads: 172613.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2173s] threads: 64, tps: 0.00, reads: 172417.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2174s] threads: 64, tps: 0.00, reads: 172341.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2175s] threads: 64, tps: 0.00, reads: 172535.44, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2176s] threads: 64, tps: 0.00, reads: 172931.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2177s] threads: 64, tps: 0.00, reads: 173367.17, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2178s] threads: 64, tps: 0.00, reads: 172666.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2179s] threads: 64, tps: 0.00, reads: 172194.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2180s] threads: 64, tps: 0.00, reads: 172613.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2181s] threads: 64, tps: 0.00, reads: 172675.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2182s] threads: 64, tps: 0.00, reads: 172829.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2183s] threads: 64, tps: 0.00, reads: 173063.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2184s] threads: 64, tps: 0.00, reads: 173265.16, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2185s] threads: 64, tps: 0.00, reads: 172943.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2186s] threads: 64, tps: 0.00, reads: 172820.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2187s] threads: 64, tps: 0.00, reads: 172721.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2188s] threads: 64, tps: 0.00, reads: 172793.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2189s] threads: 64, tps: 0.00, reads: 172814.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2190s] threads: 64, tps: 0.00, reads: 173408.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2191s] threads: 64, tps: 0.00, reads: 172863.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2192s] threads: 64, tps: 0.00, reads: 173156.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2193s] threads: 64, tps: 0.00, reads: 172688.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2194s] threads: 64, tps: 0.00, reads: 172249.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2195s] threads: 64, tps: 0.00, reads: 172538.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2196s] threads: 64, tps: 0.00, reads: 173269.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2197s] threads: 64, tps: 0.00, reads: 172680.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2198s] threads: 64, tps: 0.00, reads: 172496.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2199s] threads: 64, tps: 0.00, reads: 172151.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2200s] threads: 64, tps: 0.00, reads: 172627.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2201s] threads: 64, tps: 0.00, reads: 172617.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2202s] threads: 64, tps: 0.00, reads: 172769.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2203s] threads: 64, tps: 0.00, reads: 172886.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2204s] threads: 64, tps: 0.00, reads: 172201.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2205s] threads: 64, tps: 0.00, reads: 172466.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2206s] threads: 64, tps: 0.00, reads: 172161.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2207s] threads: 64, tps: 0.00, reads: 172285.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2208s] threads: 64, tps: 0.00, reads: 172719.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2209s] threads: 64, tps: 0.00, reads: 172576.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2210s] threads: 64, tps: 0.00, reads: 172128.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2211s] threads: 64, tps: 0.00, reads: 172163.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2212s] threads: 64, tps: 0.00, reads: 172078.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2213s] threads: 64, tps: 0.00, reads: 172116.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2214s] threads: 64, tps: 0.00, reads: 172011.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2215s] threads: 64, tps: 0.00, reads: 172798.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2216s] threads: 64, tps: 0.00, reads: 172070.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2217s] threads: 64, tps: 0.00, reads: 171568.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2218s] threads: 64, tps: 0.00, reads: 171963.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2219s] threads: 64, tps: 0.00, reads: 171606.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2220s] threads: 64, tps: 0.00, reads: 172304.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2221s] threads: 64, tps: 0.00, reads: 172847.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2222s] threads: 64, tps: 0.00, reads: 172966.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2223s] threads: 64, tps: 0.00, reads: 172456.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2224s] threads: 64, tps: 0.00, reads: 172294.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2225s] threads: 64, tps: 0.00, reads: 172568.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2226s] threads: 64, tps: 0.00, reads: 172627.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2227s] threads: 64, tps: 0.00, reads: 172931.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2228s] threads: 64, tps: 0.00, reads: 173195.49, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2229s] threads: 64, tps: 0.00, reads: 172345.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2230s] threads: 64, tps: 0.00, reads: 172579.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2231s] threads: 64, tps: 0.00, reads: 172768.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2232s] threads: 64, tps: 0.00, reads: 172665.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2233s] threads: 64, tps: 0.00, reads: 173113.80, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2234s] threads: 64, tps: 0.00, reads: 173558.13, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2235s] threads: 64, tps: 0.00, reads: 173089.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2236s] threads: 64, tps: 0.00, reads: 173043.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2237s] threads: 64, tps: 0.00, reads: 172992.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2238s] threads: 64, tps: 0.00, reads: 172934.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2239s] threads: 64, tps: 0.00, reads: 172378.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2240s] threads: 64, tps: 0.00, reads: 173354.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2241s] threads: 64, tps: 0.00, reads: 172839.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2242s] threads: 64, tps: 0.00, reads: 172933.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2243s] threads: 64, tps: 0.00, reads: 172797.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2244s] threads: 64, tps: 0.00, reads: 172158.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2245s] threads: 64, tps: 0.00, reads: 172676.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2246s] threads: 64, tps: 0.00, reads: 173111.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2247s] threads: 64, tps: 0.00, reads: 173165.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2248s] threads: 64, tps: 0.00, reads: 172691.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2249s] threads: 64, tps: 0.00, reads: 172522.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2250s] threads: 64, tps: 0.00, reads: 173094.04, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2251s] threads: 64, tps: 0.00, reads: 172827.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2252s] threads: 64, tps: 0.00, reads: 173101.85, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2253s] threads: 64, tps: 0.00, reads: 173174.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2254s] threads: 64, tps: 0.00, reads: 172461.02, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2255s] threads: 64, tps: 0.00, reads: 172248.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2256s] threads: 64, tps: 0.00, reads: 172734.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2257s] threads: 64, tps: 0.00, reads: 172927.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2258s] threads: 64, tps: 0.00, reads: 173246.95, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2259s] threads: 64, tps: 0.00, reads: 173230.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2260s] threads: 64, tps: 0.00, reads: 172592.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2261s] threads: 64, tps: 0.00, reads: 172737.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2262s] threads: 64, tps: 0.00, reads: 172481.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2263s] threads: 64, tps: 0.00, reads: 172283.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2264s] threads: 64, tps: 0.00, reads: 172547.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2265s] threads: 64, tps: 0.00, reads: 172850.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2266s] threads: 64, tps: 0.00, reads: 172448.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2267s] threads: 64, tps: 0.00, reads: 172000.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2268s] threads: 64, tps: 0.00, reads: 172558.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2269s] threads: 64, tps: 0.00, reads: 172338.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2270s] threads: 64, tps: 0.00, reads: 172005.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2271s] threads: 64, tps: 0.00, reads: 172302.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2272s] threads: 64, tps: 0.00, reads: 172459.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2273s] threads: 64, tps: 0.00, reads: 172067.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2274s] threads: 64, tps: 0.00, reads: 171837.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2275s] threads: 64, tps: 0.00, reads: 172144.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2276s] threads: 64, tps: 0.00, reads: 172051.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2277s] threads: 64, tps: 0.00, reads: 172158.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2278s] threads: 64, tps: 0.00, reads: 172781.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2279s] threads: 64, tps: 0.00, reads: 171916.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2280s] threads: 64, tps: 0.00, reads: 172409.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2281s] threads: 64, tps: 0.00, reads: 171447.07, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2282s] threads: 64, tps: 0.00, reads: 172018.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2283s] threads: 64, tps: 0.00, reads: 172217.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2284s] threads: 64, tps: 0.00, reads: 172704.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2285s] threads: 64, tps: 0.00, reads: 171450.72, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2286s] threads: 64, tps: 0.00, reads: 172009.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2287s] threads: 64, tps: 0.00, reads: 171807.85, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2288s] threads: 64, tps: 0.00, reads: 172522.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2289s] threads: 64, tps: 0.00, reads: 172723.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2290s] threads: 64, tps: 0.00, reads: 172887.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2291s] threads: 64, tps: 0.00, reads: 173410.07, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2292s] threads: 64, tps: 0.00, reads: 173056.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2293s] threads: 64, tps: 0.00, reads: 172728.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2294s] threads: 64, tps: 0.00, reads: 172701.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2295s] threads: 64, tps: 0.00, reads: 172719.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2296s] threads: 64, tps: 0.00, reads: 172990.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2297s] threads: 64, tps: 0.00, reads: 173318.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2298s] threads: 64, tps: 0.00, reads: 172820.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2299s] threads: 64, tps: 0.00, reads: 172923.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2300s] threads: 64, tps: 0.00, reads: 172882.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2301s] threads: 64, tps: 0.00, reads: 172905.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2302s] threads: 64, tps: 0.00, reads: 172864.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2303s] threads: 64, tps: 0.00, reads: 173544.63, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2304s] threads: 64, tps: 0.00, reads: 172888.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2305s] threads: 64, tps: 0.00, reads: 172756.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2306s] threads: 64, tps: 0.00, reads: 172818.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2307s] threads: 64, tps: 0.00, reads: 172676.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2308s] threads: 64, tps: 0.00, reads: 172840.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2309s] threads: 64, tps: 0.00, reads: 172996.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2310s] threads: 64, tps: 0.00, reads: 172673.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2311s] threads: 64, tps: 0.00, reads: 172397.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2312s] threads: 64, tps: 0.00, reads: 172567.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2313s] threads: 64, tps: 0.00, reads: 172745.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2314s] threads: 64, tps: 0.00, reads: 172710.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2315s] threads: 64, tps: 0.00, reads: 172858.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2316s] threads: 64, tps: 0.00, reads: 173441.09, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2317s] threads: 64, tps: 0.00, reads: 172807.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2318s] threads: 64, tps: 0.00, reads: 172471.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2319s] threads: 64, tps: 0.00, reads: 172746.42, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2320s] threads: 64, tps: 0.00, reads: 172592.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2321s] threads: 64, tps: 0.00, reads: 172741.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2322s] threads: 64, tps: 0.00, reads: 173163.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2323s] threads: 64, tps: 0.00, reads: 172298.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2324s] threads: 64, tps: 0.00, reads: 172580.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2325s] threads: 64, tps: 0.00, reads: 172632.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2326s] threads: 64, tps: 0.00, reads: 172491.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2327s] threads: 64, tps: 0.00, reads: 172155.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2328s] threads: 64, tps: 0.00, reads: 173137.53, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2329s] threads: 64, tps: 0.00, reads: 172430.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2330s] threads: 64, tps: 0.00, reads: 171886.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2331s] threads: 64, tps: 0.00, reads: 171935.64, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2332s] threads: 64, tps: 0.00, reads: 171759.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2333s] threads: 64, tps: 0.00, reads: 172165.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2334s] threads: 64, tps: 0.00, reads: 172459.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2335s] threads: 64, tps: 0.00, reads: 171869.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2336s] threads: 64, tps: 0.00, reads: 171809.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2337s] threads: 64, tps: 0.00, reads: 171893.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2338s] threads: 64, tps: 0.00, reads: 171848.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2339s] threads: 64, tps: 0.00, reads: 172095.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2340s] threads: 64, tps: 0.00, reads: 172361.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2341s] threads: 64, tps: 0.00, reads: 172775.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2342s] threads: 64, tps: 0.00, reads: 172053.89, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2343s] threads: 64, tps: 0.00, reads: 172454.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2344s] threads: 64, tps: 0.00, reads: 172595.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2345s] threads: 64, tps: 0.00, reads: 172508.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2346s] threads: 64, tps: 0.00, reads: 172725.23, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2347s] threads: 64, tps: 0.00, reads: 173208.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2348s] threads: 64, tps: 0.00, reads: 172813.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2349s] threads: 64, tps: 0.00, reads: 172862.02, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2350s] threads: 64, tps: 0.00, reads: 173110.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2351s] threads: 64, tps: 0.00, reads: 172502.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2352s] threads: 64, tps: 0.00, reads: 172776.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2353s] threads: 64, tps: 0.00, reads: 173390.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2354s] threads: 64, tps: 0.00, reads: 172314.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2355s] threads: 64, tps: 0.00, reads: 172283.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2356s] threads: 64, tps: 0.00, reads: 172592.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2357s] threads: 64, tps: 0.00, reads: 172556.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2358s] threads: 64, tps: 0.00, reads: 172860.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2359s] threads: 64, tps: 0.00, reads: 172793.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2360s] threads: 64, tps: 0.00, reads: 172694.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2361s] threads: 64, tps: 0.00, reads: 172591.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2362s] threads: 64, tps: 0.00, reads: 172863.00, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2363s] threads: 64, tps: 0.00, reads: 172876.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2364s] threads: 64, tps: 0.00, reads: 172638.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2365s] threads: 64, tps: 0.00, reads: 173381.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2366s] threads: 64, tps: 0.00, reads: 173265.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2367s] threads: 64, tps: 0.00, reads: 172873.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2368s] threads: 64, tps: 0.00, reads: 172910.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2369s] threads: 64, tps: 0.00, reads: 172970.17, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2370s] threads: 64, tps: 0.00, reads: 172687.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2371s] threads: 64, tps: 0.00, reads: 173046.12, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2372s] threads: 64, tps: 0.00, reads: 173246.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2373s] threads: 64, tps: 0.00, reads: 172850.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2374s] threads: 64, tps: 0.00, reads: 173065.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2375s] threads: 64, tps: 0.00, reads: 172682.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2376s] threads: 64, tps: 0.00, reads: 172385.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2377s] threads: 64, tps: 0.00, reads: 172856.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2378s] threads: 64, tps: 0.00, reads: 173045.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2379s] threads: 64, tps: 0.00, reads: 172351.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2380s] threads: 64, tps: 0.00, reads: 172392.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2381s] threads: 64, tps: 0.00, reads: 172521.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2382s] threads: 64, tps: 0.00, reads: 172528.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2383s] threads: 64, tps: 0.00, reads: 172785.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2384s] threads: 64, tps: 0.00, reads: 172750.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2385s] threads: 64, tps: 0.00, reads: 172298.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2386s] threads: 64, tps: 0.00, reads: 172259.74, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2387s] threads: 64, tps: 0.00, reads: 172439.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2388s] threads: 64, tps: 0.00, reads: 171963.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2389s] threads: 64, tps: 0.00, reads: 172145.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2390s] threads: 64, tps: 0.00, reads: 172796.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2391s] threads: 64, tps: 0.00, reads: 172450.11, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2392s] threads: 64, tps: 0.00, reads: 171647.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2393s] threads: 64, tps: 0.00, reads: 172019.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2394s] threads: 64, tps: 0.00, reads: 172037.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2395s] threads: 64, tps: 0.00, reads: 172129.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2396s] threads: 64, tps: 0.00, reads: 172297.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2397s] threads: 64, tps: 0.00, reads: 172647.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2398s] threads: 64, tps: 0.00, reads: 172281.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2399s] threads: 64, tps: 0.00, reads: 172589.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2400s] threads: 64, tps: 0.00, reads: 172062.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2401s] threads: 64, tps: 0.00, reads: 172022.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2402s] threads: 64, tps: 0.00, reads: 172401.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2403s] threads: 64, tps: 0.00, reads: 172925.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2404s] threads: 64, tps: 0.00, reads: 172279.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2405s] threads: 64, tps: 0.00, reads: 171895.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2406s] threads: 64, tps: 0.00, reads: 172224.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2407s] threads: 64, tps: 0.00, reads: 172434.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2408s] threads: 64, tps: 0.00, reads: 172645.50, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2409s] threads: 64, tps: 0.00, reads: 173501.59, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2410s] threads: 64, tps: 0.00, reads: 172640.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2411s] threads: 64, tps: 0.00, reads: 172768.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2412s] threads: 64, tps: 0.00, reads: 172518.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2413s] threads: 64, tps: 0.00, reads: 172787.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2414s] threads: 64, tps: 0.00, reads: 172677.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2415s] threads: 64, tps: 0.00, reads: 173526.74, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2416s] threads: 64, tps: 0.00, reads: 173218.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2417s] threads: 64, tps: 0.00, reads: 172823.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2418s] threads: 64, tps: 0.00, reads: 172598.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2419s] threads: 64, tps: 0.00, reads: 171607.23, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2420s] threads: 64, tps: 0.00, reads: 172724.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2421s] threads: 64, tps: 0.00, reads: 172629.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2422s] threads: 64, tps: 0.00, reads: 172829.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2423s] threads: 64, tps: 0.00, reads: 172856.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2424s] threads: 64, tps: 0.00, reads: 172894.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2425s] threads: 64, tps: 0.00, reads: 172683.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2426s] threads: 64, tps: 0.00, reads: 172765.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2427s] threads: 64, tps: 0.00, reads: 173056.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2428s] threads: 64, tps: 0.00, reads: 173055.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2429s] threads: 64, tps: 0.00, reads: 172596.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2430s] threads: 64, tps: 0.00, reads: 172746.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2431s] threads: 64, tps: 0.00, reads: 172712.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2432s] threads: 64, tps: 0.00, reads: 172522.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2433s] threads: 64, tps: 0.00, reads: 173230.54, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2434s] threads: 64, tps: 0.00, reads: 173200.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2435s] threads: 64, tps: 0.00, reads: 172864.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2436s] threads: 64, tps: 0.00, reads: 172673.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2437s] threads: 64, tps: 0.00, reads: 172635.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2438s] threads: 64, tps: 0.00, reads: 172878.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2439s] threads: 64, tps: 0.00, reads: 173100.76, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2440s] threads: 64, tps: 0.00, reads: 173332.20, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2441s] threads: 64, tps: 0.00, reads: 172581.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2442s] threads: 64, tps: 0.00, reads: 172474.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2443s] threads: 64, tps: 0.00, reads: 172712.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2444s] threads: 64, tps: 0.00, reads: 172630.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2445s] threads: 64, tps: 0.00, reads: 172843.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2446s] threads: 64, tps: 0.00, reads: 173081.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2447s] threads: 64, tps: 0.00, reads: 172582.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2448s] threads: 64, tps: 0.00, reads: 172551.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2449s] threads: 64, tps: 0.00, reads: 172332.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2450s] threads: 64, tps: 0.00, reads: 172068.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2451s] threads: 64, tps: 0.00, reads: 171776.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2452s] threads: 64, tps: 0.00, reads: 172535.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2453s] threads: 64, tps: 0.00, reads: 172012.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2454s] threads: 64, tps: 0.00, reads: 171976.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2455s] threads: 64, tps: 0.00, reads: 172294.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2456s] threads: 64, tps: 0.00, reads: 172052.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2457s] threads: 64, tps: 0.00, reads: 171957.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2458s] threads: 64, tps: 0.00, reads: 172630.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2459s] threads: 64, tps: 0.00, reads: 171769.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2460s] threads: 64, tps: 0.00, reads: 172054.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2461s] threads: 64, tps: 0.00, reads: 171652.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2462s] threads: 64, tps: 0.00, reads: 172114.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2463s] threads: 64, tps: 0.00, reads: 172121.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2464s] threads: 64, tps: 0.00, reads: 172827.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2465s] threads: 64, tps: 0.00, reads: 172276.90, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2466s] threads: 64, tps: 0.00, reads: 171942.96, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2467s] threads: 64, tps: 0.00, reads: 172127.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2468s] threads: 64, tps: 0.00, reads: 172253.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2469s] threads: 64, tps: 0.00, reads: 172148.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2470s] threads: 64, tps: 0.00, reads: 172642.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2471s] threads: 64, tps: 0.00, reads: 172733.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2472s] threads: 64, tps: 0.00, reads: 172419.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2473s] threads: 64, tps: 0.00, reads: 172583.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2474s] threads: 64, tps: 0.00, reads: 172480.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2475s] threads: 64, tps: 0.00, reads: 172772.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2476s] threads: 64, tps: 0.00, reads: 172995.99, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2477s] threads: 64, tps: 0.00, reads: 173146.39, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2478s] threads: 64, tps: 0.00, reads: 172361.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2479s] threads: 64, tps: 0.00, reads: 172816.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2480s] threads: 64, tps: 0.00, reads: 172877.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2481s] threads: 64, tps: 0.00, reads: 172777.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2482s] threads: 64, tps: 0.00, reads: 172951.89, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2483s] threads: 64, tps: 0.00, reads: 173244.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2484s] threads: 64, tps: 0.00, reads: 172896.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2485s] threads: 64, tps: 0.00, reads: 173030.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2486s] threads: 64, tps: 0.00, reads: 172870.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2487s] threads: 64, tps: 0.00, reads: 172574.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2488s] threads: 64, tps: 0.00, reads: 173428.22, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2489s] threads: 64, tps: 0.00, reads: 173327.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2490s] threads: 64, tps: 0.00, reads: 172952.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2491s] threads: 64, tps: 0.00, reads: 173052.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2492s] threads: 64, tps: 0.00, reads: 172779.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2493s] threads: 64, tps: 0.00, reads: 172777.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2494s] threads: 64, tps: 0.00, reads: 173032.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2495s] threads: 64, tps: 0.00, reads: 173493.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2496s] threads: 64, tps: 0.00, reads: 172952.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2497s] threads: 64, tps: 0.00, reads: 172723.20, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2498s] threads: 64, tps: 0.00, reads: 172177.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2499s] threads: 64, tps: 0.00, reads: 172549.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2500s] threads: 64, tps: 0.00, reads: 172598.96, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2501s] threads: 64, tps: 0.00, reads: 172843.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2502s] threads: 64, tps: 0.00, reads: 172348.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2503s] threads: 64, tps: 0.00, reads: 172107.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2504s] threads: 64, tps: 0.00, reads: 172731.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2505s] threads: 64, tps: 0.00, reads: 172908.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2506s] threads: 64, tps: 0.00, reads: 172579.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2507s] threads: 64, tps: 0.00, reads: 173142.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2508s] threads: 64, tps: 0.00, reads: 172203.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2509s] threads: 64, tps: 0.00, reads: 172366.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2510s] threads: 64, tps: 0.00, reads: 172152.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2511s] threads: 64, tps: 0.00, reads: 172023.94, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2512s] threads: 64, tps: 0.00, reads: 171877.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2513s] threads: 64, tps: 0.00, reads: 172695.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2514s] threads: 64, tps: 0.00, reads: 172057.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2515s] threads: 64, tps: 0.00, reads: 172110.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2516s] threads: 64, tps: 0.00, reads: 172121.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2517s] threads: 64, tps: 0.00, reads: 172023.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2518s] threads: 64, tps: 0.00, reads: 172056.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2519s] threads: 64, tps: 0.00, reads: 172543.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2520s] threads: 64, tps: 0.00, reads: 172828.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2521s] threads: 64, tps: 0.00, reads: 172903.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2522s] threads: 64, tps: 0.00, reads: 172562.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2523s] threads: 64, tps: 0.00, reads: 172168.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2524s] threads: 64, tps: 0.00, reads: 172270.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2525s] threads: 64, tps: 0.00, reads: 172810.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2526s] threads: 64, tps: 0.00, reads: 173040.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2527s] threads: 64, tps: 0.00, reads: 172300.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2528s] threads: 64, tps: 0.00, reads: 172302.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2529s] threads: 64, tps: 0.00, reads: 172967.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2530s] threads: 64, tps: 0.00, reads: 172768.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2531s] threads: 64, tps: 0.00, reads: 172565.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2532s] threads: 64, tps: 0.00, reads: 173160.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2533s] threads: 64, tps: 0.00, reads: 172667.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2534s] threads: 64, tps: 0.00, reads: 172804.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2535s] threads: 64, tps: 0.00, reads: 172919.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2536s] threads: 64, tps: 0.00, reads: 172740.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2537s] threads: 64, tps: 0.00, reads: 172736.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2538s] threads: 64, tps: 0.00, reads: 173063.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2539s] threads: 64, tps: 0.00, reads: 173528.97, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2540s] threads: 64, tps: 0.00, reads: 172785.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2541s] threads: 64, tps: 0.00, reads: 173025.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2542s] threads: 64, tps: 0.00, reads: 172779.44, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2543s] threads: 64, tps: 0.00, reads: 172949.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2544s] threads: 64, tps: 0.00, reads: 173051.32, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2545s] threads: 64, tps: 0.00, reads: 173474.92, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2546s] threads: 64, tps: 0.00, reads: 173245.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2547s] threads: 64, tps: 0.00, reads: 172697.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2548s] threads: 64, tps: 0.00, reads: 172574.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2549s] threads: 64, tps: 0.00, reads: 172590.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2550s] threads: 64, tps: 0.00, reads: 172909.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2551s] threads: 64, tps: 0.00, reads: 173306.82, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2552s] threads: 64, tps: 0.00, reads: 172515.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2553s] threads: 64, tps: 0.00, reads: 172324.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2554s] threads: 64, tps: 0.00, reads: 172842.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2555s] threads: 64, tps: 0.00, reads: 172707.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2556s] threads: 64, tps: 0.00, reads: 173090.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2557s] threads: 64, tps: 0.00, reads: 173128.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2558s] threads: 64, tps: 0.00, reads: 172416.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2559s] threads: 64, tps: 0.00, reads: 172764.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2560s] threads: 64, tps: 0.00, reads: 172719.99, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2561s] threads: 64, tps: 0.00, reads: 172762.13, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2562s] threads: 64, tps: 0.00, reads: 173143.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2563s] threads: 64, tps: 0.00, reads: 172955.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2564s] threads: 64, tps: 0.00, reads: 172837.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2565s] threads: 64, tps: 0.00, reads: 172687.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2566s] threads: 64, tps: 0.00, reads: 172608.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2567s] threads: 64, tps: 0.00, reads: 172457.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2568s] threads: 64, tps: 0.00, reads: 172793.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2569s] threads: 64, tps: 0.00, reads: 173135.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2570s] threads: 64, tps: 0.00, reads: 172197.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2571s] threads: 64, tps: 0.00, reads: 172628.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2572s] threads: 64, tps: 0.00, reads: 172079.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2573s] threads: 64, tps: 0.00, reads: 172236.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2574s] threads: 64, tps: 0.00, reads: 171707.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2575s] threads: 64, tps: 0.00, reads: 172444.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2576s] threads: 64, tps: 0.00, reads: 172229.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2577s] threads: 64, tps: 0.00, reads: 171842.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2578s] threads: 64, tps: 0.00, reads: 171786.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2579s] threads: 64, tps: 0.00, reads: 171695.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2580s] threads: 64, tps: 0.00, reads: 171724.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2581s] threads: 64, tps: 0.00, reads: 172519.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2582s] threads: 64, tps: 0.00, reads: 172828.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2583s] threads: 64, tps: 0.00, reads: 172574.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2584s] threads: 64, tps: 0.00, reads: 172557.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2585s] threads: 64, tps: 0.00, reads: 172639.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2586s] threads: 64, tps: 0.00, reads: 172754.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2587s] threads: 64, tps: 0.00, reads: 172835.45, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2588s] threads: 64, tps: 0.00, reads: 173453.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2589s] threads: 64, tps: 0.00, reads: 172655.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2590s] threads: 64, tps: 0.00, reads: 172865.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2591s] threads: 64, tps: 0.00, reads: 172899.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2592s] threads: 64, tps: 0.00, reads: 172447.64, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2593s] threads: 64, tps: 0.00, reads: 173094.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2594s] threads: 64, tps: 0.00, reads: 173429.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2595s] threads: 64, tps: 0.00, reads: 173017.13, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2596s] threads: 64, tps: 0.00, reads: 173110.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2597s] threads: 64, tps: 0.00, reads: 172959.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2598s] threads: 64, tps: 0.00, reads: 173027.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2599s] threads: 64, tps: 0.00, reads: 172852.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2600s] threads: 64, tps: 0.00, reads: 172994.64, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2601s] threads: 64, tps: 0.00, reads: 172571.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2602s] threads: 64, tps: 0.00, reads: 172298.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2603s] threads: 64, tps: 0.00, reads: 172651.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2604s] threads: 64, tps: 0.00, reads: 173014.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2605s] threads: 64, tps: 0.00, reads: 173095.26, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2606s] threads: 64, tps: 0.00, reads: 173434.63, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2607s] threads: 64, tps: 0.00, reads: 172359.20, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2608s] threads: 64, tps: 0.00, reads: 172541.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2609s] threads: 64, tps: 0.00, reads: 172743.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2610s] threads: 64, tps: 0.00, reads: 172875.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2611s] threads: 64, tps: 0.00, reads: 172810.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2612s] threads: 64, tps: 0.00, reads: 173500.61, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2613s] threads: 64, tps: 0.00, reads: 172982.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2614s] threads: 64, tps: 0.00, reads: 172782.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2615s] threads: 64, tps: 0.00, reads: 172824.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2616s] threads: 64, tps: 0.00, reads: 172550.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2617s] threads: 64, tps: 0.00, reads: 172434.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2618s] threads: 64, tps: 0.00, reads: 173160.84, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2619s] threads: 64, tps: 0.00, reads: 172906.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2620s] threads: 64, tps: 0.00, reads: 172802.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2621s] threads: 64, tps: 0.00, reads: 172704.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2622s] threads: 64, tps: 0.00, reads: 172398.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2623s] threads: 64, tps: 0.00, reads: 172725.79, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2624s] threads: 64, tps: 0.00, reads: 172710.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2625s] threads: 64, tps: 0.00, reads: 173423.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2626s] threads: 64, tps: 0.00, reads: 172464.17, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2627s] threads: 64, tps: 0.00, reads: 172032.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2628s] threads: 64, tps: 0.00, reads: 172547.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2629s] threads: 64, tps: 0.00, reads: 172463.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2630s] threads: 64, tps: 0.00, reads: 172263.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2631s] threads: 64, tps: 0.00, reads: 172668.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2632s] threads: 64, tps: 0.00, reads: 171680.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2633s] threads: 64, tps: 0.00, reads: 171957.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2634s] threads: 64, tps: 0.00, reads: 171816.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2635s] threads: 64, tps: 0.00, reads: 171874.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2636s] threads: 64, tps: 0.00, reads: 172232.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2637s] threads: 64, tps: 0.00, reads: 172669.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2638s] threads: 64, tps: 0.00, reads: 172270.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2639s] threads: 64, tps: 0.00, reads: 171378.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2640s] threads: 64, tps: 0.00, reads: 171933.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2641s] threads: 64, tps: 0.00, reads: 171782.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2642s] threads: 64, tps: 0.00, reads: 171698.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2643s] threads: 64, tps: 0.00, reads: 173412.94, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2644s] threads: 64, tps: 0.00, reads: 172422.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2645s] threads: 64, tps: 0.00, reads: 172583.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2646s] threads: 64, tps: 0.00, reads: 172617.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2647s] threads: 64, tps: 0.00, reads: 172693.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2648s] threads: 64, tps: 0.00, reads: 172853.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2649s] threads: 64, tps: 0.00, reads: 173511.11, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2650s] threads: 64, tps: 0.00, reads: 172915.10, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2651s] threads: 64, tps: 0.00, reads: 172825.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2652s] threads: 64, tps: 0.00, reads: 172514.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2653s] threads: 64, tps: 0.00, reads: 172752.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2654s] threads: 64, tps: 0.00, reads: 172402.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2655s] threads: 64, tps: 0.00, reads: 172834.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2656s] threads: 64, tps: 0.00, reads: 172946.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2657s] threads: 64, tps: 0.00, reads: 172584.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2658s] threads: 64, tps: 0.00, reads: 172455.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2659s] threads: 64, tps: 0.00, reads: 172234.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2660s] threads: 64, tps: 0.00, reads: 172633.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2661s] threads: 64, tps: 0.00, reads: 173372.07, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2662s] threads: 64, tps: 0.00, reads: 173297.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2663s] threads: 64, tps: 0.00, reads: 172670.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2664s] threads: 64, tps: 0.00, reads: 172692.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2665s] threads: 64, tps: 0.00, reads: 172194.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2666s] threads: 64, tps: 0.00, reads: 172940.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2667s] threads: 64, tps: 0.00, reads: 173050.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2668s] threads: 64, tps: 0.00, reads: 173333.07, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2669s] threads: 64, tps: 0.00, reads: 172961.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2670s] threads: 64, tps: 0.00, reads: 172766.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2671s] threads: 64, tps: 0.00, reads: 172799.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2672s] threads: 64, tps: 0.00, reads: 172698.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2673s] threads: 64, tps: 0.00, reads: 171223.98, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2674s] threads: 64, tps: 0.00, reads: 173282.64, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2675s] threads: 64, tps: 0.00, reads: 173242.30, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2676s] threads: 64, tps: 0.00, reads: 172489.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2677s] threads: 64, tps: 0.00, reads: 172514.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2678s] threads: 64, tps: 0.00, reads: 172360.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2679s] threads: 64, tps: 0.00, reads: 172562.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2680s] threads: 64, tps: 0.00, reads: 172499.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2681s] threads: 64, tps: 0.00, reads: 173178.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2682s] threads: 64, tps: 0.00, reads: 172516.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2683s] threads: 64, tps: 0.00, reads: 172262.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2684s] threads: 64, tps: 0.00, reads: 172466.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2685s] threads: 64, tps: 0.00, reads: 172583.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2686s] threads: 64, tps: 0.00, reads: 172935.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2687s] threads: 64, tps: 0.00, reads: 173000.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2688s] threads: 64, tps: 0.00, reads: 172340.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2689s] threads: 64, tps: 0.00, reads: 172268.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2690s] threads: 64, tps: 0.00, reads: 172480.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2691s] threads: 64, tps: 0.00, reads: 172169.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2692s] threads: 64, tps: 0.00, reads: 172168.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2693s] threads: 64, tps: 0.00, reads: 172595.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2694s] threads: 64, tps: 0.00, reads: 172608.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2695s] threads: 64, tps: 0.00, reads: 171955.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2696s] threads: 64, tps: 0.00, reads: 172099.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2697s] threads: 64, tps: 0.00, reads: 171898.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2698s] threads: 64, tps: 0.00, reads: 172042.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2699s] threads: 64, tps: 0.00, reads: 172574.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2700s] threads: 64, tps: 0.00, reads: 172646.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2701s] threads: 64, tps: 0.00, reads: 172436.64, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2702s] threads: 64, tps: 0.00, reads: 172952.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2703s] threads: 64, tps: 0.00, reads: 172286.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2704s] threads: 64, tps: 0.00, reads: 172321.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2705s] threads: 64, tps: 0.00, reads: 172571.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2706s] threads: 64, tps: 0.00, reads: 172525.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2707s] threads: 64, tps: 0.00, reads: 172457.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2708s] threads: 64, tps: 0.00, reads: 172317.17, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2709s] threads: 64, tps: 0.00, reads: 172624.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2710s] threads: 64, tps: 0.00, reads: 172478.66, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2711s] threads: 64, tps: 0.00, reads: 172837.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2712s] threads: 64, tps: 0.00, reads: 173481.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2713s] threads: 64, tps: 0.00, reads: 172706.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2714s] threads: 64, tps: 0.00, reads: 172911.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2715s] threads: 64, tps: 0.00, reads: 172767.75, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2716s] threads: 64, tps: 0.00, reads: 172673.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2717s] threads: 64, tps: 0.00, reads: 173013.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2718s] threads: 64, tps: 0.00, reads: 173637.56, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2719s] threads: 64, tps: 0.00, reads: 172801.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2720s] threads: 64, tps: 0.00, reads: 172892.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2721s] threads: 64, tps: 0.00, reads: 171395.89, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2722s] threads: 64, tps: 0.00, reads: 172818.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2723s] threads: 64, tps: 0.00, reads: 172321.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2724s] threads: 64, tps: 0.00, reads: 172400.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2725s] threads: 64, tps: 0.00, reads: 172565.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2726s] threads: 64, tps: 0.00, reads: 173017.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2727s] threads: 64, tps: 0.00, reads: 171992.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2728s] threads: 64, tps: 0.00, reads: 172760.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2729s] threads: 64, tps: 0.00, reads: 172534.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2730s] threads: 64, tps: 0.00, reads: 173350.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2731s] threads: 64, tps: 0.00, reads: 172725.09, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2732s] threads: 64, tps: 0.00, reads: 172289.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2733s] threads: 64, tps: 0.00, reads: 172548.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2734s] threads: 64, tps: 0.00, reads: 172775.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2735s] threads: 64, tps: 0.00, reads: 172650.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2736s] threads: 64, tps: 0.00, reads: 171950.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2737s] threads: 64, tps: 0.00, reads: 173145.83, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2738s] threads: 64, tps: 0.00, reads: 172642.32, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2739s] threads: 64, tps: 0.00, reads: 172584.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2740s] threads: 64, tps: 0.00, reads: 172726.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2741s] threads: 64, tps: 0.00, reads: 172284.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2742s] threads: 64, tps: 0.00, reads: 173342.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2743s] threads: 64, tps: 0.00, reads: 173046.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2744s] threads: 64, tps: 0.00, reads: 172617.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2745s] threads: 64, tps: 0.00, reads: 172642.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2746s] threads: 64, tps: 0.00, reads: 172304.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2747s] threads: 64, tps: 0.00, reads: 172557.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2748s] threads: 64, tps: 0.00, reads: 172835.50, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2749s] threads: 64, tps: 0.00, reads: 172953.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2750s] threads: 64, tps: 0.00, reads: 172719.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2751s] threads: 64, tps: 0.00, reads: 171977.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2752s] threads: 64, tps: 0.00, reads: 172148.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2753s] threads: 64, tps: 0.00, reads: 171939.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2754s] threads: 64, tps: 0.00, reads: 172238.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2755s] threads: 64, tps: 0.00, reads: 172311.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2756s] threads: 64, tps: 0.00, reads: 170367.97, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2757s] threads: 64, tps: 0.00, reads: 170782.98, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2758s] threads: 64, tps: 0.00, reads: 171537.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2759s] threads: 64, tps: 0.00, reads: 171680.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2760s] threads: 64, tps: 0.00, reads: 172485.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2761s] threads: 64, tps: 0.00, reads: 172916.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2762s] threads: 64, tps: 0.00, reads: 172280.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2763s] threads: 64, tps: 0.00, reads: 172292.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2764s] threads: 64, tps: 0.00, reads: 172729.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2765s] threads: 64, tps: 0.00, reads: 172591.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2766s] threads: 64, tps: 0.00, reads: 172769.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2767s] threads: 64, tps: 0.00, reads: 172913.03, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2768s] threads: 64, tps: 0.00, reads: 172966.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2769s] threads: 64, tps: 0.00, reads: 172460.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2770s] threads: 64, tps: 0.00, reads: 172831.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2771s] threads: 64, tps: 0.00, reads: 172772.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2772s] threads: 64, tps: 0.00, reads: 172900.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2773s] threads: 64, tps: 0.00, reads: 173024.55, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2774s] threads: 64, tps: 0.00, reads: 173566.90, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2775s] threads: 64, tps: 0.00, reads: 172916.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2776s] threads: 64, tps: 0.00, reads: 172732.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2777s] threads: 64, tps: 0.00, reads: 172849.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2778s] threads: 64, tps: 0.00, reads: 172730.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2779s] threads: 64, tps: 0.00, reads: 172888.85, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2780s] threads: 64, tps: 0.00, reads: 172875.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2781s] threads: 64, tps: 0.00, reads: 172408.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2782s] threads: 64, tps: 0.00, reads: 172714.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2783s] threads: 64, tps: 0.00, reads: 172757.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2784s] threads: 64, tps: 0.00, reads: 172680.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2785s] threads: 64, tps: 0.00, reads: 173205.96, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2786s] threads: 64, tps: 0.00, reads: 173214.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2787s] threads: 64, tps: 0.00, reads: 172871.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2788s] threads: 64, tps: 0.00, reads: 172432.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2789s] threads: 64, tps: 0.00, reads: 172785.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2790s] threads: 64, tps: 0.00, reads: 172830.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2791s] threads: 64, tps: 0.00, reads: 172954.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2792s] threads: 64, tps: 0.00, reads: 173457.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2793s] threads: 64, tps: 0.00, reads: 172760.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2794s] threads: 64, tps: 0.00, reads: 172953.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2795s] threads: 64, tps: 0.00, reads: 172918.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2796s] threads: 64, tps: 0.00, reads: 172490.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2797s] threads: 64, tps: 0.00, reads: 172473.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2798s] threads: 64, tps: 0.00, reads: 173597.03, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2799s] threads: 64, tps: 0.00, reads: 172931.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2800s] threads: 64, tps: 0.00, reads: 172958.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2801s] threads: 64, tps: 0.00, reads: 172568.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2802s] threads: 64, tps: 0.00, reads: 172423.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2803s] threads: 64, tps: 0.00, reads: 172497.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2804s] threads: 64, tps: 0.00, reads: 173329.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2805s] threads: 64, tps: 0.00, reads: 172413.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2806s] threads: 64, tps: 0.00, reads: 172391.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2807s] threads: 64, tps: 0.00, reads: 172106.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2808s] threads: 64, tps: 0.00, reads: 172187.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2809s] threads: 64, tps: 0.00, reads: 172224.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2810s] threads: 64, tps: 0.00, reads: 172417.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2811s] threads: 64, tps: 0.00, reads: 172116.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2812s] threads: 64, tps: 0.00, reads: 170900.90, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[2813s] threads: 64, tps: 0.00, reads: 171595.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2814s] threads: 64, tps: 0.00, reads: 171404.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2815s] threads: 64, tps: 0.00, reads: 172056.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2816s] threads: 64, tps: 0.00, reads: 172423.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2817s] threads: 64, tps: 0.00, reads: 172290.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2818s] threads: 64, tps: 0.00, reads: 172012.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2819s] threads: 64, tps: 0.00, reads: 172024.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2820s] threads: 64, tps: 0.00, reads: 172456.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2821s] threads: 64, tps: 0.00, reads: 172414.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2822s] threads: 64, tps: 0.00, reads: 172471.39, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2823s] threads: 64, tps: 0.00, reads: 173052.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2824s] threads: 64, tps: 0.00, reads: 172615.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2825s] threads: 64, tps: 0.00, reads: 172716.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2826s] threads: 64, tps: 0.00, reads: 172684.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2827s] threads: 64, tps: 0.00, reads: 172498.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2828s] threads: 64, tps: 0.00, reads: 173006.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2829s] threads: 64, tps: 0.00, reads: 173503.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2830s] threads: 64, tps: 0.00, reads: 172866.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2831s] threads: 64, tps: 0.00, reads: 172900.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2832s] threads: 64, tps: 0.00, reads: 172634.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2833s] threads: 64, tps: 0.00, reads: 172860.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2834s] threads: 64, tps: 0.00, reads: 172645.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2835s] threads: 64, tps: 0.00, reads: 173483.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2836s] threads: 64, tps: 0.00, reads: 172828.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2837s] threads: 64, tps: 0.00, reads: 171728.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2838s] threads: 64, tps: 0.00, reads: 172857.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2839s] threads: 64, tps: 0.00, reads: 172975.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2840s] threads: 64, tps: 0.00, reads: 172723.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2841s] threads: 64, tps: 0.00, reads: 173308.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2842s] threads: 64, tps: 0.00, reads: 173180.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2843s] threads: 64, tps: 0.00, reads: 172813.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2844s] threads: 64, tps: 0.00, reads: 172766.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2845s] threads: 64, tps: 0.00, reads: 172851.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2846s] threads: 64, tps: 0.00, reads: 172927.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2847s] threads: 64, tps: 0.00, reads: 172897.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2848s] threads: 64, tps: 0.00, reads: 173368.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2849s] threads: 64, tps: 0.00, reads: 172984.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2850s] threads: 64, tps: 0.00, reads: 173005.64, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2851s] threads: 64, tps: 0.00, reads: 172706.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2852s] threads: 64, tps: 0.00, reads: 172495.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2853s] threads: 64, tps: 0.00, reads: 172928.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2854s] threads: 64, tps: 0.00, reads: 173255.02, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2855s] threads: 64, tps: 0.00, reads: 172477.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2856s] threads: 64, tps: 0.00, reads: 172859.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2857s] threads: 64, tps: 0.00, reads: 172453.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2858s] threads: 64, tps: 0.00, reads: 173049.97, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2859s] threads: 64, tps: 0.00, reads: 172852.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2860s] threads: 64, tps: 0.00, reads: 173144.85, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2861s] threads: 64, tps: 0.00, reads: 172390.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2862s] threads: 64, tps: 0.00, reads: 171931.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2863s] threads: 64, tps: 0.00, reads: 172476.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2864s] threads: 64, tps: 0.00, reads: 172456.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2865s] threads: 64, tps: 0.00, reads: 172382.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2866s] threads: 64, tps: 0.00, reads: 172778.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2867s] threads: 64, tps: 0.00, reads: 172682.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2868s] threads: 64, tps: 0.00, reads: 172339.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2869s] threads: 64, tps: 0.00, reads: 172584.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2870s] threads: 64, tps: 0.00, reads: 172326.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2871s] threads: 64, tps: 0.00, reads: 172356.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2872s] threads: 64, tps: 0.00, reads: 172072.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2873s] threads: 64, tps: 0.00, reads: 172635.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2874s] threads: 64, tps: 0.00, reads: 172218.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2875s] threads: 64, tps: 0.00, reads: 172184.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2876s] threads: 64, tps: 0.00, reads: 171841.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2877s] threads: 64, tps: 0.00, reads: 171445.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2878s] threads: 64, tps: 0.00, reads: 171544.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2879s] threads: 64, tps: 0.00, reads: 172851.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2880s] threads: 64, tps: 0.00, reads: 171922.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2881s] threads: 64, tps: 0.00, reads: 172394.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2882s] threads: 64, tps: 0.00, reads: 172404.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2883s] threads: 64, tps: 0.00, reads: 172727.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2884s] threads: 64, tps: 0.00, reads: 172748.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2885s] threads: 64, tps: 0.00, reads: 173283.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2886s] threads: 64, tps: 0.00, reads: 173141.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2887s] threads: 64, tps: 0.00, reads: 172611.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2888s] threads: 64, tps: 0.00, reads: 172487.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2889s] threads: 64, tps: 0.00, reads: 172680.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2890s] threads: 64, tps: 0.00, reads: 172834.21, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2891s] threads: 64, tps: 0.00, reads: 172646.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2892s] threads: 64, tps: 0.00, reads: 173143.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2893s] threads: 64, tps: 0.00, reads: 172586.86, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2894s] threads: 64, tps: 0.00, reads: 172756.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2895s] threads: 64, tps: 0.00, reads: 172630.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2896s] threads: 64, tps: 0.00, reads: 172750.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2897s] threads: 64, tps: 0.00, reads: 172631.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2898s] threads: 64, tps: 0.00, reads: 173285.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2899s] threads: 64, tps: 0.00, reads: 172728.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2900s] threads: 64, tps: 0.00, reads: 172735.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2901s] threads: 64, tps: 0.00, reads: 172759.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2902s] threads: 64, tps: 0.00, reads: 172775.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2903s] threads: 64, tps: 0.00, reads: 172710.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2904s] threads: 64, tps: 0.00, reads: 173661.91, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2905s] threads: 64, tps: 0.00, reads: 172871.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2906s] threads: 64, tps: 0.00, reads: 172835.07, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2907s] threads: 64, tps: 0.00, reads: 172762.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2908s] threads: 64, tps: 0.00, reads: 172871.69, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2909s] threads: 64, tps: 0.00, reads: 172968.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2910s] threads: 64, tps: 0.00, reads: 173412.07, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2911s] threads: 64, tps: 0.00, reads: 173068.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2912s] threads: 64, tps: 0.00, reads: 172713.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2913s] threads: 64, tps: 0.00, reads: 172822.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2914s] threads: 64, tps: 0.00, reads: 173037.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2915s] threads: 64, tps: 0.00, reads: 173042.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2916s] threads: 64, tps: 0.00, reads: 173276.50, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2917s] threads: 64, tps: 0.00, reads: 173482.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2918s] threads: 64, tps: 0.00, reads: 172684.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2919s] threads: 64, tps: 0.00, reads: 172459.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2920s] threads: 64, tps: 0.00, reads: 172418.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2921s] threads: 64, tps: 0.00, reads: 172332.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2922s] threads: 64, tps: 0.00, reads: 172539.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2923s] threads: 64, tps: 0.00, reads: 173163.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2924s] threads: 64, tps: 0.00, reads: 172693.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2925s] threads: 64, tps: 0.00, reads: 172608.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2926s] threads: 64, tps: 0.00, reads: 172329.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2927s] threads: 64, tps: 0.00, reads: 172293.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2928s] threads: 64, tps: 0.00, reads: 172307.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2929s] threads: 64, tps: 0.00, reads: 172690.67, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2930s] threads: 64, tps: 0.00, reads: 172639.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2931s] threads: 64, tps: 0.00, reads: 172370.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2932s] threads: 64, tps: 0.00, reads: 172080.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2933s] threads: 64, tps: 0.00, reads: 172250.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2934s] threads: 64, tps: 0.00, reads: 171941.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2935s] threads: 64, tps: 0.00, reads: 171621.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2936s] threads: 64, tps: 0.00, reads: 172561.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2937s] threads: 64, tps: 0.00, reads: 171912.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2938s] threads: 64, tps: 0.00, reads: 171767.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2939s] threads: 64, tps: 0.00, reads: 172008.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2940s] threads: 64, tps: 0.00, reads: 172106.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2941s] threads: 64, tps: 0.00, reads: 171648.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2942s] threads: 64, tps: 0.00, reads: 172751.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2943s] threads: 64, tps: 0.00, reads: 172687.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2944s] threads: 64, tps: 0.00, reads: 172694.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2945s] threads: 64, tps: 0.00, reads: 172556.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2946s] threads: 64, tps: 0.00, reads: 172676.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2947s] threads: 64, tps: 0.00, reads: 172692.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2948s] threads: 64, tps: 0.00, reads: 172959.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2949s] threads: 64, tps: 0.00, reads: 172967.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2950s] threads: 64, tps: 0.00, reads: 172481.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2951s] threads: 64, tps: 0.00, reads: 172842.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2952s] threads: 64, tps: 0.00, reads: 172950.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2953s] threads: 64, tps: 0.00, reads: 172898.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2954s] threads: 64, tps: 0.00, reads: 172923.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2955s] threads: 64, tps: 0.00, reads: 172629.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2956s] threads: 64, tps: 0.00, reads: 172736.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2957s] threads: 64, tps: 0.00, reads: 172725.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2958s] threads: 64, tps: 0.00, reads: 172758.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2959s] threads: 64, tps: 0.00, reads: 171998.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2960s] threads: 64, tps: 0.00, reads: 172808.06, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2961s] threads: 64, tps: 0.00, reads: 173367.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2962s] threads: 64, tps: 0.00, reads: 172762.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2963s] threads: 64, tps: 0.00, reads: 172606.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2964s] threads: 64, tps: 0.00, reads: 172534.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2965s] threads: 64, tps: 0.00, reads: 173304.31, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2966s] threads: 64, tps: 0.00, reads: 173102.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2967s] threads: 64, tps: 0.00, reads: 173821.04, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2968s] threads: 64, tps: 0.00, reads: 172988.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2969s] threads: 64, tps: 0.00, reads: 172568.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2970s] threads: 64, tps: 0.00, reads: 172881.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2971s] threads: 64, tps: 0.00, reads: 172976.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2972s] threads: 64, tps: 0.00, reads: 173000.62, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2973s] threads: 64, tps: 0.00, reads: 173863.01, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2974s] threads: 64, tps: 0.00, reads: 172810.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2975s] threads: 64, tps: 0.00, reads: 172888.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2976s] threads: 64, tps: 0.00, reads: 172946.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2977s] threads: 64, tps: 0.00, reads: 172607.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2978s] threads: 64, tps: 0.00, reads: 172353.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2979s] threads: 64, tps: 0.00, reads: 172641.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2980s] threads: 64, tps: 0.00, reads: 173104.92, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2981s] threads: 64, tps: 0.00, reads: 172698.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2982s] threads: 64, tps: 0.00, reads: 172217.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2983s] threads: 64, tps: 0.00, reads: 172459.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2984s] threads: 64, tps: 0.00, reads: 172177.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2985s] threads: 64, tps: 0.00, reads: 172573.14, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2986s] threads: 64, tps: 0.00, reads: 172965.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2987s] threads: 64, tps: 0.00, reads: 172314.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2988s] threads: 64, tps: 0.00, reads: 172245.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2989s] threads: 64, tps: 0.00, reads: 172108.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2990s] threads: 64, tps: 0.00, reads: 172329.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2991s] threads: 64, tps: 0.00, reads: 172287.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2992s] threads: 64, tps: 0.00, reads: 173078.56, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[2993s] threads: 64, tps: 0.00, reads: 171643.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2994s] threads: 64, tps: 0.00, reads: 171622.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2995s] threads: 64, tps: 0.00, reads: 171803.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2996s] threads: 64, tps: 0.00, reads: 171910.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2997s] threads: 64, tps: 0.00, reads: 171941.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2998s] threads: 64, tps: 0.00, reads: 172851.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[2999s] threads: 64, tps: 0.00, reads: 171766.38, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3000s] threads: 64, tps: 0.00, reads: 172062.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3001s] threads: 64, tps: 0.00, reads: 172538.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3002s] threads: 64, tps: 0.00, reads: 172619.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3003s] threads: 64, tps: 0.00, reads: 172283.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3004s] threads: 64, tps: 0.00, reads: 173192.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3005s] threads: 64, tps: 0.00, reads: 172886.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3006s] threads: 64, tps: 0.00, reads: 172929.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3007s] threads: 64, tps: 0.00, reads: 172768.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3008s] threads: 64, tps: 0.00, reads: 172330.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3009s] threads: 64, tps: 0.00, reads: 172379.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3010s] threads: 64, tps: 0.00, reads: 172932.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3011s] threads: 64, tps: 0.00, reads: 172896.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3012s] threads: 64, tps: 0.00, reads: 172670.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3013s] threads: 64, tps: 0.00, reads: 172606.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3014s] threads: 64, tps: 0.00, reads: 172604.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3015s] threads: 64, tps: 0.00, reads: 172563.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3016s] threads: 64, tps: 0.00, reads: 172877.35, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3017s] threads: 64, tps: 0.00, reads: 173238.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3018s] threads: 64, tps: 0.00, reads: 172683.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3019s] threads: 64, tps: 0.00, reads: 172375.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3020s] threads: 64, tps: 0.00, reads: 172527.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3021s] threads: 64, tps: 0.00, reads: 171198.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3022s] threads: 64, tps: 0.00, reads: 173223.24, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3023s] threads: 64, tps: 0.00, reads: 172923.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3024s] threads: 64, tps: 0.00, reads: 172514.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3025s] threads: 64, tps: 0.00, reads: 172229.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3026s] threads: 64, tps: 0.00, reads: 172913.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3027s] threads: 64, tps: 0.00, reads: 172794.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3028s] threads: 64, tps: 0.00, reads: 172900.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3029s] threads: 64, tps: 0.00, reads: 173520.31, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3030s] threads: 64, tps: 0.00, reads: 172943.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3031s] threads: 64, tps: 0.00, reads: 172793.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3032s] threads: 64, tps: 0.00, reads: 172795.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3033s] threads: 64, tps: 0.00, reads: 172807.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3034s] threads: 64, tps: 0.00, reads: 172954.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3035s] threads: 64, tps: 0.00, reads: 173367.69, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3036s] threads: 64, tps: 0.00, reads: 172609.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3037s] threads: 64, tps: 0.00, reads: 172709.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3038s] threads: 64, tps: 0.00, reads: 172866.46, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3039s] threads: 64, tps: 0.00, reads: 172549.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3040s] threads: 64, tps: 0.00, reads: 172409.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3041s] threads: 64, tps: 0.00, reads: 173379.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3042s] threads: 64, tps: 0.00, reads: 172802.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3043s] threads: 64, tps: 0.00, reads: 172497.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3044s] threads: 64, tps: 0.00, reads: 172494.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3045s] threads: 64, tps: 0.00, reads: 172190.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3046s] threads: 64, tps: 0.00, reads: 172492.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3047s] threads: 64, tps: 0.00, reads: 173112.08, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3048s] threads: 64, tps: 0.00, reads: 172679.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3049s] threads: 64, tps: 0.00, reads: 172574.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3050s] threads: 64, tps: 0.00, reads: 171977.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3051s] threads: 64, tps: 0.00, reads: 172320.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3052s] threads: 64, tps: 0.00, reads: 172308.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3053s] threads: 64, tps: 0.00, reads: 172491.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3054s] threads: 64, tps: 0.00, reads: 172479.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3055s] threads: 64, tps: 0.00, reads: 171894.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3056s] threads: 64, tps: 0.00, reads: 171789.12, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[3057s] threads: 64, tps: 0.00, reads: 172011.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3058s] threads: 64, tps: 0.00, reads: 171963.48, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3059s] threads: 64, tps: 0.00, reads: 172100.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3060s] threads: 64, tps: 0.00, reads: 172263.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3061s] threads: 64, tps: 0.00, reads: 172280.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3062s] threads: 64, tps: 0.00, reads: 172530.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3063s] threads: 64, tps: 0.00, reads: 172551.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3064s] threads: 64, tps: 0.00, reads: 172211.26, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3065s] threads: 64, tps: 0.00, reads: 172271.61, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3066s] threads: 64, tps: 0.00, reads: 172808.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3067s] threads: 64, tps: 0.00, reads: 172116.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3068s] threads: 64, tps: 0.00, reads: 172369.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3069s] threads: 64, tps: 0.00, reads: 172332.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3070s] threads: 64, tps: 0.00, reads: 172544.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3071s] threads: 64, tps: 0.00, reads: 172666.45, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3072s] threads: 64, tps: 0.00, reads: 173177.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3073s] threads: 64, tps: 0.00, reads: 172670.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3074s] threads: 64, tps: 0.00, reads: 172775.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3075s] threads: 64, tps: 0.00, reads: 172491.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3076s] threads: 64, tps: 0.00, reads: 172723.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3077s] threads: 64, tps: 0.00, reads: 172662.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3078s] threads: 64, tps: 0.00, reads: 173459.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3079s] threads: 64, tps: 0.00, reads: 172760.52, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3080s] threads: 64, tps: 0.00, reads: 172143.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3081s] threads: 64, tps: 0.00, reads: 172475.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3082s] threads: 64, tps: 0.00, reads: 172713.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3083s] threads: 64, tps: 0.00, reads: 172807.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3084s] threads: 64, tps: 0.00, reads: 173340.09, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3085s] threads: 64, tps: 0.00, reads: 172774.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3086s] threads: 64, tps: 0.00, reads: 173274.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3087s] threads: 64, tps: 0.00, reads: 172915.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3088s] threads: 64, tps: 0.00, reads: 172896.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3089s] threads: 64, tps: 0.00, reads: 172417.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3090s] threads: 64, tps: 0.00, reads: 173013.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3091s] threads: 64, tps: 0.00, reads: 173263.54, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3092s] threads: 64, tps: 0.00, reads: 172869.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3093s] threads: 64, tps: 0.00, reads: 172801.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3094s] threads: 64, tps: 0.00, reads: 172644.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3095s] threads: 64, tps: 0.00, reads: 172901.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3096s] threads: 64, tps: 0.00, reads: 172645.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3097s] threads: 64, tps: 0.00, reads: 173178.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3098s] threads: 64, tps: 0.00, reads: 172519.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3099s] threads: 64, tps: 0.00, reads: 172481.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3100s] threads: 64, tps: 0.00, reads: 172540.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3101s] threads: 64, tps: 0.00, reads: 172489.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3102s] threads: 64, tps: 0.00, reads: 172660.76, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3103s] threads: 64, tps: 0.00, reads: 173102.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3104s] threads: 64, tps: 0.00, reads: 172383.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3105s] threads: 64, tps: 0.00, reads: 172189.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3106s] threads: 64, tps: 0.00, reads: 172303.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3107s] threads: 64, tps: 0.00, reads: 172226.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3108s] threads: 64, tps: 0.00, reads: 172405.82, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3109s] threads: 64, tps: 0.00, reads: 172972.27, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3110s] threads: 64, tps: 0.00, reads: 172069.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3111s] threads: 64, tps: 0.00, reads: 172311.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3112s] threads: 64, tps: 0.00, reads: 172256.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3113s] threads: 64, tps: 0.00, reads: 172046.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3114s] threads: 64, tps: 0.00, reads: 171894.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3115s] threads: 64, tps: 0.00, reads: 172463.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3116s] threads: 64, tps: 0.00, reads: 171770.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3117s] threads: 64, tps: 0.00, reads: 171956.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3118s] threads: 64, tps: 0.00, reads: 172118.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3119s] threads: 64, tps: 0.00, reads: 172093.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3120s] threads: 64, tps: 0.00, reads: 172299.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3121s] threads: 64, tps: 0.00, reads: 173082.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3122s] threads: 64, tps: 0.00, reads: 172550.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3123s] threads: 64, tps: 0.00, reads: 172489.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3124s] threads: 64, tps: 0.00, reads: 172418.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3125s] threads: 64, tps: 0.00, reads: 172787.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3126s] threads: 64, tps: 0.00, reads: 172557.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3127s] threads: 64, tps: 0.00, reads: 173522.04, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3128s] threads: 64, tps: 0.00, reads: 173144.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3129s] threads: 64, tps: 0.00, reads: 172818.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3130s] threads: 64, tps: 0.00, reads: 172286.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3131s] threads: 64, tps: 0.00, reads: 172482.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3132s] threads: 64, tps: 0.00, reads: 172383.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3133s] threads: 64, tps: 0.00, reads: 173211.61, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3134s] threads: 64, tps: 0.00, reads: 173031.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3135s] threads: 64, tps: 0.00, reads: 172471.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3136s] threads: 64, tps: 0.00, reads: 172880.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3137s] threads: 64, tps: 0.00, reads: 172654.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3138s] threads: 64, tps: 0.00, reads: 172560.78, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3139s] threads: 64, tps: 0.00, reads: 173414.32, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3140s] threads: 64, tps: 0.00, reads: 172586.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3141s] threads: 64, tps: 0.00, reads: 172654.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3142s] threads: 64, tps: 0.00, reads: 172817.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3143s] threads: 64, tps: 0.00, reads: 172876.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3144s] threads: 64, tps: 0.00, reads: 172924.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3145s] threads: 64, tps: 0.00, reads: 173379.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3146s] threads: 64, tps: 0.00, reads: 172722.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3147s] threads: 64, tps: 0.00, reads: 172780.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3148s] threads: 64, tps: 0.00, reads: 172892.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3149s] threads: 64, tps: 0.00, reads: 172779.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3150s] threads: 64, tps: 0.00, reads: 172949.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3151s] threads: 64, tps: 0.00, reads: 173312.12, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3152s] threads: 64, tps: 0.00, reads: 173289.81, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3153s] threads: 64, tps: 0.00, reads: 172781.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3154s] threads: 64, tps: 0.00, reads: 172577.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3155s] threads: 64, tps: 0.00, reads: 172716.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3156s] threads: 64, tps: 0.00, reads: 172696.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3157s] threads: 64, tps: 0.00, reads: 172923.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3158s] threads: 64, tps: 0.00, reads: 173213.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3159s] threads: 64, tps: 0.00, reads: 172448.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3160s] threads: 64, tps: 0.00, reads: 172844.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3161s] threads: 64, tps: 0.00, reads: 172480.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3162s] threads: 64, tps: 0.00, reads: 172446.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3163s] threads: 64, tps: 0.00, reads: 172190.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3164s] threads: 64, tps: 0.00, reads: 172686.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3165s] threads: 64, tps: 0.00, reads: 172060.41, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3166s] threads: 64, tps: 0.00, reads: 172417.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3167s] threads: 64, tps: 0.00, reads: 172396.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3168s] threads: 64, tps: 0.00, reads: 172329.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3169s] threads: 64, tps: 0.00, reads: 172819.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3170s] threads: 64, tps: 0.00, reads: 172418.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3171s] threads: 64, tps: 0.00, reads: 171897.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3172s] threads: 64, tps: 0.00, reads: 172120.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3173s] threads: 64, tps: 0.00, reads: 171861.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3174s] threads: 64, tps: 0.00, reads: 171503.11, writes: 0.00, response time: 0.47ms (95%), errors: 0.00, reconnects:  0.00
[3175s] threads: 64, tps: 0.00, reads: 171858.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3176s] threads: 64, tps: 0.00, reads: 172654.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3177s] threads: 64, tps: 0.00, reads: 172295.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3178s] threads: 64, tps: 0.00, reads: 172084.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3179s] threads: 64, tps: 0.00, reads: 171811.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3180s] threads: 64, tps: 0.00, reads: 171279.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3181s] threads: 64, tps: 0.00, reads: 172085.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3182s] threads: 64, tps: 0.00, reads: 172536.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3183s] threads: 64, tps: 0.00, reads: 173011.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3184s] threads: 64, tps: 0.00, reads: 171691.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3185s] threads: 64, tps: 0.00, reads: 172940.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3186s] threads: 64, tps: 0.00, reads: 172651.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3187s] threads: 64, tps: 0.00, reads: 172402.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3188s] threads: 64, tps: 0.00, reads: 173081.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3189s] threads: 64, tps: 0.00, reads: 173113.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3190s] threads: 64, tps: 0.00, reads: 172470.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3191s] threads: 64, tps: 0.00, reads: 172628.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3192s] threads: 64, tps: 0.00, reads: 172242.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3193s] threads: 64, tps: 0.00, reads: 172847.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3194s] threads: 64, tps: 0.00, reads: 172550.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3195s] threads: 64, tps: 0.00, reads: 173432.00, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3196s] threads: 64, tps: 0.00, reads: 172852.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3197s] threads: 64, tps: 0.00, reads: 172650.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3198s] threads: 64, tps: 0.00, reads: 172543.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3199s] threads: 64, tps: 0.00, reads: 172494.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3200s] threads: 64, tps: 0.00, reads: 172774.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3201s] threads: 64, tps: 0.00, reads: 173506.20, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3202s] threads: 64, tps: 0.00, reads: 172970.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3203s] threads: 64, tps: 0.00, reads: 172863.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3204s] threads: 64, tps: 0.00, reads: 172729.06, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3205s] threads: 64, tps: 0.00, reads: 172880.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3206s] threads: 64, tps: 0.00, reads: 172943.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3207s] threads: 64, tps: 0.00, reads: 172990.45, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3208s] threads: 64, tps: 0.00, reads: 173405.86, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3209s] threads: 64, tps: 0.00, reads: 172891.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3210s] threads: 64, tps: 0.00, reads: 172896.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3211s] threads: 64, tps: 0.00, reads: 172786.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3212s] threads: 64, tps: 0.00, reads: 172724.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3213s] threads: 64, tps: 0.00, reads: 173286.95, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3214s] threads: 64, tps: 0.00, reads: 173166.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3215s] threads: 64, tps: 0.00, reads: 172694.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3216s] threads: 64, tps: 0.00, reads: 172893.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3217s] threads: 64, tps: 0.00, reads: 172849.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3218s] threads: 64, tps: 0.00, reads: 172927.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3219s] threads: 64, tps: 0.00, reads: 172792.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3220s] threads: 64, tps: 0.00, reads: 173537.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3221s] threads: 64, tps: 0.00, reads: 172784.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3222s] threads: 64, tps: 0.00, reads: 172541.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3223s] threads: 64, tps: 0.00, reads: 172423.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3224s] threads: 64, tps: 0.00, reads: 172405.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3225s] threads: 64, tps: 0.00, reads: 172531.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3226s] threads: 64, tps: 0.00, reads: 173315.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3227s] threads: 64, tps: 0.00, reads: 172395.40, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3228s] threads: 64, tps: 0.00, reads: 172519.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3229s] threads: 64, tps: 0.00, reads: 172221.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3230s] threads: 64, tps: 0.00, reads: 172183.43, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3231s] threads: 64, tps: 0.00, reads: 172081.59, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3232s] threads: 64, tps: 0.00, reads: 172822.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3233s] threads: 64, tps: 0.00, reads: 172218.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3234s] threads: 64, tps: 0.00, reads: 171671.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3235s] threads: 64, tps: 0.00, reads: 171229.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3236s] threads: 64, tps: 0.00, reads: 171586.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3237s] threads: 64, tps: 0.00, reads: 171578.53, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3238s] threads: 64, tps: 0.00, reads: 172090.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3239s] threads: 64, tps: 0.00, reads: 172146.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3240s] threads: 64, tps: 0.00, reads: 171835.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3241s] threads: 64, tps: 0.00, reads: 171625.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3242s] threads: 64, tps: 0.00, reads: 171832.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3243s] threads: 64, tps: 0.00, reads: 172333.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3244s] threads: 64, tps: 0.00, reads: 172867.04, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3245s] threads: 64, tps: 0.00, reads: 173027.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3246s] threads: 64, tps: 0.00, reads: 172615.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3247s] threads: 64, tps: 0.00, reads: 172422.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3248s] threads: 64, tps: 0.00, reads: 172715.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3249s] threads: 64, tps: 0.00, reads: 172839.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3250s] threads: 64, tps: 0.00, reads: 173255.45, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3251s] threads: 64, tps: 0.00, reads: 173453.57, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3252s] threads: 64, tps: 0.00, reads: 172528.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3253s] threads: 64, tps: 0.00, reads: 172750.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3254s] threads: 64, tps: 0.00, reads: 172229.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3255s] threads: 64, tps: 0.00, reads: 172065.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3256s] threads: 64, tps: 0.00, reads: 172817.01, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3257s] threads: 64, tps: 0.00, reads: 173119.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3258s] threads: 64, tps: 0.00, reads: 172773.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3259s] threads: 64, tps: 0.00, reads: 172416.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3260s] threads: 64, tps: 0.00, reads: 172697.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3261s] threads: 64, tps: 0.00, reads: 172246.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3262s] threads: 64, tps: 0.00, reads: 172591.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3263s] threads: 64, tps: 0.00, reads: 173149.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3264s] threads: 64, tps: 0.00, reads: 173064.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3265s] threads: 64, tps: 0.00, reads: 172129.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3266s] threads: 64, tps: 0.00, reads: 173053.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3267s] threads: 64, tps: 0.00, reads: 172887.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3268s] threads: 64, tps: 0.00, reads: 172783.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3269s] threads: 64, tps: 0.00, reads: 173416.80, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3270s] threads: 64, tps: 0.00, reads: 173226.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3271s] threads: 64, tps: 0.00, reads: 172716.13, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3272s] threads: 64, tps: 0.00, reads: 172887.86, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3273s] threads: 64, tps: 0.00, reads: 172752.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3274s] threads: 64, tps: 0.00, reads: 173187.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3275s] threads: 64, tps: 0.00, reads: 172845.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3276s] threads: 64, tps: 0.00, reads: 173429.43, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3277s] threads: 64, tps: 0.00, reads: 172836.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3278s] threads: 64, tps: 0.00, reads: 172793.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3279s] threads: 64, tps: 0.00, reads: 172839.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3280s] threads: 64, tps: 0.00, reads: 172559.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3281s] threads: 64, tps: 0.00, reads: 172581.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3282s] threads: 64, tps: 0.00, reads: 173372.80, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3283s] threads: 64, tps: 0.00, reads: 172489.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3284s] threads: 64, tps: 0.00, reads: 172243.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3285s] threads: 64, tps: 0.00, reads: 172364.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3286s] threads: 64, tps: 0.00, reads: 172378.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3287s] threads: 64, tps: 0.00, reads: 172435.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3288s] threads: 64, tps: 0.00, reads: 172876.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3289s] threads: 64, tps: 0.00, reads: 171906.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3290s] threads: 64, tps: 0.00, reads: 172253.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3291s] threads: 64, tps: 0.00, reads: 171940.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3292s] threads: 64, tps: 0.00, reads: 172037.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3293s] threads: 64, tps: 0.00, reads: 171832.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3294s] threads: 64, tps: 0.00, reads: 172485.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3295s] threads: 64, tps: 0.00, reads: 171832.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3296s] threads: 64, tps: 0.00, reads: 171940.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3297s] threads: 64, tps: 0.00, reads: 171875.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3298s] threads: 64, tps: 0.00, reads: 172462.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3299s] threads: 64, tps: 0.00, reads: 171860.47, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3300s] threads: 64, tps: 0.00, reads: 172241.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3301s] threads: 64, tps: 0.00, reads: 172273.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3302s] threads: 64, tps: 0.00, reads: 172265.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3303s] threads: 64, tps: 0.00, reads: 172290.18, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3304s] threads: 64, tps: 0.00, reads: 172559.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3305s] threads: 64, tps: 0.00, reads: 172421.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3306s] threads: 64, tps: 0.00, reads: 172920.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3307s] threads: 64, tps: 0.00, reads: 173223.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3308s] threads: 64, tps: 0.00, reads: 172644.80, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3309s] threads: 64, tps: 0.00, reads: 172635.64, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3310s] threads: 64, tps: 0.00, reads: 171706.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3311s] threads: 64, tps: 0.00, reads: 172911.45, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3312s] threads: 64, tps: 0.00, reads: 173077.38, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3313s] threads: 64, tps: 0.00, reads: 173114.73, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3314s] threads: 64, tps: 0.00, reads: 172644.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3315s] threads: 64, tps: 0.00, reads: 172930.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3316s] threads: 64, tps: 0.00, reads: 172586.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3317s] threads: 64, tps: 0.00, reads: 172230.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3318s] threads: 64, tps: 0.00, reads: 171774.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3319s] threads: 64, tps: 0.00, reads: 172645.90, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3320s] threads: 64, tps: 0.00, reads: 172190.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3321s] threads: 64, tps: 0.00, reads: 172453.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3322s] threads: 64, tps: 0.00, reads: 172235.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3323s] threads: 64, tps: 0.00, reads: 172655.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3324s] threads: 64, tps: 0.00, reads: 172720.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3325s] threads: 64, tps: 0.00, reads: 173456.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3326s] threads: 64, tps: 0.00, reads: 172826.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3327s] threads: 64, tps: 0.00, reads: 172455.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3328s] threads: 64, tps: 0.00, reads: 172741.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3329s] threads: 64, tps: 0.00, reads: 172803.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3330s] threads: 64, tps: 0.00, reads: 173040.37, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3331s] threads: 64, tps: 0.00, reads: 174010.69, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3332s] threads: 64, tps: 0.00, reads: 172849.12, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3333s] threads: 64, tps: 0.00, reads: 172755.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3334s] threads: 64, tps: 0.00, reads: 172931.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3335s] threads: 64, tps: 0.00, reads: 172812.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3336s] threads: 64, tps: 0.00, reads: 172701.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3337s] threads: 64, tps: 0.00, reads: 173505.12, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3338s] threads: 64, tps: 0.00, reads: 172835.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3339s] threads: 64, tps: 0.00, reads: 172821.09, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3340s] threads: 64, tps: 0.00, reads: 172787.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3341s] threads: 64, tps: 0.00, reads: 172487.38, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3342s] threads: 64, tps: 0.00, reads: 172560.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3343s] threads: 64, tps: 0.00, reads: 173150.92, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3344s] threads: 64, tps: 0.00, reads: 172783.03, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3345s] threads: 64, tps: 0.00, reads: 172617.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3346s] threads: 64, tps: 0.00, reads: 172524.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3347s] threads: 64, tps: 0.00, reads: 173019.24, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3348s] threads: 64, tps: 0.00, reads: 172677.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3349s] threads: 64, tps: 0.00, reads: 172994.61, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3350s] threads: 64, tps: 0.00, reads: 172769.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3351s] threads: 64, tps: 0.00, reads: 171786.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3352s] threads: 64, tps: 0.00, reads: 172370.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3353s] threads: 64, tps: 0.00, reads: 172001.68, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3354s] threads: 64, tps: 0.00, reads: 171801.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3355s] threads: 64, tps: 0.00, reads: 172397.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3356s] threads: 64, tps: 0.00, reads: 172336.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3357s] threads: 64, tps: 0.00, reads: 171869.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3358s] threads: 64, tps: 0.00, reads: 172057.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3359s] threads: 64, tps: 0.00, reads: 171629.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3360s] threads: 64, tps: 0.00, reads: 171915.44, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3361s] threads: 64, tps: 0.00, reads: 171500.42, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3362s] threads: 64, tps: 0.00, reads: 172925.96, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3363s] threads: 64, tps: 0.00, reads: 172860.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3364s] threads: 64, tps: 0.00, reads: 172346.16, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3365s] threads: 64, tps: 0.00, reads: 172556.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3366s] threads: 64, tps: 0.00, reads: 172411.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3367s] threads: 64, tps: 0.00, reads: 172776.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3368s] threads: 64, tps: 0.00, reads: 173272.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3369s] threads: 64, tps: 0.00, reads: 172191.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3370s] threads: 64, tps: 0.00, reads: 172498.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3371s] threads: 64, tps: 0.00, reads: 172829.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3372s] threads: 64, tps: 0.00, reads: 172412.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3373s] threads: 64, tps: 0.00, reads: 172692.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3374s] threads: 64, tps: 0.00, reads: 173429.10, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3375s] threads: 64, tps: 0.00, reads: 172831.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3376s] threads: 64, tps: 0.00, reads: 172794.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3377s] threads: 64, tps: 0.00, reads: 172913.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3378s] threads: 64, tps: 0.00, reads: 172938.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3379s] threads: 64, tps: 0.00, reads: 173313.11, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3380s] threads: 64, tps: 0.00, reads: 173490.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3381s] threads: 64, tps: 0.00, reads: 172608.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3382s] threads: 64, tps: 0.00, reads: 172948.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3383s] threads: 64, tps: 0.00, reads: 172804.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3384s] threads: 64, tps: 0.00, reads: 172677.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3385s] threads: 64, tps: 0.00, reads: 172584.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3386s] threads: 64, tps: 0.00, reads: 173287.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3387s] threads: 64, tps: 0.00, reads: 173179.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3388s] threads: 64, tps: 0.00, reads: 172770.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3389s] threads: 64, tps: 0.00, reads: 172677.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3390s] threads: 64, tps: 0.00, reads: 172667.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3391s] threads: 64, tps: 0.00, reads: 172603.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3392s] threads: 64, tps: 0.00, reads: 173197.13, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3393s] threads: 64, tps: 0.00, reads: 172921.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3394s] threads: 64, tps: 0.00, reads: 172750.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3395s] threads: 64, tps: 0.00, reads: 172905.50, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3396s] threads: 64, tps: 0.00, reads: 172917.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3397s] threads: 64, tps: 0.00, reads: 172776.46, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3398s] threads: 64, tps: 0.00, reads: 172723.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3399s] threads: 64, tps: 0.00, reads: 172932.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3400s] threads: 64, tps: 0.00, reads: 172613.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3401s] threads: 64, tps: 0.00, reads: 172572.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3402s] threads: 64, tps: 0.00, reads: 172759.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3403s] threads: 64, tps: 0.00, reads: 172719.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3404s] threads: 64, tps: 0.00, reads: 173229.73, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3405s] threads: 64, tps: 0.00, reads: 172926.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3406s] threads: 64, tps: 0.00, reads: 172571.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3407s] threads: 64, tps: 0.00, reads: 172456.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3408s] threads: 64, tps: 0.00, reads: 172341.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3409s] threads: 64, tps: 0.00, reads: 172157.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3410s] threads: 64, tps: 0.00, reads: 172737.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3411s] threads: 64, tps: 0.00, reads: 172596.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3412s] threads: 64, tps: 0.00, reads: 172305.45, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3413s] threads: 64, tps: 0.00, reads: 172154.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3414s] threads: 64, tps: 0.00, reads: 171898.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3415s] threads: 64, tps: 0.00, reads: 172031.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3416s] threads: 64, tps: 0.00, reads: 172682.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3417s] threads: 64, tps: 0.00, reads: 172374.09, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3418s] threads: 64, tps: 0.00, reads: 172317.96, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3419s] threads: 64, tps: 0.00, reads: 172152.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3420s] threads: 64, tps: 0.00, reads: 172096.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3421s] threads: 64, tps: 0.00, reads: 172174.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3422s] threads: 64, tps: 0.00, reads: 172529.56, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3423s] threads: 64, tps: 0.00, reads: 172668.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3424s] threads: 64, tps: 0.00, reads: 172338.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3425s] threads: 64, tps: 0.00, reads: 171972.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3426s] threads: 64, tps: 0.00, reads: 172035.24, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3427s] threads: 64, tps: 0.00, reads: 172328.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3428s] threads: 64, tps: 0.00, reads: 173626.68, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3429s] threads: 64, tps: 0.00, reads: 172705.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3430s] threads: 64, tps: 0.00, reads: 172700.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3431s] threads: 64, tps: 0.00, reads: 172415.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3432s] threads: 64, tps: 0.00, reads: 172734.91, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3433s] threads: 64, tps: 0.00, reads: 172844.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3434s] threads: 64, tps: 0.00, reads: 172874.40, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3435s] threads: 64, tps: 0.00, reads: 173317.75, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3436s] threads: 64, tps: 0.00, reads: 172896.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3437s] threads: 64, tps: 0.00, reads: 172542.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3438s] threads: 64, tps: 0.00, reads: 172625.45, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3439s] threads: 64, tps: 0.00, reads: 172771.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3440s] threads: 64, tps: 0.00, reads: 172266.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3441s] threads: 64, tps: 0.00, reads: 173169.86, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3442s] threads: 64, tps: 0.00, reads: 173182.10, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3443s] threads: 64, tps: 0.00, reads: 172237.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3444s] threads: 64, tps: 0.00, reads: 172873.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3445s] threads: 64, tps: 0.00, reads: 172616.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3446s] threads: 64, tps: 0.00, reads: 173180.02, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3447s] threads: 64, tps: 0.00, reads: 173258.10, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3448s] threads: 64, tps: 0.00, reads: 173477.97, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3449s] threads: 64, tps: 0.00, reads: 173001.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3450s] threads: 64, tps: 0.00, reads: 172871.73, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3451s] threads: 64, tps: 0.00, reads: 172829.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3452s] threads: 64, tps: 0.00, reads: 172905.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3453s] threads: 64, tps: 0.00, reads: 173157.22, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3454s] threads: 64, tps: 0.00, reads: 173520.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3455s] threads: 64, tps: 0.00, reads: 172477.16, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3456s] threads: 64, tps: 0.00, reads: 172464.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3457s] threads: 64, tps: 0.00, reads: 172678.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3458s] threads: 64, tps: 0.00, reads: 172574.93, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3459s] threads: 64, tps: 0.00, reads: 172714.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3460s] threads: 64, tps: 0.00, reads: 173130.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3461s] threads: 64, tps: 0.00, reads: 172142.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3462s] threads: 64, tps: 0.00, reads: 172698.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3463s] threads: 64, tps: 0.00, reads: 172719.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3464s] threads: 64, tps: 0.00, reads: 172627.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3465s] threads: 64, tps: 0.00, reads: 172228.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3466s] threads: 64, tps: 0.00, reads: 173218.52, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3467s] threads: 64, tps: 0.00, reads: 172179.51, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3468s] threads: 64, tps: 0.00, reads: 172390.06, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3469s] threads: 64, tps: 0.00, reads: 172379.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3470s] threads: 64, tps: 0.00, reads: 172146.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3471s] threads: 64, tps: 0.00, reads: 172665.61, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3472s] threads: 64, tps: 0.00, reads: 172490.66, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3473s] threads: 64, tps: 0.00, reads: 172760.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3474s] threads: 64, tps: 0.00, reads: 171947.35, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3475s] threads: 64, tps: 0.00, reads: 171696.29, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3476s] threads: 64, tps: 0.00, reads: 171868.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3477s] threads: 64, tps: 0.00, reads: 171957.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3478s] threads: 64, tps: 0.00, reads: 172334.46, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3479s] threads: 64, tps: 0.00, reads: 172558.65, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3480s] threads: 64, tps: 0.00, reads: 171970.74, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3481s] threads: 64, tps: 0.00, reads: 171555.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3482s] threads: 64, tps: 0.00, reads: 172453.25, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3483s] threads: 64, tps: 0.00, reads: 172515.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3484s] threads: 64, tps: 0.00, reads: 172629.82, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3485s] threads: 64, tps: 0.00, reads: 173119.13, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3486s] threads: 64, tps: 0.00, reads: 172829.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3487s] threads: 64, tps: 0.00, reads: 172831.13, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3488s] threads: 64, tps: 0.00, reads: 172739.12, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3489s] threads: 64, tps: 0.00, reads: 172731.02, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3490s] threads: 64, tps: 0.00, reads: 172550.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3491s] threads: 64, tps: 0.00, reads: 173674.63, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3492s] threads: 64, tps: 0.00, reads: 172631.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3493s] threads: 64, tps: 0.00, reads: 172687.63, writes: 0.00, response time: 0.48ms (95%), errors: 0.00, reconnects:  0.00
[3494s] threads: 64, tps: 0.00, reads: 172662.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3495s] threads: 64, tps: 0.00, reads: 172594.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3496s] threads: 64, tps: 0.00, reads: 172564.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3497s] threads: 64, tps: 0.00, reads: 173050.65, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3498s] threads: 64, tps: 0.00, reads: 173082.83, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3499s] threads: 64, tps: 0.00, reads: 172745.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3500s] threads: 64, tps: 0.00, reads: 172348.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3501s] threads: 64, tps: 0.00, reads: 172597.84, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3502s] threads: 64, tps: 0.00, reads: 172865.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3503s] threads: 64, tps: 0.00, reads: 173386.87, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3504s] threads: 64, tps: 0.00, reads: 173429.03, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3505s] threads: 64, tps: 0.00, reads: 172909.12, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3506s] threads: 64, tps: 0.00, reads: 172576.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3507s] threads: 64, tps: 0.00, reads: 172667.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3508s] threads: 64, tps: 0.00, reads: 172562.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3509s] threads: 64, tps: 0.00, reads: 172976.27, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3510s] threads: 64, tps: 0.00, reads: 173364.02, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3511s] threads: 64, tps: 0.00, reads: 172802.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3512s] threads: 64, tps: 0.00, reads: 172965.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3513s] threads: 64, tps: 0.00, reads: 172734.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3514s] threads: 64, tps: 0.00, reads: 172512.02, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3515s] threads: 64, tps: 0.00, reads: 172629.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3516s] threads: 64, tps: 0.00, reads: 173295.76, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3517s] threads: 64, tps: 0.00, reads: 172814.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3518s] threads: 64, tps: 0.00, reads: 172727.23, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3519s] threads: 64, tps: 0.00, reads: 172780.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3520s] threads: 64, tps: 0.00, reads: 172773.97, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3521s] threads: 64, tps: 0.00, reads: 172552.00, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3522s] threads: 64, tps: 0.00, reads: 173202.06, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3523s] threads: 64, tps: 0.00, reads: 172946.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3524s] threads: 64, tps: 0.00, reads: 172429.07, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3525s] threads: 64, tps: 0.00, reads: 172043.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3526s] threads: 64, tps: 0.00, reads: 172330.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3527s] threads: 64, tps: 0.00, reads: 172359.60, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3528s] threads: 64, tps: 0.00, reads: 172974.34, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3529s] threads: 64, tps: 0.00, reads: 172719.15, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3530s] threads: 64, tps: 0.00, reads: 172082.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3531s] threads: 64, tps: 0.00, reads: 171930.81, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3532s] threads: 64, tps: 0.00, reads: 171847.21, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3533s] threads: 64, tps: 0.00, reads: 171957.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3534s] threads: 64, tps: 0.00, reads: 171757.30, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3535s] threads: 64, tps: 0.00, reads: 172410.87, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3536s] threads: 64, tps: 0.00, reads: 172260.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3537s] threads: 64, tps: 0.00, reads: 172363.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3538s] threads: 64, tps: 0.00, reads: 171992.01, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3539s] threads: 64, tps: 0.00, reads: 172044.72, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3540s] threads: 64, tps: 0.00, reads: 171858.20, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3541s] threads: 64, tps: 0.00, reads: 171685.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3542s] threads: 64, tps: 0.00, reads: 172229.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3543s] threads: 64, tps: 0.00, reads: 171922.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3544s] threads: 64, tps: 0.00, reads: 172343.89, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3545s] threads: 64, tps: 0.00, reads: 172488.03, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3546s] threads: 64, tps: 0.00, reads: 172243.04, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3547s] threads: 64, tps: 0.00, reads: 172708.29, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3548s] threads: 64, tps: 0.00, reads: 172665.19, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3549s] threads: 64, tps: 0.00, reads: 172477.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3550s] threads: 64, tps: 0.00, reads: 172607.92, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3551s] threads: 64, tps: 0.00, reads: 172550.85, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3552s] threads: 64, tps: 0.00, reads: 172757.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3553s] threads: 64, tps: 0.00, reads: 173435.33, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3554s] threads: 64, tps: 0.00, reads: 172972.98, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3555s] threads: 64, tps: 0.00, reads: 172302.14, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3556s] threads: 64, tps: 0.00, reads: 172761.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3557s] threads: 64, tps: 0.00, reads: 172639.28, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3558s] threads: 64, tps: 0.00, reads: 172813.63, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3559s] threads: 64, tps: 0.00, reads: 172613.39, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3560s] threads: 64, tps: 0.00, reads: 173209.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3561s] threads: 64, tps: 0.00, reads: 172526.90, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3562s] threads: 64, tps: 0.00, reads: 172738.88, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3563s] threads: 64, tps: 0.00, reads: 172787.34, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3564s] threads: 64, tps: 0.00, reads: 172720.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3565s] threads: 64, tps: 0.00, reads: 172808.33, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3566s] threads: 64, tps: 0.00, reads: 173272.08, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3567s] threads: 64, tps: 0.00, reads: 172545.79, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3568s] threads: 64, tps: 0.00, reads: 172863.28, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3569s] threads: 64, tps: 0.00, reads: 173102.62, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3570s] threads: 64, tps: 0.00, reads: 172545.31, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3571s] threads: 64, tps: 0.00, reads: 172669.36, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3572s] threads: 64, tps: 0.00, reads: 172793.78, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3573s] threads: 64, tps: 0.00, reads: 173263.55, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3574s] threads: 64, tps: 0.00, reads: 172744.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3575s] threads: 64, tps: 0.00, reads: 172681.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3576s] threads: 64, tps: 0.00, reads: 172719.95, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3577s] threads: 64, tps: 0.00, reads: 172611.11, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3578s] threads: 64, tps: 0.00, reads: 172945.80, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3579s] threads: 64, tps: 0.00, reads: 173475.19, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3580s] threads: 64, tps: 0.00, reads: 172211.86, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3581s] threads: 64, tps: 0.00, reads: 172732.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3582s] threads: 64, tps: 0.00, reads: 172352.70, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3583s] threads: 64, tps: 0.00, reads: 172521.49, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3584s] threads: 64, tps: 0.00, reads: 172534.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3585s] threads: 64, tps: 0.00, reads: 173255.40, writes: 0.00, response time: 0.45ms (95%), errors: 0.00, reconnects:  0.00
[3586s] threads: 64, tps: 0.00, reads: 173033.05, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3587s] threads: 64, tps: 0.00, reads: 172278.10, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3588s] threads: 64, tps: 0.00, reads: 172506.71, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3589s] threads: 64, tps: 0.00, reads: 172533.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3590s] threads: 64, tps: 0.00, reads: 171738.27, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3591s] threads: 64, tps: 0.00, reads: 172932.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3592s] threads: 64, tps: 0.00, reads: 172309.94, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3593s] threads: 64, tps: 0.00, reads: 172351.99, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3594s] threads: 64, tps: 0.00, reads: 171459.17, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3595s] threads: 64, tps: 0.00, reads: 171644.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3596s] threads: 64, tps: 0.00, reads: 171592.58, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3597s] threads: 64, tps: 0.00, reads: 172058.97, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3598s] threads: 64, tps: 0.00, reads: 172179.22, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3599s] threads: 64, tps: 0.00, reads: 171735.77, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
[3600s] threads: 64, tps: 0.00, reads: 171560.32, writes: 0.00, response time: 0.46ms (95%), errors: 0.00, reconnects:  0.00
OLTP test statistics:
    queries performed:
        read:                            613591695
        write:                           0
        other:                           0
        total:                           613591695
    transactions:                        0      (0.00 per sec.)
    read/write requests:                 613591695 (170442.11 per sec.)
    other operations:                    0      (0.00 per sec.)
    ignored errors:                      0      (0.00 per sec.)
    reconnects:                          0      (0.00 per sec.)

General statistics:
    total time:                          3600.0005s
    total number of events:              613591695
    total time taken by event execution: 229703.2157s
    response time:
         min:                                  0.06ms
         avg:                                  0.37ms
         max:                                113.11ms
         approx.  95 percentile:               0.46ms

Threads fairness:
    events (avg/stddev):           9587370.2344/17993.91
    execution time (avg/stddev):   3589.1127/0.07

