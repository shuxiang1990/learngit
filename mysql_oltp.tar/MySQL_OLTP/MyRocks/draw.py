#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-
#
# 适用于以下场景的画图需求：
# Time IOPS IO_util
#  1   223  43
#  2   231  100
#  3   230  99
#  4   300  53
#
#  数据要求：
#  1. 第一列作为X轴，会根据密集程度进行拆分
#  2. 其他列作为画图Y轴，会自动进行高度调节
#  3. 第一行必须是表头
#  4. 数据是齐整的，每一列的数量一样，不能有缺失
#  5. 不同类型的数据最好不要画在一个图里，比如磁盘QPS和磁盘RT，RT会很小，直接看不到
#  6. 如果第一个字段是时间戳，不能有年与日，只能有时分秒，因为是按照空格去分字段
#
#  已知Bug：
#  除去第一列，其他字段全是0，会报错
#
#  TODO
#  1. 是否为时间类型图的的匹配改为re匹配
#  2. 数据列有缺失，异常退出
#  3. 数据轴的提取过程，要抽象出一个方法，直接传入数据列即可
#  4. 代码变量有的不清楚，需要修改
#  5. 增加X轴数据间隔的参数，外部传参
#  6. 变更传参的方式，不用位置传参
#

import sys
import csv
import matplotlib
import matplotlib.pyplot as pl
from matplotlib.ticker import MultipleLocator
import numpy as np
import warnings
warnings.filterwarnings("ignore", module="matplotlib")


if len(sys.argv) != 4:
    print 'Usage: put with [File] [Title_Name] [Y_Name]'
    sys.exit(1)

filename = sys.argv[1]
title_name = sys.argv[2]
y_name = sys.argv[3]


# 这里有两个X的概念
# 一个是真正去画X轴上面的点的
# 一个是用于某根线，需要一个(x, y)的列表
# x_data是真正用于画X坐标轴数据的
x_data = []
# Y轴list
y_data = []
# Y轴上限
max_y = 0
# 颜色
# 去掉白色
# 有的情况下，图例太多，颜色重复了，需要增加颜色list
colors = "bgrcmyk"
color_index = 0

fig = pl.figure(figsize=(16, 9))


# 取第一行的列名
try:
    with open(filename) as f:
        reader = csv.reader(f)
        # 列名放在header里
        header = reader.next()
except csv.Error as e:
    print 'error %s, %s ' % (reader.line_num, e)
    sys.exit(-1)

# X轴名称
x_label_name = header[0].split()[0]
if x_label_name == 'Time':
    time_flag = 1
else:
    time_flag = 0


# 行数
total_lines = len(open(filename).readlines())
data_lines = total_lines - 1

# 本条线有多少数据量
x = np.arange(0, data_lines, 1)


# 计算X轴间隔
if time_flag == 0:
    if data_lines < 30:
        modx = 1
    else:
        modx = data_lines/20
    
else:
    if data_lines < 20:
        modx = 1
    else:
        modx = data_lines/8


# 取x轴数据
num = 0
f = open(filename, "r")
for line in f:
    # 隔modx个点显示一个label，否则x轴显示不下
    if num % modx == 0:
       x_data.append(line.strip().split(" ")[0])
    num += 1
f.close()
# 去掉表头
x_data = x_data[1:]


# 如果是时间类型的，要补一个0
if time_flag == 1:
    x_data.insert(0, 0)
else:
    pass


# 依次取出所有列的数据 去掉第一列 时间列
# 计数器，记录第几列
i = 0
for item in header[0].split(' ')[1:]:
    print 'Found item: ', item
    with open(filename) as f:
        reader = csv.reader(f)
        header = reader.next()
        # 去掉首行后开始取数据
        for row in reader:
            # 取第i列
            y_data.append(float(row[0].split(' ')[1:][i]))

    # 颜色采用随机
    # 每次只能画一条线，(x, y_data)是要画线的组合
    pl.plot(x, y_data, label=item, color=colors[color_index])
    color_index += 1
    # 一共就7个颜色，需要取mod
    color_index = color_index % 7
    # 取出y_data值最大
    max_y = max(max(y_data), max_y)
    # 画图，然后要清空list y_data
    y_data = []

    i = i + 1

# 在max_y基础上增加10%的浮动后再计算mody
max_y = max_y + 0.1*max_y
mody = max_y/20

# 设置两个坐标轴的范围
pl.ylim(0, max_y)
pl.xlim(modx, np.max(x))

# 设置图的底边距
pl.subplots_adjust(bottom=0.15)

# 开启网格
pl.grid()

ax = pl.gca()
# 主刻度
ax.xaxis.set_major_locator(MultipleLocator(modx))
ax.yaxis.set_major_locator(MultipleLocator(mody))

# 获取当前x轴的label
locs, labels = pl.xticks()
# 重新设置新的label, 用x_data设置
pl.xticks(locs, x_data)
pl.xticks( rotation=25 )

pl.ylabel(y_name)
pl.xlabel(x_label_name)
pl.title(title_name)

pl.legend()

# pl.show()
pl.savefig("%s.png" % title_name)
