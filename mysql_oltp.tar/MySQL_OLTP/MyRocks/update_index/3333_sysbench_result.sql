sysbench 0.5:  multi-threaded system evaluation benchmark

Running the test with following options:
Number of threads: 64
Report intermediate results every 1 second(s)
Initializing random number generator from timer.

Random number generator seed is 0 and will be ignored


Threads started!

[   1s] threads: 64, tps: 0.00, reads: 0.00, writes: 16958.89, response time: 8.81ms (95%), errors: 0.00, reconnects:  0.00
[   2s] threads: 64, tps: 0.00, reads: 0.00, writes: 22351.16, response time: 8.07ms (95%), errors: 0.00, reconnects:  0.00
[   3s] threads: 64, tps: 0.00, reads: 0.00, writes: 25156.03, response time: 7.34ms (95%), errors: 0.00, reconnects:  0.00
[   4s] threads: 64, tps: 0.00, reads: 0.00, writes: 28327.03, response time: 5.56ms (95%), errors: 0.00, reconnects:  0.00
[   5s] threads: 64, tps: 0.00, reads: 0.00, writes: 28982.97, response time: 5.56ms (95%), errors: 0.00, reconnects:  0.00
[   6s] threads: 64, tps: 0.00, reads: 0.00, writes: 29163.99, response time: 3.94ms (95%), errors: 0.00, reconnects:  0.00
[   7s] threads: 64, tps: 0.00, reads: 0.00, writes: 30555.98, response time: 3.70ms (95%), errors: 0.00, reconnects:  0.00
[   8s] threads: 64, tps: 0.00, reads: 0.00, writes: 30949.05, response time: 5.38ms (95%), errors: 0.00, reconnects:  0.00
[   9s] threads: 64, tps: 0.00, reads: 0.00, writes: 39343.98, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[  10s] threads: 64, tps: 0.00, reads: 0.00, writes: 30132.97, response time: 5.69ms (95%), errors: 0.00, reconnects:  0.00
[  11s] threads: 64, tps: 0.00, reads: 0.00, writes: 26386.04, response time: 6.35ms (95%), errors: 0.00, reconnects:  0.00
[  12s] threads: 64, tps: 0.00, reads: 0.00, writes: 24611.96, response time: 7.23ms (95%), errors: 0.00, reconnects:  0.00
[  13s] threads: 64, tps: 0.00, reads: 0.00, writes: 27432.99, response time: 5.53ms (95%), errors: 0.00, reconnects:  0.00
[  14s] threads: 64, tps: 0.00, reads: 0.00, writes: 26869.61, response time: 5.65ms (95%), errors: 0.00, reconnects:  0.00
[  15s] threads: 64, tps: 0.00, reads: 0.00, writes: 31864.54, response time: 5.66ms (95%), errors: 0.00, reconnects:  0.00
[  16s] threads: 64, tps: 0.00, reads: 0.00, writes: 38030.99, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[  17s] threads: 64, tps: 0.00, reads: 0.00, writes: 29569.99, response time: 5.40ms (95%), errors: 0.00, reconnects:  0.00
[  18s] threads: 64, tps: 0.00, reads: 0.00, writes: 28355.98, response time: 5.78ms (95%), errors: 0.00, reconnects:  0.00
[  19s] threads: 64, tps: 0.00, reads: 0.00, writes: 30334.15, response time: 3.96ms (95%), errors: 0.00, reconnects:  0.00
[  20s] threads: 64, tps: 0.00, reads: 0.00, writes: 29780.81, response time: 4.05ms (95%), errors: 0.00, reconnects:  0.00
[  21s] threads: 64, tps: 0.00, reads: 0.00, writes: 27920.00, response time: 5.27ms (95%), errors: 0.00, reconnects:  0.00
[  22s] threads: 64, tps: 0.00, reads: 0.00, writes: 36200.01, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[  23s] threads: 64, tps: 0.00, reads: 0.00, writes: 33140.97, response time: 3.97ms (95%), errors: 0.00, reconnects:  0.00
[  24s] threads: 64, tps: 0.00, reads: 0.00, writes: 25095.80, response time: 6.18ms (95%), errors: 0.00, reconnects:  0.00
[  25s] threads: 64, tps: 0.00, reads: 0.00, writes: 24412.19, response time: 6.55ms (95%), errors: 0.00, reconnects:  0.00
[  26s] threads: 64, tps: 0.00, reads: 0.00, writes: 30876.98, response time: 3.42ms (95%), errors: 0.00, reconnects:  0.00
[  27s] threads: 64, tps: 0.00, reads: 0.00, writes: 36301.03, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[  28s] threads: 64, tps: 0.00, reads: 0.00, writes: 39430.93, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[  29s] threads: 64, tps: 0.00, reads: 0.00, writes: 38335.06, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[  30s] threads: 64, tps: 0.00, reads: 0.00, writes: 28031.22, response time: 6.16ms (95%), errors: 0.00, reconnects:  0.00
[  31s] threads: 64, tps: 0.00, reads: 0.00, writes: 25916.63, response time: 6.05ms (95%), errors: 0.00, reconnects:  0.00
[  32s] threads: 64, tps: 0.00, reads: 0.00, writes: 28815.03, response time: 4.62ms (95%), errors: 0.00, reconnects:  0.00
[  33s] threads: 64, tps: 0.00, reads: 0.00, writes: 33936.97, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[  34s] threads: 64, tps: 0.00, reads: 0.00, writes: 37511.02, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[  35s] threads: 64, tps: 0.00, reads: 0.00, writes: 39475.01, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[  36s] threads: 64, tps: 0.00, reads: 0.00, writes: 37091.93, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[  37s] threads: 64, tps: 0.00, reads: 0.00, writes: 37838.05, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[  38s] threads: 64, tps: 0.00, reads: 0.00, writes: 39015.02, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[  39s] threads: 64, tps: 0.00, reads: 0.00, writes: 38951.99, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[  40s] threads: 64, tps: 0.00, reads: 0.00, writes: 41977.96, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[  41s] threads: 64, tps: 0.00, reads: 0.00, writes: 37623.03, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[  42s] threads: 64, tps: 0.00, reads: 0.00, writes: 36534.02, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[  43s] threads: 64, tps: 0.00, reads: 0.00, writes: 38132.95, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[  44s] threads: 64, tps: 0.00, reads: 0.00, writes: 38294.98, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[  45s] threads: 64, tps: 0.00, reads: 0.00, writes: 43546.71, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[  46s] threads: 64, tps: 0.00, reads: 0.00, writes: 40589.18, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[  47s] threads: 64, tps: 0.00, reads: 0.00, writes: 38645.97, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[  48s] threads: 64, tps: 0.00, reads: 0.00, writes: 38636.03, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[  49s] threads: 64, tps: 0.00, reads: 0.00, writes: 37336.96, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[  50s] threads: 64, tps: 0.00, reads: 0.00, writes: 43031.99, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[  51s] threads: 64, tps: 0.00, reads: 0.00, writes: 40983.04, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[  52s] threads: 64, tps: 0.00, reads: 0.00, writes: 39299.00, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[  53s] threads: 64, tps: 0.00, reads: 0.00, writes: 32296.93, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[  54s] threads: 64, tps: 0.00, reads: 0.00, writes: 38494.13, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[  55s] threads: 64, tps: 0.00, reads: 0.00, writes: 43785.96, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[  56s] threads: 64, tps: 0.00, reads: 0.00, writes: 35302.97, response time: 3.87ms (95%), errors: 0.00, reconnects:  0.00
[  57s] threads: 64, tps: 0.00, reads: 0.00, writes: 31609.02, response time: 5.39ms (95%), errors: 0.00, reconnects:  0.00
[  58s] threads: 64, tps: 0.00, reads: 0.00, writes: 34842.04, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[  59s] threads: 64, tps: 0.00, reads: 0.00, writes: 34154.98, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[  60s] threads: 64, tps: 0.00, reads: 0.00, writes: 34971.97, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[  61s] threads: 64, tps: 0.00, reads: 0.00, writes: 40681.04, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[  62s] threads: 64, tps: 0.00, reads: 0.00, writes: 36738.94, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[  63s] threads: 64, tps: 0.00, reads: 0.00, writes: 32245.02, response time: 4.05ms (95%), errors: 0.00, reconnects:  0.00
[  64s] threads: 64, tps: 0.00, reads: 0.00, writes: 29203.12, response time: 4.28ms (95%), errors: 0.00, reconnects:  0.00
[  65s] threads: 64, tps: 0.00, reads: 0.00, writes: 30217.89, response time: 3.76ms (95%), errors: 0.00, reconnects:  0.00
[  66s] threads: 64, tps: 0.00, reads: 0.00, writes: 31372.06, response time: 3.80ms (95%), errors: 0.00, reconnects:  0.00
[  67s] threads: 64, tps: 0.00, reads: 0.00, writes: 39233.92, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[  68s] threads: 64, tps: 0.00, reads: 0.00, writes: 34396.00, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[  69s] threads: 64, tps: 0.00, reads: 0.00, writes: 34867.02, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[  70s] threads: 64, tps: 0.00, reads: 0.00, writes: 34723.02, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[  71s] threads: 64, tps: 0.00, reads: 0.00, writes: 37328.02, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[  72s] threads: 64, tps: 0.00, reads: 0.00, writes: 39228.93, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[  73s] threads: 64, tps: 0.00, reads: 0.00, writes: 41178.04, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[  74s] threads: 64, tps: 0.00, reads: 0.00, writes: 39760.04, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[  75s] threads: 64, tps: 0.00, reads: 0.00, writes: 38863.97, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[  76s] threads: 64, tps: 0.00, reads: 0.00, writes: 38007.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[  77s] threads: 64, tps: 0.00, reads: 0.00, writes: 42364.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[  78s] threads: 64, tps: 0.00, reads: 0.00, writes: 41456.26, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[  79s] threads: 64, tps: 0.00, reads: 0.00, writes: 38895.68, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[  80s] threads: 64, tps: 0.00, reads: 0.00, writes: 38906.02, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[  81s] threads: 64, tps: 0.00, reads: 0.00, writes: 38444.76, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[  82s] threads: 64, tps: 0.00, reads: 0.00, writes: 41755.17, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[  83s] threads: 64, tps: 0.00, reads: 0.00, writes: 42756.86, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[  84s] threads: 64, tps: 0.00, reads: 0.00, writes: 39349.11, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[  85s] threads: 64, tps: 0.00, reads: 0.00, writes: 37867.89, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[  86s] threads: 64, tps: 0.00, reads: 0.00, writes: 36875.16, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[  87s] threads: 64, tps: 0.00, reads: 0.00, writes: 36687.88, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[  88s] threads: 64, tps: 0.00, reads: 0.00, writes: 35555.93, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[  89s] threads: 64, tps: 0.00, reads: 0.00, writes: 34982.24, response time: 3.59ms (95%), errors: 0.00, reconnects:  0.00
[  90s] threads: 64, tps: 0.00, reads: 0.00, writes: 32594.84, response time: 4.09ms (95%), errors: 0.00, reconnects:  0.00
[  91s] threads: 64, tps: 0.00, reads: 0.00, writes: 30608.11, response time: 4.73ms (95%), errors: 0.00, reconnects:  0.00
[  92s] threads: 64, tps: 0.00, reads: 0.00, writes: 30734.83, response time: 4.80ms (95%), errors: 0.00, reconnects:  0.00
[  93s] threads: 64, tps: 0.00, reads: 0.00, writes: 34522.01, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[  94s] threads: 64, tps: 0.00, reads: 0.00, writes: 38655.21, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[  95s] threads: 64, tps: 0.00, reads: 0.00, writes: 32308.91, response time: 3.47ms (95%), errors: 0.00, reconnects:  0.00
[  96s] threads: 64, tps: 0.00, reads: 0.00, writes: 31114.09, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[  97s] threads: 64, tps: 0.00, reads: 0.00, writes: 31298.87, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[  98s] threads: 64, tps: 0.00, reads: 0.00, writes: 35116.11, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[  99s] threads: 64, tps: 0.00, reads: 0.00, writes: 38673.09, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 100s] threads: 64, tps: 0.00, reads: 0.00, writes: 38989.80, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 101s] threads: 64, tps: 0.00, reads: 0.00, writes: 33896.12, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 102s] threads: 64, tps: 0.00, reads: 0.00, writes: 36520.90, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 103s] threads: 64, tps: 0.00, reads: 0.00, writes: 36936.99, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 104s] threads: 64, tps: 0.00, reads: 0.00, writes: 38064.14, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[ 105s] threads: 64, tps: 0.00, reads: 0.00, writes: 42380.97, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 106s] threads: 64, tps: 0.00, reads: 0.00, writes: 37064.01, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[ 107s] threads: 64, tps: 0.00, reads: 0.00, writes: 38042.02, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 108s] threads: 64, tps: 0.00, reads: 0.00, writes: 39300.76, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 109s] threads: 64, tps: 0.00, reads: 0.00, writes: 38534.15, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 110s] threads: 64, tps: 0.00, reads: 0.00, writes: 43807.06, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 111s] threads: 64, tps: 0.00, reads: 0.00, writes: 39549.02, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 112s] threads: 64, tps: 0.00, reads: 0.00, writes: 38690.80, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 113s] threads: 64, tps: 0.00, reads: 0.00, writes: 38040.19, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 114s] threads: 64, tps: 0.00, reads: 0.00, writes: 36732.00, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[ 115s] threads: 64, tps: 0.00, reads: 0.00, writes: 42678.03, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 116s] threads: 64, tps: 0.00, reads: 0.00, writes: 40525.92, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 117s] threads: 64, tps: 0.00, reads: 0.00, writes: 39783.00, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 118s] threads: 64, tps: 0.00, reads: 0.00, writes: 37711.06, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 119s] threads: 64, tps: 0.00, reads: 0.00, writes: 36585.97, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 120s] threads: 64, tps: 0.00, reads: 0.00, writes: 40854.98, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 121s] threads: 64, tps: 0.00, reads: 0.00, writes: 38621.02, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 122s] threads: 64, tps: 0.00, reads: 0.00, writes: 32259.98, response time: 3.69ms (95%), errors: 0.00, reconnects:  0.00
[ 123s] threads: 64, tps: 0.00, reads: 0.00, writes: 27111.01, response time: 4.36ms (95%), errors: 0.00, reconnects:  0.00
[ 124s] threads: 64, tps: 0.00, reads: 0.00, writes: 28711.02, response time: 5.37ms (95%), errors: 0.00, reconnects:  0.00
[ 125s] threads: 64, tps: 0.00, reads: 0.00, writes: 32305.03, response time: 3.67ms (95%), errors: 0.00, reconnects:  0.00
[ 126s] threads: 64, tps: 0.00, reads: 0.00, writes: 38549.92, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[ 127s] threads: 64, tps: 0.00, reads: 0.00, writes: 40106.03, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 128s] threads: 64, tps: 0.00, reads: 0.00, writes: 35123.03, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[ 129s] threads: 64, tps: 0.00, reads: 0.00, writes: 35443.72, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 130s] threads: 64, tps: 0.00, reads: 0.00, writes: 34790.28, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[ 131s] threads: 64, tps: 0.00, reads: 0.00, writes: 37197.96, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[ 132s] threads: 64, tps: 0.00, reads: 0.00, writes: 40493.06, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 133s] threads: 64, tps: 0.00, reads: 0.00, writes: 32249.95, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[ 134s] threads: 64, tps: 0.00, reads: 0.00, writes: 34381.93, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 135s] threads: 64, tps: 0.00, reads: 0.00, writes: 35857.11, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[ 136s] threads: 64, tps: 0.00, reads: 0.00, writes: 36711.00, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 137s] threads: 64, tps: 0.00, reads: 0.00, writes: 42332.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 138s] threads: 64, tps: 0.00, reads: 0.00, writes: 39420.69, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 139s] threads: 64, tps: 0.00, reads: 0.00, writes: 39736.28, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 140s] threads: 64, tps: 0.00, reads: 0.00, writes: 38912.05, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 141s] threads: 64, tps: 0.00, reads: 0.00, writes: 37346.78, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 142s] threads: 64, tps: 0.00, reads: 0.00, writes: 41779.21, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 143s] threads: 64, tps: 0.00, reads: 0.00, writes: 40856.94, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 144s] threads: 64, tps: 0.00, reads: 0.00, writes: 39745.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 145s] threads: 64, tps: 0.00, reads: 0.00, writes: 39493.01, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 146s] threads: 64, tps: 0.00, reads: 0.00, writes: 38486.08, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 147s] threads: 64, tps: 0.00, reads: 0.00, writes: 34245.95, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[ 148s] threads: 64, tps: 0.00, reads: 0.00, writes: 41463.84, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 149s] threads: 64, tps: 0.00, reads: 0.00, writes: 39201.14, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 150s] threads: 64, tps: 0.00, reads: 0.00, writes: 38724.05, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 151s] threads: 64, tps: 0.00, reads: 0.00, writes: 38377.99, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 152s] threads: 64, tps: 0.00, reads: 0.00, writes: 40989.02, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 153s] threads: 64, tps: 0.00, reads: 0.00, writes: 40353.90, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 154s] threads: 64, tps: 0.00, reads: 0.00, writes: 38133.02, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[ 155s] threads: 64, tps: 0.00, reads: 0.00, writes: 34883.02, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 156s] threads: 64, tps: 0.00, reads: 0.00, writes: 29613.03, response time: 4.00ms (95%), errors: 0.00, reconnects:  0.00
[ 157s] threads: 64, tps: 0.00, reads: 0.00, writes: 31181.82, response time: 4.36ms (95%), errors: 0.00, reconnects:  0.00
[ 158s] threads: 64, tps: 0.00, reads: 0.00, writes: 34761.20, response time: 3.96ms (95%), errors: 0.00, reconnects:  0.00
[ 159s] threads: 64, tps: 0.00, reads: 0.00, writes: 38136.64, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 160s] threads: 64, tps: 0.00, reads: 0.00, writes: 33697.89, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 161s] threads: 64, tps: 0.00, reads: 0.00, writes: 32072.38, response time: 4.33ms (95%), errors: 0.00, reconnects:  0.00
[ 162s] threads: 64, tps: 0.00, reads: 0.00, writes: 33291.71, response time: 3.59ms (95%), errors: 0.00, reconnects:  0.00
[ 163s] threads: 64, tps: 0.00, reads: 0.00, writes: 33905.97, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 164s] threads: 64, tps: 0.00, reads: 0.00, writes: 40304.04, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 165s] threads: 64, tps: 0.00, reads: 0.00, writes: 39387.84, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 166s] threads: 64, tps: 0.00, reads: 0.00, writes: 30600.06, response time: 3.68ms (95%), errors: 0.00, reconnects:  0.00
[ 167s] threads: 64, tps: 0.00, reads: 0.00, writes: 31190.99, response time: 3.66ms (95%), errors: 0.00, reconnects:  0.00
[ 168s] threads: 64, tps: 0.00, reads: 0.00, writes: 31068.05, response time: 3.71ms (95%), errors: 0.00, reconnects:  0.00
[ 169s] threads: 64, tps: 0.00, reads: 0.00, writes: 33648.89, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[ 170s] threads: 64, tps: 0.00, reads: 0.00, writes: 41086.15, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 171s] threads: 64, tps: 0.00, reads: 0.00, writes: 37368.96, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 172s] threads: 64, tps: 0.00, reads: 0.00, writes: 39240.05, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 173s] threads: 64, tps: 0.00, reads: 0.00, writes: 38955.96, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 174s] threads: 64, tps: 0.00, reads: 0.00, writes: 38480.03, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 175s] threads: 64, tps: 0.00, reads: 0.00, writes: 44211.02, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 176s] threads: 64, tps: 0.00, reads: 0.00, writes: 40836.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 177s] threads: 64, tps: 0.00, reads: 0.00, writes: 40491.94, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 178s] threads: 64, tps: 0.00, reads: 0.00, writes: 33717.99, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 179s] threads: 64, tps: 0.00, reads: 0.00, writes: 38421.98, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 180s] threads: 64, tps: 0.00, reads: 0.00, writes: 42260.00, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 181s] threads: 64, tps: 0.00, reads: 0.00, writes: 40695.09, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 182s] threads: 64, tps: 0.00, reads: 0.00, writes: 37913.94, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 183s] threads: 64, tps: 0.00, reads: 0.00, writes: 36872.85, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[ 184s] threads: 64, tps: 0.00, reads: 0.00, writes: 37112.15, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 185s] threads: 64, tps: 0.00, reads: 0.00, writes: 40407.01, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[ 186s] threads: 64, tps: 0.00, reads: 0.00, writes: 37328.01, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 187s] threads: 64, tps: 0.00, reads: 0.00, writes: 33125.99, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[ 188s] threads: 64, tps: 0.00, reads: 0.00, writes: 34491.99, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[ 189s] threads: 64, tps: 0.00, reads: 0.00, writes: 32488.98, response time: 4.09ms (95%), errors: 0.00, reconnects:  0.00
[ 190s] threads: 64, tps: 0.00, reads: 0.00, writes: 32451.99, response time: 3.78ms (95%), errors: 0.00, reconnects:  0.00
[ 191s] threads: 64, tps: 0.00, reads: 0.00, writes: 40531.10, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 192s] threads: 64, tps: 0.00, reads: 0.00, writes: 38223.96, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 193s] threads: 64, tps: 0.00, reads: 0.00, writes: 32938.01, response time: 3.82ms (95%), errors: 0.00, reconnects:  0.00
[ 194s] threads: 64, tps: 0.00, reads: 0.00, writes: 33293.96, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[ 195s] threads: 64, tps: 0.00, reads: 0.00, writes: 24901.00, response time: 3.88ms (95%), errors: 0.00, reconnects:  0.00
[ 196s] threads: 64, tps: 0.00, reads: 0.00, writes: 30146.98, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[ 197s] threads: 64, tps: 0.00, reads: 0.00, writes: 37995.00, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[ 198s] threads: 64, tps: 0.00, reads: 0.00, writes: 34957.95, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[ 199s] threads: 64, tps: 0.00, reads: 0.00, writes: 37540.13, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 200s] threads: 64, tps: 0.00, reads: 0.00, writes: 37112.96, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 201s] threads: 64, tps: 0.00, reads: 0.00, writes: 36836.06, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 202s] threads: 64, tps: 0.00, reads: 0.00, writes: 39653.91, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 203s] threads: 64, tps: 0.00, reads: 0.00, writes: 40237.01, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 204s] threads: 64, tps: 0.00, reads: 0.00, writes: 39428.03, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 205s] threads: 64, tps: 0.00, reads: 0.00, writes: 38581.71, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 206s] threads: 64, tps: 0.00, reads: 0.00, writes: 37262.02, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 207s] threads: 64, tps: 0.00, reads: 0.00, writes: 39797.95, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 208s] threads: 64, tps: 0.00, reads: 0.00, writes: 42622.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 209s] threads: 64, tps: 0.00, reads: 0.00, writes: 39705.05, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 210s] threads: 64, tps: 0.00, reads: 0.00, writes: 38720.97, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 211s] threads: 64, tps: 0.00, reads: 0.00, writes: 38645.98, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 212s] threads: 64, tps: 0.00, reads: 0.00, writes: 41796.02, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 213s] threads: 64, tps: 0.00, reads: 0.00, writes: 41454.00, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 214s] threads: 64, tps: 0.00, reads: 0.00, writes: 39702.83, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 215s] threads: 64, tps: 0.00, reads: 0.00, writes: 39000.99, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 216s] threads: 64, tps: 0.00, reads: 0.00, writes: 37648.18, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 217s] threads: 64, tps: 0.00, reads: 0.00, writes: 40148.82, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 218s] threads: 64, tps: 0.00, reads: 0.00, writes: 41674.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 219s] threads: 64, tps: 0.00, reads: 0.00, writes: 40008.13, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 220s] threads: 64, tps: 0.00, reads: 0.00, writes: 38308.02, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 221s] threads: 64, tps: 0.00, reads: 0.00, writes: 38312.85, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 222s] threads: 64, tps: 0.00, reads: 0.00, writes: 39564.15, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 223s] threads: 64, tps: 0.00, reads: 0.00, writes: 42595.81, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 224s] threads: 64, tps: 0.00, reads: 0.00, writes: 39301.03, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 225s] threads: 64, tps: 0.00, reads: 0.00, writes: 30060.10, response time: 4.67ms (95%), errors: 0.00, reconnects:  0.00
[ 226s] threads: 64, tps: 0.00, reads: 0.00, writes: 28657.97, response time: 3.81ms (95%), errors: 0.00, reconnects:  0.00
[ 227s] threads: 64, tps: 0.00, reads: 0.00, writes: 32575.05, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[ 228s] threads: 64, tps: 0.00, reads: 0.00, writes: 37598.79, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 229s] threads: 64, tps: 0.00, reads: 0.00, writes: 34846.19, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 230s] threads: 64, tps: 0.00, reads: 0.00, writes: 35008.99, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 231s] threads: 64, tps: 0.00, reads: 0.00, writes: 33579.97, response time: 3.58ms (95%), errors: 0.00, reconnects:  0.00
[ 232s] threads: 64, tps: 0.00, reads: 0.00, writes: 33194.91, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[ 233s] threads: 64, tps: 0.00, reads: 0.00, writes: 34454.15, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 234s] threads: 64, tps: 0.00, reads: 0.00, writes: 38961.97, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[ 235s] threads: 64, tps: 0.00, reads: 0.00, writes: 39283.99, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[ 236s] threads: 64, tps: 0.00, reads: 0.00, writes: 34343.85, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[ 237s] threads: 64, tps: 0.00, reads: 0.00, writes: 27342.15, response time: 6.37ms (95%), errors: 0.00, reconnects:  0.00
[ 238s] threads: 64, tps: 0.00, reads: 0.00, writes: 27734.99, response time: 4.58ms (95%), errors: 0.00, reconnects:  0.00
[ 239s] threads: 64, tps: 0.00, reads: 0.00, writes: 32499.97, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 240s] threads: 64, tps: 0.00, reads: 0.00, writes: 39039.05, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[ 241s] threads: 64, tps: 0.00, reads: 0.00, writes: 37869.98, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 242s] threads: 64, tps: 0.00, reads: 0.00, writes: 31823.85, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[ 243s] threads: 64, tps: 0.00, reads: 0.00, writes: 38392.21, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 244s] threads: 64, tps: 0.00, reads: 0.00, writes: 38119.99, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 245s] threads: 64, tps: 0.00, reads: 0.00, writes: 40280.01, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 246s] threads: 64, tps: 0.00, reads: 0.00, writes: 40759.00, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 247s] threads: 64, tps: 0.00, reads: 0.00, writes: 39842.98, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 248s] threads: 64, tps: 0.00, reads: 0.00, writes: 38821.96, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 249s] threads: 64, tps: 0.00, reads: 0.00, writes: 39465.86, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 250s] threads: 64, tps: 0.00, reads: 0.00, writes: 39739.17, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 251s] threads: 64, tps: 0.00, reads: 0.00, writes: 42136.06, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 252s] threads: 64, tps: 0.00, reads: 0.00, writes: 39303.96, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 253s] threads: 64, tps: 0.00, reads: 0.00, writes: 38844.06, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 254s] threads: 64, tps: 0.00, reads: 0.00, writes: 37316.00, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 255s] threads: 64, tps: 0.00, reads: 0.00, writes: 37096.00, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 256s] threads: 64, tps: 0.00, reads: 0.00, writes: 42511.89, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 257s] threads: 64, tps: 0.00, reads: 0.00, writes: 39995.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 258s] threads: 64, tps: 0.00, reads: 0.00, writes: 39091.83, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 259s] threads: 64, tps: 0.00, reads: 0.00, writes: 38261.16, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 260s] threads: 64, tps: 0.00, reads: 0.00, writes: 37566.99, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 261s] threads: 64, tps: 0.00, reads: 0.00, writes: 40683.06, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 262s] threads: 64, tps: 0.00, reads: 0.00, writes: 37804.99, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 263s] threads: 64, tps: 0.00, reads: 0.00, writes: 32487.94, response time: 4.19ms (95%), errors: 0.00, reconnects:  0.00
[ 264s] threads: 64, tps: 0.00, reads: 0.00, writes: 27792.06, response time: 4.96ms (95%), errors: 0.00, reconnects:  0.00
[ 265s] threads: 64, tps: 0.00, reads: 0.00, writes: 32258.91, response time: 3.73ms (95%), errors: 0.00, reconnects:  0.00
[ 266s] threads: 64, tps: 0.00, reads: 0.00, writes: 35708.09, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[ 267s] threads: 64, tps: 0.00, reads: 0.00, writes: 39563.83, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 268s] threads: 64, tps: 0.00, reads: 0.00, writes: 36078.12, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[ 269s] threads: 64, tps: 0.00, reads: 0.00, writes: 33057.97, response time: 3.70ms (95%), errors: 0.00, reconnects:  0.00
[ 270s] threads: 64, tps: 0.00, reads: 0.00, writes: 33443.02, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[ 271s] threads: 64, tps: 0.00, reads: 0.00, writes: 32810.96, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[ 272s] threads: 64, tps: 0.00, reads: 0.00, writes: 38769.07, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[ 273s] threads: 64, tps: 0.00, reads: 0.00, writes: 39350.28, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 274s] threads: 64, tps: 0.00, reads: 0.00, writes: 33300.57, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[ 275s] threads: 64, tps: 0.00, reads: 0.00, writes: 28856.02, response time: 3.80ms (95%), errors: 0.00, reconnects:  0.00
[ 276s] threads: 64, tps: 0.00, reads: 0.00, writes: 31160.00, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[ 277s] threads: 64, tps: 0.00, reads: 0.00, writes: 33707.67, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 278s] threads: 64, tps: 0.00, reads: 0.00, writes: 38460.29, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[ 279s] threads: 64, tps: 0.00, reads: 0.00, writes: 38872.05, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 280s] threads: 64, tps: 0.00, reads: 0.00, writes: 38753.06, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 281s] threads: 64, tps: 0.00, reads: 0.00, writes: 38293.00, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 282s] threads: 64, tps: 0.00, reads: 0.00, writes: 38299.93, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 283s] threads: 64, tps: 0.00, reads: 0.00, writes: 39181.04, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 284s] threads: 64, tps: 0.00, reads: 0.00, writes: 40584.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 285s] threads: 64, tps: 0.00, reads: 0.00, writes: 38677.98, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 286s] threads: 64, tps: 0.00, reads: 0.00, writes: 38568.07, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 287s] threads: 64, tps: 0.00, reads: 0.00, writes: 37830.98, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 288s] threads: 64, tps: 0.00, reads: 0.00, writes: 41066.74, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 289s] threads: 64, tps: 0.00, reads: 0.00, writes: 35952.22, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 290s] threads: 64, tps: 0.00, reads: 0.00, writes: 40199.96, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 291s] threads: 64, tps: 0.00, reads: 0.00, writes: 38532.04, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 292s] threads: 64, tps: 0.00, reads: 0.00, writes: 37660.98, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 293s] threads: 64, tps: 0.00, reads: 0.00, writes: 39651.00, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 294s] threads: 64, tps: 0.00, reads: 0.00, writes: 42108.01, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 295s] threads: 64, tps: 0.00, reads: 0.00, writes: 40410.01, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 296s] threads: 64, tps: 0.00, reads: 0.00, writes: 38671.98, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 297s] threads: 64, tps: 0.00, reads: 0.00, writes: 38112.00, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 298s] threads: 64, tps: 0.00, reads: 0.00, writes: 37402.04, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 299s] threads: 64, tps: 0.00, reads: 0.00, writes: 41407.36, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 300s] threads: 64, tps: 0.00, reads: 0.00, writes: 35495.76, response time: 3.32ms (95%), errors: 0.00, reconnects:  0.00
[ 301s] threads: 64, tps: 0.00, reads: 0.00, writes: 26958.18, response time: 5.49ms (95%), errors: 0.00, reconnects:  0.00
[ 302s] threads: 64, tps: 0.00, reads: 0.00, writes: 28465.96, response time: 3.72ms (95%), errors: 0.00, reconnects:  0.00
[ 303s] threads: 64, tps: 0.00, reads: 0.00, writes: 33284.02, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[ 304s] threads: 64, tps: 0.00, reads: 0.00, writes: 34812.00, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 305s] threads: 64, tps: 0.00, reads: 0.00, writes: 39664.96, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 306s] threads: 64, tps: 0.00, reads: 0.00, writes: 37042.03, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 307s] threads: 64, tps: 0.00, reads: 0.00, writes: 31539.98, response time: 4.70ms (95%), errors: 0.00, reconnects:  0.00
[ 308s] threads: 64, tps: 0.00, reads: 0.00, writes: 31360.03, response time: 4.38ms (95%), errors: 0.00, reconnects:  0.00
[ 309s] threads: 64, tps: 0.00, reads: 0.00, writes: 32802.94, response time: 3.43ms (95%), errors: 0.00, reconnects:  0.00
[ 310s] threads: 64, tps: 0.00, reads: 0.00, writes: 35444.01, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 311s] threads: 64, tps: 0.00, reads: 0.00, writes: 39500.03, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 312s] threads: 64, tps: 0.00, reads: 0.00, writes: 36756.00, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 313s] threads: 64, tps: 0.00, reads: 0.00, writes: 31188.84, response time: 3.28ms (95%), errors: 0.00, reconnects:  0.00
[ 314s] threads: 64, tps: 0.00, reads: 0.00, writes: 34568.17, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[ 315s] threads: 64, tps: 0.00, reads: 0.00, writes: 34013.04, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[ 316s] threads: 64, tps: 0.00, reads: 0.00, writes: 37205.97, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 317s] threads: 64, tps: 0.00, reads: 0.00, writes: 38371.35, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 318s] threads: 64, tps: 0.00, reads: 0.00, writes: 38712.65, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 319s] threads: 64, tps: 0.00, reads: 0.00, writes: 37560.97, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 320s] threads: 64, tps: 0.00, reads: 0.00, writes: 38685.02, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 321s] threads: 64, tps: 0.00, reads: 0.00, writes: 41320.99, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 322s] threads: 64, tps: 0.00, reads: 0.00, writes: 42172.89, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 323s] threads: 64, tps: 0.00, reads: 0.00, writes: 40132.11, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 324s] threads: 64, tps: 0.00, reads: 0.00, writes: 38979.97, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 325s] threads: 64, tps: 0.00, reads: 0.00, writes: 38161.84, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 326s] threads: 64, tps: 0.00, reads: 0.00, writes: 40687.15, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 327s] threads: 64, tps: 0.00, reads: 0.00, writes: 41466.08, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 328s] threads: 64, tps: 0.00, reads: 0.00, writes: 40351.96, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 329s] threads: 64, tps: 0.00, reads: 0.00, writes: 39251.97, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 330s] threads: 64, tps: 0.00, reads: 0.00, writes: 38870.01, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 331s] threads: 64, tps: 0.00, reads: 0.00, writes: 40308.00, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 332s] threads: 64, tps: 0.00, reads: 0.00, writes: 42132.04, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 333s] threads: 64, tps: 0.00, reads: 0.00, writes: 40018.94, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 334s] threads: 64, tps: 0.00, reads: 0.00, writes: 38632.03, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 335s] threads: 64, tps: 0.00, reads: 0.00, writes: 31213.99, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 336s] threads: 64, tps: 0.00, reads: 0.00, writes: 39622.00, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 337s] threads: 64, tps: 0.00, reads: 0.00, writes: 41790.06, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 338s] threads: 64, tps: 0.00, reads: 0.00, writes: 37525.93, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 339s] threads: 64, tps: 0.00, reads: 0.00, writes: 30649.87, response time: 4.03ms (95%), errors: 0.00, reconnects:  0.00
[ 340s] threads: 64, tps: 0.00, reads: 0.00, writes: 27983.13, response time: 3.87ms (95%), errors: 0.00, reconnects:  0.00
[ 341s] threads: 64, tps: 0.00, reads: 0.00, writes: 30731.06, response time: 3.87ms (95%), errors: 0.00, reconnects:  0.00
[ 342s] threads: 64, tps: 0.00, reads: 0.00, writes: 34090.94, response time: 3.71ms (95%), errors: 0.00, reconnects:  0.00
[ 343s] threads: 64, tps: 0.00, reads: 0.00, writes: 39181.04, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 344s] threads: 64, tps: 0.00, reads: 0.00, writes: 35935.93, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 345s] threads: 64, tps: 0.00, reads: 0.00, writes: 33740.04, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[ 346s] threads: 64, tps: 0.00, reads: 0.00, writes: 33663.01, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[ 347s] threads: 64, tps: 0.00, reads: 0.00, writes: 33328.98, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 348s] threads: 64, tps: 0.00, reads: 0.00, writes: 38534.01, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 349s] threads: 64, tps: 0.00, reads: 0.00, writes: 39645.80, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 350s] threads: 64, tps: 0.00, reads: 0.00, writes: 35717.30, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 351s] threads: 64, tps: 0.00, reads: 0.00, writes: 31340.74, response time: 3.57ms (95%), errors: 0.00, reconnects:  0.00
[ 352s] threads: 64, tps: 0.00, reads: 0.00, writes: 26843.86, response time: 4.23ms (95%), errors: 0.00, reconnects:  0.00
[ 353s] threads: 64, tps: 0.00, reads: 0.00, writes: 26593.17, response time: 4.64ms (95%), errors: 0.00, reconnects:  0.00
[ 354s] threads: 64, tps: 0.00, reads: 0.00, writes: 30433.95, response time: 4.77ms (95%), errors: 0.00, reconnects:  0.00
[ 355s] threads: 64, tps: 0.00, reads: 0.00, writes: 33378.73, response time: 5.04ms (95%), errors: 0.00, reconnects:  0.00
[ 356s] threads: 64, tps: 0.00, reads: 0.00, writes: 26755.27, response time: 5.15ms (95%), errors: 0.00, reconnects:  0.00
[ 357s] threads: 64, tps: 0.00, reads: 0.00, writes: 29260.96, response time: 3.69ms (95%), errors: 0.00, reconnects:  0.00
[ 358s] threads: 64, tps: 0.00, reads: 0.00, writes: 32130.02, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[ 359s] threads: 64, tps: 0.00, reads: 0.00, writes: 33825.04, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[ 360s] threads: 64, tps: 0.00, reads: 0.00, writes: 36839.99, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 361s] threads: 64, tps: 0.00, reads: 0.00, writes: 42024.93, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 362s] threads: 64, tps: 0.00, reads: 0.00, writes: 38574.84, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 363s] threads: 64, tps: 0.00, reads: 0.00, writes: 37411.97, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 364s] threads: 64, tps: 0.00, reads: 0.00, writes: 37271.88, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[ 365s] threads: 64, tps: 0.00, reads: 0.00, writes: 36600.12, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[ 366s] threads: 64, tps: 0.00, reads: 0.00, writes: 42857.83, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 367s] threads: 64, tps: 0.00, reads: 0.00, writes: 39139.22, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 368s] threads: 64, tps: 0.00, reads: 0.00, writes: 38367.96, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 369s] threads: 64, tps: 0.00, reads: 0.00, writes: 37314.99, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 370s] threads: 64, tps: 0.00, reads: 0.00, writes: 34067.03, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[ 371s] threads: 64, tps: 0.00, reads: 0.00, writes: 40744.02, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 372s] threads: 64, tps: 0.00, reads: 0.00, writes: 40095.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 373s] threads: 64, tps: 0.00, reads: 0.00, writes: 38728.00, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 374s] threads: 64, tps: 0.00, reads: 0.00, writes: 37872.93, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 375s] threads: 64, tps: 0.00, reads: 0.00, writes: 36340.05, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[ 376s] threads: 64, tps: 0.00, reads: 0.00, writes: 40009.98, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 377s] threads: 64, tps: 0.00, reads: 0.00, writes: 38560.02, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 378s] threads: 64, tps: 0.00, reads: 0.00, writes: 38310.04, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 379s] threads: 64, tps: 0.00, reads: 0.00, writes: 37576.96, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 380s] threads: 64, tps: 0.00, reads: 0.00, writes: 35772.03, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[ 381s] threads: 64, tps: 0.00, reads: 0.00, writes: 35691.97, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[ 382s] threads: 64, tps: 0.00, reads: 0.00, writes: 39576.99, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 383s] threads: 64, tps: 0.00, reads: 0.00, writes: 35275.02, response time: 3.37ms (95%), errors: 0.00, reconnects:  0.00
[ 384s] threads: 64, tps: 0.00, reads: 0.00, writes: 27285.00, response time: 4.13ms (95%), errors: 0.00, reconnects:  0.00
[ 385s] threads: 64, tps: 0.00, reads: 0.00, writes: 33758.98, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[ 386s] threads: 64, tps: 0.00, reads: 0.00, writes: 34055.02, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 387s] threads: 64, tps: 0.00, reads: 0.00, writes: 36958.94, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 388s] threads: 64, tps: 0.00, reads: 0.00, writes: 39707.92, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 389s] threads: 64, tps: 0.00, reads: 0.00, writes: 35593.10, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 390s] threads: 64, tps: 0.00, reads: 0.00, writes: 31435.52, response time: 4.58ms (95%), errors: 0.00, reconnects:  0.00
[ 391s] threads: 64, tps: 0.00, reads: 0.00, writes: 32621.56, response time: 4.02ms (95%), errors: 0.00, reconnects:  0.00
[ 392s] threads: 64, tps: 0.00, reads: 0.00, writes: 33482.00, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 393s] threads: 64, tps: 0.00, reads: 0.00, writes: 37816.92, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[ 394s] threads: 64, tps: 0.00, reads: 0.00, writes: 39465.99, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 395s] threads: 64, tps: 0.00, reads: 0.00, writes: 29070.30, response time: 4.64ms (95%), errors: 0.00, reconnects:  0.00
[ 396s] threads: 64, tps: 0.00, reads: 0.00, writes: 3092.08, response time: 21.55ms (95%), errors: 0.00, reconnects:  0.00
[ 397s] threads: 64, tps: 0.00, reads: 0.00, writes: 3081.94, response time: 22.08ms (95%), errors: 0.00, reconnects:  0.00
[ 398s] threads: 64, tps: 0.00, reads: 0.00, writes: 17382.32, response time: 20.36ms (95%), errors: 0.00, reconnects:  0.00
[ 399s] threads: 64, tps: 0.00, reads: 0.00, writes: 27699.99, response time: 4.67ms (95%), errors: 0.00, reconnects:  0.00
[ 400s] threads: 64, tps: 0.00, reads: 0.00, writes: 35903.03, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 401s] threads: 64, tps: 0.00, reads: 0.00, writes: 40879.00, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 402s] threads: 64, tps: 0.00, reads: 0.00, writes: 39814.96, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 403s] threads: 64, tps: 0.00, reads: 0.00, writes: 39630.00, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 404s] threads: 64, tps: 0.00, reads: 0.00, writes: 39056.00, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 405s] threads: 64, tps: 0.00, reads: 0.00, writes: 38403.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 406s] threads: 64, tps: 0.00, reads: 0.00, writes: 40793.03, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 407s] threads: 64, tps: 0.00, reads: 0.00, writes: 42609.93, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 408s] threads: 64, tps: 0.00, reads: 0.00, writes: 39587.04, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 409s] threads: 64, tps: 0.00, reads: 0.00, writes: 38634.68, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 410s] threads: 64, tps: 0.00, reads: 0.00, writes: 38684.34, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 411s] threads: 64, tps: 0.00, reads: 0.00, writes: 40571.05, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 412s] threads: 64, tps: 0.00, reads: 0.00, writes: 42229.93, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 413s] threads: 64, tps: 0.00, reads: 0.00, writes: 39314.98, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 414s] threads: 64, tps: 0.00, reads: 0.00, writes: 37501.03, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 415s] threads: 64, tps: 0.00, reads: 0.00, writes: 32251.98, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[ 416s] threads: 64, tps: 0.00, reads: 0.00, writes: 35617.27, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[ 417s] threads: 64, tps: 0.00, reads: 0.00, writes: 39310.86, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[ 418s] threads: 64, tps: 0.00, reads: 0.00, writes: 32506.96, response time: 3.47ms (95%), errors: 0.00, reconnects:  0.00
[ 419s] threads: 64, tps: 0.00, reads: 0.00, writes: 27832.91, response time: 3.90ms (95%), errors: 0.00, reconnects:  0.00
[ 420s] threads: 64, tps: 0.00, reads: 0.00, writes: 31324.09, response time: 3.71ms (95%), errors: 0.00, reconnects:  0.00
[ 421s] threads: 64, tps: 0.00, reads: 0.00, writes: 34203.05, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[ 422s] threads: 64, tps: 0.00, reads: 0.00, writes: 34037.77, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 423s] threads: 64, tps: 0.00, reads: 0.00, writes: 40617.24, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 424s] threads: 64, tps: 0.00, reads: 0.00, writes: 38537.99, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 425s] threads: 64, tps: 0.00, reads: 0.00, writes: 34317.04, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[ 426s] threads: 64, tps: 0.00, reads: 0.00, writes: 35155.96, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 427s] threads: 64, tps: 0.00, reads: 0.00, writes: 34559.04, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 428s] threads: 64, tps: 0.00, reads: 0.00, writes: 31862.96, response time: 4.22ms (95%), errors: 0.00, reconnects:  0.00
[ 429s] threads: 64, tps: 0.00, reads: 0.00, writes: 36510.99, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[ 430s] threads: 64, tps: 0.00, reads: 0.00, writes: 25889.60, response time: 5.96ms (95%), errors: 0.00, reconnects:  0.00
[ 431s] threads: 64, tps: 0.00, reads: 0.00, writes: 28603.56, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[ 432s] threads: 64, tps: 0.00, reads: 0.00, writes: 27098.99, response time: 4.48ms (95%), errors: 0.00, reconnects:  0.00
[ 433s] threads: 64, tps: 0.00, reads: 0.00, writes: 30052.21, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[ 434s] threads: 64, tps: 0.00, reads: 0.00, writes: 33702.00, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 435s] threads: 64, tps: 0.00, reads: 0.00, writes: 37168.86, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 436s] threads: 64, tps: 0.00, reads: 0.00, writes: 35294.16, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 437s] threads: 64, tps: 0.00, reads: 0.00, writes: 38274.95, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[ 438s] threads: 64, tps: 0.00, reads: 0.00, writes: 37769.04, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 439s] threads: 64, tps: 0.00, reads: 0.00, writes: 37352.03, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 440s] threads: 64, tps: 0.00, reads: 0.00, writes: 41619.93, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 441s] threads: 64, tps: 0.00, reads: 0.00, writes: 41373.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 442s] threads: 64, tps: 0.00, reads: 0.00, writes: 40228.04, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 443s] threads: 64, tps: 0.00, reads: 0.00, writes: 38781.97, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 444s] threads: 64, tps: 0.00, reads: 0.00, writes: 38172.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 445s] threads: 64, tps: 0.00, reads: 0.00, writes: 41522.98, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 446s] threads: 64, tps: 0.00, reads: 0.00, writes: 41060.99, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 447s] threads: 64, tps: 0.00, reads: 0.00, writes: 38801.06, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 448s] threads: 64, tps: 0.00, reads: 0.00, writes: 37836.94, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 449s] threads: 64, tps: 0.00, reads: 0.00, writes: 36954.06, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 450s] threads: 64, tps: 0.00, reads: 0.00, writes: 38823.10, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 451s] threads: 64, tps: 0.00, reads: 0.00, writes: 41362.90, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 452s] threads: 64, tps: 0.00, reads: 0.00, writes: 39678.04, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 453s] threads: 64, tps: 0.00, reads: 0.00, writes: 39081.97, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 454s] threads: 64, tps: 0.00, reads: 0.00, writes: 37645.03, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 455s] threads: 64, tps: 0.00, reads: 0.00, writes: 39608.99, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 456s] threads: 64, tps: 0.00, reads: 0.00, writes: 40061.95, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 457s] threads: 64, tps: 0.00, reads: 0.00, writes: 38726.98, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[ 458s] threads: 64, tps: 0.00, reads: 0.00, writes: 36990.09, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[ 459s] threads: 64, tps: 0.00, reads: 0.00, writes: 28305.95, response time: 4.95ms (95%), errors: 0.00, reconnects:  0.00
[ 460s] threads: 64, tps: 0.00, reads: 0.00, writes: 31725.07, response time: 3.68ms (95%), errors: 0.00, reconnects:  0.00
[ 461s] threads: 64, tps: 0.00, reads: 0.00, writes: 38742.94, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 462s] threads: 64, tps: 0.00, reads: 0.00, writes: 38676.03, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 463s] threads: 64, tps: 0.00, reads: 0.00, writes: 34305.95, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[ 464s] threads: 64, tps: 0.00, reads: 0.00, writes: 34125.02, response time: 3.37ms (95%), errors: 0.00, reconnects:  0.00
[ 465s] threads: 64, tps: 0.00, reads: 0.00, writes: 34527.15, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[ 466s] threads: 64, tps: 0.00, reads: 0.00, writes: 32645.54, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 467s] threads: 64, tps: 0.00, reads: 0.00, writes: 39986.21, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 468s] threads: 64, tps: 0.00, reads: 0.00, writes: 37099.00, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[ 469s] threads: 64, tps: 0.00, reads: 0.00, writes: 33372.86, response time: 3.84ms (95%), errors: 0.00, reconnects:  0.00
[ 470s] threads: 64, tps: 0.00, reads: 0.00, writes: 30566.09, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[ 471s] threads: 64, tps: 0.00, reads: 0.00, writes: 27471.04, response time: 3.81ms (95%), errors: 0.00, reconnects:  0.00
[ 472s] threads: 64, tps: 0.00, reads: 0.00, writes: 29457.76, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[ 473s] threads: 64, tps: 0.00, reads: 0.00, writes: 36314.29, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[ 474s] threads: 64, tps: 0.00, reads: 0.00, writes: 34315.95, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 475s] threads: 64, tps: 0.00, reads: 0.00, writes: 34560.94, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 476s] threads: 64, tps: 0.00, reads: 0.00, writes: 38707.11, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 477s] threads: 64, tps: 0.00, reads: 0.00, writes: 38323.00, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 478s] threads: 64, tps: 0.00, reads: 0.00, writes: 41701.03, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 479s] threads: 64, tps: 0.00, reads: 0.00, writes: 40973.95, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 480s] threads: 64, tps: 0.00, reads: 0.00, writes: 40100.97, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 481s] threads: 64, tps: 0.00, reads: 0.00, writes: 39313.00, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 482s] threads: 64, tps: 0.00, reads: 0.00, writes: 31458.90, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 483s] threads: 64, tps: 0.00, reads: 0.00, writes: 39465.15, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 484s] threads: 64, tps: 0.00, reads: 0.00, writes: 41581.05, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 485s] threads: 64, tps: 0.00, reads: 0.00, writes: 38885.02, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 486s] threads: 64, tps: 0.00, reads: 0.00, writes: 39366.93, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 487s] threads: 64, tps: 0.00, reads: 0.00, writes: 38458.06, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 488s] threads: 64, tps: 0.00, reads: 0.00, writes: 39048.97, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 489s] threads: 64, tps: 0.00, reads: 0.00, writes: 42529.95, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 490s] threads: 64, tps: 0.00, reads: 0.00, writes: 39315.00, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 491s] threads: 64, tps: 0.00, reads: 0.00, writes: 38202.06, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 492s] threads: 64, tps: 0.00, reads: 0.00, writes: 37570.03, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 493s] threads: 64, tps: 0.00, reads: 0.00, writes: 35168.88, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[ 494s] threads: 64, tps: 0.00, reads: 0.00, writes: 41284.10, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 495s] threads: 64, tps: 0.00, reads: 0.00, writes: 38998.03, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 496s] threads: 64, tps: 0.00, reads: 0.00, writes: 36282.90, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 497s] threads: 64, tps: 0.00, reads: 0.00, writes: 27082.03, response time: 4.73ms (95%), errors: 0.00, reconnects:  0.00
[ 498s] threads: 64, tps: 0.00, reads: 0.00, writes: 30099.98, response time: 3.73ms (95%), errors: 0.00, reconnects:  0.00
[ 499s] threads: 64, tps: 0.00, reads: 0.00, writes: 33401.03, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[ 500s] threads: 64, tps: 0.00, reads: 0.00, writes: 39594.94, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[ 501s] threads: 64, tps: 0.00, reads: 0.00, writes: 36878.05, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 502s] threads: 64, tps: 0.00, reads: 0.00, writes: 33511.98, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[ 503s] threads: 64, tps: 0.00, reads: 0.00, writes: 33941.01, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 504s] threads: 64, tps: 0.00, reads: 0.00, writes: 33874.00, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 505s] threads: 64, tps: 0.00, reads: 0.00, writes: 36989.01, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[ 506s] threads: 64, tps: 0.00, reads: 0.00, writes: 38524.02, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[ 507s] threads: 64, tps: 0.00, reads: 0.00, writes: 36227.00, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 508s] threads: 64, tps: 0.00, reads: 0.00, writes: 30022.96, response time: 3.81ms (95%), errors: 0.00, reconnects:  0.00
[ 509s] threads: 64, tps: 0.00, reads: 0.00, writes: 26834.01, response time: 5.41ms (95%), errors: 0.00, reconnects:  0.00
[ 510s] threads: 64, tps: 0.00, reads: 0.00, writes: 25938.98, response time: 4.28ms (95%), errors: 0.00, reconnects:  0.00
[ 511s] threads: 64, tps: 0.00, reads: 0.00, writes: 28552.05, response time: 3.93ms (95%), errors: 0.00, reconnects:  0.00
[ 512s] threads: 64, tps: 0.00, reads: 0.00, writes: 37475.96, response time: 3.32ms (95%), errors: 0.00, reconnects:  0.00
[ 513s] threads: 64, tps: 0.00, reads: 0.00, writes: 29604.99, response time: 4.69ms (95%), errors: 0.00, reconnects:  0.00
[ 514s] threads: 64, tps: 0.00, reads: 0.00, writes: 34154.06, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[ 515s] threads: 64, tps: 0.00, reads: 0.00, writes: 35524.93, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[ 516s] threads: 64, tps: 0.00, reads: 0.00, writes: 36242.00, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[ 517s] threads: 64, tps: 0.00, reads: 0.00, writes: 39391.19, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 518s] threads: 64, tps: 0.00, reads: 0.00, writes: 40418.76, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 519s] threads: 64, tps: 0.00, reads: 0.00, writes: 38415.15, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 520s] threads: 64, tps: 0.00, reads: 0.00, writes: 38711.03, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 521s] threads: 64, tps: 0.00, reads: 0.00, writes: 37834.98, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 522s] threads: 64, tps: 0.00, reads: 0.00, writes: 39333.96, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 523s] threads: 64, tps: 0.00, reads: 0.00, writes: 42904.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 524s] threads: 64, tps: 0.00, reads: 0.00, writes: 39710.01, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 525s] threads: 64, tps: 0.00, reads: 0.00, writes: 38898.00, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 526s] threads: 64, tps: 0.00, reads: 0.00, writes: 37435.58, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 527s] threads: 64, tps: 0.00, reads: 0.00, writes: 39210.47, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 528s] threads: 64, tps: 0.00, reads: 0.00, writes: 42452.93, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 529s] threads: 64, tps: 0.00, reads: 0.00, writes: 40547.09, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 530s] threads: 64, tps: 0.00, reads: 0.00, writes: 31821.92, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 531s] threads: 64, tps: 0.00, reads: 0.00, writes: 37860.08, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 532s] threads: 64, tps: 0.00, reads: 0.00, writes: 37691.97, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 533s] threads: 64, tps: 0.00, reads: 0.00, writes: 42963.02, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 534s] threads: 64, tps: 0.00, reads: 0.00, writes: 38462.98, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 535s] threads: 64, tps: 0.00, reads: 0.00, writes: 38473.00, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 536s] threads: 64, tps: 0.00, reads: 0.00, writes: 35686.01, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[ 537s] threads: 64, tps: 0.00, reads: 0.00, writes: 34974.90, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 538s] threads: 64, tps: 0.00, reads: 0.00, writes: 36736.03, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[ 539s] threads: 64, tps: 0.00, reads: 0.00, writes: 37685.10, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 540s] threads: 64, tps: 0.00, reads: 0.00, writes: 33959.16, response time: 3.52ms (95%), errors: 0.00, reconnects:  0.00
[ 541s] threads: 64, tps: 0.00, reads: 0.00, writes: 33784.79, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[ 542s] threads: 64, tps: 0.00, reads: 0.00, writes: 33549.04, response time: 3.28ms (95%), errors: 0.00, reconnects:  0.00
[ 543s] threads: 64, tps: 0.00, reads: 0.00, writes: 34298.02, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 544s] threads: 64, tps: 0.00, reads: 0.00, writes: 40285.98, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[ 545s] threads: 64, tps: 0.00, reads: 0.00, writes: 38129.01, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 546s] threads: 64, tps: 0.00, reads: 0.00, writes: 33308.97, response time: 3.52ms (95%), errors: 0.00, reconnects:  0.00
[ 547s] threads: 64, tps: 0.00, reads: 0.00, writes: 31944.97, response time: 3.75ms (95%), errors: 0.00, reconnects:  0.00
[ 548s] threads: 64, tps: 0.00, reads: 0.00, writes: 33861.01, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[ 549s] threads: 64, tps: 0.00, reads: 0.00, writes: 30335.97, response time: 3.70ms (95%), errors: 0.00, reconnects:  0.00
[ 550s] threads: 64, tps: 0.00, reads: 0.00, writes: 39522.08, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[ 551s] threads: 64, tps: 0.00, reads: 0.00, writes: 16024.56, response time: 20.69ms (95%), errors: 0.00, reconnects:  0.00
[ 552s] threads: 64, tps: 0.00, reads: 0.00, writes: 3095.08, response time: 21.58ms (95%), errors: 0.00, reconnects:  0.00
[ 553s] threads: 64, tps: 0.00, reads: 0.00, writes: 16522.01, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[ 554s] threads: 64, tps: 0.00, reads: 0.00, writes: 28444.97, response time: 4.10ms (95%), errors: 0.00, reconnects:  0.00
[ 555s] threads: 64, tps: 0.00, reads: 0.00, writes: 29500.99, response time: 3.87ms (95%), errors: 0.00, reconnects:  0.00
[ 556s] threads: 64, tps: 0.00, reads: 0.00, writes: 31068.01, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[ 557s] threads: 64, tps: 0.00, reads: 0.00, writes: 30039.64, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[ 558s] threads: 64, tps: 0.00, reads: 0.00, writes: 37948.98, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[ 559s] threads: 64, tps: 0.00, reads: 0.00, writes: 31684.02, response time: 3.77ms (95%), errors: 0.00, reconnects:  0.00
[ 560s] threads: 64, tps: 0.00, reads: 0.00, writes: 32145.98, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[ 561s] threads: 64, tps: 0.00, reads: 0.00, writes: 31572.02, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 562s] threads: 64, tps: 0.00, reads: 0.00, writes: 34449.97, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[ 563s] threads: 64, tps: 0.00, reads: 0.00, writes: 33620.03, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 564s] threads: 64, tps: 0.00, reads: 0.00, writes: 41427.95, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 565s] threads: 64, tps: 0.00, reads: 0.00, writes: 36500.99, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[ 566s] threads: 64, tps: 0.00, reads: 0.00, writes: 35951.08, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[ 567s] threads: 64, tps: 0.00, reads: 0.00, writes: 36938.89, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 568s] threads: 64, tps: 0.00, reads: 0.00, writes: 36240.08, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 569s] threads: 64, tps: 0.00, reads: 0.00, writes: 39707.91, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 570s] threads: 64, tps: 0.00, reads: 0.00, writes: 40472.04, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 571s] threads: 64, tps: 0.00, reads: 0.00, writes: 38200.02, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 572s] threads: 64, tps: 0.00, reads: 0.00, writes: 36181.03, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[ 573s] threads: 64, tps: 0.00, reads: 0.00, writes: 28556.99, response time: 3.68ms (95%), errors: 0.00, reconnects:  0.00
[ 574s] threads: 64, tps: 0.00, reads: 0.00, writes: 31626.28, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[ 575s] threads: 64, tps: 0.00, reads: 0.00, writes: 38470.13, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 576s] threads: 64, tps: 0.00, reads: 0.00, writes: 38127.74, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[ 577s] threads: 64, tps: 0.00, reads: 0.00, writes: 35093.00, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 578s] threads: 64, tps: 0.00, reads: 0.00, writes: 34094.83, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 579s] threads: 64, tps: 0.00, reads: 0.00, writes: 33776.20, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[ 580s] threads: 64, tps: 0.00, reads: 0.00, writes: 36581.92, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 581s] threads: 64, tps: 0.00, reads: 0.00, writes: 33797.02, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 582s] threads: 64, tps: 0.00, reads: 0.00, writes: 36462.01, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[ 583s] threads: 64, tps: 0.00, reads: 0.00, writes: 33202.95, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[ 584s] threads: 64, tps: 0.00, reads: 0.00, writes: 33830.06, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[ 585s] threads: 64, tps: 0.00, reads: 0.00, writes: 28245.95, response time: 4.48ms (95%), errors: 0.00, reconnects:  0.00
[ 586s] threads: 64, tps: 0.00, reads: 0.00, writes: 31176.04, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 587s] threads: 64, tps: 0.00, reads: 0.00, writes: 34975.95, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[ 588s] threads: 64, tps: 0.00, reads: 0.00, writes: 29281.07, response time: 4.05ms (95%), errors: 0.00, reconnects:  0.00
[ 589s] threads: 64, tps: 0.00, reads: 0.00, writes: 33216.00, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 590s] threads: 64, tps: 0.00, reads: 0.00, writes: 35196.95, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[ 591s] threads: 64, tps: 0.00, reads: 0.00, writes: 37622.07, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 592s] threads: 64, tps: 0.00, reads: 0.00, writes: 41544.96, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 593s] threads: 64, tps: 0.00, reads: 0.00, writes: 40020.97, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 594s] threads: 64, tps: 0.00, reads: 0.00, writes: 39409.03, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 595s] threads: 64, tps: 0.00, reads: 0.00, writes: 38843.93, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 596s] threads: 64, tps: 0.00, reads: 0.00, writes: 38330.07, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 597s] threads: 64, tps: 0.00, reads: 0.00, writes: 41094.83, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 598s] threads: 64, tps: 0.00, reads: 0.00, writes: 41333.16, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 599s] threads: 64, tps: 0.00, reads: 0.00, writes: 39321.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 600s] threads: 64, tps: 0.00, reads: 0.00, writes: 37900.03, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 601s] threads: 64, tps: 0.00, reads: 0.00, writes: 37927.94, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 602s] threads: 64, tps: 0.00, reads: 0.00, writes: 38673.01, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 603s] threads: 64, tps: 0.00, reads: 0.00, writes: 40830.98, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 604s] threads: 64, tps: 0.00, reads: 0.00, writes: 39416.08, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 605s] threads: 64, tps: 0.00, reads: 0.00, writes: 38758.95, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 606s] threads: 64, tps: 0.00, reads: 0.00, writes: 38038.04, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 607s] threads: 64, tps: 0.00, reads: 0.00, writes: 38036.95, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[ 608s] threads: 64, tps: 0.00, reads: 0.00, writes: 40675.03, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 609s] threads: 64, tps: 0.00, reads: 0.00, writes: 38769.00, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 610s] threads: 64, tps: 0.00, reads: 0.00, writes: 37309.01, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 611s] threads: 64, tps: 0.00, reads: 0.00, writes: 30537.02, response time: 3.70ms (95%), errors: 0.00, reconnects:  0.00
[ 612s] threads: 64, tps: 0.00, reads: 0.00, writes: 26305.98, response time: 5.33ms (95%), errors: 0.00, reconnects:  0.00
[ 613s] threads: 64, tps: 0.00, reads: 0.00, writes: 31004.97, response time: 4.09ms (95%), errors: 0.00, reconnects:  0.00
[ 614s] threads: 64, tps: 0.00, reads: 0.00, writes: 38596.03, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[ 615s] threads: 64, tps: 0.00, reads: 0.00, writes: 33089.96, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[ 616s] threads: 64, tps: 0.00, reads: 0.00, writes: 33678.97, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[ 617s] threads: 64, tps: 0.00, reads: 0.00, writes: 34368.08, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 618s] threads: 64, tps: 0.00, reads: 0.00, writes: 33406.98, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[ 619s] threads: 64, tps: 0.00, reads: 0.00, writes: 38470.99, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 620s] threads: 64, tps: 0.00, reads: 0.00, writes: 39559.04, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 621s] threads: 64, tps: 0.00, reads: 0.00, writes: 36044.00, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[ 622s] threads: 64, tps: 0.00, reads: 0.00, writes: 33487.95, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[ 623s] threads: 64, tps: 0.00, reads: 0.00, writes: 33285.06, response time: 3.49ms (95%), errors: 0.00, reconnects:  0.00
[ 624s] threads: 64, tps: 0.00, reads: 0.00, writes: 26998.96, response time: 4.06ms (95%), errors: 0.00, reconnects:  0.00
[ 625s] threads: 64, tps: 0.00, reads: 0.00, writes: 37329.99, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[ 626s] threads: 64, tps: 0.00, reads: 0.00, writes: 27581.39, response time: 5.32ms (95%), errors: 0.00, reconnects:  0.00
[ 627s] threads: 64, tps: 0.00, reads: 0.00, writes: 26214.60, response time: 5.50ms (95%), errors: 0.00, reconnects:  0.00
[ 628s] threads: 64, tps: 0.00, reads: 0.00, writes: 31757.02, response time: 3.28ms (95%), errors: 0.00, reconnects:  0.00
[ 629s] threads: 64, tps: 0.00, reads: 0.00, writes: 33137.02, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 630s] threads: 64, tps: 0.00, reads: 0.00, writes: 34239.10, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 631s] threads: 64, tps: 0.00, reads: 0.00, writes: 35192.88, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 632s] threads: 64, tps: 0.00, reads: 0.00, writes: 41187.98, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 633s] threads: 64, tps: 0.00, reads: 0.00, writes: 39523.07, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 634s] threads: 64, tps: 0.00, reads: 0.00, writes: 39275.88, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 635s] threads: 64, tps: 0.00, reads: 0.00, writes: 37989.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 636s] threads: 64, tps: 0.00, reads: 0.00, writes: 40516.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 637s] threads: 64, tps: 0.00, reads: 0.00, writes: 40493.06, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 638s] threads: 64, tps: 0.00, reads: 0.00, writes: 39093.84, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 639s] threads: 64, tps: 0.00, reads: 0.00, writes: 38407.14, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 640s] threads: 64, tps: 0.00, reads: 0.00, writes: 36397.03, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 641s] threads: 64, tps: 0.00, reads: 0.00, writes: 37676.94, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 642s] threads: 64, tps: 0.00, reads: 0.00, writes: 41820.11, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 643s] threads: 64, tps: 0.00, reads: 0.00, writes: 38990.95, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 644s] threads: 64, tps: 0.00, reads: 0.00, writes: 37937.21, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 645s] threads: 64, tps: 0.00, reads: 0.00, writes: 37304.74, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 646s] threads: 64, tps: 0.00, reads: 0.00, writes: 36064.98, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[ 647s] threads: 64, tps: 0.00, reads: 0.00, writes: 41693.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 648s] threads: 64, tps: 0.00, reads: 0.00, writes: 35820.03, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[ 649s] threads: 64, tps: 0.00, reads: 0.00, writes: 28369.99, response time: 4.56ms (95%), errors: 0.00, reconnects:  0.00
[ 650s] threads: 64, tps: 0.00, reads: 0.00, writes: 28239.94, response time: 3.97ms (95%), errors: 0.00, reconnects:  0.00
[ 651s] threads: 64, tps: 0.00, reads: 0.00, writes: 31126.71, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[ 652s] threads: 64, tps: 0.00, reads: 0.00, writes: 32810.00, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[ 653s] threads: 64, tps: 0.00, reads: 0.00, writes: 39530.97, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 654s] threads: 64, tps: 0.00, reads: 0.00, writes: 38621.02, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 655s] threads: 64, tps: 0.00, reads: 0.00, writes: 34845.00, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[ 656s] threads: 64, tps: 0.00, reads: 0.00, writes: 34177.00, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[ 657s] threads: 64, tps: 0.00, reads: 0.00, writes: 33995.00, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 658s] threads: 64, tps: 0.00, reads: 0.00, writes: 36172.98, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[ 659s] threads: 64, tps: 0.00, reads: 0.00, writes: 36812.98, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 660s] threads: 64, tps: 0.00, reads: 0.00, writes: 35593.02, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[ 661s] threads: 64, tps: 0.00, reads: 0.00, writes: 24261.99, response time: 6.43ms (95%), errors: 0.00, reconnects:  0.00
[ 662s] threads: 64, tps: 0.00, reads: 0.00, writes: 28333.96, response time: 4.06ms (95%), errors: 0.00, reconnects:  0.00
[ 663s] threads: 64, tps: 0.00, reads: 0.00, writes: 29484.14, response time: 3.76ms (95%), errors: 0.00, reconnects:  0.00
[ 664s] threads: 64, tps: 0.00, reads: 0.00, writes: 34061.98, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[ 665s] threads: 64, tps: 0.00, reads: 0.00, writes: 40804.98, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 666s] threads: 64, tps: 0.00, reads: 0.00, writes: 37545.07, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 667s] threads: 64, tps: 0.00, reads: 0.00, writes: 38503.01, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 668s] threads: 64, tps: 0.00, reads: 0.00, writes: 38361.96, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 669s] threads: 64, tps: 0.00, reads: 0.00, writes: 38088.01, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 670s] threads: 64, tps: 0.00, reads: 0.00, writes: 43223.98, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 671s] threads: 64, tps: 0.00, reads: 0.00, writes: 40499.03, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 672s] threads: 64, tps: 0.00, reads: 0.00, writes: 39758.00, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 673s] threads: 64, tps: 0.00, reads: 0.00, writes: 39713.97, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 674s] threads: 64, tps: 0.00, reads: 0.00, writes: 39163.04, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 675s] threads: 64, tps: 0.00, reads: 0.00, writes: 43457.97, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 676s] threads: 64, tps: 0.00, reads: 0.00, writes: 40832.97, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 677s] threads: 64, tps: 0.00, reads: 0.00, writes: 40391.10, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 678s] threads: 64, tps: 0.00, reads: 0.00, writes: 31004.94, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[ 679s] threads: 64, tps: 0.00, reads: 0.00, writes: 38034.98, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 680s] threads: 64, tps: 0.00, reads: 0.00, writes: 41809.03, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 681s] threads: 64, tps: 0.00, reads: 0.00, writes: 41578.57, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 682s] threads: 64, tps: 0.00, reads: 0.00, writes: 39101.36, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 683s] threads: 64, tps: 0.00, reads: 0.00, writes: 38637.06, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 684s] threads: 64, tps: 0.00, reads: 0.00, writes: 34980.97, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 685s] threads: 64, tps: 0.00, reads: 0.00, writes: 34402.02, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[ 686s] threads: 64, tps: 0.00, reads: 0.00, writes: 38096.01, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[ 687s] threads: 64, tps: 0.00, reads: 0.00, writes: 29271.97, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[ 688s] threads: 64, tps: 0.00, reads: 0.00, writes: 35371.03, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[ 689s] threads: 64, tps: 0.00, reads: 0.00, writes: 36439.97, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 690s] threads: 64, tps: 0.00, reads: 0.00, writes: 36137.01, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 691s] threads: 64, tps: 0.00, reads: 0.00, writes: 39689.02, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 692s] threads: 64, tps: 0.00, reads: 0.00, writes: 39687.92, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 693s] threads: 64, tps: 0.00, reads: 0.00, writes: 36356.06, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[ 694s] threads: 64, tps: 0.00, reads: 0.00, writes: 35058.03, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 695s] threads: 64, tps: 0.00, reads: 0.00, writes: 34981.92, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[ 696s] threads: 64, tps: 0.00, reads: 0.00, writes: 37652.03, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[ 697s] threads: 64, tps: 0.00, reads: 0.00, writes: 40296.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 698s] threads: 64, tps: 0.00, reads: 0.00, writes: 33053.84, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[ 699s] threads: 64, tps: 0.00, reads: 0.00, writes: 30395.09, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[ 700s] threads: 64, tps: 0.00, reads: 0.00, writes: 32233.01, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 701s] threads: 64, tps: 0.00, reads: 0.00, writes: 35679.96, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 702s] threads: 64, tps: 0.00, reads: 0.00, writes: 40595.11, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 703s] threads: 64, tps: 0.00, reads: 0.00, writes: 39845.02, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 704s] threads: 64, tps: 0.00, reads: 0.00, writes: 39492.98, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 705s] threads: 64, tps: 0.00, reads: 0.00, writes: 38936.96, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 706s] threads: 64, tps: 0.00, reads: 0.00, writes: 38442.07, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 707s] threads: 64, tps: 0.00, reads: 0.00, writes: 40761.96, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 708s] threads: 64, tps: 0.00, reads: 0.00, writes: 41839.03, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 709s] threads: 64, tps: 0.00, reads: 0.00, writes: 40981.65, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 710s] threads: 64, tps: 0.00, reads: 0.00, writes: 40417.32, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 711s] threads: 64, tps: 0.00, reads: 0.00, writes: 39537.99, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 712s] threads: 64, tps: 0.00, reads: 0.00, writes: 42093.98, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 713s] threads: 64, tps: 0.00, reads: 0.00, writes: 40870.90, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 714s] threads: 64, tps: 0.00, reads: 0.00, writes: 39900.11, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 715s] threads: 64, tps: 0.00, reads: 0.00, writes: 36157.97, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 716s] threads: 64, tps: 0.00, reads: 0.00, writes: 38512.57, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 717s] threads: 64, tps: 0.00, reads: 0.00, writes: 41167.41, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 718s] threads: 64, tps: 0.00, reads: 0.00, writes: 41907.03, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 719s] threads: 64, tps: 0.00, reads: 0.00, writes: 39655.00, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 720s] threads: 64, tps: 0.00, reads: 0.00, writes: 38602.05, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 721s] threads: 64, tps: 0.00, reads: 0.00, writes: 36930.10, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 722s] threads: 64, tps: 0.00, reads: 0.00, writes: 39927.03, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 723s] threads: 64, tps: 0.00, reads: 0.00, writes: 37182.79, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 724s] threads: 64, tps: 0.00, reads: 0.00, writes: 37118.20, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 725s] threads: 64, tps: 0.00, reads: 0.00, writes: 32761.00, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[ 726s] threads: 64, tps: 0.00, reads: 0.00, writes: 35470.99, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[ 727s] threads: 64, tps: 0.00, reads: 0.00, writes: 34540.01, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 728s] threads: 64, tps: 0.00, reads: 0.00, writes: 39862.01, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 729s] threads: 64, tps: 0.00, reads: 0.00, writes: 37437.99, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 730s] threads: 64, tps: 0.00, reads: 0.00, writes: 34408.01, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 731s] threads: 64, tps: 0.00, reads: 0.00, writes: 34391.01, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[ 732s] threads: 64, tps: 0.00, reads: 0.00, writes: 34121.97, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 733s] threads: 64, tps: 0.00, reads: 0.00, writes: 36487.98, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 734s] threads: 64, tps: 0.00, reads: 0.00, writes: 40095.07, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 735s] threads: 64, tps: 0.00, reads: 0.00, writes: 37584.97, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[ 736s] threads: 64, tps: 0.00, reads: 0.00, writes: 35600.03, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 737s] threads: 64, tps: 0.00, reads: 0.00, writes: 31051.95, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[ 738s] threads: 64, tps: 0.00, reads: 0.00, writes: 28868.04, response time: 3.52ms (95%), errors: 0.00, reconnects:  0.00
[ 739s] threads: 64, tps: 0.00, reads: 0.00, writes: 33572.92, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[ 740s] threads: 64, tps: 0.00, reads: 0.00, writes: 37007.11, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 741s] threads: 64, tps: 0.00, reads: 0.00, writes: 20754.98, response time: 19.97ms (95%), errors: 0.00, reconnects:  0.00
[ 742s] threads: 64, tps: 0.00, reads: 0.00, writes: 36195.99, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[ 743s] threads: 64, tps: 0.00, reads: 0.00, writes: 37204.01, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 744s] threads: 64, tps: 0.00, reads: 0.00, writes: 36628.00, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 745s] threads: 64, tps: 0.00, reads: 0.00, writes: 40346.02, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 746s] threads: 64, tps: 0.00, reads: 0.00, writes: 40597.01, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 747s] threads: 64, tps: 0.00, reads: 0.00, writes: 39465.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 748s] threads: 64, tps: 0.00, reads: 0.00, writes: 38909.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 749s] threads: 64, tps: 0.00, reads: 0.00, writes: 37742.97, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 750s] threads: 64, tps: 0.00, reads: 0.00, writes: 40950.95, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 751s] threads: 64, tps: 0.00, reads: 0.00, writes: 41471.04, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 752s] threads: 64, tps: 0.00, reads: 0.00, writes: 40022.02, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 753s] threads: 64, tps: 0.00, reads: 0.00, writes: 38269.97, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 754s] threads: 64, tps: 0.00, reads: 0.00, writes: 37462.02, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 755s] threads: 64, tps: 0.00, reads: 0.00, writes: 39060.98, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 756s] threads: 64, tps: 0.00, reads: 0.00, writes: 41327.04, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 757s] threads: 64, tps: 0.00, reads: 0.00, writes: 39361.91, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 758s] threads: 64, tps: 0.00, reads: 0.00, writes: 39002.83, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 759s] threads: 64, tps: 0.00, reads: 0.00, writes: 38110.20, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 760s] threads: 64, tps: 0.00, reads: 0.00, writes: 37365.04, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 761s] threads: 64, tps: 0.00, reads: 0.00, writes: 40658.02, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 762s] threads: 64, tps: 0.00, reads: 0.00, writes: 35484.83, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 763s] threads: 64, tps: 0.00, reads: 0.00, writes: 31626.79, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[ 764s] threads: 64, tps: 0.00, reads: 0.00, writes: 31251.98, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[ 765s] threads: 64, tps: 0.00, reads: 0.00, writes: 31223.98, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[ 766s] threads: 64, tps: 0.00, reads: 0.00, writes: 35462.00, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[ 767s] threads: 64, tps: 0.00, reads: 0.00, writes: 38828.01, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 768s] threads: 64, tps: 0.00, reads: 0.00, writes: 35256.03, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 769s] threads: 64, tps: 0.00, reads: 0.00, writes: 36313.03, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[ 770s] threads: 64, tps: 0.00, reads: 0.00, writes: 35274.98, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 771s] threads: 64, tps: 0.00, reads: 0.00, writes: 30681.96, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[ 772s] threads: 64, tps: 0.00, reads: 0.00, writes: 36782.22, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 773s] threads: 64, tps: 0.00, reads: 0.00, writes: 39587.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 774s] threads: 64, tps: 0.00, reads: 0.00, writes: 36516.99, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[ 775s] threads: 64, tps: 0.00, reads: 0.00, writes: 35215.97, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[ 776s] threads: 64, tps: 0.00, reads: 0.00, writes: 36017.04, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[ 777s] threads: 64, tps: 0.00, reads: 0.00, writes: 33482.04, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[ 778s] threads: 64, tps: 0.00, reads: 0.00, writes: 40320.93, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 779s] threads: 64, tps: 0.00, reads: 0.00, writes: 15512.02, response time: 20.76ms (95%), errors: 0.00, reconnects:  0.00
[ 780s] threads: 64, tps: 0.00, reads: 0.00, writes: 21282.95, response time: 20.15ms (95%), errors: 0.00, reconnects:  0.00
[ 781s] threads: 64, tps: 0.00, reads: 0.00, writes: 33996.01, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[ 782s] threads: 64, tps: 0.00, reads: 0.00, writes: 35423.99, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 783s] threads: 64, tps: 0.00, reads: 0.00, writes: 35515.04, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 784s] threads: 64, tps: 0.00, reads: 0.00, writes: 40088.92, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 785s] threads: 64, tps: 0.00, reads: 0.00, writes: 38987.02, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 786s] threads: 64, tps: 0.00, reads: 0.00, writes: 38446.00, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 787s] threads: 64, tps: 0.00, reads: 0.00, writes: 38271.02, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 788s] threads: 64, tps: 0.00, reads: 0.00, writes: 38634.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 789s] threads: 64, tps: 0.00, reads: 0.00, writes: 41777.04, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 790s] threads: 64, tps: 0.00, reads: 0.00, writes: 40809.99, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 791s] threads: 64, tps: 0.00, reads: 0.00, writes: 39112.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 792s] threads: 64, tps: 0.00, reads: 0.00, writes: 38084.93, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 793s] threads: 64, tps: 0.00, reads: 0.00, writes: 37880.03, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 794s] threads: 64, tps: 0.00, reads: 0.00, writes: 40371.06, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 795s] threads: 64, tps: 0.00, reads: 0.00, writes: 40499.92, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 796s] threads: 64, tps: 0.00, reads: 0.00, writes: 40090.05, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 797s] threads: 64, tps: 0.00, reads: 0.00, writes: 38015.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 798s] threads: 64, tps: 0.00, reads: 0.00, writes: 37737.99, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 799s] threads: 64, tps: 0.00, reads: 0.00, writes: 39984.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 800s] threads: 64, tps: 0.00, reads: 0.00, writes: 41608.09, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 801s] threads: 64, tps: 0.00, reads: 0.00, writes: 38901.96, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 802s] threads: 64, tps: 0.00, reads: 0.00, writes: 30737.97, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[ 803s] threads: 64, tps: 0.00, reads: 0.00, writes: 35983.01, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[ 804s] threads: 64, tps: 0.00, reads: 0.00, writes: 35059.01, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[ 805s] threads: 64, tps: 0.00, reads: 0.00, writes: 41879.95, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 806s] threads: 64, tps: 0.00, reads: 0.00, writes: 38867.98, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 807s] threads: 64, tps: 0.00, reads: 0.00, writes: 35373.33, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[ 808s] threads: 64, tps: 0.00, reads: 0.00, writes: 36702.77, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 809s] threads: 64, tps: 0.00, reads: 0.00, writes: 35662.98, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[ 810s] threads: 64, tps: 0.00, reads: 0.00, writes: 39850.55, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 811s] threads: 64, tps: 0.00, reads: 0.00, writes: 37024.40, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[ 812s] threads: 64, tps: 0.00, reads: 0.00, writes: 29061.39, response time: 3.43ms (95%), errors: 0.00, reconnects:  0.00
[ 813s] threads: 64, tps: 0.00, reads: 0.00, writes: 29647.66, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[ 814s] threads: 64, tps: 0.00, reads: 0.00, writes: 28646.96, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[ 815s] threads: 64, tps: 0.00, reads: 0.00, writes: 31786.07, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[ 816s] threads: 64, tps: 0.00, reads: 0.00, writes: 37270.94, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[ 817s] threads: 64, tps: 0.00, reads: 0.00, writes: 38352.97, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[ 818s] threads: 64, tps: 0.00, reads: 0.00, writes: 36660.90, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[ 819s] threads: 64, tps: 0.00, reads: 0.00, writes: 35322.06, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 820s] threads: 64, tps: 0.00, reads: 0.00, writes: 31832.92, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 821s] threads: 64, tps: 0.00, reads: 0.00, writes: 36755.98, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 822s] threads: 64, tps: 0.00, reads: 0.00, writes: 42879.05, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 823s] threads: 64, tps: 0.00, reads: 0.00, writes: 39093.07, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 824s] threads: 64, tps: 0.00, reads: 0.00, writes: 38024.21, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 825s] threads: 64, tps: 0.00, reads: 0.00, writes: 37585.70, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 826s] threads: 64, tps: 0.00, reads: 0.00, writes: 37283.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 827s] threads: 64, tps: 0.00, reads: 0.00, writes: 41573.98, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 828s] threads: 64, tps: 0.00, reads: 0.00, writes: 41088.94, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 829s] threads: 64, tps: 0.00, reads: 0.00, writes: 39476.11, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 830s] threads: 64, tps: 0.00, reads: 0.00, writes: 38281.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 831s] threads: 64, tps: 0.00, reads: 0.00, writes: 36977.88, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 832s] threads: 64, tps: 0.00, reads: 0.00, writes: 41720.63, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 833s] threads: 64, tps: 0.00, reads: 0.00, writes: 39262.02, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 834s] threads: 64, tps: 0.00, reads: 0.00, writes: 37865.03, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 835s] threads: 64, tps: 0.00, reads: 0.00, writes: 32008.97, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[ 836s] threads: 64, tps: 0.00, reads: 0.00, writes: 30082.01, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[ 837s] threads: 64, tps: 0.00, reads: 0.00, writes: 29343.97, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[ 838s] threads: 64, tps: 0.00, reads: 0.00, writes: 39828.72, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 839s] threads: 64, tps: 0.00, reads: 0.00, writes: 32938.66, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[ 840s] threads: 64, tps: 0.00, reads: 0.00, writes: 33446.09, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[ 841s] threads: 64, tps: 0.00, reads: 0.00, writes: 36121.38, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[ 842s] threads: 64, tps: 0.00, reads: 0.00, writes: 34995.61, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[ 843s] threads: 64, tps: 0.00, reads: 0.00, writes: 37013.03, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[ 844s] threads: 64, tps: 0.00, reads: 0.00, writes: 40974.97, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 845s] threads: 64, tps: 0.00, reads: 0.00, writes: 38609.98, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 846s] threads: 64, tps: 0.00, reads: 0.00, writes: 35966.99, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[ 847s] threads: 64, tps: 0.00, reads: 0.00, writes: 35733.00, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[ 848s] threads: 64, tps: 0.00, reads: 0.00, writes: 34932.01, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[ 849s] threads: 64, tps: 0.00, reads: 0.00, writes: 40615.01, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 850s] threads: 64, tps: 0.00, reads: 0.00, writes: 38448.97, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 851s] threads: 64, tps: 0.00, reads: 0.00, writes: 28283.98, response time: 3.42ms (95%), errors: 0.00, reconnects:  0.00
[ 852s] threads: 64, tps: 0.00, reads: 0.00, writes: 3089.00, response time: 21.78ms (95%), errors: 0.00, reconnects:  0.00
[ 853s] threads: 64, tps: 0.00, reads: 0.00, writes: 3044.99, response time: 24.25ms (95%), errors: 0.00, reconnects:  0.00
[ 854s] threads: 64, tps: 0.00, reads: 0.00, writes: 31726.18, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 855s] threads: 64, tps: 0.00, reads: 0.00, writes: 35234.22, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 856s] threads: 64, tps: 0.00, reads: 0.00, writes: 37636.02, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 857s] threads: 64, tps: 0.00, reads: 0.00, writes: 38993.99, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 858s] threads: 64, tps: 0.00, reads: 0.00, writes: 37053.06, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 859s] threads: 64, tps: 0.00, reads: 0.00, writes: 37531.04, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 860s] threads: 64, tps: 0.00, reads: 0.00, writes: 36767.89, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 861s] threads: 64, tps: 0.00, reads: 0.00, writes: 36002.02, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 862s] threads: 64, tps: 0.00, reads: 0.00, writes: 42863.02, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 863s] threads: 64, tps: 0.00, reads: 0.00, writes: 38713.33, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 864s] threads: 64, tps: 0.00, reads: 0.00, writes: 37805.70, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 865s] threads: 64, tps: 0.00, reads: 0.00, writes: 37568.95, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 866s] threads: 64, tps: 0.00, reads: 0.00, writes: 37640.78, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 867s] threads: 64, tps: 0.00, reads: 0.00, writes: 41862.06, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 868s] threads: 64, tps: 0.00, reads: 0.00, writes: 34543.18, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 869s] threads: 64, tps: 0.00, reads: 0.00, writes: 39640.00, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 870s] threads: 64, tps: 0.00, reads: 0.00, writes: 37480.98, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 871s] threads: 64, tps: 0.00, reads: 0.00, writes: 37277.01, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 872s] threads: 64, tps: 0.00, reads: 0.00, writes: 41592.96, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 873s] threads: 64, tps: 0.00, reads: 0.00, writes: 40912.01, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 874s] threads: 64, tps: 0.00, reads: 0.00, writes: 38357.03, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 875s] threads: 64, tps: 0.00, reads: 0.00, writes: 37865.99, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 876s] threads: 64, tps: 0.00, reads: 0.00, writes: 37642.98, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 877s] threads: 64, tps: 0.00, reads: 0.00, writes: 35142.98, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[ 878s] threads: 64, tps: 0.00, reads: 0.00, writes: 40392.99, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 879s] threads: 64, tps: 0.00, reads: 0.00, writes: 35237.04, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[ 880s] threads: 64, tps: 0.00, reads: 0.00, writes: 30677.92, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[ 881s] threads: 64, tps: 0.00, reads: 0.00, writes: 35649.01, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[ 882s] threads: 64, tps: 0.00, reads: 0.00, writes: 34629.98, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[ 883s] threads: 64, tps: 0.00, reads: 0.00, writes: 38984.08, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[ 884s] threads: 64, tps: 0.00, reads: 0.00, writes: 39132.96, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 885s] threads: 64, tps: 0.00, reads: 0.00, writes: 35666.08, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[ 886s] threads: 64, tps: 0.00, reads: 0.00, writes: 35164.97, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 887s] threads: 64, tps: 0.00, reads: 0.00, writes: 34566.99, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[ 888s] threads: 64, tps: 0.00, reads: 0.00, writes: 36138.02, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[ 889s] threads: 64, tps: 0.00, reads: 0.00, writes: 40771.99, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 890s] threads: 64, tps: 0.00, reads: 0.00, writes: 38082.99, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 891s] threads: 64, tps: 0.00, reads: 0.00, writes: 29734.99, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[ 892s] threads: 64, tps: 0.00, reads: 0.00, writes: 27909.00, response time: 3.75ms (95%), errors: 0.00, reconnects:  0.00
[ 893s] threads: 64, tps: 0.00, reads: 0.00, writes: 29675.04, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[ 894s] threads: 64, tps: 0.00, reads: 0.00, writes: 34187.94, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 895s] threads: 64, tps: 0.00, reads: 0.00, writes: 39600.00, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 896s] threads: 64, tps: 0.00, reads: 0.00, writes: 37800.98, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 897s] threads: 64, tps: 0.00, reads: 0.00, writes: 38577.03, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 898s] threads: 64, tps: 0.00, reads: 0.00, writes: 38254.00, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 899s] threads: 64, tps: 0.00, reads: 0.00, writes: 37642.05, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 900s] threads: 64, tps: 0.00, reads: 0.00, writes: 42703.97, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 901s] threads: 64, tps: 0.00, reads: 0.00, writes: 39281.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 902s] threads: 64, tps: 0.00, reads: 0.00, writes: 38963.99, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 903s] threads: 64, tps: 0.00, reads: 0.00, writes: 32945.02, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 904s] threads: 64, tps: 0.00, reads: 0.00, writes: 38361.95, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 905s] threads: 64, tps: 0.00, reads: 0.00, writes: 42598.04, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 906s] threads: 64, tps: 0.00, reads: 0.00, writes: 41234.99, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 907s] threads: 64, tps: 0.00, reads: 0.00, writes: 39019.03, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 908s] threads: 64, tps: 0.00, reads: 0.00, writes: 37617.00, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 909s] threads: 64, tps: 0.00, reads: 0.00, writes: 37627.00, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 910s] threads: 64, tps: 0.00, reads: 0.00, writes: 41086.93, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 911s] threads: 64, tps: 0.00, reads: 0.00, writes: 40401.99, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 912s] threads: 64, tps: 0.00, reads: 0.00, writes: 39718.05, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 913s] threads: 64, tps: 0.00, reads: 0.00, writes: 38656.96, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 914s] threads: 64, tps: 0.00, reads: 0.00, writes: 38282.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 915s] threads: 64, tps: 0.00, reads: 0.00, writes: 37500.99, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 916s] threads: 64, tps: 0.00, reads: 0.00, writes: 40860.00, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 917s] threads: 64, tps: 0.00, reads: 0.00, writes: 36550.07, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 918s] threads: 64, tps: 0.00, reads: 0.00, writes: 34945.94, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[ 919s] threads: 64, tps: 0.00, reads: 0.00, writes: 29685.99, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[ 920s] threads: 64, tps: 0.00, reads: 0.00, writes: 35266.07, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[ 921s] threads: 64, tps: 0.00, reads: 0.00, writes: 41540.99, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 922s] threads: 64, tps: 0.00, reads: 0.00, writes: 38475.99, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[ 923s] threads: 64, tps: 0.00, reads: 0.00, writes: 36574.41, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 924s] threads: 64, tps: 0.00, reads: 0.00, writes: 36820.47, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 925s] threads: 64, tps: 0.00, reads: 0.00, writes: 33969.12, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[ 926s] threads: 64, tps: 0.00, reads: 0.00, writes: 40138.03, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 927s] threads: 64, tps: 0.00, reads: 0.00, writes: 39747.86, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 928s] threads: 64, tps: 0.00, reads: 0.00, writes: 35466.90, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[ 929s] threads: 64, tps: 0.00, reads: 0.00, writes: 35402.15, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[ 930s] threads: 64, tps: 0.00, reads: 0.00, writes: 30135.89, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[ 931s] threads: 64, tps: 0.00, reads: 0.00, writes: 27669.00, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[ 932s] threads: 64, tps: 0.00, reads: 0.00, writes: 38382.77, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 933s] threads: 64, tps: 0.00, reads: 0.00, writes: 33838.33, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[ 934s] threads: 64, tps: 0.00, reads: 0.00, writes: 30919.87, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[ 935s] threads: 64, tps: 0.00, reads: 0.00, writes: 32627.16, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[ 936s] threads: 64, tps: 0.00, reads: 0.00, writes: 33106.03, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[ 937s] threads: 64, tps: 0.00, reads: 0.00, writes: 33722.69, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[ 938s] threads: 64, tps: 0.00, reads: 0.00, writes: 41272.38, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 939s] threads: 64, tps: 0.00, reads: 0.00, writes: 39018.97, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 940s] threads: 64, tps: 0.00, reads: 0.00, writes: 38103.74, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 941s] threads: 64, tps: 0.00, reads: 0.00, writes: 38171.24, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 942s] threads: 64, tps: 0.00, reads: 0.00, writes: 37338.98, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 943s] threads: 64, tps: 0.00, reads: 0.00, writes: 41684.02, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 944s] threads: 64, tps: 0.00, reads: 0.00, writes: 39416.83, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 945s] threads: 64, tps: 0.00, reads: 0.00, writes: 39084.14, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 946s] threads: 64, tps: 0.00, reads: 0.00, writes: 37613.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 947s] threads: 64, tps: 0.00, reads: 0.00, writes: 37584.00, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 948s] threads: 64, tps: 0.00, reads: 0.00, writes: 36686.01, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 949s] threads: 64, tps: 0.00, reads: 0.00, writes: 40776.90, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 950s] threads: 64, tps: 0.00, reads: 0.00, writes: 39063.17, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 951s] threads: 64, tps: 0.00, reads: 0.00, writes: 38493.97, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 952s] threads: 64, tps: 0.00, reads: 0.00, writes: 38487.95, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 953s] threads: 64, tps: 0.00, reads: 0.00, writes: 39253.04, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 954s] threads: 64, tps: 0.00, reads: 0.00, writes: 40796.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 955s] threads: 64, tps: 0.00, reads: 0.00, writes: 38493.96, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 956s] threads: 64, tps: 0.00, reads: 0.00, writes: 37869.87, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 957s] threads: 64, tps: 0.00, reads: 0.00, writes: 29659.11, response time: 3.47ms (95%), errors: 0.00, reconnects:  0.00
[ 958s] threads: 64, tps: 0.00, reads: 0.00, writes: 33865.02, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[ 959s] threads: 64, tps: 0.00, reads: 0.00, writes: 40842.96, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 960s] threads: 64, tps: 0.00, reads: 0.00, writes: 37405.00, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 961s] threads: 64, tps: 0.00, reads: 0.00, writes: 32654.60, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[ 962s] threads: 64, tps: 0.00, reads: 0.00, writes: 31595.34, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[ 963s] threads: 64, tps: 0.00, reads: 0.00, writes: 30788.85, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 964s] threads: 64, tps: 0.00, reads: 0.00, writes: 35790.94, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[ 965s] threads: 64, tps: 0.00, reads: 0.00, writes: 40342.87, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 966s] threads: 64, tps: 0.00, reads: 0.00, writes: 37086.89, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 967s] threads: 64, tps: 0.00, reads: 0.00, writes: 34946.23, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[ 968s] threads: 64, tps: 0.00, reads: 0.00, writes: 34876.01, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[ 969s] threads: 64, tps: 0.00, reads: 0.00, writes: 34564.01, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[ 970s] threads: 64, tps: 0.00, reads: 0.00, writes: 39903.01, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 971s] threads: 64, tps: 0.00, reads: 0.00, writes: 39941.02, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 972s] threads: 64, tps: 0.00, reads: 0.00, writes: 24828.49, response time: 8.00ms (95%), errors: 0.00, reconnects:  0.00
[ 973s] threads: 64, tps: 0.00, reads: 0.00, writes: 3098.05, response time: 21.63ms (95%), errors: 0.00, reconnects:  0.00
[ 974s] threads: 64, tps: 0.00, reads: 0.00, writes: 8624.02, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[ 975s] threads: 64, tps: 0.00, reads: 0.00, writes: 31113.01, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[ 976s] threads: 64, tps: 0.00, reads: 0.00, writes: 31525.96, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[ 977s] threads: 64, tps: 0.00, reads: 0.00, writes: 33192.85, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[ 978s] threads: 64, tps: 0.00, reads: 0.00, writes: 40927.29, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 979s] threads: 64, tps: 0.00, reads: 0.00, writes: 35333.89, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[ 980s] threads: 64, tps: 0.00, reads: 0.00, writes: 35402.03, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 981s] threads: 64, tps: 0.00, reads: 0.00, writes: 34565.98, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[ 982s] threads: 64, tps: 0.00, reads: 0.00, writes: 35676.05, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 983s] threads: 64, tps: 0.00, reads: 0.00, writes: 39533.05, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 984s] threads: 64, tps: 0.00, reads: 0.00, writes: 39101.98, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 985s] threads: 64, tps: 0.00, reads: 0.00, writes: 36967.98, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 986s] threads: 64, tps: 0.00, reads: 0.00, writes: 36788.95, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 987s] threads: 64, tps: 0.00, reads: 0.00, writes: 36844.92, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 988s] threads: 64, tps: 0.00, reads: 0.00, writes: 36853.10, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[ 989s] threads: 64, tps: 0.00, reads: 0.00, writes: 41720.06, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 990s] threads: 64, tps: 0.00, reads: 0.00, writes: 38577.96, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 991s] threads: 64, tps: 0.00, reads: 0.00, writes: 38057.71, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 992s] threads: 64, tps: 0.00, reads: 0.00, writes: 37379.26, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 993s] threads: 64, tps: 0.00, reads: 0.00, writes: 33316.91, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 994s] threads: 64, tps: 0.00, reads: 0.00, writes: 39375.08, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 995s] threads: 64, tps: 0.00, reads: 0.00, writes: 39531.05, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 996s] threads: 64, tps: 0.00, reads: 0.00, writes: 38779.81, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 997s] threads: 64, tps: 0.00, reads: 0.00, writes: 37480.42, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 998s] threads: 64, tps: 0.00, reads: 0.00, writes: 36575.72, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 999s] threads: 64, tps: 0.00, reads: 0.00, writes: 40013.94, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1000s] threads: 64, tps: 0.00, reads: 0.00, writes: 37360.06, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1001s] threads: 64, tps: 0.00, reads: 0.00, writes: 38563.95, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1002s] threads: 64, tps: 0.00, reads: 0.00, writes: 33486.07, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1003s] threads: 64, tps: 0.00, reads: 0.00, writes: 31132.97, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[1004s] threads: 64, tps: 0.00, reads: 0.00, writes: 34349.02, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1005s] threads: 64, tps: 0.00, reads: 0.00, writes: 41054.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1006s] threads: 64, tps: 0.00, reads: 0.00, writes: 38557.82, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1007s] threads: 64, tps: 0.00, reads: 0.00, writes: 34770.15, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1008s] threads: 64, tps: 0.00, reads: 0.00, writes: 36372.96, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1009s] threads: 64, tps: 0.00, reads: 0.00, writes: 35421.06, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1010s] threads: 64, tps: 0.00, reads: 0.00, writes: 39524.94, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1011s] threads: 64, tps: 0.00, reads: 0.00, writes: 39459.09, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1012s] threads: 64, tps: 0.00, reads: 0.00, writes: 29211.97, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1013s] threads: 64, tps: 0.00, reads: 0.00, writes: 35955.00, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[1014s] threads: 64, tps: 0.00, reads: 0.00, writes: 35346.86, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1015s] threads: 64, tps: 0.00, reads: 0.00, writes: 28477.10, response time: 3.85ms (95%), errors: 0.00, reconnects:  0.00
[1016s] threads: 64, tps: 0.00, reads: 0.00, writes: 37694.04, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1017s] threads: 64, tps: 0.00, reads: 0.00, writes: 27109.95, response time: 6.19ms (95%), errors: 0.00, reconnects:  0.00
[1018s] threads: 64, tps: 0.00, reads: 0.00, writes: 23246.97, response time: 6.20ms (95%), errors: 0.00, reconnects:  0.00
[1019s] threads: 64, tps: 0.00, reads: 0.00, writes: 33316.05, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1020s] threads: 64, tps: 0.00, reads: 0.00, writes: 36686.05, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1021s] threads: 64, tps: 0.00, reads: 0.00, writes: 35868.00, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1022s] threads: 64, tps: 0.00, reads: 0.00, writes: 42001.04, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1023s] threads: 64, tps: 0.00, reads: 0.00, writes: 40502.94, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1024s] threads: 64, tps: 0.00, reads: 0.00, writes: 39155.86, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1025s] threads: 64, tps: 0.00, reads: 0.00, writes: 38199.17, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1026s] threads: 64, tps: 0.00, reads: 0.00, writes: 37229.99, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1027s] threads: 64, tps: 0.00, reads: 0.00, writes: 41324.05, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1028s] threads: 64, tps: 0.00, reads: 0.00, writes: 40494.93, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1029s] threads: 64, tps: 0.00, reads: 0.00, writes: 39745.04, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1030s] threads: 64, tps: 0.00, reads: 0.00, writes: 38306.04, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1031s] threads: 64, tps: 0.00, reads: 0.00, writes: 37974.98, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1032s] threads: 64, tps: 0.00, reads: 0.00, writes: 39278.95, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1033s] threads: 64, tps: 0.00, reads: 0.00, writes: 40475.07, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1034s] threads: 64, tps: 0.00, reads: 0.00, writes: 38374.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1035s] threads: 64, tps: 0.00, reads: 0.00, writes: 38284.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1036s] threads: 64, tps: 0.00, reads: 0.00, writes: 37008.98, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1037s] threads: 64, tps: 0.00, reads: 0.00, writes: 38778.97, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1038s] threads: 64, tps: 0.00, reads: 0.00, writes: 40752.24, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1039s] threads: 64, tps: 0.00, reads: 0.00, writes: 39439.01, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1040s] threads: 64, tps: 0.00, reads: 0.00, writes: 37414.95, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1041s] threads: 64, tps: 0.00, reads: 0.00, writes: 35440.04, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1042s] threads: 64, tps: 0.00, reads: 0.00, writes: 33441.01, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[1043s] threads: 64, tps: 0.00, reads: 0.00, writes: 41284.94, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1044s] threads: 64, tps: 0.00, reads: 0.00, writes: 36726.00, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[1045s] threads: 64, tps: 0.00, reads: 0.00, writes: 34973.04, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1046s] threads: 64, tps: 0.00, reads: 0.00, writes: 34736.97, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1047s] threads: 64, tps: 0.00, reads: 0.00, writes: 34482.04, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1048s] threads: 64, tps: 0.00, reads: 0.00, writes: 36277.98, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[1049s] threads: 64, tps: 0.00, reads: 0.00, writes: 40156.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1050s] threads: 64, tps: 0.00, reads: 0.00, writes: 37149.98, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1051s] threads: 64, tps: 0.00, reads: 0.00, writes: 34763.03, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1052s] threads: 64, tps: 0.00, reads: 0.00, writes: 34114.96, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1053s] threads: 64, tps: 0.00, reads: 0.00, writes: 28727.69, response time: 3.52ms (95%), errors: 0.00, reconnects:  0.00
[1054s] threads: 64, tps: 0.00, reads: 0.00, writes: 36657.42, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1055s] threads: 64, tps: 0.00, reads: 0.00, writes: 33850.41, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1056s] threads: 64, tps: 0.00, reads: 0.00, writes: 3084.05, response time: 21.86ms (95%), errors: 0.00, reconnects:  0.00
[1057s] threads: 64, tps: 0.00, reads: 0.00, writes: 17439.02, response time: 20.52ms (95%), errors: 0.00, reconnects:  0.00
[1058s] threads: 64, tps: 0.00, reads: 0.00, writes: 28920.02, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[1059s] threads: 64, tps: 0.00, reads: 0.00, writes: 32301.96, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[1060s] threads: 64, tps: 0.00, reads: 0.00, writes: 34110.09, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1061s] threads: 64, tps: 0.00, reads: 0.00, writes: 39038.94, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1062s] threads: 64, tps: 0.00, reads: 0.00, writes: 36307.97, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1063s] threads: 64, tps: 0.00, reads: 0.00, writes: 40733.99, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1064s] threads: 64, tps: 0.00, reads: 0.00, writes: 39724.98, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1065s] threads: 64, tps: 0.00, reads: 0.00, writes: 38732.95, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1066s] threads: 64, tps: 0.00, reads: 0.00, writes: 40064.05, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1067s] threads: 64, tps: 0.00, reads: 0.00, writes: 42868.01, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1068s] threads: 64, tps: 0.00, reads: 0.00, writes: 39369.04, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1069s] threads: 64, tps: 0.00, reads: 0.00, writes: 37619.01, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1070s] threads: 64, tps: 0.00, reads: 0.00, writes: 38475.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1071s] threads: 64, tps: 0.00, reads: 0.00, writes: 39118.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1072s] threads: 64, tps: 0.00, reads: 0.00, writes: 42409.03, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1073s] threads: 64, tps: 0.00, reads: 0.00, writes: 40329.01, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1074s] threads: 64, tps: 0.00, reads: 0.00, writes: 39371.93, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1075s] threads: 64, tps: 0.00, reads: 0.00, writes: 37628.04, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1076s] threads: 64, tps: 0.00, reads: 0.00, writes: 38158.95, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1077s] threads: 64, tps: 0.00, reads: 0.00, writes: 42240.96, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1078s] threads: 64, tps: 0.00, reads: 0.00, writes: 39352.06, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1079s] threads: 64, tps: 0.00, reads: 0.00, writes: 37817.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1080s] threads: 64, tps: 0.00, reads: 0.00, writes: 37734.82, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1081s] threads: 64, tps: 0.00, reads: 0.00, writes: 32383.27, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[1082s] threads: 64, tps: 0.00, reads: 0.00, writes: 37701.01, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1083s] threads: 64, tps: 0.00, reads: 0.00, writes: 36332.06, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1084s] threads: 64, tps: 0.00, reads: 0.00, writes: 37233.98, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1085s] threads: 64, tps: 0.00, reads: 0.00, writes: 34728.00, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1086s] threads: 64, tps: 0.00, reads: 0.00, writes: 35077.96, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1087s] threads: 64, tps: 0.00, reads: 0.00, writes: 36738.97, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1088s] threads: 64, tps: 0.00, reads: 0.00, writes: 39455.04, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1089s] threads: 64, tps: 0.00, reads: 0.00, writes: 38022.02, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[1090s] threads: 64, tps: 0.00, reads: 0.00, writes: 35571.98, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1091s] threads: 64, tps: 0.00, reads: 0.00, writes: 34938.05, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1092s] threads: 64, tps: 0.00, reads: 0.00, writes: 35480.95, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[1093s] threads: 64, tps: 0.00, reads: 0.00, writes: 38652.98, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1094s] threads: 64, tps: 0.00, reads: 0.00, writes: 36815.97, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1095s] threads: 64, tps: 0.00, reads: 0.00, writes: 4981.00, response time: 21.89ms (95%), errors: 0.00, reconnects:  0.00
[1096s] threads: 64, tps: 0.00, reads: 0.00, writes: 3113.99, response time: 21.61ms (95%), errors: 0.00, reconnects:  0.00
[1097s] threads: 64, tps: 0.00, reads: 0.00, writes: 26234.04, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[1098s] threads: 64, tps: 0.00, reads: 0.00, writes: 33000.70, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1099s] threads: 64, tps: 0.00, reads: 0.00, writes: 33223.30, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1100s] threads: 64, tps: 0.00, reads: 0.00, writes: 36199.99, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1101s] threads: 64, tps: 0.00, reads: 0.00, writes: 42373.06, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1102s] threads: 64, tps: 0.00, reads: 0.00, writes: 40521.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1103s] threads: 64, tps: 0.00, reads: 0.00, writes: 40026.97, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1104s] threads: 64, tps: 0.00, reads: 0.00, writes: 38675.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1105s] threads: 64, tps: 0.00, reads: 0.00, writes: 38979.07, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1106s] threads: 64, tps: 0.00, reads: 0.00, writes: 43029.97, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1107s] threads: 64, tps: 0.00, reads: 0.00, writes: 40292.98, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1108s] threads: 64, tps: 0.00, reads: 0.00, writes: 39180.02, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1109s] threads: 64, tps: 0.00, reads: 0.00, writes: 31501.98, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1110s] threads: 64, tps: 0.00, reads: 0.00, writes: 37815.96, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1111s] threads: 64, tps: 0.00, reads: 0.00, writes: 43588.01, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1112s] threads: 64, tps: 0.00, reads: 0.00, writes: 41477.04, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1113s] threads: 64, tps: 0.00, reads: 0.00, writes: 39188.99, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1114s] threads: 64, tps: 0.00, reads: 0.00, writes: 38219.90, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1115s] threads: 64, tps: 0.00, reads: 0.00, writes: 36791.94, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1116s] threads: 64, tps: 0.00, reads: 0.00, writes: 42306.15, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1117s] threads: 64, tps: 0.00, reads: 0.00, writes: 40835.02, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1118s] threads: 64, tps: 0.00, reads: 0.00, writes: 38903.96, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1119s] threads: 64, tps: 0.00, reads: 0.00, writes: 38714.05, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1120s] threads: 64, tps: 0.00, reads: 0.00, writes: 38202.87, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1121s] threads: 64, tps: 0.00, reads: 0.00, writes: 42098.09, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1122s] threads: 64, tps: 0.00, reads: 0.00, writes: 40217.07, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1123s] threads: 64, tps: 0.00, reads: 0.00, writes: 38740.03, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1124s] threads: 64, tps: 0.00, reads: 0.00, writes: 37625.92, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1125s] threads: 64, tps: 0.00, reads: 0.00, writes: 30127.88, response time: 3.57ms (95%), errors: 0.00, reconnects:  0.00
[1126s] threads: 64, tps: 0.00, reads: 0.00, writes: 31677.24, response time: 3.34ms (95%), errors: 0.00, reconnects:  0.00
[1127s] threads: 64, tps: 0.00, reads: 0.00, writes: 39854.97, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1128s] threads: 64, tps: 0.00, reads: 0.00, writes: 28869.01, response time: 3.66ms (95%), errors: 0.00, reconnects:  0.00
[1129s] threads: 64, tps: 0.00, reads: 0.00, writes: 29576.02, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[1130s] threads: 64, tps: 0.00, reads: 0.00, writes: 28765.98, response time: 3.68ms (95%), errors: 0.00, reconnects:  0.00
[1131s] threads: 64, tps: 0.00, reads: 0.00, writes: 33940.00, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[1132s] threads: 64, tps: 0.00, reads: 0.00, writes: 35865.04, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1133s] threads: 64, tps: 0.00, reads: 0.00, writes: 39866.01, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1134s] threads: 64, tps: 0.00, reads: 0.00, writes: 37015.91, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[1135s] threads: 64, tps: 0.00, reads: 0.00, writes: 35177.06, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[1136s] threads: 64, tps: 0.00, reads: 0.00, writes: 35651.98, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1137s] threads: 64, tps: 0.00, reads: 0.00, writes: 34255.03, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1138s] threads: 64, tps: 0.00, reads: 0.00, writes: 39224.94, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1139s] threads: 64, tps: 0.00, reads: 0.00, writes: 39827.03, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1140s] threads: 64, tps: 0.00, reads: 0.00, writes: 28303.84, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[1141s] threads: 64, tps: 0.00, reads: 0.00, writes: 3088.96, response time: 21.53ms (95%), errors: 0.00, reconnects:  0.00
[1142s] threads: 64, tps: 0.00, reads: 0.00, writes: 3085.97, response time: 21.59ms (95%), errors: 0.00, reconnects:  0.00
[1143s] threads: 64, tps: 0.00, reads: 0.00, writes: 6863.19, response time: 21.34ms (95%), errors: 0.00, reconnects:  0.00
[1144s] threads: 64, tps: 0.00, reads: 0.00, writes: 32068.01, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1145s] threads: 64, tps: 0.00, reads: 0.00, writes: 34207.99, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1146s] threads: 64, tps: 0.00, reads: 0.00, writes: 36430.98, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1147s] threads: 64, tps: 0.00, reads: 0.00, writes: 39514.03, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1148s] threads: 64, tps: 0.00, reads: 0.00, writes: 38563.00, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1149s] threads: 64, tps: 0.00, reads: 0.00, writes: 37769.04, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1150s] threads: 64, tps: 0.00, reads: 0.00, writes: 37449.91, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1151s] threads: 64, tps: 0.00, reads: 0.00, writes: 37473.06, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1152s] threads: 64, tps: 0.00, reads: 0.00, writes: 41532.92, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1153s] threads: 64, tps: 0.00, reads: 0.00, writes: 38474.04, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1154s] threads: 64, tps: 0.00, reads: 0.00, writes: 38011.07, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1155s] threads: 64, tps: 0.00, reads: 0.00, writes: 37762.93, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1156s] threads: 64, tps: 0.00, reads: 0.00, writes: 38203.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1157s] threads: 64, tps: 0.00, reads: 0.00, writes: 42975.05, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1158s] threads: 64, tps: 0.00, reads: 0.00, writes: 40161.95, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1159s] threads: 64, tps: 0.00, reads: 0.00, writes: 33995.06, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1160s] threads: 64, tps: 0.00, reads: 0.00, writes: 37663.64, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1161s] threads: 64, tps: 0.00, reads: 0.00, writes: 37412.36, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1162s] threads: 64, tps: 0.00, reads: 0.00, writes: 40446.97, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1163s] threads: 64, tps: 0.00, reads: 0.00, writes: 40309.00, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1164s] threads: 64, tps: 0.00, reads: 0.00, writes: 39485.04, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1165s] threads: 64, tps: 0.00, reads: 0.00, writes: 38354.68, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1166s] threads: 64, tps: 0.00, reads: 0.00, writes: 37030.27, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1167s] threads: 64, tps: 0.00, reads: 0.00, writes: 39807.91, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1168s] threads: 64, tps: 0.00, reads: 0.00, writes: 40537.11, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1169s] threads: 64, tps: 0.00, reads: 0.00, writes: 38569.14, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1170s] threads: 64, tps: 0.00, reads: 0.00, writes: 34203.73, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[1171s] threads: 64, tps: 0.00, reads: 0.00, writes: 30191.01, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[1172s] threads: 64, tps: 0.00, reads: 0.00, writes: 34019.96, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1173s] threads: 64, tps: 0.00, reads: 0.00, writes: 42003.07, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1174s] threads: 64, tps: 0.00, reads: 0.00, writes: 39462.96, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1175s] threads: 64, tps: 0.00, reads: 0.00, writes: 35989.98, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1176s] threads: 64, tps: 0.00, reads: 0.00, writes: 35234.98, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[1177s] threads: 64, tps: 0.00, reads: 0.00, writes: 35115.07, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1178s] threads: 64, tps: 0.00, reads: 0.00, writes: 40629.99, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1179s] threads: 64, tps: 0.00, reads: 0.00, writes: 39704.94, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1180s] threads: 64, tps: 0.00, reads: 0.00, writes: 37198.06, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1181s] threads: 64, tps: 0.00, reads: 0.00, writes: 36316.97, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1182s] threads: 64, tps: 0.00, reads: 0.00, writes: 29677.99, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[1183s] threads: 64, tps: 0.00, reads: 0.00, writes: 28387.01, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[1184s] threads: 64, tps: 0.00, reads: 0.00, writes: 39031.00, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[1185s] threads: 64, tps: 0.00, reads: 0.00, writes: 34433.99, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1186s] threads: 64, tps: 0.00, reads: 0.00, writes: 30841.03, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[1187s] threads: 64, tps: 0.00, reads: 0.00, writes: 33756.93, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1188s] threads: 64, tps: 0.00, reads: 0.00, writes: 35104.05, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1189s] threads: 64, tps: 0.00, reads: 0.00, writes: 37699.04, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1190s] threads: 64, tps: 0.00, reads: 0.00, writes: 42214.99, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1191s] threads: 64, tps: 0.00, reads: 0.00, writes: 40367.95, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1192s] threads: 64, tps: 0.00, reads: 0.00, writes: 39621.01, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1193s] threads: 64, tps: 0.00, reads: 0.00, writes: 38546.01, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1194s] threads: 64, tps: 0.00, reads: 0.00, writes: 38690.03, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1195s] threads: 64, tps: 0.00, reads: 0.00, writes: 42285.97, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1196s] threads: 64, tps: 0.00, reads: 0.00, writes: 39856.01, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1197s] threads: 64, tps: 0.00, reads: 0.00, writes: 39335.02, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1198s] threads: 64, tps: 0.00, reads: 0.00, writes: 37913.97, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1199s] threads: 64, tps: 0.00, reads: 0.00, writes: 36585.92, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1200s] threads: 64, tps: 0.00, reads: 0.00, writes: 42144.06, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1201s] threads: 64, tps: 0.00, reads: 0.00, writes: 40105.01, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1202s] threads: 64, tps: 0.00, reads: 0.00, writes: 38974.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1203s] threads: 64, tps: 0.00, reads: 0.00, writes: 36141.04, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1204s] threads: 64, tps: 0.00, reads: 0.00, writes: 37577.01, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1205s] threads: 64, tps: 0.00, reads: 0.00, writes: 37230.05, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1206s] threads: 64, tps: 0.00, reads: 0.00, writes: 39209.91, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1207s] threads: 64, tps: 0.00, reads: 0.00, writes: 38009.05, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1208s] threads: 64, tps: 0.00, reads: 0.00, writes: 36747.96, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1209s] threads: 64, tps: 0.00, reads: 0.00, writes: 34906.00, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1210s] threads: 64, tps: 0.00, reads: 0.00, writes: 36411.99, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1211s] threads: 64, tps: 0.00, reads: 0.00, writes: 39166.94, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1212s] threads: 64, tps: 0.00, reads: 0.00, writes: 36011.02, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1213s] threads: 64, tps: 0.00, reads: 0.00, writes: 35240.05, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[1214s] threads: 64, tps: 0.00, reads: 0.00, writes: 34531.96, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1215s] threads: 64, tps: 0.00, reads: 0.00, writes: 34353.00, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[1216s] threads: 64, tps: 0.00, reads: 0.00, writes: 40093.09, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1217s] threads: 64, tps: 0.00, reads: 0.00, writes: 39119.94, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1218s] threads: 64, tps: 0.00, reads: 0.00, writes: 36585.95, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1219s] threads: 64, tps: 0.00, reads: 0.00, writes: 35906.57, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[1220s] threads: 64, tps: 0.00, reads: 0.00, writes: 35303.48, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1221s] threads: 64, tps: 0.00, reads: 0.00, writes: 35781.90, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1222s] threads: 64, tps: 0.00, reads: 0.00, writes: 37639.18, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1223s] threads: 64, tps: 0.00, reads: 0.00, writes: 4447.00, response time: 21.73ms (95%), errors: 0.00, reconnects:  0.00
[1224s] threads: 64, tps: 0.00, reads: 0.00, writes: 17923.01, response time: 20.58ms (95%), errors: 0.00, reconnects:  0.00
[1225s] threads: 64, tps: 0.00, reads: 0.00, writes: 35061.99, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[1226s] threads: 64, tps: 0.00, reads: 0.00, writes: 33587.04, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1227s] threads: 64, tps: 0.00, reads: 0.00, writes: 35929.02, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1228s] threads: 64, tps: 0.00, reads: 0.00, writes: 39547.92, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1229s] threads: 64, tps: 0.00, reads: 0.00, writes: 41236.02, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1230s] threads: 64, tps: 0.00, reads: 0.00, writes: 40361.06, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1231s] threads: 64, tps: 0.00, reads: 0.00, writes: 39874.92, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1232s] threads: 64, tps: 0.00, reads: 0.00, writes: 38676.99, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1233s] threads: 64, tps: 0.00, reads: 0.00, writes: 41858.04, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1234s] threads: 64, tps: 0.00, reads: 0.00, writes: 40987.00, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1235s] threads: 64, tps: 0.00, reads: 0.00, writes: 38958.07, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1236s] threads: 64, tps: 0.00, reads: 0.00, writes: 37659.96, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1237s] threads: 64, tps: 0.00, reads: 0.00, writes: 35713.01, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1238s] threads: 64, tps: 0.00, reads: 0.00, writes: 37533.94, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1239s] threads: 64, tps: 0.00, reads: 0.00, writes: 41820.04, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1240s] threads: 64, tps: 0.00, reads: 0.00, writes: 38895.99, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1241s] threads: 64, tps: 0.00, reads: 0.00, writes: 38984.99, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1242s] threads: 64, tps: 0.00, reads: 0.00, writes: 37462.00, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1243s] threads: 64, tps: 0.00, reads: 0.00, writes: 38544.99, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1244s] threads: 64, tps: 0.00, reads: 0.00, writes: 41167.08, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1245s] threads: 64, tps: 0.00, reads: 0.00, writes: 38470.97, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1246s] threads: 64, tps: 0.00, reads: 0.00, writes: 39074.96, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1247s] threads: 64, tps: 0.00, reads: 0.00, writes: 36602.05, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1248s] threads: 64, tps: 0.00, reads: 0.00, writes: 36069.94, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1249s] threads: 64, tps: 0.00, reads: 0.00, writes: 40887.01, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1250s] threads: 64, tps: 0.00, reads: 0.00, writes: 40367.30, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1251s] threads: 64, tps: 0.00, reads: 0.00, writes: 37364.71, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1252s] threads: 64, tps: 0.00, reads: 0.00, writes: 30678.00, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[1253s] threads: 64, tps: 0.00, reads: 0.00, writes: 24374.96, response time: 3.63ms (95%), errors: 0.00, reconnects:  0.00
[1254s] threads: 64, tps: 0.00, reads: 0.00, writes: 35789.04, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1255s] threads: 64, tps: 0.00, reads: 0.00, writes: 40004.94, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1256s] threads: 64, tps: 0.00, reads: 0.00, writes: 38445.02, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1257s] threads: 64, tps: 0.00, reads: 0.00, writes: 35062.05, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1258s] threads: 64, tps: 0.00, reads: 0.00, writes: 34771.95, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1259s] threads: 64, tps: 0.00, reads: 0.00, writes: 34201.01, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1260s] threads: 64, tps: 0.00, reads: 0.00, writes: 39488.98, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1261s] threads: 64, tps: 0.00, reads: 0.00, writes: 39129.05, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1262s] threads: 64, tps: 0.00, reads: 0.00, writes: 34993.26, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1263s] threads: 64, tps: 0.00, reads: 0.00, writes: 3079.00, response time: 21.66ms (95%), errors: 0.00, reconnects:  0.00
[1264s] threads: 64, tps: 0.00, reads: 0.00, writes: 3112.07, response time: 21.41ms (95%), errors: 0.00, reconnects:  0.00
[1265s] threads: 64, tps: 0.00, reads: 0.00, writes: 3071.94, response time: 21.85ms (95%), errors: 0.00, reconnects:  0.00
[1266s] threads: 64, tps: 0.00, reads: 0.00, writes: 3091.05, response time: 21.51ms (95%), errors: 0.00, reconnects:  0.00
[1267s] threads: 64, tps: 0.00, reads: 0.00, writes: 22940.02, response time: 5.98ms (95%), errors: 0.00, reconnects:  0.00
[1268s] threads: 64, tps: 0.00, reads: 0.00, writes: 31536.02, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[1269s] threads: 64, tps: 0.00, reads: 0.00, writes: 34202.01, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1270s] threads: 64, tps: 0.00, reads: 0.00, writes: 41394.07, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1271s] threads: 64, tps: 0.00, reads: 0.00, writes: 40074.00, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1272s] threads: 64, tps: 0.00, reads: 0.00, writes: 39042.95, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1273s] threads: 64, tps: 0.00, reads: 0.00, writes: 38677.96, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1274s] threads: 64, tps: 0.00, reads: 0.00, writes: 37730.04, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1275s] threads: 64, tps: 0.00, reads: 0.00, writes: 43199.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1276s] threads: 64, tps: 0.00, reads: 0.00, writes: 40619.00, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1277s] threads: 64, tps: 0.00, reads: 0.00, writes: 39066.97, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1278s] threads: 64, tps: 0.00, reads: 0.00, writes: 38547.02, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1279s] threads: 64, tps: 0.00, reads: 0.00, writes: 36737.78, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1280s] threads: 64, tps: 0.00, reads: 0.00, writes: 44071.32, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1281s] threads: 64, tps: 0.00, reads: 0.00, writes: 40618.99, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1282s] threads: 64, tps: 0.00, reads: 0.00, writes: 38457.53, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1283s] threads: 64, tps: 0.00, reads: 0.00, writes: 38207.28, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1284s] threads: 64, tps: 0.00, reads: 0.00, writes: 37189.07, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1285s] threads: 64, tps: 0.00, reads: 0.00, writes: 40674.00, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1286s] threads: 64, tps: 0.00, reads: 0.00, writes: 39794.05, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1287s] threads: 64, tps: 0.00, reads: 0.00, writes: 38603.93, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1288s] threads: 64, tps: 0.00, reads: 0.00, writes: 38208.06, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1289s] threads: 64, tps: 0.00, reads: 0.00, writes: 36537.01, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1290s] threads: 64, tps: 0.00, reads: 0.00, writes: 35259.92, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1291s] threads: 64, tps: 0.00, reads: 0.00, writes: 34092.02, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[1292s] threads: 64, tps: 0.00, reads: 0.00, writes: 30054.97, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[1293s] threads: 64, tps: 0.00, reads: 0.00, writes: 29310.02, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[1294s] threads: 64, tps: 0.00, reads: 0.00, writes: 28197.01, response time: 3.58ms (95%), errors: 0.00, reconnects:  0.00
[1295s] threads: 64, tps: 0.00, reads: 0.00, writes: 32587.05, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[1296s] threads: 64, tps: 0.00, reads: 0.00, writes: 37045.95, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1297s] threads: 64, tps: 0.00, reads: 0.00, writes: 40745.00, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1298s] threads: 64, tps: 0.00, reads: 0.00, writes: 36042.02, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1299s] threads: 64, tps: 0.00, reads: 0.00, writes: 34656.98, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1300s] threads: 64, tps: 0.00, reads: 0.00, writes: 35146.02, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[1301s] threads: 64, tps: 0.00, reads: 0.00, writes: 33465.99, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1302s] threads: 64, tps: 0.00, reads: 0.00, writes: 39797.04, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1303s] threads: 64, tps: 0.00, reads: 0.00, writes: 39681.80, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1304s] threads: 64, tps: 0.00, reads: 0.00, writes: 29291.98, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[1305s] threads: 64, tps: 0.00, reads: 0.00, writes: 32127.09, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[1306s] threads: 64, tps: 0.00, reads: 0.00, writes: 29326.99, response time: 3.32ms (95%), errors: 0.00, reconnects:  0.00
[1307s] threads: 64, tps: 0.00, reads: 0.00, writes: 30080.49, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[1308s] threads: 64, tps: 0.00, reads: 0.00, writes: 37746.78, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1309s] threads: 64, tps: 0.00, reads: 0.00, writes: 34089.57, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1310s] threads: 64, tps: 0.00, reads: 0.00, writes: 33540.03, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1311s] threads: 64, tps: 0.00, reads: 0.00, writes: 35094.01, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1312s] threads: 64, tps: 0.00, reads: 0.00, writes: 37134.00, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1313s] threads: 64, tps: 0.00, reads: 0.00, writes: 38803.00, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1314s] threads: 64, tps: 0.00, reads: 0.00, writes: 42489.97, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1315s] threads: 64, tps: 0.00, reads: 0.00, writes: 38818.05, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1316s] threads: 64, tps: 0.00, reads: 0.00, writes: 39328.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1317s] threads: 64, tps: 0.00, reads: 0.00, writes: 38375.06, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1318s] threads: 64, tps: 0.00, reads: 0.00, writes: 39183.93, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1319s] threads: 64, tps: 0.00, reads: 0.00, writes: 42896.01, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1320s] threads: 64, tps: 0.00, reads: 0.00, writes: 39880.94, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1321s] threads: 64, tps: 0.00, reads: 0.00, writes: 38880.09, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1322s] threads: 64, tps: 0.00, reads: 0.00, writes: 38275.01, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1323s] threads: 64, tps: 0.00, reads: 0.00, writes: 37888.93, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1324s] threads: 64, tps: 0.00, reads: 0.00, writes: 42828.00, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1325s] threads: 64, tps: 0.00, reads: 0.00, writes: 40516.09, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1326s] threads: 64, tps: 0.00, reads: 0.00, writes: 38278.21, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1327s] threads: 64, tps: 0.00, reads: 0.00, writes: 37319.70, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1328s] threads: 64, tps: 0.00, reads: 0.00, writes: 34054.98, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1329s] threads: 64, tps: 0.00, reads: 0.00, writes: 38540.02, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[1330s] threads: 64, tps: 0.00, reads: 0.00, writes: 32141.01, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[1331s] threads: 64, tps: 0.00, reads: 0.00, writes: 30026.03, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[1332s] threads: 64, tps: 0.00, reads: 0.00, writes: 28973.88, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[1333s] threads: 64, tps: 0.00, reads: 0.00, writes: 32841.73, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1334s] threads: 64, tps: 0.00, reads: 0.00, writes: 34277.43, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1335s] threads: 64, tps: 0.00, reads: 0.00, writes: 37307.92, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1336s] threads: 64, tps: 0.00, reads: 0.00, writes: 38833.04, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1337s] threads: 64, tps: 0.00, reads: 0.00, writes: 35733.33, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[1338s] threads: 64, tps: 0.00, reads: 0.00, writes: 34059.18, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1339s] threads: 64, tps: 0.00, reads: 0.00, writes: 34367.79, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1340s] threads: 64, tps: 0.00, reads: 0.00, writes: 36746.68, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1341s] threads: 64, tps: 0.00, reads: 0.00, writes: 40772.26, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1342s] threads: 64, tps: 0.00, reads: 0.00, writes: 38119.99, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1343s] threads: 64, tps: 0.00, reads: 0.00, writes: 31269.00, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[1344s] threads: 64, tps: 0.00, reads: 0.00, writes: 29745.01, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[1345s] threads: 64, tps: 0.00, reads: 0.00, writes: 28484.91, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[1346s] threads: 64, tps: 0.00, reads: 0.00, writes: 33096.02, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1347s] threads: 64, tps: 0.00, reads: 0.00, writes: 38523.05, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[1348s] threads: 64, tps: 0.00, reads: 0.00, writes: 30097.00, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[1349s] threads: 64, tps: 0.00, reads: 0.00, writes: 30617.99, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[1350s] threads: 64, tps: 0.00, reads: 0.00, writes: 29895.04, response time: 3.27ms (95%), errors: 0.00, reconnects:  0.00
[1351s] threads: 64, tps: 0.00, reads: 0.00, writes: 32246.00, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[1352s] threads: 64, tps: 0.00, reads: 0.00, writes: 33943.97, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1353s] threads: 64, tps: 0.00, reads: 0.00, writes: 35480.73, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1354s] threads: 64, tps: 0.00, reads: 0.00, writes: 36076.30, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1355s] threads: 64, tps: 0.00, reads: 0.00, writes: 36178.98, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[1356s] threads: 64, tps: 0.00, reads: 0.00, writes: 37884.08, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1357s] threads: 64, tps: 0.00, reads: 0.00, writes: 37320.93, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1358s] threads: 64, tps: 0.00, reads: 0.00, writes: 40435.04, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1359s] threads: 64, tps: 0.00, reads: 0.00, writes: 39805.97, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1360s] threads: 64, tps: 0.00, reads: 0.00, writes: 39715.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1361s] threads: 64, tps: 0.00, reads: 0.00, writes: 38098.98, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1362s] threads: 64, tps: 0.00, reads: 0.00, writes: 37135.97, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1363s] threads: 64, tps: 0.00, reads: 0.00, writes: 40853.00, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1364s] threads: 64, tps: 0.00, reads: 0.00, writes: 41026.98, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1365s] threads: 64, tps: 0.00, reads: 0.00, writes: 39755.14, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1366s] threads: 64, tps: 0.00, reads: 0.00, writes: 38732.67, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1367s] threads: 64, tps: 0.00, reads: 0.00, writes: 37611.03, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1368s] threads: 64, tps: 0.00, reads: 0.00, writes: 39307.93, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1369s] threads: 64, tps: 0.00, reads: 0.00, writes: 39433.05, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1370s] threads: 64, tps: 0.00, reads: 0.00, writes: 34881.04, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1371s] threads: 64, tps: 0.00, reads: 0.00, writes: 30807.97, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[1372s] threads: 64, tps: 0.00, reads: 0.00, writes: 33528.99, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1373s] threads: 64, tps: 0.00, reads: 0.00, writes: 34748.02, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1374s] threads: 64, tps: 0.00, reads: 0.00, writes: 40096.95, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1375s] threads: 64, tps: 0.00, reads: 0.00, writes: 39432.09, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1376s] threads: 64, tps: 0.00, reads: 0.00, writes: 35790.92, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1377s] threads: 64, tps: 0.00, reads: 0.00, writes: 34437.91, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1378s] threads: 64, tps: 0.00, reads: 0.00, writes: 34304.12, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1379s] threads: 64, tps: 0.00, reads: 0.00, writes: 36071.96, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1380s] threads: 64, tps: 0.00, reads: 0.00, writes: 39721.03, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1381s] threads: 64, tps: 0.00, reads: 0.00, writes: 38778.94, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1382s] threads: 64, tps: 0.00, reads: 0.00, writes: 35261.09, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1383s] threads: 64, tps: 0.00, reads: 0.00, writes: 28669.96, response time: 3.58ms (95%), errors: 0.00, reconnects:  0.00
[1384s] threads: 64, tps: 0.00, reads: 0.00, writes: 28881.01, response time: 3.53ms (95%), errors: 0.00, reconnects:  0.00
[1385s] threads: 64, tps: 0.00, reads: 0.00, writes: 33819.00, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1386s] threads: 64, tps: 0.00, reads: 0.00, writes: 39049.02, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1387s] threads: 64, tps: 0.00, reads: 0.00, writes: 38966.96, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1388s] threads: 64, tps: 0.00, reads: 0.00, writes: 38334.37, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1389s] threads: 64, tps: 0.00, reads: 0.00, writes: 38775.68, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1390s] threads: 64, tps: 0.00, reads: 0.00, writes: 39805.98, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1391s] threads: 64, tps: 0.00, reads: 0.00, writes: 42480.82, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1392s] threads: 64, tps: 0.00, reads: 0.00, writes: 40427.19, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1393s] threads: 64, tps: 0.00, reads: 0.00, writes: 39478.02, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1394s] threads: 64, tps: 0.00, reads: 0.00, writes: 38588.02, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1395s] threads: 64, tps: 0.00, reads: 0.00, writes: 38954.54, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1396s] threads: 64, tps: 0.00, reads: 0.00, writes: 42076.45, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1397s] threads: 64, tps: 0.00, reads: 0.00, writes: 40006.91, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1398s] threads: 64, tps: 0.00, reads: 0.00, writes: 38226.09, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1399s] threads: 64, tps: 0.00, reads: 0.00, writes: 36999.97, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1400s] threads: 64, tps: 0.00, reads: 0.00, writes: 28255.97, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1401s] threads: 64, tps: 0.00, reads: 0.00, writes: 42286.00, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1402s] threads: 64, tps: 0.00, reads: 0.00, writes: 39851.03, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1403s] threads: 64, tps: 0.00, reads: 0.00, writes: 38910.99, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1404s] threads: 64, tps: 0.00, reads: 0.00, writes: 37932.07, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1405s] threads: 64, tps: 0.00, reads: 0.00, writes: 32837.99, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[1406s] threads: 64, tps: 0.00, reads: 0.00, writes: 32136.96, response time: 3.49ms (95%), errors: 0.00, reconnects:  0.00
[1407s] threads: 64, tps: 0.00, reads: 0.00, writes: 37192.94, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1408s] threads: 64, tps: 0.00, reads: 0.00, writes: 29749.04, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[1409s] threads: 64, tps: 0.00, reads: 0.00, writes: 28298.00, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[1410s] threads: 64, tps: 0.00, reads: 0.00, writes: 29955.04, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[1411s] threads: 64, tps: 0.00, reads: 0.00, writes: 32367.98, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1412s] threads: 64, tps: 0.00, reads: 0.00, writes: 35412.97, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1413s] threads: 64, tps: 0.00, reads: 0.00, writes: 40066.00, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1414s] threads: 64, tps: 0.00, reads: 0.00, writes: 37928.00, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1415s] threads: 64, tps: 0.00, reads: 0.00, writes: 34993.03, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1416s] threads: 64, tps: 0.00, reads: 0.00, writes: 34227.99, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1417s] threads: 64, tps: 0.00, reads: 0.00, writes: 34463.04, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1418s] threads: 64, tps: 0.00, reads: 0.00, writes: 39799.98, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1419s] threads: 64, tps: 0.00, reads: 0.00, writes: 39419.00, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1420s] threads: 64, tps: 0.00, reads: 0.00, writes: 36140.00, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1421s] threads: 64, tps: 0.00, reads: 0.00, writes: 30670.98, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[1422s] threads: 64, tps: 0.00, reads: 0.00, writes: 29629.96, response time: 3.32ms (95%), errors: 0.00, reconnects:  0.00
[1423s] threads: 64, tps: 0.00, reads: 0.00, writes: 29075.05, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[1424s] threads: 64, tps: 0.00, reads: 0.00, writes: 37800.00, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1425s] threads: 64, tps: 0.00, reads: 0.00, writes: 35689.03, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1426s] threads: 64, tps: 0.00, reads: 0.00, writes: 34770.96, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1427s] threads: 64, tps: 0.00, reads: 0.00, writes: 35602.00, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[1428s] threads: 64, tps: 0.00, reads: 0.00, writes: 38130.96, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1429s] threads: 64, tps: 0.00, reads: 0.00, writes: 40126.09, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1430s] threads: 64, tps: 0.00, reads: 0.00, writes: 41954.94, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1431s] threads: 64, tps: 0.00, reads: 0.00, writes: 40217.86, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1432s] threads: 64, tps: 0.00, reads: 0.00, writes: 39610.15, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1433s] threads: 64, tps: 0.00, reads: 0.00, writes: 39521.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1434s] threads: 64, tps: 0.00, reads: 0.00, writes: 41250.00, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1435s] threads: 64, tps: 0.00, reads: 0.00, writes: 40898.37, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1436s] threads: 64, tps: 0.00, reads: 0.00, writes: 40728.59, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1437s] threads: 64, tps: 0.00, reads: 0.00, writes: 39058.03, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1438s] threads: 64, tps: 0.00, reads: 0.00, writes: 37536.95, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1439s] threads: 64, tps: 0.00, reads: 0.00, writes: 37682.01, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1440s] threads: 64, tps: 0.00, reads: 0.00, writes: 41432.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1441s] threads: 64, tps: 0.00, reads: 0.00, writes: 40587.01, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1442s] threads: 64, tps: 0.00, reads: 0.00, writes: 39423.03, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1443s] threads: 64, tps: 0.00, reads: 0.00, writes: 36759.94, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1444s] threads: 64, tps: 0.00, reads: 0.00, writes: 38622.69, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1445s] threads: 64, tps: 0.00, reads: 0.00, writes: 41228.27, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1446s] threads: 64, tps: 0.00, reads: 0.00, writes: 39271.96, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1447s] threads: 64, tps: 0.00, reads: 0.00, writes: 31193.03, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[1448s] threads: 64, tps: 0.00, reads: 0.00, writes: 37169.05, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1449s] threads: 64, tps: 0.00, reads: 0.00, writes: 35563.98, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1450s] threads: 64, tps: 0.00, reads: 0.00, writes: 39222.02, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1451s] threads: 64, tps: 0.00, reads: 0.00, writes: 37642.99, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1452s] threads: 64, tps: 0.00, reads: 0.00, writes: 35075.96, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1453s] threads: 64, tps: 0.00, reads: 0.00, writes: 34654.00, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1454s] threads: 64, tps: 0.00, reads: 0.00, writes: 33374.04, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1455s] threads: 64, tps: 0.00, reads: 0.00, writes: 34556.98, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1456s] threads: 64, tps: 0.00, reads: 0.00, writes: 40408.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1457s] threads: 64, tps: 0.00, reads: 0.00, writes: 38158.96, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1458s] threads: 64, tps: 0.00, reads: 0.00, writes: 34736.01, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1459s] threads: 64, tps: 0.00, reads: 0.00, writes: 34791.00, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1460s] threads: 64, tps: 0.00, reads: 0.00, writes: 30434.00, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[1461s] threads: 64, tps: 0.00, reads: 0.00, writes: 34280.01, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1462s] threads: 64, tps: 0.00, reads: 0.00, writes: 36959.94, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[1463s] threads: 64, tps: 0.00, reads: 0.00, writes: 5624.01, response time: 21.56ms (95%), errors: 0.00, reconnects:  0.00
[1464s] threads: 64, tps: 0.00, reads: 0.00, writes: 7080.00, response time: 21.40ms (95%), errors: 0.00, reconnects:  0.00
[1465s] threads: 64, tps: 0.00, reads: 0.00, writes: 29688.00, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[1466s] threads: 64, tps: 0.00, reads: 0.00, writes: 35276.98, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1467s] threads: 64, tps: 0.00, reads: 0.00, writes: 37480.00, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1468s] threads: 64, tps: 0.00, reads: 0.00, writes: 39148.01, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1469s] threads: 64, tps: 0.00, reads: 0.00, writes: 42046.07, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1470s] threads: 64, tps: 0.00, reads: 0.00, writes: 40257.95, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1471s] threads: 64, tps: 0.00, reads: 0.00, writes: 39199.99, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1472s] threads: 64, tps: 0.00, reads: 0.00, writes: 38090.01, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1473s] threads: 64, tps: 0.00, reads: 0.00, writes: 38711.97, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1474s] threads: 64, tps: 0.00, reads: 0.00, writes: 42080.06, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1475s] threads: 64, tps: 0.00, reads: 0.00, writes: 40511.97, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1476s] threads: 64, tps: 0.00, reads: 0.00, writes: 38414.01, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1477s] threads: 64, tps: 0.00, reads: 0.00, writes: 38213.98, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1478s] threads: 64, tps: 0.00, reads: 0.00, writes: 38026.78, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1479s] threads: 64, tps: 0.00, reads: 0.00, writes: 42480.26, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1480s] threads: 64, tps: 0.00, reads: 0.00, writes: 39904.99, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1481s] threads: 64, tps: 0.00, reads: 0.00, writes: 37065.00, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1482s] threads: 64, tps: 0.00, reads: 0.00, writes: 38144.97, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1483s] threads: 64, tps: 0.00, reads: 0.00, writes: 37901.33, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1484s] threads: 64, tps: 0.00, reads: 0.00, writes: 41943.80, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1485s] threads: 64, tps: 0.00, reads: 0.00, writes: 39747.00, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1486s] threads: 64, tps: 0.00, reads: 0.00, writes: 38063.97, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1487s] threads: 64, tps: 0.00, reads: 0.00, writes: 37025.03, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1488s] threads: 64, tps: 0.00, reads: 0.00, writes: 34397.97, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1489s] threads: 64, tps: 0.00, reads: 0.00, writes: 35157.00, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1490s] threads: 64, tps: 0.00, reads: 0.00, writes: 37964.98, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1491s] threads: 64, tps: 0.00, reads: 0.00, writes: 35263.00, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[1492s] threads: 64, tps: 0.00, reads: 0.00, writes: 35210.06, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1493s] threads: 64, tps: 0.00, reads: 0.00, writes: 35230.91, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[1494s] threads: 64, tps: 0.00, reads: 0.00, writes: 34441.03, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[1495s] threads: 64, tps: 0.00, reads: 0.00, writes: 40774.07, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1496s] threads: 64, tps: 0.00, reads: 0.00, writes: 34098.03, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1497s] threads: 64, tps: 0.00, reads: 0.00, writes: 35838.94, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1498s] threads: 64, tps: 0.00, reads: 0.00, writes: 34968.05, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1499s] threads: 64, tps: 0.00, reads: 0.00, writes: 31365.96, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[1500s] threads: 64, tps: 0.00, reads: 0.00, writes: 33407.03, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[1501s] threads: 64, tps: 0.00, reads: 0.00, writes: 38546.97, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1502s] threads: 64, tps: 0.00, reads: 0.00, writes: 18733.99, response time: 20.52ms (95%), errors: 0.00, reconnects:  0.00
[1503s] threads: 64, tps: 0.00, reads: 0.00, writes: 33121.94, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1504s] threads: 64, tps: 0.00, reads: 0.00, writes: 34665.07, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1505s] threads: 64, tps: 0.00, reads: 0.00, writes: 35768.99, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1506s] threads: 64, tps: 0.00, reads: 0.00, writes: 37746.05, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1507s] threads: 64, tps: 0.00, reads: 0.00, writes: 40850.95, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1508s] threads: 64, tps: 0.00, reads: 0.00, writes: 38390.98, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1509s] threads: 64, tps: 0.00, reads: 0.00, writes: 37464.02, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1510s] threads: 64, tps: 0.00, reads: 0.00, writes: 37215.02, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1511s] threads: 64, tps: 0.00, reads: 0.00, writes: 36547.62, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1512s] threads: 64, tps: 0.00, reads: 0.00, writes: 42525.41, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1513s] threads: 64, tps: 0.00, reads: 0.00, writes: 38996.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1514s] threads: 64, tps: 0.00, reads: 0.00, writes: 39054.98, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1515s] threads: 64, tps: 0.00, reads: 0.00, writes: 37390.99, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1516s] threads: 64, tps: 0.00, reads: 0.00, writes: 36962.00, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1517s] threads: 64, tps: 0.00, reads: 0.00, writes: 42080.52, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1518s] threads: 64, tps: 0.00, reads: 0.00, writes: 41002.35, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1519s] threads: 64, tps: 0.00, reads: 0.00, writes: 39472.65, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1520s] threads: 64, tps: 0.00, reads: 0.00, writes: 38546.23, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1521s] threads: 64, tps: 0.00, reads: 0.00, writes: 37574.01, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1522s] threads: 64, tps: 0.00, reads: 0.00, writes: 41285.99, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1523s] threads: 64, tps: 0.00, reads: 0.00, writes: 40356.96, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1524s] threads: 64, tps: 0.00, reads: 0.00, writes: 38672.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1525s] threads: 64, tps: 0.00, reads: 0.00, writes: 37247.78, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1526s] threads: 64, tps: 0.00, reads: 0.00, writes: 35496.45, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1527s] threads: 64, tps: 0.00, reads: 0.00, writes: 40780.77, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1528s] threads: 64, tps: 0.00, reads: 0.00, writes: 39289.05, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1529s] threads: 64, tps: 0.00, reads: 0.00, writes: 37534.04, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1530s] threads: 64, tps: 0.00, reads: 0.00, writes: 33688.03, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[1531s] threads: 64, tps: 0.00, reads: 0.00, writes: 31001.88, response time: 3.42ms (95%), errors: 0.00, reconnects:  0.00
[1532s] threads: 64, tps: 0.00, reads: 0.00, writes: 32824.10, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1533s] threads: 64, tps: 0.00, reads: 0.00, writes: 40821.00, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1534s] threads: 64, tps: 0.00, reads: 0.00, writes: 38398.96, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1535s] threads: 64, tps: 0.00, reads: 0.00, writes: 34901.03, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[1536s] threads: 64, tps: 0.00, reads: 0.00, writes: 34384.96, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1537s] threads: 64, tps: 0.00, reads: 0.00, writes: 34461.00, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1538s] threads: 64, tps: 0.00, reads: 0.00, writes: 38214.02, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[1539s] threads: 64, tps: 0.00, reads: 0.00, writes: 39124.99, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1540s] threads: 64, tps: 0.00, reads: 0.00, writes: 37502.95, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1541s] threads: 64, tps: 0.00, reads: 0.00, writes: 13868.72, response time: 20.88ms (95%), errors: 0.00, reconnects:  0.00
[1542s] threads: 64, tps: 0.00, reads: 0.00, writes: 3114.07, response time: 21.63ms (95%), errors: 0.00, reconnects:  0.00
[1543s] threads: 64, tps: 0.00, reads: 0.00, writes: 3087.00, response time: 21.68ms (95%), errors: 0.00, reconnects:  0.00
[1544s] threads: 64, tps: 0.00, reads: 0.00, writes: 3095.00, response time: 21.65ms (95%), errors: 0.00, reconnects:  0.00
[1545s] threads: 64, tps: 0.00, reads: 0.00, writes: 3072.01, response time: 21.92ms (95%), errors: 0.00, reconnects:  0.00
[1546s] threads: 64, tps: 0.00, reads: 0.00, writes: 26402.99, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[1547s] threads: 64, tps: 0.00, reads: 0.00, writes: 33757.99, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[1548s] threads: 64, tps: 0.00, reads: 0.00, writes: 28154.98, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[1549s] threads: 64, tps: 0.00, reads: 0.00, writes: 38653.03, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1550s] threads: 64, tps: 0.00, reads: 0.00, writes: 36828.04, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[1551s] threads: 64, tps: 0.00, reads: 0.00, writes: 37957.94, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1552s] threads: 64, tps: 0.00, reads: 0.00, writes: 38403.99, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1553s] threads: 64, tps: 0.00, reads: 0.00, writes: 38033.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1554s] threads: 64, tps: 0.00, reads: 0.00, writes: 42844.01, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1555s] threads: 64, tps: 0.00, reads: 0.00, writes: 40179.08, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1556s] threads: 64, tps: 0.00, reads: 0.00, writes: 38117.92, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1557s] threads: 64, tps: 0.00, reads: 0.00, writes: 38578.07, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1558s] threads: 64, tps: 0.00, reads: 0.00, writes: 37462.01, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1559s] threads: 64, tps: 0.00, reads: 0.00, writes: 42925.95, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1560s] threads: 64, tps: 0.00, reads: 0.00, writes: 40726.06, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1561s] threads: 64, tps: 0.00, reads: 0.00, writes: 38253.89, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1562s] threads: 64, tps: 0.00, reads: 0.00, writes: 37401.01, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1563s] threads: 64, tps: 0.00, reads: 0.00, writes: 37063.06, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1564s] threads: 64, tps: 0.00, reads: 0.00, writes: 42274.91, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1565s] threads: 64, tps: 0.00, reads: 0.00, writes: 40582.06, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1566s] threads: 64, tps: 0.00, reads: 0.00, writes: 39477.93, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1567s] threads: 64, tps: 0.00, reads: 0.00, writes: 38430.01, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1568s] threads: 64, tps: 0.00, reads: 0.00, writes: 35593.08, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1569s] threads: 64, tps: 0.00, reads: 0.00, writes: 34642.99, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[1570s] threads: 64, tps: 0.00, reads: 0.00, writes: 36837.95, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1571s] threads: 64, tps: 0.00, reads: 0.00, writes: 31435.99, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[1572s] threads: 64, tps: 0.00, reads: 0.00, writes: 35379.04, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1573s] threads: 64, tps: 0.00, reads: 0.00, writes: 35232.01, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1574s] threads: 64, tps: 0.00, reads: 0.00, writes: 34227.00, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1575s] threads: 64, tps: 0.00, reads: 0.00, writes: 40164.96, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1576s] threads: 64, tps: 0.00, reads: 0.00, writes: 38747.09, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1577s] threads: 64, tps: 0.00, reads: 0.00, writes: 35807.98, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1578s] threads: 64, tps: 0.00, reads: 0.00, writes: 34910.01, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1579s] threads: 64, tps: 0.00, reads: 0.00, writes: 34460.96, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1580s] threads: 64, tps: 0.00, reads: 0.00, writes: 36883.99, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[1581s] threads: 64, tps: 0.00, reads: 0.00, writes: 39655.01, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1582s] threads: 64, tps: 0.00, reads: 0.00, writes: 24895.99, response time: 4.89ms (95%), errors: 0.00, reconnects:  0.00
[1583s] threads: 64, tps: 0.00, reads: 0.00, writes: 28355.98, response time: 3.65ms (95%), errors: 0.00, reconnects:  0.00
[1584s] threads: 64, tps: 0.00, reads: 0.00, writes: 28711.02, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[1585s] threads: 64, tps: 0.00, reads: 0.00, writes: 31016.00, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1586s] threads: 64, tps: 0.00, reads: 0.00, writes: 30678.99, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[1587s] threads: 64, tps: 0.00, reads: 0.00, writes: 38700.00, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1588s] threads: 64, tps: 0.00, reads: 0.00, writes: 34089.92, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1589s] threads: 64, tps: 0.00, reads: 0.00, writes: 36313.13, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1590s] threads: 64, tps: 0.00, reads: 0.00, writes: 36132.83, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1591s] threads: 64, tps: 0.00, reads: 0.00, writes: 36897.15, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1592s] threads: 64, tps: 0.00, reads: 0.00, writes: 39583.01, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1593s] threads: 64, tps: 0.00, reads: 0.00, writes: 40086.99, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1594s] threads: 64, tps: 0.00, reads: 0.00, writes: 39138.01, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1595s] threads: 64, tps: 0.00, reads: 0.00, writes: 32293.94, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1596s] threads: 64, tps: 0.00, reads: 0.00, writes: 38174.08, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1597s] threads: 64, tps: 0.00, reads: 0.00, writes: 39505.02, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1598s] threads: 64, tps: 0.00, reads: 0.00, writes: 42502.95, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1599s] threads: 64, tps: 0.00, reads: 0.00, writes: 38915.98, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1600s] threads: 64, tps: 0.00, reads: 0.00, writes: 38982.94, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1601s] threads: 64, tps: 0.00, reads: 0.00, writes: 37826.12, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1602s] threads: 64, tps: 0.00, reads: 0.00, writes: 37542.96, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1603s] threads: 64, tps: 0.00, reads: 0.00, writes: 41379.99, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1604s] threads: 64, tps: 0.00, reads: 0.00, writes: 39427.95, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1605s] threads: 64, tps: 0.00, reads: 0.00, writes: 37682.10, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1606s] threads: 64, tps: 0.00, reads: 0.00, writes: 36680.95, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1607s] threads: 64, tps: 0.00, reads: 0.00, writes: 34822.05, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1608s] threads: 64, tps: 0.00, reads: 0.00, writes: 41884.93, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1609s] threads: 64, tps: 0.00, reads: 0.00, writes: 40619.03, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1610s] threads: 64, tps: 0.00, reads: 0.00, writes: 38312.00, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1611s] threads: 64, tps: 0.00, reads: 0.00, writes: 37721.91, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1612s] threads: 64, tps: 0.00, reads: 0.00, writes: 36452.06, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1613s] threads: 64, tps: 0.00, reads: 0.00, writes: 39842.04, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1614s] threads: 64, tps: 0.00, reads: 0.00, writes: 38454.98, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1615s] threads: 64, tps: 0.00, reads: 0.00, writes: 33760.83, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1616s] threads: 64, tps: 0.00, reads: 0.00, writes: 28643.12, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[1617s] threads: 64, tps: 0.00, reads: 0.00, writes: 29224.99, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[1618s] threads: 64, tps: 0.00, reads: 0.00, writes: 32548.02, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1619s] threads: 64, tps: 0.00, reads: 0.00, writes: 38708.98, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1620s] threads: 64, tps: 0.00, reads: 0.00, writes: 39320.99, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1621s] threads: 64, tps: 0.00, reads: 0.00, writes: 36411.02, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[1622s] threads: 64, tps: 0.00, reads: 0.00, writes: 34843.03, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1623s] threads: 64, tps: 0.00, reads: 0.00, writes: 34892.00, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[1624s] threads: 64, tps: 0.00, reads: 0.00, writes: 36018.98, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1625s] threads: 64, tps: 0.00, reads: 0.00, writes: 39944.97, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1626s] threads: 64, tps: 0.00, reads: 0.00, writes: 36867.96, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[1627s] threads: 64, tps: 0.00, reads: 0.00, writes: 17756.55, response time: 20.57ms (95%), errors: 0.00, reconnects:  0.00
[1628s] threads: 64, tps: 0.00, reads: 0.00, writes: 3100.01, response time: 21.56ms (95%), errors: 0.00, reconnects:  0.00
[1629s] threads: 64, tps: 0.00, reads: 0.00, writes: 3106.07, response time: 21.60ms (95%), errors: 0.00, reconnects:  0.00
[1630s] threads: 64, tps: 0.00, reads: 0.00, writes: 3093.99, response time: 21.46ms (95%), errors: 0.00, reconnects:  0.00
[1631s] threads: 64, tps: 0.00, reads: 0.00, writes: 3095.00, response time: 21.57ms (95%), errors: 0.00, reconnects:  0.00
[1632s] threads: 64, tps: 0.00, reads: 0.00, writes: 3202.01, response time: 21.52ms (95%), errors: 0.00, reconnects:  0.00
[1633s] threads: 64, tps: 0.00, reads: 0.00, writes: 29681.98, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[1634s] threads: 64, tps: 0.00, reads: 0.00, writes: 31477.93, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[1635s] threads: 64, tps: 0.00, reads: 0.00, writes: 34361.07, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1636s] threads: 64, tps: 0.00, reads: 0.00, writes: 38001.01, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1637s] threads: 64, tps: 0.00, reads: 0.00, writes: 34947.96, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1638s] threads: 64, tps: 0.00, reads: 0.00, writes: 35353.99, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1639s] threads: 64, tps: 0.00, reads: 0.00, writes: 35749.01, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1640s] threads: 64, tps: 0.00, reads: 0.00, writes: 35461.02, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1641s] threads: 64, tps: 0.00, reads: 0.00, writes: 40965.98, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1642s] threads: 64, tps: 0.00, reads: 0.00, writes: 38952.98, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1643s] threads: 64, tps: 0.00, reads: 0.00, writes: 38002.04, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1644s] threads: 64, tps: 0.00, reads: 0.00, writes: 37497.92, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1645s] threads: 64, tps: 0.00, reads: 0.00, writes: 36992.91, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1646s] threads: 64, tps: 0.00, reads: 0.00, writes: 40723.17, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1647s] threads: 64, tps: 0.00, reads: 0.00, writes: 39635.98, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1648s] threads: 64, tps: 0.00, reads: 0.00, writes: 34150.88, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1649s] threads: 64, tps: 0.00, reads: 0.00, writes: 37641.04, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1650s] threads: 64, tps: 0.00, reads: 0.00, writes: 38239.99, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1651s] threads: 64, tps: 0.00, reads: 0.00, writes: 37423.95, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1652s] threads: 64, tps: 0.00, reads: 0.00, writes: 42234.07, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1653s] threads: 64, tps: 0.00, reads: 0.00, writes: 39939.98, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1654s] threads: 64, tps: 0.00, reads: 0.00, writes: 38523.00, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1655s] threads: 64, tps: 0.00, reads: 0.00, writes: 37190.02, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1656s] threads: 64, tps: 0.00, reads: 0.00, writes: 36457.63, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1657s] threads: 64, tps: 0.00, reads: 0.00, writes: 42391.37, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1658s] threads: 64, tps: 0.00, reads: 0.00, writes: 39932.05, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1659s] threads: 64, tps: 0.00, reads: 0.00, writes: 38192.02, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1660s] threads: 64, tps: 0.00, reads: 0.00, writes: 37362.98, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1661s] threads: 64, tps: 0.00, reads: 0.00, writes: 36473.98, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1662s] threads: 64, tps: 0.00, reads: 0.00, writes: 39432.04, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1663s] threads: 64, tps: 0.00, reads: 0.00, writes: 36516.94, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[1664s] threads: 64, tps: 0.00, reads: 0.00, writes: 33731.04, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1665s] threads: 64, tps: 0.00, reads: 0.00, writes: 34732.99, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1666s] threads: 64, tps: 0.00, reads: 0.00, writes: 33226.02, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[1667s] threads: 64, tps: 0.00, reads: 0.00, writes: 36127.95, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[1668s] threads: 64, tps: 0.00, reads: 0.00, writes: 39201.95, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1669s] threads: 64, tps: 0.00, reads: 0.00, writes: 37972.99, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1670s] threads: 64, tps: 0.00, reads: 0.00, writes: 34427.05, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1671s] threads: 64, tps: 0.00, reads: 0.00, writes: 35681.96, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1672s] threads: 64, tps: 0.00, reads: 0.00, writes: 33885.04, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[1673s] threads: 64, tps: 0.00, reads: 0.00, writes: 38017.31, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[1674s] threads: 64, tps: 0.00, reads: 0.00, writes: 38911.75, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1675s] threads: 64, tps: 0.00, reads: 0.00, writes: 22345.89, response time: 17.08ms (95%), errors: 0.00, reconnects:  0.00
[1676s] threads: 64, tps: 0.00, reads: 0.00, writes: 3081.01, response time: 21.56ms (95%), errors: 0.00, reconnects:  0.00
[1677s] threads: 64, tps: 0.00, reads: 0.00, writes: 5757.99, response time: 21.29ms (95%), errors: 0.00, reconnects:  0.00
[1678s] threads: 64, tps: 0.00, reads: 0.00, writes: 28767.02, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[1679s] threads: 64, tps: 0.00, reads: 0.00, writes: 30852.00, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1680s] threads: 64, tps: 0.00, reads: 0.00, writes: 32336.96, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1681s] threads: 64, tps: 0.00, reads: 0.00, writes: 37897.09, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1682s] threads: 64, tps: 0.00, reads: 0.00, writes: 36079.98, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[1683s] threads: 64, tps: 0.00, reads: 0.00, writes: 35787.99, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1684s] threads: 64, tps: 0.00, reads: 0.00, writes: 38170.98, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1685s] threads: 64, tps: 0.00, reads: 0.00, writes: 38100.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1686s] threads: 64, tps: 0.00, reads: 0.00, writes: 39908.02, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1687s] threads: 64, tps: 0.00, reads: 0.00, writes: 41324.01, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1688s] threads: 64, tps: 0.00, reads: 0.00, writes: 40009.01, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1689s] threads: 64, tps: 0.00, reads: 0.00, writes: 39681.97, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1690s] threads: 64, tps: 0.00, reads: 0.00, writes: 38794.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1691s] threads: 64, tps: 0.00, reads: 0.00, writes: 40172.95, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1692s] threads: 64, tps: 0.00, reads: 0.00, writes: 41276.06, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1693s] threads: 64, tps: 0.00, reads: 0.00, writes: 39637.96, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1694s] threads: 64, tps: 0.00, reads: 0.00, writes: 37438.03, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1695s] threads: 64, tps: 0.00, reads: 0.00, writes: 37367.03, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1696s] threads: 64, tps: 0.00, reads: 0.00, writes: 30842.94, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1697s] threads: 64, tps: 0.00, reads: 0.00, writes: 41447.06, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1698s] threads: 64, tps: 0.00, reads: 0.00, writes: 39900.00, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1699s] threads: 64, tps: 0.00, reads: 0.00, writes: 38854.02, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1700s] threads: 64, tps: 0.00, reads: 0.00, writes: 38448.00, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1701s] threads: 64, tps: 0.00, reads: 0.00, writes: 36957.95, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1702s] threads: 64, tps: 0.00, reads: 0.00, writes: 40553.02, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1703s] threads: 64, tps: 0.00, reads: 0.00, writes: 39777.01, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1704s] threads: 64, tps: 0.00, reads: 0.00, writes: 38157.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1705s] threads: 64, tps: 0.00, reads: 0.00, writes: 36858.32, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1706s] threads: 64, tps: 0.00, reads: 0.00, writes: 36093.48, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1707s] threads: 64, tps: 0.00, reads: 0.00, writes: 39558.20, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1708s] threads: 64, tps: 0.00, reads: 0.00, writes: 38961.90, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1709s] threads: 64, tps: 0.00, reads: 0.00, writes: 32849.02, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[1710s] threads: 64, tps: 0.00, reads: 0.00, writes: 28995.00, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[1711s] threads: 64, tps: 0.00, reads: 0.00, writes: 28781.01, response time: 3.59ms (95%), errors: 0.00, reconnects:  0.00
[1712s] threads: 64, tps: 0.00, reads: 0.00, writes: 28599.99, response time: 3.53ms (95%), errors: 0.00, reconnects:  0.00
[1713s] threads: 64, tps: 0.00, reads: 0.00, writes: 33907.04, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[1714s] threads: 64, tps: 0.00, reads: 0.00, writes: 37825.97, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1715s] threads: 64, tps: 0.00, reads: 0.00, writes: 32154.89, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[1716s] threads: 64, tps: 0.00, reads: 0.00, writes: 34916.14, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1717s] threads: 64, tps: 0.00, reads: 0.00, writes: 34171.99, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[1718s] threads: 64, tps: 0.00, reads: 0.00, writes: 33606.99, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[1719s] threads: 64, tps: 0.00, reads: 0.00, writes: 39082.00, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1720s] threads: 64, tps: 0.00, reads: 0.00, writes: 39260.74, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1721s] threads: 64, tps: 0.00, reads: 0.00, writes: 34599.02, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1722s] threads: 64, tps: 0.00, reads: 0.00, writes: 3114.07, response time: 21.93ms (95%), errors: 0.00, reconnects:  0.00
[1723s] threads: 64, tps: 0.00, reads: 0.00, writes: 3094.03, response time: 21.45ms (95%), errors: 0.00, reconnects:  0.00
[1724s] threads: 64, tps: 0.00, reads: 0.00, writes: 3076.00, response time: 21.59ms (95%), errors: 0.00, reconnects:  0.00
[1725s] threads: 64, tps: 0.00, reads: 0.00, writes: 3114.00, response time: 21.62ms (95%), errors: 0.00, reconnects:  0.00
[1726s] threads: 64, tps: 0.00, reads: 0.00, writes: 3095.99, response time: 21.37ms (95%), errors: 0.00, reconnects:  0.00
[1727s] threads: 64, tps: 0.00, reads: 0.00, writes: 3077.01, response time: 22.02ms (95%), errors: 0.00, reconnects:  0.00
[1728s] threads: 64, tps: 0.00, reads: 0.00, writes: 3097.00, response time: 21.73ms (95%), errors: 0.00, reconnects:  0.00
[1729s] threads: 64, tps: 0.00, reads: 0.00, writes: 3083.94, response time: 21.33ms (95%), errors: 0.00, reconnects:  0.00
[1730s] threads: 64, tps: 0.00, reads: 0.00, writes: 22281.45, response time: 7.27ms (95%), errors: 0.00, reconnects:  0.00
[1731s] threads: 64, tps: 0.00, reads: 0.00, writes: 32004.02, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1732s] threads: 64, tps: 0.00, reads: 0.00, writes: 35562.98, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[1733s] threads: 64, tps: 0.00, reads: 0.00, writes: 37487.98, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[1734s] threads: 64, tps: 0.00, reads: 0.00, writes: 33157.02, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1735s] threads: 64, tps: 0.00, reads: 0.00, writes: 35236.97, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1736s] threads: 64, tps: 0.00, reads: 0.00, writes: 35792.99, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[1737s] threads: 64, tps: 0.00, reads: 0.00, writes: 35948.19, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1738s] threads: 64, tps: 0.00, reads: 0.00, writes: 40783.68, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1739s] threads: 64, tps: 0.00, reads: 0.00, writes: 37461.91, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1740s] threads: 64, tps: 0.00, reads: 0.00, writes: 37582.99, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1741s] threads: 64, tps: 0.00, reads: 0.00, writes: 36906.65, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1742s] threads: 64, tps: 0.00, reads: 0.00, writes: 36696.38, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[1743s] threads: 64, tps: 0.00, reads: 0.00, writes: 40010.98, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1744s] threads: 64, tps: 0.00, reads: 0.00, writes: 39798.07, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1745s] threads: 64, tps: 0.00, reads: 0.00, writes: 39037.96, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1746s] threads: 64, tps: 0.00, reads: 0.00, writes: 38651.50, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1747s] threads: 64, tps: 0.00, reads: 0.00, writes: 38373.45, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1748s] threads: 64, tps: 0.00, reads: 0.00, writes: 40224.03, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1749s] threads: 64, tps: 0.00, reads: 0.00, writes: 40632.01, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1750s] threads: 64, tps: 0.00, reads: 0.00, writes: 38507.99, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1751s] threads: 64, tps: 0.00, reads: 0.00, writes: 37277.98, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1752s] threads: 64, tps: 0.00, reads: 0.00, writes: 27109.98, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[1753s] threads: 64, tps: 0.00, reads: 0.00, writes: 36476.07, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1754s] threads: 64, tps: 0.00, reads: 0.00, writes: 42269.98, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1755s] threads: 64, tps: 0.00, reads: 0.00, writes: 40050.96, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1756s] threads: 64, tps: 0.00, reads: 0.00, writes: 37614.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1757s] threads: 64, tps: 0.00, reads: 0.00, writes: 38725.98, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1758s] threads: 64, tps: 0.00, reads: 0.00, writes: 37791.00, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1759s] threads: 64, tps: 0.00, reads: 0.00, writes: 41105.06, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1760s] threads: 64, tps: 0.00, reads: 0.00, writes: 39149.98, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1761s] threads: 64, tps: 0.00, reads: 0.00, writes: 36349.01, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1762s] threads: 64, tps: 0.00, reads: 0.00, writes: 29015.94, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[1763s] threads: 64, tps: 0.00, reads: 0.00, writes: 29998.01, response time: 3.43ms (95%), errors: 0.00, reconnects:  0.00
[1764s] threads: 64, tps: 0.00, reads: 0.00, writes: 34369.03, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[1765s] threads: 64, tps: 0.00, reads: 0.00, writes: 40473.98, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1766s] threads: 64, tps: 0.00, reads: 0.00, writes: 37806.87, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1767s] threads: 64, tps: 0.00, reads: 0.00, writes: 35827.16, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[1768s] threads: 64, tps: 0.00, reads: 0.00, writes: 35079.93, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1769s] threads: 64, tps: 0.00, reads: 0.00, writes: 33043.02, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1770s] threads: 64, tps: 0.00, reads: 0.00, writes: 38281.02, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1771s] threads: 64, tps: 0.00, reads: 0.00, writes: 38686.97, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1772s] threads: 64, tps: 0.00, reads: 0.00, writes: 36302.74, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1773s] threads: 64, tps: 0.00, reads: 0.00, writes: 34329.24, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1774s] threads: 64, tps: 0.00, reads: 0.00, writes: 30383.04, response time: 3.50ms (95%), errors: 0.00, reconnects:  0.00
[1775s] threads: 64, tps: 0.00, reads: 0.00, writes: 29851.98, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[1776s] threads: 64, tps: 0.00, reads: 0.00, writes: 36683.98, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1777s] threads: 64, tps: 0.00, reads: 0.00, writes: 35083.21, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1778s] threads: 64, tps: 0.00, reads: 0.00, writes: 32149.65, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1779s] threads: 64, tps: 0.00, reads: 0.00, writes: 33204.03, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[1780s] threads: 64, tps: 0.00, reads: 0.00, writes: 35235.99, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[1781s] threads: 64, tps: 0.00, reads: 0.00, writes: 36998.98, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1782s] threads: 64, tps: 0.00, reads: 0.00, writes: 42944.03, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1783s] threads: 64, tps: 0.00, reads: 0.00, writes: 37930.98, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1784s] threads: 64, tps: 0.00, reads: 0.00, writes: 38994.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1785s] threads: 64, tps: 0.00, reads: 0.00, writes: 38746.99, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1786s] threads: 64, tps: 0.00, reads: 0.00, writes: 37837.01, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1787s] threads: 64, tps: 0.00, reads: 0.00, writes: 42215.01, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1788s] threads: 64, tps: 0.00, reads: 0.00, writes: 39808.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1789s] threads: 64, tps: 0.00, reads: 0.00, writes: 38950.06, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1790s] threads: 64, tps: 0.00, reads: 0.00, writes: 38203.95, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1791s] threads: 64, tps: 0.00, reads: 0.00, writes: 36762.04, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1792s] threads: 64, tps: 0.00, reads: 0.00, writes: 40487.95, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1793s] threads: 64, tps: 0.00, reads: 0.00, writes: 39834.03, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1794s] threads: 64, tps: 0.00, reads: 0.00, writes: 38760.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1795s] threads: 64, tps: 0.00, reads: 0.00, writes: 37349.04, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1796s] threads: 64, tps: 0.00, reads: 0.00, writes: 37452.91, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1797s] threads: 64, tps: 0.00, reads: 0.00, writes: 40595.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1798s] threads: 64, tps: 0.00, reads: 0.00, writes: 41256.07, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1799s] threads: 64, tps: 0.00, reads: 0.00, writes: 32031.96, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[1800s] threads: 64, tps: 0.00, reads: 0.00, writes: 38775.01, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1801s] threads: 64, tps: 0.00, reads: 0.00, writes: 37400.98, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1802s] threads: 64, tps: 0.00, reads: 0.00, writes: 38322.06, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1803s] threads: 64, tps: 0.00, reads: 0.00, writes: 40593.92, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1804s] threads: 64, tps: 0.00, reads: 0.00, writes: 38456.00, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1805s] threads: 64, tps: 0.00, reads: 0.00, writes: 32269.24, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[1806s] threads: 64, tps: 0.00, reads: 0.00, writes: 34130.12, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1807s] threads: 64, tps: 0.00, reads: 0.00, writes: 33710.70, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1808s] threads: 64, tps: 0.00, reads: 0.00, writes: 39154.01, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1809s] threads: 64, tps: 0.00, reads: 0.00, writes: 39269.96, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1810s] threads: 64, tps: 0.00, reads: 0.00, writes: 36908.03, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1811s] threads: 64, tps: 0.00, reads: 0.00, writes: 33937.02, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[1812s] threads: 64, tps: 0.00, reads: 0.00, writes: 33955.96, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1813s] threads: 64, tps: 0.00, reads: 0.00, writes: 35114.07, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1814s] threads: 64, tps: 0.00, reads: 0.00, writes: 40700.97, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1815s] threads: 64, tps: 0.00, reads: 0.00, writes: 38420.02, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1816s] threads: 64, tps: 0.00, reads: 0.00, writes: 12225.99, response time: 20.82ms (95%), errors: 0.00, reconnects:  0.00
[1817s] threads: 64, tps: 0.00, reads: 0.00, writes: 3086.00, response time: 21.75ms (95%), errors: 0.00, reconnects:  0.00
[1818s] threads: 64, tps: 0.00, reads: 0.00, writes: 3097.91, response time: 21.76ms (95%), errors: 0.00, reconnects:  0.00
[1819s] threads: 64, tps: 0.00, reads: 0.00, writes: 9595.28, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[1820s] threads: 64, tps: 0.00, reads: 0.00, writes: 29471.90, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[1821s] threads: 64, tps: 0.00, reads: 0.00, writes: 35893.11, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1822s] threads: 64, tps: 0.00, reads: 0.00, writes: 40844.98, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1823s] threads: 64, tps: 0.00, reads: 0.00, writes: 40837.04, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1824s] threads: 64, tps: 0.00, reads: 0.00, writes: 39787.96, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1825s] threads: 64, tps: 0.00, reads: 0.00, writes: 39457.08, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1826s] threads: 64, tps: 0.00, reads: 0.00, writes: 37608.97, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1827s] threads: 64, tps: 0.00, reads: 0.00, writes: 40451.02, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1828s] threads: 64, tps: 0.00, reads: 0.00, writes: 41916.96, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1829s] threads: 64, tps: 0.00, reads: 0.00, writes: 39911.01, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1830s] threads: 64, tps: 0.00, reads: 0.00, writes: 38930.99, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1831s] threads: 64, tps: 0.00, reads: 0.00, writes: 38215.99, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1832s] threads: 64, tps: 0.00, reads: 0.00, writes: 40347.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1833s] threads: 64, tps: 0.00, reads: 0.00, writes: 36485.98, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1834s] threads: 64, tps: 0.00, reads: 0.00, writes: 39777.04, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1835s] threads: 64, tps: 0.00, reads: 0.00, writes: 37633.90, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1836s] threads: 64, tps: 0.00, reads: 0.00, writes: 37522.10, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1837s] threads: 64, tps: 0.00, reads: 0.00, writes: 37548.03, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1838s] threads: 64, tps: 0.00, reads: 0.00, writes: 42510.94, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1839s] threads: 64, tps: 0.00, reads: 0.00, writes: 39444.05, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1840s] threads: 64, tps: 0.00, reads: 0.00, writes: 38716.92, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1841s] threads: 64, tps: 0.00, reads: 0.00, writes: 38675.00, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1842s] threads: 64, tps: 0.00, reads: 0.00, writes: 37657.04, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1843s] threads: 64, tps: 0.00, reads: 0.00, writes: 42601.98, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1844s] threads: 64, tps: 0.00, reads: 0.00, writes: 39120.02, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1845s] threads: 64, tps: 0.00, reads: 0.00, writes: 36793.98, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1846s] threads: 64, tps: 0.00, reads: 0.00, writes: 28770.00, response time: 3.71ms (95%), errors: 0.00, reconnects:  0.00
[1847s] threads: 64, tps: 0.00, reads: 0.00, writes: 28627.99, response time: 3.59ms (95%), errors: 0.00, reconnects:  0.00
[1848s] threads: 64, tps: 0.00, reads: 0.00, writes: 30433.04, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[1849s] threads: 64, tps: 0.00, reads: 0.00, writes: 34020.94, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1850s] threads: 64, tps: 0.00, reads: 0.00, writes: 31448.00, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[1851s] threads: 64, tps: 0.00, reads: 0.00, writes: 29391.71, response time: 3.57ms (95%), errors: 0.00, reconnects:  0.00
[1852s] threads: 64, tps: 0.00, reads: 0.00, writes: 34665.39, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1853s] threads: 64, tps: 0.00, reads: 0.00, writes: 35198.98, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1854s] threads: 64, tps: 0.00, reads: 0.00, writes: 35004.00, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[1855s] threads: 64, tps: 0.00, reads: 0.00, writes: 40869.02, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1856s] threads: 64, tps: 0.00, reads: 0.00, writes: 37472.00, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1857s] threads: 64, tps: 0.00, reads: 0.00, writes: 35629.01, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[1858s] threads: 64, tps: 0.00, reads: 0.00, writes: 34098.99, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1859s] threads: 64, tps: 0.00, reads: 0.00, writes: 34003.02, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[1860s] threads: 64, tps: 0.00, reads: 0.00, writes: 38872.92, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1861s] threads: 64, tps: 0.00, reads: 0.00, writes: 39713.03, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1862s] threads: 64, tps: 0.00, reads: 0.00, writes: 28148.02, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[1863s] threads: 64, tps: 0.00, reads: 0.00, writes: 3092.99, response time: 21.62ms (95%), errors: 0.00, reconnects:  0.00
[1864s] threads: 64, tps: 0.00, reads: 0.00, writes: 3086.00, response time: 21.68ms (95%), errors: 0.00, reconnects:  0.00
[1865s] threads: 64, tps: 0.00, reads: 0.00, writes: 29415.97, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[1866s] threads: 64, tps: 0.00, reads: 0.00, writes: 31050.07, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[1867s] threads: 64, tps: 0.00, reads: 0.00, writes: 34000.00, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[1868s] threads: 64, tps: 0.00, reads: 0.00, writes: 40873.98, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1869s] threads: 64, tps: 0.00, reads: 0.00, writes: 39668.99, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1870s] threads: 64, tps: 0.00, reads: 0.00, writes: 38906.96, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1871s] threads: 64, tps: 0.00, reads: 0.00, writes: 38830.04, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1872s] threads: 64, tps: 0.00, reads: 0.00, writes: 37851.06, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1873s] threads: 64, tps: 0.00, reads: 0.00, writes: 41717.96, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1874s] threads: 64, tps: 0.00, reads: 0.00, writes: 39946.03, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1875s] threads: 64, tps: 0.00, reads: 0.00, writes: 39883.97, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1876s] threads: 64, tps: 0.00, reads: 0.00, writes: 39176.95, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1877s] threads: 64, tps: 0.00, reads: 0.00, writes: 37624.05, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1878s] threads: 64, tps: 0.00, reads: 0.00, writes: 41874.02, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1879s] threads: 64, tps: 0.00, reads: 0.00, writes: 40104.93, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1880s] threads: 64, tps: 0.00, reads: 0.00, writes: 39586.91, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1881s] threads: 64, tps: 0.00, reads: 0.00, writes: 37029.15, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1882s] threads: 64, tps: 0.00, reads: 0.00, writes: 38107.99, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1883s] threads: 64, tps: 0.00, reads: 0.00, writes: 40997.98, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1884s] threads: 64, tps: 0.00, reads: 0.00, writes: 36104.02, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1885s] threads: 64, tps: 0.00, reads: 0.00, writes: 39495.94, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1886s] threads: 64, tps: 0.00, reads: 0.00, writes: 38260.07, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1887s] threads: 64, tps: 0.00, reads: 0.00, writes: 36902.94, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1888s] threads: 64, tps: 0.00, reads: 0.00, writes: 38679.02, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1889s] threads: 64, tps: 0.00, reads: 0.00, writes: 41443.98, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1890s] threads: 64, tps: 0.00, reads: 0.00, writes: 39925.99, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1891s] threads: 64, tps: 0.00, reads: 0.00, writes: 39064.97, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1892s] threads: 64, tps: 0.00, reads: 0.00, writes: 36004.05, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1893s] threads: 64, tps: 0.00, reads: 0.00, writes: 32512.98, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[1894s] threads: 64, tps: 0.00, reads: 0.00, writes: 39821.96, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1895s] threads: 64, tps: 0.00, reads: 0.00, writes: 32166.03, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[1896s] threads: 64, tps: 0.00, reads: 0.00, writes: 34998.00, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[1897s] threads: 64, tps: 0.00, reads: 0.00, writes: 35059.03, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1898s] threads: 64, tps: 0.00, reads: 0.00, writes: 30102.54, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[1899s] threads: 64, tps: 0.00, reads: 0.00, writes: 36182.58, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1900s] threads: 64, tps: 0.00, reads: 0.00, writes: 40087.95, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1901s] threads: 64, tps: 0.00, reads: 0.00, writes: 37308.00, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1902s] threads: 64, tps: 0.00, reads: 0.00, writes: 35118.97, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1903s] threads: 64, tps: 0.00, reads: 0.00, writes: 35251.03, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[1904s] threads: 64, tps: 0.00, reads: 0.00, writes: 34994.96, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1905s] threads: 64, tps: 0.00, reads: 0.00, writes: 40914.03, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1906s] threads: 64, tps: 0.00, reads: 0.00, writes: 38733.00, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1907s] threads: 64, tps: 0.00, reads: 0.00, writes: 11173.77, response time: 20.93ms (95%), errors: 0.00, reconnects:  0.00
[1908s] threads: 64, tps: 0.00, reads: 0.00, writes: 3091.06, response time: 21.70ms (95%), errors: 0.00, reconnects:  0.00
[1909s] threads: 64, tps: 0.00, reads: 0.00, writes: 20692.02, response time: 20.24ms (95%), errors: 0.00, reconnects:  0.00
[1910s] threads: 64, tps: 0.00, reads: 0.00, writes: 33355.94, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[1911s] threads: 64, tps: 0.00, reads: 0.00, writes: 35064.05, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[1912s] threads: 64, tps: 0.00, reads: 0.00, writes: 36870.02, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1913s] threads: 64, tps: 0.00, reads: 0.00, writes: 40923.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1914s] threads: 64, tps: 0.00, reads: 0.00, writes: 38862.01, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1915s] threads: 64, tps: 0.00, reads: 0.00, writes: 39174.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1916s] threads: 64, tps: 0.00, reads: 0.00, writes: 39278.94, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1917s] threads: 64, tps: 0.00, reads: 0.00, writes: 39884.07, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1918s] threads: 64, tps: 0.00, reads: 0.00, writes: 42841.93, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1919s] threads: 64, tps: 0.00, reads: 0.00, writes: 41058.02, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1920s] threads: 64, tps: 0.00, reads: 0.00, writes: 39775.98, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1921s] threads: 64, tps: 0.00, reads: 0.00, writes: 39114.08, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1922s] threads: 64, tps: 0.00, reads: 0.00, writes: 40423.94, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1923s] threads: 64, tps: 0.00, reads: 0.00, writes: 42287.05, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1924s] threads: 64, tps: 0.00, reads: 0.00, writes: 39888.96, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1925s] threads: 64, tps: 0.00, reads: 0.00, writes: 39325.02, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1926s] threads: 64, tps: 0.00, reads: 0.00, writes: 36658.02, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1927s] threads: 64, tps: 0.00, reads: 0.00, writes: 38562.96, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1928s] threads: 64, tps: 0.00, reads: 0.00, writes: 41900.10, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1929s] threads: 64, tps: 0.00, reads: 0.00, writes: 34725.90, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1930s] threads: 64, tps: 0.00, reads: 0.00, writes: 39044.03, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1931s] threads: 64, tps: 0.00, reads: 0.00, writes: 38665.96, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1932s] threads: 64, tps: 0.00, reads: 0.00, writes: 37438.03, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1933s] threads: 64, tps: 0.00, reads: 0.00, writes: 42311.96, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1934s] threads: 64, tps: 0.00, reads: 0.00, writes: 40034.93, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1935s] threads: 64, tps: 0.00, reads: 0.00, writes: 37758.69, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1936s] threads: 64, tps: 0.00, reads: 0.00, writes: 37490.42, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1937s] threads: 64, tps: 0.00, reads: 0.00, writes: 36535.97, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1938s] threads: 64, tps: 0.00, reads: 0.00, writes: 40984.99, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1939s] threads: 64, tps: 0.00, reads: 0.00, writes: 38772.04, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1940s] threads: 64, tps: 0.00, reads: 0.00, writes: 31037.96, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[1941s] threads: 64, tps: 0.00, reads: 0.00, writes: 28726.02, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[1942s] threads: 64, tps: 0.00, reads: 0.00, writes: 27813.98, response time: 3.77ms (95%), errors: 0.00, reconnects:  0.00
[1943s] threads: 64, tps: 0.00, reads: 0.00, writes: 32855.02, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1944s] threads: 64, tps: 0.00, reads: 0.00, writes: 39261.98, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1945s] threads: 64, tps: 0.00, reads: 0.00, writes: 38610.01, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1946s] threads: 64, tps: 0.00, reads: 0.00, writes: 27468.99, response time: 3.53ms (95%), errors: 0.00, reconnects:  0.00
[1947s] threads: 64, tps: 0.00, reads: 0.00, writes: 35498.07, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[1948s] threads: 64, tps: 0.00, reads: 0.00, writes: 35325.98, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1949s] threads: 64, tps: 0.00, reads: 0.00, writes: 34389.01, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[1950s] threads: 64, tps: 0.00, reads: 0.00, writes: 39932.97, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1951s] threads: 64, tps: 0.00, reads: 0.00, writes: 38268.01, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1952s] threads: 64, tps: 0.00, reads: 0.00, writes: 15386.97, response time: 20.90ms (95%), errors: 0.00, reconnects:  0.00
[1953s] threads: 64, tps: 0.00, reads: 0.00, writes: 3086.00, response time: 21.49ms (95%), errors: 0.00, reconnects:  0.00
[1954s] threads: 64, tps: 0.00, reads: 0.00, writes: 3081.93, response time: 21.51ms (95%), errors: 0.00, reconnects:  0.00
[1955s] threads: 64, tps: 0.00, reads: 0.00, writes: 3114.00, response time: 21.61ms (95%), errors: 0.00, reconnects:  0.00
[1956s] threads: 64, tps: 0.00, reads: 0.00, writes: 3083.02, response time: 21.66ms (95%), errors: 0.00, reconnects:  0.00
[1957s] threads: 64, tps: 0.00, reads: 0.00, writes: 3656.04, response time: 21.31ms (95%), errors: 0.00, reconnects:  0.00
[1958s] threads: 64, tps: 0.00, reads: 0.00, writes: 31904.32, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[1959s] threads: 64, tps: 0.00, reads: 0.00, writes: 32817.86, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[1960s] threads: 64, tps: 0.00, reads: 0.00, writes: 35763.98, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[1961s] threads: 64, tps: 0.00, reads: 0.00, writes: 40920.03, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1962s] threads: 64, tps: 0.00, reads: 0.00, writes: 37812.99, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1963s] threads: 64, tps: 0.00, reads: 0.00, writes: 37130.97, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1964s] threads: 64, tps: 0.00, reads: 0.00, writes: 36857.00, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[1965s] threads: 64, tps: 0.00, reads: 0.00, writes: 36586.53, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1966s] threads: 64, tps: 0.00, reads: 0.00, writes: 43199.52, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1967s] threads: 64, tps: 0.00, reads: 0.00, writes: 38694.03, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1968s] threads: 64, tps: 0.00, reads: 0.00, writes: 38664.04, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1969s] threads: 64, tps: 0.00, reads: 0.00, writes: 38338.00, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1970s] threads: 64, tps: 0.00, reads: 0.00, writes: 37545.98, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1971s] threads: 64, tps: 0.00, reads: 0.00, writes: 41333.94, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1972s] threads: 64, tps: 0.00, reads: 0.00, writes: 40041.08, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1973s] threads: 64, tps: 0.00, reads: 0.00, writes: 38775.95, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1974s] threads: 64, tps: 0.00, reads: 0.00, writes: 35560.00, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1975s] threads: 64, tps: 0.00, reads: 0.00, writes: 37203.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1976s] threads: 64, tps: 0.00, reads: 0.00, writes: 39157.97, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1977s] threads: 64, tps: 0.00, reads: 0.00, writes: 40637.07, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1978s] threads: 64, tps: 0.00, reads: 0.00, writes: 38924.98, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1979s] threads: 64, tps: 0.00, reads: 0.00, writes: 34064.99, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1980s] threads: 64, tps: 0.00, reads: 0.00, writes: 37248.00, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1981s] threads: 64, tps: 0.00, reads: 0.00, writes: 38906.03, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1982s] threads: 64, tps: 0.00, reads: 0.00, writes: 40981.95, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1983s] threads: 64, tps: 0.00, reads: 0.00, writes: 39247.07, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1984s] threads: 64, tps: 0.00, reads: 0.00, writes: 37183.97, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[1985s] threads: 64, tps: 0.00, reads: 0.00, writes: 35756.00, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[1986s] threads: 64, tps: 0.00, reads: 0.00, writes: 30798.97, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[1987s] threads: 64, tps: 0.00, reads: 0.00, writes: 38054.07, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1988s] threads: 64, tps: 0.00, reads: 0.00, writes: 33291.93, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[1989s] threads: 64, tps: 0.00, reads: 0.00, writes: 29657.04, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[1990s] threads: 64, tps: 0.00, reads: 0.00, writes: 28157.95, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[1991s] threads: 64, tps: 0.00, reads: 0.00, writes: 34475.03, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[1992s] threads: 64, tps: 0.00, reads: 0.00, writes: 34166.00, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1993s] threads: 64, tps: 0.00, reads: 0.00, writes: 39497.05, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1994s] threads: 64, tps: 0.00, reads: 0.00, writes: 39018.96, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1995s] threads: 64, tps: 0.00, reads: 0.00, writes: 34432.77, response time: 3.05ms (95%), errors: 0.00, reconnects:  0.00
[1996s] threads: 64, tps: 0.00, reads: 0.00, writes: 35218.56, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[1997s] threads: 64, tps: 0.00, reads: 0.00, writes: 34514.61, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1998s] threads: 64, tps: 0.00, reads: 0.00, writes: 36470.39, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[1999s] threads: 64, tps: 0.00, reads: 0.00, writes: 32199.55, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[2000s] threads: 64, tps: 0.00, reads: 0.00, writes: 37067.98, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2001s] threads: 64, tps: 0.00, reads: 0.00, writes: 9891.76, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[2002s] threads: 64, tps: 0.00, reads: 0.00, writes: 3089.03, response time: 21.69ms (95%), errors: 0.00, reconnects:  0.00
[2003s] threads: 64, tps: 0.00, reads: 0.00, writes: 3094.04, response time: 21.86ms (95%), errors: 0.00, reconnects:  0.00
[2004s] threads: 64, tps: 0.00, reads: 0.00, writes: 7970.01, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[2005s] threads: 64, tps: 0.00, reads: 0.00, writes: 32862.02, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[2006s] threads: 64, tps: 0.00, reads: 0.00, writes: 34442.98, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2007s] threads: 64, tps: 0.00, reads: 0.00, writes: 36365.00, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2008s] threads: 64, tps: 0.00, reads: 0.00, writes: 39964.98, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2009s] threads: 64, tps: 0.00, reads: 0.00, writes: 36897.07, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2010s] threads: 64, tps: 0.00, reads: 0.00, writes: 37922.98, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2011s] threads: 64, tps: 0.00, reads: 0.00, writes: 38441.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2012s] threads: 64, tps: 0.00, reads: 0.00, writes: 37707.94, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2013s] threads: 64, tps: 0.00, reads: 0.00, writes: 42993.04, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2014s] threads: 64, tps: 0.00, reads: 0.00, writes: 40273.06, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2015s] threads: 64, tps: 0.00, reads: 0.00, writes: 38855.82, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2016s] threads: 64, tps: 0.00, reads: 0.00, writes: 39213.10, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2017s] threads: 64, tps: 0.00, reads: 0.00, writes: 38065.03, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2018s] threads: 64, tps: 0.00, reads: 0.00, writes: 43938.96, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2019s] threads: 64, tps: 0.00, reads: 0.00, writes: 39454.90, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2020s] threads: 64, tps: 0.00, reads: 0.00, writes: 38673.08, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2021s] threads: 64, tps: 0.00, reads: 0.00, writes: 38015.96, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2022s] threads: 64, tps: 0.00, reads: 0.00, writes: 37887.25, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2023s] threads: 64, tps: 0.00, reads: 0.00, writes: 42304.90, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2024s] threads: 64, tps: 0.00, reads: 0.00, writes: 40447.97, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2025s] threads: 64, tps: 0.00, reads: 0.00, writes: 38446.94, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2026s] threads: 64, tps: 0.00, reads: 0.00, writes: 38014.13, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2027s] threads: 64, tps: 0.00, reads: 0.00, writes: 36956.98, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2028s] threads: 64, tps: 0.00, reads: 0.00, writes: 42099.91, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2029s] threads: 64, tps: 0.00, reads: 0.00, writes: 39362.99, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2030s] threads: 64, tps: 0.00, reads: 0.00, writes: 35021.05, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2031s] threads: 64, tps: 0.00, reads: 0.00, writes: 36149.02, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2032s] threads: 64, tps: 0.00, reads: 0.00, writes: 32975.00, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[2033s] threads: 64, tps: 0.00, reads: 0.00, writes: 28972.97, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[2034s] threads: 64, tps: 0.00, reads: 0.00, writes: 40978.00, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2035s] threads: 64, tps: 0.00, reads: 0.00, writes: 37284.99, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2036s] threads: 64, tps: 0.00, reads: 0.00, writes: 31191.05, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[2037s] threads: 64, tps: 0.00, reads: 0.00, writes: 34411.96, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[2038s] threads: 64, tps: 0.00, reads: 0.00, writes: 33989.97, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[2039s] threads: 64, tps: 0.00, reads: 0.00, writes: 38309.06, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[2040s] threads: 64, tps: 0.00, reads: 0.00, writes: 40099.88, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2041s] threads: 64, tps: 0.00, reads: 0.00, writes: 36931.07, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2042s] threads: 64, tps: 0.00, reads: 0.00, writes: 35416.01, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[2043s] threads: 64, tps: 0.00, reads: 0.00, writes: 35311.03, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[2044s] threads: 64, tps: 0.00, reads: 0.00, writes: 33802.98, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[2045s] threads: 64, tps: 0.00, reads: 0.00, writes: 40276.02, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2046s] threads: 64, tps: 0.00, reads: 0.00, writes: 38022.97, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2047s] threads: 64, tps: 0.00, reads: 0.00, writes: 17960.98, response time: 20.55ms (95%), errors: 0.00, reconnects:  0.00
[2048s] threads: 64, tps: 0.00, reads: 0.00, writes: 3088.00, response time: 21.71ms (95%), errors: 0.00, reconnects:  0.00
[2049s] threads: 64, tps: 0.00, reads: 0.00, writes: 3100.95, response time: 21.62ms (95%), errors: 0.00, reconnects:  0.00
[2050s] threads: 64, tps: 0.00, reads: 0.00, writes: 3090.06, response time: 22.14ms (95%), errors: 0.00, reconnects:  0.00
[2051s] threads: 64, tps: 0.00, reads: 0.00, writes: 15863.73, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[2052s] threads: 64, tps: 0.00, reads: 0.00, writes: 32722.56, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[2053s] threads: 64, tps: 0.00, reads: 0.00, writes: 27315.01, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2054s] threads: 64, tps: 0.00, reads: 0.00, writes: 39845.03, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2055s] threads: 64, tps: 0.00, reads: 0.00, writes: 40191.02, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2056s] threads: 64, tps: 0.00, reads: 0.00, writes: 39969.97, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2057s] threads: 64, tps: 0.00, reads: 0.00, writes: 39139.98, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2058s] threads: 64, tps: 0.00, reads: 0.00, writes: 38945.01, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2059s] threads: 64, tps: 0.00, reads: 0.00, writes: 40789.99, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2060s] threads: 64, tps: 0.00, reads: 0.00, writes: 41917.97, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2061s] threads: 64, tps: 0.00, reads: 0.00, writes: 38567.98, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2062s] threads: 64, tps: 0.00, reads: 0.00, writes: 38904.07, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2063s] threads: 64, tps: 0.00, reads: 0.00, writes: 38332.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2064s] threads: 64, tps: 0.00, reads: 0.00, writes: 39709.95, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2065s] threads: 64, tps: 0.00, reads: 0.00, writes: 42389.02, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2066s] threads: 64, tps: 0.00, reads: 0.00, writes: 39487.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2067s] threads: 64, tps: 0.00, reads: 0.00, writes: 38405.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2068s] threads: 64, tps: 0.00, reads: 0.00, writes: 37581.96, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2069s] threads: 64, tps: 0.00, reads: 0.00, writes: 39538.03, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2070s] threads: 64, tps: 0.00, reads: 0.00, writes: 41237.96, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2071s] threads: 64, tps: 0.00, reads: 0.00, writes: 39055.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2072s] threads: 64, tps: 0.00, reads: 0.00, writes: 37706.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2073s] threads: 64, tps: 0.00, reads: 0.00, writes: 36787.00, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2074s] threads: 64, tps: 0.00, reads: 0.00, writes: 36489.93, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2075s] threads: 64, tps: 0.00, reads: 0.00, writes: 41313.12, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2076s] threads: 64, tps: 0.00, reads: 0.00, writes: 38782.41, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2077s] threads: 64, tps: 0.00, reads: 0.00, writes: 31659.49, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[2078s] threads: 64, tps: 0.00, reads: 0.00, writes: 27962.97, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[2079s] threads: 64, tps: 0.00, reads: 0.00, writes: 29251.05, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[2080s] threads: 64, tps: 0.00, reads: 0.00, writes: 30221.95, response time: 3.34ms (95%), errors: 0.00, reconnects:  0.00
[2081s] threads: 64, tps: 0.00, reads: 0.00, writes: 38601.96, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[2082s] threads: 64, tps: 0.00, reads: 0.00, writes: 31912.05, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[2083s] threads: 64, tps: 0.00, reads: 0.00, writes: 34267.01, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[2084s] threads: 64, tps: 0.00, reads: 0.00, writes: 35429.01, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[2085s] threads: 64, tps: 0.00, reads: 0.00, writes: 32989.95, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[2086s] threads: 64, tps: 0.00, reads: 0.00, writes: 36465.05, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[2087s] threads: 64, tps: 0.00, reads: 0.00, writes: 40440.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2088s] threads: 64, tps: 0.00, reads: 0.00, writes: 36799.99, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2089s] threads: 64, tps: 0.00, reads: 0.00, writes: 33903.04, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[2090s] threads: 64, tps: 0.00, reads: 0.00, writes: 34408.93, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[2091s] threads: 64, tps: 0.00, reads: 0.00, writes: 33761.02, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[2092s] threads: 64, tps: 0.00, reads: 0.00, writes: 38756.95, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[2093s] threads: 64, tps: 0.00, reads: 0.00, writes: 39475.99, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2094s] threads: 64, tps: 0.00, reads: 0.00, writes: 13479.75, response time: 20.69ms (95%), errors: 0.00, reconnects:  0.00
[2095s] threads: 64, tps: 0.00, reads: 0.00, writes: 3097.06, response time: 21.56ms (95%), errors: 0.00, reconnects:  0.00
[2096s] threads: 64, tps: 0.00, reads: 0.00, writes: 3087.91, response time: 21.65ms (95%), errors: 0.00, reconnects:  0.00
[2097s] threads: 64, tps: 0.00, reads: 0.00, writes: 24255.72, response time: 3.88ms (95%), errors: 0.00, reconnects:  0.00
[2098s] threads: 64, tps: 0.00, reads: 0.00, writes: 29449.05, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[2099s] threads: 64, tps: 0.00, reads: 0.00, writes: 32975.99, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2100s] threads: 64, tps: 0.00, reads: 0.00, writes: 37114.99, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2101s] threads: 64, tps: 0.00, reads: 0.00, writes: 40389.99, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2102s] threads: 64, tps: 0.00, reads: 0.00, writes: 37976.97, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2103s] threads: 64, tps: 0.00, reads: 0.00, writes: 32492.03, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2104s] threads: 64, tps: 0.00, reads: 0.00, writes: 38336.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2105s] threads: 64, tps: 0.00, reads: 0.00, writes: 37777.98, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2106s] threads: 64, tps: 0.00, reads: 0.00, writes: 43416.07, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2107s] threads: 64, tps: 0.00, reads: 0.00, writes: 39360.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2108s] threads: 64, tps: 0.00, reads: 0.00, writes: 39634.97, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2109s] threads: 64, tps: 0.00, reads: 0.00, writes: 38755.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2110s] threads: 64, tps: 0.00, reads: 0.00, writes: 37863.97, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2111s] threads: 64, tps: 0.00, reads: 0.00, writes: 43184.85, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2112s] threads: 64, tps: 0.00, reads: 0.00, writes: 40598.99, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2113s] threads: 64, tps: 0.00, reads: 0.00, writes: 38595.03, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2114s] threads: 64, tps: 0.00, reads: 0.00, writes: 37943.96, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2115s] threads: 64, tps: 0.00, reads: 0.00, writes: 38005.20, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2116s] threads: 64, tps: 0.00, reads: 0.00, writes: 39496.80, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2117s] threads: 64, tps: 0.00, reads: 0.00, writes: 39824.07, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2118s] threads: 64, tps: 0.00, reads: 0.00, writes: 39287.98, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2119s] threads: 64, tps: 0.00, reads: 0.00, writes: 37802.11, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2120s] threads: 64, tps: 0.00, reads: 0.00, writes: 36752.87, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2121s] threads: 64, tps: 0.00, reads: 0.00, writes: 40810.10, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2122s] threads: 64, tps: 0.00, reads: 0.00, writes: 40404.07, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2123s] threads: 64, tps: 0.00, reads: 0.00, writes: 39648.80, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2124s] threads: 64, tps: 0.00, reads: 0.00, writes: 38537.21, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2125s] threads: 64, tps: 0.00, reads: 0.00, writes: 37040.02, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2126s] threads: 64, tps: 0.00, reads: 0.00, writes: 38597.92, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2127s] threads: 64, tps: 0.00, reads: 0.00, writes: 40876.86, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2128s] threads: 64, tps: 0.00, reads: 0.00, writes: 38960.16, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2129s] threads: 64, tps: 0.00, reads: 0.00, writes: 35753.02, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2130s] threads: 64, tps: 0.00, reads: 0.00, writes: 29044.00, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[2131s] threads: 64, tps: 0.00, reads: 0.00, writes: 29848.85, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[2132s] threads: 64, tps: 0.00, reads: 0.00, writes: 37275.15, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[2133s] threads: 64, tps: 0.00, reads: 0.00, writes: 32377.75, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[2134s] threads: 64, tps: 0.00, reads: 0.00, writes: 29189.24, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[2135s] threads: 64, tps: 0.00, reads: 0.00, writes: 29211.98, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[2136s] threads: 64, tps: 0.00, reads: 0.00, writes: 32364.93, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[2137s] threads: 64, tps: 0.00, reads: 0.00, writes: 32665.08, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[2138s] threads: 64, tps: 0.00, reads: 0.00, writes: 38255.04, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[2139s] threads: 64, tps: 0.00, reads: 0.00, writes: 39115.98, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2140s] threads: 64, tps: 0.00, reads: 0.00, writes: 32606.11, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[2141s] threads: 64, tps: 0.00, reads: 0.00, writes: 3126.08, response time: 21.44ms (95%), errors: 0.00, reconnects:  0.00
[2142s] threads: 64, tps: 0.00, reads: 0.00, writes: 3088.95, response time: 21.52ms (95%), errors: 0.00, reconnects:  0.00
[2143s] threads: 64, tps: 0.00, reads: 0.00, writes: 3102.99, response time: 21.75ms (95%), errors: 0.00, reconnects:  0.00
[2144s] threads: 64, tps: 0.00, reads: 0.00, writes: 3083.05, response time: 21.81ms (95%), errors: 0.00, reconnects:  0.00
[2145s] threads: 64, tps: 0.00, reads: 0.00, writes: 3094.96, response time: 21.51ms (95%), errors: 0.00, reconnects:  0.00
[2146s] threads: 64, tps: 0.00, reads: 0.00, writes: 3090.05, response time: 21.55ms (95%), errors: 0.00, reconnects:  0.00
[2147s] threads: 64, tps: 0.00, reads: 0.00, writes: 3095.00, response time: 21.82ms (95%), errors: 0.00, reconnects:  0.00
[2148s] threads: 64, tps: 0.00, reads: 0.00, writes: 3094.71, response time: 21.70ms (95%), errors: 0.00, reconnects:  0.00
[2149s] threads: 64, tps: 0.00, reads: 0.00, writes: 3089.27, response time: 21.62ms (95%), errors: 0.00, reconnects:  0.00
[2150s] threads: 64, tps: 0.00, reads: 0.00, writes: 12294.05, response time: 20.77ms (95%), errors: 0.00, reconnects:  0.00
[2151s] threads: 64, tps: 0.00, reads: 0.00, writes: 29000.98, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[2152s] threads: 64, tps: 0.00, reads: 0.00, writes: 28123.00, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[2153s] threads: 64, tps: 0.00, reads: 0.00, writes: 37842.47, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[2154s] threads: 64, tps: 0.00, reads: 0.00, writes: 31233.54, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[2155s] threads: 64, tps: 0.00, reads: 0.00, writes: 32645.21, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[2156s] threads: 64, tps: 0.00, reads: 0.00, writes: 33121.04, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[2157s] threads: 64, tps: 0.00, reads: 0.00, writes: 33555.92, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[2158s] threads: 64, tps: 0.00, reads: 0.00, writes: 33661.05, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2159s] threads: 64, tps: 0.00, reads: 0.00, writes: 38022.41, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2160s] threads: 64, tps: 0.00, reads: 0.00, writes: 34431.46, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[2161s] threads: 64, tps: 0.00, reads: 0.00, writes: 38744.04, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2162s] threads: 64, tps: 0.00, reads: 0.00, writes: 38521.96, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2163s] threads: 64, tps: 0.00, reads: 0.00, writes: 37593.00, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2164s] threads: 64, tps: 0.00, reads: 0.00, writes: 40886.91, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2165s] threads: 64, tps: 0.00, reads: 0.00, writes: 41070.10, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2166s] threads: 64, tps: 0.00, reads: 0.00, writes: 39110.07, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2167s] threads: 64, tps: 0.00, reads: 0.00, writes: 38448.94, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2168s] threads: 64, tps: 0.00, reads: 0.00, writes: 37225.89, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2169s] threads: 64, tps: 0.00, reads: 0.00, writes: 39506.08, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2170s] threads: 64, tps: 0.00, reads: 0.00, writes: 40806.94, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2171s] threads: 64, tps: 0.00, reads: 0.00, writes: 39313.02, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2172s] threads: 64, tps: 0.00, reads: 0.00, writes: 37565.99, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2173s] threads: 64, tps: 0.00, reads: 0.00, writes: 36627.99, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2174s] threads: 64, tps: 0.00, reads: 0.00, writes: 38181.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2175s] threads: 64, tps: 0.00, reads: 0.00, writes: 40282.52, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2176s] threads: 64, tps: 0.00, reads: 0.00, writes: 38469.78, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2177s] threads: 64, tps: 0.00, reads: 0.00, writes: 36648.05, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2178s] threads: 64, tps: 0.00, reads: 0.00, writes: 36082.11, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2179s] threads: 64, tps: 0.00, reads: 0.00, writes: 35530.88, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2180s] threads: 64, tps: 0.00, reads: 0.00, writes: 42194.97, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2181s] threads: 64, tps: 0.00, reads: 0.00, writes: 40107.23, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2182s] threads: 64, tps: 0.00, reads: 0.00, writes: 38051.90, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2183s] threads: 64, tps: 0.00, reads: 0.00, writes: 37322.88, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2184s] threads: 64, tps: 0.00, reads: 0.00, writes: 29987.97, response time: 3.49ms (95%), errors: 0.00, reconnects:  0.00
[2185s] threads: 64, tps: 0.00, reads: 0.00, writes: 33457.17, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[2186s] threads: 64, tps: 0.00, reads: 0.00, writes: 39914.81, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2187s] threads: 64, tps: 0.00, reads: 0.00, writes: 36876.15, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2188s] threads: 64, tps: 0.00, reads: 0.00, writes: 34945.02, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[2189s] threads: 64, tps: 0.00, reads: 0.00, writes: 35551.98, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2190s] threads: 64, tps: 0.00, reads: 0.00, writes: 33765.88, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[2191s] threads: 64, tps: 0.00, reads: 0.00, writes: 38136.14, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2192s] threads: 64, tps: 0.00, reads: 0.00, writes: 38069.01, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2193s] threads: 64, tps: 0.00, reads: 0.00, writes: 34175.98, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[2194s] threads: 64, tps: 0.00, reads: 0.00, writes: 33887.92, response time: 2.93ms (95%), errors: 0.00, reconnects:  0.00
[2195s] threads: 64, tps: 0.00, reads: 0.00, writes: 33338.13, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[2196s] threads: 64, tps: 0.00, reads: 0.00, writes: 25826.89, response time: 4.10ms (95%), errors: 0.00, reconnects:  0.00
[2197s] threads: 64, tps: 0.00, reads: 0.00, writes: 39310.14, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2198s] threads: 64, tps: 0.00, reads: 0.00, writes: 20566.98, response time: 20.40ms (95%), errors: 0.00, reconnects:  0.00
[2199s] threads: 64, tps: 0.00, reads: 0.00, writes: 30490.01, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[2200s] threads: 64, tps: 0.00, reads: 0.00, writes: 29902.91, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[2201s] threads: 64, tps: 0.00, reads: 0.00, writes: 34571.35, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2202s] threads: 64, tps: 0.00, reads: 0.00, writes: 36002.86, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[2203s] threads: 64, tps: 0.00, reads: 0.00, writes: 41091.96, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2204s] threads: 64, tps: 0.00, reads: 0.00, writes: 38101.00, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2205s] threads: 64, tps: 0.00, reads: 0.00, writes: 38893.05, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2206s] threads: 64, tps: 0.00, reads: 0.00, writes: 38156.13, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2207s] threads: 64, tps: 0.00, reads: 0.00, writes: 29600.49, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2208s] threads: 64, tps: 0.00, reads: 0.00, writes: 40256.19, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2209s] threads: 64, tps: 0.00, reads: 0.00, writes: 41100.02, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2210s] threads: 64, tps: 0.00, reads: 0.00, writes: 39388.03, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2211s] threads: 64, tps: 0.00, reads: 0.00, writes: 38458.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2212s] threads: 64, tps: 0.00, reads: 0.00, writes: 38073.99, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2213s] threads: 64, tps: 0.00, reads: 0.00, writes: 38674.01, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2214s] threads: 64, tps: 0.00, reads: 0.00, writes: 41236.75, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2215s] threads: 64, tps: 0.00, reads: 0.00, writes: 39952.21, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2216s] threads: 64, tps: 0.00, reads: 0.00, writes: 39064.00, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2217s] threads: 64, tps: 0.00, reads: 0.00, writes: 37600.04, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2218s] threads: 64, tps: 0.00, reads: 0.00, writes: 37500.04, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2219s] threads: 64, tps: 0.00, reads: 0.00, writes: 40904.93, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2220s] threads: 64, tps: 0.00, reads: 0.00, writes: 38754.83, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2221s] threads: 64, tps: 0.00, reads: 0.00, writes: 38581.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2222s] threads: 64, tps: 0.00, reads: 0.00, writes: 37037.16, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2223s] threads: 64, tps: 0.00, reads: 0.00, writes: 36106.01, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2224s] threads: 64, tps: 0.00, reads: 0.00, writes: 39413.90, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2225s] threads: 64, tps: 0.00, reads: 0.00, writes: 39776.05, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2226s] threads: 64, tps: 0.00, reads: 0.00, writes: 38677.96, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2227s] threads: 64, tps: 0.00, reads: 0.00, writes: 30846.00, response time: 3.50ms (95%), errors: 0.00, reconnects:  0.00
[2228s] threads: 64, tps: 0.00, reads: 0.00, writes: 28347.96, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[2229s] threads: 64, tps: 0.00, reads: 0.00, writes: 29555.05, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[2230s] threads: 64, tps: 0.00, reads: 0.00, writes: 39655.86, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2231s] threads: 64, tps: 0.00, reads: 0.00, writes: 31923.10, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[2232s] threads: 64, tps: 0.00, reads: 0.00, writes: 27606.03, response time: 3.84ms (95%), errors: 0.00, reconnects:  0.00
[2233s] threads: 64, tps: 0.00, reads: 0.00, writes: 32412.05, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[2234s] threads: 64, tps: 0.00, reads: 0.00, writes: 34762.99, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[2235s] threads: 64, tps: 0.00, reads: 0.00, writes: 35272.94, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2236s] threads: 64, tps: 0.00, reads: 0.00, writes: 41371.10, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2237s] threads: 64, tps: 0.00, reads: 0.00, writes: 38676.88, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2238s] threads: 64, tps: 0.00, reads: 0.00, writes: 33172.90, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2239s] threads: 64, tps: 0.00, reads: 0.00, writes: 3091.04, response time: 21.54ms (95%), errors: 0.00, reconnects:  0.00
[2240s] threads: 64, tps: 0.00, reads: 0.00, writes: 3103.06, response time: 21.64ms (95%), errors: 0.00, reconnects:  0.00
[2241s] threads: 64, tps: 0.00, reads: 0.00, writes: 3088.98, response time: 21.55ms (95%), errors: 0.00, reconnects:  0.00
[2242s] threads: 64, tps: 0.00, reads: 0.00, writes: 3105.00, response time: 21.68ms (95%), errors: 0.00, reconnects:  0.00
[2243s] threads: 64, tps: 0.00, reads: 0.00, writes: 3078.02, response time: 21.63ms (95%), errors: 0.00, reconnects:  0.00
[2244s] threads: 64, tps: 0.00, reads: 0.00, writes: 3102.99, response time: 21.71ms (95%), errors: 0.00, reconnects:  0.00
[2245s] threads: 64, tps: 0.00, reads: 0.00, writes: 3092.00, response time: 21.60ms (95%), errors: 0.00, reconnects:  0.00
[2246s] threads: 64, tps: 0.00, reads: 0.00, writes: 3072.01, response time: 21.64ms (95%), errors: 0.00, reconnects:  0.00
[2247s] threads: 64, tps: 0.00, reads: 0.00, writes: 14794.96, response time: 20.74ms (95%), errors: 0.00, reconnects:  0.00
[2248s] threads: 64, tps: 0.00, reads: 0.00, writes: 32547.37, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[2249s] threads: 64, tps: 0.00, reads: 0.00, writes: 38783.83, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2250s] threads: 64, tps: 0.00, reads: 0.00, writes: 39606.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2251s] threads: 64, tps: 0.00, reads: 0.00, writes: 39544.99, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2252s] threads: 64, tps: 0.00, reads: 0.00, writes: 38180.04, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2253s] threads: 64, tps: 0.00, reads: 0.00, writes: 37671.87, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2254s] threads: 64, tps: 0.00, reads: 0.00, writes: 40046.96, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2255s] threads: 64, tps: 0.00, reads: 0.00, writes: 41023.03, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2256s] threads: 64, tps: 0.00, reads: 0.00, writes: 37861.18, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2257s] threads: 64, tps: 0.00, reads: 0.00, writes: 38349.81, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2258s] threads: 64, tps: 0.00, reads: 0.00, writes: 37321.99, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2259s] threads: 64, tps: 0.00, reads: 0.00, writes: 38730.17, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2260s] threads: 64, tps: 0.00, reads: 0.00, writes: 41564.83, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2261s] threads: 64, tps: 0.00, reads: 0.00, writes: 40306.12, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2262s] threads: 64, tps: 0.00, reads: 0.00, writes: 31043.87, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2263s] threads: 64, tps: 0.00, reads: 0.00, writes: 38577.12, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2264s] threads: 64, tps: 0.00, reads: 0.00, writes: 38049.11, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2265s] threads: 64, tps: 0.00, reads: 0.00, writes: 42325.40, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2266s] threads: 64, tps: 0.00, reads: 0.00, writes: 40002.58, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2267s] threads: 64, tps: 0.00, reads: 0.00, writes: 35832.79, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2268s] threads: 64, tps: 0.00, reads: 0.00, writes: 35894.15, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2269s] threads: 64, tps: 0.00, reads: 0.00, writes: 33718.90, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[2270s] threads: 64, tps: 0.00, reads: 0.00, writes: 35949.67, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[2271s] threads: 64, tps: 0.00, reads: 0.00, writes: 36270.45, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[2272s] threads: 64, tps: 0.00, reads: 0.00, writes: 27262.00, response time: 3.86ms (95%), errors: 0.00, reconnects:  0.00
[2273s] threads: 64, tps: 0.00, reads: 0.00, writes: 28251.86, response time: 3.58ms (95%), errors: 0.00, reconnects:  0.00
[2274s] threads: 64, tps: 0.00, reads: 0.00, writes: 27703.10, response time: 3.72ms (95%), errors: 0.00, reconnects:  0.00
[2275s] threads: 64, tps: 0.00, reads: 0.00, writes: 28241.03, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[2276s] threads: 64, tps: 0.00, reads: 0.00, writes: 29475.02, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[2277s] threads: 64, tps: 0.00, reads: 0.00, writes: 39864.77, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[2278s] threads: 64, tps: 0.00, reads: 0.00, writes: 31442.11, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[2279s] threads: 64, tps: 0.00, reads: 0.00, writes: 31357.01, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[2280s] threads: 64, tps: 0.00, reads: 0.00, writes: 35423.06, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2281s] threads: 64, tps: 0.00, reads: 0.00, writes: 34340.84, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[2282s] threads: 64, tps: 0.00, reads: 0.00, writes: 36174.16, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[2283s] threads: 64, tps: 0.00, reads: 0.00, writes: 39346.01, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2284s] threads: 64, tps: 0.00, reads: 0.00, writes: 37509.98, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2285s] threads: 64, tps: 0.00, reads: 0.00, writes: 35439.95, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2286s] threads: 64, tps: 0.00, reads: 0.00, writes: 34908.57, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[2287s] threads: 64, tps: 0.00, reads: 0.00, writes: 34025.34, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[2288s] threads: 64, tps: 0.00, reads: 0.00, writes: 38865.88, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2289s] threads: 64, tps: 0.00, reads: 0.00, writes: 34974.14, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[2290s] threads: 64, tps: 0.00, reads: 0.00, writes: 27836.98, response time: 3.82ms (95%), errors: 0.00, reconnects:  0.00
[2291s] threads: 64, tps: 0.00, reads: 0.00, writes: 29708.92, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[2292s] threads: 64, tps: 0.00, reads: 0.00, writes: 30604.08, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[2293s] threads: 64, tps: 0.00, reads: 0.00, writes: 36135.99, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2294s] threads: 64, tps: 0.00, reads: 0.00, writes: 40554.06, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2295s] threads: 64, tps: 0.00, reads: 0.00, writes: 39973.76, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2296s] threads: 64, tps: 0.00, reads: 0.00, writes: 38125.23, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2297s] threads: 64, tps: 0.00, reads: 0.00, writes: 38695.98, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2298s] threads: 64, tps: 0.00, reads: 0.00, writes: 38314.02, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2299s] threads: 64, tps: 0.00, reads: 0.00, writes: 41169.86, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2300s] threads: 64, tps: 0.00, reads: 0.00, writes: 40686.09, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2301s] threads: 64, tps: 0.00, reads: 0.00, writes: 39861.03, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2302s] threads: 64, tps: 0.00, reads: 0.00, writes: 38791.76, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2303s] threads: 64, tps: 0.00, reads: 0.00, writes: 38295.17, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2304s] threads: 64, tps: 0.00, reads: 0.00, writes: 41059.04, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2305s] threads: 64, tps: 0.00, reads: 0.00, writes: 39925.84, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2306s] threads: 64, tps: 0.00, reads: 0.00, writes: 39347.15, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2307s] threads: 64, tps: 0.00, reads: 0.00, writes: 37780.04, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2308s] threads: 64, tps: 0.00, reads: 0.00, writes: 36518.98, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2309s] threads: 64, tps: 0.00, reads: 0.00, writes: 38837.96, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2310s] threads: 64, tps: 0.00, reads: 0.00, writes: 35147.83, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2311s] threads: 64, tps: 0.00, reads: 0.00, writes: 39562.20, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2312s] threads: 64, tps: 0.00, reads: 0.00, writes: 38685.06, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2313s] threads: 64, tps: 0.00, reads: 0.00, writes: 37738.96, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2314s] threads: 64, tps: 0.00, reads: 0.00, writes: 37154.85, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2315s] threads: 64, tps: 0.00, reads: 0.00, writes: 42460.61, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2316s] threads: 64, tps: 0.00, reads: 0.00, writes: 39380.96, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2317s] threads: 64, tps: 0.00, reads: 0.00, writes: 37202.97, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2318s] threads: 64, tps: 0.00, reads: 0.00, writes: 35973.07, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[2319s] threads: 64, tps: 0.00, reads: 0.00, writes: 30771.95, response time: 3.45ms (95%), errors: 0.00, reconnects:  0.00
[2320s] threads: 64, tps: 0.00, reads: 0.00, writes: 38352.03, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2321s] threads: 64, tps: 0.00, reads: 0.00, writes: 39032.84, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2322s] threads: 64, tps: 0.00, reads: 0.00, writes: 35924.16, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[2323s] threads: 64, tps: 0.00, reads: 0.00, writes: 34997.99, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[2324s] threads: 64, tps: 0.00, reads: 0.00, writes: 35615.86, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2325s] threads: 64, tps: 0.00, reads: 0.00, writes: 34872.19, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[2326s] threads: 64, tps: 0.00, reads: 0.00, writes: 40238.92, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2327s] threads: 64, tps: 0.00, reads: 0.00, writes: 37909.09, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2328s] threads: 64, tps: 0.00, reads: 0.00, writes: 34947.78, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[2329s] threads: 64, tps: 0.00, reads: 0.00, writes: 31906.15, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[2330s] threads: 64, tps: 0.00, reads: 0.00, writes: 29621.99, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[2331s] threads: 64, tps: 0.00, reads: 0.00, writes: 29950.03, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[2332s] threads: 64, tps: 0.00, reads: 0.00, writes: 39469.85, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2333s] threads: 64, tps: 0.00, reads: 0.00, writes: 19479.70, response time: 19.93ms (95%), errors: 0.00, reconnects:  0.00
[2334s] threads: 64, tps: 0.00, reads: 0.00, writes: 30645.57, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[2335s] threads: 64, tps: 0.00, reads: 0.00, writes: 34828.02, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2336s] threads: 64, tps: 0.00, reads: 0.00, writes: 37152.11, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2337s] threads: 64, tps: 0.00, reads: 0.00, writes: 36550.85, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2338s] threads: 64, tps: 0.00, reads: 0.00, writes: 41706.05, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2339s] threads: 64, tps: 0.00, reads: 0.00, writes: 39716.00, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2340s] threads: 64, tps: 0.00, reads: 0.00, writes: 39216.96, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2341s] threads: 64, tps: 0.00, reads: 0.00, writes: 37673.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2342s] threads: 64, tps: 0.00, reads: 0.00, writes: 38648.03, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2343s] threads: 64, tps: 0.00, reads: 0.00, writes: 43459.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2344s] threads: 64, tps: 0.00, reads: 0.00, writes: 39374.96, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2345s] threads: 64, tps: 0.00, reads: 0.00, writes: 38869.50, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2346s] threads: 64, tps: 0.00, reads: 0.00, writes: 37707.53, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2347s] threads: 64, tps: 0.00, reads: 0.00, writes: 37355.29, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2348s] threads: 64, tps: 0.00, reads: 0.00, writes: 42170.69, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2349s] threads: 64, tps: 0.00, reads: 0.00, writes: 40128.06, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2350s] threads: 64, tps: 0.00, reads: 0.00, writes: 38924.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2351s] threads: 64, tps: 0.00, reads: 0.00, writes: 37580.02, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2352s] threads: 64, tps: 0.00, reads: 0.00, writes: 37878.94, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2353s] threads: 64, tps: 0.00, reads: 0.00, writes: 40823.07, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2354s] threads: 64, tps: 0.00, reads: 0.00, writes: 40378.94, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2355s] threads: 64, tps: 0.00, reads: 0.00, writes: 38814.02, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2356s] threads: 64, tps: 0.00, reads: 0.00, writes: 36784.94, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2357s] threads: 64, tps: 0.00, reads: 0.00, writes: 31548.34, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2358s] threads: 64, tps: 0.00, reads: 0.00, writes: 37751.85, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2359s] threads: 64, tps: 0.00, reads: 0.00, writes: 40173.03, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2360s] threads: 64, tps: 0.00, reads: 0.00, writes: 37742.96, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2361s] threads: 64, tps: 0.00, reads: 0.00, writes: 36618.01, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2362s] threads: 64, tps: 0.00, reads: 0.00, writes: 29426.00, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[2363s] threads: 64, tps: 0.00, reads: 0.00, writes: 28700.95, response time: 3.43ms (95%), errors: 0.00, reconnects:  0.00
[2364s] threads: 64, tps: 0.00, reads: 0.00, writes: 37253.12, response time: 2.98ms (95%), errors: 0.00, reconnects:  0.00
[2365s] threads: 64, tps: 0.00, reads: 0.00, writes: 34637.99, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[2366s] threads: 64, tps: 0.00, reads: 0.00, writes: 29043.87, response time: 3.52ms (95%), errors: 0.00, reconnects:  0.00
[2367s] threads: 64, tps: 0.00, reads: 0.00, writes: 28920.12, response time: 3.67ms (95%), errors: 0.00, reconnects:  0.00
[2368s] threads: 64, tps: 0.00, reads: 0.00, writes: 34258.99, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[2369s] threads: 64, tps: 0.00, reads: 0.00, writes: 34357.96, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[2370s] threads: 64, tps: 0.00, reads: 0.00, writes: 39582.04, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2371s] threads: 64, tps: 0.00, reads: 0.00, writes: 39853.03, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2372s] threads: 64, tps: 0.00, reads: 0.00, writes: 30611.87, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[2373s] threads: 64, tps: 0.00, reads: 0.00, writes: 3087.01, response time: 21.49ms (95%), errors: 0.00, reconnects:  0.00
[2374s] threads: 64, tps: 0.00, reads: 0.00, writes: 3095.00, response time: 21.56ms (95%), errors: 0.00, reconnects:  0.00
[2375s] threads: 64, tps: 0.00, reads: 0.00, writes: 3080.92, response time: 21.63ms (95%), errors: 0.00, reconnects:  0.00
[2376s] threads: 64, tps: 0.00, reads: 0.00, writes: 3095.99, response time: 21.53ms (95%), errors: 0.00, reconnects:  0.00
[2377s] threads: 64, tps: 0.00, reads: 0.00, writes: 3100.07, response time: 21.68ms (95%), errors: 0.00, reconnects:  0.00
[2378s] threads: 64, tps: 0.00, reads: 0.00, writes: 3103.99, response time: 21.61ms (95%), errors: 0.00, reconnects:  0.00
[2379s] threads: 64, tps: 0.00, reads: 0.00, writes: 3084.02, response time: 21.67ms (95%), errors: 0.00, reconnects:  0.00
[2380s] threads: 64, tps: 0.00, reads: 0.00, writes: 3068.88, response time: 22.13ms (95%), errors: 0.00, reconnects:  0.00
[2381s] threads: 64, tps: 0.00, reads: 0.00, writes: 3118.11, response time: 21.70ms (95%), errors: 0.00, reconnects:  0.00
[2382s] threads: 64, tps: 0.00, reads: 0.00, writes: 8497.03, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[2383s] threads: 64, tps: 0.00, reads: 0.00, writes: 30926.97, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[2384s] threads: 64, tps: 0.00, reads: 0.00, writes: 34046.01, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[2385s] threads: 64, tps: 0.00, reads: 0.00, writes: 41188.97, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2386s] threads: 64, tps: 0.00, reads: 0.00, writes: 36610.01, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2387s] threads: 64, tps: 0.00, reads: 0.00, writes: 37145.99, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2388s] threads: 64, tps: 0.00, reads: 0.00, writes: 38027.09, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2389s] threads: 64, tps: 0.00, reads: 0.00, writes: 37390.95, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2390s] threads: 64, tps: 0.00, reads: 0.00, writes: 42014.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2391s] threads: 64, tps: 0.00, reads: 0.00, writes: 39239.01, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2392s] threads: 64, tps: 0.00, reads: 0.00, writes: 39719.05, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2393s] threads: 64, tps: 0.00, reads: 0.00, writes: 38755.03, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2394s] threads: 64, tps: 0.00, reads: 0.00, writes: 38409.75, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2395s] threads: 64, tps: 0.00, reads: 0.00, writes: 42652.29, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2396s] threads: 64, tps: 0.00, reads: 0.00, writes: 41134.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2397s] threads: 64, tps: 0.00, reads: 0.00, writes: 39997.05, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2398s] threads: 64, tps: 0.00, reads: 0.00, writes: 39562.02, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2399s] threads: 64, tps: 0.00, reads: 0.00, writes: 38835.96, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2400s] threads: 64, tps: 0.00, reads: 0.00, writes: 41732.04, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2401s] threads: 64, tps: 0.00, reads: 0.00, writes: 39716.01, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2402s] threads: 64, tps: 0.00, reads: 0.00, writes: 39131.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2403s] threads: 64, tps: 0.00, reads: 0.00, writes: 37016.99, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2404s] threads: 64, tps: 0.00, reads: 0.00, writes: 36704.96, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2405s] threads: 64, tps: 0.00, reads: 0.00, writes: 40472.04, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2406s] threads: 64, tps: 0.00, reads: 0.00, writes: 41230.90, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2407s] threads: 64, tps: 0.00, reads: 0.00, writes: 39144.09, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2408s] threads: 64, tps: 0.00, reads: 0.00, writes: 38749.05, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2409s] threads: 64, tps: 0.00, reads: 0.00, writes: 38202.96, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2410s] threads: 64, tps: 0.00, reads: 0.00, writes: 40216.94, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2411s] threads: 64, tps: 0.00, reads: 0.00, writes: 39357.05, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2412s] threads: 64, tps: 0.00, reads: 0.00, writes: 37820.01, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2413s] threads: 64, tps: 0.00, reads: 0.00, writes: 25795.82, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[2414s] threads: 64, tps: 0.00, reads: 0.00, writes: 34130.21, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[2415s] threads: 64, tps: 0.00, reads: 0.00, writes: 30290.05, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[2416s] threads: 64, tps: 0.00, reads: 0.00, writes: 35164.97, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[2417s] threads: 64, tps: 0.00, reads: 0.00, writes: 35388.03, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[2418s] threads: 64, tps: 0.00, reads: 0.00, writes: 28699.59, response time: 3.47ms (95%), errors: 0.00, reconnects:  0.00
[2419s] threads: 64, tps: 0.00, reads: 0.00, writes: 33513.61, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[2420s] threads: 64, tps: 0.00, reads: 0.00, writes: 34834.01, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2421s] threads: 64, tps: 0.00, reads: 0.00, writes: 33820.96, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[2422s] threads: 64, tps: 0.00, reads: 0.00, writes: 39342.03, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[2423s] threads: 64, tps: 0.00, reads: 0.00, writes: 39597.96, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2424s] threads: 64, tps: 0.00, reads: 0.00, writes: 35850.02, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[2425s] threads: 64, tps: 0.00, reads: 0.00, writes: 34910.01, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[2426s] threads: 64, tps: 0.00, reads: 0.00, writes: 35212.06, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[2427s] threads: 64, tps: 0.00, reads: 0.00, writes: 36821.89, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2428s] threads: 64, tps: 0.00, reads: 0.00, writes: 40750.13, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2429s] threads: 64, tps: 0.00, reads: 0.00, writes: 37897.57, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2430s] threads: 64, tps: 0.00, reads: 0.00, writes: 13468.56, response time: 20.86ms (95%), errors: 0.00, reconnects:  0.00
[2431s] threads: 64, tps: 0.00, reads: 0.00, writes: 3092.01, response time: 21.73ms (95%), errors: 0.00, reconnects:  0.00
[2432s] threads: 64, tps: 0.00, reads: 0.00, writes: 10064.30, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[2433s] threads: 64, tps: 0.00, reads: 0.00, writes: 29060.01, response time: 3.31ms (95%), errors: 0.00, reconnects:  0.00
[2434s] threads: 64, tps: 0.00, reads: 0.00, writes: 29995.96, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[2435s] threads: 64, tps: 0.00, reads: 0.00, writes: 35652.05, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2436s] threads: 64, tps: 0.00, reads: 0.00, writes: 40080.97, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2437s] threads: 64, tps: 0.00, reads: 0.00, writes: 37227.01, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2438s] threads: 64, tps: 0.00, reads: 0.00, writes: 35959.05, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2439s] threads: 64, tps: 0.00, reads: 0.00, writes: 36120.98, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2440s] threads: 64, tps: 0.00, reads: 0.00, writes: 36764.97, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2441s] threads: 64, tps: 0.00, reads: 0.00, writes: 40883.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2442s] threads: 64, tps: 0.00, reads: 0.00, writes: 38591.95, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2443s] threads: 64, tps: 0.00, reads: 0.00, writes: 38049.08, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2444s] threads: 64, tps: 0.00, reads: 0.00, writes: 37159.96, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[2445s] threads: 64, tps: 0.00, reads: 0.00, writes: 36473.03, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2446s] threads: 64, tps: 0.00, reads: 0.00, writes: 39906.00, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2447s] threads: 64, tps: 0.00, reads: 0.00, writes: 39037.94, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2448s] threads: 64, tps: 0.00, reads: 0.00, writes: 38866.06, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2449s] threads: 64, tps: 0.00, reads: 0.00, writes: 37408.01, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2450s] threads: 64, tps: 0.00, reads: 0.00, writes: 37865.99, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2451s] threads: 64, tps: 0.00, reads: 0.00, writes: 39542.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2452s] threads: 64, tps: 0.00, reads: 0.00, writes: 39835.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2453s] threads: 64, tps: 0.00, reads: 0.00, writes: 38627.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2454s] threads: 64, tps: 0.00, reads: 0.00, writes: 37964.00, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2455s] threads: 64, tps: 0.00, reads: 0.00, writes: 37030.97, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2456s] threads: 64, tps: 0.00, reads: 0.00, writes: 37553.22, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2457s] threads: 64, tps: 0.00, reads: 0.00, writes: 39737.88, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2458s] threads: 64, tps: 0.00, reads: 0.00, writes: 36776.92, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2459s] threads: 64, tps: 0.00, reads: 0.00, writes: 36861.05, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2460s] threads: 64, tps: 0.00, reads: 0.00, writes: 32226.00, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[2461s] threads: 64, tps: 0.00, reads: 0.00, writes: 31749.97, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[2462s] threads: 64, tps: 0.00, reads: 0.00, writes: 38851.58, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2463s] threads: 64, tps: 0.00, reads: 0.00, writes: 34802.29, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2464s] threads: 64, tps: 0.00, reads: 0.00, writes: 27791.44, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[2465s] threads: 64, tps: 0.00, reads: 0.00, writes: 31701.48, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[2466s] threads: 64, tps: 0.00, reads: 0.00, writes: 34814.08, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[2467s] threads: 64, tps: 0.00, reads: 0.00, writes: 33984.92, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[2468s] threads: 64, tps: 0.00, reads: 0.00, writes: 36806.03, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[2469s] threads: 64, tps: 0.00, reads: 0.00, writes: 39729.00, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2470s] threads: 64, tps: 0.00, reads: 0.00, writes: 36722.00, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2471s] threads: 64, tps: 0.00, reads: 0.00, writes: 34403.99, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[2472s] threads: 64, tps: 0.00, reads: 0.00, writes: 34761.96, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[2473s] threads: 64, tps: 0.00, reads: 0.00, writes: 34511.33, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[2474s] threads: 64, tps: 0.00, reads: 0.00, writes: 40413.90, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2475s] threads: 64, tps: 0.00, reads: 0.00, writes: 38545.96, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2476s] threads: 64, tps: 0.00, reads: 0.00, writes: 16725.91, response time: 20.69ms (95%), errors: 0.00, reconnects:  0.00
[2477s] threads: 64, tps: 0.00, reads: 0.00, writes: 3090.94, response time: 21.39ms (95%), errors: 0.00, reconnects:  0.00
[2478s] threads: 64, tps: 0.00, reads: 0.00, writes: 5801.14, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[2479s] threads: 64, tps: 0.00, reads: 0.00, writes: 30978.03, response time: 3.08ms (95%), errors: 0.00, reconnects:  0.00
[2480s] threads: 64, tps: 0.00, reads: 0.00, writes: 29905.47, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[2481s] threads: 64, tps: 0.00, reads: 0.00, writes: 34306.55, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2482s] threads: 64, tps: 0.00, reads: 0.00, writes: 42020.06, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2483s] threads: 64, tps: 0.00, reads: 0.00, writes: 38604.02, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2484s] threads: 64, tps: 0.00, reads: 0.00, writes: 38268.01, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2485s] threads: 64, tps: 0.00, reads: 0.00, writes: 37490.01, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2486s] threads: 64, tps: 0.00, reads: 0.00, writes: 37433.97, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2487s] threads: 64, tps: 0.00, reads: 0.00, writes: 42028.96, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2488s] threads: 64, tps: 0.00, reads: 0.00, writes: 40992.86, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2489s] threads: 64, tps: 0.00, reads: 0.00, writes: 40210.20, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2490s] threads: 64, tps: 0.00, reads: 0.00, writes: 38420.81, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2491s] threads: 64, tps: 0.00, reads: 0.00, writes: 37915.22, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2492s] threads: 64, tps: 0.00, reads: 0.00, writes: 41704.76, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2493s] threads: 64, tps: 0.00, reads: 0.00, writes: 39869.19, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2494s] threads: 64, tps: 0.00, reads: 0.00, writes: 39137.93, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2495s] threads: 64, tps: 0.00, reads: 0.00, writes: 35984.02, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2496s] threads: 64, tps: 0.00, reads: 0.00, writes: 37406.02, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2497s] threads: 64, tps: 0.00, reads: 0.00, writes: 30028.00, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[2498s] threads: 64, tps: 0.00, reads: 0.00, writes: 40526.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2499s] threads: 64, tps: 0.00, reads: 0.00, writes: 39134.00, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2500s] threads: 64, tps: 0.00, reads: 0.00, writes: 37461.95, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2501s] threads: 64, tps: 0.00, reads: 0.00, writes: 36913.01, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2502s] threads: 64, tps: 0.00, reads: 0.00, writes: 37847.03, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2503s] threads: 64, tps: 0.00, reads: 0.00, writes: 42238.98, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2504s] threads: 64, tps: 0.00, reads: 0.00, writes: 39826.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2505s] threads: 64, tps: 0.00, reads: 0.00, writes: 38866.01, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2506s] threads: 64, tps: 0.00, reads: 0.00, writes: 38002.95, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2507s] threads: 64, tps: 0.00, reads: 0.00, writes: 35526.82, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[2508s] threads: 64, tps: 0.00, reads: 0.00, writes: 41751.19, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2509s] threads: 64, tps: 0.00, reads: 0.00, writes: 39612.04, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2510s] threads: 64, tps: 0.00, reads: 0.00, writes: 37168.95, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2511s] threads: 64, tps: 0.00, reads: 0.00, writes: 32667.04, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[2512s] threads: 64, tps: 0.00, reads: 0.00, writes: 28426.00, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[2513s] threads: 64, tps: 0.00, reads: 0.00, writes: 26101.99, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[2514s] threads: 64, tps: 0.00, reads: 0.00, writes: 38302.98, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2515s] threads: 64, tps: 0.00, reads: 0.00, writes: 30308.02, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[2516s] threads: 64, tps: 0.00, reads: 0.00, writes: 31716.99, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[2517s] threads: 64, tps: 0.00, reads: 0.00, writes: 32191.98, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[2518s] threads: 64, tps: 0.00, reads: 0.00, writes: 35190.06, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[2519s] threads: 64, tps: 0.00, reads: 0.00, writes: 36753.93, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2520s] threads: 64, tps: 0.00, reads: 0.00, writes: 40092.03, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2521s] threads: 64, tps: 0.00, reads: 0.00, writes: 37656.04, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[2522s] threads: 64, tps: 0.00, reads: 0.00, writes: 18110.02, response time: 20.72ms (95%), errors: 0.00, reconnects:  0.00
[2523s] threads: 64, tps: 0.00, reads: 0.00, writes: 3101.98, response time: 21.70ms (95%), errors: 0.00, reconnects:  0.00
[2524s] threads: 64, tps: 0.00, reads: 0.00, writes: 3097.00, response time: 21.35ms (95%), errors: 0.00, reconnects:  0.00
[2525s] threads: 64, tps: 0.00, reads: 0.00, writes: 3087.96, response time: 21.40ms (95%), errors: 0.00, reconnects:  0.00
[2526s] threads: 64, tps: 0.00, reads: 0.00, writes: 3082.97, response time: 21.55ms (95%), errors: 0.00, reconnects:  0.00
[2527s] threads: 64, tps: 0.00, reads: 0.00, writes: 3095.02, response time: 21.37ms (95%), errors: 0.00, reconnects:  0.00
[2528s] threads: 64, tps: 0.00, reads: 0.00, writes: 3110.07, response time: 21.59ms (95%), errors: 0.00, reconnects:  0.00
[2529s] threads: 64, tps: 0.00, reads: 0.00, writes: 3076.01, response time: 21.61ms (95%), errors: 0.00, reconnects:  0.00
[2530s] threads: 64, tps: 0.00, reads: 0.00, writes: 3108.00, response time: 21.76ms (95%), errors: 0.00, reconnects:  0.00
[2531s] threads: 64, tps: 0.00, reads: 0.00, writes: 3086.00, response time: 21.57ms (95%), errors: 0.00, reconnects:  0.00
[2532s] threads: 64, tps: 0.00, reads: 0.00, writes: 26077.02, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[2533s] threads: 64, tps: 0.00, reads: 0.00, writes: 34798.95, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2534s] threads: 64, tps: 0.00, reads: 0.00, writes: 41197.06, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2535s] threads: 64, tps: 0.00, reads: 0.00, writes: 39053.97, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2536s] threads: 64, tps: 0.00, reads: 0.00, writes: 39756.97, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2537s] threads: 64, tps: 0.00, reads: 0.00, writes: 39296.10, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2538s] threads: 64, tps: 0.00, reads: 0.00, writes: 38080.97, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2539s] threads: 64, tps: 0.00, reads: 0.00, writes: 41913.04, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2540s] threads: 64, tps: 0.00, reads: 0.00, writes: 40991.97, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2541s] threads: 64, tps: 0.00, reads: 0.00, writes: 39755.99, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2542s] threads: 64, tps: 0.00, reads: 0.00, writes: 38377.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2543s] threads: 64, tps: 0.00, reads: 0.00, writes: 38542.95, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2544s] threads: 64, tps: 0.00, reads: 0.00, writes: 41966.99, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2545s] threads: 64, tps: 0.00, reads: 0.00, writes: 41285.05, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2546s] threads: 64, tps: 0.00, reads: 0.00, writes: 39634.84, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2547s] threads: 64, tps: 0.00, reads: 0.00, writes: 37979.17, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2548s] threads: 64, tps: 0.00, reads: 0.00, writes: 38133.02, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2549s] threads: 64, tps: 0.00, reads: 0.00, writes: 40662.98, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2550s] threads: 64, tps: 0.00, reads: 0.00, writes: 42241.92, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2551s] threads: 64, tps: 0.00, reads: 0.00, writes: 38816.08, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2552s] threads: 64, tps: 0.00, reads: 0.00, writes: 38883.96, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2553s] threads: 64, tps: 0.00, reads: 0.00, writes: 37142.07, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2554s] threads: 64, tps: 0.00, reads: 0.00, writes: 42037.96, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2555s] threads: 64, tps: 0.00, reads: 0.00, writes: 38946.03, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2556s] threads: 64, tps: 0.00, reads: 0.00, writes: 39667.95, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2557s] threads: 64, tps: 0.00, reads: 0.00, writes: 36828.97, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2558s] threads: 64, tps: 0.00, reads: 0.00, writes: 28807.02, response time: 3.66ms (95%), errors: 0.00, reconnects:  0.00
[2559s] threads: 64, tps: 0.00, reads: 0.00, writes: 27667.97, response time: 3.66ms (95%), errors: 0.00, reconnects:  0.00
[2560s] threads: 64, tps: 0.00, reads: 0.00, writes: 38637.04, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[2561s] threads: 64, tps: 0.00, reads: 0.00, writes: 32042.99, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[2562s] threads: 64, tps: 0.00, reads: 0.00, writes: 28127.00, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[2563s] threads: 64, tps: 0.00, reads: 0.00, writes: 28559.98, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[2564s] threads: 64, tps: 0.00, reads: 0.00, writes: 29213.02, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[2565s] threads: 64, tps: 0.00, reads: 0.00, writes: 27737.00, response time: 3.65ms (95%), errors: 0.00, reconnects:  0.00
[2566s] threads: 64, tps: 0.00, reads: 0.00, writes: 31622.04, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[2567s] threads: 64, tps: 0.00, reads: 0.00, writes: 37769.98, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[2568s] threads: 64, tps: 0.00, reads: 0.00, writes: 33438.97, response time: 3.06ms (95%), errors: 0.00, reconnects:  0.00
[2569s] threads: 64, tps: 0.00, reads: 0.00, writes: 35688.03, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2570s] threads: 64, tps: 0.00, reads: 0.00, writes: 28303.99, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[2571s] threads: 64, tps: 0.00, reads: 0.00, writes: 34423.71, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2572s] threads: 64, tps: 0.00, reads: 0.00, writes: 37736.27, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[2573s] threads: 64, tps: 0.00, reads: 0.00, writes: 39144.06, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2574s] threads: 64, tps: 0.00, reads: 0.00, writes: 36331.94, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[2575s] threads: 64, tps: 0.00, reads: 0.00, writes: 34875.04, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[2576s] threads: 64, tps: 0.00, reads: 0.00, writes: 35203.05, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[2577s] threads: 64, tps: 0.00, reads: 0.00, writes: 33474.99, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[2578s] threads: 64, tps: 0.00, reads: 0.00, writes: 38556.34, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2579s] threads: 64, tps: 0.00, reads: 0.00, writes: 21868.49, response time: 18.91ms (95%), errors: 0.00, reconnects:  0.00
[2580s] threads: 64, tps: 0.00, reads: 0.00, writes: 3099.12, response time: 21.68ms (95%), errors: 0.00, reconnects:  0.00
[2581s] threads: 64, tps: 0.00, reads: 0.00, writes: 24198.05, response time: 3.71ms (95%), errors: 0.00, reconnects:  0.00
[2582s] threads: 64, tps: 0.00, reads: 0.00, writes: 29450.73, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[2583s] threads: 64, tps: 0.00, reads: 0.00, writes: 32101.29, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[2584s] threads: 64, tps: 0.00, reads: 0.00, writes: 34397.44, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[2585s] threads: 64, tps: 0.00, reads: 0.00, writes: 39094.60, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2586s] threads: 64, tps: 0.00, reads: 0.00, writes: 39930.99, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2587s] threads: 64, tps: 0.00, reads: 0.00, writes: 39247.00, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2588s] threads: 64, tps: 0.00, reads: 0.00, writes: 38868.04, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2589s] threads: 64, tps: 0.00, reads: 0.00, writes: 37730.94, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2590s] threads: 64, tps: 0.00, reads: 0.00, writes: 39031.07, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2591s] threads: 64, tps: 0.00, reads: 0.00, writes: 41510.96, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2592s] threads: 64, tps: 0.00, reads: 0.00, writes: 39318.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2593s] threads: 64, tps: 0.00, reads: 0.00, writes: 38459.95, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2594s] threads: 64, tps: 0.00, reads: 0.00, writes: 37253.09, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2595s] threads: 64, tps: 0.00, reads: 0.00, writes: 36303.96, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2596s] threads: 64, tps: 0.00, reads: 0.00, writes: 42421.03, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2597s] threads: 64, tps: 0.00, reads: 0.00, writes: 40086.88, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2598s] threads: 64, tps: 0.00, reads: 0.00, writes: 37131.11, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2599s] threads: 64, tps: 0.00, reads: 0.00, writes: 37941.94, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2600s] threads: 64, tps: 0.00, reads: 0.00, writes: 36428.03, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2601s] threads: 64, tps: 0.00, reads: 0.00, writes: 42100.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2602s] threads: 64, tps: 0.00, reads: 0.00, writes: 39716.97, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2603s] threads: 64, tps: 0.00, reads: 0.00, writes: 34177.07, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[2604s] threads: 64, tps: 0.00, reads: 0.00, writes: 37574.98, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2605s] threads: 64, tps: 0.00, reads: 0.00, writes: 34286.97, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[2606s] threads: 64, tps: 0.00, reads: 0.00, writes: 35446.85, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[2607s] threads: 64, tps: 0.00, reads: 0.00, writes: 35666.99, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[2608s] threads: 64, tps: 0.00, reads: 0.00, writes: 29286.12, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[2609s] threads: 64, tps: 0.00, reads: 0.00, writes: 29061.01, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[2610s] threads: 64, tps: 0.00, reads: 0.00, writes: 31985.83, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[2611s] threads: 64, tps: 0.00, reads: 0.00, writes: 28544.12, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[2612s] threads: 64, tps: 0.00, reads: 0.00, writes: 33439.02, response time: 3.37ms (95%), errors: 0.00, reconnects:  0.00
[2613s] threads: 64, tps: 0.00, reads: 0.00, writes: 39669.04, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2614s] threads: 64, tps: 0.00, reads: 0.00, writes: 37717.29, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2615s] threads: 64, tps: 0.00, reads: 0.00, writes: 35532.67, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[2616s] threads: 64, tps: 0.00, reads: 0.00, writes: 34273.98, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[2617s] threads: 64, tps: 0.00, reads: 0.00, writes: 34599.97, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[2618s] threads: 64, tps: 0.00, reads: 0.00, writes: 40106.07, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2619s] threads: 64, tps: 0.00, reads: 0.00, writes: 37309.26, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2620s] threads: 64, tps: 0.00, reads: 0.00, writes: 31841.59, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[2621s] threads: 64, tps: 0.00, reads: 0.00, writes: 35812.03, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[2622s] threads: 64, tps: 0.00, reads: 0.00, writes: 28291.00, response time: 3.85ms (95%), errors: 0.00, reconnects:  0.00
[2623s] threads: 64, tps: 0.00, reads: 0.00, writes: 30393.97, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[2624s] threads: 64, tps: 0.00, reads: 0.00, writes: 38183.06, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[2625s] threads: 64, tps: 0.00, reads: 0.00, writes: 31669.88, response time: 3.17ms (95%), errors: 0.00, reconnects:  0.00
[2626s] threads: 64, tps: 0.00, reads: 0.00, writes: 20972.03, response time: 19.64ms (95%), errors: 0.00, reconnects:  0.00
[2627s] threads: 64, tps: 0.00, reads: 0.00, writes: 32948.08, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[2628s] threads: 64, tps: 0.00, reads: 0.00, writes: 32995.98, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[2629s] threads: 64, tps: 0.00, reads: 0.00, writes: 35092.02, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2630s] threads: 64, tps: 0.00, reads: 0.00, writes: 37803.04, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[2631s] threads: 64, tps: 0.00, reads: 0.00, writes: 38728.98, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2632s] threads: 64, tps: 0.00, reads: 0.00, writes: 37267.96, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2633s] threads: 64, tps: 0.00, reads: 0.00, writes: 36840.03, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2634s] threads: 64, tps: 0.00, reads: 0.00, writes: 36075.98, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2635s] threads: 64, tps: 0.00, reads: 0.00, writes: 35532.00, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2636s] threads: 64, tps: 0.00, reads: 0.00, writes: 41533.94, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2637s] threads: 64, tps: 0.00, reads: 0.00, writes: 38354.06, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2638s] threads: 64, tps: 0.00, reads: 0.00, writes: 37382.99, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2639s] threads: 64, tps: 0.00, reads: 0.00, writes: 37885.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2640s] threads: 64, tps: 0.00, reads: 0.00, writes: 37302.05, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2641s] threads: 64, tps: 0.00, reads: 0.00, writes: 41872.97, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2642s] threads: 64, tps: 0.00, reads: 0.00, writes: 39483.97, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2643s] threads: 64, tps: 0.00, reads: 0.00, writes: 38578.63, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2644s] threads: 64, tps: 0.00, reads: 0.00, writes: 37751.28, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2645s] threads: 64, tps: 0.00, reads: 0.00, writes: 37653.04, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2646s] threads: 64, tps: 0.00, reads: 0.00, writes: 40528.99, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2647s] threads: 64, tps: 0.00, reads: 0.00, writes: 39076.99, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2648s] threads: 64, tps: 0.00, reads: 0.00, writes: 37178.91, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2649s] threads: 64, tps: 0.00, reads: 0.00, writes: 34627.09, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[2650s] threads: 64, tps: 0.00, reads: 0.00, writes: 27958.01, response time: 3.78ms (95%), errors: 0.00, reconnects:  0.00
[2651s] threads: 64, tps: 0.00, reads: 0.00, writes: 34791.03, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[2652s] threads: 64, tps: 0.00, reads: 0.00, writes: 40027.93, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2653s] threads: 64, tps: 0.00, reads: 0.00, writes: 36690.01, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2654s] threads: 64, tps: 0.00, reads: 0.00, writes: 34964.01, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[2655s] threads: 64, tps: 0.00, reads: 0.00, writes: 35203.00, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2656s] threads: 64, tps: 0.00, reads: 0.00, writes: 34120.97, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[2657s] threads: 64, tps: 0.00, reads: 0.00, writes: 38423.07, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2658s] threads: 64, tps: 0.00, reads: 0.00, writes: 39218.98, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2659s] threads: 64, tps: 0.00, reads: 0.00, writes: 35613.30, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[2660s] threads: 64, tps: 0.00, reads: 0.00, writes: 35589.71, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[2661s] threads: 64, tps: 0.00, reads: 0.00, writes: 31101.09, response time: 3.42ms (95%), errors: 0.00, reconnects:  0.00
[2662s] threads: 64, tps: 0.00, reads: 0.00, writes: 29918.46, response time: 3.35ms (95%), errors: 0.00, reconnects:  0.00
[2663s] threads: 64, tps: 0.00, reads: 0.00, writes: 38591.75, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2664s] threads: 64, tps: 0.00, reads: 0.00, writes: 25753.99, response time: 7.18ms (95%), errors: 0.00, reconnects:  0.00
[2665s] threads: 64, tps: 0.00, reads: 0.00, writes: 4131.00, response time: 21.62ms (95%), errors: 0.00, reconnects:  0.00
[2666s] threads: 64, tps: 0.00, reads: 0.00, writes: 32428.00, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[2667s] threads: 64, tps: 0.00, reads: 0.00, writes: 35381.88, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2668s] threads: 64, tps: 0.00, reads: 0.00, writes: 35177.15, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2669s] threads: 64, tps: 0.00, reads: 0.00, writes: 36783.83, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2670s] threads: 64, tps: 0.00, reads: 0.00, writes: 35887.14, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2671s] threads: 64, tps: 0.00, reads: 0.00, writes: 39777.04, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2672s] threads: 64, tps: 0.00, reads: 0.00, writes: 39816.83, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2673s] threads: 64, tps: 0.00, reads: 0.00, writes: 39421.16, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2674s] threads: 64, tps: 0.00, reads: 0.00, writes: 38209.98, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2675s] threads: 64, tps: 0.00, reads: 0.00, writes: 41692.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2676s] threads: 64, tps: 0.00, reads: 0.00, writes: 40162.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2677s] threads: 64, tps: 0.00, reads: 0.00, writes: 38583.06, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2678s] threads: 64, tps: 0.00, reads: 0.00, writes: 38166.00, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2679s] threads: 64, tps: 0.00, reads: 0.00, writes: 37188.02, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2680s] threads: 64, tps: 0.00, reads: 0.00, writes: 39248.02, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2681s] threads: 64, tps: 0.00, reads: 0.00, writes: 40792.79, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2682s] threads: 64, tps: 0.00, reads: 0.00, writes: 39067.11, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2683s] threads: 64, tps: 0.00, reads: 0.00, writes: 38668.97, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2684s] threads: 64, tps: 0.00, reads: 0.00, writes: 37627.00, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2685s] threads: 64, tps: 0.00, reads: 0.00, writes: 40363.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2686s] threads: 64, tps: 0.00, reads: 0.00, writes: 40481.01, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2687s] threads: 64, tps: 0.00, reads: 0.00, writes: 38497.50, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2688s] threads: 64, tps: 0.00, reads: 0.00, writes: 38092.53, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2689s] threads: 64, tps: 0.00, reads: 0.00, writes: 35946.97, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[2690s] threads: 64, tps: 0.00, reads: 0.00, writes: 36700.95, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[2691s] threads: 64, tps: 0.00, reads: 0.00, writes: 37295.07, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2692s] threads: 64, tps: 0.00, reads: 0.00, writes: 29161.76, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[2693s] threads: 64, tps: 0.00, reads: 0.00, writes: 28518.38, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[2694s] threads: 64, tps: 0.00, reads: 0.00, writes: 29007.62, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[2695s] threads: 64, tps: 0.00, reads: 0.00, writes: 27782.99, response time: 3.66ms (95%), errors: 0.00, reconnects:  0.00
[2696s] threads: 64, tps: 0.00, reads: 0.00, writes: 28122.04, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[2697s] threads: 64, tps: 0.00, reads: 0.00, writes: 37335.85, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[2698s] threads: 64, tps: 0.00, reads: 0.00, writes: 36732.82, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[2699s] threads: 64, tps: 0.00, reads: 0.00, writes: 35997.17, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[2700s] threads: 64, tps: 0.00, reads: 0.00, writes: 35211.07, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[2701s] threads: 64, tps: 0.00, reads: 0.00, writes: 35287.96, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[2702s] threads: 64, tps: 0.00, reads: 0.00, writes: 36474.97, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2703s] threads: 64, tps: 0.00, reads: 0.00, writes: 38601.10, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2704s] threads: 64, tps: 0.00, reads: 0.00, writes: 37760.99, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2705s] threads: 64, tps: 0.00, reads: 0.00, writes: 15881.99, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[2706s] threads: 64, tps: 0.00, reads: 0.00, writes: 3126.99, response time: 21.50ms (95%), errors: 0.00, reconnects:  0.00
[2707s] threads: 64, tps: 0.00, reads: 0.00, writes: 3075.01, response time: 21.76ms (95%), errors: 0.00, reconnects:  0.00
[2708s] threads: 64, tps: 0.00, reads: 0.00, writes: 3120.00, response time: 21.59ms (95%), errors: 0.00, reconnects:  0.00
[2709s] threads: 64, tps: 0.00, reads: 0.00, writes: 3092.00, response time: 21.70ms (95%), errors: 0.00, reconnects:  0.00
[2710s] threads: 64, tps: 0.00, reads: 0.00, writes: 4761.00, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2711s] threads: 64, tps: 0.00, reads: 0.00, writes: 29802.97, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[2712s] threads: 64, tps: 0.00, reads: 0.00, writes: 34288.05, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2713s] threads: 64, tps: 0.00, reads: 0.00, writes: 37548.05, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2714s] threads: 64, tps: 0.00, reads: 0.00, writes: 40050.96, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2715s] threads: 64, tps: 0.00, reads: 0.00, writes: 38881.98, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2716s] threads: 64, tps: 0.00, reads: 0.00, writes: 38378.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2717s] threads: 64, tps: 0.00, reads: 0.00, writes: 38460.04, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2718s] threads: 64, tps: 0.00, reads: 0.00, writes: 40252.86, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2719s] threads: 64, tps: 0.00, reads: 0.00, writes: 40399.06, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2720s] threads: 64, tps: 0.00, reads: 0.00, writes: 39754.94, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2721s] threads: 64, tps: 0.00, reads: 0.00, writes: 39343.99, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2722s] threads: 64, tps: 0.00, reads: 0.00, writes: 31797.06, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2723s] threads: 64, tps: 0.00, reads: 0.00, writes: 39331.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2724s] threads: 64, tps: 0.00, reads: 0.00, writes: 42124.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2725s] threads: 64, tps: 0.00, reads: 0.00, writes: 38898.97, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2726s] threads: 64, tps: 0.00, reads: 0.00, writes: 38399.04, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2727s] threads: 64, tps: 0.00, reads: 0.00, writes: 36839.99, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2728s] threads: 64, tps: 0.00, reads: 0.00, writes: 36497.91, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2729s] threads: 64, tps: 0.00, reads: 0.00, writes: 42251.05, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2730s] threads: 64, tps: 0.00, reads: 0.00, writes: 38231.05, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2731s] threads: 64, tps: 0.00, reads: 0.00, writes: 37730.99, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2732s] threads: 64, tps: 0.00, reads: 0.00, writes: 37190.83, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2733s] threads: 64, tps: 0.00, reads: 0.00, writes: 36417.14, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2734s] threads: 64, tps: 0.00, reads: 0.00, writes: 41081.01, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2735s] threads: 64, tps: 0.00, reads: 0.00, writes: 40320.98, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2736s] threads: 64, tps: 0.00, reads: 0.00, writes: 38728.80, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2737s] threads: 64, tps: 0.00, reads: 0.00, writes: 37759.24, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2738s] threads: 64, tps: 0.00, reads: 0.00, writes: 35135.99, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2739s] threads: 64, tps: 0.00, reads: 0.00, writes: 37133.97, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2740s] threads: 64, tps: 0.00, reads: 0.00, writes: 38601.96, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2741s] threads: 64, tps: 0.00, reads: 0.00, writes: 32220.01, response time: 3.28ms (95%), errors: 0.00, reconnects:  0.00
[2742s] threads: 64, tps: 0.00, reads: 0.00, writes: 28631.02, response time: 3.49ms (95%), errors: 0.00, reconnects:  0.00
[2743s] threads: 64, tps: 0.00, reads: 0.00, writes: 28604.00, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[2744s] threads: 64, tps: 0.00, reads: 0.00, writes: 27824.97, response time: 3.68ms (95%), errors: 0.00, reconnects:  0.00
[2745s] threads: 64, tps: 0.00, reads: 0.00, writes: 34206.02, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[2746s] threads: 64, tps: 0.00, reads: 0.00, writes: 40105.97, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2747s] threads: 64, tps: 0.00, reads: 0.00, writes: 37137.05, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2748s] threads: 64, tps: 0.00, reads: 0.00, writes: 34132.48, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[2749s] threads: 64, tps: 0.00, reads: 0.00, writes: 34744.57, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[2750s] threads: 64, tps: 0.00, reads: 0.00, writes: 34286.99, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[2751s] threads: 64, tps: 0.00, reads: 0.00, writes: 37192.94, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2752s] threads: 64, tps: 0.00, reads: 0.00, writes: 39083.00, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2753s] threads: 64, tps: 0.00, reads: 0.00, writes: 32975.39, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[2754s] threads: 64, tps: 0.00, reads: 0.00, writes: 3091.05, response time: 21.77ms (95%), errors: 0.00, reconnects:  0.00
[2755s] threads: 64, tps: 0.00, reads: 0.00, writes: 3104.01, response time: 21.57ms (95%), errors: 0.00, reconnects:  0.00
[2756s] threads: 64, tps: 0.00, reads: 0.00, writes: 3082.95, response time: 21.78ms (95%), errors: 0.00, reconnects:  0.00
[2757s] threads: 64, tps: 0.00, reads: 0.00, writes: 3091.97, response time: 21.67ms (95%), errors: 0.00, reconnects:  0.00
[2758s] threads: 64, tps: 0.00, reads: 0.00, writes: 3088.03, response time: 21.35ms (95%), errors: 0.00, reconnects:  0.00
[2759s] threads: 64, tps: 0.00, reads: 0.00, writes: 3094.05, response time: 21.98ms (95%), errors: 0.00, reconnects:  0.00
[2760s] threads: 64, tps: 0.00, reads: 0.00, writes: 24496.96, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[2761s] threads: 64, tps: 0.00, reads: 0.00, writes: 30678.99, response time: 3.14ms (95%), errors: 0.00, reconnects:  0.00
[2762s] threads: 64, tps: 0.00, reads: 0.00, writes: 29853.02, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[2763s] threads: 64, tps: 0.00, reads: 0.00, writes: 38661.98, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2764s] threads: 64, tps: 0.00, reads: 0.00, writes: 35017.07, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[2765s] threads: 64, tps: 0.00, reads: 0.00, writes: 35133.94, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[2766s] threads: 64, tps: 0.00, reads: 0.00, writes: 35469.99, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2767s] threads: 64, tps: 0.00, reads: 0.00, writes: 35041.99, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2768s] threads: 64, tps: 0.00, reads: 0.00, writes: 38069.05, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2769s] threads: 64, tps: 0.00, reads: 0.00, writes: 39449.98, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2770s] threads: 64, tps: 0.00, reads: 0.00, writes: 36208.04, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2771s] threads: 64, tps: 0.00, reads: 0.00, writes: 35513.00, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2772s] threads: 64, tps: 0.00, reads: 0.00, writes: 36296.94, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2773s] threads: 64, tps: 0.00, reads: 0.00, writes: 33782.05, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2774s] threads: 64, tps: 0.00, reads: 0.00, writes: 41683.96, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2775s] threads: 64, tps: 0.00, reads: 0.00, writes: 38016.99, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2776s] threads: 64, tps: 0.00, reads: 0.00, writes: 31902.01, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2777s] threads: 64, tps: 0.00, reads: 0.00, writes: 36697.18, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2778s] threads: 64, tps: 0.00, reads: 0.00, writes: 36391.80, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2779s] threads: 64, tps: 0.00, reads: 0.00, writes: 39972.93, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2780s] threads: 64, tps: 0.00, reads: 0.00, writes: 40524.04, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2781s] threads: 64, tps: 0.00, reads: 0.00, writes: 39312.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2782s] threads: 64, tps: 0.00, reads: 0.00, writes: 37376.89, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2783s] threads: 64, tps: 0.00, reads: 0.00, writes: 36789.13, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2784s] threads: 64, tps: 0.00, reads: 0.00, writes: 37346.02, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2785s] threads: 64, tps: 0.00, reads: 0.00, writes: 40030.29, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2786s] threads: 64, tps: 0.00, reads: 0.00, writes: 37210.70, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2787s] threads: 64, tps: 0.00, reads: 0.00, writes: 30187.18, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[2788s] threads: 64, tps: 0.00, reads: 0.00, writes: 29608.27, response time: 3.47ms (95%), errors: 0.00, reconnects:  0.00
[2789s] threads: 64, tps: 0.00, reads: 0.00, writes: 32274.31, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[2790s] threads: 64, tps: 0.00, reads: 0.00, writes: 37521.77, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[2791s] threads: 64, tps: 0.00, reads: 0.00, writes: 39550.11, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2792s] threads: 64, tps: 0.00, reads: 0.00, writes: 37153.03, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2793s] threads: 64, tps: 0.00, reads: 0.00, writes: 35510.03, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[2794s] threads: 64, tps: 0.00, reads: 0.00, writes: 34794.02, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[2795s] threads: 64, tps: 0.00, reads: 0.00, writes: 35011.03, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[2796s] threads: 64, tps: 0.00, reads: 0.00, writes: 40855.03, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2797s] threads: 64, tps: 0.00, reads: 0.00, writes: 38327.96, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2798s] threads: 64, tps: 0.00, reads: 0.00, writes: 32923.03, response time: 3.02ms (95%), errors: 0.00, reconnects:  0.00
[2799s] threads: 64, tps: 0.00, reads: 0.00, writes: 32497.96, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[2800s] threads: 64, tps: 0.00, reads: 0.00, writes: 29144.99, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[2801s] threads: 64, tps: 0.00, reads: 0.00, writes: 29194.04, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[2802s] threads: 64, tps: 0.00, reads: 0.00, writes: 39632.98, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2803s] threads: 64, tps: 0.00, reads: 0.00, writes: 31228.99, response time: 3.34ms (95%), errors: 0.00, reconnects:  0.00
[2804s] threads: 64, tps: 0.00, reads: 0.00, writes: 32607.99, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[2805s] threads: 64, tps: 0.00, reads: 0.00, writes: 35274.06, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2806s] threads: 64, tps: 0.00, reads: 0.00, writes: 34711.96, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2807s] threads: 64, tps: 0.00, reads: 0.00, writes: 37032.97, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2808s] threads: 64, tps: 0.00, reads: 0.00, writes: 40358.03, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2809s] threads: 64, tps: 0.00, reads: 0.00, writes: 32807.80, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2810s] threads: 64, tps: 0.00, reads: 0.00, writes: 38291.29, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2811s] threads: 64, tps: 0.00, reads: 0.00, writes: 37839.95, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[2812s] threads: 64, tps: 0.00, reads: 0.00, writes: 37562.03, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2813s] threads: 64, tps: 0.00, reads: 0.00, writes: 42633.00, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2814s] threads: 64, tps: 0.00, reads: 0.00, writes: 39690.91, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2815s] threads: 64, tps: 0.00, reads: 0.00, writes: 39233.04, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2816s] threads: 64, tps: 0.00, reads: 0.00, writes: 37611.02, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2817s] threads: 64, tps: 0.00, reads: 0.00, writes: 37548.98, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2818s] threads: 64, tps: 0.00, reads: 0.00, writes: 41746.98, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2819s] threads: 64, tps: 0.00, reads: 0.00, writes: 40030.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2820s] threads: 64, tps: 0.00, reads: 0.00, writes: 38178.86, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2821s] threads: 64, tps: 0.00, reads: 0.00, writes: 39028.63, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2822s] threads: 64, tps: 0.00, reads: 0.00, writes: 37482.06, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2823s] threads: 64, tps: 0.00, reads: 0.00, writes: 33793.92, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2824s] threads: 64, tps: 0.00, reads: 0.00, writes: 40039.83, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2825s] threads: 64, tps: 0.00, reads: 0.00, writes: 38026.10, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2826s] threads: 64, tps: 0.00, reads: 0.00, writes: 37175.91, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2827s] threads: 64, tps: 0.00, reads: 0.00, writes: 36335.06, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2828s] threads: 64, tps: 0.00, reads: 0.00, writes: 36543.95, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[2829s] threads: 64, tps: 0.00, reads: 0.00, writes: 40384.04, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2830s] threads: 64, tps: 0.00, reads: 0.00, writes: 37704.95, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[2831s] threads: 64, tps: 0.00, reads: 0.00, writes: 28190.02, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[2832s] threads: 64, tps: 0.00, reads: 0.00, writes: 28682.99, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[2833s] threads: 64, tps: 0.00, reads: 0.00, writes: 28515.89, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[2834s] threads: 64, tps: 0.00, reads: 0.00, writes: 35599.15, response time: 2.96ms (95%), errors: 0.00, reconnects:  0.00
[2835s] threads: 64, tps: 0.00, reads: 0.00, writes: 39918.97, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2836s] threads: 64, tps: 0.00, reads: 0.00, writes: 37256.98, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2837s] threads: 64, tps: 0.00, reads: 0.00, writes: 34838.08, response time: 2.95ms (95%), errors: 0.00, reconnects:  0.00
[2838s] threads: 64, tps: 0.00, reads: 0.00, writes: 34860.99, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[2839s] threads: 64, tps: 0.00, reads: 0.00, writes: 34267.97, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[2840s] threads: 64, tps: 0.00, reads: 0.00, writes: 39258.01, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2841s] threads: 64, tps: 0.00, reads: 0.00, writes: 38153.00, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2842s] threads: 64, tps: 0.00, reads: 0.00, writes: 24937.03, response time: 6.15ms (95%), errors: 0.00, reconnects:  0.00
[2843s] threads: 64, tps: 0.00, reads: 0.00, writes: 3106.99, response time: 21.59ms (95%), errors: 0.00, reconnects:  0.00
[2844s] threads: 64, tps: 0.00, reads: 0.00, writes: 3080.93, response time: 21.70ms (95%), errors: 0.00, reconnects:  0.00
[2845s] threads: 64, tps: 0.00, reads: 0.00, writes: 3089.02, response time: 21.94ms (95%), errors: 0.00, reconnects:  0.00
[2846s] threads: 64, tps: 0.00, reads: 0.00, writes: 3066.05, response time: 22.41ms (95%), errors: 0.00, reconnects:  0.00
[2847s] threads: 64, tps: 0.00, reads: 0.00, writes: 3077.92, response time: 21.32ms (95%), errors: 0.00, reconnects:  0.00
[2848s] threads: 64, tps: 0.00, reads: 0.00, writes: 6356.16, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[2849s] threads: 64, tps: 0.00, reads: 0.00, writes: 31342.00, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[2850s] threads: 64, tps: 0.00, reads: 0.00, writes: 33503.99, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[2851s] threads: 64, tps: 0.00, reads: 0.00, writes: 37074.69, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[2852s] threads: 64, tps: 0.00, reads: 0.00, writes: 39852.46, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2853s] threads: 64, tps: 0.00, reads: 0.00, writes: 39626.00, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2854s] threads: 64, tps: 0.00, reads: 0.00, writes: 38356.05, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2855s] threads: 64, tps: 0.00, reads: 0.00, writes: 38102.98, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2856s] threads: 64, tps: 0.00, reads: 0.00, writes: 39686.98, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2857s] threads: 64, tps: 0.00, reads: 0.00, writes: 41154.98, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2858s] threads: 64, tps: 0.00, reads: 0.00, writes: 39643.98, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2859s] threads: 64, tps: 0.00, reads: 0.00, writes: 38934.01, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2860s] threads: 64, tps: 0.00, reads: 0.00, writes: 38039.04, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2861s] threads: 64, tps: 0.00, reads: 0.00, writes: 39204.85, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2862s] threads: 64, tps: 0.00, reads: 0.00, writes: 42790.63, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2863s] threads: 64, tps: 0.00, reads: 0.00, writes: 40078.49, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2864s] threads: 64, tps: 0.00, reads: 0.00, writes: 38595.99, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2865s] threads: 64, tps: 0.00, reads: 0.00, writes: 38402.03, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2866s] threads: 64, tps: 0.00, reads: 0.00, writes: 36158.99, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2867s] threads: 64, tps: 0.00, reads: 0.00, writes: 42342.89, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2868s] threads: 64, tps: 0.00, reads: 0.00, writes: 39834.06, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2869s] threads: 64, tps: 0.00, reads: 0.00, writes: 37746.04, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2870s] threads: 64, tps: 0.00, reads: 0.00, writes: 33964.99, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[2871s] threads: 64, tps: 0.00, reads: 0.00, writes: 28307.01, response time: 3.57ms (95%), errors: 0.00, reconnects:  0.00
[2872s] threads: 64, tps: 0.00, reads: 0.00, writes: 34050.99, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[2873s] threads: 64, tps: 0.00, reads: 0.00, writes: 37168.96, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2874s] threads: 64, tps: 0.00, reads: 0.00, writes: 28554.01, response time: 3.65ms (95%), errors: 0.00, reconnects:  0.00
[2875s] threads: 64, tps: 0.00, reads: 0.00, writes: 28895.00, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[2876s] threads: 64, tps: 0.00, reads: 0.00, writes: 28899.01, response time: 3.59ms (95%), errors: 0.00, reconnects:  0.00
[2877s] threads: 64, tps: 0.00, reads: 0.00, writes: 23118.00, response time: 3.65ms (95%), errors: 0.00, reconnects:  0.00
[2878s] threads: 64, tps: 0.00, reads: 0.00, writes: 28216.01, response time: 3.49ms (95%), errors: 0.00, reconnects:  0.00
[2879s] threads: 64, tps: 0.00, reads: 0.00, writes: 37961.94, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[2880s] threads: 64, tps: 0.00, reads: 0.00, writes: 39252.05, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2881s] threads: 64, tps: 0.00, reads: 0.00, writes: 35013.04, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2882s] threads: 64, tps: 0.00, reads: 0.00, writes: 34952.96, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[2883s] threads: 64, tps: 0.00, reads: 0.00, writes: 34302.00, response time: 2.81ms (95%), errors: 0.00, reconnects:  0.00
[2884s] threads: 64, tps: 0.00, reads: 0.00, writes: 35736.05, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[2885s] threads: 64, tps: 0.00, reads: 0.00, writes: 39449.97, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2886s] threads: 64, tps: 0.00, reads: 0.00, writes: 37915.01, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2887s] threads: 64, tps: 0.00, reads: 0.00, writes: 34356.97, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[2888s] threads: 64, tps: 0.00, reads: 0.00, writes: 33612.31, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[2889s] threads: 64, tps: 0.00, reads: 0.00, writes: 31937.81, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[2890s] threads: 64, tps: 0.00, reads: 0.00, writes: 33725.43, response time: 3.34ms (95%), errors: 0.00, reconnects:  0.00
[2891s] threads: 64, tps: 0.00, reads: 0.00, writes: 35401.48, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[2892s] threads: 64, tps: 0.00, reads: 0.00, writes: 17198.99, response time: 20.58ms (95%), errors: 0.00, reconnects:  0.00
[2893s] threads: 64, tps: 0.00, reads: 0.00, writes: 32821.02, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[2894s] threads: 64, tps: 0.00, reads: 0.00, writes: 34816.97, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2895s] threads: 64, tps: 0.00, reads: 0.00, writes: 35435.03, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2896s] threads: 64, tps: 0.00, reads: 0.00, writes: 37897.05, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2897s] threads: 64, tps: 0.00, reads: 0.00, writes: 39823.96, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2898s] threads: 64, tps: 0.00, reads: 0.00, writes: 37509.14, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2899s] threads: 64, tps: 0.00, reads: 0.00, writes: 37741.90, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2900s] threads: 64, tps: 0.00, reads: 0.00, writes: 36746.95, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[2901s] threads: 64, tps: 0.00, reads: 0.00, writes: 36731.95, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2902s] threads: 64, tps: 0.00, reads: 0.00, writes: 42259.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2903s] threads: 64, tps: 0.00, reads: 0.00, writes: 39122.09, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2904s] threads: 64, tps: 0.00, reads: 0.00, writes: 37825.92, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2905s] threads: 64, tps: 0.00, reads: 0.00, writes: 37660.07, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2906s] threads: 64, tps: 0.00, reads: 0.00, writes: 36573.94, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2907s] threads: 64, tps: 0.00, reads: 0.00, writes: 40442.07, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2908s] threads: 64, tps: 0.00, reads: 0.00, writes: 39868.01, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2909s] threads: 64, tps: 0.00, reads: 0.00, writes: 37844.93, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2910s] threads: 64, tps: 0.00, reads: 0.00, writes: 37437.05, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2911s] threads: 64, tps: 0.00, reads: 0.00, writes: 35855.82, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2912s] threads: 64, tps: 0.00, reads: 0.00, writes: 38828.15, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2913s] threads: 64, tps: 0.00, reads: 0.00, writes: 39295.98, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2914s] threads: 64, tps: 0.00, reads: 0.00, writes: 38490.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2915s] threads: 64, tps: 0.00, reads: 0.00, writes: 36119.99, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2916s] threads: 64, tps: 0.00, reads: 0.00, writes: 33110.99, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[2917s] threads: 64, tps: 0.00, reads: 0.00, writes: 27960.60, response time: 3.59ms (95%), errors: 0.00, reconnects:  0.00
[2918s] threads: 64, tps: 0.00, reads: 0.00, writes: 37901.93, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[2919s] threads: 64, tps: 0.00, reads: 0.00, writes: 31366.00, response time: 3.57ms (95%), errors: 0.00, reconnects:  0.00
[2920s] threads: 64, tps: 0.00, reads: 0.00, writes: 28649.03, response time: 3.57ms (95%), errors: 0.00, reconnects:  0.00
[2921s] threads: 64, tps: 0.00, reads: 0.00, writes: 29425.95, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[2922s] threads: 64, tps: 0.00, reads: 0.00, writes: 29755.00, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[2923s] threads: 64, tps: 0.00, reads: 0.00, writes: 28392.01, response time: 3.53ms (95%), errors: 0.00, reconnects:  0.00
[2924s] threads: 64, tps: 0.00, reads: 0.00, writes: 31913.99, response time: 3.37ms (95%), errors: 0.00, reconnects:  0.00
[2925s] threads: 64, tps: 0.00, reads: 0.00, writes: 37841.01, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2926s] threads: 64, tps: 0.00, reads: 0.00, writes: 29518.97, response time: 3.59ms (95%), errors: 0.00, reconnects:  0.00
[2927s] threads: 64, tps: 0.00, reads: 0.00, writes: 26997.02, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[2928s] threads: 64, tps: 0.00, reads: 0.00, writes: 28742.98, response time: 3.66ms (95%), errors: 0.00, reconnects:  0.00
[2929s] threads: 64, tps: 0.00, reads: 0.00, writes: 34038.04, response time: 2.87ms (95%), errors: 0.00, reconnects:  0.00
[2930s] threads: 64, tps: 0.00, reads: 0.00, writes: 34899.99, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[2931s] threads: 64, tps: 0.00, reads: 0.00, writes: 39635.05, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2932s] threads: 64, tps: 0.00, reads: 0.00, writes: 36280.96, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2933s] threads: 64, tps: 0.00, reads: 0.00, writes: 7752.00, response time: 21.35ms (95%), errors: 0.00, reconnects:  0.00
[2934s] threads: 64, tps: 0.00, reads: 0.00, writes: 3088.99, response time: 21.56ms (95%), errors: 0.00, reconnects:  0.00
[2935s] threads: 64, tps: 0.00, reads: 0.00, writes: 3089.01, response time: 21.65ms (95%), errors: 0.00, reconnects:  0.00
[2936s] threads: 64, tps: 0.00, reads: 0.00, writes: 3078.99, response time: 21.43ms (95%), errors: 0.00, reconnects:  0.00
[2937s] threads: 64, tps: 0.00, reads: 0.00, writes: 3108.00, response time: 21.58ms (95%), errors: 0.00, reconnects:  0.00
[2938s] threads: 64, tps: 0.00, reads: 0.00, writes: 3089.01, response time: 21.57ms (95%), errors: 0.00, reconnects:  0.00
[2939s] threads: 64, tps: 0.00, reads: 0.00, writes: 3085.00, response time: 21.70ms (95%), errors: 0.00, reconnects:  0.00
[2940s] threads: 64, tps: 0.00, reads: 0.00, writes: 3072.00, response time: 21.69ms (95%), errors: 0.00, reconnects:  0.00
[2941s] threads: 64, tps: 0.00, reads: 0.00, writes: 3090.00, response time: 21.65ms (95%), errors: 0.00, reconnects:  0.00
[2942s] threads: 64, tps: 0.00, reads: 0.00, writes: 26213.02, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[2943s] threads: 64, tps: 0.00, reads: 0.00, writes: 32112.50, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[2944s] threads: 64, tps: 0.00, reads: 0.00, writes: 35941.66, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2945s] threads: 64, tps: 0.00, reads: 0.00, writes: 40448.09, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2946s] threads: 64, tps: 0.00, reads: 0.00, writes: 35769.07, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2947s] threads: 64, tps: 0.00, reads: 0.00, writes: 36087.97, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2948s] threads: 64, tps: 0.00, reads: 0.00, writes: 35859.98, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2949s] threads: 64, tps: 0.00, reads: 0.00, writes: 35307.96, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2950s] threads: 64, tps: 0.00, reads: 0.00, writes: 39069.06, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[2951s] threads: 64, tps: 0.00, reads: 0.00, writes: 36757.01, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2952s] threads: 64, tps: 0.00, reads: 0.00, writes: 36178.99, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[2953s] threads: 64, tps: 0.00, reads: 0.00, writes: 36636.75, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2954s] threads: 64, tps: 0.00, reads: 0.00, writes: 36600.01, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2955s] threads: 64, tps: 0.00, reads: 0.00, writes: 38983.43, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2956s] threads: 64, tps: 0.00, reads: 0.00, writes: 40417.02, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2957s] threads: 64, tps: 0.00, reads: 0.00, writes: 39392.02, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2958s] threads: 64, tps: 0.00, reads: 0.00, writes: 38807.43, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2959s] threads: 64, tps: 0.00, reads: 0.00, writes: 36616.50, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2960s] threads: 64, tps: 0.00, reads: 0.00, writes: 38156.03, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2961s] threads: 64, tps: 0.00, reads: 0.00, writes: 42137.95, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2962s] threads: 64, tps: 0.00, reads: 0.00, writes: 39974.05, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2963s] threads: 64, tps: 0.00, reads: 0.00, writes: 38803.97, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2964s] threads: 64, tps: 0.00, reads: 0.00, writes: 37281.01, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2965s] threads: 64, tps: 0.00, reads: 0.00, writes: 35357.14, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2966s] threads: 64, tps: 0.00, reads: 0.00, writes: 41108.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2967s] threads: 64, tps: 0.00, reads: 0.00, writes: 39456.03, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2968s] threads: 64, tps: 0.00, reads: 0.00, writes: 38333.97, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2969s] threads: 64, tps: 0.00, reads: 0.00, writes: 37847.95, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2970s] threads: 64, tps: 0.00, reads: 0.00, writes: 37163.05, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2971s] threads: 64, tps: 0.00, reads: 0.00, writes: 41295.83, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2972s] threads: 64, tps: 0.00, reads: 0.00, writes: 38255.16, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2973s] threads: 64, tps: 0.00, reads: 0.00, writes: 29934.03, response time: 3.60ms (95%), errors: 0.00, reconnects:  0.00
[2974s] threads: 64, tps: 0.00, reads: 0.00, writes: 29345.98, response time: 3.34ms (95%), errors: 0.00, reconnects:  0.00
[2975s] threads: 64, tps: 0.00, reads: 0.00, writes: 28661.97, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[2976s] threads: 64, tps: 0.00, reads: 0.00, writes: 28097.00, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[2977s] threads: 64, tps: 0.00, reads: 0.00, writes: 36951.04, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[2978s] threads: 64, tps: 0.00, reads: 0.00, writes: 38523.02, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2979s] threads: 64, tps: 0.00, reads: 0.00, writes: 35978.97, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[2980s] threads: 64, tps: 0.00, reads: 0.00, writes: 34726.05, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2981s] threads: 64, tps: 0.00, reads: 0.00, writes: 34352.97, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[2982s] threads: 64, tps: 0.00, reads: 0.00, writes: 32938.51, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[2983s] threads: 64, tps: 0.00, reads: 0.00, writes: 32279.35, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[2984s] threads: 64, tps: 0.00, reads: 0.00, writes: 36783.03, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2985s] threads: 64, tps: 0.00, reads: 0.00, writes: 34470.96, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[2986s] threads: 64, tps: 0.00, reads: 0.00, writes: 34537.06, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[2987s] threads: 64, tps: 0.00, reads: 0.00, writes: 32029.00, response time: 3.19ms (95%), errors: 0.00, reconnects:  0.00
[2988s] threads: 64, tps: 0.00, reads: 0.00, writes: 28278.03, response time: 3.65ms (95%), errors: 0.00, reconnects:  0.00
[2989s] threads: 64, tps: 0.00, reads: 0.00, writes: 39308.99, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2990s] threads: 64, tps: 0.00, reads: 0.00, writes: 24455.97, response time: 7.14ms (95%), errors: 0.00, reconnects:  0.00
[2991s] threads: 64, tps: 0.00, reads: 0.00, writes: 3101.00, response time: 21.79ms (95%), errors: 0.00, reconnects:  0.00
[2992s] threads: 64, tps: 0.00, reads: 0.00, writes: 12172.00, response time: 20.79ms (95%), errors: 0.00, reconnects:  0.00
[2993s] threads: 64, tps: 0.00, reads: 0.00, writes: 32350.02, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[2994s] threads: 64, tps: 0.00, reads: 0.00, writes: 33988.94, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2995s] threads: 64, tps: 0.00, reads: 0.00, writes: 36351.04, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[2996s] threads: 64, tps: 0.00, reads: 0.00, writes: 39166.06, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2997s] threads: 64, tps: 0.00, reads: 0.00, writes: 40244.99, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2998s] threads: 64, tps: 0.00, reads: 0.00, writes: 40097.92, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2999s] threads: 64, tps: 0.00, reads: 0.00, writes: 38276.12, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3000s] threads: 64, tps: 0.00, reads: 0.00, writes: 37893.93, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3001s] threads: 64, tps: 0.00, reads: 0.00, writes: 39601.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3002s] threads: 64, tps: 0.00, reads: 0.00, writes: 41403.98, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3003s] threads: 64, tps: 0.00, reads: 0.00, writes: 39101.84, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3004s] threads: 64, tps: 0.00, reads: 0.00, writes: 37441.15, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[3005s] threads: 64, tps: 0.00, reads: 0.00, writes: 37790.03, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3006s] threads: 64, tps: 0.00, reads: 0.00, writes: 34715.97, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[3007s] threads: 64, tps: 0.00, reads: 0.00, writes: 41495.05, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3008s] threads: 64, tps: 0.00, reads: 0.00, writes: 38778.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3009s] threads: 64, tps: 0.00, reads: 0.00, writes: 38920.00, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3010s] threads: 64, tps: 0.00, reads: 0.00, writes: 37372.94, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3011s] threads: 64, tps: 0.00, reads: 0.00, writes: 37023.00, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3012s] threads: 64, tps: 0.00, reads: 0.00, writes: 41837.04, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3013s] threads: 64, tps: 0.00, reads: 0.00, writes: 38535.01, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3014s] threads: 64, tps: 0.00, reads: 0.00, writes: 38388.00, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3015s] threads: 64, tps: 0.00, reads: 0.00, writes: 32456.96, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[3016s] threads: 64, tps: 0.00, reads: 0.00, writes: 32190.03, response time: 3.25ms (95%), errors: 0.00, reconnects:  0.00
[3017s] threads: 64, tps: 0.00, reads: 0.00, writes: 31472.96, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[3018s] threads: 64, tps: 0.00, reads: 0.00, writes: 37766.05, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[3019s] threads: 64, tps: 0.00, reads: 0.00, writes: 28641.99, response time: 3.66ms (95%), errors: 0.00, reconnects:  0.00
[3020s] threads: 64, tps: 0.00, reads: 0.00, writes: 28509.01, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[3021s] threads: 64, tps: 0.00, reads: 0.00, writes: 28981.00, response time: 3.40ms (95%), errors: 0.00, reconnects:  0.00
[3022s] threads: 64, tps: 0.00, reads: 0.00, writes: 29553.02, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[3023s] threads: 64, tps: 0.00, reads: 0.00, writes: 28609.98, response time: 3.54ms (95%), errors: 0.00, reconnects:  0.00
[3024s] threads: 64, tps: 0.00, reads: 0.00, writes: 35703.01, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[3025s] threads: 64, tps: 0.00, reads: 0.00, writes: 37648.98, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[3026s] threads: 64, tps: 0.00, reads: 0.00, writes: 35098.02, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[3027s] threads: 64, tps: 0.00, reads: 0.00, writes: 34411.94, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[3028s] threads: 64, tps: 0.00, reads: 0.00, writes: 34048.02, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[3029s] threads: 64, tps: 0.00, reads: 0.00, writes: 34931.05, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[3030s] threads: 64, tps: 0.00, reads: 0.00, writes: 40251.96, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3031s] threads: 64, tps: 0.00, reads: 0.00, writes: 37082.13, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3032s] threads: 64, tps: 0.00, reads: 0.00, writes: 13473.23, response time: 20.96ms (95%), errors: 0.00, reconnects:  0.00
[3033s] threads: 64, tps: 0.00, reads: 0.00, writes: 3081.01, response time: 21.62ms (95%), errors: 0.00, reconnects:  0.00
[3034s] threads: 64, tps: 0.00, reads: 0.00, writes: 3086.92, response time: 21.52ms (95%), errors: 0.00, reconnects:  0.00
[3035s] threads: 64, tps: 0.00, reads: 0.00, writes: 3100.07, response time: 21.69ms (95%), errors: 0.00, reconnects:  0.00
[3036s] threads: 64, tps: 0.00, reads: 0.00, writes: 3087.00, response time: 21.57ms (95%), errors: 0.00, reconnects:  0.00
[3037s] threads: 64, tps: 0.00, reads: 0.00, writes: 25653.99, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[3038s] threads: 64, tps: 0.00, reads: 0.00, writes: 32642.40, response time: 2.83ms (95%), errors: 0.00, reconnects:  0.00
[3039s] threads: 64, tps: 0.00, reads: 0.00, writes: 27768.50, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[3040s] threads: 64, tps: 0.00, reads: 0.00, writes: 40870.87, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3041s] threads: 64, tps: 0.00, reads: 0.00, writes: 39025.13, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[3042s] threads: 64, tps: 0.00, reads: 0.00, writes: 38881.88, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3043s] threads: 64, tps: 0.00, reads: 0.00, writes: 38682.16, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3044s] threads: 64, tps: 0.00, reads: 0.00, writes: 37578.96, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3045s] threads: 64, tps: 0.00, reads: 0.00, writes: 40169.90, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3046s] threads: 64, tps: 0.00, reads: 0.00, writes: 40163.12, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3047s] threads: 64, tps: 0.00, reads: 0.00, writes: 38603.03, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3048s] threads: 64, tps: 0.00, reads: 0.00, writes: 38320.51, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3049s] threads: 64, tps: 0.00, reads: 0.00, writes: 37111.49, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[3050s] threads: 64, tps: 0.00, reads: 0.00, writes: 41124.01, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3051s] threads: 64, tps: 0.00, reads: 0.00, writes: 40446.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3052s] threads: 64, tps: 0.00, reads: 0.00, writes: 39431.84, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3053s] threads: 64, tps: 0.00, reads: 0.00, writes: 37332.14, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3054s] threads: 64, tps: 0.00, reads: 0.00, writes: 36464.89, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[3055s] threads: 64, tps: 0.00, reads: 0.00, writes: 37730.11, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3056s] threads: 64, tps: 0.00, reads: 0.00, writes: 40135.91, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3057s] threads: 64, tps: 0.00, reads: 0.00, writes: 39582.07, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3058s] threads: 64, tps: 0.00, reads: 0.00, writes: 38835.25, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3059s] threads: 64, tps: 0.00, reads: 0.00, writes: 38256.28, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3060s] threads: 64, tps: 0.00, reads: 0.00, writes: 38502.16, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3061s] threads: 64, tps: 0.00, reads: 0.00, writes: 41772.95, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3062s] threads: 64, tps: 0.00, reads: 0.00, writes: 39122.03, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3063s] threads: 64, tps: 0.00, reads: 0.00, writes: 38336.97, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3064s] threads: 64, tps: 0.00, reads: 0.00, writes: 35774.03, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3065s] threads: 64, tps: 0.00, reads: 0.00, writes: 30808.00, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[3066s] threads: 64, tps: 0.00, reads: 0.00, writes: 34472.92, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[3067s] threads: 64, tps: 0.00, reads: 0.00, writes: 32961.07, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[3068s] threads: 64, tps: 0.00, reads: 0.00, writes: 28144.02, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[3069s] threads: 64, tps: 0.00, reads: 0.00, writes: 29497.87, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[3070s] threads: 64, tps: 0.00, reads: 0.00, writes: 29279.02, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[3071s] threads: 64, tps: 0.00, reads: 0.00, writes: 32844.98, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[3072s] threads: 64, tps: 0.00, reads: 0.00, writes: 35475.14, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[3073s] threads: 64, tps: 0.00, reads: 0.00, writes: 39339.02, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3074s] threads: 64, tps: 0.00, reads: 0.00, writes: 35790.01, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[3075s] threads: 64, tps: 0.00, reads: 0.00, writes: 34114.96, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[3076s] threads: 64, tps: 0.00, reads: 0.00, writes: 33852.00, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[3077s] threads: 64, tps: 0.00, reads: 0.00, writes: 34817.02, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[3078s] threads: 64, tps: 0.00, reads: 0.00, writes: 39348.99, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[3080s] threads: 64, tps: 0.00, reads: 0.00, writes: 39098.05, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[3080s] threads: 64, tps: 0.00, reads: 0.00, writes: 30312.85, response time: 3.68ms (95%), errors: 0.00, reconnects:  0.00
[3081s] threads: 64, tps: 0.00, reads: 0.00, writes: 3072.00, response time: 22.21ms (95%), errors: 0.00, reconnects:  0.00
[3082s] threads: 64, tps: 0.00, reads: 0.00, writes: 3101.01, response time: 21.65ms (95%), errors: 0.00, reconnects:  0.00
[3083s] threads: 64, tps: 0.00, reads: 0.00, writes: 3081.00, response time: 21.76ms (95%), errors: 0.00, reconnects:  0.00
[3084s] threads: 64, tps: 0.00, reads: 0.00, writes: 3100.00, response time: 21.73ms (95%), errors: 0.00, reconnects:  0.00
[3085s] threads: 64, tps: 0.00, reads: 0.00, writes: 3075.00, response time: 21.71ms (95%), errors: 0.00, reconnects:  0.00
[3086s] threads: 64, tps: 0.00, reads: 0.00, writes: 28062.02, response time: 3.46ms (95%), errors: 0.00, reconnects:  0.00
[3087s] threads: 64, tps: 0.00, reads: 0.00, writes: 33172.02, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[3088s] threads: 64, tps: 0.00, reads: 0.00, writes: 36609.98, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3089s] threads: 64, tps: 0.00, reads: 0.00, writes: 39511.96, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3090s] threads: 64, tps: 0.00, reads: 0.00, writes: 36048.98, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[3091s] threads: 64, tps: 0.00, reads: 0.00, writes: 30907.98, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[3092s] threads: 64, tps: 0.00, reads: 0.00, writes: 36095.10, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3093s] threads: 64, tps: 0.00, reads: 0.00, writes: 35714.95, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3094s] threads: 64, tps: 0.00, reads: 0.00, writes: 39952.97, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3095s] threads: 64, tps: 0.00, reads: 0.00, writes: 37442.01, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3096s] threads: 64, tps: 0.00, reads: 0.00, writes: 36588.07, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3097s] threads: 64, tps: 0.00, reads: 0.00, writes: 36149.97, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3098s] threads: 64, tps: 0.00, reads: 0.00, writes: 35153.98, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[3099s] threads: 64, tps: 0.00, reads: 0.00, writes: 37054.03, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3100s] threads: 64, tps: 0.00, reads: 0.00, writes: 40663.03, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3101s] threads: 64, tps: 0.00, reads: 0.00, writes: 38688.97, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3102s] threads: 64, tps: 0.00, reads: 0.00, writes: 38157.99, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[3103s] threads: 64, tps: 0.00, reads: 0.00, writes: 37392.94, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[3104s] threads: 64, tps: 0.00, reads: 0.00, writes: 36676.98, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[3105s] threads: 64, tps: 0.00, reads: 0.00, writes: 41019.06, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3106s] threads: 64, tps: 0.00, reads: 0.00, writes: 38617.98, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3107s] threads: 64, tps: 0.00, reads: 0.00, writes: 36181.92, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[3108s] threads: 64, tps: 0.00, reads: 0.00, writes: 37274.12, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3109s] threads: 64, tps: 0.00, reads: 0.00, writes: 35862.87, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[3110s] threads: 64, tps: 0.00, reads: 0.00, writes: 40028.94, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3111s] threads: 64, tps: 0.00, reads: 0.00, writes: 39204.17, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3112s] threads: 64, tps: 0.00, reads: 0.00, writes: 36831.05, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3113s] threads: 64, tps: 0.00, reads: 0.00, writes: 34377.84, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[3114s] threads: 64, tps: 0.00, reads: 0.00, writes: 32466.17, response time: 3.10ms (95%), errors: 0.00, reconnects:  0.00
[3115s] threads: 64, tps: 0.00, reads: 0.00, writes: 33791.00, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[3116s] threads: 64, tps: 0.00, reads: 0.00, writes: 40450.92, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[3117s] threads: 64, tps: 0.00, reads: 0.00, writes: 36599.06, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[3118s] threads: 64, tps: 0.00, reads: 0.00, writes: 34340.01, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[3119s] threads: 64, tps: 0.00, reads: 0.00, writes: 35397.77, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[3120s] threads: 64, tps: 0.00, reads: 0.00, writes: 33960.22, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[3121s] threads: 64, tps: 0.00, reads: 0.00, writes: 39052.98, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3122s] threads: 64, tps: 0.00, reads: 0.00, writes: 39220.97, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3123s] threads: 64, tps: 0.00, reads: 0.00, writes: 35489.88, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[3124s] threads: 64, tps: 0.00, reads: 0.00, writes: 35553.16, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[3125s] threads: 64, tps: 0.00, reads: 0.00, writes: 34629.97, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[3126s] threads: 64, tps: 0.00, reads: 0.00, writes: 33903.03, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[3127s] threads: 64, tps: 0.00, reads: 0.00, writes: 38838.98, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3128s] threads: 64, tps: 0.00, reads: 0.00, writes: 15106.67, response time: 20.72ms (95%), errors: 0.00, reconnects:  0.00
[3129s] threads: 64, tps: 0.00, reads: 0.00, writes: 9925.17, response time: 21.36ms (95%), errors: 0.00, reconnects:  0.00
[3130s] threads: 64, tps: 0.00, reads: 0.00, writes: 30906.13, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[3131s] threads: 64, tps: 0.00, reads: 0.00, writes: 33605.98, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[3132s] threads: 64, tps: 0.00, reads: 0.00, writes: 33395.98, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[3133s] threads: 64, tps: 0.00, reads: 0.00, writes: 35452.12, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[3134s] threads: 64, tps: 0.00, reads: 0.00, writes: 42782.94, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3135s] threads: 64, tps: 0.00, reads: 0.00, writes: 38876.07, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3136s] threads: 64, tps: 0.00, reads: 0.00, writes: 39519.04, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3137s] threads: 64, tps: 0.00, reads: 0.00, writes: 39073.03, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3138s] threads: 64, tps: 0.00, reads: 0.00, writes: 37869.83, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3139s] threads: 64, tps: 0.00, reads: 0.00, writes: 41338.13, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3140s] threads: 64, tps: 0.00, reads: 0.00, writes: 34699.04, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[3141s] threads: 64, tps: 0.00, reads: 0.00, writes: 38645.91, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3142s] threads: 64, tps: 0.00, reads: 0.00, writes: 37237.03, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3143s] threads: 64, tps: 0.00, reads: 0.00, writes: 37414.86, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3144s] threads: 64, tps: 0.00, reads: 0.00, writes: 39004.23, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3145s] threads: 64, tps: 0.00, reads: 0.00, writes: 40494.96, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3146s] threads: 64, tps: 0.00, reads: 0.00, writes: 37945.06, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3147s] threads: 64, tps: 0.00, reads: 0.00, writes: 38180.96, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3148s] threads: 64, tps: 0.00, reads: 0.00, writes: 37038.03, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3149s] threads: 64, tps: 0.00, reads: 0.00, writes: 37487.85, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[3150s] threads: 64, tps: 0.00, reads: 0.00, writes: 40501.18, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3151s] threads: 64, tps: 0.00, reads: 0.00, writes: 38448.97, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3152s] threads: 64, tps: 0.00, reads: 0.00, writes: 37077.97, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3153s] threads: 64, tps: 0.00, reads: 0.00, writes: 36585.02, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3154s] threads: 64, tps: 0.00, reads: 0.00, writes: 36957.84, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3155s] threads: 64, tps: 0.00, reads: 0.00, writes: 41171.34, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3156s] threads: 64, tps: 0.00, reads: 0.00, writes: 39107.84, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3157s] threads: 64, tps: 0.00, reads: 0.00, writes: 37095.01, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[3158s] threads: 64, tps: 0.00, reads: 0.00, writes: 29096.96, response time: 3.61ms (95%), errors: 0.00, reconnects:  0.00
[3159s] threads: 64, tps: 0.00, reads: 0.00, writes: 29374.04, response time: 3.36ms (95%), errors: 0.00, reconnects:  0.00
[3160s] threads: 64, tps: 0.00, reads: 0.00, writes: 31367.00, response time: 3.39ms (95%), errors: 0.00, reconnects:  0.00
[3161s] threads: 64, tps: 0.00, reads: 0.00, writes: 37607.94, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[3162s] threads: 64, tps: 0.00, reads: 0.00, writes: 28924.11, response time: 3.69ms (95%), errors: 0.00, reconnects:  0.00
[3163s] threads: 64, tps: 0.00, reads: 0.00, writes: 29770.03, response time: 3.30ms (95%), errors: 0.00, reconnects:  0.00
[3164s] threads: 64, tps: 0.00, reads: 0.00, writes: 30088.89, response time: 3.48ms (95%), errors: 0.00, reconnects:  0.00
[3165s] threads: 64, tps: 0.00, reads: 0.00, writes: 33827.12, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[3166s] threads: 64, tps: 0.00, reads: 0.00, writes: 37165.82, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[3167s] threads: 64, tps: 0.00, reads: 0.00, writes: 39912.01, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3168s] threads: 64, tps: 0.00, reads: 0.00, writes: 37366.07, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[3169s] threads: 64, tps: 0.00, reads: 0.00, writes: 9222.82, response time: 21.34ms (95%), errors: 0.00, reconnects:  0.00
[3170s] threads: 64, tps: 0.00, reads: 0.00, writes: 3091.07, response time: 21.57ms (95%), errors: 0.00, reconnects:  0.00
[3171s] threads: 64, tps: 0.00, reads: 0.00, writes: 3088.99, response time: 21.68ms (95%), errors: 0.00, reconnects:  0.00
[3172s] threads: 64, tps: 0.00, reads: 0.00, writes: 3095.02, response time: 21.70ms (95%), errors: 0.00, reconnects:  0.00
[3173s] threads: 64, tps: 0.00, reads: 0.00, writes: 3089.99, response time: 21.62ms (95%), errors: 0.00, reconnects:  0.00
[3174s] threads: 64, tps: 0.00, reads: 0.00, writes: 3079.01, response time: 21.69ms (95%), errors: 0.00, reconnects:  0.00
[3175s] threads: 64, tps: 0.00, reads: 0.00, writes: 3088.98, response time: 21.77ms (95%), errors: 0.00, reconnects:  0.00
[3176s] threads: 64, tps: 0.00, reads: 0.00, writes: 3087.00, response time: 21.69ms (95%), errors: 0.00, reconnects:  0.00
[3177s] threads: 64, tps: 0.00, reads: 0.00, writes: 3089.01, response time: 21.64ms (95%), errors: 0.00, reconnects:  0.00
[3178s] threads: 64, tps: 0.00, reads: 0.00, writes: 3093.99, response time: 21.72ms (95%), errors: 0.00, reconnects:  0.00
[3179s] threads: 64, tps: 0.00, reads: 0.00, writes: 20417.07, response time: 18.80ms (95%), errors: 0.00, reconnects:  0.00
[3180s] threads: 64, tps: 0.00, reads: 0.00, writes: 32244.85, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[3181s] threads: 64, tps: 0.00, reads: 0.00, writes: 37464.10, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[3182s] threads: 64, tps: 0.00, reads: 0.00, writes: 39795.10, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[3183s] threads: 64, tps: 0.00, reads: 0.00, writes: 39455.92, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[3184s] threads: 64, tps: 0.00, reads: 0.00, writes: 38996.09, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3185s] threads: 64, tps: 0.00, reads: 0.00, writes: 38451.81, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3186s] threads: 64, tps: 0.00, reads: 0.00, writes: 39653.16, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3187s] threads: 64, tps: 0.00, reads: 0.00, writes: 41212.98, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3188s] threads: 64, tps: 0.00, reads: 0.00, writes: 39840.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3189s] threads: 64, tps: 0.00, reads: 0.00, writes: 39013.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3190s] threads: 64, tps: 0.00, reads: 0.00, writes: 37892.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3191s] threads: 64, tps: 0.00, reads: 0.00, writes: 37453.82, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3192s] threads: 64, tps: 0.00, reads: 0.00, writes: 42422.19, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3193s] threads: 64, tps: 0.00, reads: 0.00, writes: 39266.03, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3194s] threads: 64, tps: 0.00, reads: 0.00, writes: 38594.91, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3195s] threads: 64, tps: 0.00, reads: 0.00, writes: 38289.03, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3196s] threads: 64, tps: 0.00, reads: 0.00, writes: 26754.00, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[3197s] threads: 64, tps: 0.00, reads: 0.00, writes: 42186.86, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3198s] threads: 64, tps: 0.00, reads: 0.00, writes: 40692.00, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3199s] threads: 64, tps: 0.00, reads: 0.00, writes: 39295.11, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3200s] threads: 64, tps: 0.00, reads: 0.00, writes: 38522.83, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3201s] threads: 64, tps: 0.00, reads: 0.00, writes: 37766.17, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3202s] threads: 64, tps: 0.00, reads: 0.00, writes: 41434.08, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3203s] threads: 64, tps: 0.00, reads: 0.00, writes: 41269.95, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3204s] threads: 64, tps: 0.00, reads: 0.00, writes: 38901.63, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3205s] threads: 64, tps: 0.00, reads: 0.00, writes: 36777.94, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3206s] threads: 64, tps: 0.00, reads: 0.00, writes: 36845.48, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3207s] threads: 64, tps: 0.00, reads: 0.00, writes: 38462.90, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3208s] threads: 64, tps: 0.00, reads: 0.00, writes: 38221.99, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3209s] threads: 64, tps: 0.00, reads: 0.00, writes: 38234.04, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[3210s] threads: 64, tps: 0.00, reads: 0.00, writes: 31909.96, response time: 3.42ms (95%), errors: 0.00, reconnects:  0.00
[3211s] threads: 64, tps: 0.00, reads: 0.00, writes: 30443.02, response time: 3.23ms (95%), errors: 0.00, reconnects:  0.00
[3212s] threads: 64, tps: 0.00, reads: 0.00, writes: 28597.86, response time: 3.55ms (95%), errors: 0.00, reconnects:  0.00
[3213s] threads: 64, tps: 0.00, reads: 0.00, writes: 33588.32, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[3214s] threads: 64, tps: 0.00, reads: 0.00, writes: 36608.91, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[3215s] threads: 64, tps: 0.00, reads: 0.00, writes: 30559.01, response time: 3.32ms (95%), errors: 0.00, reconnects:  0.00
[3216s] threads: 64, tps: 0.00, reads: 0.00, writes: 28623.99, response time: 3.51ms (95%), errors: 0.00, reconnects:  0.00
[3217s] threads: 64, tps: 0.00, reads: 0.00, writes: 30168.64, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[3218s] threads: 64, tps: 0.00, reads: 0.00, writes: 35326.41, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[3219s] threads: 64, tps: 0.00, reads: 0.00, writes: 37823.05, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3220s] threads: 64, tps: 0.00, reads: 0.00, writes: 39945.96, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3221s] threads: 64, tps: 0.00, reads: 0.00, writes: 37644.64, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[3222s] threads: 64, tps: 0.00, reads: 0.00, writes: 35052.32, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[3224s] threads: 64, tps: 0.00, reads: 0.00, writes: 34778.98, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[3224s] threads: 64, tps: 0.00, reads: 0.00, writes: 33765.04, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[3225s] threads: 64, tps: 0.00, reads: 0.00, writes: 40482.86, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3226s] threads: 64, tps: 0.00, reads: 0.00, writes: 38413.14, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3227s] threads: 64, tps: 0.00, reads: 0.00, writes: 17416.68, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[3228s] threads: 64, tps: 0.00, reads: 0.00, writes: 3083.97, response time: 21.71ms (95%), errors: 0.00, reconnects:  0.00
[3229s] threads: 64, tps: 0.00, reads: 0.00, writes: 3089.06, response time: 21.64ms (95%), errors: 0.00, reconnects:  0.00
[3230s] threads: 64, tps: 0.00, reads: 0.00, writes: 6801.05, response time: 21.33ms (95%), errors: 0.00, reconnects:  0.00
[3231s] threads: 64, tps: 0.00, reads: 0.00, writes: 29299.03, response time: 3.24ms (95%), errors: 0.00, reconnects:  0.00
[3232s] threads: 64, tps: 0.00, reads: 0.00, writes: 33980.92, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[3233s] threads: 64, tps: 0.00, reads: 0.00, writes: 36532.85, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3234s] threads: 64, tps: 0.00, reads: 0.00, writes: 40332.23, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[3235s] threads: 64, tps: 0.00, reads: 0.00, writes: 36732.01, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[3236s] threads: 64, tps: 0.00, reads: 0.00, writes: 37918.02, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[3237s] threads: 64, tps: 0.00, reads: 0.00, writes: 37816.96, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3238s] threads: 64, tps: 0.00, reads: 0.00, writes: 37975.05, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3239s] threads: 64, tps: 0.00, reads: 0.00, writes: 43210.95, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3240s] threads: 64, tps: 0.00, reads: 0.00, writes: 40397.02, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3241s] threads: 64, tps: 0.00, reads: 0.00, writes: 39682.82, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3242s] threads: 64, tps: 0.00, reads: 0.00, writes: 38960.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3243s] threads: 64, tps: 0.00, reads: 0.00, writes: 37786.11, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3244s] threads: 64, tps: 0.00, reads: 0.00, writes: 43387.88, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[3245s] threads: 64, tps: 0.00, reads: 0.00, writes: 39479.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3246s] threads: 64, tps: 0.00, reads: 0.00, writes: 35647.91, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3247s] threads: 64, tps: 0.00, reads: 0.00, writes: 33741.97, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[3248s] threads: 64, tps: 0.00, reads: 0.00, writes: 36727.97, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[3249s] threads: 64, tps: 0.00, reads: 0.00, writes: 40897.79, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3250s] threads: 64, tps: 0.00, reads: 0.00, writes: 40109.44, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3251s] threads: 64, tps: 0.00, reads: 0.00, writes: 38487.98, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3252s] threads: 64, tps: 0.00, reads: 0.00, writes: 37620.96, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3253s] threads: 64, tps: 0.00, reads: 0.00, writes: 37684.01, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3254s] threads: 64, tps: 0.00, reads: 0.00, writes: 38948.04, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3255s] threads: 64, tps: 0.00, reads: 0.00, writes: 40371.01, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3256s] threads: 64, tps: 0.00, reads: 0.00, writes: 38703.93, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3257s] threads: 64, tps: 0.00, reads: 0.00, writes: 36118.07, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[3258s] threads: 64, tps: 0.00, reads: 0.00, writes: 37490.96, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3259s] threads: 64, tps: 0.00, reads: 0.00, writes: 38080.02, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3260s] threads: 64, tps: 0.00, reads: 0.00, writes: 40196.97, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3261s] threads: 64, tps: 0.00, reads: 0.00, writes: 33735.98, response time: 3.16ms (95%), errors: 0.00, reconnects:  0.00
[3262s] threads: 64, tps: 0.00, reads: 0.00, writes: 30721.05, response time: 3.18ms (95%), errors: 0.00, reconnects:  0.00
[3263s] threads: 64, tps: 0.00, reads: 0.00, writes: 28238.98, response time: 3.56ms (95%), errors: 0.00, reconnects:  0.00
[3264s] threads: 64, tps: 0.00, reads: 0.00, writes: 33513.98, response time: 3.01ms (95%), errors: 0.00, reconnects:  0.00
[3265s] threads: 64, tps: 0.00, reads: 0.00, writes: 36479.00, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[3266s] threads: 64, tps: 0.00, reads: 0.00, writes: 39734.06, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[3267s] threads: 64, tps: 0.00, reads: 0.00, writes: 37887.87, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[3268s] threads: 64, tps: 0.00, reads: 0.00, writes: 35214.11, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[3269s] threads: 64, tps: 0.00, reads: 0.00, writes: 35307.99, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[3270s] threads: 64, tps: 0.00, reads: 0.00, writes: 34695.32, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[3271s] threads: 64, tps: 0.00, reads: 0.00, writes: 39895.20, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[3272s] threads: 64, tps: 0.00, reads: 0.00, writes: 39332.76, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[3273s] threads: 64, tps: 0.00, reads: 0.00, writes: 33409.42, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[3274s] threads: 64, tps: 0.00, reads: 0.00, writes: 3081.07, response time: 21.94ms (95%), errors: 0.00, reconnects:  0.00
[3275s] threads: 64, tps: 0.00, reads: 0.00, writes: 3111.00, response time: 21.57ms (95%), errors: 0.00, reconnects:  0.00
[3276s] threads: 64, tps: 0.00, reads: 0.00, writes: 3087.01, response time: 21.73ms (95%), errors: 0.00, reconnects:  0.00
[3277s] threads: 64, tps: 0.00, reads: 0.00, writes: 3092.00, response time: 21.61ms (95%), errors: 0.00, reconnects:  0.00
[3278s] threads: 64, tps: 0.00, reads: 0.00, writes: 10028.01, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[3279s] threads: 64, tps: 0.00, reads: 0.00, writes: 33961.99, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[3280s] threads: 64, tps: 0.00, reads: 0.00, writes: 37047.02, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3281s] threads: 64, tps: 0.00, reads: 0.00, writes: 40101.94, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3282s] threads: 64, tps: 0.00, reads: 0.00, writes: 38880.07, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3283s] threads: 64, tps: 0.00, reads: 0.00, writes: 39054.01, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3284s] threads: 64, tps: 0.00, reads: 0.00, writes: 38312.98, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3285s] threads: 64, tps: 0.00, reads: 0.00, writes: 37723.97, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3286s] threads: 64, tps: 0.00, reads: 0.00, writes: 42017.97, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3287s] threads: 64, tps: 0.00, reads: 0.00, writes: 39427.03, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3288s] threads: 64, tps: 0.00, reads: 0.00, writes: 39406.02, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3289s] threads: 64, tps: 0.00, reads: 0.00, writes: 39505.96, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3290s] threads: 64, tps: 0.00, reads: 0.00, writes: 38219.86, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3291s] threads: 64, tps: 0.00, reads: 0.00, writes: 40583.27, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3292s] threads: 64, tps: 0.00, reads: 0.00, writes: 40476.85, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3293s] threads: 64, tps: 0.00, reads: 0.00, writes: 38542.12, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3294s] threads: 64, tps: 0.00, reads: 0.00, writes: 37801.91, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3295s] threads: 64, tps: 0.00, reads: 0.00, writes: 37612.04, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3296s] threads: 64, tps: 0.00, reads: 0.00, writes: 39588.98, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3297s] threads: 64, tps: 0.00, reads: 0.00, writes: 34439.03, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[3298s] threads: 64, tps: 0.00, reads: 0.00, writes: 39338.91, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3299s] threads: 64, tps: 0.00, reads: 0.00, writes: 38673.06, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3300s] threads: 64, tps: 0.00, reads: 0.00, writes: 37675.05, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3301s] threads: 64, tps: 0.00, reads: 0.00, writes: 39070.94, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3302s] threads: 64, tps: 0.00, reads: 0.00, writes: 39531.97, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[3303s] threads: 64, tps: 0.00, reads: 0.00, writes: 32847.07, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[3304s] threads: 64, tps: 0.00, reads: 0.00, writes: 29349.02, response time: 3.42ms (95%), errors: 0.00, reconnects:  0.00
[3305s] threads: 64, tps: 0.00, reads: 0.00, writes: 27893.96, response time: 3.78ms (95%), errors: 0.00, reconnects:  0.00
[3306s] threads: 64, tps: 0.00, reads: 0.00, writes: 30060.01, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[3307s] threads: 64, tps: 0.00, reads: 0.00, writes: 29476.02, response time: 3.38ms (95%), errors: 0.00, reconnects:  0.00
[3308s] threads: 64, tps: 0.00, reads: 0.00, writes: 39537.96, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[3309s] threads: 64, tps: 0.00, reads: 0.00, writes: 32574.46, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[3310s] threads: 64, tps: 0.00, reads: 0.00, writes: 33494.56, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[3311s] threads: 64, tps: 0.00, reads: 0.00, writes: 35227.12, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[3312s] threads: 64, tps: 0.00, reads: 0.00, writes: 34472.94, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[3313s] threads: 64, tps: 0.00, reads: 0.00, writes: 36980.01, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[3314s] threads: 64, tps: 0.00, reads: 0.00, writes: 39781.99, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3315s] threads: 64, tps: 0.00, reads: 0.00, writes: 35793.02, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3316s] threads: 64, tps: 0.00, reads: 0.00, writes: 34007.00, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[3317s] threads: 64, tps: 0.00, reads: 0.00, writes: 34817.97, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[3318s] threads: 64, tps: 0.00, reads: 0.00, writes: 34269.98, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[3319s] threads: 64, tps: 0.00, reads: 0.00, writes: 38626.04, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[3320s] threads: 64, tps: 0.00, reads: 0.00, writes: 38656.01, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[3321s] threads: 64, tps: 0.00, reads: 0.00, writes: 15481.00, response time: 20.74ms (95%), errors: 0.00, reconnects:  0.00
[3322s] threads: 64, tps: 0.00, reads: 0.00, writes: 3092.98, response time: 21.58ms (95%), errors: 0.00, reconnects:  0.00
[3323s] threads: 64, tps: 0.00, reads: 0.00, writes: 18074.15, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[3324s] threads: 64, tps: 0.00, reads: 0.00, writes: 30392.97, response time: 3.13ms (95%), errors: 0.00, reconnects:  0.00
[3325s] threads: 64, tps: 0.00, reads: 0.00, writes: 30950.81, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[3326s] threads: 64, tps: 0.00, reads: 0.00, writes: 32671.42, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[3327s] threads: 64, tps: 0.00, reads: 0.00, writes: 41108.94, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3328s] threads: 64, tps: 0.00, reads: 0.00, writes: 38668.07, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[3329s] threads: 64, tps: 0.00, reads: 0.00, writes: 38317.98, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3330s] threads: 64, tps: 0.00, reads: 0.00, writes: 38023.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3331s] threads: 64, tps: 0.00, reads: 0.00, writes: 37795.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3332s] threads: 64, tps: 0.00, reads: 0.00, writes: 42012.01, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3333s] threads: 64, tps: 0.00, reads: 0.00, writes: 40411.04, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3334s] threads: 64, tps: 0.00, reads: 0.00, writes: 39205.92, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3335s] threads: 64, tps: 0.00, reads: 0.00, writes: 38598.00, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3336s] threads: 64, tps: 0.00, reads: 0.00, writes: 38059.85, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3337s] threads: 64, tps: 0.00, reads: 0.00, writes: 40535.18, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3338s] threads: 64, tps: 0.00, reads: 0.00, writes: 40067.03, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3339s] threads: 64, tps: 0.00, reads: 0.00, writes: 38996.80, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3340s] threads: 64, tps: 0.00, reads: 0.00, writes: 36457.16, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[3341s] threads: 64, tps: 0.00, reads: 0.00, writes: 38038.02, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3342s] threads: 64, tps: 0.00, reads: 0.00, writes: 40219.02, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3343s] threads: 64, tps: 0.00, reads: 0.00, writes: 40812.96, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3344s] threads: 64, tps: 0.00, reads: 0.00, writes: 38156.01, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3345s] threads: 64, tps: 0.00, reads: 0.00, writes: 38009.98, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3346s] threads: 64, tps: 0.00, reads: 0.00, writes: 37931.99, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3347s] threads: 64, tps: 0.00, reads: 0.00, writes: 31059.02, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3348s] threads: 64, tps: 0.00, reads: 0.00, writes: 41577.94, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3349s] threads: 64, tps: 0.00, reads: 0.00, writes: 38336.93, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3350s] threads: 64, tps: 0.00, reads: 0.00, writes: 38400.13, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3351s] threads: 64, tps: 0.00, reads: 0.00, writes: 36383.00, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[3352s] threads: 64, tps: 0.00, reads: 0.00, writes: 35937.97, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[3353s] threads: 64, tps: 0.00, reads: 0.00, writes: 39843.08, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3354s] threads: 64, tps: 0.00, reads: 0.00, writes: 36517.99, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[3355s] threads: 64, tps: 0.00, reads: 0.00, writes: 31244.98, response time: 3.26ms (95%), errors: 0.00, reconnects:  0.00
[3356s] threads: 64, tps: 0.00, reads: 0.00, writes: 30946.97, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[3357s] threads: 64, tps: 0.00, reads: 0.00, writes: 35027.05, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[3358s] threads: 64, tps: 0.00, reads: 0.00, writes: 35686.99, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[3359s] threads: 64, tps: 0.00, reads: 0.00, writes: 40746.93, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3360s] threads: 64, tps: 0.00, reads: 0.00, writes: 38068.06, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[3361s] threads: 64, tps: 0.00, reads: 0.00, writes: 35187.96, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[3362s] threads: 64, tps: 0.00, reads: 0.00, writes: 34771.05, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[3363s] threads: 64, tps: 0.00, reads: 0.00, writes: 33823.00, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[3364s] threads: 64, tps: 0.00, reads: 0.00, writes: 37562.01, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3365s] threads: 64, tps: 0.00, reads: 0.00, writes: 40079.92, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3366s] threads: 64, tps: 0.00, reads: 0.00, writes: 32752.08, response time: 2.99ms (95%), errors: 0.00, reconnects:  0.00
[3367s] threads: 64, tps: 0.00, reads: 0.00, writes: 3092.93, response time: 21.85ms (95%), errors: 0.00, reconnects:  0.00
[3368s] threads: 64, tps: 0.00, reads: 0.00, writes: 3092.07, response time: 21.70ms (95%), errors: 0.00, reconnects:  0.00
[3369s] threads: 64, tps: 0.00, reads: 0.00, writes: 3093.00, response time: 21.58ms (95%), errors: 0.00, reconnects:  0.00
[3370s] threads: 64, tps: 0.00, reads: 0.00, writes: 3084.00, response time: 21.79ms (95%), errors: 0.00, reconnects:  0.00
[3371s] threads: 64, tps: 0.00, reads: 0.00, writes: 20629.00, response time: 19.75ms (95%), errors: 0.00, reconnects:  0.00
[3372s] threads: 64, tps: 0.00, reads: 0.00, writes: 30830.96, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[3373s] threads: 64, tps: 0.00, reads: 0.00, writes: 34004.02, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[3374s] threads: 64, tps: 0.00, reads: 0.00, writes: 38814.00, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[3375s] threads: 64, tps: 0.00, reads: 0.00, writes: 37403.00, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[3376s] threads: 64, tps: 0.00, reads: 0.00, writes: 37245.02, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[3377s] threads: 64, tps: 0.00, reads: 0.00, writes: 37254.84, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[3378s] threads: 64, tps: 0.00, reads: 0.00, writes: 37827.21, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3379s] threads: 64, tps: 0.00, reads: 0.00, writes: 39776.93, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3380s] threads: 64, tps: 0.00, reads: 0.00, writes: 41226.03, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3381s] threads: 64, tps: 0.00, reads: 0.00, writes: 38660.06, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3382s] threads: 64, tps: 0.00, reads: 0.00, writes: 37792.85, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3383s] threads: 64, tps: 0.00, reads: 0.00, writes: 37779.09, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3384s] threads: 64, tps: 0.00, reads: 0.00, writes: 38199.90, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3385s] threads: 64, tps: 0.00, reads: 0.00, writes: 42040.12, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3386s] threads: 64, tps: 0.00, reads: 0.00, writes: 39384.02, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3387s] threads: 64, tps: 0.00, reads: 0.00, writes: 38599.11, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3388s] threads: 64, tps: 0.00, reads: 0.00, writes: 37916.81, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3389s] threads: 64, tps: 0.00, reads: 0.00, writes: 37863.07, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[3390s] threads: 64, tps: 0.00, reads: 0.00, writes: 39972.97, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3391s] threads: 64, tps: 0.00, reads: 0.00, writes: 38787.98, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3392s] threads: 64, tps: 0.00, reads: 0.00, writes: 38221.97, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3393s] threads: 64, tps: 0.00, reads: 0.00, writes: 37588.05, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3394s] threads: 64, tps: 0.00, reads: 0.00, writes: 37734.90, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3395s] threads: 64, tps: 0.00, reads: 0.00, writes: 42142.13, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3396s] threads: 64, tps: 0.00, reads: 0.00, writes: 39572.96, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3397s] threads: 64, tps: 0.00, reads: 0.00, writes: 37089.04, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3398s] threads: 64, tps: 0.00, reads: 0.00, writes: 30827.98, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3399s] threads: 64, tps: 0.00, reads: 0.00, writes: 35204.02, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[3400s] threads: 64, tps: 0.00, reads: 0.00, writes: 39625.97, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3401s] threads: 64, tps: 0.00, reads: 0.00, writes: 39329.04, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3402s] threads: 64, tps: 0.00, reads: 0.00, writes: 36561.97, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[3403s] threads: 64, tps: 0.00, reads: 0.00, writes: 28806.04, response time: 3.62ms (95%), errors: 0.00, reconnects:  0.00
[3404s] threads: 64, tps: 0.00, reads: 0.00, writes: 33490.97, response time: 3.11ms (95%), errors: 0.00, reconnects:  0.00
[3405s] threads: 64, tps: 0.00, reads: 0.00, writes: 34104.94, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[3406s] threads: 64, tps: 0.00, reads: 0.00, writes: 40423.07, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3407s] threads: 64, tps: 0.00, reads: 0.00, writes: 38803.00, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3408s] threads: 64, tps: 0.00, reads: 0.00, writes: 34848.97, response time: 2.85ms (95%), errors: 0.00, reconnects:  0.00
[3409s] threads: 64, tps: 0.00, reads: 0.00, writes: 34987.00, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[3410s] threads: 64, tps: 0.00, reads: 0.00, writes: 33880.05, response time: 2.90ms (95%), errors: 0.00, reconnects:  0.00
[3411s] threads: 64, tps: 0.00, reads: 0.00, writes: 36388.95, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[3412s] threads: 64, tps: 0.00, reads: 0.00, writes: 38530.01, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3413s] threads: 64, tps: 0.00, reads: 0.00, writes: 36618.00, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[3414s] threads: 64, tps: 0.00, reads: 0.00, writes: 8794.99, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[3415s] threads: 64, tps: 0.00, reads: 0.00, writes: 3096.00, response time: 21.77ms (95%), errors: 0.00, reconnects:  0.00
[3416s] threads: 64, tps: 0.00, reads: 0.00, writes: 4109.00, response time: 21.53ms (95%), errors: 0.00, reconnects:  0.00
[3417s] threads: 64, tps: 0.00, reads: 0.00, writes: 28899.99, response time: 3.32ms (95%), errors: 0.00, reconnects:  0.00
[3418s] threads: 64, tps: 0.00, reads: 0.00, writes: 31035.00, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[3419s] threads: 64, tps: 0.00, reads: 0.00, writes: 31504.97, response time: 3.03ms (95%), errors: 0.00, reconnects:  0.00
[3420s] threads: 64, tps: 0.00, reads: 0.00, writes: 39072.05, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[3421s] threads: 64, tps: 0.00, reads: 0.00, writes: 36489.01, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[3422s] threads: 64, tps: 0.00, reads: 0.00, writes: 36691.00, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[3423s] threads: 64, tps: 0.00, reads: 0.00, writes: 38478.96, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3424s] threads: 64, tps: 0.00, reads: 0.00, writes: 38201.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3425s] threads: 64, tps: 0.00, reads: 0.00, writes: 41959.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3426s] threads: 64, tps: 0.00, reads: 0.00, writes: 41310.95, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3427s] threads: 64, tps: 0.00, reads: 0.00, writes: 39900.07, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3428s] threads: 64, tps: 0.00, reads: 0.00, writes: 38457.95, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3429s] threads: 64, tps: 0.00, reads: 0.00, writes: 38363.06, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3430s] threads: 64, tps: 0.00, reads: 0.00, writes: 41756.49, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3431s] threads: 64, tps: 0.00, reads: 0.00, writes: 40123.38, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3432s] threads: 64, tps: 0.00, reads: 0.00, writes: 34255.09, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[3433s] threads: 64, tps: 0.00, reads: 0.00, writes: 37394.98, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[3434s] threads: 64, tps: 0.00, reads: 0.00, writes: 37395.97, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3435s] threads: 64, tps: 0.00, reads: 0.00, writes: 38295.04, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3436s] threads: 64, tps: 0.00, reads: 0.00, writes: 40555.96, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3437s] threads: 64, tps: 0.00, reads: 0.00, writes: 38541.98, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3438s] threads: 64, tps: 0.00, reads: 0.00, writes: 37541.00, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3439s] threads: 64, tps: 0.00, reads: 0.00, writes: 37785.04, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3440s] threads: 64, tps: 0.00, reads: 0.00, writes: 38889.03, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3441s] threads: 64, tps: 0.00, reads: 0.00, writes: 41321.99, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3442s] threads: 64, tps: 0.00, reads: 0.00, writes: 39039.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3443s] threads: 64, tps: 0.00, reads: 0.00, writes: 37016.00, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3444s] threads: 64, tps: 0.00, reads: 0.00, writes: 36159.90, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[3445s] threads: 64, tps: 0.00, reads: 0.00, writes: 36420.11, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3446s] threads: 64, tps: 0.00, reads: 0.00, writes: 42366.95, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3447s] threads: 64, tps: 0.00, reads: 0.00, writes: 32805.05, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3448s] threads: 64, tps: 0.00, reads: 0.00, writes: 37318.90, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3449s] threads: 64, tps: 0.00, reads: 0.00, writes: 36754.90, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[3450s] threads: 64, tps: 0.00, reads: 0.00, writes: 30525.13, response time: 3.44ms (95%), errors: 0.00, reconnects:  0.00
[3451s] threads: 64, tps: 0.00, reads: 0.00, writes: 31292.99, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[3452s] threads: 64, tps: 0.00, reads: 0.00, writes: 37425.03, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[3453s] threads: 64, tps: 0.00, reads: 0.00, writes: 28415.99, response time: 4.03ms (95%), errors: 0.00, reconnects:  0.00
[3454s] threads: 64, tps: 0.00, reads: 0.00, writes: 33864.99, response time: 2.92ms (95%), errors: 0.00, reconnects:  0.00
[3455s] threads: 64, tps: 0.00, reads: 0.00, writes: 34237.40, response time: 2.79ms (95%), errors: 0.00, reconnects:  0.00
[3456s] threads: 64, tps: 0.00, reads: 0.00, writes: 34766.72, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[3457s] threads: 64, tps: 0.00, reads: 0.00, writes: 36184.40, response time: 2.82ms (95%), errors: 0.00, reconnects:  0.00
[3458s] threads: 64, tps: 0.00, reads: 0.00, writes: 40217.64, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3459s] threads: 64, tps: 0.00, reads: 0.00, writes: 36408.04, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[3460s] threads: 64, tps: 0.00, reads: 0.00, writes: 7007.99, response time: 21.33ms (95%), errors: 0.00, reconnects:  0.00
[3461s] threads: 64, tps: 0.00, reads: 0.00, writes: 3103.00, response time: 21.57ms (95%), errors: 0.00, reconnects:  0.00
[3462s] threads: 64, tps: 0.00, reads: 0.00, writes: 3070.94, response time: 21.75ms (95%), errors: 0.00, reconnects:  0.00
[3463s] threads: 64, tps: 0.00, reads: 0.00, writes: 3103.06, response time: 21.66ms (95%), errors: 0.00, reconnects:  0.00
[3464s] threads: 64, tps: 0.00, reads: 0.00, writes: 3089.01, response time: 21.60ms (95%), errors: 0.00, reconnects:  0.00
[3465s] threads: 64, tps: 0.00, reads: 0.00, writes: 3096.00, response time: 21.62ms (95%), errors: 0.00, reconnects:  0.00
[3466s] threads: 64, tps: 0.00, reads: 0.00, writes: 3081.00, response time: 21.74ms (95%), errors: 0.00, reconnects:  0.00
[3467s] threads: 64, tps: 0.00, reads: 0.00, writes: 3090.78, response time: 21.77ms (95%), errors: 0.00, reconnects:  0.00
[3468s] threads: 64, tps: 0.00, reads: 0.00, writes: 10388.76, response time: 20.88ms (95%), errors: 0.00, reconnects:  0.00
[3469s] threads: 64, tps: 0.00, reads: 0.00, writes: 30868.97, response time: 3.07ms (95%), errors: 0.00, reconnects:  0.00
[3470s] threads: 64, tps: 0.00, reads: 0.00, writes: 33382.02, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[3471s] threads: 64, tps: 0.00, reads: 0.00, writes: 38512.03, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[3472s] threads: 64, tps: 0.00, reads: 0.00, writes: 36981.03, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[3473s] threads: 64, tps: 0.00, reads: 0.00, writes: 36462.95, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3474s] threads: 64, tps: 0.00, reads: 0.00, writes: 37009.03, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3475s] threads: 64, tps: 0.00, reads: 0.00, writes: 37477.99, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[3476s] threads: 64, tps: 0.00, reads: 0.00, writes: 40211.00, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3477s] threads: 64, tps: 0.00, reads: 0.00, writes: 41174.04, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3478s] threads: 64, tps: 0.00, reads: 0.00, writes: 40067.99, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3479s] threads: 64, tps: 0.00, reads: 0.00, writes: 38758.93, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3480s] threads: 64, tps: 0.00, reads: 0.00, writes: 38800.06, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3481s] threads: 64, tps: 0.00, reads: 0.00, writes: 40753.02, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3482s] threads: 64, tps: 0.00, reads: 0.00, writes: 39202.98, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3483s] threads: 64, tps: 0.00, reads: 0.00, writes: 40444.02, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3484s] threads: 64, tps: 0.00, reads: 0.00, writes: 38219.93, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3485s] threads: 64, tps: 0.00, reads: 0.00, writes: 37804.98, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3486s] threads: 64, tps: 0.00, reads: 0.00, writes: 39016.05, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3487s] threads: 64, tps: 0.00, reads: 0.00, writes: 42373.02, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3488s] threads: 64, tps: 0.00, reads: 0.00, writes: 39971.03, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3489s] threads: 64, tps: 0.00, reads: 0.00, writes: 38216.89, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3490s] threads: 64, tps: 0.00, reads: 0.00, writes: 37995.06, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3491s] threads: 64, tps: 0.00, reads: 0.00, writes: 37322.94, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3492s] threads: 64, tps: 0.00, reads: 0.00, writes: 41295.85, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3493s] threads: 64, tps: 0.00, reads: 0.00, writes: 39922.18, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3494s] threads: 64, tps: 0.00, reads: 0.00, writes: 37811.05, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3495s] threads: 64, tps: 0.00, reads: 0.00, writes: 37994.95, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3496s] threads: 64, tps: 0.00, reads: 0.00, writes: 36771.04, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3497s] threads: 64, tps: 0.00, reads: 0.00, writes: 42233.00, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3498s] threads: 64, tps: 0.00, reads: 0.00, writes: 38644.94, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3499s] threads: 64, tps: 0.00, reads: 0.00, writes: 36626.04, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[3500s] threads: 64, tps: 0.00, reads: 0.00, writes: 29083.92, response time: 3.67ms (95%), errors: 0.00, reconnects:  0.00
[3501s] threads: 64, tps: 0.00, reads: 0.00, writes: 30291.09, response time: 3.20ms (95%), errors: 0.00, reconnects:  0.00
[3502s] threads: 64, tps: 0.00, reads: 0.00, writes: 26217.80, response time: 3.64ms (95%), errors: 0.00, reconnects:  0.00
[3503s] threads: 64, tps: 0.00, reads: 0.00, writes: 37012.28, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[3504s] threads: 64, tps: 0.00, reads: 0.00, writes: 30344.97, response time: 3.50ms (95%), errors: 0.00, reconnects:  0.00
[3505s] threads: 64, tps: 0.00, reads: 0.00, writes: 31163.99, response time: 3.21ms (95%), errors: 0.00, reconnects:  0.00
[3506s] threads: 64, tps: 0.00, reads: 0.00, writes: 28928.02, response time: 3.49ms (95%), errors: 0.00, reconnects:  0.00
[3507s] threads: 64, tps: 0.00, reads: 0.00, writes: 34606.97, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[3508s] threads: 64, tps: 0.00, reads: 0.00, writes: 34383.02, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[3509s] threads: 64, tps: 0.00, reads: 0.00, writes: 39245.04, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[3510s] threads: 64, tps: 0.00, reads: 0.00, writes: 38611.98, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3511s] threads: 64, tps: 0.00, reads: 0.00, writes: 35497.02, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[3512s] threads: 64, tps: 0.00, reads: 0.00, writes: 33976.00, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[3513s] threads: 64, tps: 0.00, reads: 0.00, writes: 34028.98, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[3514s] threads: 64, tps: 0.00, reads: 0.00, writes: 36608.00, response time: 2.78ms (95%), errors: 0.00, reconnects:  0.00
[3515s] threads: 64, tps: 0.00, reads: 0.00, writes: 38870.97, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[3516s] threads: 64, tps: 0.00, reads: 0.00, writes: 37739.99, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3517s] threads: 64, tps: 0.00, reads: 0.00, writes: 13912.72, response time: 20.79ms (95%), errors: 0.00, reconnects:  0.00
[3518s] threads: 64, tps: 0.00, reads: 0.00, writes: 3101.07, response time: 21.76ms (95%), errors: 0.00, reconnects:  0.00
[3519s] threads: 64, tps: 0.00, reads: 0.00, writes: 12598.00, response time: 20.64ms (95%), errors: 0.00, reconnects:  0.00
[3520s] threads: 64, tps: 0.00, reads: 0.00, writes: 30710.94, response time: 3.12ms (95%), errors: 0.00, reconnects:  0.00
[3521s] threads: 64, tps: 0.00, reads: 0.00, writes: 33705.58, response time: 2.80ms (95%), errors: 0.00, reconnects:  0.00
[3522s] threads: 64, tps: 0.00, reads: 0.00, writes: 40075.51, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3523s] threads: 64, tps: 0.00, reads: 0.00, writes: 39378.01, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3524s] threads: 64, tps: 0.00, reads: 0.00, writes: 39209.05, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3525s] threads: 64, tps: 0.00, reads: 0.00, writes: 38479.95, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3526s] threads: 64, tps: 0.00, reads: 0.00, writes: 37902.02, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3527s] threads: 64, tps: 0.00, reads: 0.00, writes: 40917.99, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3528s] threads: 64, tps: 0.00, reads: 0.00, writes: 41695.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3529s] threads: 64, tps: 0.00, reads: 0.00, writes: 40525.03, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3530s] threads: 64, tps: 0.00, reads: 0.00, writes: 39680.99, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3531s] threads: 64, tps: 0.00, reads: 0.00, writes: 38878.93, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3532s] threads: 64, tps: 0.00, reads: 0.00, writes: 40962.08, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3533s] threads: 64, tps: 0.00, reads: 0.00, writes: 40399.00, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3534s] threads: 64, tps: 0.00, reads: 0.00, writes: 38650.96, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3535s] threads: 64, tps: 0.00, reads: 0.00, writes: 36957.95, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3536s] threads: 64, tps: 0.00, reads: 0.00, writes: 34702.03, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[3537s] threads: 64, tps: 0.00, reads: 0.00, writes: 37320.53, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3538s] threads: 64, tps: 0.00, reads: 0.00, writes: 39560.46, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3539s] threads: 64, tps: 0.00, reads: 0.00, writes: 39086.08, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3540s] threads: 64, tps: 0.00, reads: 0.00, writes: 37925.87, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3541s] threads: 64, tps: 0.00, reads: 0.00, writes: 37282.13, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3542s] threads: 64, tps: 0.00, reads: 0.00, writes: 36510.02, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[3543s] threads: 64, tps: 0.00, reads: 0.00, writes: 41936.93, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3544s] threads: 64, tps: 0.00, reads: 0.00, writes: 40208.02, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3545s] threads: 64, tps: 0.00, reads: 0.00, writes: 38860.86, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3546s] threads: 64, tps: 0.00, reads: 0.00, writes: 37152.98, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[3547s] threads: 64, tps: 0.00, reads: 0.00, writes: 36685.98, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3548s] threads: 64, tps: 0.00, reads: 0.00, writes: 40837.21, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3549s] threads: 64, tps: 0.00, reads: 0.00, writes: 39386.91, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3550s] threads: 64, tps: 0.00, reads: 0.00, writes: 37473.05, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3551s] threads: 64, tps: 0.00, reads: 0.00, writes: 29174.69, response time: 3.33ms (95%), errors: 0.00, reconnects:  0.00
[3552s] threads: 64, tps: 0.00, reads: 0.00, writes: 22694.19, response time: 4.13ms (95%), errors: 0.00, reconnects:  0.00
[3553s] threads: 64, tps: 0.00, reads: 0.00, writes: 28971.99, response time: 3.47ms (95%), errors: 0.00, reconnects:  0.00
[3554s] threads: 64, tps: 0.00, reads: 0.00, writes: 38772.03, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3555s] threads: 64, tps: 0.00, reads: 0.00, writes: 37362.04, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[3556s] threads: 64, tps: 0.00, reads: 0.00, writes: 34258.95, response time: 2.94ms (95%), errors: 0.00, reconnects:  0.00
[3557s] threads: 64, tps: 0.00, reads: 0.00, writes: 34466.08, response time: 2.88ms (95%), errors: 0.00, reconnects:  0.00
[3558s] threads: 64, tps: 0.00, reads: 0.00, writes: 33291.94, response time: 2.97ms (95%), errors: 0.00, reconnects:  0.00
[3559s] threads: 64, tps: 0.00, reads: 0.00, writes: 32349.04, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[3560s] threads: 64, tps: 0.00, reads: 0.00, writes: 40042.01, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[3561s] threads: 64, tps: 0.00, reads: 0.00, writes: 38565.78, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3562s] threads: 64, tps: 0.00, reads: 0.00, writes: 25068.52, response time: 7.77ms (95%), errors: 0.00, reconnects:  0.00
[3563s] threads: 64, tps: 0.00, reads: 0.00, writes: 3095.07, response time: 21.61ms (95%), errors: 0.00, reconnects:  0.00
[3564s] threads: 64, tps: 0.00, reads: 0.00, writes: 3086.00, response time: 21.61ms (95%), errors: 0.00, reconnects:  0.00
[3565s] threads: 64, tps: 0.00, reads: 0.00, writes: 3074.94, response time: 21.64ms (95%), errors: 0.00, reconnects:  0.00
[3566s] threads: 64, tps: 0.00, reads: 0.00, writes: 3098.07, response time: 21.83ms (95%), errors: 0.00, reconnects:  0.00
[3567s] threads: 64, tps: 0.00, reads: 0.00, writes: 3081.00, response time: 21.65ms (95%), errors: 0.00, reconnects:  0.00
[3568s] threads: 64, tps: 0.00, reads: 0.00, writes: 27294.97, response time: 3.41ms (95%), errors: 0.00, reconnects:  0.00
[3569s] threads: 64, tps: 0.00, reads: 0.00, writes: 33480.02, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[3570s] threads: 64, tps: 0.00, reads: 0.00, writes: 36353.96, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[3571s] threads: 64, tps: 0.00, reads: 0.00, writes: 40399.98, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3572s] threads: 64, tps: 0.00, reads: 0.00, writes: 37685.06, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[3573s] threads: 64, tps: 0.00, reads: 0.00, writes: 37038.97, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3574s] threads: 64, tps: 0.00, reads: 0.00, writes: 36571.02, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[3575s] threads: 64, tps: 0.00, reads: 0.00, writes: 36148.00, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[3576s] threads: 64, tps: 0.00, reads: 0.00, writes: 41942.95, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3577s] threads: 64, tps: 0.00, reads: 0.00, writes: 38815.27, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3578s] threads: 64, tps: 0.00, reads: 0.00, writes: 38829.70, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3579s] threads: 64, tps: 0.00, reads: 0.00, writes: 38153.05, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3580s] threads: 64, tps: 0.00, reads: 0.00, writes: 37863.05, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[3581s] threads: 64, tps: 0.00, reads: 0.00, writes: 42638.95, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3582s] threads: 64, tps: 0.00, reads: 0.00, writes: 40136.03, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3583s] threads: 64, tps: 0.00, reads: 0.00, writes: 35402.88, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3584s] threads: 64, tps: 0.00, reads: 0.00, writes: 37235.15, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3585s] threads: 64, tps: 0.00, reads: 0.00, writes: 36793.92, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3586s] threads: 64, tps: 0.00, reads: 0.00, writes: 40397.89, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3587s] threads: 64, tps: 0.00, reads: 0.00, writes: 40826.20, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3588s] threads: 64, tps: 0.00, reads: 0.00, writes: 39102.94, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3589s] threads: 64, tps: 0.00, reads: 0.00, writes: 37771.94, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3590s] threads: 64, tps: 0.00, reads: 0.00, writes: 37407.08, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3591s] threads: 64, tps: 0.00, reads: 0.00, writes: 40001.02, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3592s] threads: 64, tps: 0.00, reads: 0.00, writes: 40609.96, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3593s] threads: 64, tps: 0.00, reads: 0.00, writes: 38327.98, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3594s] threads: 64, tps: 0.00, reads: 0.00, writes: 38002.03, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3595s] threads: 64, tps: 0.00, reads: 0.00, writes: 36133.00, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[3596s] threads: 64, tps: 0.00, reads: 0.00, writes: 37767.15, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[3597s] threads: 64, tps: 0.00, reads: 0.00, writes: 40175.90, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[3598s] threads: 64, tps: 0.00, reads: 0.00, writes: 33912.00, response time: 3.15ms (95%), errors: 0.00, reconnects:  0.00
[3599s] threads: 64, tps: 0.00, reads: 0.00, writes: 33617.05, response time: 3.00ms (95%), errors: 0.00, reconnects:  0.00
[3600s] threads: 64, tps: 0.00, reads: 0.00, writes: 35007.53, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
OLTP test statistics:
    queries performed:
        read:                            0
        write:                           125365443
        other:                           0
        total:                           125365443
    transactions:                        0      (0.00 per sec.)
    read/write requests:                 125365443 (34823.67 per sec.)
    other operations:                    0      (0.00 per sec.)
    ignored errors:                      0      (0.00 per sec.)
    reconnects:                          0      (0.00 per sec.)

General statistics:
    total time:                          3600.0064s
    total number of events:              125365443
    total time taken by event execution: 230255.3176s
    response time:
         min:                                  0.12ms
         avg:                                  1.84ms
         max:                                269.41ms
         approx.  95 percentile:               2.67ms

Threads fairness:
    events (avg/stddev):           1958835.0469/638.11
    execution time (avg/stddev):   3597.7393/0.02

