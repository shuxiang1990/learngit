sysbench 0.5:  multi-threaded system evaluation benchmark

Running the test with following options:
Number of threads: 64
Report intermediate results every 1 second(s)
Initializing random number generator from timer.

Random number generator seed is 0 and will be ignored


Threads started!

[   1s] threads: 64, tps: 0.00, reads: 0.00, writes: 38306.17, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[   2s] threads: 64, tps: 0.00, reads: 0.00, writes: 41019.26, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[   3s] threads: 64, tps: 0.00, reads: 0.00, writes: 38939.07, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[   4s] threads: 64, tps: 0.00, reads: 0.00, writes: 40654.96, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[   5s] threads: 64, tps: 0.00, reads: 0.00, writes: 39976.99, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[   6s] threads: 64, tps: 0.00, reads: 0.00, writes: 46641.02, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[   7s] threads: 64, tps: 0.00, reads: 0.00, writes: 44754.02, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[   8s] threads: 64, tps: 0.00, reads: 0.00, writes: 39117.93, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[   9s] threads: 64, tps: 0.00, reads: 0.00, writes: 39154.01, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[  10s] threads: 64, tps: 0.00, reads: 0.00, writes: 39826.02, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[  11s] threads: 64, tps: 0.00, reads: 0.00, writes: 44229.01, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[  12s] threads: 64, tps: 0.00, reads: 0.00, writes: 45954.98, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[  13s] threads: 64, tps: 0.00, reads: 0.00, writes: 39921.99, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[  14s] threads: 64, tps: 0.00, reads: 0.00, writes: 35869.98, response time: 2.77ms (95%), errors: 0.00, reconnects:  0.00
[  15s] threads: 64, tps: 0.00, reads: 0.00, writes: 38041.08, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[  16s] threads: 64, tps: 0.00, reads: 0.00, writes: 42039.95, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[  17s] threads: 64, tps: 0.00, reads: 0.00, writes: 47283.44, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[  18s] threads: 64, tps: 0.00, reads: 0.00, writes: 40542.03, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[  19s] threads: 64, tps: 0.00, reads: 0.00, writes: 38699.03, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[  20s] threads: 64, tps: 0.00, reads: 0.00, writes: 38064.96, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[  21s] threads: 64, tps: 0.00, reads: 0.00, writes: 40430.04, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[  22s] threads: 64, tps: 0.00, reads: 0.00, writes: 47394.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[  23s] threads: 64, tps: 0.00, reads: 0.00, writes: 42942.06, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[  24s] threads: 64, tps: 0.00, reads: 0.00, writes: 39758.98, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[  25s] threads: 64, tps: 0.00, reads: 0.00, writes: 40590.98, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[  26s] threads: 64, tps: 0.00, reads: 0.00, writes: 37343.98, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[  27s] threads: 64, tps: 0.00, reads: 0.00, writes: 48542.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[  28s] threads: 64, tps: 0.00, reads: 0.00, writes: 40095.00, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[  29s] threads: 64, tps: 0.00, reads: 0.00, writes: 38597.06, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[  30s] threads: 64, tps: 0.00, reads: 0.00, writes: 38048.96, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[  31s] threads: 64, tps: 0.00, reads: 0.00, writes: 41134.99, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[  32s] threads: 64, tps: 0.00, reads: 0.00, writes: 48136.97, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[  33s] threads: 64, tps: 0.00, reads: 0.00, writes: 46791.06, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[  34s] threads: 64, tps: 0.00, reads: 0.00, writes: 44665.00, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[  35s] threads: 64, tps: 0.00, reads: 0.00, writes: 45328.80, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[  36s] threads: 64, tps: 0.00, reads: 0.00, writes: 45708.24, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[  37s] threads: 64, tps: 0.00, reads: 0.00, writes: 48559.00, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[  38s] threads: 64, tps: 0.00, reads: 0.00, writes: 47071.72, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[  39s] threads: 64, tps: 0.00, reads: 0.00, writes: 43758.17, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[  40s] threads: 64, tps: 0.00, reads: 0.00, writes: 44036.88, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[  41s] threads: 64, tps: 0.00, reads: 0.00, writes: 46821.97, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[  42s] threads: 64, tps: 0.00, reads: 0.00, writes: 48103.19, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[  43s] threads: 64, tps: 0.00, reads: 0.00, writes: 43457.62, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[  44s] threads: 64, tps: 0.00, reads: 0.00, writes: 40753.34, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[  45s] threads: 64, tps: 0.00, reads: 0.00, writes: 39113.92, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[  46s] threads: 64, tps: 0.00, reads: 0.00, writes: 46853.21, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[  47s] threads: 64, tps: 0.00, reads: 0.00, writes: 45399.67, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[  48s] threads: 64, tps: 0.00, reads: 0.00, writes: 45101.23, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[  49s] threads: 64, tps: 0.00, reads: 0.00, writes: 48279.05, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[  50s] threads: 64, tps: 0.00, reads: 0.00, writes: 48165.24, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[  51s] threads: 64, tps: 0.00, reads: 0.00, writes: 51105.90, response time: 1.63ms (95%), errors: 0.00, reconnects:  0.00
[  52s] threads: 64, tps: 0.00, reads: 0.00, writes: 47329.87, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[  53s] threads: 64, tps: 0.00, reads: 0.00, writes: 47030.17, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[  54s] threads: 64, tps: 0.00, reads: 0.00, writes: 44989.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[  55s] threads: 64, tps: 0.00, reads: 0.00, writes: 49224.08, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[  56s] threads: 64, tps: 0.00, reads: 0.00, writes: 47415.77, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[  57s] threads: 64, tps: 0.00, reads: 0.00, writes: 46707.17, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[  58s] threads: 64, tps: 0.00, reads: 0.00, writes: 44640.06, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[  59s] threads: 64, tps: 0.00, reads: 0.00, writes: 41112.95, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[  60s] threads: 64, tps: 0.00, reads: 0.00, writes: 44787.97, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[  61s] threads: 64, tps: 0.00, reads: 0.00, writes: 43286.84, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[  62s] threads: 64, tps: 0.00, reads: 0.00, writes: 45087.15, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[  63s] threads: 64, tps: 0.00, reads: 0.00, writes: 43209.04, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[  64s] threads: 64, tps: 0.00, reads: 0.00, writes: 46100.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[  65s] threads: 64, tps: 0.00, reads: 0.00, writes: 47699.06, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[  66s] threads: 64, tps: 0.00, reads: 0.00, writes: 44092.99, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[  67s] threads: 64, tps: 0.00, reads: 0.00, writes: 43893.99, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[  68s] threads: 64, tps: 0.00, reads: 0.00, writes: 41926.75, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[  69s] threads: 64, tps: 0.00, reads: 0.00, writes: 47785.20, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[  70s] threads: 64, tps: 0.00, reads: 0.00, writes: 46859.07, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[  71s] threads: 64, tps: 0.00, reads: 0.00, writes: 44215.93, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[  72s] threads: 64, tps: 0.00, reads: 0.00, writes: 43867.17, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[  73s] threads: 64, tps: 0.00, reads: 0.00, writes: 43605.84, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[  74s] threads: 64, tps: 0.00, reads: 0.00, writes: 47767.04, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[  75s] threads: 64, tps: 0.00, reads: 0.00, writes: 45465.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[  76s] threads: 64, tps: 0.00, reads: 0.00, writes: 32524.81, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[  77s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.01, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[  78s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.94, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[  79s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.06, response time: 21.30ms (95%), errors: 0.00, reconnects:  0.00
[  80s] threads: 64, tps: 0.00, reads: 0.00, writes: 22776.98, response time: 19.76ms (95%), errors: 0.00, reconnects:  0.00
[  81s] threads: 64, tps: 0.00, reads: 0.00, writes: 41254.03, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[  82s] threads: 64, tps: 0.00, reads: 0.00, writes: 48660.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[  83s] threads: 64, tps: 0.00, reads: 0.00, writes: 47188.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[  84s] threads: 64, tps: 0.00, reads: 0.00, writes: 47300.83, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[  85s] threads: 64, tps: 0.00, reads: 0.00, writes: 47958.16, response time: 1.70ms (95%), errors: 0.00, reconnects:  0.00
[  86s] threads: 64, tps: 0.00, reads: 0.00, writes: 49425.07, response time: 1.66ms (95%), errors: 0.00, reconnects:  0.00
[  87s] threads: 64, tps: 0.00, reads: 0.00, writes: 49206.96, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[  88s] threads: 64, tps: 0.00, reads: 0.00, writes: 48774.02, response time: 1.67ms (95%), errors: 0.00, reconnects:  0.00
[  89s] threads: 64, tps: 0.00, reads: 0.00, writes: 45705.96, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[  90s] threads: 64, tps: 0.00, reads: 0.00, writes: 44704.01, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[  91s] threads: 64, tps: 0.00, reads: 0.00, writes: 49457.04, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[  92s] threads: 64, tps: 0.00, reads: 0.00, writes: 47671.88, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[  93s] threads: 64, tps: 0.00, reads: 0.00, writes: 45210.83, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[  94s] threads: 64, tps: 0.00, reads: 0.00, writes: 44748.22, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[  95s] threads: 64, tps: 0.00, reads: 0.00, writes: 44373.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[  96s] threads: 64, tps: 0.00, reads: 0.00, writes: 45760.04, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[  97s] threads: 64, tps: 0.00, reads: 0.00, writes: 44086.01, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[  98s] threads: 64, tps: 0.00, reads: 0.00, writes: 44090.95, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[  99s] threads: 64, tps: 0.00, reads: 0.00, writes: 44394.05, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 100s] threads: 64, tps: 0.00, reads: 0.00, writes: 46228.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 101s] threads: 64, tps: 0.00, reads: 0.00, writes: 44392.82, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 102s] threads: 64, tps: 0.00, reads: 0.00, writes: 44106.20, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 103s] threads: 64, tps: 0.00, reads: 0.00, writes: 43090.97, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 104s] threads: 64, tps: 0.00, reads: 0.00, writes: 42521.80, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 105s] threads: 64, tps: 0.00, reads: 0.00, writes: 48697.27, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 106s] threads: 64, tps: 0.00, reads: 0.00, writes: 48496.99, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 107s] threads: 64, tps: 0.00, reads: 0.00, writes: 45055.99, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 108s] threads: 64, tps: 0.00, reads: 0.00, writes: 44882.03, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 109s] threads: 64, tps: 0.00, reads: 0.00, writes: 45572.96, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 110s] threads: 64, tps: 0.00, reads: 0.00, writes: 48144.06, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 111s] threads: 64, tps: 0.00, reads: 0.00, writes: 46949.03, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 112s] threads: 64, tps: 0.00, reads: 0.00, writes: 25036.51, response time: 19.59ms (95%), errors: 0.00, reconnects:  0.00
[ 113s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.04, response time: 20.98ms (95%), errors: 0.00, reconnects:  0.00
[ 114s] threads: 64, tps: 0.00, reads: 0.00, writes: 4914.02, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[ 115s] threads: 64, tps: 0.00, reads: 0.00, writes: 40820.98, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 116s] threads: 64, tps: 0.00, reads: 0.00, writes: 41417.00, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 117s] threads: 64, tps: 0.00, reads: 0.00, writes: 47820.98, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 118s] threads: 64, tps: 0.00, reads: 0.00, writes: 44653.99, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 119s] threads: 64, tps: 0.00, reads: 0.00, writes: 44545.96, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 120s] threads: 64, tps: 0.00, reads: 0.00, writes: 35847.88, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 121s] threads: 64, tps: 0.00, reads: 0.00, writes: 46725.25, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 122s] threads: 64, tps: 0.00, reads: 0.00, writes: 49251.01, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 123s] threads: 64, tps: 0.00, reads: 0.00, writes: 47138.01, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 124s] threads: 64, tps: 0.00, reads: 0.00, writes: 46749.94, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 125s] threads: 64, tps: 0.00, reads: 0.00, writes: 44143.98, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 126s] threads: 64, tps: 0.00, reads: 0.00, writes: 51587.08, response time: 1.65ms (95%), errors: 0.00, reconnects:  0.00
[ 127s] threads: 64, tps: 0.00, reads: 0.00, writes: 48058.97, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 128s] threads: 64, tps: 0.00, reads: 0.00, writes: 47382.99, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 129s] threads: 64, tps: 0.00, reads: 0.00, writes: 43974.97, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 130s] threads: 64, tps: 0.00, reads: 0.00, writes: 45442.97, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 131s] threads: 64, tps: 0.00, reads: 0.00, writes: 46675.10, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 132s] threads: 64, tps: 0.00, reads: 0.00, writes: 47140.27, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 133s] threads: 64, tps: 0.00, reads: 0.00, writes: 42792.98, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 134s] threads: 64, tps: 0.00, reads: 0.00, writes: 38845.03, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 135s] threads: 64, tps: 0.00, reads: 0.00, writes: 42405.99, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 136s] threads: 64, tps: 0.00, reads: 0.00, writes: 47995.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 137s] threads: 64, tps: 0.00, reads: 0.00, writes: 44772.00, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 138s] threads: 64, tps: 0.00, reads: 0.00, writes: 45920.97, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 139s] threads: 64, tps: 0.00, reads: 0.00, writes: 44782.05, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 140s] threads: 64, tps: 0.00, reads: 0.00, writes: 47810.00, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 141s] threads: 64, tps: 0.00, reads: 0.00, writes: 46777.91, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 142s] threads: 64, tps: 0.00, reads: 0.00, writes: 44870.82, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 143s] threads: 64, tps: 0.00, reads: 0.00, writes: 43192.92, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 144s] threads: 64, tps: 0.00, reads: 0.00, writes: 44798.00, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 145s] threads: 64, tps: 0.00, reads: 0.00, writes: 46372.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 146s] threads: 64, tps: 0.00, reads: 0.00, writes: 44902.98, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 147s] threads: 64, tps: 0.00, reads: 0.00, writes: 36600.99, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 148s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.98, response time: 21.17ms (95%), errors: 0.00, reconnects:  0.00
[ 149s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.02, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 150s] threads: 64, tps: 0.00, reads: 0.00, writes: 3180.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 151s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.00, response time: 21.26ms (95%), errors: 0.00, reconnects:  0.00
[ 152s] threads: 64, tps: 0.00, reads: 0.00, writes: 20465.97, response time: 20.22ms (95%), errors: 0.00, reconnects:  0.00
[ 153s] threads: 64, tps: 0.00, reads: 0.00, writes: 41117.74, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 154s] threads: 64, tps: 0.00, reads: 0.00, writes: 49995.64, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[ 155s] threads: 64, tps: 0.00, reads: 0.00, writes: 45015.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 156s] threads: 64, tps: 0.00, reads: 0.00, writes: 45724.70, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 157s] threads: 64, tps: 0.00, reads: 0.00, writes: 44492.24, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 158s] threads: 64, tps: 0.00, reads: 0.00, writes: 47801.94, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 159s] threads: 64, tps: 0.00, reads: 0.00, writes: 49073.06, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 160s] threads: 64, tps: 0.00, reads: 0.00, writes: 46628.07, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 161s] threads: 64, tps: 0.00, reads: 0.00, writes: 46099.00, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 162s] threads: 64, tps: 0.00, reads: 0.00, writes: 44734.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 163s] threads: 64, tps: 0.00, reads: 0.00, writes: 48191.00, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[ 164s] threads: 64, tps: 0.00, reads: 0.00, writes: 47086.03, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 165s] threads: 64, tps: 0.00, reads: 0.00, writes: 45748.96, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 166s] threads: 64, tps: 0.00, reads: 0.00, writes: 44358.03, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 167s] threads: 64, tps: 0.00, reads: 0.00, writes: 40337.95, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 168s] threads: 64, tps: 0.00, reads: 0.00, writes: 48101.02, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 169s] threads: 64, tps: 0.00, reads: 0.00, writes: 43595.02, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 170s] threads: 64, tps: 0.00, reads: 0.00, writes: 44456.01, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 171s] threads: 64, tps: 0.00, reads: 0.00, writes: 44876.94, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 172s] threads: 64, tps: 0.00, reads: 0.00, writes: 46294.08, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 173s] threads: 64, tps: 0.00, reads: 0.00, writes: 47911.97, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 174s] threads: 64, tps: 0.00, reads: 0.00, writes: 46500.02, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 175s] threads: 64, tps: 0.00, reads: 0.00, writes: 40726.97, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 176s] threads: 64, tps: 0.00, reads: 0.00, writes: 42182.99, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 177s] threads: 64, tps: 0.00, reads: 0.00, writes: 47354.29, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 178s] threads: 64, tps: 0.00, reads: 0.00, writes: 46285.55, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 179s] threads: 64, tps: 0.00, reads: 0.00, writes: 44623.02, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 180s] threads: 64, tps: 0.00, reads: 0.00, writes: 32358.85, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 181s] threads: 64, tps: 0.00, reads: 0.00, writes: 43552.24, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 182s] threads: 64, tps: 0.00, reads: 0.00, writes: 45923.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 183s] threads: 64, tps: 0.00, reads: 0.00, writes: 46763.04, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 184s] threads: 64, tps: 0.00, reads: 0.00, writes: 44315.97, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 185s] threads: 64, tps: 0.00, reads: 0.00, writes: 3696.00, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[ 186s] threads: 64, tps: 0.00, reads: 0.00, writes: 45525.01, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 187s] threads: 64, tps: 0.00, reads: 0.00, writes: 46312.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 188s] threads: 64, tps: 0.00, reads: 0.00, writes: 48909.95, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 189s] threads: 64, tps: 0.00, reads: 0.00, writes: 48210.07, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 190s] threads: 64, tps: 0.00, reads: 0.00, writes: 46480.01, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 191s] threads: 64, tps: 0.00, reads: 0.00, writes: 46467.02, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 192s] threads: 64, tps: 0.00, reads: 0.00, writes: 49616.92, response time: 1.70ms (95%), errors: 0.00, reconnects:  0.00
[ 193s] threads: 64, tps: 0.00, reads: 0.00, writes: 48818.01, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 194s] threads: 64, tps: 0.00, reads: 0.00, writes: 44046.07, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 195s] threads: 64, tps: 0.00, reads: 0.00, writes: 39393.94, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 196s] threads: 64, tps: 0.00, reads: 0.00, writes: 37920.98, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 197s] threads: 64, tps: 0.00, reads: 0.00, writes: 48001.08, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 198s] threads: 64, tps: 0.00, reads: 0.00, writes: 47731.93, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 199s] threads: 64, tps: 0.00, reads: 0.00, writes: 43601.00, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 200s] threads: 64, tps: 0.00, reads: 0.00, writes: 45257.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 201s] threads: 64, tps: 0.00, reads: 0.00, writes: 45042.04, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 202s] threads: 64, tps: 0.00, reads: 0.00, writes: 47229.95, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 203s] threads: 64, tps: 0.00, reads: 0.00, writes: 46178.05, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 204s] threads: 64, tps: 0.00, reads: 0.00, writes: 45026.00, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 205s] threads: 64, tps: 0.00, reads: 0.00, writes: 44146.96, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 206s] threads: 64, tps: 0.00, reads: 0.00, writes: 47290.11, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 207s] threads: 64, tps: 0.00, reads: 0.00, writes: 46699.09, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 208s] threads: 64, tps: 0.00, reads: 0.00, writes: 45033.85, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 209s] threads: 64, tps: 0.00, reads: 0.00, writes: 43748.03, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 210s] threads: 64, tps: 0.00, reads: 0.00, writes: 43571.87, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 211s] threads: 64, tps: 0.00, reads: 0.00, writes: 49227.91, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 212s] threads: 64, tps: 0.00, reads: 0.00, writes: 39908.96, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[ 213s] threads: 64, tps: 0.00, reads: 0.00, writes: 25539.24, response time: 19.55ms (95%), errors: 0.00, reconnects:  0.00
[ 214s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.02, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[ 215s] threads: 64, tps: 0.00, reads: 0.00, writes: 3177.03, response time: 21.05ms (95%), errors: 0.00, reconnects:  0.00
[ 216s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.05, response time: 20.94ms (95%), errors: 0.00, reconnects:  0.00
[ 217s] threads: 64, tps: 0.00, reads: 0.00, writes: 32850.86, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 218s] threads: 64, tps: 0.00, reads: 0.00, writes: 42695.06, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 219s] threads: 64, tps: 0.00, reads: 0.00, writes: 45999.10, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 220s] threads: 64, tps: 0.00, reads: 0.00, writes: 48079.92, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 221s] threads: 64, tps: 0.00, reads: 0.00, writes: 46585.10, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 222s] threads: 64, tps: 0.00, reads: 0.00, writes: 47298.75, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[ 223s] threads: 64, tps: 0.00, reads: 0.00, writes: 47079.16, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 224s] threads: 64, tps: 0.00, reads: 0.00, writes: 48608.86, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 225s] threads: 64, tps: 0.00, reads: 0.00, writes: 48157.20, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 226s] threads: 64, tps: 0.00, reads: 0.00, writes: 46761.97, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 227s] threads: 64, tps: 0.00, reads: 0.00, writes: 42192.82, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 228s] threads: 64, tps: 0.00, reads: 0.00, writes: 45467.68, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 229s] threads: 64, tps: 0.00, reads: 0.00, writes: 43825.27, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 230s] threads: 64, tps: 0.00, reads: 0.00, writes: 38929.12, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[ 231s] threads: 64, tps: 0.00, reads: 0.00, writes: 37872.07, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[ 232s] threads: 64, tps: 0.00, reads: 0.00, writes: 39221.92, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 233s] threads: 64, tps: 0.00, reads: 0.00, writes: 45159.85, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 234s] threads: 64, tps: 0.00, reads: 0.00, writes: 47223.15, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 235s] threads: 64, tps: 0.00, reads: 0.00, writes: 45736.03, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 236s] threads: 64, tps: 0.00, reads: 0.00, writes: 42572.71, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 237s] threads: 64, tps: 0.00, reads: 0.00, writes: 42185.25, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 238s] threads: 64, tps: 0.00, reads: 0.00, writes: 45926.81, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 239s] threads: 64, tps: 0.00, reads: 0.00, writes: 46254.19, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 240s] threads: 64, tps: 0.00, reads: 0.00, writes: 43964.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 241s] threads: 64, tps: 0.00, reads: 0.00, writes: 31656.00, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 242s] threads: 64, tps: 0.00, reads: 0.00, writes: 42573.83, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 243s] threads: 64, tps: 0.00, reads: 0.00, writes: 46711.09, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 244s] threads: 64, tps: 0.00, reads: 0.00, writes: 45877.12, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 245s] threads: 64, tps: 0.00, reads: 0.00, writes: 43542.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 246s] threads: 64, tps: 0.00, reads: 0.00, writes: 6858.00, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[ 247s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.98, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[ 248s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.02, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[ 249s] threads: 64, tps: 0.00, reads: 0.00, writes: 5596.00, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[ 250s] threads: 64, tps: 0.00, reads: 0.00, writes: 40021.98, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 251s] threads: 64, tps: 0.00, reads: 0.00, writes: 44394.01, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 252s] threads: 64, tps: 0.00, reads: 0.00, writes: 48021.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 253s] threads: 64, tps: 0.00, reads: 0.00, writes: 46143.68, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 254s] threads: 64, tps: 0.00, reads: 0.00, writes: 46129.13, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 255s] threads: 64, tps: 0.00, reads: 0.00, writes: 46053.17, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 256s] threads: 64, tps: 0.00, reads: 0.00, writes: 50277.75, response time: 1.70ms (95%), errors: 0.00, reconnects:  0.00
[ 257s] threads: 64, tps: 0.00, reads: 0.00, writes: 48198.21, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 258s] threads: 64, tps: 0.00, reads: 0.00, writes: 46799.76, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 259s] threads: 64, tps: 0.00, reads: 0.00, writes: 45261.21, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 260s] threads: 64, tps: 0.00, reads: 0.00, writes: 43920.01, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 261s] threads: 64, tps: 0.00, reads: 0.00, writes: 50278.04, response time: 1.64ms (95%), errors: 0.00, reconnects:  0.00
[ 262s] threads: 64, tps: 0.00, reads: 0.00, writes: 47342.96, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 263s] threads: 64, tps: 0.00, reads: 0.00, writes: 46735.04, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 264s] threads: 64, tps: 0.00, reads: 0.00, writes: 45675.97, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 265s] threads: 64, tps: 0.00, reads: 0.00, writes: 49028.96, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 266s] threads: 64, tps: 0.00, reads: 0.00, writes: 47224.80, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 267s] threads: 64, tps: 0.00, reads: 0.00, writes: 47007.23, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 268s] threads: 64, tps: 0.00, reads: 0.00, writes: 44381.96, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 269s] threads: 64, tps: 0.00, reads: 0.00, writes: 41487.04, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 270s] threads: 64, tps: 0.00, reads: 0.00, writes: 47633.91, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 271s] threads: 64, tps: 0.00, reads: 0.00, writes: 41501.00, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 272s] threads: 64, tps: 0.00, reads: 0.00, writes: 37828.05, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[ 273s] threads: 64, tps: 0.00, reads: 0.00, writes: 40237.05, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 274s] threads: 64, tps: 0.00, reads: 0.00, writes: 41545.88, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 275s] threads: 64, tps: 0.00, reads: 0.00, writes: 49751.03, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 276s] threads: 64, tps: 0.00, reads: 0.00, writes: 46413.96, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 277s] threads: 64, tps: 0.00, reads: 0.00, writes: 44583.78, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 278s] threads: 64, tps: 0.00, reads: 0.00, writes: 44206.08, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 279s] threads: 64, tps: 0.00, reads: 0.00, writes: 46014.18, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 280s] threads: 64, tps: 0.00, reads: 0.00, writes: 47287.98, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 281s] threads: 64, tps: 0.00, reads: 0.00, writes: 43754.80, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 282s] threads: 64, tps: 0.00, reads: 0.00, writes: 3179.97, response time: 21.35ms (95%), errors: 0.00, reconnects:  0.00
[ 283s] threads: 64, tps: 0.00, reads: 0.00, writes: 3145.02, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[ 284s] threads: 64, tps: 0.00, reads: 0.00, writes: 3178.94, response time: 21.20ms (95%), errors: 0.00, reconnects:  0.00
[ 285s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.08, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[ 286s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 287s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.98, response time: 21.20ms (95%), errors: 0.00, reconnects:  0.00
[ 288s] threads: 64, tps: 0.00, reads: 0.00, writes: 3171.02, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[ 289s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.00, response time: 21.08ms (95%), errors: 0.00, reconnects:  0.00
[ 290s] threads: 64, tps: 0.00, reads: 0.00, writes: 6073.99, response time: 20.87ms (95%), errors: 0.00, reconnects:  0.00
[ 291s] threads: 64, tps: 0.00, reads: 0.00, writes: 39406.05, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 292s] threads: 64, tps: 0.00, reads: 0.00, writes: 42718.05, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 293s] threads: 64, tps: 0.00, reads: 0.00, writes: 47453.30, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 294s] threads: 64, tps: 0.00, reads: 0.00, writes: 40561.41, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 295s] threads: 64, tps: 0.00, reads: 0.00, writes: 40180.02, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 296s] threads: 64, tps: 0.00, reads: 0.00, writes: 41478.98, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 297s] threads: 64, tps: 0.00, reads: 0.00, writes: 43344.06, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 298s] threads: 64, tps: 0.00, reads: 0.00, writes: 48369.88, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 299s] threads: 64, tps: 0.00, reads: 0.00, writes: 43191.04, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 300s] threads: 64, tps: 0.00, reads: 0.00, writes: 43752.88, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 301s] threads: 64, tps: 0.00, reads: 0.00, writes: 43460.07, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 302s] threads: 64, tps: 0.00, reads: 0.00, writes: 47930.53, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 303s] threads: 64, tps: 0.00, reads: 0.00, writes: 48143.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 304s] threads: 64, tps: 0.00, reads: 0.00, writes: 45637.98, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 304s] threads: 64, tps: 0.00, reads: 0.00, writes: 45291.93, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 306s] threads: 64, tps: 0.00, reads: 0.00, writes: 45094.08, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 307s] threads: 64, tps: 0.00, reads: 0.00, writes: 49438.06, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[ 308s] threads: 64, tps: 0.00, reads: 0.00, writes: 45937.01, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 309s] threads: 64, tps: 0.00, reads: 0.00, writes: 41134.97, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 310s] threads: 64, tps: 0.00, reads: 0.00, writes: 44549.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 311s] threads: 64, tps: 0.00, reads: 0.00, writes: 46776.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 312s] threads: 64, tps: 0.00, reads: 0.00, writes: 47268.95, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 313s] threads: 64, tps: 0.00, reads: 0.00, writes: 47229.07, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 314s] threads: 64, tps: 0.00, reads: 0.00, writes: 44023.90, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 315s] threads: 64, tps: 0.00, reads: 0.00, writes: 39165.91, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 316s] threads: 64, tps: 0.00, reads: 0.00, writes: 43043.18, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 317s] threads: 64, tps: 0.00, reads: 0.00, writes: 47619.99, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 318s] threads: 64, tps: 0.00, reads: 0.00, writes: 41807.02, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 319s] threads: 64, tps: 0.00, reads: 0.00, writes: 43085.97, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 320s] threads: 64, tps: 0.00, reads: 0.00, writes: 43951.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 321s] threads: 64, tps: 0.00, reads: 0.00, writes: 46696.01, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 322s] threads: 64, tps: 0.00, reads: 0.00, writes: 47968.40, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 323s] threads: 64, tps: 0.00, reads: 0.00, writes: 44946.47, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 324s] threads: 64, tps: 0.00, reads: 0.00, writes: 43909.29, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 325s] threads: 64, tps: 0.00, reads: 0.00, writes: 37674.64, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[ 326s] threads: 64, tps: 0.00, reads: 0.00, writes: 46526.93, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 327s] threads: 64, tps: 0.00, reads: 0.00, writes: 25052.77, response time: 19.65ms (95%), errors: 0.00, reconnects:  0.00
[ 328s] threads: 64, tps: 0.00, reads: 0.00, writes: 3146.97, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[ 329s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.06, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 330s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.00, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[ 331s] threads: 64, tps: 0.00, reads: 0.00, writes: 3140.99, response time: 20.96ms (95%), errors: 0.00, reconnects:  0.00
[ 332s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.96, response time: 20.98ms (95%), errors: 0.00, reconnects:  0.00
[ 333s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.05, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[ 334s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.99, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[ 335s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 336s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.98, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[ 337s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.02, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 338s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.99, response time: 21.22ms (95%), errors: 0.00, reconnects:  0.00
[ 339s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.00, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[ 340s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.02, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[ 341s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.94, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[ 342s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.01, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[ 343s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.04, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[ 344s] threads: 64, tps: 0.00, reads: 0.00, writes: 3168.99, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[ 345s] threads: 64, tps: 0.00, reads: 0.00, writes: 3168.02, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[ 346s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.99, response time: 20.93ms (95%), errors: 0.00, reconnects:  0.00
[ 347s] threads: 64, tps: 0.00, reads: 0.00, writes: 7696.04, response time: 20.87ms (95%), errors: 0.00, reconnects:  0.00
[ 348s] threads: 64, tps: 0.00, reads: 0.00, writes: 42048.76, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 349s] threads: 64, tps: 0.00, reads: 0.00, writes: 45307.22, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 350s] threads: 64, tps: 0.00, reads: 0.00, writes: 48426.94, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 351s] threads: 64, tps: 0.00, reads: 0.00, writes: 44361.04, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 352s] threads: 64, tps: 0.00, reads: 0.00, writes: 46185.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 353s] threads: 64, tps: 0.00, reads: 0.00, writes: 46473.01, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 354s] threads: 64, tps: 0.00, reads: 0.00, writes: 49029.88, response time: 1.70ms (95%), errors: 0.00, reconnects:  0.00
[ 355s] threads: 64, tps: 0.00, reads: 0.00, writes: 48407.14, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 356s] threads: 64, tps: 0.00, reads: 0.00, writes: 46934.90, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 357s] threads: 64, tps: 0.00, reads: 0.00, writes: 46418.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 358s] threads: 64, tps: 0.00, reads: 0.00, writes: 47670.97, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 359s] threads: 64, tps: 0.00, reads: 0.00, writes: 48795.12, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 360s] threads: 64, tps: 0.00, reads: 0.00, writes: 47679.90, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 361s] threads: 64, tps: 0.00, reads: 0.00, writes: 47180.05, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 362s] threads: 64, tps: 0.00, reads: 0.00, writes: 46665.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 363s] threads: 64, tps: 0.00, reads: 0.00, writes: 49387.41, response time: 1.67ms (95%), errors: 0.00, reconnects:  0.00
[ 364s] threads: 64, tps: 0.00, reads: 0.00, writes: 48836.63, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 365s] threads: 64, tps: 0.00, reads: 0.00, writes: 48556.01, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[ 366s] threads: 64, tps: 0.00, reads: 0.00, writes: 47532.99, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 367s] threads: 64, tps: 0.00, reads: 0.00, writes: 50515.96, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[ 368s] threads: 64, tps: 0.00, reads: 0.00, writes: 49422.07, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[ 369s] threads: 64, tps: 0.00, reads: 0.00, writes: 48322.98, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[ 370s] threads: 64, tps: 0.00, reads: 0.00, writes: 47328.06, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 371s] threads: 64, tps: 0.00, reads: 0.00, writes: 48107.93, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[ 372s] threads: 64, tps: 0.00, reads: 0.00, writes: 49488.01, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 373s] threads: 64, tps: 0.00, reads: 0.00, writes: 47257.81, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 374s] threads: 64, tps: 0.00, reads: 0.00, writes: 47071.16, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 375s] threads: 64, tps: 0.00, reads: 0.00, writes: 46578.09, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 376s] threads: 64, tps: 0.00, reads: 0.00, writes: 49466.92, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 377s] threads: 64, tps: 0.00, reads: 0.00, writes: 45838.36, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 378s] threads: 64, tps: 0.00, reads: 0.00, writes: 47109.58, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 379s] threads: 64, tps: 0.00, reads: 0.00, writes: 45243.09, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 380s] threads: 64, tps: 0.00, reads: 0.00, writes: 44761.00, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 381s] threads: 64, tps: 0.00, reads: 0.00, writes: 49143.04, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 382s] threads: 64, tps: 0.00, reads: 0.00, writes: 45604.93, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 383s] threads: 64, tps: 0.00, reads: 0.00, writes: 40800.03, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 384s] threads: 64, tps: 0.00, reads: 0.00, writes: 42854.98, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 385s] threads: 64, tps: 0.00, reads: 0.00, writes: 42784.05, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 386s] threads: 64, tps: 0.00, reads: 0.00, writes: 48203.95, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 387s] threads: 64, tps: 0.00, reads: 0.00, writes: 43533.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 388s] threads: 64, tps: 0.00, reads: 0.00, writes: 43093.92, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 389s] threads: 64, tps: 0.00, reads: 0.00, writes: 37453.02, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 390s] threads: 64, tps: 0.00, reads: 0.00, writes: 39610.01, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[ 391s] threads: 64, tps: 0.00, reads: 0.00, writes: 45092.97, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 392s] threads: 64, tps: 0.00, reads: 0.00, writes: 13534.72, response time: 20.42ms (95%), errors: 0.00, reconnects:  0.00
[ 393s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.02, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[ 394s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.05, response time: 21.51ms (95%), errors: 0.00, reconnects:  0.00
[ 395s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.00, response time: 21.23ms (95%), errors: 0.00, reconnects:  0.00
[ 396s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.99, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 397s] threads: 64, tps: 0.00, reads: 0.00, writes: 3139.01, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[ 398s] threads: 64, tps: 0.00, reads: 0.00, writes: 3184.00, response time: 20.79ms (95%), errors: 0.00, reconnects:  0.00
[ 399s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.00, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[ 400s] threads: 64, tps: 0.00, reads: 0.00, writes: 3145.00, response time: 21.25ms (95%), errors: 0.00, reconnects:  0.00
[ 401s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.01, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[ 402s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.98, response time: 20.85ms (95%), errors: 0.00, reconnects:  0.00
[ 403s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.01, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[ 404s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.99, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[ 405s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.97, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[ 406s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.99, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[ 407s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.02, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[ 408s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.00, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[ 409s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.01, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[ 410s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.99, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[ 411s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.02, response time: 21.17ms (95%), errors: 0.00, reconnects:  0.00
[ 412s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.98, response time: 21.00ms (95%), errors: 0.00, reconnects:  0.00
[ 413s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 414s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.01, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[ 415s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 416s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.01, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[ 417s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.99, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 418s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.02, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[ 419s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.00, response time: 21.20ms (95%), errors: 0.00, reconnects:  0.00
[ 420s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.00, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[ 421s] threads: 64, tps: 0.00, reads: 0.00, writes: 12143.01, response time: 20.54ms (95%), errors: 0.00, reconnects:  0.00
[ 422s] threads: 64, tps: 0.00, reads: 0.00, writes: 42882.95, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 423s] threads: 64, tps: 0.00, reads: 0.00, writes: 49017.12, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 424s] threads: 64, tps: 0.00, reads: 0.00, writes: 43388.92, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 425s] threads: 64, tps: 0.00, reads: 0.00, writes: 44837.06, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 426s] threads: 64, tps: 0.00, reads: 0.00, writes: 45595.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 427s] threads: 64, tps: 0.00, reads: 0.00, writes: 47591.01, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 428s] threads: 64, tps: 0.00, reads: 0.00, writes: 50138.96, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[ 429s] threads: 64, tps: 0.00, reads: 0.00, writes: 48156.94, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 430s] threads: 64, tps: 0.00, reads: 0.00, writes: 47209.89, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 431s] threads: 64, tps: 0.00, reads: 0.00, writes: 46464.50, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 432s] threads: 64, tps: 0.00, reads: 0.00, writes: 50199.70, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[ 433s] threads: 64, tps: 0.00, reads: 0.00, writes: 48834.04, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[ 434s] threads: 64, tps: 0.00, reads: 0.00, writes: 48069.00, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[ 435s] threads: 64, tps: 0.00, reads: 0.00, writes: 47657.02, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[ 436s] threads: 64, tps: 0.00, reads: 0.00, writes: 50582.97, response time: 1.67ms (95%), errors: 0.00, reconnects:  0.00
[ 437s] threads: 64, tps: 0.00, reads: 0.00, writes: 49499.01, response time: 1.67ms (95%), errors: 0.00, reconnects:  0.00
[ 438s] threads: 64, tps: 0.00, reads: 0.00, writes: 47601.03, response time: 1.67ms (95%), errors: 0.00, reconnects:  0.00
[ 439s] threads: 64, tps: 0.00, reads: 0.00, writes: 47586.99, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[ 440s] threads: 64, tps: 0.00, reads: 0.00, writes: 49695.92, response time: 1.67ms (95%), errors: 0.00, reconnects:  0.00
[ 441s] threads: 64, tps: 0.00, reads: 0.00, writes: 49928.04, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[ 442s] threads: 64, tps: 0.00, reads: 0.00, writes: 47873.99, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[ 443s] threads: 64, tps: 0.00, reads: 0.00, writes: 44821.06, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 444s] threads: 64, tps: 0.00, reads: 0.00, writes: 45358.97, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 445s] threads: 64, tps: 0.00, reads: 0.00, writes: 49163.02, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[ 446s] threads: 64, tps: 0.00, reads: 0.00, writes: 48669.97, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 447s] threads: 64, tps: 0.00, reads: 0.00, writes: 47229.95, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 448s] threads: 64, tps: 0.00, reads: 0.00, writes: 45056.08, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 449s] threads: 64, tps: 0.00, reads: 0.00, writes: 46709.96, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 450s] threads: 64, tps: 0.00, reads: 0.00, writes: 48248.92, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 451s] threads: 64, tps: 0.00, reads: 0.00, writes: 45846.06, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 452s] threads: 64, tps: 0.00, reads: 0.00, writes: 41049.07, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 453s] threads: 64, tps: 0.00, reads: 0.00, writes: 35681.93, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[ 454s] threads: 64, tps: 0.00, reads: 0.00, writes: 44705.02, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 455s] threads: 64, tps: 0.00, reads: 0.00, writes: 49095.01, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 456s] threads: 64, tps: 0.00, reads: 0.00, writes: 46128.02, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 457s] threads: 64, tps: 0.00, reads: 0.00, writes: 44923.96, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 458s] threads: 64, tps: 0.00, reads: 0.00, writes: 45154.06, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 459s] threads: 64, tps: 0.00, reads: 0.00, writes: 49648.99, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 460s] threads: 64, tps: 0.00, reads: 0.00, writes: 47499.92, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 461s] threads: 64, tps: 0.00, reads: 0.00, writes: 43917.05, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 462s] threads: 64, tps: 0.00, reads: 0.00, writes: 42915.04, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 463s] threads: 64, tps: 0.00, reads: 0.00, writes: 46018.98, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 464s] threads: 64, tps: 0.00, reads: 0.00, writes: 47423.91, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 465s] threads: 64, tps: 0.00, reads: 0.00, writes: 35879.91, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 466s] threads: 64, tps: 0.00, reads: 0.00, writes: 13212.68, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[ 467s] threads: 64, tps: 0.00, reads: 0.00, writes: 3187.09, response time: 20.94ms (95%), errors: 0.00, reconnects:  0.00
[ 468s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.94, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[ 469s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.99, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[ 470s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.01, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 471s] threads: 64, tps: 0.00, reads: 0.00, writes: 33280.23, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 472s] threads: 64, tps: 0.00, reads: 0.00, writes: 43910.63, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 473s] threads: 64, tps: 0.00, reads: 0.00, writes: 49150.76, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 474s] threads: 64, tps: 0.00, reads: 0.00, writes: 46178.06, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 475s] threads: 64, tps: 0.00, reads: 0.00, writes: 43324.16, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 476s] threads: 64, tps: 0.00, reads: 0.00, writes: 43646.03, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 477s] threads: 64, tps: 0.00, reads: 0.00, writes: 43282.82, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 478s] threads: 64, tps: 0.00, reads: 0.00, writes: 47037.17, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 479s] threads: 64, tps: 0.00, reads: 0.00, writes: 45841.04, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 480s] threads: 64, tps: 0.00, reads: 0.00, writes: 40158.88, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[ 481s] threads: 64, tps: 0.00, reads: 0.00, writes: 40442.96, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 482s] threads: 64, tps: 0.00, reads: 0.00, writes: 43366.93, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 483s] threads: 64, tps: 0.00, reads: 0.00, writes: 47733.06, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 484s] threads: 64, tps: 0.00, reads: 0.00, writes: 45313.20, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 485s] threads: 64, tps: 0.00, reads: 0.00, writes: 44425.01, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 486s] threads: 64, tps: 0.00, reads: 0.00, writes: 45326.94, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 487s] threads: 64, tps: 0.00, reads: 0.00, writes: 45084.07, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 488s] threads: 64, tps: 0.00, reads: 0.00, writes: 46282.92, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 489s] threads: 64, tps: 0.00, reads: 0.00, writes: 45321.88, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 490s] threads: 64, tps: 0.00, reads: 0.00, writes: 43010.93, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[ 491s] threads: 64, tps: 0.00, reads: 0.00, writes: 43922.15, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 492s] threads: 64, tps: 0.00, reads: 0.00, writes: 47721.07, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 493s] threads: 64, tps: 0.00, reads: 0.00, writes: 46984.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 494s] threads: 64, tps: 0.00, reads: 0.00, writes: 45284.97, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 495s] threads: 64, tps: 0.00, reads: 0.00, writes: 44351.03, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 496s] threads: 64, tps: 0.00, reads: 0.00, writes: 44252.04, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 497s] threads: 64, tps: 0.00, reads: 0.00, writes: 48154.61, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 498s] threads: 64, tps: 0.00, reads: 0.00, writes: 42338.84, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 499s] threads: 64, tps: 0.00, reads: 0.00, writes: 43035.99, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 500s] threads: 64, tps: 0.00, reads: 0.00, writes: 37656.83, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[ 501s] threads: 64, tps: 0.00, reads: 0.00, writes: 39304.97, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[ 502s] threads: 64, tps: 0.00, reads: 0.00, writes: 49334.24, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 503s] threads: 64, tps: 0.00, reads: 0.00, writes: 45081.03, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 504s] threads: 64, tps: 0.00, reads: 0.00, writes: 43787.97, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 505s] threads: 64, tps: 0.00, reads: 0.00, writes: 45424.96, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 506s] threads: 64, tps: 0.00, reads: 0.00, writes: 47453.03, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 507s] threads: 64, tps: 0.00, reads: 0.00, writes: 47284.03, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 508s] threads: 64, tps: 0.00, reads: 0.00, writes: 46135.99, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 509s] threads: 64, tps: 0.00, reads: 0.00, writes: 45781.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 510s] threads: 64, tps: 0.00, reads: 0.00, writes: 43610.81, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 511s] threads: 64, tps: 0.00, reads: 0.00, writes: 49241.95, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 512s] threads: 64, tps: 0.00, reads: 0.00, writes: 47957.06, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 513s] threads: 64, tps: 0.00, reads: 0.00, writes: 45167.17, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 514s] threads: 64, tps: 0.00, reads: 0.00, writes: 43552.72, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 515s] threads: 64, tps: 0.00, reads: 0.00, writes: 47370.25, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 516s] threads: 64, tps: 0.00, reads: 0.00, writes: 45572.62, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 517s] threads: 64, tps: 0.00, reads: 0.00, writes: 41657.98, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[ 518s] threads: 64, tps: 0.00, reads: 0.00, writes: 44489.93, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 519s] threads: 64, tps: 0.00, reads: 0.00, writes: 43402.20, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 520s] threads: 64, tps: 0.00, reads: 0.00, writes: 45912.98, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 521s] threads: 64, tps: 0.00, reads: 0.00, writes: 47037.84, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 522s] threads: 64, tps: 0.00, reads: 0.00, writes: 45532.14, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 523s] threads: 64, tps: 0.00, reads: 0.00, writes: 43952.04, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 524s] threads: 64, tps: 0.00, reads: 0.00, writes: 43459.96, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 525s] threads: 64, tps: 0.00, reads: 0.00, writes: 49167.03, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 526s] threads: 64, tps: 0.00, reads: 0.00, writes: 34163.92, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 527s] threads: 64, tps: 0.00, reads: 0.00, writes: 36476.04, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 528s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.99, response time: 21.29ms (95%), errors: 0.00, reconnects:  0.00
[ 529s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.01, response time: 21.08ms (95%), errors: 0.00, reconnects:  0.00
[ 530s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.93, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[ 531s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.05, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 532s] threads: 64, tps: 0.00, reads: 0.00, writes: 3168.01, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[ 533s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.99, response time: 20.98ms (95%), errors: 0.00, reconnects:  0.00
[ 534s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.01, response time: 20.94ms (95%), errors: 0.00, reconnects:  0.00
[ 535s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.99, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[ 536s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.00, response time: 21.28ms (95%), errors: 0.00, reconnects:  0.00
[ 537s] threads: 64, tps: 0.00, reads: 0.00, writes: 3139.98, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[ 538s] threads: 64, tps: 0.00, reads: 0.00, writes: 3176.03, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[ 539s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.93, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[ 540s] threads: 64, tps: 0.00, reads: 0.00, writes: 3138.95, response time: 21.28ms (95%), errors: 0.00, reconnects:  0.00
[ 541s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.05, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[ 542s] threads: 64, tps: 0.00, reads: 0.00, writes: 20572.47, response time: 20.29ms (95%), errors: 0.00, reconnects:  0.00
[ 543s] threads: 64, tps: 0.00, reads: 0.00, writes: 44493.98, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 544s] threads: 64, tps: 0.00, reads: 0.00, writes: 49601.08, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 545s] threads: 64, tps: 0.00, reads: 0.00, writes: 47053.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 546s] threads: 64, tps: 0.00, reads: 0.00, writes: 44943.01, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 547s] threads: 64, tps: 0.00, reads: 0.00, writes: 45095.97, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 548s] threads: 64, tps: 0.00, reads: 0.00, writes: 49500.97, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 549s] threads: 64, tps: 0.00, reads: 0.00, writes: 48684.01, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 550s] threads: 64, tps: 0.00, reads: 0.00, writes: 45544.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 551s] threads: 64, tps: 0.00, reads: 0.00, writes: 44766.97, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 552s] threads: 64, tps: 0.00, reads: 0.00, writes: 45769.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 553s] threads: 64, tps: 0.00, reads: 0.00, writes: 48493.99, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 554s] threads: 64, tps: 0.00, reads: 0.00, writes: 46803.00, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 555s] threads: 64, tps: 0.00, reads: 0.00, writes: 46291.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 556s] threads: 64, tps: 0.00, reads: 0.00, writes: 45464.05, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 557s] threads: 64, tps: 0.00, reads: 0.00, writes: 49316.97, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 558s] threads: 64, tps: 0.00, reads: 0.00, writes: 44434.00, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 559s] threads: 64, tps: 0.00, reads: 0.00, writes: 45709.03, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 560s] threads: 64, tps: 0.00, reads: 0.00, writes: 45231.97, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 561s] threads: 64, tps: 0.00, reads: 0.00, writes: 44943.01, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 562s] threads: 64, tps: 0.00, reads: 0.00, writes: 49149.97, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 563s] threads: 64, tps: 0.00, reads: 0.00, writes: 45150.08, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 564s] threads: 64, tps: 0.00, reads: 0.00, writes: 42394.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 565s] threads: 64, tps: 0.00, reads: 0.00, writes: 37875.91, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 566s] threads: 64, tps: 0.00, reads: 0.00, writes: 38405.09, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 567s] threads: 64, tps: 0.00, reads: 0.00, writes: 47275.93, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 568s] threads: 64, tps: 0.00, reads: 0.00, writes: 41059.77, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 569s] threads: 64, tps: 0.00, reads: 0.00, writes: 37115.89, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 570s] threads: 64, tps: 0.00, reads: 0.00, writes: 38040.42, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[ 571s] threads: 64, tps: 0.00, reads: 0.00, writes: 38890.96, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 572s] threads: 64, tps: 0.00, reads: 0.00, writes: 44259.00, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 573s] threads: 64, tps: 0.00, reads: 0.00, writes: 43372.00, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[ 574s] threads: 64, tps: 0.00, reads: 0.00, writes: 37742.93, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[ 575s] threads: 64, tps: 0.00, reads: 0.00, writes: 41368.05, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 576s] threads: 64, tps: 0.00, reads: 0.00, writes: 42720.87, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 577s] threads: 64, tps: 0.00, reads: 0.00, writes: 46911.18, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 578s] threads: 64, tps: 0.00, reads: 0.00, writes: 46723.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 579s] threads: 64, tps: 0.00, reads: 0.00, writes: 40630.87, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 580s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.08, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[ 581s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.94, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 582s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.06, response time: 21.28ms (95%), errors: 0.00, reconnects:  0.00
[ 583s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 584s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.01, response time: 21.35ms (95%), errors: 0.00, reconnects:  0.00
[ 585s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.00, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[ 586s] threads: 64, tps: 0.00, reads: 0.00, writes: 3140.99, response time: 21.39ms (95%), errors: 0.00, reconnects:  0.00
[ 587s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.94, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[ 588s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.07, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[ 589s] threads: 64, tps: 0.00, reads: 0.00, writes: 3168.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 590s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.99, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[ 591s] threads: 64, tps: 0.00, reads: 0.00, writes: 3141.92, response time: 20.98ms (95%), errors: 0.00, reconnects:  0.00
[ 592s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.09, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 593s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.95, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 594s] threads: 64, tps: 0.00, reads: 0.00, writes: 3174.04, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 595s] threads: 64, tps: 0.00, reads: 0.00, writes: 3139.95, response time: 21.17ms (95%), errors: 0.00, reconnects:  0.00
[ 596s] threads: 64, tps: 0.00, reads: 0.00, writes: 3183.06, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 597s] threads: 64, tps: 0.00, reads: 0.00, writes: 3137.01, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[ 598s] threads: 64, tps: 0.00, reads: 0.00, writes: 3176.99, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 599s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.01, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 600s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.00, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 601s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.94, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[ 602s] threads: 64, tps: 0.00, reads: 0.00, writes: 3168.06, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[ 603s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.92, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[ 604s] threads: 64, tps: 0.00, reads: 0.00, writes: 3168.09, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[ 605s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.95, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[ 606s] threads: 64, tps: 0.00, reads: 0.00, writes: 18320.32, response time: 20.39ms (95%), errors: 0.00, reconnects:  0.00
[ 607s] threads: 64, tps: 0.00, reads: 0.00, writes: 48321.04, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 608s] threads: 64, tps: 0.00, reads: 0.00, writes: 46001.35, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 609s] threads: 64, tps: 0.00, reads: 0.00, writes: 43563.56, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 610s] threads: 64, tps: 0.00, reads: 0.00, writes: 40308.77, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 611s] threads: 64, tps: 0.00, reads: 0.00, writes: 42643.27, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 612s] threads: 64, tps: 0.00, reads: 0.00, writes: 45955.01, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 613s] threads: 64, tps: 0.00, reads: 0.00, writes: 40143.40, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 614s] threads: 64, tps: 0.00, reads: 0.00, writes: 36568.34, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[ 615s] threads: 64, tps: 0.00, reads: 0.00, writes: 39173.04, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 616s] threads: 64, tps: 0.00, reads: 0.00, writes: 39868.99, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 617s] threads: 64, tps: 0.00, reads: 0.00, writes: 48667.02, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 618s] threads: 64, tps: 0.00, reads: 0.00, writes: 45843.03, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 619s] threads: 64, tps: 0.00, reads: 0.00, writes: 44648.98, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 620s] threads: 64, tps: 0.00, reads: 0.00, writes: 42801.86, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 621s] threads: 64, tps: 0.00, reads: 0.00, writes: 47806.12, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 622s] threads: 64, tps: 0.00, reads: 0.00, writes: 44296.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 623s] threads: 64, tps: 0.00, reads: 0.00, writes: 45030.09, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 624s] threads: 64, tps: 0.00, reads: 0.00, writes: 37742.90, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[ 625s] threads: 64, tps: 0.00, reads: 0.00, writes: 38971.98, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 626s] threads: 64, tps: 0.00, reads: 0.00, writes: 46808.06, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 627s] threads: 64, tps: 0.00, reads: 0.00, writes: 46837.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 628s] threads: 64, tps: 0.00, reads: 0.00, writes: 38688.96, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 629s] threads: 64, tps: 0.00, reads: 0.00, writes: 38186.02, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 630s] threads: 64, tps: 0.00, reads: 0.00, writes: 38083.18, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[ 631s] threads: 64, tps: 0.00, reads: 0.00, writes: 43252.92, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 632s] threads: 64, tps: 0.00, reads: 0.00, writes: 45905.03, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 633s] threads: 64, tps: 0.00, reads: 0.00, writes: 37916.95, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 634s] threads: 64, tps: 0.00, reads: 0.00, writes: 37630.97, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[ 635s] threads: 64, tps: 0.00, reads: 0.00, writes: 36503.06, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[ 636s] threads: 64, tps: 0.00, reads: 0.00, writes: 37862.04, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 637s] threads: 64, tps: 0.00, reads: 0.00, writes: 48409.98, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 638s] threads: 64, tps: 0.00, reads: 0.00, writes: 37854.95, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[ 639s] threads: 64, tps: 0.00, reads: 0.00, writes: 38896.05, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[ 640s] threads: 64, tps: 0.00, reads: 0.00, writes: 36765.02, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[ 641s] threads: 64, tps: 0.00, reads: 0.00, writes: 37582.00, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[ 642s] threads: 64, tps: 0.00, reads: 0.00, writes: 46306.24, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 643s] threads: 64, tps: 0.00, reads: 0.00, writes: 42343.95, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 644s] threads: 64, tps: 0.00, reads: 0.00, writes: 37399.99, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[ 645s] threads: 64, tps: 0.00, reads: 0.00, writes: 38050.06, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 646s] threads: 64, tps: 0.00, reads: 0.00, writes: 37054.41, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 647s] threads: 64, tps: 0.00, reads: 0.00, writes: 44362.55, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 648s] threads: 64, tps: 0.00, reads: 0.00, writes: 42060.17, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[ 649s] threads: 64, tps: 0.00, reads: 0.00, writes: 38528.96, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[ 650s] threads: 64, tps: 0.00, reads: 0.00, writes: 37829.00, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 651s] threads: 64, tps: 0.00, reads: 0.00, writes: 38895.00, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 652s] threads: 64, tps: 0.00, reads: 0.00, writes: 41894.96, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 653s] threads: 64, tps: 0.00, reads: 0.00, writes: 47677.05, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 654s] threads: 64, tps: 0.00, reads: 0.00, writes: 13290.98, response time: 20.52ms (95%), errors: 0.00, reconnects:  0.00
[ 655s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.00, response time: 20.80ms (95%), errors: 0.00, reconnects:  0.00
[ 656s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.97, response time: 21.26ms (95%), errors: 0.00, reconnects:  0.00
[ 657s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.02, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[ 658s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.02, response time: 21.25ms (95%), errors: 0.00, reconnects:  0.00
[ 659s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.97, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[ 660s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.93, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[ 661s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.08, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[ 662s] threads: 64, tps: 0.00, reads: 0.00, writes: 3174.00, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 663s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.93, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[ 664s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.08, response time: 20.85ms (95%), errors: 0.00, reconnects:  0.00
[ 665s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.01, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[ 666s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.00, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[ 667s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.00, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[ 668s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.00, response time: 20.98ms (95%), errors: 0.00, reconnects:  0.00
[ 669s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.00, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[ 670s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.00, response time: 20.89ms (95%), errors: 0.00, reconnects:  0.00
[ 671s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.97, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[ 672s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.98, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[ 673s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.05, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[ 674s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.98, response time: 21.27ms (95%), errors: 0.00, reconnects:  0.00
[ 675s] threads: 64, tps: 0.00, reads: 0.00, writes: 9576.05, response time: 20.84ms (95%), errors: 0.00, reconnects:  0.00
[ 676s] threads: 64, tps: 0.00, reads: 0.00, writes: 44711.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 677s] threads: 64, tps: 0.00, reads: 0.00, writes: 47565.12, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 678s] threads: 64, tps: 0.00, reads: 0.00, writes: 46882.94, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 679s] threads: 64, tps: 0.00, reads: 0.00, writes: 45928.92, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 680s] threads: 64, tps: 0.00, reads: 0.00, writes: 43574.03, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 681s] threads: 64, tps: 0.00, reads: 0.00, writes: 44459.07, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 682s] threads: 64, tps: 0.00, reads: 0.00, writes: 48442.99, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 683s] threads: 64, tps: 0.00, reads: 0.00, writes: 43808.01, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[ 684s] threads: 64, tps: 0.00, reads: 0.00, writes: 38690.93, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 685s] threads: 64, tps: 0.00, reads: 0.00, writes: 43214.03, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 686s] threads: 64, tps: 0.00, reads: 0.00, writes: 43062.71, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 687s] threads: 64, tps: 0.00, reads: 0.00, writes: 46980.11, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 688s] threads: 64, tps: 0.00, reads: 0.00, writes: 40804.17, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 689s] threads: 64, tps: 0.00, reads: 0.00, writes: 40256.98, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[ 690s] threads: 64, tps: 0.00, reads: 0.00, writes: 41161.00, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 691s] threads: 64, tps: 0.00, reads: 0.00, writes: 43490.32, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 692s] threads: 64, tps: 0.00, reads: 0.00, writes: 48212.81, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 693s] threads: 64, tps: 0.00, reads: 0.00, writes: 43791.00, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 694s] threads: 64, tps: 0.00, reads: 0.00, writes: 44404.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 695s] threads: 64, tps: 0.00, reads: 0.00, writes: 43998.01, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 696s] threads: 64, tps: 0.00, reads: 0.00, writes: 44966.99, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 697s] threads: 64, tps: 0.00, reads: 0.00, writes: 48276.95, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 698s] threads: 64, tps: 0.00, reads: 0.00, writes: 38320.05, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[ 699s] threads: 64, tps: 0.00, reads: 0.00, writes: 44925.92, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 700s] threads: 64, tps: 0.00, reads: 0.00, writes: 41559.08, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 701s] threads: 64, tps: 0.00, reads: 0.00, writes: 45520.03, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 702s] threads: 64, tps: 0.00, reads: 0.00, writes: 40366.89, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[ 703s] threads: 64, tps: 0.00, reads: 0.00, writes: 36560.02, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 704s] threads: 64, tps: 0.00, reads: 0.00, writes: 41875.07, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 705s] threads: 64, tps: 0.00, reads: 0.00, writes: 44637.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 706s] threads: 64, tps: 0.00, reads: 0.00, writes: 46655.94, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 707s] threads: 64, tps: 0.00, reads: 0.00, writes: 48137.02, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 708s] threads: 64, tps: 0.00, reads: 0.00, writes: 46184.02, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 709s] threads: 64, tps: 0.00, reads: 0.00, writes: 43893.01, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 710s] threads: 64, tps: 0.00, reads: 0.00, writes: 42107.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 711s] threads: 64, tps: 0.00, reads: 0.00, writes: 46308.94, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 712s] threads: 64, tps: 0.00, reads: 0.00, writes: 46460.10, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 713s] threads: 64, tps: 0.00, reads: 0.00, writes: 44414.96, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 714s] threads: 64, tps: 0.00, reads: 0.00, writes: 45593.00, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 715s] threads: 64, tps: 0.00, reads: 0.00, writes: 44362.01, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 716s] threads: 64, tps: 0.00, reads: 0.00, writes: 46164.01, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 717s] threads: 64, tps: 0.00, reads: 0.00, writes: 41222.03, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 718s] threads: 64, tps: 0.00, reads: 0.00, writes: 44751.96, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 719s] threads: 64, tps: 0.00, reads: 0.00, writes: 45768.00, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 720s] threads: 64, tps: 0.00, reads: 0.00, writes: 45576.03, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 721s] threads: 64, tps: 0.00, reads: 0.00, writes: 47159.98, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 722s] threads: 64, tps: 0.00, reads: 0.00, writes: 44368.77, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 723s] threads: 64, tps: 0.00, reads: 0.00, writes: 44703.03, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 724s] threads: 64, tps: 0.00, reads: 0.00, writes: 42736.15, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 725s] threads: 64, tps: 0.00, reads: 0.00, writes: 47272.07, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 726s] threads: 64, tps: 0.00, reads: 0.00, writes: 46701.90, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 727s] threads: 64, tps: 0.00, reads: 0.00, writes: 44899.05, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 728s] threads: 64, tps: 0.00, reads: 0.00, writes: 44931.95, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 729s] threads: 64, tps: 0.00, reads: 0.00, writes: 44914.07, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 730s] threads: 64, tps: 0.00, reads: 0.00, writes: 48917.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 731s] threads: 64, tps: 0.00, reads: 0.00, writes: 47795.00, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 732s] threads: 64, tps: 0.00, reads: 0.00, writes: 46255.98, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 733s] threads: 64, tps: 0.00, reads: 0.00, writes: 45522.07, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 734s] threads: 64, tps: 0.00, reads: 0.00, writes: 42343.95, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 735s] threads: 64, tps: 0.00, reads: 0.00, writes: 48414.00, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 736s] threads: 64, tps: 0.00, reads: 0.00, writes: 46010.94, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 737s] threads: 64, tps: 0.00, reads: 0.00, writes: 42407.99, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[ 738s] threads: 64, tps: 0.00, reads: 0.00, writes: 37047.99, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[ 739s] threads: 64, tps: 0.00, reads: 0.00, writes: 44498.10, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 740s] threads: 64, tps: 0.00, reads: 0.00, writes: 47384.97, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 741s] threads: 64, tps: 0.00, reads: 0.00, writes: 44626.06, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 742s] threads: 64, tps: 0.00, reads: 0.00, writes: 43848.96, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 743s] threads: 64, tps: 0.00, reads: 0.00, writes: 44761.99, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 744s] threads: 64, tps: 0.00, reads: 0.00, writes: 48562.98, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 745s] threads: 64, tps: 0.00, reads: 0.00, writes: 46329.02, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 746s] threads: 64, tps: 0.00, reads: 0.00, writes: 41416.00, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[ 747s] threads: 64, tps: 0.00, reads: 0.00, writes: 41415.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 748s] threads: 64, tps: 0.00, reads: 0.00, writes: 27469.87, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 749s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 750s] threads: 64, tps: 0.00, reads: 0.00, writes: 0.00, response time: 0.00ms (95%), errors: 0.00, reconnects:  0.00
[ 751s] threads: 64, tps: 0.00, reads: 0.00, writes: 16525.45, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[ 752s] threads: 64, tps: 0.00, reads: 0.00, writes: 48901.90, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[ 753s] threads: 64, tps: 0.00, reads: 0.00, writes: 47705.01, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 754s] threads: 64, tps: 0.00, reads: 0.00, writes: 44294.68, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[ 755s] threads: 64, tps: 0.00, reads: 0.00, writes: 42042.35, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 756s] threads: 64, tps: 0.00, reads: 0.00, writes: 47072.01, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 757s] threads: 64, tps: 0.00, reads: 0.00, writes: 47111.95, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 758s] threads: 64, tps: 0.00, reads: 0.00, writes: 46179.08, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 759s] threads: 64, tps: 0.00, reads: 0.00, writes: 44468.94, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 760s] threads: 64, tps: 0.00, reads: 0.00, writes: 44367.99, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 761s] threads: 64, tps: 0.00, reads: 0.00, writes: 40211.03, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 762s] threads: 64, tps: 0.00, reads: 0.00, writes: 47433.99, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 763s] threads: 64, tps: 0.00, reads: 0.00, writes: 43653.04, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 764s] threads: 64, tps: 0.00, reads: 0.00, writes: 44092.75, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 765s] threads: 64, tps: 0.00, reads: 0.00, writes: 42164.06, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 766s] threads: 64, tps: 0.00, reads: 0.00, writes: 47299.16, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 767s] threads: 64, tps: 0.00, reads: 0.00, writes: 41792.80, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 768s] threads: 64, tps: 0.00, reads: 0.00, writes: 39075.35, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 769s] threads: 64, tps: 0.00, reads: 0.00, writes: 39377.81, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 770s] threads: 64, tps: 0.00, reads: 0.00, writes: 44826.10, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 771s] threads: 64, tps: 0.00, reads: 0.00, writes: 49006.76, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 772s] threads: 64, tps: 0.00, reads: 0.00, writes: 47189.20, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 773s] threads: 64, tps: 0.00, reads: 0.00, writes: 41984.02, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[ 774s] threads: 64, tps: 0.00, reads: 0.00, writes: 39568.00, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[ 775s] threads: 64, tps: 0.00, reads: 0.00, writes: 43096.00, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 776s] threads: 64, tps: 0.00, reads: 0.00, writes: 48948.95, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 777s] threads: 64, tps: 0.00, reads: 0.00, writes: 44311.03, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 778s] threads: 64, tps: 0.00, reads: 0.00, writes: 38622.81, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[ 779s] threads: 64, tps: 0.00, reads: 0.00, writes: 41112.18, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 780s] threads: 64, tps: 0.00, reads: 0.00, writes: 38651.03, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[ 781s] threads: 64, tps: 0.00, reads: 0.00, writes: 47217.83, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 782s] threads: 64, tps: 0.00, reads: 0.00, writes: 39842.10, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[ 783s] threads: 64, tps: 0.00, reads: 0.00, writes: 40799.81, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[ 784s] threads: 64, tps: 0.00, reads: 0.00, writes: 42197.17, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 785s] threads: 64, tps: 0.00, reads: 0.00, writes: 45785.85, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 786s] threads: 64, tps: 0.00, reads: 0.00, writes: 48984.22, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 787s] threads: 64, tps: 0.00, reads: 0.00, writes: 46525.79, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 788s] threads: 64, tps: 0.00, reads: 0.00, writes: 41508.17, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 789s] threads: 64, tps: 0.00, reads: 0.00, writes: 43700.98, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 790s] threads: 64, tps: 0.00, reads: 0.00, writes: 47916.73, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 791s] threads: 64, tps: 0.00, reads: 0.00, writes: 48327.30, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 792s] threads: 64, tps: 0.00, reads: 0.00, writes: 41339.78, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[ 793s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.00, response time: 21.22ms (95%), errors: 0.00, reconnects:  0.00
[ 794s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.00, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[ 795s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.89, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[ 796s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.11, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 797s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.99, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[ 798s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.02, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[ 799s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.93, response time: 21.00ms (95%), errors: 0.00, reconnects:  0.00
[ 800s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.06, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[ 801s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.00, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[ 802s] threads: 64, tps: 0.00, reads: 0.00, writes: 3145.90, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[ 803s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.00, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[ 804s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.04, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[ 805s] threads: 64, tps: 0.00, reads: 0.00, writes: 19393.37, response time: 20.29ms (95%), errors: 0.00, reconnects:  0.00
[ 806s] threads: 64, tps: 0.00, reads: 0.00, writes: 45192.98, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 807s] threads: 64, tps: 0.00, reads: 0.00, writes: 48464.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 808s] threads: 64, tps: 0.00, reads: 0.00, writes: 49197.95, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[ 809s] threads: 64, tps: 0.00, reads: 0.00, writes: 46247.06, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 810s] threads: 64, tps: 0.00, reads: 0.00, writes: 44476.97, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 811s] threads: 64, tps: 0.00, reads: 0.00, writes: 49576.93, response time: 1.70ms (95%), errors: 0.00, reconnects:  0.00
[ 812s] threads: 64, tps: 0.00, reads: 0.00, writes: 46560.07, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 813s] threads: 64, tps: 0.00, reads: 0.00, writes: 46899.06, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 814s] threads: 64, tps: 0.00, reads: 0.00, writes: 40599.94, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 815s] threads: 64, tps: 0.00, reads: 0.00, writes: 36660.11, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[ 816s] threads: 64, tps: 0.00, reads: 0.00, writes: 45642.12, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[ 817s] threads: 64, tps: 0.00, reads: 0.00, writes: 40879.41, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[ 818s] threads: 64, tps: 0.00, reads: 0.00, writes: 40207.44, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 819s] threads: 64, tps: 0.00, reads: 0.00, writes: 39835.11, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 820s] threads: 64, tps: 0.00, reads: 0.00, writes: 45478.96, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 821s] threads: 64, tps: 0.00, reads: 0.00, writes: 47449.03, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 822s] threads: 64, tps: 0.00, reads: 0.00, writes: 45981.07, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 823s] threads: 64, tps: 0.00, reads: 0.00, writes: 44193.82, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 824s] threads: 64, tps: 0.00, reads: 0.00, writes: 43077.96, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 825s] threads: 64, tps: 0.00, reads: 0.00, writes: 37320.08, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[ 826s] threads: 64, tps: 0.00, reads: 0.00, writes: 45402.36, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[ 827s] threads: 64, tps: 0.00, reads: 0.00, writes: 40859.37, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[ 828s] threads: 64, tps: 0.00, reads: 0.00, writes: 37560.51, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[ 829s] threads: 64, tps: 0.00, reads: 0.00, writes: 39719.83, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 830s] threads: 64, tps: 0.00, reads: 0.00, writes: 37524.06, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 831s] threads: 64, tps: 0.00, reads: 0.00, writes: 41318.21, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 832s] threads: 64, tps: 0.00, reads: 0.00, writes: 44478.98, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[ 833s] threads: 64, tps: 0.00, reads: 0.00, writes: 41603.93, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 834s] threads: 64, tps: 0.00, reads: 0.00, writes: 44542.06, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 835s] threads: 64, tps: 0.00, reads: 0.00, writes: 42425.97, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 836s] threads: 64, tps: 0.00, reads: 0.00, writes: 45863.01, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 837s] threads: 64, tps: 0.00, reads: 0.00, writes: 47219.13, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 838s] threads: 64, tps: 0.00, reads: 0.00, writes: 44294.81, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 839s] threads: 64, tps: 0.00, reads: 0.00, writes: 44000.96, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 840s] threads: 64, tps: 0.00, reads: 0.00, writes: 44907.05, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[ 841s] threads: 64, tps: 0.00, reads: 0.00, writes: 47000.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 842s] threads: 64, tps: 0.00, reads: 0.00, writes: 47054.85, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 843s] threads: 64, tps: 0.00, reads: 0.00, writes: 22074.52, response time: 20.08ms (95%), errors: 0.00, reconnects:  0.00
[ 844s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.04, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[ 845s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.99, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[ 846s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.99, response time: 21.08ms (95%), errors: 0.00, reconnects:  0.00
[ 847s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.02, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[ 848s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.04, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[ 849s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.97, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[ 850s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.94, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[ 851s] threads: 64, tps: 0.00, reads: 0.00, writes: 3174.08, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[ 852s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[ 853s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.01, response time: 21.15ms (95%), errors: 0.00, reconnects:  0.00
[ 854s] threads: 64, tps: 0.00, reads: 0.00, writes: 9259.99, response time: 20.65ms (95%), errors: 0.00, reconnects:  0.00
[ 855s] threads: 64, tps: 0.00, reads: 0.00, writes: 44457.14, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 856s] threads: 64, tps: 0.00, reads: 0.00, writes: 48883.79, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[ 857s] threads: 64, tps: 0.00, reads: 0.00, writes: 46524.18, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 858s] threads: 64, tps: 0.00, reads: 0.00, writes: 46544.82, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[ 859s] threads: 64, tps: 0.00, reads: 0.00, writes: 44013.20, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 860s] threads: 64, tps: 0.00, reads: 0.00, writes: 46914.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[ 861s] threads: 64, tps: 0.00, reads: 0.00, writes: 48937.83, response time: 1.69ms (95%), errors: 0.00, reconnects:  0.00
[ 862s] threads: 64, tps: 0.00, reads: 0.00, writes: 46712.10, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 863s] threads: 64, tps: 0.00, reads: 0.00, writes: 42353.04, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[ 864s] threads: 64, tps: 0.00, reads: 0.00, writes: 42205.00, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[ 865s] threads: 64, tps: 0.00, reads: 0.00, writes: 43499.05, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[ 866s] threads: 64, tps: 0.00, reads: 0.00, writes: 46960.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 867s] threads: 64, tps: 0.00, reads: 0.00, writes: 41596.05, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 868s] threads: 64, tps: 0.00, reads: 0.00, writes: 38899.71, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[ 869s] threads: 64, tps: 0.00, reads: 0.00, writes: 39010.22, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 870s] threads: 64, tps: 0.00, reads: 0.00, writes: 40364.04, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 871s] threads: 64, tps: 0.00, reads: 0.00, writes: 45632.97, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[ 872s] threads: 64, tps: 0.00, reads: 0.00, writes: 44318.73, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 873s] threads: 64, tps: 0.00, reads: 0.00, writes: 44237.05, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 874s] threads: 64, tps: 0.00, reads: 0.00, writes: 42167.20, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[ 875s] threads: 64, tps: 0.00, reads: 0.00, writes: 45696.01, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 876s] threads: 64, tps: 0.00, reads: 0.00, writes: 48161.99, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 877s] threads: 64, tps: 0.00, reads: 0.00, writes: 45160.98, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 878s] threads: 64, tps: 0.00, reads: 0.00, writes: 43710.84, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 879s] threads: 64, tps: 0.00, reads: 0.00, writes: 44727.45, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[ 880s] threads: 64, tps: 0.00, reads: 0.00, writes: 48941.85, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 881s] threads: 64, tps: 0.00, reads: 0.00, writes: 46073.02, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 882s] threads: 64, tps: 0.00, reads: 0.00, writes: 43004.03, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 883s] threads: 64, tps: 0.00, reads: 0.00, writes: 45175.96, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[ 884s] threads: 64, tps: 0.00, reads: 0.00, writes: 47419.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[ 885s] threads: 64, tps: 0.00, reads: 0.00, writes: 48071.77, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[ 886s] threads: 64, tps: 0.00, reads: 0.00, writes: 46408.18, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 887s] threads: 64, tps: 0.00, reads: 0.00, writes: 43758.98, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 888s] threads: 64, tps: 0.00, reads: 0.00, writes: 44601.02, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[ 889s] threads: 64, tps: 0.00, reads: 0.00, writes: 49288.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 890s] threads: 64, tps: 0.00, reads: 0.00, writes: 47676.03, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 891s] threads: 64, tps: 0.00, reads: 0.00, writes: 38417.92, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[ 892s] threads: 64, tps: 0.00, reads: 0.00, writes: 6893.97, response time: 20.90ms (95%), errors: 0.00, reconnects:  0.00
[ 893s] threads: 64, tps: 0.00, reads: 0.00, writes: 44049.07, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 894s] threads: 64, tps: 0.00, reads: 0.00, writes: 46320.18, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 895s] threads: 64, tps: 0.00, reads: 0.00, writes: 48267.95, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 896s] threads: 64, tps: 0.00, reads: 0.00, writes: 47862.99, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[ 897s] threads: 64, tps: 0.00, reads: 0.00, writes: 44593.01, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[ 898s] threads: 64, tps: 0.00, reads: 0.00, writes: 41019.82, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[ 899s] threads: 64, tps: 0.00, reads: 0.00, writes: 48387.00, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[ 900s] threads: 64, tps: 0.00, reads: 0.00, writes: 47590.96, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 901s] threads: 64, tps: 0.00, reads: 0.00, writes: 46041.34, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 902s] threads: 64, tps: 0.00, reads: 0.00, writes: 40632.90, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 903s] threads: 64, tps: 0.00, reads: 0.00, writes: 38608.02, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[ 904s] threads: 64, tps: 0.00, reads: 0.00, writes: 45504.96, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[ 905s] threads: 64, tps: 0.00, reads: 0.00, writes: 41924.02, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[ 906s] threads: 64, tps: 0.00, reads: 0.00, writes: 38515.04, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[ 907s] threads: 64, tps: 0.00, reads: 0.00, writes: 40412.01, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 908s] threads: 64, tps: 0.00, reads: 0.00, writes: 43685.50, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 909s] threads: 64, tps: 0.00, reads: 0.00, writes: 48210.15, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 910s] threads: 64, tps: 0.00, reads: 0.00, writes: 46914.98, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 911s] threads: 64, tps: 0.00, reads: 0.00, writes: 44071.03, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[ 912s] threads: 64, tps: 0.00, reads: 0.00, writes: 44201.00, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 913s] threads: 64, tps: 0.00, reads: 0.00, writes: 42721.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 914s] threads: 64, tps: 0.00, reads: 0.00, writes: 48834.93, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 915s] threads: 64, tps: 0.00, reads: 0.00, writes: 46881.05, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 916s] threads: 64, tps: 0.00, reads: 0.00, writes: 22432.31, response time: 19.97ms (95%), errors: 0.00, reconnects:  0.00
[ 917s] threads: 64, tps: 0.00, reads: 0.00, writes: 3144.99, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[ 918s] threads: 64, tps: 0.00, reads: 0.00, writes: 3178.05, response time: 21.22ms (95%), errors: 0.00, reconnects:  0.00
[ 919s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.06, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[ 920s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.98, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[ 921s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.00, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[ 922s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.93, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[ 923s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.08, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[ 924s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.00, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 925s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.00, response time: 21.08ms (95%), errors: 0.00, reconnects:  0.00
[ 926s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.97, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[ 927s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.03, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[ 928s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.00, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[ 929s] threads: 64, tps: 0.00, reads: 0.00, writes: 16085.01, response time: 20.45ms (95%), errors: 0.00, reconnects:  0.00
[ 930s] threads: 64, tps: 0.00, reads: 0.00, writes: 46579.65, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 931s] threads: 64, tps: 0.00, reads: 0.00, writes: 48896.37, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[ 932s] threads: 64, tps: 0.00, reads: 0.00, writes: 46349.99, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[ 933s] threads: 64, tps: 0.00, reads: 0.00, writes: 44681.03, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 934s] threads: 64, tps: 0.00, reads: 0.00, writes: 42982.00, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 935s] threads: 64, tps: 0.00, reads: 0.00, writes: 43998.00, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 936s] threads: 64, tps: 0.00, reads: 0.00, writes: 48336.00, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 937s] threads: 64, tps: 0.00, reads: 0.00, writes: 46194.68, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[ 938s] threads: 64, tps: 0.00, reads: 0.00, writes: 46031.33, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 939s] threads: 64, tps: 0.00, reads: 0.00, writes: 42809.97, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[ 940s] threads: 64, tps: 0.00, reads: 0.00, writes: 46836.03, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 941s] threads: 64, tps: 0.00, reads: 0.00, writes: 46582.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[ 942s] threads: 64, tps: 0.00, reads: 0.00, writes: 43506.19, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 943s] threads: 64, tps: 0.00, reads: 0.00, writes: 42584.79, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[ 944s] threads: 64, tps: 0.00, reads: 0.00, writes: 43874.96, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 945s] threads: 64, tps: 0.00, reads: 0.00, writes: 46674.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[ 946s] threads: 64, tps: 0.00, reads: 0.00, writes: 40332.97, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[ 947s] threads: 64, tps: 0.00, reads: 0.00, writes: 37310.05, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[ 948s] threads: 64, tps: 0.00, reads: 0.00, writes: 38469.93, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[ 949s] threads: 64, tps: 0.00, reads: 0.00, writes: 37206.07, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[ 950s] threads: 64, tps: 0.00, reads: 0.00, writes: 44707.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[ 951s] threads: 64, tps: 0.00, reads: 0.00, writes: 41956.92, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[ 952s] threads: 64, tps: 0.00, reads: 0.00, writes: 37902.06, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 953s] threads: 64, tps: 0.00, reads: 0.00, writes: 36772.00, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[ 954s] threads: 64, tps: 0.00, reads: 0.00, writes: 37260.97, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[ 955s] threads: 64, tps: 0.00, reads: 0.00, writes: 42153.06, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[ 956s] threads: 64, tps: 0.00, reads: 0.00, writes: 44678.00, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[ 957s] threads: 64, tps: 0.00, reads: 0.00, writes: 37579.00, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 958s] threads: 64, tps: 0.00, reads: 0.00, writes: 44183.79, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[ 959s] threads: 64, tps: 0.00, reads: 0.00, writes: 43114.17, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[ 960s] threads: 64, tps: 0.00, reads: 0.00, writes: 45018.05, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 961s] threads: 64, tps: 0.00, reads: 0.00, writes: 47739.92, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[ 962s] threads: 64, tps: 0.00, reads: 0.00, writes: 45723.08, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[ 963s] threads: 64, tps: 0.00, reads: 0.00, writes: 44091.96, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[ 964s] threads: 64, tps: 0.00, reads: 0.00, writes: 44102.01, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 965s] threads: 64, tps: 0.00, reads: 0.00, writes: 48200.02, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[ 966s] threads: 64, tps: 0.00, reads: 0.00, writes: 46697.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[ 967s] threads: 64, tps: 0.00, reads: 0.00, writes: 42216.72, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[ 968s] threads: 64, tps: 0.00, reads: 0.00, writes: 3146.07, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[ 969s] threads: 64, tps: 0.00, reads: 0.00, writes: 3177.90, response time: 21.05ms (95%), errors: 0.00, reconnects:  0.00
[ 970s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.07, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[ 971s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.02, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[ 972s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.97, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[ 973s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.99, response time: 20.86ms (95%), errors: 0.00, reconnects:  0.00
[ 974s] threads: 64, tps: 0.00, reads: 0.00, writes: 3135.97, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[ 975s] threads: 64, tps: 0.00, reads: 0.00, writes: 3184.05, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[ 976s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.95, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 977s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.97, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[ 978s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.11, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[ 979s] threads: 64, tps: 0.00, reads: 0.00, writes: 3135.93, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[ 980s] threads: 64, tps: 0.00, reads: 0.00, writes: 3186.96, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[ 981s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.04, response time: 20.94ms (95%), errors: 0.00, reconnects:  0.00
[ 982s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.09, response time: 21.79ms (95%), errors: 0.00, reconnects:  0.00
[ 983s] threads: 64, tps: 0.00, reads: 0.00, writes: 12588.98, response time: 20.56ms (95%), errors: 0.00, reconnects:  0.00
[ 984s] threads: 64, tps: 0.00, reads: 0.00, writes: 47473.27, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[ 985s] threads: 64, tps: 0.00, reads: 0.00, writes: 47074.75, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[ 986s] threads: 64, tps: 0.00, reads: 0.00, writes: 44335.19, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[ 987s] threads: 64, tps: 0.00, reads: 0.00, writes: 40371.82, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[ 988s] threads: 64, tps: 0.00, reads: 0.00, writes: 36708.17, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[ 989s] threads: 64, tps: 0.00, reads: 0.00, writes: 43651.03, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[ 990s] threads: 64, tps: 0.00, reads: 0.00, writes: 44861.04, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[ 991s] threads: 64, tps: 0.00, reads: 0.00, writes: 38575.94, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[ 992s] threads: 64, tps: 0.00, reads: 0.00, writes: 39400.99, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[ 993s] threads: 64, tps: 0.00, reads: 0.00, writes: 38810.86, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[ 994s] threads: 64, tps: 0.00, reads: 0.00, writes: 42670.13, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[ 995s] threads: 64, tps: 0.00, reads: 0.00, writes: 47526.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[ 996s] threads: 64, tps: 0.00, reads: 0.00, writes: 38312.02, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[ 997s] threads: 64, tps: 0.00, reads: 0.00, writes: 38471.98, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[ 998s] threads: 64, tps: 0.00, reads: 0.00, writes: 37178.04, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[ 999s] threads: 64, tps: 0.00, reads: 0.00, writes: 39573.99, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1000s] threads: 64, tps: 0.00, reads: 0.00, writes: 47483.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1001s] threads: 64, tps: 0.00, reads: 0.00, writes: 38405.95, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1002s] threads: 64, tps: 0.00, reads: 0.00, writes: 41650.02, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[1003s] threads: 64, tps: 0.00, reads: 0.00, writes: 42759.03, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1004s] threads: 64, tps: 0.00, reads: 0.00, writes: 43220.98, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1005s] threads: 64, tps: 0.00, reads: 0.00, writes: 47247.01, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1006s] threads: 64, tps: 0.00, reads: 0.00, writes: 46268.99, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1007s] threads: 64, tps: 0.00, reads: 0.00, writes: 42075.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1008s] threads: 64, tps: 0.00, reads: 0.00, writes: 43452.20, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1009s] threads: 64, tps: 0.00, reads: 0.00, writes: 41300.77, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1010s] threads: 64, tps: 0.00, reads: 0.00, writes: 46666.71, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1011s] threads: 64, tps: 0.00, reads: 0.00, writes: 36394.18, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[1012s] threads: 64, tps: 0.00, reads: 0.00, writes: 39536.95, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1013s] threads: 64, tps: 0.00, reads: 0.00, writes: 37059.06, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1014s] threads: 64, tps: 0.00, reads: 0.00, writes: 37369.85, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1015s] threads: 64, tps: 0.00, reads: 0.00, writes: 47654.20, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1016s] threads: 64, tps: 0.00, reads: 0.00, writes: 39664.01, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1017s] threads: 64, tps: 0.00, reads: 0.00, writes: 36676.99, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1018s] threads: 64, tps: 0.00, reads: 0.00, writes: 42025.98, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1019s] threads: 64, tps: 0.00, reads: 0.00, writes: 42239.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1020s] threads: 64, tps: 0.00, reads: 0.00, writes: 48089.07, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1021s] threads: 64, tps: 0.00, reads: 0.00, writes: 46063.90, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1022s] threads: 64, tps: 0.00, reads: 0.00, writes: 36569.33, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1023s] threads: 64, tps: 0.00, reads: 0.00, writes: 3179.13, response time: 21.51ms (95%), errors: 0.00, reconnects:  0.00
[1024s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.01, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[1025s] threads: 64, tps: 0.00, reads: 0.00, writes: 3143.96, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[1026s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.04, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1027s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.91, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1028s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.09, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1029s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.00, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[1030s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[1031s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.00, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[1032s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.01, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1033s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.89, response time: 20.96ms (95%), errors: 0.00, reconnects:  0.00
[1034s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.11, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1035s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.00, response time: 20.89ms (95%), errors: 0.00, reconnects:  0.00
[1036s] threads: 64, tps: 0.00, reads: 0.00, writes: 15086.01, response time: 20.40ms (95%), errors: 0.00, reconnects:  0.00
[1037s] threads: 64, tps: 0.00, reads: 0.00, writes: 46236.96, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1038s] threads: 64, tps: 0.00, reads: 0.00, writes: 46032.27, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1039s] threads: 64, tps: 0.00, reads: 0.00, writes: 36568.52, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1040s] threads: 64, tps: 0.00, reads: 0.00, writes: 38512.03, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[1041s] threads: 64, tps: 0.00, reads: 0.00, writes: 37158.88, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[1042s] threads: 64, tps: 0.00, reads: 0.00, writes: 37600.04, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1043s] threads: 64, tps: 0.00, reads: 0.00, writes: 48141.90, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1044s] threads: 64, tps: 0.00, reads: 0.00, writes: 41629.00, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1045s] threads: 64, tps: 0.00, reads: 0.00, writes: 37944.22, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1046s] threads: 64, tps: 0.00, reads: 0.00, writes: 36907.80, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1047s] threads: 64, tps: 0.00, reads: 0.00, writes: 37684.20, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1048s] threads: 64, tps: 0.00, reads: 0.00, writes: 47081.98, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1049s] threads: 64, tps: 0.00, reads: 0.00, writes: 41535.91, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1050s] threads: 64, tps: 0.00, reads: 0.00, writes: 40086.06, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[1051s] threads: 64, tps: 0.00, reads: 0.00, writes: 43051.81, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1052s] threads: 64, tps: 0.00, reads: 0.00, writes: 43090.20, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1053s] threads: 64, tps: 0.00, reads: 0.00, writes: 49257.98, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1054s] threads: 64, tps: 0.00, reads: 0.00, writes: 45366.97, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1055s] threads: 64, tps: 0.00, reads: 0.00, writes: 42540.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1056s] threads: 64, tps: 0.00, reads: 0.00, writes: 37831.02, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1057s] threads: 64, tps: 0.00, reads: 0.00, writes: 44975.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1058s] threads: 64, tps: 0.00, reads: 0.00, writes: 47139.72, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1059s] threads: 64, tps: 0.00, reads: 0.00, writes: 44559.21, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1060s] threads: 64, tps: 0.00, reads: 0.00, writes: 43626.00, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1061s] threads: 64, tps: 0.00, reads: 0.00, writes: 42675.04, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1062s] threads: 64, tps: 0.00, reads: 0.00, writes: 46359.03, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1063s] threads: 64, tps: 0.00, reads: 0.00, writes: 46109.90, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1064s] threads: 64, tps: 0.00, reads: 0.00, writes: 46481.04, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[1065s] threads: 64, tps: 0.00, reads: 0.00, writes: 42837.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1066s] threads: 64, tps: 0.00, reads: 0.00, writes: 43263.02, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1067s] threads: 64, tps: 0.00, reads: 0.00, writes: 45799.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1068s] threads: 64, tps: 0.00, reads: 0.00, writes: 44809.67, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1069s] threads: 64, tps: 0.00, reads: 0.00, writes: 39378.91, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1070s] threads: 64, tps: 0.00, reads: 0.00, writes: 42791.95, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1071s] threads: 64, tps: 0.00, reads: 0.00, writes: 43953.07, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1072s] threads: 64, tps: 0.00, reads: 0.00, writes: 48958.99, response time: 1.66ms (95%), errors: 0.00, reconnects:  0.00
[1073s] threads: 64, tps: 0.00, reads: 0.00, writes: 49487.04, response time: 1.68ms (95%), errors: 0.00, reconnects:  0.00
[1074s] threads: 64, tps: 0.00, reads: 0.00, writes: 45916.97, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1075s] threads: 64, tps: 0.00, reads: 0.00, writes: 45839.01, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1076s] threads: 64, tps: 0.00, reads: 0.00, writes: 43089.93, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1077s] threads: 64, tps: 0.00, reads: 0.00, writes: 48477.07, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[1078s] threads: 64, tps: 0.00, reads: 0.00, writes: 47447.02, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1079s] threads: 64, tps: 0.00, reads: 0.00, writes: 45910.97, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1080s] threads: 64, tps: 0.00, reads: 0.00, writes: 45143.98, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1081s] threads: 64, tps: 0.00, reads: 0.00, writes: 47501.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1082s] threads: 64, tps: 0.00, reads: 0.00, writes: 45968.03, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1083s] threads: 64, tps: 0.00, reads: 0.00, writes: 37038.03, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1084s] threads: 64, tps: 0.00, reads: 0.00, writes: 43199.01, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1085s] threads: 64, tps: 0.00, reads: 0.00, writes: 43747.99, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1086s] threads: 64, tps: 0.00, reads: 0.00, writes: 47994.00, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1087s] threads: 64, tps: 0.00, reads: 0.00, writes: 41737.95, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1088s] threads: 64, tps: 0.00, reads: 0.00, writes: 38200.06, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1089s] threads: 64, tps: 0.00, reads: 0.00, writes: 39617.92, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1090s] threads: 64, tps: 0.00, reads: 0.00, writes: 38350.55, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1091s] threads: 64, tps: 0.00, reads: 0.00, writes: 38521.51, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[1092s] threads: 64, tps: 0.00, reads: 0.00, writes: 44496.99, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1093s] threads: 64, tps: 0.00, reads: 0.00, writes: 36221.96, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[1094s] threads: 64, tps: 0.00, reads: 0.00, writes: 40879.02, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1095s] threads: 64, tps: 0.00, reads: 0.00, writes: 44396.99, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1096s] threads: 64, tps: 0.00, reads: 0.00, writes: 45463.71, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1097s] threads: 64, tps: 0.00, reads: 0.00, writes: 46938.70, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1098s] threads: 64, tps: 0.00, reads: 0.00, writes: 46232.93, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1099s] threads: 64, tps: 0.00, reads: 0.00, writes: 8698.77, response time: 20.89ms (95%), errors: 0.00, reconnects:  0.00
[1100s] threads: 64, tps: 0.00, reads: 0.00, writes: 3142.01, response time: 21.15ms (95%), errors: 0.00, reconnects:  0.00
[1101s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.06, response time: 21.36ms (95%), errors: 0.00, reconnects:  0.00
[1102s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.01, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[1103s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.00, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1104s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.99, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[1105s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.00, response time: 20.96ms (95%), errors: 0.00, reconnects:  0.00
[1106s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.98, response time: 20.85ms (95%), errors: 0.00, reconnects:  0.00
[1107s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.94, response time: 20.94ms (95%), errors: 0.00, reconnects:  0.00
[1108s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.08, response time: 21.90ms (95%), errors: 0.00, reconnects:  0.00
[1109s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.00, response time: 21.00ms (95%), errors: 0.00, reconnects:  0.00
[1110s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.99, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1111s] threads: 64, tps: 0.00, reads: 0.00, writes: 3125.01, response time: 22.21ms (95%), errors: 0.00, reconnects:  0.00
[1112s] threads: 64, tps: 0.00, reads: 0.00, writes: 3144.95, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[1113s] threads: 64, tps: 0.00, reads: 0.00, writes: 3181.04, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[1114s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[1115s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[1116s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.01, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1117s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.00, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1118s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.99, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[1119s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.01, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1120s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.00, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1121s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.99, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1122s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.01, response time: 21.15ms (95%), errors: 0.00, reconnects:  0.00
[1123s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.95, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[1124s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.05, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[1125s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.99, response time: 20.92ms (95%), errors: 0.00, reconnects:  0.00
[1126s] threads: 64, tps: 0.00, reads: 0.00, writes: 2934.99, response time: 26.03ms (95%), errors: 0.00, reconnects:  0.00
[1127s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.00, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[1128s] threads: 64, tps: 0.00, reads: 0.00, writes: 3118.00, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[1129s] threads: 64, tps: 0.00, reads: 0.00, writes: 2515.97, response time: 26.24ms (95%), errors: 0.00, reconnects:  0.00
[1130s] threads: 64, tps: 0.00, reads: 0.00, writes: 2541.04, response time: 26.09ms (95%), errors: 0.00, reconnects:  0.00
[1131s] threads: 64, tps: 0.00, reads: 0.00, writes: 17708.01, response time: 25.28ms (95%), errors: 0.00, reconnects:  0.00
[1132s] threads: 64, tps: 0.00, reads: 0.00, writes: 46680.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1133s] threads: 64, tps: 0.00, reads: 0.00, writes: 44357.04, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1134s] threads: 64, tps: 0.00, reads: 0.00, writes: 43893.97, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1135s] threads: 64, tps: 0.00, reads: 0.00, writes: 40423.44, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[1136s] threads: 64, tps: 0.00, reads: 0.00, writes: 46016.68, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1137s] threads: 64, tps: 0.00, reads: 0.00, writes: 45366.93, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1138s] threads: 64, tps: 0.00, reads: 0.00, writes: 43752.07, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1139s] threads: 64, tps: 0.00, reads: 0.00, writes: 43668.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1140s] threads: 64, tps: 0.00, reads: 0.00, writes: 42382.93, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1141s] threads: 64, tps: 0.00, reads: 0.00, writes: 48513.09, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1142s] threads: 64, tps: 0.00, reads: 0.00, writes: 48192.97, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1143s] threads: 64, tps: 0.00, reads: 0.00, writes: 38719.91, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1144s] threads: 64, tps: 0.00, reads: 0.00, writes: 43427.07, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1145s] threads: 64, tps: 0.00, reads: 0.00, writes: 41050.97, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1146s] threads: 64, tps: 0.00, reads: 0.00, writes: 47109.08, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1147s] threads: 64, tps: 0.00, reads: 0.00, writes: 41884.94, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[1148s] threads: 64, tps: 0.00, reads: 0.00, writes: 44480.03, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1149s] threads: 64, tps: 0.00, reads: 0.00, writes: 42634.02, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1150s] threads: 64, tps: 0.00, reads: 0.00, writes: 45443.02, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1151s] threads: 64, tps: 0.00, reads: 0.00, writes: 48157.97, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1152s] threads: 64, tps: 0.00, reads: 0.00, writes: 45873.07, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1153s] threads: 64, tps: 0.00, reads: 0.00, writes: 44389.90, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1154s] threads: 64, tps: 0.00, reads: 0.00, writes: 43741.04, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1155s] threads: 64, tps: 0.00, reads: 0.00, writes: 47750.89, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1156s] threads: 64, tps: 0.00, reads: 0.00, writes: 47789.03, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1157s] threads: 64, tps: 0.00, reads: 0.00, writes: 43348.07, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1158s] threads: 64, tps: 0.00, reads: 0.00, writes: 42946.95, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1159s] threads: 64, tps: 0.00, reads: 0.00, writes: 42309.06, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1160s] threads: 64, tps: 0.00, reads: 0.00, writes: 48531.96, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1161s] threads: 64, tps: 0.00, reads: 0.00, writes: 45892.97, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1162s] threads: 64, tps: 0.00, reads: 0.00, writes: 44555.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1163s] threads: 64, tps: 0.00, reads: 0.00, writes: 44347.08, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1164s] threads: 64, tps: 0.00, reads: 0.00, writes: 46001.99, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1165s] threads: 64, tps: 0.00, reads: 0.00, writes: 47767.01, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1166s] threads: 64, tps: 0.00, reads: 0.00, writes: 39543.98, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[1167s] threads: 64, tps: 0.00, reads: 0.00, writes: 38054.03, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1168s] threads: 64, tps: 0.00, reads: 0.00, writes: 40362.00, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1169s] threads: 64, tps: 0.00, reads: 0.00, writes: 45029.75, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1170s] threads: 64, tps: 0.00, reads: 0.00, writes: 46293.09, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1171s] threads: 64, tps: 0.00, reads: 0.00, writes: 45849.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1172s] threads: 64, tps: 0.00, reads: 0.00, writes: 44513.09, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1173s] threads: 64, tps: 0.00, reads: 0.00, writes: 43929.05, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1174s] threads: 64, tps: 0.00, reads: 0.00, writes: 47620.86, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1175s] threads: 64, tps: 0.00, reads: 0.00, writes: 46925.88, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1176s] threads: 64, tps: 0.00, reads: 0.00, writes: 41270.17, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1177s] threads: 64, tps: 0.00, reads: 0.00, writes: 40261.91, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1178s] threads: 64, tps: 0.00, reads: 0.00, writes: 38461.15, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1179s] threads: 64, tps: 0.00, reads: 0.00, writes: 47758.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1180s] threads: 64, tps: 0.00, reads: 0.00, writes: 46364.75, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1181s] threads: 64, tps: 0.00, reads: 0.00, writes: 43674.23, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1182s] threads: 64, tps: 0.00, reads: 0.00, writes: 45474.02, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1183s] threads: 64, tps: 0.00, reads: 0.00, writes: 43439.00, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1184s] threads: 64, tps: 0.00, reads: 0.00, writes: 49054.00, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1185s] threads: 64, tps: 0.00, reads: 0.00, writes: 48000.92, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1186s] threads: 64, tps: 0.00, reads: 0.00, writes: 44477.86, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1187s] threads: 64, tps: 0.00, reads: 0.00, writes: 44280.25, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1188s] threads: 64, tps: 0.00, reads: 0.00, writes: 46430.93, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1189s] threads: 64, tps: 0.00, reads: 0.00, writes: 47562.96, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1190s] threads: 64, tps: 0.00, reads: 0.00, writes: 46198.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1191s] threads: 64, tps: 0.00, reads: 0.00, writes: 43969.05, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1192s] threads: 64, tps: 0.00, reads: 0.00, writes: 45112.96, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1193s] threads: 64, tps: 0.00, reads: 0.00, writes: 48941.02, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1194s] threads: 64, tps: 0.00, reads: 0.00, writes: 46348.03, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1195s] threads: 64, tps: 0.00, reads: 0.00, writes: 39446.67, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1196s] threads: 64, tps: 0.00, reads: 0.00, writes: 3171.10, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1197s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.99, response time: 20.96ms (95%), errors: 0.00, reconnects:  0.00
[1198s] threads: 64, tps: 0.00, reads: 0.00, writes: 3179.99, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[1199s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.00, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1200s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.94, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[1201s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.04, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[1202s] threads: 64, tps: 0.00, reads: 0.00, writes: 4951.03, response time: 20.92ms (95%), errors: 0.00, reconnects:  0.00
[1203s] threads: 64, tps: 0.00, reads: 0.00, writes: 45081.26, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1204s] threads: 64, tps: 0.00, reads: 0.00, writes: 48403.78, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1205s] threads: 64, tps: 0.00, reads: 0.00, writes: 47789.14, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1206s] threads: 64, tps: 0.00, reads: 0.00, writes: 35547.92, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1207s] threads: 64, tps: 0.00, reads: 0.00, writes: 43708.11, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1208s] threads: 64, tps: 0.00, reads: 0.00, writes: 36059.03, response time: 2.70ms (95%), errors: 0.00, reconnects:  0.00
[1209s] threads: 64, tps: 0.00, reads: 0.00, writes: 45616.98, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1210s] threads: 64, tps: 0.00, reads: 0.00, writes: 46442.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1211s] threads: 64, tps: 0.00, reads: 0.00, writes: 44192.77, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1212s] threads: 64, tps: 0.00, reads: 0.00, writes: 44967.87, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1213s] threads: 64, tps: 0.00, reads: 0.00, writes: 43390.20, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1214s] threads: 64, tps: 0.00, reads: 0.00, writes: 47669.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1215s] threads: 64, tps: 0.00, reads: 0.00, writes: 46906.97, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1216s] threads: 64, tps: 0.00, reads: 0.00, writes: 44433.18, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1217s] threads: 64, tps: 0.00, reads: 0.00, writes: 43495.97, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1218s] threads: 64, tps: 0.00, reads: 0.00, writes: 44385.05, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1219s] threads: 64, tps: 0.00, reads: 0.00, writes: 46983.04, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1220s] threads: 64, tps: 0.00, reads: 0.00, writes: 46082.72, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1221s] threads: 64, tps: 0.00, reads: 0.00, writes: 43601.21, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1222s] threads: 64, tps: 0.00, reads: 0.00, writes: 40636.86, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1223s] threads: 64, tps: 0.00, reads: 0.00, writes: 46112.94, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1224s] threads: 64, tps: 0.00, reads: 0.00, writes: 45071.02, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1225s] threads: 64, tps: 0.00, reads: 0.00, writes: 44025.25, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1226s] threads: 64, tps: 0.00, reads: 0.00, writes: 43145.99, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1227s] threads: 64, tps: 0.00, reads: 0.00, writes: 42406.83, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1228s] threads: 64, tps: 0.00, reads: 0.00, writes: 46921.15, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1229s] threads: 64, tps: 0.00, reads: 0.00, writes: 47223.08, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1230s] threads: 64, tps: 0.00, reads: 0.00, writes: 42748.82, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1231s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.98, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[1232s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.97, response time: 21.25ms (95%), errors: 0.00, reconnects:  0.00
[1233s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.02, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1234s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.03, response time: 21.15ms (95%), errors: 0.00, reconnects:  0.00
[1235s] threads: 64, tps: 0.00, reads: 0.00, writes: 3142.01, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[1236s] threads: 64, tps: 0.00, reads: 0.00, writes: 3181.00, response time: 21.05ms (95%), errors: 0.00, reconnects:  0.00
[1237s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.93, response time: 21.42ms (95%), errors: 0.00, reconnects:  0.00
[1238s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.06, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[1239s] threads: 64, tps: 0.00, reads: 0.00, writes: 18319.07, response time: 20.43ms (95%), errors: 0.00, reconnects:  0.00
[1240s] threads: 64, tps: 0.00, reads: 0.00, writes: 44427.04, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1241s] threads: 64, tps: 0.00, reads: 0.00, writes: 48380.76, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1242s] threads: 64, tps: 0.00, reads: 0.00, writes: 47184.23, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1243s] threads: 64, tps: 0.00, reads: 0.00, writes: 46209.74, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1244s] threads: 64, tps: 0.00, reads: 0.00, writes: 44762.26, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1245s] threads: 64, tps: 0.00, reads: 0.00, writes: 44497.14, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1246s] threads: 64, tps: 0.00, reads: 0.00, writes: 46245.64, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1247s] threads: 64, tps: 0.00, reads: 0.00, writes: 41186.25, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1248s] threads: 64, tps: 0.00, reads: 0.00, writes: 38551.98, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1249s] threads: 64, tps: 0.00, reads: 0.00, writes: 42160.96, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1250s] threads: 64, tps: 0.00, reads: 0.00, writes: 46276.83, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1251s] threads: 64, tps: 0.00, reads: 0.00, writes: 47908.83, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1252s] threads: 64, tps: 0.00, reads: 0.00, writes: 44824.87, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1253s] threads: 64, tps: 0.00, reads: 0.00, writes: 44194.90, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1254s] threads: 64, tps: 0.00, reads: 0.00, writes: 42732.05, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1255s] threads: 64, tps: 0.00, reads: 0.00, writes: 44204.87, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1256s] threads: 64, tps: 0.00, reads: 0.00, writes: 45274.14, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1257s] threads: 64, tps: 0.00, reads: 0.00, writes: 38464.01, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[1258s] threads: 64, tps: 0.00, reads: 0.00, writes: 42406.01, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1259s] threads: 64, tps: 0.00, reads: 0.00, writes: 38423.98, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[1260s] threads: 64, tps: 0.00, reads: 0.00, writes: 43558.79, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1261s] threads: 64, tps: 0.00, reads: 0.00, writes: 41587.20, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1262s] threads: 64, tps: 0.00, reads: 0.00, writes: 3261.98, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[1263s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.96, response time: 21.25ms (95%), errors: 0.00, reconnects:  0.00
[1264s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.98, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[1265s] threads: 64, tps: 0.00, reads: 0.00, writes: 3139.08, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[1266s] threads: 64, tps: 0.00, reads: 0.00, writes: 3135.87, response time: 21.81ms (95%), errors: 0.00, reconnects:  0.00
[1267s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.00, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[1268s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.03, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1269s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.03, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[1270s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.06, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[1271s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.01, response time: 21.26ms (95%), errors: 0.00, reconnects:  0.00
[1272s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.98, response time: 21.30ms (95%), errors: 0.00, reconnects:  0.00
[1273s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.92, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[1274s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.02, response time: 21.27ms (95%), errors: 0.00, reconnects:  0.00
[1275s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.05, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[1276s] threads: 64, tps: 0.00, reads: 0.00, writes: 3110.95, response time: 21.30ms (95%), errors: 0.00, reconnects:  0.00
[1277s] threads: 64, tps: 0.00, reads: 0.00, writes: 3180.08, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[1278s] threads: 64, tps: 0.00, reads: 0.00, writes: 3138.94, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1279s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.03, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[1280s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.04, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[1281s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.00, response time: 21.00ms (95%), errors: 0.00, reconnects:  0.00
[1282s] threads: 64, tps: 0.00, reads: 0.00, writes: 3138.99, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[1283s] threads: 64, tps: 0.00, reads: 0.00, writes: 3183.00, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1284s] threads: 64, tps: 0.00, reads: 0.00, writes: 3148.95, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1285s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.05, response time: 21.34ms (95%), errors: 0.00, reconnects:  0.00
[1286s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.00, response time: 21.17ms (95%), errors: 0.00, reconnects:  0.00
[1287s] threads: 64, tps: 0.00, reads: 0.00, writes: 3140.95, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[1288s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.05, response time: 21.37ms (95%), errors: 0.00, reconnects:  0.00
[1289s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.00, response time: 21.15ms (95%), errors: 0.00, reconnects:  0.00
[1290s] threads: 64, tps: 0.00, reads: 0.00, writes: 3143.96, response time: 21.37ms (95%), errors: 0.00, reconnects:  0.00
[1291s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.05, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1292s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.00, response time: 21.17ms (95%), errors: 0.00, reconnects:  0.00
[1293s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.01, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[1294s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.93, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[1295s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.07, response time: 21.08ms (95%), errors: 0.00, reconnects:  0.00
[1296s] threads: 64, tps: 0.00, reads: 0.00, writes: 3144.00, response time: 20.92ms (95%), errors: 0.00, reconnects:  0.00
[1297s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.00, response time: 21.24ms (95%), errors: 0.00, reconnects:  0.00
[1298s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.99, response time: 21.35ms (95%), errors: 0.00, reconnects:  0.00
[1299s] threads: 64, tps: 0.00, reads: 0.00, writes: 3130.83, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1300s] threads: 64, tps: 0.00, reads: 0.00, writes: 3177.17, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[1301s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.97, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[1302s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.15, response time: 21.15ms (95%), errors: 0.00, reconnects:  0.00
[1303s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.86, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[1304s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.01, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[1305s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.89, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[1306s] threads: 64, tps: 0.00, reads: 0.00, writes: 2560.01, response time: 26.14ms (95%), errors: 0.00, reconnects:  0.00
[1307s] threads: 64, tps: 0.00, reads: 0.00, writes: 2526.99, response time: 26.24ms (95%), errors: 0.00, reconnects:  0.00
[1308s] threads: 64, tps: 0.00, reads: 0.00, writes: 2427.08, response time: 32.27ms (95%), errors: 0.00, reconnects:  0.00
[1309s] threads: 64, tps: 0.00, reads: 0.00, writes: 2148.98, response time: 32.66ms (95%), errors: 0.00, reconnects:  0.00
[1310s] threads: 64, tps: 0.00, reads: 0.00, writes: 2523.95, response time: 25.98ms (95%), errors: 0.00, reconnects:  0.00
[1311s] threads: 64, tps: 0.00, reads: 0.00, writes: 2532.00, response time: 26.12ms (95%), errors: 0.00, reconnects:  0.00
[1312s] threads: 64, tps: 0.00, reads: 0.00, writes: 2524.07, response time: 26.01ms (95%), errors: 0.00, reconnects:  0.00
[1313s] threads: 64, tps: 0.00, reads: 0.00, writes: 2531.96, response time: 26.10ms (95%), errors: 0.00, reconnects:  0.00
[1314s] threads: 64, tps: 0.00, reads: 0.00, writes: 2525.05, response time: 25.98ms (95%), errors: 0.00, reconnects:  0.00
[1315s] threads: 64, tps: 0.00, reads: 0.00, writes: 2530.92, response time: 26.11ms (95%), errors: 0.00, reconnects:  0.00
[1316s] threads: 64, tps: 0.00, reads: 0.00, writes: 2530.00, response time: 26.24ms (95%), errors: 0.00, reconnects:  0.00
[1317s] threads: 64, tps: 0.00, reads: 0.00, writes: 2528.98, response time: 26.14ms (95%), errors: 0.00, reconnects:  0.00
[1318s] threads: 64, tps: 0.00, reads: 0.00, writes: 2537.09, response time: 26.14ms (95%), errors: 0.00, reconnects:  0.00
[1319s] threads: 64, tps: 0.00, reads: 0.00, writes: 2522.92, response time: 26.20ms (95%), errors: 0.00, reconnects:  0.00
[1320s] threads: 64, tps: 0.00, reads: 0.00, writes: 2525.08, response time: 26.14ms (95%), errors: 0.00, reconnects:  0.00
[1321s] threads: 64, tps: 0.00, reads: 0.00, writes: 2538.00, response time: 26.17ms (95%), errors: 0.00, reconnects:  0.00
[1322s] threads: 64, tps: 0.00, reads: 0.00, writes: 2511.99, response time: 26.09ms (95%), errors: 0.00, reconnects:  0.00
[1323s] threads: 64, tps: 0.00, reads: 0.00, writes: 4776.03, response time: 25.48ms (95%), errors: 0.00, reconnects:  0.00
[1324s] threads: 64, tps: 0.00, reads: 0.00, writes: 47743.00, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1325s] threads: 64, tps: 0.00, reads: 0.00, writes: 45395.07, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1326s] threads: 64, tps: 0.00, reads: 0.00, writes: 43573.69, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1327s] threads: 64, tps: 0.00, reads: 0.00, writes: 44574.35, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1328s] threads: 64, tps: 0.00, reads: 0.00, writes: 49123.83, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[1329s] threads: 64, tps: 0.00, reads: 0.00, writes: 44296.09, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1330s] threads: 64, tps: 0.00, reads: 0.00, writes: 44359.80, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1331s] threads: 64, tps: 0.00, reads: 0.00, writes: 45338.99, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1332s] threads: 64, tps: 0.00, reads: 0.00, writes: 47722.27, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1333s] threads: 64, tps: 0.00, reads: 0.00, writes: 46280.86, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1334s] threads: 64, tps: 0.00, reads: 0.00, writes: 39171.10, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1335s] threads: 64, tps: 0.00, reads: 0.00, writes: 38369.04, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[1336s] threads: 64, tps: 0.00, reads: 0.00, writes: 37111.97, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1337s] threads: 64, tps: 0.00, reads: 0.00, writes: 44367.93, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1338s] threads: 64, tps: 0.00, reads: 0.00, writes: 46620.03, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1339s] threads: 64, tps: 0.00, reads: 0.00, writes: 38730.79, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1340s] threads: 64, tps: 0.00, reads: 0.00, writes: 37805.02, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1341s] threads: 64, tps: 0.00, reads: 0.00, writes: 42980.25, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1342s] threads: 64, tps: 0.00, reads: 0.00, writes: 45762.73, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1343s] threads: 64, tps: 0.00, reads: 0.00, writes: 45477.01, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1344s] threads: 64, tps: 0.00, reads: 0.00, writes: 46041.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1345s] threads: 64, tps: 0.00, reads: 0.00, writes: 43871.23, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1346s] threads: 64, tps: 0.00, reads: 0.00, writes: 42794.04, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1347s] threads: 64, tps: 0.00, reads: 0.00, writes: 46876.71, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1348s] threads: 64, tps: 0.00, reads: 0.00, writes: 45238.06, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1349s] threads: 64, tps: 0.00, reads: 0.00, writes: 44359.94, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1350s] threads: 64, tps: 0.00, reads: 0.00, writes: 43657.23, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1351s] threads: 64, tps: 0.00, reads: 0.00, writes: 43445.71, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1352s] threads: 64, tps: 0.00, reads: 0.00, writes: 47955.29, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1353s] threads: 64, tps: 0.00, reads: 0.00, writes: 41374.92, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1354s] threads: 64, tps: 0.00, reads: 0.00, writes: 35929.92, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[1355s] threads: 64, tps: 0.00, reads: 0.00, writes: 37805.06, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[1356s] threads: 64, tps: 0.00, reads: 0.00, writes: 38032.05, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1357s] threads: 64, tps: 0.00, reads: 0.00, writes: 45533.08, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[1358s] threads: 64, tps: 0.00, reads: 0.00, writes: 42780.78, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1359s] threads: 64, tps: 0.00, reads: 0.00, writes: 41358.99, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1360s] threads: 64, tps: 0.00, reads: 0.00, writes: 38374.02, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1361s] threads: 64, tps: 0.00, reads: 0.00, writes: 35804.13, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[1362s] threads: 64, tps: 0.00, reads: 0.00, writes: 40939.06, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1363s] threads: 64, tps: 0.00, reads: 0.00, writes: 44745.17, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1364s] threads: 64, tps: 0.00, reads: 0.00, writes: 39817.94, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1365s] threads: 64, tps: 0.00, reads: 0.00, writes: 36868.01, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1366s] threads: 64, tps: 0.00, reads: 0.00, writes: 38816.00, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1367s] threads: 64, tps: 0.00, reads: 0.00, writes: 41127.10, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[1368s] threads: 64, tps: 0.00, reads: 0.00, writes: 47068.93, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1369s] threads: 64, tps: 0.00, reads: 0.00, writes: 21650.65, response time: 20.03ms (95%), errors: 0.00, reconnects:  0.00
[1370s] threads: 64, tps: 0.00, reads: 0.00, writes: 3140.04, response time: 21.42ms (95%), errors: 0.00, reconnects:  0.00
[1371s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.00, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1372s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.00, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1373s] threads: 64, tps: 0.00, reads: 0.00, writes: 3174.01, response time: 21.00ms (95%), errors: 0.00, reconnects:  0.00
[1374s] threads: 64, tps: 0.00, reads: 0.00, writes: 3142.00, response time: 21.25ms (95%), errors: 0.00, reconnects:  0.00
[1375s] threads: 64, tps: 0.00, reads: 0.00, writes: 3171.94, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[1376s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.06, response time: 21.26ms (95%), errors: 0.00, reconnects:  0.00
[1377s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.00, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1378s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.95, response time: 21.20ms (95%), errors: 0.00, reconnects:  0.00
[1379s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.05, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1380s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.93, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[1381s] threads: 64, tps: 0.00, reads: 0.00, writes: 3174.99, response time: 21.08ms (95%), errors: 0.00, reconnects:  0.00
[1382s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.04, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[1383s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.04, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[1384s] threads: 64, tps: 0.00, reads: 0.00, writes: 3139.92, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[1385s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.08, response time: 21.08ms (95%), errors: 0.00, reconnects:  0.00
[1386s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.99, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1387s] threads: 64, tps: 0.00, reads: 0.00, writes: 3145.93, response time: 21.23ms (95%), errors: 0.00, reconnects:  0.00
[1388s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.09, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[1389s] threads: 64, tps: 0.00, reads: 0.00, writes: 7034.01, response time: 20.80ms (95%), errors: 0.00, reconnects:  0.00
[1390s] threads: 64, tps: 0.00, reads: 0.00, writes: 40496.07, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[1391s] threads: 64, tps: 0.00, reads: 0.00, writes: 46947.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1392s] threads: 64, tps: 0.00, reads: 0.00, writes: 47769.96, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1393s] threads: 64, tps: 0.00, reads: 0.00, writes: 44694.06, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1394s] threads: 64, tps: 0.00, reads: 0.00, writes: 41721.81, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1395s] threads: 64, tps: 0.00, reads: 0.00, writes: 43442.98, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1396s] threads: 64, tps: 0.00, reads: 0.00, writes: 48497.06, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1397s] threads: 64, tps: 0.00, reads: 0.00, writes: 46249.14, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1398s] threads: 64, tps: 0.00, reads: 0.00, writes: 46137.78, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1399s] threads: 64, tps: 0.00, reads: 0.00, writes: 42828.02, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1400s] threads: 64, tps: 0.00, reads: 0.00, writes: 40191.98, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1401s] threads: 64, tps: 0.00, reads: 0.00, writes: 48515.16, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1402s] threads: 64, tps: 0.00, reads: 0.00, writes: 40982.05, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[1403s] threads: 64, tps: 0.00, reads: 0.00, writes: 38603.99, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1404s] threads: 64, tps: 0.00, reads: 0.00, writes: 38922.99, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1405s] threads: 64, tps: 0.00, reads: 0.00, writes: 38179.99, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1406s] threads: 64, tps: 0.00, reads: 0.00, writes: 45187.76, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1407s] threads: 64, tps: 0.00, reads: 0.00, writes: 37393.11, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1408s] threads: 64, tps: 0.00, reads: 0.00, writes: 37861.92, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1409s] threads: 64, tps: 0.00, reads: 0.00, writes: 37454.75, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1410s] threads: 64, tps: 0.00, reads: 0.00, writes: 37916.44, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[1411s] threads: 64, tps: 0.00, reads: 0.00, writes: 43721.96, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1412s] threads: 64, tps: 0.00, reads: 0.00, writes: 45448.09, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1413s] threads: 64, tps: 0.00, reads: 0.00, writes: 37714.14, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1414s] threads: 64, tps: 0.00, reads: 0.00, writes: 38257.66, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1415s] threads: 64, tps: 0.00, reads: 0.00, writes: 40013.07, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1416s] threads: 64, tps: 0.00, reads: 0.00, writes: 44318.96, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1417s] threads: 64, tps: 0.00, reads: 0.00, writes: 48440.38, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1418s] threads: 64, tps: 0.00, reads: 0.00, writes: 45538.35, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1419s] threads: 64, tps: 0.00, reads: 0.00, writes: 41183.82, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1420s] threads: 64, tps: 0.00, reads: 0.00, writes: 43337.13, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1421s] threads: 64, tps: 0.00, reads: 0.00, writes: 44694.94, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1422s] threads: 64, tps: 0.00, reads: 0.00, writes: 47359.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1423s] threads: 64, tps: 0.00, reads: 0.00, writes: 43931.98, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1424s] threads: 64, tps: 0.00, reads: 0.00, writes: 43988.36, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1425s] threads: 64, tps: 0.00, reads: 0.00, writes: 43951.81, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1426s] threads: 64, tps: 0.00, reads: 0.00, writes: 48887.83, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1427s] threads: 64, tps: 0.00, reads: 0.00, writes: 45564.94, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1428s] threads: 64, tps: 0.00, reads: 0.00, writes: 43731.28, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1429s] threads: 64, tps: 0.00, reads: 0.00, writes: 42178.79, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1430s] threads: 64, tps: 0.00, reads: 0.00, writes: 43400.05, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1431s] threads: 64, tps: 0.00, reads: 0.00, writes: 47913.91, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[1432s] threads: 64, tps: 0.00, reads: 0.00, writes: 46379.23, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1433s] threads: 64, tps: 0.00, reads: 0.00, writes: 43468.95, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1434s] threads: 64, tps: 0.00, reads: 0.00, writes: 39641.97, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[1435s] threads: 64, tps: 0.00, reads: 0.00, writes: 41309.98, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1436s] threads: 64, tps: 0.00, reads: 0.00, writes: 47576.05, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1437s] threads: 64, tps: 0.00, reads: 0.00, writes: 44693.10, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1438s] threads: 64, tps: 0.00, reads: 0.00, writes: 40509.20, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1439s] threads: 64, tps: 0.00, reads: 0.00, writes: 36075.99, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1440s] threads: 64, tps: 0.00, reads: 0.00, writes: 39215.96, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1441s] threads: 64, tps: 0.00, reads: 0.00, writes: 46820.07, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1442s] threads: 64, tps: 0.00, reads: 0.00, writes: 39256.97, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1443s] threads: 64, tps: 0.00, reads: 0.00, writes: 44563.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1444s] threads: 64, tps: 0.00, reads: 0.00, writes: 42795.99, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1445s] threads: 64, tps: 0.00, reads: 0.00, writes: 42402.01, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[1446s] threads: 64, tps: 0.00, reads: 0.00, writes: 47576.01, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1447s] threads: 64, tps: 0.00, reads: 0.00, writes: 44439.98, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1448s] threads: 64, tps: 0.00, reads: 0.00, writes: 39353.95, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1449s] threads: 64, tps: 0.00, reads: 0.00, writes: 38097.03, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1450s] threads: 64, tps: 0.00, reads: 0.00, writes: 42311.63, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1451s] threads: 64, tps: 0.00, reads: 0.00, writes: 48219.24, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1452s] threads: 64, tps: 0.00, reads: 0.00, writes: 46039.00, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1453s] threads: 64, tps: 0.00, reads: 0.00, writes: 44354.22, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1454s] threads: 64, tps: 0.00, reads: 0.00, writes: 44045.84, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1455s] threads: 64, tps: 0.00, reads: 0.00, writes: 47267.94, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1456s] threads: 64, tps: 0.00, reads: 0.00, writes: 47064.17, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1457s] threads: 64, tps: 0.00, reads: 0.00, writes: 46510.02, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1458s] threads: 64, tps: 0.00, reads: 0.00, writes: 43043.76, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1459s] threads: 64, tps: 0.00, reads: 0.00, writes: 42975.24, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1460s] threads: 64, tps: 0.00, reads: 0.00, writes: 48686.03, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1461s] threads: 64, tps: 0.00, reads: 0.00, writes: 46817.04, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1462s] threads: 64, tps: 0.00, reads: 0.00, writes: 27084.12, response time: 12.46ms (95%), errors: 0.00, reconnects:  0.00
[1463s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.97, response time: 21.25ms (95%), errors: 0.00, reconnects:  0.00
[1464s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.11, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[1465s] threads: 64, tps: 0.00, reads: 0.00, writes: 3140.00, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1466s] threads: 64, tps: 0.00, reads: 0.00, writes: 3186.00, response time: 21.20ms (95%), errors: 0.00, reconnects:  0.00
[1467s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.95, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1468s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.96, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[1469s] threads: 64, tps: 0.00, reads: 0.00, writes: 3171.01, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[1470s] threads: 64, tps: 0.00, reads: 0.00, writes: 3146.03, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1471s] threads: 64, tps: 0.00, reads: 0.00, writes: 3179.05, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[1472s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.91, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[1473s] threads: 64, tps: 0.00, reads: 0.00, writes: 3139.08, response time: 21.05ms (95%), errors: 0.00, reconnects:  0.00
[1474s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.94, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[1475s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.07, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1476s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.02, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[1477s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.00, response time: 20.87ms (95%), errors: 0.00, reconnects:  0.00
[1478s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.96, response time: 20.92ms (95%), errors: 0.00, reconnects:  0.00
[1479s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.04, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[1480s] threads: 64, tps: 0.00, reads: 0.00, writes: 40139.97, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1481s] threads: 64, tps: 0.00, reads: 0.00, writes: 46300.03, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1482s] threads: 64, tps: 0.00, reads: 0.00, writes: 43373.04, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1483s] threads: 64, tps: 0.00, reads: 0.00, writes: 42579.98, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1484s] threads: 64, tps: 0.00, reads: 0.00, writes: 42456.01, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1485s] threads: 64, tps: 0.00, reads: 0.00, writes: 43116.03, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1486s] threads: 64, tps: 0.00, reads: 0.00, writes: 47368.91, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1487s] threads: 64, tps: 0.00, reads: 0.00, writes: 46003.07, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1488s] threads: 64, tps: 0.00, reads: 0.00, writes: 35936.96, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[1489s] threads: 64, tps: 0.00, reads: 0.00, writes: 36774.67, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1490s] threads: 64, tps: 0.00, reads: 0.00, writes: 38767.36, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1491s] threads: 64, tps: 0.00, reads: 0.00, writes: 45486.97, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1492s] threads: 64, tps: 0.00, reads: 0.00, writes: 43674.12, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1493s] threads: 64, tps: 0.00, reads: 0.00, writes: 44141.71, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1494s] threads: 64, tps: 0.00, reads: 0.00, writes: 43013.30, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1495s] threads: 64, tps: 0.00, reads: 0.00, writes: 43213.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1496s] threads: 64, tps: 0.00, reads: 0.00, writes: 44730.98, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1497s] threads: 64, tps: 0.00, reads: 0.00, writes: 38545.02, response time: 2.74ms (95%), errors: 0.00, reconnects:  0.00
[1498s] threads: 64, tps: 0.00, reads: 0.00, writes: 36535.99, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1499s] threads: 64, tps: 0.00, reads: 0.00, writes: 35944.01, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1500s] threads: 64, tps: 0.00, reads: 0.00, writes: 34303.33, response time: 2.89ms (95%), errors: 0.00, reconnects:  0.00
[1501s] threads: 64, tps: 0.00, reads: 0.00, writes: 39795.80, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[1502s] threads: 64, tps: 0.00, reads: 0.00, writes: 40701.99, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1503s] threads: 64, tps: 0.00, reads: 0.00, writes: 33186.99, response time: 3.04ms (95%), errors: 0.00, reconnects:  0.00
[1504s] threads: 64, tps: 0.00, reads: 0.00, writes: 35535.99, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1505s] threads: 64, tps: 0.00, reads: 0.00, writes: 36629.98, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[1506s] threads: 64, tps: 0.00, reads: 0.00, writes: 35099.00, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[1507s] threads: 64, tps: 0.00, reads: 0.00, writes: 48306.06, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1508s] threads: 64, tps: 0.00, reads: 0.00, writes: 38840.98, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1509s] threads: 64, tps: 0.00, reads: 0.00, writes: 37232.95, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1510s] threads: 64, tps: 0.00, reads: 0.00, writes: 38187.03, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1511s] threads: 64, tps: 0.00, reads: 0.00, writes: 37266.05, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1512s] threads: 64, tps: 0.00, reads: 0.00, writes: 43716.94, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1513s] threads: 64, tps: 0.00, reads: 0.00, writes: 47611.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1514s] threads: 64, tps: 0.00, reads: 0.00, writes: 45775.02, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1515s] threads: 64, tps: 0.00, reads: 0.00, writes: 42134.02, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1516s] threads: 64, tps: 0.00, reads: 0.00, writes: 42034.97, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1517s] threads: 64, tps: 0.00, reads: 0.00, writes: 46491.99, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1518s] threads: 64, tps: 0.00, reads: 0.00, writes: 47717.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1519s] threads: 64, tps: 0.00, reads: 0.00, writes: 43312.02, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1520s] threads: 64, tps: 0.00, reads: 0.00, writes: 44465.96, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1521s] threads: 64, tps: 0.00, reads: 0.00, writes: 42971.05, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1522s] threads: 64, tps: 0.00, reads: 0.00, writes: 46255.92, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1523s] threads: 64, tps: 0.00, reads: 0.00, writes: 45895.04, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1524s] threads: 64, tps: 0.00, reads: 0.00, writes: 29358.99, response time: 3.29ms (95%), errors: 0.00, reconnects:  0.00
[1525s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.00, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[1526s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.83, response time: 21.15ms (95%), errors: 0.00, reconnects:  0.00
[1527s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.17, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[1528s] threads: 64, tps: 0.00, reads: 0.00, writes: 3145.99, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[1529s] threads: 64, tps: 0.00, reads: 0.00, writes: 3180.01, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1530s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.00, response time: 21.00ms (95%), errors: 0.00, reconnects:  0.00
[1531s] threads: 64, tps: 0.00, reads: 0.00, writes: 3135.94, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1532s] threads: 64, tps: 0.00, reads: 0.00, writes: 3174.05, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1533s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.01, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1534s] threads: 64, tps: 0.00, reads: 0.00, writes: 12813.00, response time: 20.70ms (95%), errors: 0.00, reconnects:  0.00
[1535s] threads: 64, tps: 0.00, reads: 0.00, writes: 45281.96, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1536s] threads: 64, tps: 0.00, reads: 0.00, writes: 48629.99, response time: 1.70ms (95%), errors: 0.00, reconnects:  0.00
[1537s] threads: 64, tps: 0.00, reads: 0.00, writes: 47732.06, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1538s] threads: 64, tps: 0.00, reads: 0.00, writes: 43457.99, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1539s] threads: 64, tps: 0.00, reads: 0.00, writes: 41757.96, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1540s] threads: 64, tps: 0.00, reads: 0.00, writes: 38476.04, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[1541s] threads: 64, tps: 0.00, reads: 0.00, writes: 44312.00, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[1542s] threads: 64, tps: 0.00, reads: 0.00, writes: 40231.94, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1543s] threads: 64, tps: 0.00, reads: 0.00, writes: 37747.99, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1544s] threads: 64, tps: 0.00, reads: 0.00, writes: 39148.82, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[1545s] threads: 64, tps: 0.00, reads: 0.00, writes: 42663.41, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[1546s] threads: 64, tps: 0.00, reads: 0.00, writes: 46115.06, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1547s] threads: 64, tps: 0.00, reads: 0.00, writes: 44888.93, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1548s] threads: 64, tps: 0.00, reads: 0.00, writes: 42939.01, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1549s] threads: 64, tps: 0.00, reads: 0.00, writes: 43099.03, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1550s] threads: 64, tps: 0.00, reads: 0.00, writes: 45975.03, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1551s] threads: 64, tps: 0.00, reads: 0.00, writes: 42515.96, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1552s] threads: 64, tps: 0.00, reads: 0.00, writes: 44136.01, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1553s] threads: 64, tps: 0.00, reads: 0.00, writes: 44177.02, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1554s] threads: 64, tps: 0.00, reads: 0.00, writes: 43255.99, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1555s] threads: 64, tps: 0.00, reads: 0.00, writes: 46342.01, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1556s] threads: 64, tps: 0.00, reads: 0.00, writes: 47615.98, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1557s] threads: 64, tps: 0.00, reads: 0.00, writes: 44473.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1558s] threads: 64, tps: 0.00, reads: 0.00, writes: 43110.01, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1559s] threads: 64, tps: 0.00, reads: 0.00, writes: 42800.82, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1560s] threads: 64, tps: 0.00, reads: 0.00, writes: 48237.93, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1561s] threads: 64, tps: 0.00, reads: 0.00, writes: 47205.31, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1562s] threads: 64, tps: 0.00, reads: 0.00, writes: 45965.71, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1563s] threads: 64, tps: 0.00, reads: 0.00, writes: 43800.26, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1564s] threads: 64, tps: 0.00, reads: 0.00, writes: 42000.99, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1565s] threads: 64, tps: 0.00, reads: 0.00, writes: 47702.80, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1566s] threads: 64, tps: 0.00, reads: 0.00, writes: 45970.19, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1567s] threads: 64, tps: 0.00, reads: 0.00, writes: 27451.35, response time: 7.74ms (95%), errors: 0.00, reconnects:  0.00
[1568s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.06, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[1569s] threads: 64, tps: 0.00, reads: 0.00, writes: 3183.01, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[1570s] threads: 64, tps: 0.00, reads: 0.00, writes: 5907.99, response time: 20.85ms (95%), errors: 0.00, reconnects:  0.00
[1571s] threads: 64, tps: 0.00, reads: 0.00, writes: 45490.06, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1572s] threads: 64, tps: 0.00, reads: 0.00, writes: 45947.12, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1573s] threads: 64, tps: 0.00, reads: 0.00, writes: 48407.91, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1574s] threads: 64, tps: 0.00, reads: 0.00, writes: 44510.05, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1575s] threads: 64, tps: 0.00, reads: 0.00, writes: 38791.95, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[1576s] threads: 64, tps: 0.00, reads: 0.00, writes: 36192.06, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1577s] threads: 64, tps: 0.00, reads: 0.00, writes: 44282.98, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1578s] threads: 64, tps: 0.00, reads: 0.00, writes: 48319.03, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1579s] threads: 64, tps: 0.00, reads: 0.00, writes: 47442.95, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1580s] threads: 64, tps: 0.00, reads: 0.00, writes: 42324.00, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1581s] threads: 64, tps: 0.00, reads: 0.00, writes: 43112.98, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1582s] threads: 64, tps: 0.00, reads: 0.00, writes: 44260.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1583s] threads: 64, tps: 0.00, reads: 0.00, writes: 43218.96, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1584s] threads: 64, tps: 0.00, reads: 0.00, writes: 44887.10, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1585s] threads: 64, tps: 0.00, reads: 0.00, writes: 44284.93, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1586s] threads: 64, tps: 0.00, reads: 0.00, writes: 44184.01, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1587s] threads: 64, tps: 0.00, reads: 0.00, writes: 48296.02, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1588s] threads: 64, tps: 0.00, reads: 0.00, writes: 46998.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1589s] threads: 64, tps: 0.00, reads: 0.00, writes: 43696.01, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1590s] threads: 64, tps: 0.00, reads: 0.00, writes: 44014.01, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1591s] threads: 64, tps: 0.00, reads: 0.00, writes: 44674.01, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1592s] threads: 64, tps: 0.00, reads: 0.00, writes: 47540.90, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1593s] threads: 64, tps: 0.00, reads: 0.00, writes: 44531.60, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1594s] threads: 64, tps: 0.00, reads: 0.00, writes: 20673.58, response time: 20.02ms (95%), errors: 0.00, reconnects:  0.00
[1595s] threads: 64, tps: 0.00, reads: 0.00, writes: 3119.93, response time: 21.47ms (95%), errors: 0.00, reconnects:  0.00
[1596s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.08, response time: 21.30ms (95%), errors: 0.00, reconnects:  0.00
[1597s] threads: 64, tps: 0.00, reads: 0.00, writes: 3180.99, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[1598s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.01, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[1599s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.00, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[1600s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.00, response time: 21.15ms (95%), errors: 0.00, reconnects:  0.00
[1601s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.00, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1602s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.01, response time: 21.28ms (95%), errors: 0.00, reconnects:  0.00
[1603s] threads: 64, tps: 0.00, reads: 0.00, writes: 3146.94, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[1604s] threads: 64, tps: 0.00, reads: 0.00, writes: 3178.06, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[1605s] threads: 64, tps: 0.00, reads: 0.00, writes: 24439.07, response time: 19.70ms (95%), errors: 0.00, reconnects:  0.00
[1606s] threads: 64, tps: 0.00, reads: 0.00, writes: 45424.97, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1607s] threads: 64, tps: 0.00, reads: 0.00, writes: 48627.11, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1608s] threads: 64, tps: 0.00, reads: 0.00, writes: 46981.89, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1609s] threads: 64, tps: 0.00, reads: 0.00, writes: 44728.01, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1610s] threads: 64, tps: 0.00, reads: 0.00, writes: 41271.05, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1611s] threads: 64, tps: 0.00, reads: 0.00, writes: 46274.95, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1612s] threads: 64, tps: 0.00, reads: 0.00, writes: 44982.93, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1613s] threads: 64, tps: 0.00, reads: 0.00, writes: 39472.97, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1614s] threads: 64, tps: 0.00, reads: 0.00, writes: 36072.91, response time: 2.72ms (95%), errors: 0.00, reconnects:  0.00
[1615s] threads: 64, tps: 0.00, reads: 0.00, writes: 38790.09, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1616s] threads: 64, tps: 0.00, reads: 0.00, writes: 39212.05, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1617s] threads: 64, tps: 0.00, reads: 0.00, writes: 46891.98, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1618s] threads: 64, tps: 0.00, reads: 0.00, writes: 41489.04, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1619s] threads: 64, tps: 0.00, reads: 0.00, writes: 38165.11, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1620s] threads: 64, tps: 0.00, reads: 0.00, writes: 36817.82, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1621s] threads: 64, tps: 0.00, reads: 0.00, writes: 38836.62, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1622s] threads: 64, tps: 0.00, reads: 0.00, writes: 43475.67, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1623s] threads: 64, tps: 0.00, reads: 0.00, writes: 45540.99, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1624s] threads: 64, tps: 0.00, reads: 0.00, writes: 41503.03, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1625s] threads: 64, tps: 0.00, reads: 0.00, writes: 40398.04, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1626s] threads: 64, tps: 0.00, reads: 0.00, writes: 43122.99, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1627s] threads: 64, tps: 0.00, reads: 0.00, writes: 48577.94, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[1628s] threads: 64, tps: 0.00, reads: 0.00, writes: 47263.94, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1629s] threads: 64, tps: 0.00, reads: 0.00, writes: 45359.09, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1630s] threads: 64, tps: 0.00, reads: 0.00, writes: 43089.78, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1631s] threads: 64, tps: 0.00, reads: 0.00, writes: 46985.23, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1632s] threads: 64, tps: 0.00, reads: 0.00, writes: 47883.03, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1633s] threads: 64, tps: 0.00, reads: 0.00, writes: 45761.95, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1634s] threads: 64, tps: 0.00, reads: 0.00, writes: 4639.87, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[1635s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.99, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1636s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.02, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[1637s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.03, response time: 21.23ms (95%), errors: 0.00, reconnects:  0.00
[1638s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.05, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[1639s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.92, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[1640s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.07, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[1641s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.01, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[1642s] threads: 64, tps: 0.00, reads: 0.00, writes: 23335.02, response time: 19.75ms (95%), errors: 0.00, reconnects:  0.00
[1643s] threads: 64, tps: 0.00, reads: 0.00, writes: 36177.99, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1644s] threads: 64, tps: 0.00, reads: 0.00, writes: 47743.01, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1645s] threads: 64, tps: 0.00, reads: 0.00, writes: 46333.04, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1646s] threads: 64, tps: 0.00, reads: 0.00, writes: 47436.91, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1647s] threads: 64, tps: 0.00, reads: 0.00, writes: 44751.12, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1648s] threads: 64, tps: 0.00, reads: 0.00, writes: 45619.91, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1649s] threads: 64, tps: 0.00, reads: 0.00, writes: 47271.00, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1650s] threads: 64, tps: 0.00, reads: 0.00, writes: 45135.96, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1651s] threads: 64, tps: 0.00, reads: 0.00, writes: 45440.12, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1652s] threads: 64, tps: 0.00, reads: 0.00, writes: 42291.94, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1653s] threads: 64, tps: 0.00, reads: 0.00, writes: 47488.06, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1654s] threads: 64, tps: 0.00, reads: 0.00, writes: 46120.97, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1655s] threads: 64, tps: 0.00, reads: 0.00, writes: 46678.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1656s] threads: 64, tps: 0.00, reads: 0.00, writes: 42093.00, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[1657s] threads: 64, tps: 0.00, reads: 0.00, writes: 42872.05, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1658s] threads: 64, tps: 0.00, reads: 0.00, writes: 46103.02, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1659s] threads: 64, tps: 0.00, reads: 0.00, writes: 43397.96, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1660s] threads: 64, tps: 0.00, reads: 0.00, writes: 39531.02, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1661s] threads: 64, tps: 0.00, reads: 0.00, writes: 38904.97, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1662s] threads: 64, tps: 0.00, reads: 0.00, writes: 37380.06, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1663s] threads: 64, tps: 0.00, reads: 0.00, writes: 45705.95, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1664s] threads: 64, tps: 0.00, reads: 0.00, writes: 41791.97, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1665s] threads: 64, tps: 0.00, reads: 0.00, writes: 36522.43, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1666s] threads: 64, tps: 0.00, reads: 0.00, writes: 38214.66, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1667s] threads: 64, tps: 0.00, reads: 0.00, writes: 36029.98, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1668s] threads: 64, tps: 0.00, reads: 0.00, writes: 41298.00, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1669s] threads: 64, tps: 0.00, reads: 0.00, writes: 46218.97, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1670s] threads: 64, tps: 0.00, reads: 0.00, writes: 40838.04, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1671s] threads: 64, tps: 0.00, reads: 0.00, writes: 43616.28, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1672s] threads: 64, tps: 0.00, reads: 0.00, writes: 43489.72, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1673s] threads: 64, tps: 0.00, reads: 0.00, writes: 47805.94, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1674s] threads: 64, tps: 0.00, reads: 0.00, writes: 47876.98, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1675s] threads: 64, tps: 0.00, reads: 0.00, writes: 44149.07, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1676s] threads: 64, tps: 0.00, reads: 0.00, writes: 7327.95, response time: 20.90ms (95%), errors: 0.00, reconnects:  0.00
[1677s] threads: 64, tps: 0.00, reads: 0.00, writes: 3180.01, response time: 21.20ms (95%), errors: 0.00, reconnects:  0.00
[1678s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.93, response time: 21.32ms (95%), errors: 0.00, reconnects:  0.00
[1679s] threads: 64, tps: 0.00, reads: 0.00, writes: 3173.06, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1680s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.01, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[1681s] threads: 64, tps: 0.00, reads: 0.00, writes: 3140.01, response time: 21.32ms (95%), errors: 0.00, reconnects:  0.00
[1682s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.99, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[1683s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.93, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[1684s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.04, response time: 21.53ms (95%), errors: 0.00, reconnects:  0.00
[1685s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.02, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1686s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.00, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1687s] threads: 64, tps: 0.00, reads: 0.00, writes: 3144.00, response time: 21.24ms (95%), errors: 0.00, reconnects:  0.00
[1688s] threads: 64, tps: 0.00, reads: 0.00, writes: 3140.00, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[1689s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.01, response time: 20.87ms (95%), errors: 0.00, reconnects:  0.00
[1690s] threads: 64, tps: 0.00, reads: 0.00, writes: 7230.98, response time: 20.80ms (95%), errors: 0.00, reconnects:  0.00
[1691s] threads: 64, tps: 0.00, reads: 0.00, writes: 45052.71, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1692s] threads: 64, tps: 0.00, reads: 0.00, writes: 47499.54, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1693s] threads: 64, tps: 0.00, reads: 0.00, writes: 46634.03, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1694s] threads: 64, tps: 0.00, reads: 0.00, writes: 43094.94, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1695s] threads: 64, tps: 0.00, reads: 0.00, writes: 40821.00, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1696s] threads: 64, tps: 0.00, reads: 0.00, writes: 39695.89, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1697s] threads: 64, tps: 0.00, reads: 0.00, writes: 46322.20, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1698s] threads: 64, tps: 0.00, reads: 0.00, writes: 39131.69, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[1699s] threads: 64, tps: 0.00, reads: 0.00, writes: 36693.20, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[1700s] threads: 64, tps: 0.00, reads: 0.00, writes: 37235.09, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1701s] threads: 64, tps: 0.00, reads: 0.00, writes: 38490.94, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[1702s] threads: 64, tps: 0.00, reads: 0.00, writes: 43322.84, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1703s] threads: 64, tps: 0.00, reads: 0.00, writes: 41683.13, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1704s] threads: 64, tps: 0.00, reads: 0.00, writes: 40010.97, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1705s] threads: 64, tps: 0.00, reads: 0.00, writes: 44946.03, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1706s] threads: 64, tps: 0.00, reads: 0.00, writes: 44835.09, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1707s] threads: 64, tps: 0.00, reads: 0.00, writes: 48241.97, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1708s] threads: 64, tps: 0.00, reads: 0.00, writes: 46110.03, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1709s] threads: 64, tps: 0.00, reads: 0.00, writes: 44009.98, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1710s] threads: 64, tps: 0.00, reads: 0.00, writes: 44348.80, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1711s] threads: 64, tps: 0.00, reads: 0.00, writes: 46971.21, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1712s] threads: 64, tps: 0.00, reads: 0.00, writes: 46003.99, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1713s] threads: 64, tps: 0.00, reads: 0.00, writes: 45892.00, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1714s] threads: 64, tps: 0.00, reads: 0.00, writes: 38306.00, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[1715s] threads: 64, tps: 0.00, reads: 0.00, writes: 36408.02, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1716s] threads: 64, tps: 0.00, reads: 0.00, writes: 40251.98, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1717s] threads: 64, tps: 0.00, reads: 0.00, writes: 45806.98, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1718s] threads: 64, tps: 0.00, reads: 0.00, writes: 37810.04, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1719s] threads: 64, tps: 0.00, reads: 0.00, writes: 38291.23, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[1720s] threads: 64, tps: 0.00, reads: 0.00, writes: 36886.49, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1721s] threads: 64, tps: 0.00, reads: 0.00, writes: 35871.53, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[1722s] threads: 64, tps: 0.00, reads: 0.00, writes: 46681.15, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1723s] threads: 64, tps: 0.00, reads: 0.00, writes: 40070.17, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1724s] threads: 64, tps: 0.00, reads: 0.00, writes: 38308.07, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1725s] threads: 64, tps: 0.00, reads: 0.00, writes: 43520.77, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1726s] threads: 64, tps: 0.00, reads: 0.00, writes: 44652.02, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1727s] threads: 64, tps: 0.00, reads: 0.00, writes: 49114.96, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[1728s] threads: 64, tps: 0.00, reads: 0.00, writes: 47426.19, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1729s] threads: 64, tps: 0.00, reads: 0.00, writes: 43886.02, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1730s] threads: 64, tps: 0.00, reads: 0.00, writes: 41242.99, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1731s] threads: 64, tps: 0.00, reads: 0.00, writes: 44159.81, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1732s] threads: 64, tps: 0.00, reads: 0.00, writes: 49127.26, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1733s] threads: 64, tps: 0.00, reads: 0.00, writes: 46193.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1734s] threads: 64, tps: 0.00, reads: 0.00, writes: 18469.01, response time: 20.40ms (95%), errors: 0.00, reconnects:  0.00
[1735s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.99, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[1736s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.98, response time: 21.36ms (95%), errors: 0.00, reconnects:  0.00
[1737s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.02, response time: 21.29ms (95%), errors: 0.00, reconnects:  0.00
[1738s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.99, response time: 21.26ms (95%), errors: 0.00, reconnects:  0.00
[1739s] threads: 64, tps: 0.00, reads: 0.00, writes: 3142.00, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[1740s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[1741s] threads: 64, tps: 0.00, reads: 0.00, writes: 3173.01, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1742s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.94, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1743s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.03, response time: 20.88ms (95%), errors: 0.00, reconnects:  0.00
[1744s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.99, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[1745s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.99, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[1746s] threads: 64, tps: 0.00, reads: 0.00, writes: 43780.64, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1747s] threads: 64, tps: 0.00, reads: 0.00, writes: 48771.02, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1748s] threads: 64, tps: 0.00, reads: 0.00, writes: 47292.16, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1749s] threads: 64, tps: 0.00, reads: 0.00, writes: 45698.03, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1749s] threads: 64, tps: 0.00, reads: 0.00, writes: 37603.91, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[1751s] threads: 64, tps: 0.00, reads: 0.00, writes: 41159.28, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[1752s] threads: 64, tps: 0.00, reads: 0.00, writes: 47192.24, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1753s] threads: 64, tps: 0.00, reads: 0.00, writes: 38325.81, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1754s] threads: 64, tps: 0.00, reads: 0.00, writes: 37742.19, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1755s] threads: 64, tps: 0.00, reads: 0.00, writes: 37605.96, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1756s] threads: 64, tps: 0.00, reads: 0.00, writes: 36775.97, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1757s] threads: 64, tps: 0.00, reads: 0.00, writes: 45257.07, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1758s] threads: 64, tps: 0.00, reads: 0.00, writes: 43316.94, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1759s] threads: 64, tps: 0.00, reads: 0.00, writes: 37550.06, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1760s] threads: 64, tps: 0.00, reads: 0.00, writes: 39156.98, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1761s] threads: 64, tps: 0.00, reads: 0.00, writes: 38727.97, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[1762s] threads: 64, tps: 0.00, reads: 0.00, writes: 43530.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[1763s] threads: 64, tps: 0.00, reads: 0.00, writes: 45576.06, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1764s] threads: 64, tps: 0.00, reads: 0.00, writes: 35762.94, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1765s] threads: 64, tps: 0.00, reads: 0.00, writes: 38104.07, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[1766s] threads: 64, tps: 0.00, reads: 0.00, writes: 36929.92, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1767s] threads: 64, tps: 0.00, reads: 0.00, writes: 36752.02, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[1768s] threads: 64, tps: 0.00, reads: 0.00, writes: 47473.04, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1769s] threads: 64, tps: 0.00, reads: 0.00, writes: 39684.97, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1770s] threads: 64, tps: 0.00, reads: 0.00, writes: 38287.03, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1771s] threads: 64, tps: 0.00, reads: 0.00, writes: 43764.96, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[1772s] threads: 64, tps: 0.00, reads: 0.00, writes: 38839.99, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[1773s] threads: 64, tps: 0.00, reads: 0.00, writes: 49727.03, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1774s] threads: 64, tps: 0.00, reads: 0.00, writes: 46426.95, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1775s] threads: 64, tps: 0.00, reads: 0.00, writes: 45890.01, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1776s] threads: 64, tps: 0.00, reads: 0.00, writes: 42901.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1777s] threads: 64, tps: 0.00, reads: 0.00, writes: 43971.02, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1778s] threads: 64, tps: 0.00, reads: 0.00, writes: 45528.03, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1779s] threads: 64, tps: 0.00, reads: 0.00, writes: 44047.92, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1780s] threads: 64, tps: 0.00, reads: 0.00, writes: 42290.05, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1781s] threads: 64, tps: 0.00, reads: 0.00, writes: 42138.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1782s] threads: 64, tps: 0.00, reads: 0.00, writes: 45876.04, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1783s] threads: 64, tps: 0.00, reads: 0.00, writes: 45959.96, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1784s] threads: 64, tps: 0.00, reads: 0.00, writes: 39775.56, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1785s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.03, response time: 21.33ms (95%), errors: 0.00, reconnects:  0.00
[1786s] threads: 64, tps: 0.00, reads: 0.00, writes: 3176.08, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[1787s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.00, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[1788s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.94, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[1789s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.04, response time: 21.26ms (95%), errors: 0.00, reconnects:  0.00
[1790s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.02, response time: 20.93ms (95%), errors: 0.00, reconnects:  0.00
[1791s] threads: 64, tps: 0.00, reads: 0.00, writes: 25873.03, response time: 19.40ms (95%), errors: 0.00, reconnects:  0.00
[1792s] threads: 64, tps: 0.00, reads: 0.00, writes: 42420.11, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1793s] threads: 64, tps: 0.00, reads: 0.00, writes: 46527.96, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1794s] threads: 64, tps: 0.00, reads: 0.00, writes: 46561.83, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1795s] threads: 64, tps: 0.00, reads: 0.00, writes: 42389.21, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1796s] threads: 64, tps: 0.00, reads: 0.00, writes: 43936.01, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1797s] threads: 64, tps: 0.00, reads: 0.00, writes: 41831.31, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1798s] threads: 64, tps: 0.00, reads: 0.00, writes: 46855.98, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1799s] threads: 64, tps: 0.00, reads: 0.00, writes: 41317.02, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1800s] threads: 64, tps: 0.00, reads: 0.00, writes: 38666.77, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1801s] threads: 64, tps: 0.00, reads: 0.00, writes: 37646.45, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[1802s] threads: 64, tps: 0.00, reads: 0.00, writes: 36976.59, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[1803s] threads: 64, tps: 0.00, reads: 0.00, writes: 43285.66, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1804s] threads: 64, tps: 0.00, reads: 0.00, writes: 41666.32, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[1805s] threads: 64, tps: 0.00, reads: 0.00, writes: 34714.10, response time: 2.84ms (95%), errors: 0.00, reconnects:  0.00
[1806s] threads: 64, tps: 0.00, reads: 0.00, writes: 38249.88, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[1807s] threads: 64, tps: 0.00, reads: 0.00, writes: 40830.13, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1808s] threads: 64, tps: 0.00, reads: 0.00, writes: 45309.01, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1809s] threads: 64, tps: 0.00, reads: 0.00, writes: 47320.99, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1810s] threads: 64, tps: 0.00, reads: 0.00, writes: 46364.85, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1811s] threads: 64, tps: 0.00, reads: 0.00, writes: 45506.29, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1812s] threads: 64, tps: 0.00, reads: 0.00, writes: 43676.09, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1813s] threads: 64, tps: 0.00, reads: 0.00, writes: 48150.90, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[1814s] threads: 64, tps: 0.00, reads: 0.00, writes: 46491.11, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1815s] threads: 64, tps: 0.00, reads: 0.00, writes: 43105.97, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1816s] threads: 64, tps: 0.00, reads: 0.00, writes: 43945.99, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1817s] threads: 64, tps: 0.00, reads: 0.00, writes: 42800.92, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1818s] threads: 64, tps: 0.00, reads: 0.00, writes: 48868.14, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[1819s] threads: 64, tps: 0.00, reads: 0.00, writes: 46477.91, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1820s] threads: 64, tps: 0.00, reads: 0.00, writes: 43131.04, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1821s] threads: 64, tps: 0.00, reads: 0.00, writes: 42536.04, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1822s] threads: 64, tps: 0.00, reads: 0.00, writes: 44992.94, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1823s] threads: 64, tps: 0.00, reads: 0.00, writes: 48419.93, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1824s] threads: 64, tps: 0.00, reads: 0.00, writes: 45276.07, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[1825s] threads: 64, tps: 0.00, reads: 0.00, writes: 21228.45, response time: 20.07ms (95%), errors: 0.00, reconnects:  0.00
[1826s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.08, response time: 21.42ms (95%), errors: 0.00, reconnects:  0.00
[1827s] threads: 64, tps: 0.00, reads: 0.00, writes: 25871.91, response time: 19.40ms (95%), errors: 0.00, reconnects:  0.00
[1828s] threads: 64, tps: 0.00, reads: 0.00, writes: 42466.85, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1829s] threads: 64, tps: 0.00, reads: 0.00, writes: 46860.05, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1830s] threads: 64, tps: 0.00, reads: 0.00, writes: 46138.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1831s] threads: 64, tps: 0.00, reads: 0.00, writes: 44003.99, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1832s] threads: 64, tps: 0.00, reads: 0.00, writes: 44963.01, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1833s] threads: 64, tps: 0.00, reads: 0.00, writes: 37317.96, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1834s] threads: 64, tps: 0.00, reads: 0.00, writes: 47127.07, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1835s] threads: 64, tps: 0.00, reads: 0.00, writes: 40495.99, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[1836s] threads: 64, tps: 0.00, reads: 0.00, writes: 45139.05, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1837s] threads: 64, tps: 0.00, reads: 0.00, writes: 43102.75, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1838s] threads: 64, tps: 0.00, reads: 0.00, writes: 40492.03, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[1839s] threads: 64, tps: 0.00, reads: 0.00, writes: 48734.07, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1840s] threads: 64, tps: 0.00, reads: 0.00, writes: 43079.97, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1841s] threads: 64, tps: 0.00, reads: 0.00, writes: 42668.75, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1842s] threads: 64, tps: 0.00, reads: 0.00, writes: 42053.29, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1843s] threads: 64, tps: 0.00, reads: 0.00, writes: 44350.92, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1844s] threads: 64, tps: 0.00, reads: 0.00, writes: 47395.06, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[1845s] threads: 64, tps: 0.00, reads: 0.00, writes: 47680.96, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[1846s] threads: 64, tps: 0.00, reads: 0.00, writes: 42473.00, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1847s] threads: 64, tps: 0.00, reads: 0.00, writes: 36630.96, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[1848s] threads: 64, tps: 0.00, reads: 0.00, writes: 39141.00, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[1849s] threads: 64, tps: 0.00, reads: 0.00, writes: 47104.98, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1850s] threads: 64, tps: 0.00, reads: 0.00, writes: 39892.04, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1851s] threads: 64, tps: 0.00, reads: 0.00, writes: 43937.00, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1852s] threads: 64, tps: 0.00, reads: 0.00, writes: 42536.01, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[1853s] threads: 64, tps: 0.00, reads: 0.00, writes: 44539.99, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1854s] threads: 64, tps: 0.00, reads: 0.00, writes: 47816.08, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[1855s] threads: 64, tps: 0.00, reads: 0.00, writes: 45089.95, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[1856s] threads: 64, tps: 0.00, reads: 0.00, writes: 18294.92, response time: 20.14ms (95%), errors: 0.00, reconnects:  0.00
[1857s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.99, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1858s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.92, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1859s] threads: 64, tps: 0.00, reads: 0.00, writes: 3174.03, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[1860s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.05, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[1861s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.00, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[1862s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.97, response time: 21.22ms (95%), errors: 0.00, reconnects:  0.00
[1863s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.03, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[1864s] threads: 64, tps: 0.00, reads: 0.00, writes: 3141.97, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[1865s] threads: 64, tps: 0.00, reads: 0.00, writes: 3176.05, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[1866s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.97, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[1867s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.04, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[1868s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.90, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1869s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.11, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[1870s] threads: 64, tps: 0.00, reads: 0.00, writes: 3173.00, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1871s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.00, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[1872s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.99, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[1873s] threads: 64, tps: 0.00, reads: 0.00, writes: 7611.00, response time: 20.74ms (95%), errors: 0.00, reconnects:  0.00
[1874s] threads: 64, tps: 0.00, reads: 0.00, writes: 45688.20, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1875s] threads: 64, tps: 0.00, reads: 0.00, writes: 46592.93, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1876s] threads: 64, tps: 0.00, reads: 0.00, writes: 44728.05, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1877s] threads: 64, tps: 0.00, reads: 0.00, writes: 43296.01, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[1878s] threads: 64, tps: 0.00, reads: 0.00, writes: 38907.97, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1879s] threads: 64, tps: 0.00, reads: 0.00, writes: 42305.98, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[1880s] threads: 64, tps: 0.00, reads: 0.00, writes: 44339.81, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1881s] threads: 64, tps: 0.00, reads: 0.00, writes: 37784.15, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[1882s] threads: 64, tps: 0.00, reads: 0.00, writes: 38162.03, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1883s] threads: 64, tps: 0.00, reads: 0.00, writes: 37930.98, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[1884s] threads: 64, tps: 0.00, reads: 0.00, writes: 40085.02, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[1885s] threads: 64, tps: 0.00, reads: 0.00, writes: 45982.13, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1886s] threads: 64, tps: 0.00, reads: 0.00, writes: 40076.93, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[1887s] threads: 64, tps: 0.00, reads: 0.00, writes: 43033.02, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1888s] threads: 64, tps: 0.00, reads: 0.00, writes: 44863.90, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1889s] threads: 64, tps: 0.00, reads: 0.00, writes: 46882.04, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1890s] threads: 64, tps: 0.00, reads: 0.00, writes: 47388.03, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1891s] threads: 64, tps: 0.00, reads: 0.00, writes: 37655.85, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1892s] threads: 64, tps: 0.00, reads: 0.00, writes: 40635.15, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[1893s] threads: 64, tps: 0.00, reads: 0.00, writes: 42290.97, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1894s] threads: 64, tps: 0.00, reads: 0.00, writes: 46140.03, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[1895s] threads: 64, tps: 0.00, reads: 0.00, writes: 47438.99, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[1896s] threads: 64, tps: 0.00, reads: 0.00, writes: 45803.96, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[1897s] threads: 64, tps: 0.00, reads: 0.00, writes: 43188.03, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[1898s] threads: 64, tps: 0.00, reads: 0.00, writes: 43977.98, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[1899s] threads: 64, tps: 0.00, reads: 0.00, writes: 46223.03, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[1900s] threads: 64, tps: 0.00, reads: 0.00, writes: 43029.98, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[1901s] threads: 64, tps: 0.00, reads: 0.00, writes: 42936.04, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1902s] threads: 64, tps: 0.00, reads: 0.00, writes: 43705.02, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1903s] threads: 64, tps: 0.00, reads: 0.00, writes: 43302.89, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1904s] threads: 64, tps: 0.00, reads: 0.00, writes: 47593.89, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1905s] threads: 64, tps: 0.00, reads: 0.00, writes: 47197.11, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1906s] threads: 64, tps: 0.00, reads: 0.00, writes: 44642.07, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1907s] threads: 64, tps: 0.00, reads: 0.00, writes: 44088.99, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1908s] threads: 64, tps: 0.00, reads: 0.00, writes: 45549.97, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1909s] threads: 64, tps: 0.00, reads: 0.00, writes: 45250.02, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[1910s] threads: 64, tps: 0.00, reads: 0.00, writes: 39810.98, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[1911s] threads: 64, tps: 0.00, reads: 0.00, writes: 43736.02, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1912s] threads: 64, tps: 0.00, reads: 0.00, writes: 34900.98, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[1913s] threads: 64, tps: 0.00, reads: 0.00, writes: 39630.96, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[1914s] threads: 64, tps: 0.00, reads: 0.00, writes: 46476.08, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[1915s] threads: 64, tps: 0.00, reads: 0.00, writes: 37040.01, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[1916s] threads: 64, tps: 0.00, reads: 0.00, writes: 37693.01, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[1917s] threads: 64, tps: 0.00, reads: 0.00, writes: 37222.99, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1918s] threads: 64, tps: 0.00, reads: 0.00, writes: 41589.02, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[1919s] threads: 64, tps: 0.00, reads: 0.00, writes: 47563.00, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1920s] threads: 64, tps: 0.00, reads: 0.00, writes: 45697.96, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[1921s] threads: 64, tps: 0.00, reads: 0.00, writes: 42276.98, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1922s] threads: 64, tps: 0.00, reads: 0.00, writes: 42833.62, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1923s] threads: 64, tps: 0.00, reads: 0.00, writes: 42789.41, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1924s] threads: 64, tps: 0.00, reads: 0.00, writes: 47874.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1925s] threads: 64, tps: 0.00, reads: 0.00, writes: 46477.02, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[1926s] threads: 64, tps: 0.00, reads: 0.00, writes: 42927.00, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[1927s] threads: 64, tps: 0.00, reads: 0.00, writes: 42036.99, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1928s] threads: 64, tps: 0.00, reads: 0.00, writes: 45033.95, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1929s] threads: 64, tps: 0.00, reads: 0.00, writes: 48057.04, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1930s] threads: 64, tps: 0.00, reads: 0.00, writes: 45656.03, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1931s] threads: 64, tps: 0.00, reads: 0.00, writes: 43495.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[1932s] threads: 64, tps: 0.00, reads: 0.00, writes: 42073.01, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[1933s] threads: 64, tps: 0.00, reads: 0.00, writes: 46482.03, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1934s] threads: 64, tps: 0.00, reads: 0.00, writes: 45510.95, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1935s] threads: 64, tps: 0.00, reads: 0.00, writes: 44754.92, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1936s] threads: 64, tps: 0.00, reads: 0.00, writes: 43775.01, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[1937s] threads: 64, tps: 0.00, reads: 0.00, writes: 41349.05, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[1938s] threads: 64, tps: 0.00, reads: 0.00, writes: 46270.06, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1939s] threads: 64, tps: 0.00, reads: 0.00, writes: 46278.89, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1940s] threads: 64, tps: 0.00, reads: 0.00, writes: 13877.89, response time: 20.45ms (95%), errors: 0.00, reconnects:  0.00
[1941s] threads: 64, tps: 0.00, reads: 0.00, writes: 7052.06, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[1942s] threads: 64, tps: 0.00, reads: 0.00, writes: 44406.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[1943s] threads: 64, tps: 0.00, reads: 0.00, writes: 43920.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1944s] threads: 64, tps: 0.00, reads: 0.00, writes: 46469.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[1945s] threads: 64, tps: 0.00, reads: 0.00, writes: 40648.83, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[1946s] threads: 64, tps: 0.00, reads: 0.00, writes: 42799.27, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1947s] threads: 64, tps: 0.00, reads: 0.00, writes: 43486.94, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1948s] threads: 64, tps: 0.00, reads: 0.00, writes: 41180.02, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[1949s] threads: 64, tps: 0.00, reads: 0.00, writes: 43568.00, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[1950s] threads: 64, tps: 0.00, reads: 0.00, writes: 43722.97, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[1951s] threads: 64, tps: 0.00, reads: 0.00, writes: 38277.03, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[1952s] threads: 64, tps: 0.00, reads: 0.00, writes: 37316.00, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[1953s] threads: 64, tps: 0.00, reads: 0.00, writes: 36852.95, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1954s] threads: 64, tps: 0.00, reads: 0.00, writes: 40936.09, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[1955s] threads: 64, tps: 0.00, reads: 0.00, writes: 45813.95, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[1956s] threads: 64, tps: 0.00, reads: 0.00, writes: 36597.94, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[1957s] threads: 64, tps: 0.00, reads: 0.00, writes: 37360.03, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[1958s] threads: 64, tps: 0.00, reads: 0.00, writes: 36739.02, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1959s] threads: 64, tps: 0.00, reads: 0.00, writes: 36266.96, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[1960s] threads: 64, tps: 0.00, reads: 0.00, writes: 47038.12, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[1961s] threads: 64, tps: 0.00, reads: 0.00, writes: 42828.90, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[1962s] threads: 64, tps: 0.00, reads: 0.00, writes: 44091.07, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[1963s] threads: 64, tps: 0.00, reads: 0.00, writes: 43492.03, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[1964s] threads: 64, tps: 0.00, reads: 0.00, writes: 44123.69, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1965s] threads: 64, tps: 0.00, reads: 0.00, writes: 48589.30, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[1966s] threads: 64, tps: 0.00, reads: 0.00, writes: 44447.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[1967s] threads: 64, tps: 0.00, reads: 0.00, writes: 20812.96, response time: 20.05ms (95%), errors: 0.00, reconnects:  0.00
[1968s] threads: 64, tps: 0.00, reads: 0.00, writes: 3143.92, response time: 21.20ms (95%), errors: 0.00, reconnects:  0.00
[1969s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.00, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[1970s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.02, response time: 20.98ms (95%), errors: 0.00, reconnects:  0.00
[1971s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.00, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[1972s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.94, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[1973s] threads: 64, tps: 0.00, reads: 0.00, writes: 3179.10, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1974s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.92, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[1975s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.00, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[1976s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.99, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[1977s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.01, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[1978s] threads: 64, tps: 0.00, reads: 0.00, writes: 3174.00, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[1979s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.02, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[1980s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.01, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[1981s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.08, response time: 21.33ms (95%), errors: 0.00, reconnects:  0.00
[1982s] threads: 64, tps: 0.00, reads: 0.00, writes: 23979.00, response time: 20.02ms (95%), errors: 0.00, reconnects:  0.00
[1983s] threads: 64, tps: 0.00, reads: 0.00, writes: 47285.97, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[1984s] threads: 64, tps: 0.00, reads: 0.00, writes: 47535.08, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[1985s] threads: 64, tps: 0.00, reads: 0.00, writes: 44213.95, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1986s] threads: 64, tps: 0.00, reads: 0.00, writes: 39109.04, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[1987s] threads: 64, tps: 0.00, reads: 0.00, writes: 42537.95, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[1988s] threads: 64, tps: 0.00, reads: 0.00, writes: 45463.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[1989s] threads: 64, tps: 0.00, reads: 0.00, writes: 46119.01, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[1990s] threads: 64, tps: 0.00, reads: 0.00, writes: 44518.01, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[1991s] threads: 64, tps: 0.00, reads: 0.00, writes: 42671.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[1992s] threads: 64, tps: 0.00, reads: 0.00, writes: 43214.96, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[1993s] threads: 64, tps: 0.00, reads: 0.00, writes: 45241.96, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[1994s] threads: 64, tps: 0.00, reads: 0.00, writes: 42068.01, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[1995s] threads: 64, tps: 0.00, reads: 0.00, writes: 39508.07, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[1996s] threads: 64, tps: 0.00, reads: 0.00, writes: 37579.00, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[1997s] threads: 64, tps: 0.00, reads: 0.00, writes: 37017.51, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[1998s] threads: 64, tps: 0.00, reads: 0.00, writes: 44980.40, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[1999s] threads: 64, tps: 0.00, reads: 0.00, writes: 45770.17, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2000s] threads: 64, tps: 0.00, reads: 0.00, writes: 37348.98, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2001s] threads: 64, tps: 0.00, reads: 0.00, writes: 38939.98, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2002s] threads: 64, tps: 0.00, reads: 0.00, writes: 42526.05, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2003s] threads: 64, tps: 0.00, reads: 0.00, writes: 47549.00, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2004s] threads: 64, tps: 0.00, reads: 0.00, writes: 47319.98, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2005s] threads: 64, tps: 0.00, reads: 0.00, writes: 45059.00, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2006s] threads: 64, tps: 0.00, reads: 0.00, writes: 43007.02, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2007s] threads: 64, tps: 0.00, reads: 0.00, writes: 44110.98, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2008s] threads: 64, tps: 0.00, reads: 0.00, writes: 48065.93, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2009s] threads: 64, tps: 0.00, reads: 0.00, writes: 46944.07, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[2010s] threads: 64, tps: 0.00, reads: 0.00, writes: 43803.95, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2011s] threads: 64, tps: 0.00, reads: 0.00, writes: 43295.03, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2012s] threads: 64, tps: 0.00, reads: 0.00, writes: 44413.98, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2013s] threads: 64, tps: 0.00, reads: 0.00, writes: 46881.03, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2014s] threads: 64, tps: 0.00, reads: 0.00, writes: 46569.94, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2015s] threads: 64, tps: 0.00, reads: 0.00, writes: 42393.04, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2016s] threads: 64, tps: 0.00, reads: 0.00, writes: 42091.03, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2017s] threads: 64, tps: 0.00, reads: 0.00, writes: 43152.98, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2018s] threads: 64, tps: 0.00, reads: 0.00, writes: 47486.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2019s] threads: 64, tps: 0.00, reads: 0.00, writes: 42077.97, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2020s] threads: 64, tps: 0.00, reads: 0.00, writes: 39009.07, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2021s] threads: 64, tps: 0.00, reads: 0.00, writes: 33434.96, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[2022s] threads: 64, tps: 0.00, reads: 0.00, writes: 44507.05, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2023s] threads: 64, tps: 0.00, reads: 0.00, writes: 46938.96, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2024s] threads: 64, tps: 0.00, reads: 0.00, writes: 42892.03, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2025s] threads: 64, tps: 0.00, reads: 0.00, writes: 41276.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2026s] threads: 64, tps: 0.00, reads: 0.00, writes: 43692.94, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2027s] threads: 64, tps: 0.00, reads: 0.00, writes: 46848.01, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2028s] threads: 64, tps: 0.00, reads: 0.00, writes: 45939.01, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2029s] threads: 64, tps: 0.00, reads: 0.00, writes: 39420.99, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2030s] threads: 64, tps: 0.00, reads: 0.00, writes: 37091.03, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2031s] threads: 64, tps: 0.00, reads: 0.00, writes: 36373.98, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2032s] threads: 64, tps: 0.00, reads: 0.00, writes: 38708.69, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2033s] threads: 64, tps: 0.00, reads: 0.00, writes: 46957.61, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2034s] threads: 64, tps: 0.00, reads: 0.00, writes: 38695.99, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2035s] threads: 64, tps: 0.00, reads: 0.00, writes: 42501.01, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2036s] threads: 64, tps: 0.00, reads: 0.00, writes: 43867.81, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2037s] threads: 64, tps: 0.00, reads: 0.00, writes: 45581.20, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2038s] threads: 64, tps: 0.00, reads: 0.00, writes: 47610.89, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2039s] threads: 64, tps: 0.00, reads: 0.00, writes: 46029.06, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2040s] threads: 64, tps: 0.00, reads: 0.00, writes: 38503.98, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2041s] threads: 64, tps: 0.00, reads: 0.00, writes: 37191.98, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2042s] threads: 64, tps: 0.00, reads: 0.00, writes: 38524.14, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2043s] threads: 64, tps: 0.00, reads: 0.00, writes: 48066.12, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2044s] threads: 64, tps: 0.00, reads: 0.00, writes: 40833.88, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2045s] threads: 64, tps: 0.00, reads: 0.00, writes: 35884.09, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2046s] threads: 64, tps: 0.00, reads: 0.00, writes: 44449.97, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2047s] threads: 64, tps: 0.00, reads: 0.00, writes: 46025.99, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2048s] threads: 64, tps: 0.00, reads: 0.00, writes: 47245.98, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2049s] threads: 64, tps: 0.00, reads: 0.00, writes: 47491.94, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2050s] threads: 64, tps: 0.00, reads: 0.00, writes: 16680.96, response time: 20.37ms (95%), errors: 0.00, reconnects:  0.00
[2051s] threads: 64, tps: 0.00, reads: 0.00, writes: 3139.91, response time: 21.00ms (95%), errors: 0.00, reconnects:  0.00
[2052s] threads: 64, tps: 0.00, reads: 0.00, writes: 3176.03, response time: 21.17ms (95%), errors: 0.00, reconnects:  0.00
[2053s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.97, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[2054s] threads: 64, tps: 0.00, reads: 0.00, writes: 3174.02, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[2055s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.99, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[2056s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.00, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[2057s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.02, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[2058s] threads: 64, tps: 0.00, reads: 0.00, writes: 3178.06, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[2059s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.01, response time: 21.17ms (95%), errors: 0.00, reconnects:  0.00
[2060s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.00, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[2061s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.93, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[2062s] threads: 64, tps: 0.00, reads: 0.00, writes: 39994.12, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2063s] threads: 64, tps: 0.00, reads: 0.00, writes: 47015.39, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2064s] threads: 64, tps: 0.00, reads: 0.00, writes: 45686.58, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2065s] threads: 64, tps: 0.00, reads: 0.00, writes: 41896.93, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2066s] threads: 64, tps: 0.00, reads: 0.00, writes: 35775.07, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2067s] threads: 64, tps: 0.00, reads: 0.00, writes: 38463.99, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2068s] threads: 64, tps: 0.00, reads: 0.00, writes: 44233.00, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2069s] threads: 64, tps: 0.00, reads: 0.00, writes: 43181.95, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2070s] threads: 64, tps: 0.00, reads: 0.00, writes: 39318.00, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2071s] threads: 64, tps: 0.00, reads: 0.00, writes: 39536.01, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2072s] threads: 64, tps: 0.00, reads: 0.00, writes: 38177.02, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2073s] threads: 64, tps: 0.00, reads: 0.00, writes: 40735.02, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2074s] threads: 64, tps: 0.00, reads: 0.00, writes: 46063.97, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2075s] threads: 64, tps: 0.00, reads: 0.00, writes: 38210.00, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2076s] threads: 64, tps: 0.00, reads: 0.00, writes: 37051.05, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[2077s] threads: 64, tps: 0.00, reads: 0.00, writes: 40484.24, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[2078s] threads: 64, tps: 0.00, reads: 0.00, writes: 37466.99, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2079s] threads: 64, tps: 0.00, reads: 0.00, writes: 46509.43, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2080s] threads: 64, tps: 0.00, reads: 0.00, writes: 39561.62, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[2081s] threads: 64, tps: 0.00, reads: 0.00, writes: 37527.97, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2082s] threads: 64, tps: 0.00, reads: 0.00, writes: 38819.03, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2083s] threads: 64, tps: 0.00, reads: 0.00, writes: 38855.02, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2084s] threads: 64, tps: 0.00, reads: 0.00, writes: 47485.92, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2085s] threads: 64, tps: 0.00, reads: 0.00, writes: 41124.05, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2086s] threads: 64, tps: 0.00, reads: 0.00, writes: 39566.98, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2087s] threads: 64, tps: 0.00, reads: 0.00, writes: 43739.94, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2088s] threads: 64, tps: 0.00, reads: 0.00, writes: 44091.08, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2089s] threads: 64, tps: 0.00, reads: 0.00, writes: 48133.93, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2090s] threads: 64, tps: 0.00, reads: 0.00, writes: 45530.13, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2091s] threads: 64, tps: 0.00, reads: 0.00, writes: 42963.92, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2092s] threads: 64, tps: 0.00, reads: 0.00, writes: 43629.02, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2093s] threads: 64, tps: 0.00, reads: 0.00, writes: 44386.14, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2094s] threads: 64, tps: 0.00, reads: 0.00, writes: 49452.95, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[2095s] threads: 64, tps: 0.00, reads: 0.00, writes: 45703.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2096s] threads: 64, tps: 0.00, reads: 0.00, writes: 43108.05, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2097s] threads: 64, tps: 0.00, reads: 0.00, writes: 43072.93, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2098s] threads: 64, tps: 0.00, reads: 0.00, writes: 47938.84, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2099s] threads: 64, tps: 0.00, reads: 0.00, writes: 46713.02, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2100s] threads: 64, tps: 0.00, reads: 0.00, writes: 44618.13, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2101s] threads: 64, tps: 0.00, reads: 0.00, writes: 44918.07, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2102s] threads: 64, tps: 0.00, reads: 0.00, writes: 43792.97, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2103s] threads: 64, tps: 0.00, reads: 0.00, writes: 47421.96, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2104s] threads: 64, tps: 0.00, reads: 0.00, writes: 32251.31, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[2105s] threads: 64, tps: 0.00, reads: 0.00, writes: 26517.46, response time: 10.49ms (95%), errors: 0.00, reconnects:  0.00
[2106s] threads: 64, tps: 0.00, reads: 0.00, writes: 38151.06, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2107s] threads: 64, tps: 0.00, reads: 0.00, writes: 44527.08, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2108s] threads: 64, tps: 0.00, reads: 0.00, writes: 44068.04, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2109s] threads: 64, tps: 0.00, reads: 0.00, writes: 45446.02, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2110s] threads: 64, tps: 0.00, reads: 0.00, writes: 37570.99, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2111s] threads: 64, tps: 0.00, reads: 0.00, writes: 37265.97, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2112s] threads: 64, tps: 0.00, reads: 0.00, writes: 38432.45, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2113s] threads: 64, tps: 0.00, reads: 0.00, writes: 36070.54, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2114s] threads: 64, tps: 0.00, reads: 0.00, writes: 45612.05, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2115s] threads: 64, tps: 0.00, reads: 0.00, writes: 40641.77, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2116s] threads: 64, tps: 0.00, reads: 0.00, writes: 35564.19, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2117s] threads: 64, tps: 0.00, reads: 0.00, writes: 38426.78, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2118s] threads: 64, tps: 0.00, reads: 0.00, writes: 38018.17, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2119s] threads: 64, tps: 0.00, reads: 0.00, writes: 44888.06, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2120s] threads: 64, tps: 0.00, reads: 0.00, writes: 44266.96, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2121s] threads: 64, tps: 0.00, reads: 0.00, writes: 39682.95, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2122s] threads: 64, tps: 0.00, reads: 0.00, writes: 38368.47, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2123s] threads: 64, tps: 0.00, reads: 0.00, writes: 38120.54, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2124s] threads: 64, tps: 0.00, reads: 0.00, writes: 41338.00, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2125s] threads: 64, tps: 0.00, reads: 0.00, writes: 44029.03, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2126s] threads: 64, tps: 0.00, reads: 0.00, writes: 36607.00, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2127s] threads: 64, tps: 0.00, reads: 0.00, writes: 36919.95, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2128s] threads: 64, tps: 0.00, reads: 0.00, writes: 37084.04, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2129s] threads: 64, tps: 0.00, reads: 0.00, writes: 36616.01, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[2130s] threads: 64, tps: 0.00, reads: 0.00, writes: 46616.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2131s] threads: 64, tps: 0.00, reads: 0.00, writes: 41655.00, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2132s] threads: 64, tps: 0.00, reads: 0.00, writes: 37135.00, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2133s] threads: 64, tps: 0.00, reads: 0.00, writes: 36967.98, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2134s] threads: 64, tps: 0.00, reads: 0.00, writes: 36130.05, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[2135s] threads: 64, tps: 0.00, reads: 0.00, writes: 43245.00, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[2136s] threads: 64, tps: 0.00, reads: 0.00, writes: 38156.92, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[2137s] threads: 64, tps: 0.00, reads: 0.00, writes: 3143.94, response time: 21.26ms (95%), errors: 0.00, reconnects:  0.00
[2138s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.01, response time: 21.08ms (95%), errors: 0.00, reconnects:  0.00
[2139s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.00, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[2140s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.03, response time: 21.33ms (95%), errors: 0.00, reconnects:  0.00
[2141s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.92, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2142s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.99, response time: 21.05ms (95%), errors: 0.00, reconnects:  0.00
[2143s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.03, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[2144s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.07, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[2145s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.00, response time: 21.23ms (95%), errors: 0.00, reconnects:  0.00
[2146s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.99, response time: 21.26ms (95%), errors: 0.00, reconnects:  0.00
[2147s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.00, response time: 21.05ms (95%), errors: 0.00, reconnects:  0.00
[2148s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.99, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[2149s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.00, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[2150s] threads: 64, tps: 0.00, reads: 0.00, writes: 3140.99, response time: 21.45ms (95%), errors: 0.00, reconnects:  0.00
[2151s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.01, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[2152s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.95, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[2153s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.03, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[2154s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.03, response time: 21.25ms (95%), errors: 0.00, reconnects:  0.00
[2155s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.89, response time: 21.22ms (95%), errors: 0.00, reconnects:  0.00
[2156s] threads: 64, tps: 0.00, reads: 0.00, writes: 3145.03, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[2157s] threads: 64, tps: 0.00, reads: 0.00, writes: 33024.03, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[2158s] threads: 64, tps: 0.00, reads: 0.00, writes: 44120.94, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2159s] threads: 64, tps: 0.00, reads: 0.00, writes: 46580.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2160s] threads: 64, tps: 0.00, reads: 0.00, writes: 47610.01, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2161s] threads: 64, tps: 0.00, reads: 0.00, writes: 43628.01, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2162s] threads: 64, tps: 0.00, reads: 0.00, writes: 40610.03, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2163s] threads: 64, tps: 0.00, reads: 0.00, writes: 37301.85, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2164s] threads: 64, tps: 0.00, reads: 0.00, writes: 48128.08, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[2165s] threads: 64, tps: 0.00, reads: 0.00, writes: 46564.84, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2166s] threads: 64, tps: 0.00, reads: 0.00, writes: 43005.14, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2167s] threads: 64, tps: 0.00, reads: 0.00, writes: 37171.07, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2168s] threads: 64, tps: 0.00, reads: 0.00, writes: 38199.47, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2169s] threads: 64, tps: 0.00, reads: 0.00, writes: 48130.66, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2170s] threads: 64, tps: 0.00, reads: 0.00, writes: 40690.97, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2171s] threads: 64, tps: 0.00, reads: 0.00, writes: 38893.86, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2172s] threads: 64, tps: 0.00, reads: 0.00, writes: 38189.38, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2173s] threads: 64, tps: 0.00, reads: 0.00, writes: 38029.79, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2174s] threads: 64, tps: 0.00, reads: 0.00, writes: 46074.66, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2175s] threads: 64, tps: 0.00, reads: 0.00, writes: 41587.92, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2176s] threads: 64, tps: 0.00, reads: 0.00, writes: 37415.02, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2177s] threads: 64, tps: 0.00, reads: 0.00, writes: 35726.02, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[2178s] threads: 64, tps: 0.00, reads: 0.00, writes: 35507.13, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[2179s] threads: 64, tps: 0.00, reads: 0.00, writes: 42165.20, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[2180s] threads: 64, tps: 0.00, reads: 0.00, writes: 44233.00, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2181s] threads: 64, tps: 0.00, reads: 0.00, writes: 39810.02, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2182s] threads: 64, tps: 0.00, reads: 0.00, writes: 43509.96, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2183s] threads: 64, tps: 0.00, reads: 0.00, writes: 41796.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2184s] threads: 64, tps: 0.00, reads: 0.00, writes: 46997.91, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2185s] threads: 64, tps: 0.00, reads: 0.00, writes: 47060.04, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2186s] threads: 64, tps: 0.00, reads: 0.00, writes: 45752.98, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2187s] threads: 64, tps: 0.00, reads: 0.00, writes: 43191.03, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2188s] threads: 64, tps: 0.00, reads: 0.00, writes: 44349.04, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2189s] threads: 64, tps: 0.00, reads: 0.00, writes: 48520.93, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2190s] threads: 64, tps: 0.00, reads: 0.00, writes: 45144.03, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2191s] threads: 64, tps: 0.00, reads: 0.00, writes: 43566.03, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2192s] threads: 64, tps: 0.00, reads: 0.00, writes: 42954.92, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2193s] threads: 64, tps: 0.00, reads: 0.00, writes: 37267.03, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2194s] threads: 64, tps: 0.00, reads: 0.00, writes: 48773.02, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2195s] threads: 64, tps: 0.00, reads: 0.00, writes: 44989.02, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2196s] threads: 64, tps: 0.00, reads: 0.00, writes: 33797.98, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[2197s] threads: 64, tps: 0.00, reads: 0.00, writes: 38415.02, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2198s] threads: 64, tps: 0.00, reads: 0.00, writes: 41697.01, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2199s] threads: 64, tps: 0.00, reads: 0.00, writes: 48446.98, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2200s] threads: 64, tps: 0.00, reads: 0.00, writes: 46977.04, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[2201s] threads: 64, tps: 0.00, reads: 0.00, writes: 47101.93, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2202s] threads: 64, tps: 0.00, reads: 0.00, writes: 44687.03, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2203s] threads: 64, tps: 0.00, reads: 0.00, writes: 45269.99, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2204s] threads: 64, tps: 0.00, reads: 0.00, writes: 48366.97, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2205s] threads: 64, tps: 0.00, reads: 0.00, writes: 44062.96, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2206s] threads: 64, tps: 0.00, reads: 0.00, writes: 38154.05, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2207s] threads: 64, tps: 0.00, reads: 0.00, writes: 37594.06, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2208s] threads: 64, tps: 0.00, reads: 0.00, writes: 44765.94, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2209s] threads: 64, tps: 0.00, reads: 0.00, writes: 46666.99, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2210s] threads: 64, tps: 0.00, reads: 0.00, writes: 45963.00, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2211s] threads: 64, tps: 0.00, reads: 0.00, writes: 43303.98, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2212s] threads: 64, tps: 0.00, reads: 0.00, writes: 42528.03, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2213s] threads: 64, tps: 0.00, reads: 0.00, writes: 47152.97, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2214s] threads: 64, tps: 0.00, reads: 0.00, writes: 45880.94, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2215s] threads: 64, tps: 0.00, reads: 0.00, writes: 44567.04, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2216s] threads: 64, tps: 0.00, reads: 0.00, writes: 43017.02, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2217s] threads: 64, tps: 0.00, reads: 0.00, writes: 43646.01, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2218s] threads: 64, tps: 0.00, reads: 0.00, writes: 47298.94, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2219s] threads: 64, tps: 0.00, reads: 0.00, writes: 47188.04, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2220s] threads: 64, tps: 0.00, reads: 0.00, writes: 42492.04, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2221s] threads: 64, tps: 0.00, reads: 0.00, writes: 41996.85, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2222s] threads: 64, tps: 0.00, reads: 0.00, writes: 36713.10, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2223s] threads: 64, tps: 0.00, reads: 0.00, writes: 48680.02, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2224s] threads: 64, tps: 0.00, reads: 0.00, writes: 46256.97, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2225s] threads: 64, tps: 0.00, reads: 0.00, writes: 43295.80, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2226s] threads: 64, tps: 0.00, reads: 0.00, writes: 43043.32, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2227s] threads: 64, tps: 0.00, reads: 0.00, writes: 44652.90, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2228s] threads: 64, tps: 0.00, reads: 0.00, writes: 47560.92, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[2229s] threads: 64, tps: 0.00, reads: 0.00, writes: 45584.99, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2230s] threads: 64, tps: 0.00, reads: 0.00, writes: 44606.08, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2231s] threads: 64, tps: 0.00, reads: 0.00, writes: 43971.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2232s] threads: 64, tps: 0.00, reads: 0.00, writes: 45033.06, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2233s] threads: 64, tps: 0.00, reads: 0.00, writes: 44554.86, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2234s] threads: 64, tps: 0.00, reads: 0.00, writes: 36887.07, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2235s] threads: 64, tps: 0.00, reads: 0.00, writes: 41795.93, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2236s] threads: 64, tps: 0.00, reads: 0.00, writes: 37980.00, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2237s] threads: 64, tps: 0.00, reads: 0.00, writes: 42567.10, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2238s] threads: 64, tps: 0.00, reads: 0.00, writes: 46277.92, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2239s] threads: 64, tps: 0.00, reads: 0.00, writes: 38379.01, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[2240s] threads: 64, tps: 0.00, reads: 0.00, writes: 39299.98, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2241s] threads: 64, tps: 0.00, reads: 0.00, writes: 42908.00, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2242s] threads: 64, tps: 0.00, reads: 0.00, writes: 46069.02, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2243s] threads: 64, tps: 0.00, reads: 0.00, writes: 47855.51, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2244s] threads: 64, tps: 0.00, reads: 0.00, writes: 46595.44, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2245s] threads: 64, tps: 0.00, reads: 0.00, writes: 42630.01, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2246s] threads: 64, tps: 0.00, reads: 0.00, writes: 43533.98, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2247s] threads: 64, tps: 0.00, reads: 0.00, writes: 47022.02, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2248s] threads: 64, tps: 0.00, reads: 0.00, writes: 46538.06, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2249s] threads: 64, tps: 0.00, reads: 0.00, writes: 44769.99, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2250s] threads: 64, tps: 0.00, reads: 0.00, writes: 43582.95, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2251s] threads: 64, tps: 0.00, reads: 0.00, writes: 43811.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2252s] threads: 64, tps: 0.00, reads: 0.00, writes: 49321.03, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[2253s] threads: 64, tps: 0.00, reads: 0.00, writes: 38901.69, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2254s] threads: 64, tps: 0.00, reads: 0.00, writes: 26130.77, response time: 19.44ms (95%), errors: 0.00, reconnects:  0.00
[2255s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.00, response time: 21.83ms (95%), errors: 0.00, reconnects:  0.00
[2256s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.02, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[2257s] threads: 64, tps: 0.00, reads: 0.00, writes: 5376.00, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[2258s] threads: 64, tps: 0.00, reads: 0.00, writes: 41236.02, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2259s] threads: 64, tps: 0.00, reads: 0.00, writes: 41541.95, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2260s] threads: 64, tps: 0.00, reads: 0.00, writes: 49407.11, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[2261s] threads: 64, tps: 0.00, reads: 0.00, writes: 46613.60, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2262s] threads: 64, tps: 0.00, reads: 0.00, writes: 42828.40, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2263s] threads: 64, tps: 0.00, reads: 0.00, writes: 43639.95, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2264s] threads: 64, tps: 0.00, reads: 0.00, writes: 46380.02, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2265s] threads: 64, tps: 0.00, reads: 0.00, writes: 48199.97, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[2266s] threads: 64, tps: 0.00, reads: 0.00, writes: 46754.95, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2267s] threads: 64, tps: 0.00, reads: 0.00, writes: 44695.02, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2268s] threads: 64, tps: 0.00, reads: 0.00, writes: 42708.03, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2269s] threads: 64, tps: 0.00, reads: 0.00, writes: 44007.02, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2270s] threads: 64, tps: 0.00, reads: 0.00, writes: 44232.01, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2271s] threads: 64, tps: 0.00, reads: 0.00, writes: 38575.15, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2272s] threads: 64, tps: 0.00, reads: 0.00, writes: 38297.84, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[2273s] threads: 64, tps: 0.00, reads: 0.00, writes: 36373.10, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2274s] threads: 64, tps: 0.00, reads: 0.00, writes: 40788.01, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2275s] threads: 64, tps: 0.00, reads: 0.00, writes: 47423.97, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2276s] threads: 64, tps: 0.00, reads: 0.00, writes: 38981.14, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2277s] threads: 64, tps: 0.00, reads: 0.00, writes: 39286.85, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2278s] threads: 64, tps: 0.00, reads: 0.00, writes: 43464.98, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2279s] threads: 64, tps: 0.00, reads: 0.00, writes: 45805.03, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2280s] threads: 64, tps: 0.00, reads: 0.00, writes: 45834.03, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2281s] threads: 64, tps: 0.00, reads: 0.00, writes: 44661.01, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2282s] threads: 64, tps: 0.00, reads: 0.00, writes: 41852.98, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2283s] threads: 64, tps: 0.00, reads: 0.00, writes: 42840.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2284s] threads: 64, tps: 0.00, reads: 0.00, writes: 45845.03, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2285s] threads: 64, tps: 0.00, reads: 0.00, writes: 47525.99, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2286s] threads: 64, tps: 0.00, reads: 0.00, writes: 45115.00, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2287s] threads: 64, tps: 0.00, reads: 0.00, writes: 43228.97, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2288s] threads: 64, tps: 0.00, reads: 0.00, writes: 43760.03, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2289s] threads: 64, tps: 0.00, reads: 0.00, writes: 46809.94, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2290s] threads: 64, tps: 0.00, reads: 0.00, writes: 46240.01, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2291s] threads: 64, tps: 0.00, reads: 0.00, writes: 44995.98, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2292s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.94, response time: 21.08ms (95%), errors: 0.00, reconnects:  0.00
[2293s] threads: 64, tps: 0.00, reads: 0.00, writes: 3144.90, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[2294s] threads: 64, tps: 0.00, reads: 0.00, writes: 3173.07, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[2295s] threads: 64, tps: 0.00, reads: 0.00, writes: 3165.08, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[2296s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.01, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[2297s] threads: 64, tps: 0.00, reads: 0.00, writes: 33546.92, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2298s] threads: 64, tps: 0.00, reads: 0.00, writes: 44194.44, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2299s] threads: 64, tps: 0.00, reads: 0.00, writes: 47847.11, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[2300s] threads: 64, tps: 0.00, reads: 0.00, writes: 46416.06, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2301s] threads: 64, tps: 0.00, reads: 0.00, writes: 43999.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2302s] threads: 64, tps: 0.00, reads: 0.00, writes: 37585.00, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2303s] threads: 64, tps: 0.00, reads: 0.00, writes: 40730.86, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2304s] threads: 64, tps: 0.00, reads: 0.00, writes: 46072.24, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2305s] threads: 64, tps: 0.00, reads: 0.00, writes: 43219.72, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2306s] threads: 64, tps: 0.00, reads: 0.00, writes: 40319.19, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2307s] threads: 64, tps: 0.00, reads: 0.00, writes: 37673.06, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2308s] threads: 64, tps: 0.00, reads: 0.00, writes: 44560.93, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2309s] threads: 64, tps: 0.00, reads: 0.00, writes: 45621.86, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2310s] threads: 64, tps: 0.00, reads: 0.00, writes: 37911.17, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2311s] threads: 64, tps: 0.00, reads: 0.00, writes: 41228.84, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2312s] threads: 64, tps: 0.00, reads: 0.00, writes: 44115.16, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2313s] threads: 64, tps: 0.00, reads: 0.00, writes: 46124.98, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2314s] threads: 64, tps: 0.00, reads: 0.00, writes: 46686.05, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2315s] threads: 64, tps: 0.00, reads: 0.00, writes: 45396.86, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2316s] threads: 64, tps: 0.00, reads: 0.00, writes: 43022.92, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2317s] threads: 64, tps: 0.00, reads: 0.00, writes: 42824.94, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2318s] threads: 64, tps: 0.00, reads: 0.00, writes: 45348.00, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2319s] threads: 64, tps: 0.00, reads: 0.00, writes: 45451.24, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2320s] threads: 64, tps: 0.00, reads: 0.00, writes: 43876.79, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2321s] threads: 64, tps: 0.00, reads: 0.00, writes: 44336.13, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2322s] threads: 64, tps: 0.00, reads: 0.00, writes: 43197.13, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2323s] threads: 64, tps: 0.00, reads: 0.00, writes: 47207.72, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2324s] threads: 64, tps: 0.00, reads: 0.00, writes: 44997.28, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2325s] threads: 64, tps: 0.00, reads: 0.00, writes: 44026.89, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2326s] threads: 64, tps: 0.00, reads: 0.00, writes: 42974.03, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2327s] threads: 64, tps: 0.00, reads: 0.00, writes: 45857.02, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2328s] threads: 64, tps: 0.00, reads: 0.00, writes: 46729.03, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2329s] threads: 64, tps: 0.00, reads: 0.00, writes: 46596.97, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2330s] threads: 64, tps: 0.00, reads: 0.00, writes: 24233.18, response time: 19.81ms (95%), errors: 0.00, reconnects:  0.00
[2331s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.04, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[2332s] threads: 64, tps: 0.00, reads: 0.00, writes: 20372.42, response time: 20.32ms (95%), errors: 0.00, reconnects:  0.00
[2333s] threads: 64, tps: 0.00, reads: 0.00, writes: 44059.02, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2334s] threads: 64, tps: 0.00, reads: 0.00, writes: 47029.99, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2335s] threads: 64, tps: 0.00, reads: 0.00, writes: 45031.03, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2336s] threads: 64, tps: 0.00, reads: 0.00, writes: 44470.99, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2337s] threads: 64, tps: 0.00, reads: 0.00, writes: 44016.00, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2338s] threads: 64, tps: 0.00, reads: 0.00, writes: 45149.98, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2339s] threads: 64, tps: 0.00, reads: 0.00, writes: 47751.97, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[2340s] threads: 64, tps: 0.00, reads: 0.00, writes: 43079.80, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2341s] threads: 64, tps: 0.00, reads: 0.00, writes: 39860.18, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2342s] threads: 64, tps: 0.00, reads: 0.00, writes: 42164.98, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2343s] threads: 64, tps: 0.00, reads: 0.00, writes: 42301.04, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2344s] threads: 64, tps: 0.00, reads: 0.00, writes: 48049.48, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2345s] threads: 64, tps: 0.00, reads: 0.00, writes: 45683.49, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2346s] threads: 64, tps: 0.00, reads: 0.00, writes: 43371.93, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2347s] threads: 64, tps: 0.00, reads: 0.00, writes: 45182.06, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2348s] threads: 64, tps: 0.00, reads: 0.00, writes: 46163.92, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2349s] threads: 64, tps: 0.00, reads: 0.00, writes: 47566.07, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[2350s] threads: 64, tps: 0.00, reads: 0.00, writes: 46483.01, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2351s] threads: 64, tps: 0.00, reads: 0.00, writes: 42167.01, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2352s] threads: 64, tps: 0.00, reads: 0.00, writes: 40648.01, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2353s] threads: 64, tps: 0.00, reads: 0.00, writes: 45754.95, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2354s] threads: 64, tps: 0.00, reads: 0.00, writes: 46167.88, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2355s] threads: 64, tps: 0.00, reads: 0.00, writes: 44369.08, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2356s] threads: 64, tps: 0.00, reads: 0.00, writes: 44611.94, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2357s] threads: 64, tps: 0.00, reads: 0.00, writes: 43395.07, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2358s] threads: 64, tps: 0.00, reads: 0.00, writes: 47053.98, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2359s] threads: 64, tps: 0.00, reads: 0.00, writes: 46766.00, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2360s] threads: 64, tps: 0.00, reads: 0.00, writes: 44302.22, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2361s] threads: 64, tps: 0.00, reads: 0.00, writes: 6218.01, response time: 20.87ms (95%), errors: 0.00, reconnects:  0.00
[2362s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.01, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[2363s] threads: 64, tps: 0.00, reads: 0.00, writes: 11598.38, response time: 20.53ms (95%), errors: 0.00, reconnects:  0.00
[2364s] threads: 64, tps: 0.00, reads: 0.00, writes: 43783.05, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2365s] threads: 64, tps: 0.00, reads: 0.00, writes: 48139.98, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2366s] threads: 64, tps: 0.00, reads: 0.00, writes: 47339.76, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[2367s] threads: 64, tps: 0.00, reads: 0.00, writes: 46571.23, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2368s] threads: 64, tps: 0.00, reads: 0.00, writes: 43608.78, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2369s] threads: 64, tps: 0.00, reads: 0.00, writes: 40260.11, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[2370s] threads: 64, tps: 0.00, reads: 0.00, writes: 47298.07, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2371s] threads: 64, tps: 0.00, reads: 0.00, writes: 44312.10, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2372s] threads: 64, tps: 0.00, reads: 0.00, writes: 36427.77, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[2373s] threads: 64, tps: 0.00, reads: 0.00, writes: 37515.89, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2374s] threads: 64, tps: 0.00, reads: 0.00, writes: 39417.15, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2375s] threads: 64, tps: 0.00, reads: 0.00, writes: 46997.94, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2376s] threads: 64, tps: 0.00, reads: 0.00, writes: 45389.98, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2377s] threads: 64, tps: 0.00, reads: 0.00, writes: 43891.01, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2378s] threads: 64, tps: 0.00, reads: 0.00, writes: 41829.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2379s] threads: 64, tps: 0.00, reads: 0.00, writes: 43507.04, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2380s] threads: 64, tps: 0.00, reads: 0.00, writes: 40364.96, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2381s] threads: 64, tps: 0.00, reads: 0.00, writes: 46824.08, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2382s] threads: 64, tps: 0.00, reads: 0.00, writes: 44382.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2383s] threads: 64, tps: 0.00, reads: 0.00, writes: 44260.76, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2384s] threads: 64, tps: 0.00, reads: 0.00, writes: 45756.94, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2385s] threads: 64, tps: 0.00, reads: 0.00, writes: 48175.98, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2386s] threads: 64, tps: 0.00, reads: 0.00, writes: 45784.27, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2387s] threads: 64, tps: 0.00, reads: 0.00, writes: 42190.82, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2388s] threads: 64, tps: 0.00, reads: 0.00, writes: 42828.19, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2389s] threads: 64, tps: 0.00, reads: 0.00, writes: 45886.79, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2390s] threads: 64, tps: 0.00, reads: 0.00, writes: 46425.15, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2391s] threads: 64, tps: 0.00, reads: 0.00, writes: 45382.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2392s] threads: 64, tps: 0.00, reads: 0.00, writes: 19902.83, response time: 20.14ms (95%), errors: 0.00, reconnects:  0.00
[2393s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.02, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[2394s] threads: 64, tps: 0.00, reads: 0.00, writes: 3144.99, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[2395s] threads: 64, tps: 0.00, reads: 0.00, writes: 3187.02, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[2396s] threads: 64, tps: 0.00, reads: 0.00, writes: 5235.96, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2397s] threads: 64, tps: 0.00, reads: 0.00, writes: 44035.31, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2398s] threads: 64, tps: 0.00, reads: 0.00, writes: 45642.01, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2399s] threads: 64, tps: 0.00, reads: 0.00, writes: 47266.07, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[2400s] threads: 64, tps: 0.00, reads: 0.00, writes: 45442.03, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2401s] threads: 64, tps: 0.00, reads: 0.00, writes: 45205.96, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2402s] threads: 64, tps: 0.00, reads: 0.00, writes: 42560.94, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2403s] threads: 64, tps: 0.00, reads: 0.00, writes: 46484.03, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2404s] threads: 64, tps: 0.00, reads: 0.00, writes: 41010.82, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2405s] threads: 64, tps: 0.00, reads: 0.00, writes: 42618.22, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2406s] threads: 64, tps: 0.00, reads: 0.00, writes: 43800.96, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2407s] threads: 64, tps: 0.00, reads: 0.00, writes: 38353.97, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2408s] threads: 64, tps: 0.00, reads: 0.00, writes: 49093.04, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2409s] threads: 64, tps: 0.00, reads: 0.00, writes: 40199.01, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2410s] threads: 64, tps: 0.00, reads: 0.00, writes: 38801.02, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2411s] threads: 64, tps: 0.00, reads: 0.00, writes: 37512.03, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2412s] threads: 64, tps: 0.00, reads: 0.00, writes: 44024.98, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2413s] threads: 64, tps: 0.00, reads: 0.00, writes: 47804.95, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2414s] threads: 64, tps: 0.00, reads: 0.00, writes: 46994.72, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2415s] threads: 64, tps: 0.00, reads: 0.00, writes: 40266.06, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2416s] threads: 64, tps: 0.00, reads: 0.00, writes: 42717.87, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2417s] threads: 64, tps: 0.00, reads: 0.00, writes: 42907.04, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2418s] threads: 64, tps: 0.00, reads: 0.00, writes: 46572.11, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2419s] threads: 64, tps: 0.00, reads: 0.00, writes: 46224.06, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2420s] threads: 64, tps: 0.00, reads: 0.00, writes: 41351.03, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[2421s] threads: 64, tps: 0.00, reads: 0.00, writes: 42667.94, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2422s] threads: 64, tps: 0.00, reads: 0.00, writes: 42691.99, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2423s] threads: 64, tps: 0.00, reads: 0.00, writes: 46579.81, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2424s] threads: 64, tps: 0.00, reads: 0.00, writes: 44618.04, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2425s] threads: 64, tps: 0.00, reads: 0.00, writes: 13528.23, response time: 20.54ms (95%), errors: 0.00, reconnects:  0.00
[2426s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.10, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[2427s] threads: 64, tps: 0.00, reads: 0.00, writes: 3178.02, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[2428s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.97, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2429s] threads: 64, tps: 0.00, reads: 0.00, writes: 3168.03, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[2430s] threads: 64, tps: 0.00, reads: 0.00, writes: 3135.96, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[2431s] threads: 64, tps: 0.00, reads: 0.00, writes: 3185.09, response time: 21.28ms (95%), errors: 0.00, reconnects:  0.00
[2432s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.01, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[2433s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.98, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2434s] threads: 64, tps: 0.00, reads: 0.00, writes: 3146.93, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[2435s] threads: 64, tps: 0.00, reads: 0.00, writes: 3188.99, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[2436s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.09, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[2437s] threads: 64, tps: 0.00, reads: 0.00, writes: 4802.02, response time: 20.94ms (95%), errors: 0.00, reconnects:  0.00
[2438s] threads: 64, tps: 0.00, reads: 0.00, writes: 44477.05, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2439s] threads: 64, tps: 0.00, reads: 0.00, writes: 47969.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2440s] threads: 64, tps: 0.00, reads: 0.00, writes: 45172.96, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2441s] threads: 64, tps: 0.00, reads: 0.00, writes: 44985.04, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2442s] threads: 64, tps: 0.00, reads: 0.00, writes: 42909.95, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2443s] threads: 64, tps: 0.00, reads: 0.00, writes: 42825.86, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2444s] threads: 64, tps: 0.00, reads: 0.00, writes: 48891.20, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[2445s] threads: 64, tps: 0.00, reads: 0.00, writes: 46495.00, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2446s] threads: 64, tps: 0.00, reads: 0.00, writes: 45158.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2447s] threads: 64, tps: 0.00, reads: 0.00, writes: 42564.78, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2448s] threads: 64, tps: 0.00, reads: 0.00, writes: 40302.90, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2449s] threads: 64, tps: 0.00, reads: 0.00, writes: 46838.11, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2450s] threads: 64, tps: 0.00, reads: 0.00, writes: 38132.19, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2451s] threads: 64, tps: 0.00, reads: 0.00, writes: 40217.83, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2452s] threads: 64, tps: 0.00, reads: 0.00, writes: 38936.19, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2453s] threads: 64, tps: 0.00, reads: 0.00, writes: 38838.76, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2454s] threads: 64, tps: 0.00, reads: 0.00, writes: 41585.03, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2455s] threads: 64, tps: 0.00, reads: 0.00, writes: 46330.94, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2456s] threads: 64, tps: 0.00, reads: 0.00, writes: 42803.23, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2457s] threads: 64, tps: 0.00, reads: 0.00, writes: 44035.04, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2458s] threads: 64, tps: 0.00, reads: 0.00, writes: 42951.21, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2459s] threads: 64, tps: 0.00, reads: 0.00, writes: 47673.81, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2460s] threads: 64, tps: 0.00, reads: 0.00, writes: 45378.77, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2461s] threads: 64, tps: 0.00, reads: 0.00, writes: 43085.21, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2462s] threads: 64, tps: 0.00, reads: 0.00, writes: 44447.88, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2463s] threads: 64, tps: 0.00, reads: 0.00, writes: 46647.13, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2464s] threads: 64, tps: 0.00, reads: 0.00, writes: 47653.06, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2465s] threads: 64, tps: 0.00, reads: 0.00, writes: 43155.87, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2466s] threads: 64, tps: 0.00, reads: 0.00, writes: 43323.17, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2467s] threads: 64, tps: 0.00, reads: 0.00, writes: 41798.96, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2468s] threads: 64, tps: 0.00, reads: 0.00, writes: 47034.05, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2469s] threads: 64, tps: 0.00, reads: 0.00, writes: 47608.97, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2470s] threads: 64, tps: 0.00, reads: 0.00, writes: 44967.70, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2471s] threads: 64, tps: 0.00, reads: 0.00, writes: 4580.88, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[2472s] threads: 64, tps: 0.00, reads: 0.00, writes: 3182.09, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[2473s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.94, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[2474s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.98, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2475s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.07, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[2476s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.00, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[2477s] threads: 64, tps: 0.00, reads: 0.00, writes: 3178.00, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[2478s] threads: 64, tps: 0.00, reads: 0.00, writes: 3144.99, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2479s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.02, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[2480s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.91, response time: 21.15ms (95%), errors: 0.00, reconnects:  0.00
[2481s] threads: 64, tps: 0.00, reads: 0.00, writes: 3146.10, response time: 21.40ms (95%), errors: 0.00, reconnects:  0.00
[2482s] threads: 64, tps: 0.00, reads: 0.00, writes: 29185.98, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[2483s] threads: 64, tps: 0.00, reads: 0.00, writes: 47889.04, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2484s] threads: 64, tps: 0.00, reads: 0.00, writes: 46233.98, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2485s] threads: 64, tps: 0.00, reads: 0.00, writes: 46488.00, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2486s] threads: 64, tps: 0.00, reads: 0.00, writes: 43871.02, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2487s] threads: 64, tps: 0.00, reads: 0.00, writes: 43469.01, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2488s] threads: 64, tps: 0.00, reads: 0.00, writes: 47484.69, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2489s] threads: 64, tps: 0.00, reads: 0.00, writes: 46683.28, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2490s] threads: 64, tps: 0.00, reads: 0.00, writes: 43998.99, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2491s] threads: 64, tps: 0.00, reads: 0.00, writes: 42681.06, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2492s] threads: 64, tps: 0.00, reads: 0.00, writes: 44207.98, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2493s] threads: 64, tps: 0.00, reads: 0.00, writes: 45206.96, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2494s] threads: 64, tps: 0.00, reads: 0.00, writes: 40868.99, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[2495s] threads: 64, tps: 0.00, reads: 0.00, writes: 39196.05, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[2496s] threads: 64, tps: 0.00, reads: 0.00, writes: 39053.96, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2497s] threads: 64, tps: 0.00, reads: 0.00, writes: 36921.02, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[2498s] threads: 64, tps: 0.00, reads: 0.00, writes: 46204.04, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2499s] threads: 64, tps: 0.00, reads: 0.00, writes: 42738.71, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2500s] threads: 64, tps: 0.00, reads: 0.00, writes: 37094.22, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2501s] threads: 64, tps: 0.00, reads: 0.00, writes: 44243.78, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2502s] threads: 64, tps: 0.00, reads: 0.00, writes: 42346.28, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2503s] threads: 64, tps: 0.00, reads: 0.00, writes: 49395.05, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[2504s] threads: 64, tps: 0.00, reads: 0.00, writes: 45413.01, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2505s] threads: 64, tps: 0.00, reads: 0.00, writes: 38648.60, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2506s] threads: 64, tps: 0.00, reads: 0.00, writes: 37951.00, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2507s] threads: 64, tps: 0.00, reads: 0.00, writes: 37739.35, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2508s] threads: 64, tps: 0.00, reads: 0.00, writes: 47255.79, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2509s] threads: 64, tps: 0.00, reads: 0.00, writes: 27289.73, response time: 8.12ms (95%), errors: 0.00, reconnects:  0.00
[2510s] threads: 64, tps: 0.00, reads: 0.00, writes: 3137.97, response time: 20.86ms (95%), errors: 0.00, reconnects:  0.00
[2511s] threads: 64, tps: 0.00, reads: 0.00, writes: 3193.96, response time: 20.90ms (95%), errors: 0.00, reconnects:  0.00
[2512s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.07, response time: 21.30ms (95%), errors: 0.00, reconnects:  0.00
[2513s] threads: 64, tps: 0.00, reads: 0.00, writes: 3144.91, response time: 20.85ms (95%), errors: 0.00, reconnects:  0.00
[2514s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.02, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[2515s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.03, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[2516s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.97, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[2517s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.10, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[2518s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.00, response time: 21.22ms (95%), errors: 0.00, reconnects:  0.00
[2519s] threads: 64, tps: 0.00, reads: 0.00, writes: 3143.00, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2520s] threads: 64, tps: 0.00, reads: 0.00, writes: 3141.98, response time: 21.37ms (95%), errors: 0.00, reconnects:  0.00
[2521s] threads: 64, tps: 0.00, reads: 0.00, writes: 3172.96, response time: 20.91ms (95%), errors: 0.00, reconnects:  0.00
[2522s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.08, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[2523s] threads: 64, tps: 0.00, reads: 0.00, writes: 3148.96, response time: 21.63ms (95%), errors: 0.00, reconnects:  0.00
[2524s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.90, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[2525s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.03, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[2526s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.03, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[2527s] threads: 64, tps: 0.00, reads: 0.00, writes: 3174.06, response time: 21.00ms (95%), errors: 0.00, reconnects:  0.00
[2528s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.92, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[2529s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.98, response time: 21.05ms (95%), errors: 0.00, reconnects:  0.00
[2530s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.04, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[2531s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.96, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[2532s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.01, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[2533s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.96, response time: 21.05ms (95%), errors: 0.00, reconnects:  0.00
[2534s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.04, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[2535s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.99, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[2536s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.00, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[2537s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.09, response time: 21.05ms (95%), errors: 0.00, reconnects:  0.00
[2538s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.96, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2539s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.95, response time: 20.82ms (95%), errors: 0.00, reconnects:  0.00
[2540s] threads: 64, tps: 0.00, reads: 0.00, writes: 23513.82, response time: 19.96ms (95%), errors: 0.00, reconnects:  0.00
[2541s] threads: 64, tps: 0.00, reads: 0.00, writes: 47430.98, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2542s] threads: 64, tps: 0.00, reads: 0.00, writes: 47301.14, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2543s] threads: 64, tps: 0.00, reads: 0.00, writes: 45597.51, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2544s] threads: 64, tps: 0.00, reads: 0.00, writes: 38227.15, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2545s] threads: 64, tps: 0.00, reads: 0.00, writes: 37627.78, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2546s] threads: 64, tps: 0.00, reads: 0.00, writes: 40658.07, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2547s] threads: 64, tps: 0.00, reads: 0.00, writes: 46807.25, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2548s] threads: 64, tps: 0.00, reads: 0.00, writes: 36367.95, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[2549s] threads: 64, tps: 0.00, reads: 0.00, writes: 36194.02, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2550s] threads: 64, tps: 0.00, reads: 0.00, writes: 37349.98, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2551s] threads: 64, tps: 0.00, reads: 0.00, writes: 36493.99, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[2552s] threads: 64, tps: 0.00, reads: 0.00, writes: 49733.05, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2553s] threads: 64, tps: 0.00, reads: 0.00, writes: 40674.00, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2554s] threads: 64, tps: 0.00, reads: 0.00, writes: 40149.98, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[2555s] threads: 64, tps: 0.00, reads: 0.00, writes: 38760.99, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2556s] threads: 64, tps: 0.00, reads: 0.00, writes: 37611.98, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2557s] threads: 64, tps: 0.00, reads: 0.00, writes: 47497.05, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2558s] threads: 64, tps: 0.00, reads: 0.00, writes: 40593.01, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2559s] threads: 64, tps: 0.00, reads: 0.00, writes: 37643.96, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2560s] threads: 64, tps: 0.00, reads: 0.00, writes: 37480.05, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2561s] threads: 64, tps: 0.00, reads: 0.00, writes: 39001.96, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2562s] threads: 64, tps: 0.00, reads: 0.00, writes: 44241.01, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2563s] threads: 64, tps: 0.00, reads: 0.00, writes: 41850.96, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2564s] threads: 64, tps: 0.00, reads: 0.00, writes: 43200.04, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2565s] threads: 64, tps: 0.00, reads: 0.00, writes: 44834.96, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2566s] threads: 64, tps: 0.00, reads: 0.00, writes: 43059.09, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2567s] threads: 64, tps: 0.00, reads: 0.00, writes: 46239.95, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2568s] threads: 64, tps: 0.00, reads: 0.00, writes: 47010.94, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2569s] threads: 64, tps: 0.00, reads: 0.00, writes: 44497.05, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2570s] threads: 64, tps: 0.00, reads: 0.00, writes: 44180.57, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2571s] threads: 64, tps: 0.00, reads: 0.00, writes: 44372.48, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2572s] threads: 64, tps: 0.00, reads: 0.00, writes: 46875.98, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2573s] threads: 64, tps: 0.00, reads: 0.00, writes: 45912.05, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2574s] threads: 64, tps: 0.00, reads: 0.00, writes: 41200.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2575s] threads: 64, tps: 0.00, reads: 0.00, writes: 44589.35, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2576s] threads: 64, tps: 0.00, reads: 0.00, writes: 43400.58, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2577s] threads: 64, tps: 0.00, reads: 0.00, writes: 46387.07, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2578s] threads: 64, tps: 0.00, reads: 0.00, writes: 40018.98, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[2579s] threads: 64, tps: 0.00, reads: 0.00, writes: 37945.99, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2580s] threads: 64, tps: 0.00, reads: 0.00, writes: 37323.96, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2581s] threads: 64, tps: 0.00, reads: 0.00, writes: 43340.04, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2582s] threads: 64, tps: 0.00, reads: 0.00, writes: 47325.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2583s] threads: 64, tps: 0.00, reads: 0.00, writes: 46668.94, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2584s] threads: 64, tps: 0.00, reads: 0.00, writes: 37814.96, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2585s] threads: 64, tps: 0.00, reads: 0.00, writes: 43615.05, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[2586s] threads: 64, tps: 0.00, reads: 0.00, writes: 45787.07, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2587s] threads: 64, tps: 0.00, reads: 0.00, writes: 46703.91, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2588s] threads: 64, tps: 0.00, reads: 0.00, writes: 38660.03, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2589s] threads: 64, tps: 0.00, reads: 0.00, writes: 39343.01, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[2590s] threads: 64, tps: 0.00, reads: 0.00, writes: 36069.00, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[2591s] threads: 64, tps: 0.00, reads: 0.00, writes: 41098.04, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2592s] threads: 64, tps: 0.00, reads: 0.00, writes: 45751.66, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2593s] threads: 64, tps: 0.00, reads: 0.00, writes: 37221.06, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2594s] threads: 64, tps: 0.00, reads: 0.00, writes: 37073.02, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2595s] threads: 64, tps: 0.00, reads: 0.00, writes: 36809.93, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2596s] threads: 64, tps: 0.00, reads: 0.00, writes: 36901.00, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2597s] threads: 64, tps: 0.00, reads: 0.00, writes: 45281.02, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2598s] threads: 64, tps: 0.00, reads: 0.00, writes: 41707.06, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2599s] threads: 64, tps: 0.00, reads: 0.00, writes: 37620.88, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2600s] threads: 64, tps: 0.00, reads: 0.00, writes: 39235.09, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2601s] threads: 64, tps: 0.00, reads: 0.00, writes: 42691.00, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2602s] threads: 64, tps: 0.00, reads: 0.00, writes: 46193.97, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2603s] threads: 64, tps: 0.00, reads: 0.00, writes: 46360.93, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2604s] threads: 64, tps: 0.00, reads: 0.00, writes: 45402.12, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2605s] threads: 64, tps: 0.00, reads: 0.00, writes: 44002.93, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2606s] threads: 64, tps: 0.00, reads: 0.00, writes: 39054.84, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2607s] threads: 64, tps: 0.00, reads: 0.00, writes: 46751.29, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2608s] threads: 64, tps: 0.00, reads: 0.00, writes: 40142.89, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2609s] threads: 64, tps: 0.00, reads: 0.00, writes: 40107.88, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[2610s] threads: 64, tps: 0.00, reads: 0.00, writes: 38653.00, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[2611s] threads: 64, tps: 0.00, reads: 0.00, writes: 34067.28, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[2612s] threads: 64, tps: 0.00, reads: 0.00, writes: 42986.94, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2613s] threads: 64, tps: 0.00, reads: 0.00, writes: 47096.60, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2614s] threads: 64, tps: 0.00, reads: 0.00, writes: 43842.86, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2615s] threads: 64, tps: 0.00, reads: 0.00, writes: 3344.97, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[2616s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.99, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[2617s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.03, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[2618s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.98, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[2619s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.10, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[2620s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.93, response time: 21.22ms (95%), errors: 0.00, reconnects:  0.00
[2621s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.07, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[2622s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.94, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[2623s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.01, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[2624s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.95, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[2625s] threads: 64, tps: 0.00, reads: 0.00, writes: 3162.02, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[2626s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.00, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[2627s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.07, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[2628s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.95, response time: 20.98ms (95%), errors: 0.00, reconnects:  0.00
[2629s] threads: 64, tps: 0.00, reads: 0.00, writes: 33181.74, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[2630s] threads: 64, tps: 0.00, reads: 0.00, writes: 45686.06, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2631s] threads: 64, tps: 0.00, reads: 0.00, writes: 46885.99, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2632s] threads: 64, tps: 0.00, reads: 0.00, writes: 39686.00, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[2633s] threads: 64, tps: 0.00, reads: 0.00, writes: 38934.97, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2634s] threads: 64, tps: 0.00, reads: 0.00, writes: 38146.03, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2635s] threads: 64, tps: 0.00, reads: 0.00, writes: 43980.99, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2636s] threads: 64, tps: 0.00, reads: 0.00, writes: 45969.84, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[2637s] threads: 64, tps: 0.00, reads: 0.00, writes: 39374.07, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2638s] threads: 64, tps: 0.00, reads: 0.00, writes: 36884.07, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2639s] threads: 64, tps: 0.00, reads: 0.00, writes: 37168.01, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2640s] threads: 64, tps: 0.00, reads: 0.00, writes: 39054.49, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2641s] threads: 64, tps: 0.00, reads: 0.00, writes: 45939.67, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2642s] threads: 64, tps: 0.00, reads: 0.00, writes: 37237.94, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2643s] threads: 64, tps: 0.00, reads: 0.00, writes: 37501.80, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2644s] threads: 64, tps: 0.00, reads: 0.00, writes: 37688.14, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[2645s] threads: 64, tps: 0.00, reads: 0.00, writes: 37466.06, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2646s] threads: 64, tps: 0.00, reads: 0.00, writes: 47293.58, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2647s] threads: 64, tps: 0.00, reads: 0.00, writes: 40924.11, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2648s] threads: 64, tps: 0.00, reads: 0.00, writes: 41017.20, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2649s] threads: 64, tps: 0.00, reads: 0.00, writes: 43531.09, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2650s] threads: 64, tps: 0.00, reads: 0.00, writes: 42672.57, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2651s] threads: 64, tps: 0.00, reads: 0.00, writes: 46195.42, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2652s] threads: 64, tps: 0.00, reads: 0.00, writes: 46582.84, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2653s] threads: 64, tps: 0.00, reads: 0.00, writes: 44154.13, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2654s] threads: 64, tps: 0.00, reads: 0.00, writes: 44464.01, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2655s] threads: 64, tps: 0.00, reads: 0.00, writes: 43679.08, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2656s] threads: 64, tps: 0.00, reads: 0.00, writes: 46707.88, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2657s] threads: 64, tps: 0.00, reads: 0.00, writes: 46129.57, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2658s] threads: 64, tps: 0.00, reads: 0.00, writes: 43874.41, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2659s] threads: 64, tps: 0.00, reads: 0.00, writes: 40951.98, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[2660s] threads: 64, tps: 0.00, reads: 0.00, writes: 43346.05, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2661s] threads: 64, tps: 0.00, reads: 0.00, writes: 46695.72, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2662s] threads: 64, tps: 0.00, reads: 0.00, writes: 45672.26, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2663s] threads: 64, tps: 0.00, reads: 0.00, writes: 35429.96, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[2664s] threads: 64, tps: 0.00, reads: 0.00, writes: 38210.09, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2665s] threads: 64, tps: 0.00, reads: 0.00, writes: 46595.96, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2666s] threads: 64, tps: 0.00, reads: 0.00, writes: 45992.99, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2667s] threads: 64, tps: 0.00, reads: 0.00, writes: 46039.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2668s] threads: 64, tps: 0.00, reads: 0.00, writes: 40028.95, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[2669s] threads: 64, tps: 0.00, reads: 0.00, writes: 37663.97, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2670s] threads: 64, tps: 0.00, reads: 0.00, writes: 41172.00, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2671s] threads: 64, tps: 0.00, reads: 0.00, writes: 44040.60, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2672s] threads: 64, tps: 0.00, reads: 0.00, writes: 38066.20, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2673s] threads: 64, tps: 0.00, reads: 0.00, writes: 38712.06, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[2674s] threads: 64, tps: 0.00, reads: 0.00, writes: 34264.32, response time: 2.73ms (95%), errors: 0.00, reconnects:  0.00
[2675s] threads: 64, tps: 0.00, reads: 0.00, writes: 37991.83, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2676s] threads: 64, tps: 0.00, reads: 0.00, writes: 47990.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2677s] threads: 64, tps: 0.00, reads: 0.00, writes: 46837.98, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2678s] threads: 64, tps: 0.00, reads: 0.00, writes: 43155.01, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2679s] threads: 64, tps: 0.00, reads: 0.00, writes: 42833.05, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2680s] threads: 64, tps: 0.00, reads: 0.00, writes: 43726.95, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2681s] threads: 64, tps: 0.00, reads: 0.00, writes: 48460.09, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2682s] threads: 64, tps: 0.00, reads: 0.00, writes: 46157.90, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2683s] threads: 64, tps: 0.00, reads: 0.00, writes: 42662.04, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2684s] threads: 64, tps: 0.00, reads: 0.00, writes: 36979.83, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[2685s] threads: 64, tps: 0.00, reads: 0.00, writes: 46591.20, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2686s] threads: 64, tps: 0.00, reads: 0.00, writes: 46089.94, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2687s] threads: 64, tps: 0.00, reads: 0.00, writes: 46792.05, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2688s] threads: 64, tps: 0.00, reads: 0.00, writes: 43921.02, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2689s] threads: 64, tps: 0.00, reads: 0.00, writes: 43683.98, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2690s] threads: 64, tps: 0.00, reads: 0.00, writes: 47189.04, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2691s] threads: 64, tps: 0.00, reads: 0.00, writes: 42111.90, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[2692s] threads: 64, tps: 0.00, reads: 0.00, writes: 43684.09, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2693s] threads: 64, tps: 0.00, reads: 0.00, writes: 38497.00, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2694s] threads: 64, tps: 0.00, reads: 0.00, writes: 42873.00, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2695s] threads: 64, tps: 0.00, reads: 0.00, writes: 45213.03, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2696s] threads: 64, tps: 0.00, reads: 0.00, writes: 47780.76, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2697s] threads: 64, tps: 0.00, reads: 0.00, writes: 44217.14, response time: 2.15ms (95%), errors: 0.00, reconnects:  0.00
[2698s] threads: 64, tps: 0.00, reads: 0.00, writes: 39675.97, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2699s] threads: 64, tps: 0.00, reads: 0.00, writes: 37402.97, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2700s] threads: 64, tps: 0.00, reads: 0.00, writes: 46522.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2701s] threads: 64, tps: 0.00, reads: 0.00, writes: 41953.97, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2702s] threads: 64, tps: 0.00, reads: 0.00, writes: 37768.98, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2703s] threads: 64, tps: 0.00, reads: 0.00, writes: 38784.01, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2704s] threads: 64, tps: 0.00, reads: 0.00, writes: 39431.06, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2705s] threads: 64, tps: 0.00, reads: 0.00, writes: 44616.90, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2706s] threads: 64, tps: 0.00, reads: 0.00, writes: 41442.05, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[2707s] threads: 64, tps: 0.00, reads: 0.00, writes: 38749.04, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[2708s] threads: 64, tps: 0.00, reads: 0.00, writes: 38070.99, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[2709s] threads: 64, tps: 0.00, reads: 0.00, writes: 40272.97, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[2710s] threads: 64, tps: 0.00, reads: 0.00, writes: 45800.05, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2711s] threads: 64, tps: 0.00, reads: 0.00, writes: 48079.98, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2712s] threads: 64, tps: 0.00, reads: 0.00, writes: 44322.19, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2713s] threads: 64, tps: 0.00, reads: 0.00, writes: 41011.50, response time: 2.21ms (95%), errors: 0.00, reconnects:  0.00
[2714s] threads: 64, tps: 0.00, reads: 0.00, writes: 38631.26, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2715s] threads: 64, tps: 0.00, reads: 0.00, writes: 47020.97, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2716s] threads: 64, tps: 0.00, reads: 0.00, writes: 45564.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2717s] threads: 64, tps: 0.00, reads: 0.00, writes: 43446.02, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2718s] threads: 64, tps: 0.00, reads: 0.00, writes: 45441.91, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2719s] threads: 64, tps: 0.00, reads: 0.00, writes: 43247.05, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2720s] threads: 64, tps: 0.00, reads: 0.00, writes: 48309.04, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2721s] threads: 64, tps: 0.00, reads: 0.00, writes: 45188.95, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2722s] threads: 64, tps: 0.00, reads: 0.00, writes: 28665.83, response time: 6.83ms (95%), errors: 0.00, reconnects:  0.00
[2723s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.93, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2724s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.08, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[2725s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.01, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[2726s] threads: 64, tps: 0.00, reads: 0.00, writes: 35535.08, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2727s] threads: 64, tps: 0.00, reads: 0.00, writes: 45657.93, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2728s] threads: 64, tps: 0.00, reads: 0.00, writes: 49489.86, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2729s] threads: 64, tps: 0.00, reads: 0.00, writes: 47127.18, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2730s] threads: 64, tps: 0.00, reads: 0.00, writes: 38369.99, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2731s] threads: 64, tps: 0.00, reads: 0.00, writes: 37920.94, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[2732s] threads: 64, tps: 0.00, reads: 0.00, writes: 36137.04, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2733s] threads: 64, tps: 0.00, reads: 0.00, writes: 45926.02, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2734s] threads: 64, tps: 0.00, reads: 0.00, writes: 42046.96, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[2735s] threads: 64, tps: 0.00, reads: 0.00, writes: 37205.99, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[2736s] threads: 64, tps: 0.00, reads: 0.00, writes: 37033.97, response time: 2.60ms (95%), errors: 0.00, reconnects:  0.00
[2737s] threads: 64, tps: 0.00, reads: 0.00, writes: 36872.01, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2738s] threads: 64, tps: 0.00, reads: 0.00, writes: 42480.07, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2739s] threads: 64, tps: 0.00, reads: 0.00, writes: 43319.93, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2740s] threads: 64, tps: 0.00, reads: 0.00, writes: 36865.00, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2741s] threads: 64, tps: 0.00, reads: 0.00, writes: 38172.02, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2742s] threads: 64, tps: 0.00, reads: 0.00, writes: 42655.83, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2743s] threads: 64, tps: 0.00, reads: 0.00, writes: 44385.17, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2744s] threads: 64, tps: 0.00, reads: 0.00, writes: 46409.79, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[2745s] threads: 64, tps: 0.00, reads: 0.00, writes: 39756.21, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[2746s] threads: 64, tps: 0.00, reads: 0.00, writes: 42187.98, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2747s] threads: 64, tps: 0.00, reads: 0.00, writes: 41062.01, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2748s] threads: 64, tps: 0.00, reads: 0.00, writes: 47281.11, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[2749s] threads: 64, tps: 0.00, reads: 0.00, writes: 46661.85, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2750s] threads: 64, tps: 0.00, reads: 0.00, writes: 45913.05, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2751s] threads: 64, tps: 0.00, reads: 0.00, writes: 43586.92, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2752s] threads: 64, tps: 0.00, reads: 0.00, writes: 44529.04, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2753s] threads: 64, tps: 0.00, reads: 0.00, writes: 48312.01, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2754s] threads: 64, tps: 0.00, reads: 0.00, writes: 46725.99, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2755s] threads: 64, tps: 0.00, reads: 0.00, writes: 42165.98, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2756s] threads: 64, tps: 0.00, reads: 0.00, writes: 37090.03, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2757s] threads: 64, tps: 0.00, reads: 0.00, writes: 41348.02, response time: 2.23ms (95%), errors: 0.00, reconnects:  0.00
[2758s] threads: 64, tps: 0.00, reads: 0.00, writes: 47571.97, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2759s] threads: 64, tps: 0.00, reads: 0.00, writes: 40453.93, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2760s] threads: 64, tps: 0.00, reads: 0.00, writes: 40027.02, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2761s] threads: 64, tps: 0.00, reads: 0.00, writes: 43357.04, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2762s] threads: 64, tps: 0.00, reads: 0.00, writes: 43407.71, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2763s] threads: 64, tps: 0.00, reads: 0.00, writes: 48145.34, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2764s] threads: 64, tps: 0.00, reads: 0.00, writes: 45633.78, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2765s] threads: 64, tps: 0.00, reads: 0.00, writes: 43984.29, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2766s] threads: 64, tps: 0.00, reads: 0.00, writes: 44773.90, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2767s] threads: 64, tps: 0.00, reads: 0.00, writes: 44816.77, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2768s] threads: 64, tps: 0.00, reads: 0.00, writes: 46057.29, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2769s] threads: 64, tps: 0.00, reads: 0.00, writes: 44920.98, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2770s] threads: 64, tps: 0.00, reads: 0.00, writes: 39137.09, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2771s] threads: 64, tps: 0.00, reads: 0.00, writes: 36310.86, response time: 2.64ms (95%), errors: 0.00, reconnects:  0.00
[2772s] threads: 64, tps: 0.00, reads: 0.00, writes: 37495.98, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2773s] threads: 64, tps: 0.00, reads: 0.00, writes: 47393.00, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2774s] threads: 64, tps: 0.00, reads: 0.00, writes: 40245.74, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2775s] threads: 64, tps: 0.00, reads: 0.00, writes: 36982.22, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[2776s] threads: 64, tps: 0.00, reads: 0.00, writes: 36600.99, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2777s] threads: 64, tps: 0.00, reads: 0.00, writes: 37166.01, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[2778s] threads: 64, tps: 0.00, reads: 0.00, writes: 46171.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2779s] threads: 64, tps: 0.00, reads: 0.00, writes: 43605.99, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2780s] threads: 64, tps: 0.00, reads: 0.00, writes: 36349.00, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[2781s] threads: 64, tps: 0.00, reads: 0.00, writes: 39655.00, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[2782s] threads: 64, tps: 0.00, reads: 0.00, writes: 42362.06, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2783s] threads: 64, tps: 0.00, reads: 0.00, writes: 47968.94, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2784s] threads: 64, tps: 0.00, reads: 0.00, writes: 47290.03, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2785s] threads: 64, tps: 0.00, reads: 0.00, writes: 44510.97, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2786s] threads: 64, tps: 0.00, reads: 0.00, writes: 43285.99, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2787s] threads: 64, tps: 0.00, reads: 0.00, writes: 44411.78, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2788s] threads: 64, tps: 0.00, reads: 0.00, writes: 47575.19, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2789s] threads: 64, tps: 0.00, reads: 0.00, writes: 46265.99, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2790s] threads: 64, tps: 0.00, reads: 0.00, writes: 25564.28, response time: 19.30ms (95%), errors: 0.00, reconnects:  0.00
[2791s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.07, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[2792s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.93, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[2793s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.00, response time: 20.98ms (95%), errors: 0.00, reconnects:  0.00
[2794s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.02, response time: 20.94ms (95%), errors: 0.00, reconnects:  0.00
[2795s] threads: 64, tps: 0.00, reads: 0.00, writes: 3175.07, response time: 20.98ms (95%), errors: 0.00, reconnects:  0.00
[2796s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[2797s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.92, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[2798s] threads: 64, tps: 0.00, reads: 0.00, writes: 3144.01, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[2799s] threads: 64, tps: 0.00, reads: 0.00, writes: 3178.98, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[2800s] threads: 64, tps: 0.00, reads: 0.00, writes: 3137.00, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[2801s] threads: 64, tps: 0.00, reads: 0.00, writes: 32180.01, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2802s] threads: 64, tps: 0.00, reads: 0.00, writes: 46149.78, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2803s] threads: 64, tps: 0.00, reads: 0.00, writes: 48511.58, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2804s] threads: 64, tps: 0.00, reads: 0.00, writes: 47225.92, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[2805s] threads: 64, tps: 0.00, reads: 0.00, writes: 45498.04, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2806s] threads: 64, tps: 0.00, reads: 0.00, writes: 43986.01, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2807s] threads: 64, tps: 0.00, reads: 0.00, writes: 49341.01, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2808s] threads: 64, tps: 0.00, reads: 0.00, writes: 46300.99, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2809s] threads: 64, tps: 0.00, reads: 0.00, writes: 44169.03, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2810s] threads: 64, tps: 0.00, reads: 0.00, writes: 42905.02, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2811s] threads: 64, tps: 0.00, reads: 0.00, writes: 44577.97, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2812s] threads: 64, tps: 0.00, reads: 0.00, writes: 48647.99, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2813s] threads: 64, tps: 0.00, reads: 0.00, writes: 42969.99, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2814s] threads: 64, tps: 0.00, reads: 0.00, writes: 36545.96, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[2815s] threads: 64, tps: 0.00, reads: 0.00, writes: 32992.05, response time: 2.86ms (95%), errors: 0.00, reconnects:  0.00
[2816s] threads: 64, tps: 0.00, reads: 0.00, writes: 36598.98, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[2817s] threads: 64, tps: 0.00, reads: 0.00, writes: 45190.01, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2818s] threads: 64, tps: 0.00, reads: 0.00, writes: 42142.98, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[2819s] threads: 64, tps: 0.00, reads: 0.00, writes: 39500.03, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2820s] threads: 64, tps: 0.00, reads: 0.00, writes: 36582.02, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2821s] threads: 64, tps: 0.00, reads: 0.00, writes: 38292.98, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2822s] threads: 64, tps: 0.00, reads: 0.00, writes: 40619.01, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2823s] threads: 64, tps: 0.00, reads: 0.00, writes: 45477.99, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2824s] threads: 64, tps: 0.00, reads: 0.00, writes: 45648.04, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2825s] threads: 64, tps: 0.00, reads: 0.00, writes: 44029.96, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2826s] threads: 64, tps: 0.00, reads: 0.00, writes: 43160.05, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2827s] threads: 64, tps: 0.00, reads: 0.00, writes: 48064.90, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2828s] threads: 64, tps: 0.00, reads: 0.00, writes: 45606.01, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2829s] threads: 64, tps: 0.00, reads: 0.00, writes: 40942.01, response time: 2.28ms (95%), errors: 0.00, reconnects:  0.00
[2830s] threads: 64, tps: 0.00, reads: 0.00, writes: 43742.06, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2831s] threads: 64, tps: 0.00, reads: 0.00, writes: 44393.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2832s] threads: 64, tps: 0.00, reads: 0.00, writes: 48814.96, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2833s] threads: 64, tps: 0.00, reads: 0.00, writes: 47304.96, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2834s] threads: 64, tps: 0.00, reads: 0.00, writes: 42124.05, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2835s] threads: 64, tps: 0.00, reads: 0.00, writes: 42843.99, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2836s] threads: 64, tps: 0.00, reads: 0.00, writes: 46429.92, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2837s] threads: 64, tps: 0.00, reads: 0.00, writes: 47013.04, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2838s] threads: 64, tps: 0.00, reads: 0.00, writes: 29116.06, response time: 3.09ms (95%), errors: 0.00, reconnects:  0.00
[2839s] threads: 64, tps: 0.00, reads: 0.00, writes: 24025.78, response time: 19.77ms (95%), errors: 0.00, reconnects:  0.00
[2840s] threads: 64, tps: 0.00, reads: 0.00, writes: 45693.01, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2841s] threads: 64, tps: 0.00, reads: 0.00, writes: 35343.53, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[2842s] threads: 64, tps: 0.00, reads: 0.00, writes: 46050.65, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2843s] threads: 64, tps: 0.00, reads: 0.00, writes: 44414.80, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2844s] threads: 64, tps: 0.00, reads: 0.00, writes: 45027.20, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2845s] threads: 64, tps: 0.00, reads: 0.00, writes: 44113.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2846s] threads: 64, tps: 0.00, reads: 0.00, writes: 37999.98, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2847s] threads: 64, tps: 0.00, reads: 0.00, writes: 45257.84, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[2848s] threads: 64, tps: 0.00, reads: 0.00, writes: 43691.18, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2849s] threads: 64, tps: 0.00, reads: 0.00, writes: 45701.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2850s] threads: 64, tps: 0.00, reads: 0.00, writes: 44436.82, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[2851s] threads: 64, tps: 0.00, reads: 0.00, writes: 44723.21, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2852s] threads: 64, tps: 0.00, reads: 0.00, writes: 48021.98, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[2853s] threads: 64, tps: 0.00, reads: 0.00, writes: 47048.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2854s] threads: 64, tps: 0.00, reads: 0.00, writes: 43568.97, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2855s] threads: 64, tps: 0.00, reads: 0.00, writes: 44626.98, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2856s] threads: 64, tps: 0.00, reads: 0.00, writes: 46587.99, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2857s] threads: 64, tps: 0.00, reads: 0.00, writes: 46833.07, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2858s] threads: 64, tps: 0.00, reads: 0.00, writes: 46723.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2859s] threads: 64, tps: 0.00, reads: 0.00, writes: 43884.93, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2860s] threads: 64, tps: 0.00, reads: 0.00, writes: 42824.02, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2861s] threads: 64, tps: 0.00, reads: 0.00, writes: 47974.05, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[2862s] threads: 64, tps: 0.00, reads: 0.00, writes: 47058.97, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2863s] threads: 64, tps: 0.00, reads: 0.00, writes: 43645.02, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2864s] threads: 64, tps: 0.00, reads: 0.00, writes: 43794.93, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2865s] threads: 64, tps: 0.00, reads: 0.00, writes: 41642.00, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2866s] threads: 64, tps: 0.00, reads: 0.00, writes: 48120.21, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2867s] threads: 64, tps: 0.00, reads: 0.00, writes: 42204.01, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2868s] threads: 64, tps: 0.00, reads: 0.00, writes: 45239.97, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2869s] threads: 64, tps: 0.00, reads: 0.00, writes: 43329.00, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2870s] threads: 64, tps: 0.00, reads: 0.00, writes: 40228.00, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[2871s] threads: 64, tps: 0.00, reads: 0.00, writes: 44948.99, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2872s] threads: 64, tps: 0.00, reads: 0.00, writes: 40713.81, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[2873s] threads: 64, tps: 0.00, reads: 0.00, writes: 31251.99, response time: 2.67ms (95%), errors: 0.00, reconnects:  0.00
[2874s] threads: 64, tps: 0.00, reads: 0.00, writes: 44232.04, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2875s] threads: 64, tps: 0.00, reads: 0.00, writes: 43437.96, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[2876s] threads: 64, tps: 0.00, reads: 0.00, writes: 47800.03, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2877s] threads: 64, tps: 0.00, reads: 0.00, writes: 42574.88, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2878s] threads: 64, tps: 0.00, reads: 0.00, writes: 39120.11, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[2879s] threads: 64, tps: 0.00, reads: 0.00, writes: 41729.97, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[2880s] threads: 64, tps: 0.00, reads: 0.00, writes: 45268.04, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2881s] threads: 64, tps: 0.00, reads: 0.00, writes: 47817.04, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2882s] threads: 64, tps: 0.00, reads: 0.00, writes: 47699.96, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2883s] threads: 64, tps: 0.00, reads: 0.00, writes: 44650.00, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2884s] threads: 64, tps: 0.00, reads: 0.00, writes: 45002.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[2885s] threads: 64, tps: 0.00, reads: 0.00, writes: 47888.99, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2886s] threads: 64, tps: 0.00, reads: 0.00, writes: 47672.04, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2887s] threads: 64, tps: 0.00, reads: 0.00, writes: 45737.96, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2888s] threads: 64, tps: 0.00, reads: 0.00, writes: 43327.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2889s] threads: 64, tps: 0.00, reads: 0.00, writes: 43731.08, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2890s] threads: 64, tps: 0.00, reads: 0.00, writes: 48899.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2891s] threads: 64, tps: 0.00, reads: 0.00, writes: 46285.05, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2892s] threads: 64, tps: 0.00, reads: 0.00, writes: 42581.97, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2893s] threads: 64, tps: 0.00, reads: 0.00, writes: 43382.99, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2894s] threads: 64, tps: 0.00, reads: 0.00, writes: 43972.03, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[2895s] threads: 64, tps: 0.00, reads: 0.00, writes: 46503.00, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2896s] threads: 64, tps: 0.00, reads: 0.00, writes: 33033.95, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2897s] threads: 64, tps: 0.00, reads: 0.00, writes: 44741.85, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2898s] threads: 64, tps: 0.00, reads: 0.00, writes: 45165.17, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2899s] threads: 64, tps: 0.00, reads: 0.00, writes: 43771.08, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2900s] threads: 64, tps: 0.00, reads: 0.00, writes: 47697.98, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2901s] threads: 64, tps: 0.00, reads: 0.00, writes: 45705.88, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2902s] threads: 64, tps: 0.00, reads: 0.00, writes: 38195.09, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[2903s] threads: 64, tps: 0.00, reads: 0.00, writes: 37089.97, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[2904s] threads: 64, tps: 0.00, reads: 0.00, writes: 41812.39, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[2905s] threads: 64, tps: 0.00, reads: 0.00, writes: 47709.02, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2906s] threads: 64, tps: 0.00, reads: 0.00, writes: 46247.02, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[2907s] threads: 64, tps: 0.00, reads: 0.00, writes: 41348.00, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[2908s] threads: 64, tps: 0.00, reads: 0.00, writes: 43125.96, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2909s] threads: 64, tps: 0.00, reads: 0.00, writes: 46008.97, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2910s] threads: 64, tps: 0.00, reads: 0.00, writes: 45464.04, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2911s] threads: 64, tps: 0.00, reads: 0.00, writes: 38935.97, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[2912s] threads: 64, tps: 0.00, reads: 0.00, writes: 41203.08, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[2913s] threads: 64, tps: 0.00, reads: 0.00, writes: 43185.90, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2914s] threads: 64, tps: 0.00, reads: 0.00, writes: 45587.04, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2915s] threads: 64, tps: 0.00, reads: 0.00, writes: 47461.02, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2916s] threads: 64, tps: 0.00, reads: 0.00, writes: 45281.98, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2917s] threads: 64, tps: 0.00, reads: 0.00, writes: 43202.98, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[2918s] threads: 64, tps: 0.00, reads: 0.00, writes: 43829.05, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[2919s] threads: 64, tps: 0.00, reads: 0.00, writes: 45596.01, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2920s] threads: 64, tps: 0.00, reads: 0.00, writes: 45910.99, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[2921s] threads: 64, tps: 0.00, reads: 0.00, writes: 43911.95, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[2922s] threads: 64, tps: 0.00, reads: 0.00, writes: 43452.04, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2923s] threads: 64, tps: 0.00, reads: 0.00, writes: 45587.95, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2924s] threads: 64, tps: 0.00, reads: 0.00, writes: 48509.09, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[2925s] threads: 64, tps: 0.00, reads: 0.00, writes: 47346.76, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2926s] threads: 64, tps: 0.00, reads: 0.00, writes: 19293.04, response time: 20.29ms (95%), errors: 0.00, reconnects:  0.00
[2927s] threads: 64, tps: 0.00, reads: 0.00, writes: 3145.92, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[2928s] threads: 64, tps: 0.00, reads: 0.00, writes: 3146.06, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[2929s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.93, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[2930s] threads: 64, tps: 0.00, reads: 0.00, writes: 3145.99, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[2931s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.99, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[2932s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.10, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[2933s] threads: 64, tps: 0.00, reads: 0.00, writes: 28855.04, response time: 5.80ms (95%), errors: 0.00, reconnects:  0.00
[2934s] threads: 64, tps: 0.00, reads: 0.00, writes: 44287.00, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[2935s] threads: 64, tps: 0.00, reads: 0.00, writes: 47261.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2936s] threads: 64, tps: 0.00, reads: 0.00, writes: 40964.06, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[2937s] threads: 64, tps: 0.00, reads: 0.00, writes: 39345.89, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[2938s] threads: 64, tps: 0.00, reads: 0.00, writes: 43828.06, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2939s] threads: 64, tps: 0.00, reads: 0.00, writes: 44408.03, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[2940s] threads: 64, tps: 0.00, reads: 0.00, writes: 48780.92, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[2941s] threads: 64, tps: 0.00, reads: 0.00, writes: 45567.08, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[2942s] threads: 64, tps: 0.00, reads: 0.00, writes: 42097.98, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2943s] threads: 64, tps: 0.00, reads: 0.00, writes: 41899.02, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[2944s] threads: 64, tps: 0.00, reads: 0.00, writes: 43449.01, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2945s] threads: 64, tps: 0.00, reads: 0.00, writes: 46797.98, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[2946s] threads: 64, tps: 0.00, reads: 0.00, writes: 44690.95, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[2947s] threads: 64, tps: 0.00, reads: 0.00, writes: 37447.00, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2948s] threads: 64, tps: 0.00, reads: 0.00, writes: 37377.98, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[2949s] threads: 64, tps: 0.00, reads: 0.00, writes: 36735.03, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[2950s] threads: 64, tps: 0.00, reads: 0.00, writes: 45658.08, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2951s] threads: 64, tps: 0.00, reads: 0.00, writes: 41855.95, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[2952s] threads: 64, tps: 0.00, reads: 0.00, writes: 38364.98, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[2953s] threads: 64, tps: 0.00, reads: 0.00, writes: 37185.05, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[2954s] threads: 64, tps: 0.00, reads: 0.00, writes: 44256.92, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[2955s] threads: 64, tps: 0.00, reads: 0.00, writes: 48009.04, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2956s] threads: 64, tps: 0.00, reads: 0.00, writes: 46284.97, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2957s] threads: 64, tps: 0.00, reads: 0.00, writes: 44917.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2958s] threads: 64, tps: 0.00, reads: 0.00, writes: 43610.03, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2959s] threads: 64, tps: 0.00, reads: 0.00, writes: 45406.01, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2960s] threads: 64, tps: 0.00, reads: 0.00, writes: 47134.03, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[2961s] threads: 64, tps: 0.00, reads: 0.00, writes: 45806.90, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[2962s] threads: 64, tps: 0.00, reads: 0.00, writes: 42308.01, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[2963s] threads: 64, tps: 0.00, reads: 0.00, writes: 44412.95, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[2964s] threads: 64, tps: 0.00, reads: 0.00, writes: 46612.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2965s] threads: 64, tps: 0.00, reads: 0.00, writes: 47164.11, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[2966s] threads: 64, tps: 0.00, reads: 0.00, writes: 42873.91, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[2967s] threads: 64, tps: 0.00, reads: 0.00, writes: 3135.98, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[2968s] threads: 64, tps: 0.00, reads: 0.00, writes: 3189.04, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[2969s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.94, response time: 21.03ms (95%), errors: 0.00, reconnects:  0.00
[2970s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.00, response time: 21.05ms (95%), errors: 0.00, reconnects:  0.00
[2971s] threads: 64, tps: 0.00, reads: 0.00, writes: 25220.87, response time: 10.30ms (95%), errors: 0.00, reconnects:  0.00
[2972s] threads: 64, tps: 0.00, reads: 0.00, writes: 39814.05, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2973s] threads: 64, tps: 0.00, reads: 0.00, writes: 48097.96, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[2974s] threads: 64, tps: 0.00, reads: 0.00, writes: 45645.82, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[2975s] threads: 64, tps: 0.00, reads: 0.00, writes: 41536.20, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[2976s] threads: 64, tps: 0.00, reads: 0.00, writes: 44238.00, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2977s] threads: 64, tps: 0.00, reads: 0.00, writes: 42102.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[2978s] threads: 64, tps: 0.00, reads: 0.00, writes: 48969.03, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2979s] threads: 64, tps: 0.00, reads: 0.00, writes: 45823.96, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[2980s] threads: 64, tps: 0.00, reads: 0.00, writes: 41024.89, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[2981s] threads: 64, tps: 0.00, reads: 0.00, writes: 42151.14, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[2982s] threads: 64, tps: 0.00, reads: 0.00, writes: 43502.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2983s] threads: 64, tps: 0.00, reads: 0.00, writes: 45767.85, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2984s] threads: 64, tps: 0.00, reads: 0.00, writes: 39623.07, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[2985s] threads: 64, tps: 0.00, reads: 0.00, writes: 39588.97, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[2986s] threads: 64, tps: 0.00, reads: 0.00, writes: 39313.04, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[2987s] threads: 64, tps: 0.00, reads: 0.00, writes: 36916.97, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[2988s] threads: 64, tps: 0.00, reads: 0.00, writes: 48143.06, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[2989s] threads: 64, tps: 0.00, reads: 0.00, writes: 45772.05, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[2990s] threads: 64, tps: 0.00, reads: 0.00, writes: 41022.00, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[2991s] threads: 64, tps: 0.00, reads: 0.00, writes: 43656.99, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[2992s] threads: 64, tps: 0.00, reads: 0.00, writes: 43796.82, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[2993s] threads: 64, tps: 0.00, reads: 0.00, writes: 48080.20, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[2994s] threads: 64, tps: 0.00, reads: 0.00, writes: 46199.99, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2995s] threads: 64, tps: 0.00, reads: 0.00, writes: 41774.97, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[2996s] threads: 64, tps: 0.00, reads: 0.00, writes: 45174.02, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[2997s] threads: 64, tps: 0.00, reads: 0.00, writes: 45736.04, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[2998s] threads: 64, tps: 0.00, reads: 0.00, writes: 46433.99, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[2999s] threads: 64, tps: 0.00, reads: 0.00, writes: 33858.02, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[3000s] threads: 64, tps: 0.00, reads: 0.00, writes: 43834.95, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3001s] threads: 64, tps: 0.00, reads: 0.00, writes: 42734.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3002s] threads: 64, tps: 0.00, reads: 0.00, writes: 46440.96, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3003s] threads: 64, tps: 0.00, reads: 0.00, writes: 47981.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3004s] threads: 64, tps: 0.00, reads: 0.00, writes: 45141.00, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3005s] threads: 64, tps: 0.00, reads: 0.00, writes: 12000.64, response time: 20.70ms (95%), errors: 0.00, reconnects:  0.00
[3006s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.06, response time: 20.91ms (95%), errors: 0.00, reconnects:  0.00
[3007s] threads: 64, tps: 0.00, reads: 0.00, writes: 6390.06, response time: 20.67ms (95%), errors: 0.00, reconnects:  0.00
[3008s] threads: 64, tps: 0.00, reads: 0.00, writes: 45747.06, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3009s] threads: 64, tps: 0.00, reads: 0.00, writes: 45271.92, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3010s] threads: 64, tps: 0.00, reads: 0.00, writes: 47194.09, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[3011s] threads: 64, tps: 0.00, reads: 0.00, writes: 46205.98, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3012s] threads: 64, tps: 0.00, reads: 0.00, writes: 46272.93, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3013s] threads: 64, tps: 0.00, reads: 0.00, writes: 43945.12, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3014s] threads: 64, tps: 0.00, reads: 0.00, writes: 47787.97, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[3015s] threads: 64, tps: 0.00, reads: 0.00, writes: 48025.97, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[3016s] threads: 64, tps: 0.00, reads: 0.00, writes: 44189.99, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3017s] threads: 64, tps: 0.00, reads: 0.00, writes: 43957.96, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3018s] threads: 64, tps: 0.00, reads: 0.00, writes: 43575.11, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3019s] threads: 64, tps: 0.00, reads: 0.00, writes: 48030.94, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3020s] threads: 64, tps: 0.00, reads: 0.00, writes: 40327.01, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3021s] threads: 64, tps: 0.00, reads: 0.00, writes: 36999.92, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3022s] threads: 64, tps: 0.00, reads: 0.00, writes: 37351.06, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[3023s] threads: 64, tps: 0.00, reads: 0.00, writes: 38939.04, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[3024s] threads: 64, tps: 0.00, reads: 0.00, writes: 46983.90, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3025s] threads: 64, tps: 0.00, reads: 0.00, writes: 44038.99, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3026s] threads: 64, tps: 0.00, reads: 0.00, writes: 38189.04, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[3027s] threads: 64, tps: 0.00, reads: 0.00, writes: 39220.99, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3028s] threads: 64, tps: 0.00, reads: 0.00, writes: 39636.04, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[3029s] threads: 64, tps: 0.00, reads: 0.00, writes: 47506.96, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3030s] threads: 64, tps: 0.00, reads: 0.00, writes: 47783.03, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3031s] threads: 64, tps: 0.00, reads: 0.00, writes: 46805.95, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3032s] threads: 64, tps: 0.00, reads: 0.00, writes: 44206.00, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3033s] threads: 64, tps: 0.00, reads: 0.00, writes: 46246.50, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3034s] threads: 64, tps: 0.00, reads: 0.00, writes: 47858.82, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3035s] threads: 64, tps: 0.00, reads: 0.00, writes: 47918.82, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3036s] threads: 64, tps: 0.00, reads: 0.00, writes: 11098.73, response time: 20.77ms (95%), errors: 0.00, reconnects:  0.00
[3037s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.98, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[3038s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.02, response time: 21.09ms (95%), errors: 0.00, reconnects:  0.00
[3039s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.04, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[3040s] threads: 64, tps: 0.00, reads: 0.00, writes: 3135.92, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[3041s] threads: 64, tps: 0.00, reads: 0.00, writes: 3179.04, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[3042s] threads: 64, tps: 0.00, reads: 0.00, writes: 3139.99, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[3043s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.02, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[3044s] threads: 64, tps: 0.00, reads: 0.00, writes: 3167.03, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[3045s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.00, response time: 21.25ms (95%), errors: 0.00, reconnects:  0.00
[3046s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.00, response time: 21.24ms (95%), errors: 0.00, reconnects:  0.00
[3047s] threads: 64, tps: 0.00, reads: 0.00, writes: 3141.95, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[3048s] threads: 64, tps: 0.00, reads: 0.00, writes: 3145.98, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[3049s] threads: 64, tps: 0.00, reads: 0.00, writes: 3184.00, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[3050s] threads: 64, tps: 0.00, reads: 0.00, writes: 3140.00, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[3051s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.08, response time: 21.17ms (95%), errors: 0.00, reconnects:  0.00
[3052s] threads: 64, tps: 0.00, reads: 0.00, writes: 3137.93, response time: 21.56ms (95%), errors: 0.00, reconnects:  0.00
[3053s] threads: 64, tps: 0.00, reads: 0.00, writes: 39965.95, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3054s] threads: 64, tps: 0.00, reads: 0.00, writes: 47031.88, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[3055s] threads: 64, tps: 0.00, reads: 0.00, writes: 44257.08, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3056s] threads: 64, tps: 0.00, reads: 0.00, writes: 38113.01, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[3057s] threads: 64, tps: 0.00, reads: 0.00, writes: 36626.99, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3058s] threads: 64, tps: 0.00, reads: 0.00, writes: 37746.96, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[3059s] threads: 64, tps: 0.00, reads: 0.00, writes: 43284.99, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3060s] threads: 64, tps: 0.00, reads: 0.00, writes: 45026.18, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3061s] threads: 64, tps: 0.00, reads: 0.00, writes: 37886.99, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[3062s] threads: 64, tps: 0.00, reads: 0.00, writes: 44660.97, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3063s] threads: 64, tps: 0.00, reads: 0.00, writes: 43414.01, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3064s] threads: 64, tps: 0.00, reads: 0.00, writes: 48335.92, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3065s] threads: 64, tps: 0.00, reads: 0.00, writes: 47790.13, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3066s] threads: 64, tps: 0.00, reads: 0.00, writes: 44486.93, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3067s] threads: 64, tps: 0.00, reads: 0.00, writes: 44284.03, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3068s] threads: 64, tps: 0.00, reads: 0.00, writes: 43583.65, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3069s] threads: 64, tps: 0.00, reads: 0.00, writes: 49580.59, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[3070s] threads: 64, tps: 0.00, reads: 0.00, writes: 46023.91, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3071s] threads: 64, tps: 0.00, reads: 0.00, writes: 42616.07, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3072s] threads: 64, tps: 0.00, reads: 0.00, writes: 40795.94, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[3073s] threads: 64, tps: 0.00, reads: 0.00, writes: 41899.35, response time: 2.32ms (95%), errors: 0.00, reconnects:  0.00
[3074s] threads: 64, tps: 0.00, reads: 0.00, writes: 46925.74, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3075s] threads: 64, tps: 0.00, reads: 0.00, writes: 32884.97, response time: 2.71ms (95%), errors: 0.00, reconnects:  0.00
[3076s] threads: 64, tps: 0.00, reads: 0.00, writes: 38438.01, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[3077s] threads: 64, tps: 0.00, reads: 0.00, writes: 38043.02, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[3078s] threads: 64, tps: 0.00, reads: 0.00, writes: 37719.20, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[3079s] threads: 64, tps: 0.00, reads: 0.00, writes: 48126.35, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3080s] threads: 64, tps: 0.00, reads: 0.00, writes: 41434.06, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[3081s] threads: 64, tps: 0.00, reads: 0.00, writes: 43028.94, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3082s] threads: 64, tps: 0.00, reads: 0.00, writes: 44590.85, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3083s] threads: 64, tps: 0.00, reads: 0.00, writes: 44468.16, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3084s] threads: 64, tps: 0.00, reads: 0.00, writes: 47640.03, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3085s] threads: 64, tps: 0.00, reads: 0.00, writes: 46242.93, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3086s] threads: 64, tps: 0.00, reads: 0.00, writes: 43811.05, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3087s] threads: 64, tps: 0.00, reads: 0.00, writes: 42308.00, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3088s] threads: 64, tps: 0.00, reads: 0.00, writes: 44370.02, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3089s] threads: 64, tps: 0.00, reads: 0.00, writes: 47340.02, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3090s] threads: 64, tps: 0.00, reads: 0.00, writes: 45408.01, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3091s] threads: 64, tps: 0.00, reads: 0.00, writes: 21817.41, response time: 20.00ms (95%), errors: 0.00, reconnects:  0.00
[3092s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.02, response time: 21.59ms (95%), errors: 0.00, reconnects:  0.00
[3093s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.05, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[3094s] threads: 64, tps: 0.00, reads: 0.00, writes: 3147.91, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[3095s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.00, response time: 21.02ms (95%), errors: 0.00, reconnects:  0.00
[3096s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.99, response time: 21.19ms (95%), errors: 0.00, reconnects:  0.00
[3097s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.09, response time: 21.25ms (95%), errors: 0.00, reconnects:  0.00
[3098s] threads: 64, tps: 0.00, reads: 0.00, writes: 3164.91, response time: 21.04ms (95%), errors: 0.00, reconnects:  0.00
[3099s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.03, response time: 21.01ms (95%), errors: 0.00, reconnects:  0.00
[3100s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.07, response time: 21.17ms (95%), errors: 0.00, reconnects:  0.00
[3101s] threads: 64, tps: 0.00, reads: 0.00, writes: 23184.98, response time: 19.27ms (95%), errors: 0.00, reconnects:  0.00
[3102s] threads: 64, tps: 0.00, reads: 0.00, writes: 43281.05, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[3103s] threads: 64, tps: 0.00, reads: 0.00, writes: 48200.01, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[3104s] threads: 64, tps: 0.00, reads: 0.00, writes: 46295.98, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3105s] threads: 64, tps: 0.00, reads: 0.00, writes: 44742.03, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3106s] threads: 64, tps: 0.00, reads: 0.00, writes: 43646.96, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3107s] threads: 64, tps: 0.00, reads: 0.00, writes: 46638.91, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3108s] threads: 64, tps: 0.00, reads: 0.00, writes: 47000.12, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3109s] threads: 64, tps: 0.00, reads: 0.00, writes: 45716.03, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3110s] threads: 64, tps: 0.00, reads: 0.00, writes: 39356.97, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3111s] threads: 64, tps: 0.00, reads: 0.00, writes: 40255.93, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[3112s] threads: 64, tps: 0.00, reads: 0.00, writes: 48712.01, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[3113s] threads: 64, tps: 0.00, reads: 0.00, writes: 48077.06, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3114s] threads: 64, tps: 0.00, reads: 0.00, writes: 45171.03, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3115s] threads: 64, tps: 0.00, reads: 0.00, writes: 42797.79, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3116s] threads: 64, tps: 0.00, reads: 0.00, writes: 42858.18, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3117s] threads: 64, tps: 0.00, reads: 0.00, writes: 48058.95, response time: 1.72ms (95%), errors: 0.00, reconnects:  0.00
[3118s] threads: 64, tps: 0.00, reads: 0.00, writes: 41454.83, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3119s] threads: 64, tps: 0.00, reads: 0.00, writes: 35190.19, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[3120s] threads: 64, tps: 0.00, reads: 0.00, writes: 36821.94, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[3121s] threads: 64, tps: 0.00, reads: 0.00, writes: 37321.00, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[3122s] threads: 64, tps: 0.00, reads: 0.00, writes: 47280.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3123s] threads: 64, tps: 0.00, reads: 0.00, writes: 40275.01, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[3124s] threads: 64, tps: 0.00, reads: 0.00, writes: 42778.03, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3125s] threads: 64, tps: 0.00, reads: 0.00, writes: 43035.05, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3126s] threads: 64, tps: 0.00, reads: 0.00, writes: 43951.01, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3127s] threads: 64, tps: 0.00, reads: 0.00, writes: 47936.97, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3128s] threads: 64, tps: 0.00, reads: 0.00, writes: 45729.00, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3129s] threads: 64, tps: 0.00, reads: 0.00, writes: 41525.99, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3130s] threads: 64, tps: 0.00, reads: 0.00, writes: 43867.03, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3131s] threads: 64, tps: 0.00, reads: 0.00, writes: 44714.90, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3132s] threads: 64, tps: 0.00, reads: 0.00, writes: 46773.06, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[3133s] threads: 64, tps: 0.00, reads: 0.00, writes: 45895.02, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3134s] threads: 64, tps: 0.00, reads: 0.00, writes: 43900.97, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3135s] threads: 64, tps: 0.00, reads: 0.00, writes: 42682.99, response time: 2.13ms (95%), errors: 0.00, reconnects:  0.00
[3136s] threads: 64, tps: 0.00, reads: 0.00, writes: 45961.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3137s] threads: 64, tps: 0.00, reads: 0.00, writes: 46121.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3138s] threads: 64, tps: 0.00, reads: 0.00, writes: 45140.98, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3139s] threads: 64, tps: 0.00, reads: 0.00, writes: 4374.98, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[3140s] threads: 64, tps: 0.00, reads: 0.00, writes: 3144.92, response time: 21.37ms (95%), errors: 0.00, reconnects:  0.00
[3141s] threads: 64, tps: 0.00, reads: 0.00, writes: 32887.96, response time: 2.91ms (95%), errors: 0.00, reconnects:  0.00
[3142s] threads: 64, tps: 0.00, reads: 0.00, writes: 40892.42, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3143s] threads: 64, tps: 0.00, reads: 0.00, writes: 47695.03, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3144s] threads: 64, tps: 0.00, reads: 0.00, writes: 45149.99, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3145s] threads: 64, tps: 0.00, reads: 0.00, writes: 47341.03, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3146s] threads: 64, tps: 0.00, reads: 0.00, writes: 44897.96, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3147s] threads: 64, tps: 0.00, reads: 0.00, writes: 41547.01, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3148s] threads: 64, tps: 0.00, reads: 0.00, writes: 47204.02, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3149s] threads: 64, tps: 0.00, reads: 0.00, writes: 42245.97, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3150s] threads: 64, tps: 0.00, reads: 0.00, writes: 38158.97, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[3151s] threads: 64, tps: 0.00, reads: 0.00, writes: 36978.98, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3152s] threads: 64, tps: 0.00, reads: 0.00, writes: 37091.90, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[3153s] threads: 64, tps: 0.00, reads: 0.00, writes: 45053.15, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3154s] threads: 64, tps: 0.00, reads: 0.00, writes: 42557.02, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[3155s] threads: 64, tps: 0.00, reads: 0.00, writes: 43731.04, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3156s] threads: 64, tps: 0.00, reads: 0.00, writes: 42225.55, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3157s] threads: 64, tps: 0.00, reads: 0.00, writes: 43713.44, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3158s] threads: 64, tps: 0.00, reads: 0.00, writes: 47472.06, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3159s] threads: 64, tps: 0.00, reads: 0.00, writes: 46768.01, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3160s] threads: 64, tps: 0.00, reads: 0.00, writes: 42830.95, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3161s] threads: 64, tps: 0.00, reads: 0.00, writes: 43226.05, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3162s] threads: 64, tps: 0.00, reads: 0.00, writes: 43461.95, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3163s] threads: 64, tps: 0.00, reads: 0.00, writes: 47142.04, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3164s] threads: 64, tps: 0.00, reads: 0.00, writes: 45428.99, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3165s] threads: 64, tps: 0.00, reads: 0.00, writes: 42827.96, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3166s] threads: 64, tps: 0.00, reads: 0.00, writes: 43439.97, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3167s] threads: 64, tps: 0.00, reads: 0.00, writes: 46265.96, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3168s] threads: 64, tps: 0.00, reads: 0.00, writes: 46894.10, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3169s] threads: 64, tps: 0.00, reads: 0.00, writes: 45614.02, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3170s] threads: 64, tps: 0.00, reads: 0.00, writes: 43051.79, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3171s] threads: 64, tps: 0.00, reads: 0.00, writes: 44176.21, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3172s] threads: 64, tps: 0.00, reads: 0.00, writes: 48729.87, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3173s] threads: 64, tps: 0.00, reads: 0.00, writes: 46728.91, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3174s] threads: 64, tps: 0.00, reads: 0.00, writes: 38200.02, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3175s] threads: 64, tps: 0.00, reads: 0.00, writes: 11611.17, response time: 20.67ms (95%), errors: 0.00, reconnects:  0.00
[3176s] threads: 64, tps: 0.00, reads: 0.00, writes: 38906.62, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[3177s] threads: 64, tps: 0.00, reads: 0.00, writes: 37995.94, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[3178s] threads: 64, tps: 0.00, reads: 0.00, writes: 48530.84, response time: 1.73ms (95%), errors: 0.00, reconnects:  0.00
[3179s] threads: 64, tps: 0.00, reads: 0.00, writes: 46476.93, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[3180s] threads: 64, tps: 0.00, reads: 0.00, writes: 44696.26, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3181s] threads: 64, tps: 0.00, reads: 0.00, writes: 43373.94, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3182s] threads: 64, tps: 0.00, reads: 0.00, writes: 46032.02, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3183s] threads: 64, tps: 0.00, reads: 0.00, writes: 45251.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3184s] threads: 64, tps: 0.00, reads: 0.00, writes: 45885.04, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3185s] threads: 64, tps: 0.00, reads: 0.00, writes: 38756.94, response time: 2.44ms (95%), errors: 0.00, reconnects:  0.00
[3186s] threads: 64, tps: 0.00, reads: 0.00, writes: 38027.79, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3187s] threads: 64, tps: 0.00, reads: 0.00, writes: 40448.15, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3188s] threads: 64, tps: 0.00, reads: 0.00, writes: 46430.58, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3189s] threads: 64, tps: 0.00, reads: 0.00, writes: 38579.14, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3190s] threads: 64, tps: 0.00, reads: 0.00, writes: 36633.06, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[3191s] threads: 64, tps: 0.00, reads: 0.00, writes: 40290.00, response time: 2.39ms (95%), errors: 0.00, reconnects:  0.00
[3192s] threads: 64, tps: 0.00, reads: 0.00, writes: 43334.03, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3193s] threads: 64, tps: 0.00, reads: 0.00, writes: 47065.00, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3194s] threads: 64, tps: 0.00, reads: 0.00, writes: 45694.85, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3195s] threads: 64, tps: 0.00, reads: 0.00, writes: 42367.14, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3196s] threads: 64, tps: 0.00, reads: 0.00, writes: 43292.95, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3197s] threads: 64, tps: 0.00, reads: 0.00, writes: 45662.07, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3198s] threads: 64, tps: 0.00, reads: 0.00, writes: 47619.01, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[3199s] threads: 64, tps: 0.00, reads: 0.00, writes: 44078.95, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3200s] threads: 64, tps: 0.00, reads: 0.00, writes: 42147.78, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3201s] threads: 64, tps: 0.00, reads: 0.00, writes: 43564.24, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3202s] threads: 64, tps: 0.00, reads: 0.00, writes: 46375.74, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3203s] threads: 64, tps: 0.00, reads: 0.00, writes: 35298.06, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3204s] threads: 64, tps: 0.00, reads: 0.00, writes: 43526.05, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3205s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.04, response time: 21.28ms (95%), errors: 0.00, reconnects:  0.00
[3206s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.92, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[3207s] threads: 64, tps: 0.00, reads: 0.00, writes: 3140.94, response time: 21.20ms (95%), errors: 0.00, reconnects:  0.00
[3208s] threads: 64, tps: 0.00, reads: 0.00, writes: 3169.05, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[3209s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.08, response time: 21.15ms (95%), errors: 0.00, reconnects:  0.00
[3210s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.93, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[3211s] threads: 64, tps: 0.00, reads: 0.00, writes: 6863.24, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[3212s] threads: 64, tps: 0.00, reads: 0.00, writes: 44523.04, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3213s] threads: 64, tps: 0.00, reads: 0.00, writes: 45706.03, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3214s] threads: 64, tps: 0.00, reads: 0.00, writes: 47122.94, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3215s] threads: 64, tps: 0.00, reads: 0.00, writes: 44757.07, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3216s] threads: 64, tps: 0.00, reads: 0.00, writes: 43901.95, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3217s] threads: 64, tps: 0.00, reads: 0.00, writes: 38287.98, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[3218s] threads: 64, tps: 0.00, reads: 0.00, writes: 40103.03, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3219s] threads: 64, tps: 0.00, reads: 0.00, writes: 44382.97, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3220s] threads: 64, tps: 0.00, reads: 0.00, writes: 39143.98, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3221s] threads: 64, tps: 0.00, reads: 0.00, writes: 40302.99, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[3222s] threads: 64, tps: 0.00, reads: 0.00, writes: 38979.00, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3223s] threads: 64, tps: 0.00, reads: 0.00, writes: 39955.00, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3224s] threads: 64, tps: 0.00, reads: 0.00, writes: 45986.83, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3225s] threads: 64, tps: 0.00, reads: 0.00, writes: 39024.02, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3226s] threads: 64, tps: 0.00, reads: 0.00, writes: 37898.11, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[3227s] threads: 64, tps: 0.00, reads: 0.00, writes: 38911.05, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3228s] threads: 64, tps: 0.00, reads: 0.00, writes: 38285.01, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[3229s] threads: 64, tps: 0.00, reads: 0.00, writes: 46608.77, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3230s] threads: 64, tps: 0.00, reads: 0.00, writes: 45073.21, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3231s] threads: 64, tps: 0.00, reads: 0.00, writes: 44034.00, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3232s] threads: 64, tps: 0.00, reads: 0.00, writes: 43533.01, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3233s] threads: 64, tps: 0.00, reads: 0.00, writes: 44448.06, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3234s] threads: 64, tps: 0.00, reads: 0.00, writes: 47762.98, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3235s] threads: 64, tps: 0.00, reads: 0.00, writes: 47797.89, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3236s] threads: 64, tps: 0.00, reads: 0.00, writes: 44862.10, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3237s] threads: 64, tps: 0.00, reads: 0.00, writes: 40315.91, response time: 2.38ms (95%), errors: 0.00, reconnects:  0.00
[3238s] threads: 64, tps: 0.00, reads: 0.00, writes: 46970.03, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3239s] threads: 64, tps: 0.00, reads: 0.00, writes: 47994.01, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[3240s] threads: 64, tps: 0.00, reads: 0.00, writes: 42781.99, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3241s] threads: 64, tps: 0.00, reads: 0.00, writes: 43561.00, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3242s] threads: 64, tps: 0.00, reads: 0.00, writes: 44114.01, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3243s] threads: 64, tps: 0.00, reads: 0.00, writes: 47141.60, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3244s] threads: 64, tps: 0.00, reads: 0.00, writes: 45350.38, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3245s] threads: 64, tps: 0.00, reads: 0.00, writes: 42982.01, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3246s] threads: 64, tps: 0.00, reads: 0.00, writes: 4680.88, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[3247s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.99, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[3248s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.99, response time: 21.14ms (95%), errors: 0.00, reconnects:  0.00
[3249s] threads: 64, tps: 0.00, reads: 0.00, writes: 4359.12, response time: 21.07ms (95%), errors: 0.00, reconnects:  0.00
[3250s] threads: 64, tps: 0.00, reads: 0.00, writes: 42822.08, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3251s] threads: 64, tps: 0.00, reads: 0.00, writes: 44106.07, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3252s] threads: 64, tps: 0.00, reads: 0.00, writes: 48592.94, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3253s] threads: 64, tps: 0.00, reads: 0.00, writes: 46098.12, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3254s] threads: 64, tps: 0.00, reads: 0.00, writes: 40128.92, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[3255s] threads: 64, tps: 0.00, reads: 0.00, writes: 37884.85, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3256s] threads: 64, tps: 0.00, reads: 0.00, writes: 42803.12, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[3257s] threads: 64, tps: 0.00, reads: 0.00, writes: 46393.10, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3258s] threads: 64, tps: 0.00, reads: 0.00, writes: 40224.03, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[3259s] threads: 64, tps: 0.00, reads: 0.00, writes: 38518.94, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[3260s] threads: 64, tps: 0.00, reads: 0.00, writes: 38009.04, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[3261s] threads: 64, tps: 0.00, reads: 0.00, writes: 39272.96, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3262s] threads: 64, tps: 0.00, reads: 0.00, writes: 46520.03, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3263s] threads: 64, tps: 0.00, reads: 0.00, writes: 41188.94, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3264s] threads: 64, tps: 0.00, reads: 0.00, writes: 43610.06, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3265s] threads: 64, tps: 0.00, reads: 0.00, writes: 42797.98, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3266s] threads: 64, tps: 0.00, reads: 0.00, writes: 44659.02, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3267s] threads: 64, tps: 0.00, reads: 0.00, writes: 42359.97, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3268s] threads: 64, tps: 0.00, reads: 0.00, writes: 46325.10, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3269s] threads: 64, tps: 0.00, reads: 0.00, writes: 43822.86, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3270s] threads: 64, tps: 0.00, reads: 0.00, writes: 43306.07, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3271s] threads: 64, tps: 0.00, reads: 0.00, writes: 46157.02, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3272s] threads: 64, tps: 0.00, reads: 0.00, writes: 46699.00, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3273s] threads: 64, tps: 0.00, reads: 0.00, writes: 45081.93, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3274s] threads: 64, tps: 0.00, reads: 0.00, writes: 43967.03, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3275s] threads: 64, tps: 0.00, reads: 0.00, writes: 43362.05, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3276s] threads: 64, tps: 0.00, reads: 0.00, writes: 45717.98, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3277s] threads: 64, tps: 0.00, reads: 0.00, writes: 44018.01, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[3278s] threads: 64, tps: 0.00, reads: 0.00, writes: 38669.96, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[3279s] threads: 64, tps: 0.00, reads: 0.00, writes: 43714.00, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3280s] threads: 64, tps: 0.00, reads: 0.00, writes: 42510.96, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3281s] threads: 64, tps: 0.00, reads: 0.00, writes: 48097.04, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[3282s] threads: 64, tps: 0.00, reads: 0.00, writes: 46899.01, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3283s] threads: 64, tps: 0.00, reads: 0.00, writes: 44672.97, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3284s] threads: 64, tps: 0.00, reads: 0.00, writes: 36211.01, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[3285s] threads: 64, tps: 0.00, reads: 0.00, writes: 37445.65, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3286s] threads: 64, tps: 0.00, reads: 0.00, writes: 46873.46, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3287s] threads: 64, tps: 0.00, reads: 0.00, writes: 45551.84, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3288s] threads: 64, tps: 0.00, reads: 0.00, writes: 46154.25, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3289s] threads: 64, tps: 0.00, reads: 0.00, writes: 43563.98, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3290s] threads: 64, tps: 0.00, reads: 0.00, writes: 42183.00, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3291s] threads: 64, tps: 0.00, reads: 0.00, writes: 47388.98, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[3292s] threads: 64, tps: 0.00, reads: 0.00, writes: 46045.02, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3293s] threads: 64, tps: 0.00, reads: 0.00, writes: 40151.96, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3294s] threads: 64, tps: 0.00, reads: 0.00, writes: 43252.96, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3295s] threads: 64, tps: 0.00, reads: 0.00, writes: 44458.07, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3296s] threads: 64, tps: 0.00, reads: 0.00, writes: 46332.82, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3297s] threads: 64, tps: 0.00, reads: 0.00, writes: 46439.15, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3298s] threads: 64, tps: 0.00, reads: 0.00, writes: 41549.05, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3299s] threads: 64, tps: 0.00, reads: 0.00, writes: 41677.81, response time: 2.11ms (95%), errors: 0.00, reconnects:  0.00
[3300s] threads: 64, tps: 0.00, reads: 0.00, writes: 47935.22, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3301s] threads: 64, tps: 0.00, reads: 0.00, writes: 46048.00, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3302s] threads: 64, tps: 0.00, reads: 0.00, writes: 42932.01, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3303s] threads: 64, tps: 0.00, reads: 0.00, writes: 36315.96, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[3304s] threads: 64, tps: 0.00, reads: 0.00, writes: 42732.99, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3305s] threads: 64, tps: 0.00, reads: 0.00, writes: 48079.98, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3306s] threads: 64, tps: 0.00, reads: 0.00, writes: 45930.07, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3307s] threads: 64, tps: 0.00, reads: 0.00, writes: 43898.94, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3308s] threads: 64, tps: 0.00, reads: 0.00, writes: 3734.88, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[3309s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.01, response time: 20.95ms (95%), errors: 0.00, reconnects:  0.00
[3310s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.00, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[3311s] threads: 64, tps: 0.00, reads: 0.00, writes: 3170.09, response time: 20.97ms (95%), errors: 0.00, reconnects:  0.00
[3312s] threads: 64, tps: 0.00, reads: 0.00, writes: 28966.00, response time: 3.22ms (95%), errors: 0.00, reconnects:  0.00
[3313s] threads: 64, tps: 0.00, reads: 0.00, writes: 42910.94, response time: 2.20ms (95%), errors: 0.00, reconnects:  0.00
[3314s] threads: 64, tps: 0.00, reads: 0.00, writes: 48190.09, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3315s] threads: 64, tps: 0.00, reads: 0.00, writes: 47757.97, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[3316s] threads: 64, tps: 0.00, reads: 0.00, writes: 42862.04, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3317s] threads: 64, tps: 0.00, reads: 0.00, writes: 38970.62, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3318s] threads: 64, tps: 0.00, reads: 0.00, writes: 36896.36, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3319s] threads: 64, tps: 0.00, reads: 0.00, writes: 47713.93, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[3320s] threads: 64, tps: 0.00, reads: 0.00, writes: 41751.01, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[3321s] threads: 64, tps: 0.00, reads: 0.00, writes: 37466.99, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[3322s] threads: 64, tps: 0.00, reads: 0.00, writes: 39490.03, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[3323s] threads: 64, tps: 0.00, reads: 0.00, writes: 43855.94, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3324s] threads: 64, tps: 0.00, reads: 0.00, writes: 47578.07, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3325s] threads: 64, tps: 0.00, reads: 0.00, writes: 47240.08, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[3326s] threads: 64, tps: 0.00, reads: 0.00, writes: 41583.97, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3327s] threads: 64, tps: 0.00, reads: 0.00, writes: 43460.93, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3328s] threads: 64, tps: 0.00, reads: 0.00, writes: 44936.02, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3329s] threads: 64, tps: 0.00, reads: 0.00, writes: 48775.05, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[3330s] threads: 64, tps: 0.00, reads: 0.00, writes: 44009.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3331s] threads: 64, tps: 0.00, reads: 0.00, writes: 44225.00, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3332s] threads: 64, tps: 0.00, reads: 0.00, writes: 43550.98, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3333s] threads: 64, tps: 0.00, reads: 0.00, writes: 40627.94, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3334s] threads: 64, tps: 0.00, reads: 0.00, writes: 48224.08, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3335s] threads: 64, tps: 0.00, reads: 0.00, writes: 45040.02, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3336s] threads: 64, tps: 0.00, reads: 0.00, writes: 44727.98, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3337s] threads: 64, tps: 0.00, reads: 0.00, writes: 42823.96, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3338s] threads: 64, tps: 0.00, reads: 0.00, writes: 43222.02, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3339s] threads: 64, tps: 0.00, reads: 0.00, writes: 44443.97, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3340s] threads: 64, tps: 0.00, reads: 0.00, writes: 44534.02, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3341s] threads: 64, tps: 0.00, reads: 0.00, writes: 43711.07, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[3342s] threads: 64, tps: 0.00, reads: 0.00, writes: 44604.97, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3343s] threads: 64, tps: 0.00, reads: 0.00, writes: 48266.01, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3344s] threads: 64, tps: 0.00, reads: 0.00, writes: 44930.90, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3345s] threads: 64, tps: 0.00, reads: 0.00, writes: 39378.87, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[3346s] threads: 64, tps: 0.00, reads: 0.00, writes: 42472.03, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3347s] threads: 64, tps: 0.00, reads: 0.00, writes: 38057.15, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[3348s] threads: 64, tps: 0.00, reads: 0.00, writes: 48535.99, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3349s] threads: 64, tps: 0.00, reads: 0.00, writes: 42851.23, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3350s] threads: 64, tps: 0.00, reads: 0.00, writes: 39060.72, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3351s] threads: 64, tps: 0.00, reads: 0.00, writes: 39475.82, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3352s] threads: 64, tps: 0.00, reads: 0.00, writes: 39691.36, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3353s] threads: 64, tps: 0.00, reads: 0.00, writes: 45277.93, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3354s] threads: 64, tps: 0.00, reads: 0.00, writes: 41620.98, response time: 2.31ms (95%), errors: 0.00, reconnects:  0.00
[3355s] threads: 64, tps: 0.00, reads: 0.00, writes: 41973.60, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3356s] threads: 64, tps: 0.00, reads: 0.00, writes: 43549.47, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3357s] threads: 64, tps: 0.00, reads: 0.00, writes: 43717.74, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3358s] threads: 64, tps: 0.00, reads: 0.00, writes: 47969.29, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3359s] threads: 64, tps: 0.00, reads: 0.00, writes: 47637.77, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3360s] threads: 64, tps: 0.00, reads: 0.00, writes: 42859.20, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3361s] threads: 64, tps: 0.00, reads: 0.00, writes: 43694.96, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3362s] threads: 64, tps: 0.00, reads: 0.00, writes: 43739.00, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3363s] threads: 64, tps: 0.00, reads: 0.00, writes: 47906.62, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3364s] threads: 64, tps: 0.00, reads: 0.00, writes: 45946.33, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3365s] threads: 64, tps: 0.00, reads: 0.00, writes: 42239.03, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3366s] threads: 64, tps: 0.00, reads: 0.00, writes: 42209.99, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3367s] threads: 64, tps: 0.00, reads: 0.00, writes: 44362.00, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3368s] threads: 64, tps: 0.00, reads: 0.00, writes: 43460.99, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3369s] threads: 64, tps: 0.00, reads: 0.00, writes: 43891.01, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3370s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.99, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[3371s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.00, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[3372s] threads: 64, tps: 0.00, reads: 0.00, writes: 3149.92, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[3373s] threads: 64, tps: 0.00, reads: 0.00, writes: 3159.00, response time: 20.87ms (95%), errors: 0.00, reconnects:  0.00
[3374s] threads: 64, tps: 0.00, reads: 0.00, writes: 33367.91, response time: 2.33ms (95%), errors: 0.00, reconnects:  0.00
[3375s] threads: 64, tps: 0.00, reads: 0.00, writes: 39475.06, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[3376s] threads: 64, tps: 0.00, reads: 0.00, writes: 46202.02, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3377s] threads: 64, tps: 0.00, reads: 0.00, writes: 47060.89, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3378s] threads: 64, tps: 0.00, reads: 0.00, writes: 45256.10, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3379s] threads: 64, tps: 0.00, reads: 0.00, writes: 44919.04, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3380s] threads: 64, tps: 0.00, reads: 0.00, writes: 46041.73, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3381s] threads: 64, tps: 0.00, reads: 0.00, writes: 48412.27, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3382s] threads: 64, tps: 0.00, reads: 0.00, writes: 44602.95, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3383s] threads: 64, tps: 0.00, reads: 0.00, writes: 37837.68, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[3384s] threads: 64, tps: 0.00, reads: 0.00, writes: 37839.30, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3385s] threads: 64, tps: 0.00, reads: 0.00, writes: 37693.04, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3386s] threads: 64, tps: 0.00, reads: 0.00, writes: 46232.94, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3387s] threads: 64, tps: 0.00, reads: 0.00, writes: 39578.98, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[3388s] threads: 64, tps: 0.00, reads: 0.00, writes: 37289.01, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[3389s] threads: 64, tps: 0.00, reads: 0.00, writes: 36835.97, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[3390s] threads: 64, tps: 0.00, reads: 0.00, writes: 35849.00, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[3391s] threads: 64, tps: 0.00, reads: 0.00, writes: 40986.02, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[3392s] threads: 64, tps: 0.00, reads: 0.00, writes: 44272.00, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3393s] threads: 64, tps: 0.00, reads: 0.00, writes: 38009.96, response time: 2.51ms (95%), errors: 0.00, reconnects:  0.00
[3394s] threads: 64, tps: 0.00, reads: 0.00, writes: 40535.10, response time: 2.29ms (95%), errors: 0.00, reconnects:  0.00
[3395s] threads: 64, tps: 0.00, reads: 0.00, writes: 44114.01, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3396s] threads: 64, tps: 0.00, reads: 0.00, writes: 35128.96, response time: 2.30ms (95%), errors: 0.00, reconnects:  0.00
[3397s] threads: 64, tps: 0.00, reads: 0.00, writes: 47888.93, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[3398s] threads: 64, tps: 0.00, reads: 0.00, writes: 45530.11, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3399s] threads: 64, tps: 0.00, reads: 0.00, writes: 42652.97, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3400s] threads: 64, tps: 0.00, reads: 0.00, writes: 43559.02, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3401s] threads: 64, tps: 0.00, reads: 0.00, writes: 46713.00, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3402s] threads: 64, tps: 0.00, reads: 0.00, writes: 47987.05, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3403s] threads: 64, tps: 0.00, reads: 0.00, writes: 42169.91, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3404s] threads: 64, tps: 0.00, reads: 0.00, writes: 43476.11, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3405s] threads: 64, tps: 0.00, reads: 0.00, writes: 42783.90, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3406s] threads: 64, tps: 0.00, reads: 0.00, writes: 46901.04, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3407s] threads: 64, tps: 0.00, reads: 0.00, writes: 47358.96, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3408s] threads: 64, tps: 0.00, reads: 0.00, writes: 38263.91, response time: 2.24ms (95%), errors: 0.00, reconnects:  0.00
[3409s] threads: 64, tps: 0.00, reads: 0.00, writes: 3142.91, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[3410s] threads: 64, tps: 0.00, reads: 0.00, writes: 3179.01, response time: 21.13ms (95%), errors: 0.00, reconnects:  0.00
[3411s] threads: 64, tps: 0.00, reads: 0.00, writes: 3150.00, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[3412s] threads: 64, tps: 0.00, reads: 0.00, writes: 3151.06, response time: 20.88ms (95%), errors: 0.00, reconnects:  0.00
[3413s] threads: 64, tps: 0.00, reads: 0.00, writes: 3157.97, response time: 21.16ms (95%), errors: 0.00, reconnects:  0.00
[3414s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.04, response time: 21.28ms (95%), errors: 0.00, reconnects:  0.00
[3415s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.00, response time: 21.20ms (95%), errors: 0.00, reconnects:  0.00
[3416s] threads: 64, tps: 0.00, reads: 0.00, writes: 3163.01, response time: 21.10ms (95%), errors: 0.00, reconnects:  0.00
[3417s] threads: 64, tps: 0.00, reads: 0.00, writes: 3154.90, response time: 20.99ms (95%), errors: 0.00, reconnects:  0.00
[3418s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.02, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[3419s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.95, response time: 20.98ms (95%), errors: 0.00, reconnects:  0.00
[3420s] threads: 64, tps: 0.00, reads: 0.00, writes: 3160.12, response time: 20.84ms (95%), errors: 0.00, reconnects:  0.00
[3421s] threads: 64, tps: 0.00, reads: 0.00, writes: 3153.92, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[3422s] threads: 64, tps: 0.00, reads: 0.00, writes: 4064.10, response time: 20.96ms (95%), errors: 0.00, reconnects:  0.00
[3423s] threads: 64, tps: 0.00, reads: 0.00, writes: 45359.22, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3424s] threads: 64, tps: 0.00, reads: 0.00, writes: 48151.98, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3425s] threads: 64, tps: 0.00, reads: 0.00, writes: 46678.99, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3426s] threads: 64, tps: 0.00, reads: 0.00, writes: 43781.98, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3427s] threads: 64, tps: 0.00, reads: 0.00, writes: 40300.95, response time: 2.35ms (95%), errors: 0.00, reconnects:  0.00
[3428s] threads: 64, tps: 0.00, reads: 0.00, writes: 34100.79, response time: 2.66ms (95%), errors: 0.00, reconnects:  0.00
[3429s] threads: 64, tps: 0.00, reads: 0.00, writes: 48231.21, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3430s] threads: 64, tps: 0.00, reads: 0.00, writes: 39998.99, response time: 2.37ms (95%), errors: 0.00, reconnects:  0.00
[3431s] threads: 64, tps: 0.00, reads: 0.00, writes: 40437.80, response time: 2.40ms (95%), errors: 0.00, reconnects:  0.00
[3432s] threads: 64, tps: 0.00, reads: 0.00, writes: 38109.25, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[3433s] threads: 64, tps: 0.00, reads: 0.00, writes: 38142.93, response time: 2.46ms (95%), errors: 0.00, reconnects:  0.00
[3434s] threads: 64, tps: 0.00, reads: 0.00, writes: 45292.87, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3435s] threads: 64, tps: 0.00, reads: 0.00, writes: 41097.15, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[3436s] threads: 64, tps: 0.00, reads: 0.00, writes: 37539.94, response time: 2.61ms (95%), errors: 0.00, reconnects:  0.00
[3437s] threads: 64, tps: 0.00, reads: 0.00, writes: 39029.04, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[3438s] threads: 64, tps: 0.00, reads: 0.00, writes: 37829.96, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[3439s] threads: 64, tps: 0.00, reads: 0.00, writes: 42908.08, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[3440s] threads: 64, tps: 0.00, reads: 0.00, writes: 45576.97, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3441s] threads: 64, tps: 0.00, reads: 0.00, writes: 36587.99, response time: 2.75ms (95%), errors: 0.00, reconnects:  0.00
[3442s] threads: 64, tps: 0.00, reads: 0.00, writes: 38460.78, response time: 2.53ms (95%), errors: 0.00, reconnects:  0.00
[3443s] threads: 64, tps: 0.00, reads: 0.00, writes: 39050.28, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[3444s] threads: 64, tps: 0.00, reads: 0.00, writes: 41970.93, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[3445s] threads: 64, tps: 0.00, reads: 0.00, writes: 47221.03, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3446s] threads: 64, tps: 0.00, reads: 0.00, writes: 40545.00, response time: 2.48ms (95%), errors: 0.00, reconnects:  0.00
[3447s] threads: 64, tps: 0.00, reads: 0.00, writes: 43439.99, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3448s] threads: 64, tps: 0.00, reads: 0.00, writes: 42116.03, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3449s] threads: 64, tps: 0.00, reads: 0.00, writes: 43310.01, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3450s] threads: 64, tps: 0.00, reads: 0.00, writes: 48408.96, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3451s] threads: 64, tps: 0.00, reads: 0.00, writes: 45406.02, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3452s] threads: 64, tps: 0.00, reads: 0.00, writes: 41197.99, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3453s] threads: 64, tps: 0.00, reads: 0.00, writes: 42401.03, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3454s] threads: 64, tps: 0.00, reads: 0.00, writes: 47176.96, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3455s] threads: 64, tps: 0.00, reads: 0.00, writes: 46057.04, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3456s] threads: 64, tps: 0.00, reads: 0.00, writes: 44686.97, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3457s] threads: 64, tps: 0.00, reads: 0.00, writes: 42519.98, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3458s] threads: 64, tps: 0.00, reads: 0.00, writes: 42934.03, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3459s] threads: 64, tps: 0.00, reads: 0.00, writes: 48236.01, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[3460s] threads: 64, tps: 0.00, reads: 0.00, writes: 45475.96, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3461s] threads: 64, tps: 0.00, reads: 0.00, writes: 42908.04, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3462s] threads: 64, tps: 0.00, reads: 0.00, writes: 37285.95, response time: 2.59ms (95%), errors: 0.00, reconnects:  0.00
[3463s] threads: 64, tps: 0.00, reads: 0.00, writes: 42061.05, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3464s] threads: 64, tps: 0.00, reads: 0.00, writes: 47357.75, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3465s] threads: 64, tps: 0.00, reads: 0.00, writes: 40106.26, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[3466s] threads: 64, tps: 0.00, reads: 0.00, writes: 37766.97, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[3467s] threads: 64, tps: 0.00, reads: 0.00, writes: 41469.95, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3468s] threads: 64, tps: 0.00, reads: 0.00, writes: 33107.07, response time: 2.63ms (95%), errors: 0.00, reconnects:  0.00
[3469s] threads: 64, tps: 0.00, reads: 0.00, writes: 46938.89, response time: 1.99ms (95%), errors: 0.00, reconnects:  0.00
[3470s] threads: 64, tps: 0.00, reads: 0.00, writes: 44346.08, response time: 2.17ms (95%), errors: 0.00, reconnects:  0.00
[3471s] threads: 64, tps: 0.00, reads: 0.00, writes: 38993.94, response time: 2.41ms (95%), errors: 0.00, reconnects:  0.00
[3472s] threads: 64, tps: 0.00, reads: 0.00, writes: 37095.04, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[3473s] threads: 64, tps: 0.00, reads: 0.00, writes: 40308.98, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[3474s] threads: 64, tps: 0.00, reads: 0.00, writes: 47641.99, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3475s] threads: 64, tps: 0.00, reads: 0.00, writes: 47857.06, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3476s] threads: 64, tps: 0.00, reads: 0.00, writes: 44826.89, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3477s] threads: 64, tps: 0.00, reads: 0.00, writes: 44531.05, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3478s] threads: 64, tps: 0.00, reads: 0.00, writes: 44798.05, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3479s] threads: 64, tps: 0.00, reads: 0.00, writes: 48872.97, response time: 1.71ms (95%), errors: 0.00, reconnects:  0.00
[3480s] threads: 64, tps: 0.00, reads: 0.00, writes: 46186.00, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[3481s] threads: 64, tps: 0.00, reads: 0.00, writes: 43980.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3482s] threads: 64, tps: 0.00, reads: 0.00, writes: 44646.98, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3483s] threads: 64, tps: 0.00, reads: 0.00, writes: 43972.01, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3484s] threads: 64, tps: 0.00, reads: 0.00, writes: 47419.12, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[3485s] threads: 64, tps: 0.00, reads: 0.00, writes: 45902.75, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3486s] threads: 64, tps: 0.00, reads: 0.00, writes: 45347.08, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3487s] threads: 64, tps: 0.00, reads: 0.00, writes: 42870.95, response time: 2.07ms (95%), errors: 0.00, reconnects:  0.00
[3488s] threads: 64, tps: 0.00, reads: 0.00, writes: 47151.01, response time: 1.96ms (95%), errors: 0.00, reconnects:  0.00
[3489s] threads: 64, tps: 0.00, reads: 0.00, writes: 45619.07, response time: 1.87ms (95%), errors: 0.00, reconnects:  0.00
[3490s] threads: 64, tps: 0.00, reads: 0.00, writes: 42206.96, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3491s] threads: 64, tps: 0.00, reads: 0.00, writes: 42840.05, response time: 2.14ms (95%), errors: 0.00, reconnects:  0.00
[3492s] threads: 64, tps: 0.00, reads: 0.00, writes: 37017.01, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3493s] threads: 64, tps: 0.00, reads: 0.00, writes: 46229.94, response time: 1.80ms (95%), errors: 0.00, reconnects:  0.00
[3494s] threads: 64, tps: 0.00, reads: 0.00, writes: 45935.06, response time: 1.83ms (95%), errors: 0.00, reconnects:  0.00
[3495s] threads: 64, tps: 0.00, reads: 0.00, writes: 38932.93, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3496s] threads: 64, tps: 0.00, reads: 0.00, writes: 37733.99, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3497s] threads: 64, tps: 0.00, reads: 0.00, writes: 38989.99, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3498s] threads: 64, tps: 0.00, reads: 0.00, writes: 44739.07, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3499s] threads: 64, tps: 0.00, reads: 0.00, writes: 36573.01, response time: 2.68ms (95%), errors: 0.00, reconnects:  0.00
[3500s] threads: 64, tps: 0.00, reads: 0.00, writes: 34953.97, response time: 2.76ms (95%), errors: 0.00, reconnects:  0.00
[3501s] threads: 64, tps: 0.00, reads: 0.00, writes: 37762.03, response time: 2.52ms (95%), errors: 0.00, reconnects:  0.00
[3502s] threads: 64, tps: 0.00, reads: 0.00, writes: 38212.96, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[3503s] threads: 64, tps: 0.00, reads: 0.00, writes: 38877.01, response time: 2.47ms (95%), errors: 0.00, reconnects:  0.00
[3504s] threads: 64, tps: 0.00, reads: 0.00, writes: 48072.09, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3505s] threads: 64, tps: 0.00, reads: 0.00, writes: 39583.88, response time: 2.45ms (95%), errors: 0.00, reconnects:  0.00
[3506s] threads: 64, tps: 0.00, reads: 0.00, writes: 40292.11, response time: 2.42ms (95%), errors: 0.00, reconnects:  0.00
[3507s] threads: 64, tps: 0.00, reads: 0.00, writes: 41948.93, response time: 2.09ms (95%), errors: 0.00, reconnects:  0.00
[3508s] threads: 64, tps: 0.00, reads: 0.00, writes: 43765.06, response time: 2.05ms (95%), errors: 0.00, reconnects:  0.00
[3509s] threads: 64, tps: 0.00, reads: 0.00, writes: 48328.96, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[3510s] threads: 64, tps: 0.00, reads: 0.00, writes: 46744.07, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3511s] threads: 64, tps: 0.00, reads: 0.00, writes: 43039.94, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3512s] threads: 64, tps: 0.00, reads: 0.00, writes: 43072.00, response time: 2.06ms (95%), errors: 0.00, reconnects:  0.00
[3513s] threads: 64, tps: 0.00, reads: 0.00, writes: 46310.00, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3514s] threads: 64, tps: 0.00, reads: 0.00, writes: 47954.96, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3515s] threads: 64, tps: 0.00, reads: 0.00, writes: 43593.01, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3516s] threads: 64, tps: 0.00, reads: 0.00, writes: 41925.07, response time: 2.18ms (95%), errors: 0.00, reconnects:  0.00
[3517s] threads: 64, tps: 0.00, reads: 0.00, writes: 43594.98, response time: 2.03ms (95%), errors: 0.00, reconnects:  0.00
[3518s] threads: 64, tps: 0.00, reads: 0.00, writes: 48494.99, response time: 1.86ms (95%), errors: 0.00, reconnects:  0.00
[3519s] threads: 64, tps: 0.00, reads: 0.00, writes: 47246.04, response time: 1.76ms (95%), errors: 0.00, reconnects:  0.00
[3520s] threads: 64, tps: 0.00, reads: 0.00, writes: 40971.82, response time: 2.12ms (95%), errors: 0.00, reconnects:  0.00
[3521s] threads: 64, tps: 0.00, reads: 0.00, writes: 3152.99, response time: 21.33ms (95%), errors: 0.00, reconnects:  0.00
[3522s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.00, response time: 21.08ms (95%), errors: 0.00, reconnects:  0.00
[3523s] threads: 64, tps: 0.00, reads: 0.00, writes: 3142.01, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[3524s] threads: 64, tps: 0.00, reads: 0.00, writes: 3158.97, response time: 21.11ms (95%), errors: 0.00, reconnects:  0.00
[3525s] threads: 64, tps: 0.00, reads: 0.00, writes: 3161.01, response time: 21.27ms (95%), errors: 0.00, reconnects:  0.00
[3526s] threads: 64, tps: 0.00, reads: 0.00, writes: 3122.92, response time: 21.12ms (95%), errors: 0.00, reconnects:  0.00
[3527s] threads: 64, tps: 0.00, reads: 0.00, writes: 31635.53, response time: 2.56ms (95%), errors: 0.00, reconnects:  0.00
[3528s] threads: 64, tps: 0.00, reads: 0.00, writes: 43781.84, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3529s] threads: 64, tps: 0.00, reads: 0.00, writes: 47367.20, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3530s] threads: 64, tps: 0.00, reads: 0.00, writes: 43604.95, response time: 2.19ms (95%), errors: 0.00, reconnects:  0.00
[3531s] threads: 64, tps: 0.00, reads: 0.00, writes: 44106.99, response time: 2.02ms (95%), errors: 0.00, reconnects:  0.00
[3532s] threads: 64, tps: 0.00, reads: 0.00, writes: 41071.80, response time: 2.16ms (95%), errors: 0.00, reconnects:  0.00
[3533s] threads: 64, tps: 0.00, reads: 0.00, writes: 46139.23, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3534s] threads: 64, tps: 0.00, reads: 0.00, writes: 46405.02, response time: 1.79ms (95%), errors: 0.00, reconnects:  0.00
[3535s] threads: 64, tps: 0.00, reads: 0.00, writes: 44765.97, response time: 1.92ms (95%), errors: 0.00, reconnects:  0.00
[3536s] threads: 64, tps: 0.00, reads: 0.00, writes: 41494.99, response time: 2.22ms (95%), errors: 0.00, reconnects:  0.00
[3537s] threads: 64, tps: 0.00, reads: 0.00, writes: 39961.03, response time: 2.49ms (95%), errors: 0.00, reconnects:  0.00
[3538s] threads: 64, tps: 0.00, reads: 0.00, writes: 43501.70, response time: 2.25ms (95%), errors: 0.00, reconnects:  0.00
[3539s] threads: 64, tps: 0.00, reads: 0.00, writes: 44415.37, response time: 2.10ms (95%), errors: 0.00, reconnects:  0.00
[3540s] threads: 64, tps: 0.00, reads: 0.00, writes: 37448.95, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3541s] threads: 64, tps: 0.00, reads: 0.00, writes: 41543.02, response time: 2.36ms (95%), errors: 0.00, reconnects:  0.00
[3542s] threads: 64, tps: 0.00, reads: 0.00, writes: 42896.98, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3543s] threads: 64, tps: 0.00, reads: 0.00, writes: 43998.99, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3544s] threads: 64, tps: 0.00, reads: 0.00, writes: 46295.04, response time: 1.94ms (95%), errors: 0.00, reconnects:  0.00
[3545s] threads: 64, tps: 0.00, reads: 0.00, writes: 36653.97, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3546s] threads: 64, tps: 0.00, reads: 0.00, writes: 37566.00, response time: 2.58ms (95%), errors: 0.00, reconnects:  0.00
[3547s] threads: 64, tps: 0.00, reads: 0.00, writes: 37629.04, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[3548s] threads: 64, tps: 0.00, reads: 0.00, writes: 38051.97, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3549s] threads: 64, tps: 0.00, reads: 0.00, writes: 47266.93, response time: 1.88ms (95%), errors: 0.00, reconnects:  0.00
[3550s] threads: 64, tps: 0.00, reads: 0.00, writes: 38913.07, response time: 2.62ms (95%), errors: 0.00, reconnects:  0.00
[3551s] threads: 64, tps: 0.00, reads: 0.00, writes: 36858.97, response time: 2.57ms (95%), errors: 0.00, reconnects:  0.00
[3552s] threads: 64, tps: 0.00, reads: 0.00, writes: 35689.98, response time: 2.65ms (95%), errors: 0.00, reconnects:  0.00
[3553s] threads: 64, tps: 0.00, reads: 0.00, writes: 38787.08, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[3554s] threads: 64, tps: 0.00, reads: 0.00, writes: 47493.97, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3555s] threads: 64, tps: 0.00, reads: 0.00, writes: 47495.69, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3556s] threads: 64, tps: 0.00, reads: 0.00, writes: 45184.03, response time: 1.91ms (95%), errors: 0.00, reconnects:  0.00
[3557s] threads: 64, tps: 0.00, reads: 0.00, writes: 43278.29, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3558s] threads: 64, tps: 0.00, reads: 0.00, writes: 43917.95, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3559s] threads: 64, tps: 0.00, reads: 0.00, writes: 47863.97, response time: 1.77ms (95%), errors: 0.00, reconnects:  0.00
[3560s] threads: 64, tps: 0.00, reads: 0.00, writes: 46176.06, response time: 1.81ms (95%), errors: 0.00, reconnects:  0.00
[3561s] threads: 64, tps: 0.00, reads: 0.00, writes: 19888.35, response time: 20.31ms (95%), errors: 0.00, reconnects:  0.00
[3562s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.98, response time: 21.30ms (95%), errors: 0.00, reconnects:  0.00
[3563s] threads: 64, tps: 0.00, reads: 0.00, writes: 3156.05, response time: 21.35ms (95%), errors: 0.00, reconnects:  0.00
[3564s] threads: 64, tps: 0.00, reads: 0.00, writes: 3155.04, response time: 21.21ms (95%), errors: 0.00, reconnects:  0.00
[3565s] threads: 64, tps: 0.00, reads: 0.00, writes: 3136.93, response time: 21.18ms (95%), errors: 0.00, reconnects:  0.00
[3566s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.97, response time: 21.06ms (95%), errors: 0.00, reconnects:  0.00
[3567s] threads: 64, tps: 0.00, reads: 0.00, writes: 3133.02, response time: 21.33ms (95%), errors: 0.00, reconnects:  0.00
[3568s] threads: 64, tps: 0.00, reads: 0.00, writes: 3166.03, response time: 21.27ms (95%), errors: 0.00, reconnects:  0.00
[3569s] threads: 64, tps: 0.00, reads: 0.00, writes: 3120.99, response time: 21.68ms (95%), errors: 0.00, reconnects:  0.00
[3570s] threads: 64, tps: 0.00, reads: 0.00, writes: 19249.53, response time: 20.40ms (95%), errors: 0.00, reconnects:  0.00
[3571s] threads: 64, tps: 0.00, reads: 0.00, writes: 44209.10, response time: 1.90ms (95%), errors: 0.00, reconnects:  0.00
[3572s] threads: 64, tps: 0.00, reads: 0.00, writes: 47463.97, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3573s] threads: 64, tps: 0.00, reads: 0.00, writes: 45336.98, response time: 2.01ms (95%), errors: 0.00, reconnects:  0.00
[3574s] threads: 64, tps: 0.00, reads: 0.00, writes: 39804.04, response time: 2.43ms (95%), errors: 0.00, reconnects:  0.00
[3575s] threads: 64, tps: 0.00, reads: 0.00, writes: 37483.91, response time: 2.55ms (95%), errors: 0.00, reconnects:  0.00
[3576s] threads: 64, tps: 0.00, reads: 0.00, writes: 37778.04, response time: 2.54ms (95%), errors: 0.00, reconnects:  0.00
[3577s] threads: 64, tps: 0.00, reads: 0.00, writes: 46283.99, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
[3578s] threads: 64, tps: 0.00, reads: 0.00, writes: 45356.08, response time: 2.04ms (95%), errors: 0.00, reconnects:  0.00
[3579s] threads: 64, tps: 0.00, reads: 0.00, writes: 45811.96, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3580s] threads: 64, tps: 0.00, reads: 0.00, writes: 44797.04, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3581s] threads: 64, tps: 0.00, reads: 0.00, writes: 45873.97, response time: 1.98ms (95%), errors: 0.00, reconnects:  0.00
[3582s] threads: 64, tps: 0.00, reads: 0.00, writes: 48802.97, response time: 1.74ms (95%), errors: 0.00, reconnects:  0.00
[3583s] threads: 64, tps: 0.00, reads: 0.00, writes: 46416.01, response time: 1.78ms (95%), errors: 0.00, reconnects:  0.00
[3584s] threads: 64, tps: 0.00, reads: 0.00, writes: 44709.00, response time: 1.97ms (95%), errors: 0.00, reconnects:  0.00
[3585s] threads: 64, tps: 0.00, reads: 0.00, writes: 46144.00, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3586s] threads: 64, tps: 0.00, reads: 0.00, writes: 46433.98, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3587s] threads: 64, tps: 0.00, reads: 0.00, writes: 47494.00, response time: 1.75ms (95%), errors: 0.00, reconnects:  0.00
[3588s] threads: 64, tps: 0.00, reads: 0.00, writes: 45619.07, response time: 1.89ms (95%), errors: 0.00, reconnects:  0.00
[3589s] threads: 64, tps: 0.00, reads: 0.00, writes: 44714.95, response time: 1.85ms (95%), errors: 0.00, reconnects:  0.00
[3590s] threads: 64, tps: 0.00, reads: 0.00, writes: 43584.51, response time: 1.95ms (95%), errors: 0.00, reconnects:  0.00
[3591s] threads: 64, tps: 0.00, reads: 0.00, writes: 46072.64, response time: 1.84ms (95%), errors: 0.00, reconnects:  0.00
[3592s] threads: 64, tps: 0.00, reads: 0.00, writes: 44577.97, response time: 2.00ms (95%), errors: 0.00, reconnects:  0.00
[3593s] threads: 64, tps: 0.00, reads: 0.00, writes: 45387.07, response time: 1.82ms (95%), errors: 0.00, reconnects:  0.00
[3594s] threads: 64, tps: 0.00, reads: 0.00, writes: 41406.95, response time: 2.26ms (95%), errors: 0.00, reconnects:  0.00
[3595s] threads: 64, tps: 0.00, reads: 0.00, writes: 34267.02, response time: 2.69ms (95%), errors: 0.00, reconnects:  0.00
[3596s] threads: 64, tps: 0.00, reads: 0.00, writes: 47486.94, response time: 1.93ms (95%), errors: 0.00, reconnects:  0.00
[3597s] threads: 64, tps: 0.00, reads: 0.00, writes: 42585.06, response time: 2.27ms (95%), errors: 0.00, reconnects:  0.00
[3598s] threads: 64, tps: 0.00, reads: 0.00, writes: 38639.79, response time: 2.50ms (95%), errors: 0.00, reconnects:  0.00
[3599s] threads: 64, tps: 0.00, reads: 0.00, writes: 40327.15, response time: 2.34ms (95%), errors: 0.00, reconnects:  0.00
[3600s] threads: 64, tps: 0.00, reads: 0.00, writes: 43022.06, response time: 2.08ms (95%), errors: 0.00, reconnects:  0.00
OLTP test statistics:
    queries performed:
        read:                            0
        write:                           128891873
        other:                           0
        total:                           128891873
    transactions:                        0      (0.00 per sec.)
    read/write requests:                 128891873 (35803.18 per sec.)
    other operations:                    0      (0.00 per sec.)
    ignored errors:                      0      (0.00 per sec.)
    reconnects:                          0      (0.00 per sec.)

General statistics:
    total time:                          3600.0123s
    total number of events:              128891873
    total time taken by event execution: 230251.4002s
    response time:
         min:                                  0.11ms
         avg:                                  1.79ms
         max:                               2990.25ms
         approx.  95 percentile:               2.34ms

Threads fairness:
    events (avg/stddev):           2013935.5156/717.94
    execution time (avg/stddev):   3597.6781/0.01

